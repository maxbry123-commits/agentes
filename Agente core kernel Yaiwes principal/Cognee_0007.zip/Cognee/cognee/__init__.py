"""Public Python API for Cognee.

This module exposes the main functions and objects intended for direct use
through ``import cognee``. It groups the stable V1 API, memory-oriented V2 API,
visualization helpers, tracing utilities, migration helpers, and session models
behind a single package-level entrypoint.

Common entrypoints include:
    add: Add data to a Cognee dataset.
    cognify: Process ingested data into Cognee's knowledge representation.
    search: Query processed data using the configured search type.
    remember: Store memory-oriented entries using the V2 API.
    recall: Retrieve information from memory-oriented entries.
    delete: Remove data from Cognee-managed storage.
"""

# ruff: noqa: E402
from cognee.version import get_cognee_version

# NOTE: __version__ extraction must be at the top of the __init__.py otherwise
#       there will be circular import issues
__version__ = get_cognee_version()

# Load environment variable settings has to be before setting up logging for LOG_LEVEL value
import dotenv

dotenv.load_dotenv(override=True)

# NOTE: Log level can be set with the LOG_LEVEL env variable
from cognee.shared.logging_utils import setup_logging

logger = setup_logging()

# ---------------------------------------------------------------------------
# V1 API
# ---------------------------------------------------------------------------
from .api.v1.add import add
from .api.v1.delete import delete
from .api.v1.cognify import cognify
from .modules.memify import memify
from .modules.run_custom_pipeline import run_custom_pipeline
from .api.v1.update import update
from .api.v1.config.config import config
from .api.v1.datasets.datasets import datasets
from .api.v1.agents.agents import agents
from .api.v1.prune import prune
from .api.v1.search import SearchType, search
from .api.v1.report import report
from .api.v1.validate import validate, ValidationReport, ValidationIssue, ValidationStatus
from .api.v1.visualize import (
    visualize_graph,
    start_visualization_server,
    get_schema_inventory,
    get_memory_provenance_graph,
    visualize_memory_provenance,
)
from cognee.modules.visualization.cognee_network_visualization import (
    cognee_network_visualization,
)
from .api.v1.ui import start_ui
from .api.v1.session import session

# Pipelines
from .modules import pipelines
from .pipelines import Drop

# Migrations
from cognee.run_migrations import run_migrations

# ---------------------------------------------------------------------------
# V2 memory-oriented API
# ---------------------------------------------------------------------------
from .api.v1 import (
    remember,
    RememberResult,
    recall,
    improve,
    forget,
    serve,
    disconnect,
    visualize,
    push,
    PushResult,
    export,
    ExportResult,
)
from .memory import MemoryEntry, QAEntry, TraceEntry, FeedbackEntry

# Memory migration (cognee.migration has the provider sources:
# Mem0Source, ZepSource/GraphitiSource, LettaSource, COGXArchiveSource)
from . import migration

# Tracing / Observability
from cognee.modules.observability.trace_context import (
    enable_tracing,
    disable_tracing,
    get_last_trace,
    get_all_traces,
    clear_traces,
)

# Agent memory
from cognee.modules.agent_memory import agent_memory

# Tool connections (authorized external databases for recall's "tools" scope)
from .api.v1.tools import tools

# Relational DB models
from cognee.modules.session_lifecycle.models import SessionModelUsage, SessionRecord
import cognee.modules.migrations.models  # noqa: F401  (registers global_database_version)
import cognee.modules.tools.models  # noqa: F401  (registers tool_connections)
