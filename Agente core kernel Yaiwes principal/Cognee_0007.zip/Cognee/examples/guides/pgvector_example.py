"""Use PostgreSQL with the PGVector extension as cognee's vector (and relational) store.

Prerequisites:
1. Install the Postgres extra: `uv pip install "cognee[postgres]"`
2. Start a Postgres server with the pgvector extension, e.g. with Docker:
   docker run -p 5432:5432 -e POSTGRES_USER=cognee -e POSTGRES_PASSWORD=cognee \
       -e POSTGRES_DB=cognee_db pgvector/pgvector:pg17
   (The credentials above match the defaults hardcoded below; override DB_HOST in
   `.env` if the server is not on 127.0.0.1.)
3. A configured LLM (`LLM_API_KEY` in `.env`).
"""

# ruff: noqa: E402
import os
import pathlib
import asyncio

from dotenv import load_dotenv

load_dotenv(override=True)

DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")

import cognee
from cognee import SearchType


async def main():
    """
    Example script demonstrating how to use Cognee with PGVector

    This example:
    1. Configures Cognee to use PostgreSQL with PGVector extension as vector database
    2. Sets up data directories
    3. Stores sample data with remember to Cognee
    4. Performs different types of searches
    """
    # Configure PGVector as the vector database provider
    cognee.config.set_vector_db_config(
        {
            "vector_db_provider": "pgvector",  # Specify PGVector as provider
            "vector_dataset_database_handler": "pgvector",
            "vector_db_name": "cognee_db",
            "vector_db_host": os.environ.get("DB_HOST", "127.0.0.1"),
            "vector_db_port": "5432",
            "vector_db_username": "cognee",
            "vector_db_password": "cognee",
        }
    )

    # Configure PostgreSQL connection details
    # These settings are required for PGVector
    cognee.config.set_relational_db_config(
        {
            "db_path": "",
            "db_name": "cognee_db",
            "db_host": DB_HOST,
            "db_port": "5432",
            "db_username": "cognee",
            "db_password": "cognee",
            "db_provider": "postgres",
        }
    )

    # Set up data directories for storing documents and system files
    # You should adjust these paths to your needs
    current_dir = pathlib.Path(__file__).parent
    data_directory_path = str(current_dir / "data_storage")
    cognee.config.data_root_directory(data_directory_path)

    cognee_directory_path = str(current_dir / "cognee_system")
    cognee.config.system_root_directory(cognee_directory_path)

    # Clean any existing data (optional)
    # await cognee.forget(everything=True)

    # Create a dataset
    dataset_name = "pgvector_example"

    # Add sample text to the dataset
    sample_text = """PGVector is an extension for PostgreSQL that adds vector similarity search capabilities.
    It supports multiple indexing methods, including IVFFlat, HNSW, and brute-force search.
    PGVector allows you to store vector embeddings directly in your PostgreSQL database.
    It provides distance functions like L2 distance, inner product, and cosine distance.
    Using PGVector, you can perform both metadata filtering and vector similarity search in a single query.
    The extension is often used for applications like semantic search, recommendations, and image similarity."""

    # Add the sample text to the dataset
    await cognee.remember([sample_text], dataset_name=dataset_name, self_improvement=False)

    # Now let's perform some searches
    # 1. Search for insights related to "PGVector"
    insights_results = await cognee.recall(
        query_type=SearchType.GRAPH_COMPLETION, query_text="PGVector"
    )
    print("\nInsights about PGVector:")
    for result in insights_results:
        print(f"- {result}")

    # 2. Search for text chunks related to "vector similarity"
    chunks_results = await cognee.recall(
        query_type=SearchType.CHUNKS, query_text="vector similarity", datasets=[dataset_name]
    )
    print("\nChunks about vector similarity:")
    for result in chunks_results:
        print(f"- {result}")

    # 3. Get graph completion related to databases
    graph_completion_results = await cognee.recall(
        query_type=SearchType.GRAPH_COMPLETION, query_text="database"
    )
    print("\nGraph completion for databases:")
    for result in graph_completion_results:
        print(f"- {result}")

    # Clean up (optional)
    # await cognee.forget(everything=True)


if __name__ == "__main__":
    asyncio.run(main())
