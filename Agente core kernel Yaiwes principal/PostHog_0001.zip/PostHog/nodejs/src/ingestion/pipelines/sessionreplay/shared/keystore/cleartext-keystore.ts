import { DeleteKeyResult, KeyStore, SessionKey } from '~/ingestion/pipelines/sessionreplay/shared/types'

/**
 * Cleartext key store used for hobby deployments and local development instances.
 * Returns empty keys and treats all sessions as cleartext (unencrypted).
 */
export class CleartextKeyStore implements KeyStore {
    start(): Promise<void> {
        return Promise.resolve()
    }

    generateKey(_sessionId: string, _teamId: number, _retentionDays: number): Promise<SessionKey> {
        return Promise.resolve({
            plaintextKey: Buffer.alloc(0),
            encryptedKey: Buffer.alloc(0),
            sessionState: 'cleartext',
        })
    }

    getKey(_sessionId: string, _teamId: number): Promise<SessionKey> {
        return Promise.resolve({
            plaintextKey: Buffer.alloc(0),
            encryptedKey: Buffer.alloc(0),
            sessionState: 'cleartext',
        })
    }

    deleteKey(_sessionId: string, _teamId: number, deletedBy: string): Promise<DeleteKeyResult> {
        // Cleartext sessions have no encryption key to shred, but we return success
        // so the recording-api continues with the rest of the delete pipeline
        // (Kafka deletion event + Postgres cleanup).
        return Promise.resolve({ status: 'deleted', deletedAt: Math.floor(Date.now() / 1000), deletedBy })
    }

    stop(): void {}
}
