"""
GigaChat Chat Transformation

Transforms OpenAI-format requests to GigaChat format and back.
"""

from __future__ import annotations

import json
import time
import uuid
from collections.abc import AsyncIterator, Iterator, Mapping, Sequence
from typing import TYPE_CHECKING, Any, Final

import httpx

from litellm._logging import verbose_logger
from litellm.llms.base_llm.chat.transformation import BaseConfig, BaseLLMException
from litellm.llms.gigachat.utils import convert_usage, get_api_base
from litellm.secret_managers.main import get_secret_str
from litellm.types.llms.openai import AllMessageValues
from litellm.types.utils import Choices, Message, ModelResponse

from ..authenticator import get_access_token
from ..file_handler import upload_file_sync

if TYPE_CHECKING:
    import tiktoken

    from litellm.litellm_core_utils.litellm_logging import Logging as _LiteLLMLoggingObj

    LiteLLMLoggingObj = _LiteLLMLoggingObj
else:
    LiteLLMLoggingObj = Any


def is_valid_json(value: str) -> bool:
    """Checks whether the value passed is a valid serialized JSON string"""
    try:
        json.loads(value)
    except json.JSONDecodeError:
        return False
    else:
        return True


class GigaChatError(BaseLLMException):
    """GigaChat API error."""


class GigaChatConfig(BaseConfig):
    """
    Configuration class for GigaChat API.

    GigaChat is Sber's (Russia's largest bank) LLM API.

    Supported parameters:
        temperature: Sampling temperature (0-2, default 0.87)
        top_p: Nucleus sampling parameter
        max_tokens: Maximum tokens to generate
        repetition_penalty: Repetition penalty factor
        profanity_check: Enable content filtering
        stream: Enable streaming
    """

    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    repetition_penalty: float | None = None
    profanity_check: bool | None = None

    def __init__(
        self,
        temperature: float | None = None,
        top_p: float | None = None,
        max_tokens: int | None = None,
        repetition_penalty: float | None = None,
        profanity_check: bool | None = None,
    ) -> None:
        locals_: Final = locals().copy()
        for key, value in locals_.items():
            if key != "self" and value is not None:
                setattr(self.__class__, key, value)
        # Instance variables for current request context
        self._current_credentials: str | None = None
        self._current_api_base: str | None = None

    def get_complete_url(
        self,
        api_base: str | None,
        api_key: str | None,
        model: str,
        optional_params: Mapping[str, object],
        litellm_params: Mapping[str, object],
        stream: bool | None = None,
    ) -> str:
        """Get complete API URL for chat completions."""
        base: Final = get_api_base(api_base)
        return f"{base}/chat/completions"

    def validate_environment(
        self,
        headers: dict,  # mutable-ok: mutates in place per GigaChat OAuth setup
        model: str,
        messages: Sequence[AllMessageValues],
        optional_params: Mapping[str, object],
        litellm_params: Mapping[str, object],
        api_key: str | None = None,
        api_base: str | None = None,
    ) -> dict:  # mutable-ok: base class contract returns dict for httpx
        """
        Set up headers with OAuth token.
        """
        # Get access token
        credentials: Final = api_key or get_secret_str("GIGACHAT_CREDENTIALS") or get_secret_str("GIGACHAT_API_KEY")
        access_token: Final = get_access_token(credentials=credentials, litellm_params=litellm_params)

        # Store credentials for image uploads
        self._current_credentials = credentials
        self._current_api_base = api_base

        headers["Authorization"] = f"Bearer {access_token}"
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json"

        return headers

    def get_supported_openai_params(self, model: str) -> list[str]:  # mutable-ok: base class contract returns list
        """Return list of supported OpenAI parameters."""
        return [  # mutable-ok: base class contract returns list
            "stream",
            "temperature",
            "top_p",
            "max_tokens",
            "max_completion_tokens",
            "stop",
            "tools",
            "tool_choice",
            "functions",
            "function_call",
            "response_format",
        ]

    def map_openai_params(
        self,
        non_default_params: Mapping[str, object],
        optional_params: dict,  # mutable-ok: mutated in place per GigaChat mapping
        model: str,
        drop_params: bool,
    ) -> dict:  # mutable-ok: base class contract returns dict
        """Map OpenAI parameters to GigaChat parameters."""
        for param, value in non_default_params.items():
            if param == "stream":
                optional_params["stream"] = value
            elif param == "temperature":
                # GigaChat: temperature 0 means use top_p=0 instead
                if value == 0:
                    optional_params["top_p"] = 0
                else:
                    optional_params["temperature"] = value
            elif param == "top_p":
                optional_params["top_p"] = value
            elif param in ("max_tokens", "max_completion_tokens"):
                optional_params["max_tokens"] = value
            elif param == "stop":
                # GigaChat doesn't support stop sequences
                pass
            elif param == "tools":
                # Convert tools to functions format
                if isinstance(value, Sequence):
                    optional_params["functions"] = self._convert_tools_to_functions(value)
            elif param == "tool_choice":
                # Map OpenAI tool_choice to GigaChat function_call
                if isinstance(value, (str, Mapping)):
                    mapped_choice = self._map_tool_choice(value)
                    if mapped_choice is not None:
                        optional_params["function_call"] = mapped_choice
            elif param == "functions":
                optional_params["functions"] = value
            elif param == "function_call":
                optional_params["function_call"] = value
            elif param == "response_format":
                # Handle structured output via function calling
                if isinstance(value, Mapping) and value.get("type") == "json_schema":
                    json_schema = value.get("json_schema", {})
                    schema_name = json_schema.get("name", "structured_output")
                    schema = json_schema.get("schema", {})

                    function_def = {  # mutable-ok: request payload for httpx
                        "name": schema_name,
                        "description": f"Output structured response: {schema_name}",
                        "parameters": schema,
                    }

                    existing_functions = optional_params.get("functions")
                    optional_params["functions"] = [
                        *(
                            existing_functions
                            if isinstance(existing_functions, Sequence) and not isinstance(existing_functions, str)
                            else ()
                        ),
                        function_def,
                    ]
                    optional_params["function_call"] = {"name": schema_name}  # mutable-ok: request payload
                    optional_params["_structured_output"] = True

        return optional_params

    def _convert_tools_to_functions(self, tools: Sequence) -> Sequence[dict]:
        """Convert OpenAI tools format to GigaChat functions format."""
        functions: Final[list[dict]] = []  # mutable-ok: accumulator for building functions list
        for tool in tools:
            if isinstance(tool, dict) and tool.get("type") == "function":
                func = tool.get("function", {})
                functions.append(
                    {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "parameters": func.get("parameters", {}),
                    }
                )
        return functions

    def _map_tool_choice(self, tool_choice: str | Mapping[str, object]) -> str | Mapping[str, object] | None:
        """
        Map OpenAI tool_choice to GigaChat function_call format.

        OpenAI format:
        - "auto": Call zero, one, or multiple functions (default)
        - "required": Call one or more functions
        - "none": Don't call any functions
        - {"type": "function", "function": {"name": "get_weather"}}: Force specific function

        GigaChat format:
        - "none": Disable function calls
        - "auto": Automatic mode (default)
        - {"name": "get_weather"}: Force specific function

        Args:
            tool_choice: OpenAI tool_choice value

        Returns:
            GigaChat function_call value or None
        """
        if tool_choice == "none":
            return "none"
        elif tool_choice == "auto":
            return "auto"
        elif tool_choice == "required":
            # GigaChat doesn't have a direct "required" equivalent
            # Use "auto" as the closest behavior
            return "auto"
        elif isinstance(tool_choice, dict):
            # OpenAI format: {"type": "function", "function": {"name": "func_name"}}
            # GigaChat format: {"name": "func_name"}
            if tool_choice.get("type") == "function":
                function_spec: Final = tool_choice.get("function")
                func_name: Final = function_spec.get("name") if isinstance(function_spec, Mapping) else None
                if isinstance(func_name, str) and func_name:
                    return {"name": func_name}

        # Default to None (don't set function_call)
        return None

    def _upload_image(self, image_url: str) -> str | None:
        """
        Upload image to GigaChat and return file_id.

        Args:
            image_url: URL or base64 data URL of the image

        Returns:
            file_id string or None if upload failed
        """
        try:
            return upload_file_sync(
                image_url=image_url,
                credentials=self._current_credentials,
                api_base=self._current_api_base,
            )
        except Exception as e:
            verbose_logger.error("Failed to upload image: %s", e)
            return None

    def _transform_list_content(self, content: Sequence) -> tuple[str, Sequence[str]]:
        """
        Extract text and image attachments from a multimodal message content list.

        Args:
            content: List of content parts (OpenAI multimodal format)

        Returns:
            Tuple of (combined text, list of attachment file ids)
        """
        texts: Final[list[str]] = []  # mutable-ok: accumulator
        attachments: Final[list[str]] = []  # mutable-ok: accumulator
        for part in content:
            if isinstance(part, dict):
                if part.get("type") == "text":
                    texts.append(part.get("text", ""))
                elif part.get("type") == "image_url":
                    # Extract image URL and upload to GigaChat
                    image_url: object = part.get("image_url", {})
                    upload_url: str
                    if isinstance(image_url, str):
                        upload_url = image_url
                    else:
                        upload_url = str(image_url.get("url", "")) if isinstance(image_url, dict) else ""
                    if upload_url:
                        file_id = self._upload_image(upload_url)
                        if file_id:
                            attachments.append(file_id)
        text: Final = "\n".join(texts) if texts else ""
        return text, attachments

    def transform_request(
        self,
        model: str,
        messages: Sequence[AllMessageValues],
        optional_params: Mapping[str, object],
        litellm_params: Mapping[str, object],
        headers: Mapping[str, object],
    ) -> dict:  # mutable-ok: request payload sent to httpx
        """Transform OpenAI request to GigaChat format."""
        # Transform messages
        giga_messages: Final = self._transform_messages(messages)

        # Build request
        request_data: Final[dict[str, object]] = {
            "model": model.replace("gigachat/", ""),
            "messages": giga_messages,
        }

        # Add optional params
        for key in [
            "temperature",
            "top_p",
            "max_tokens",
            "stream",
            "repetition_penalty",
            "profanity_check",
        ]:
            if key in optional_params:
                request_data[key] = optional_params[key]

        # Add functions if present
        if "functions" in optional_params:
            request_data["functions"] = optional_params["functions"]
        if "function_call" in optional_params:
            request_data["function_call"] = optional_params["function_call"]

        return request_data

    def _transform_messages(self, messages: Sequence[AllMessageValues]) -> Sequence[dict]:
        """Transform OpenAI messages to GigaChat format."""
        transformed: Final[list[dict]] = []  # mutable-ok: accumulator for building transformed messages

        for i, msg in enumerate(messages):
            message = dict(msg)

            # Remove unsupported fields
            message.pop("name", None)

            # Transform roles
            role = message.get("role", "user")
            if role == "developer":
                message["role"] = "system"
            elif role == "system" and i > 0:
                # GigaChat only allows system message as first message
                message["role"] = "user"
            elif role == "tool":
                message["role"] = "function"
                content = message.get("content", "")
                if not isinstance(content, str) or not is_valid_json(content):
                    message["content"] = json.dumps(content, ensure_ascii=False)

            # Handle None content
            if message.get("content") is None:
                message["content"] = ""

            # Handle list content (multimodal) - extract text and images
            content = message.get("content")
            if isinstance(content, list):
                message["content"], attachments = self._transform_list_content(content)
                if attachments:
                    message["attachments"] = attachments

            # Transform tool_calls to function_call
            tool_calls = message.get("tool_calls")
            if tool_calls and isinstance(tool_calls, list) and len(tool_calls) > 0:
                tool_call = tool_calls[0]
                func = tool_call.get("function", {})
                args = func.get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {}
                message["function_call"] = {
                    "name": func.get("name", ""),
                    "arguments": args,
                }
                message.pop("tool_calls", None)

            transformed.append(message)

        return transformed

    def transform_response(
        self,
        model: str,
        raw_response: httpx.Response,
        model_response: ModelResponse,
        logging_obj: LiteLLMLoggingObj,
        request_data: dict,
        messages: list[AllMessageValues],
        optional_params: dict,
        litellm_params: dict,
        encoding: tiktoken.Encoding | None,
        api_key: str | None = None,
        json_mode: bool | None = None,
    ) -> ModelResponse:
        """Transform GigaChat response to OpenAI format."""
        try:
            response_json: Final = raw_response.json()
        except Exception:
            raise GigaChatError(
                status_code=raw_response.status_code,
                message=f"Invalid JSON response: {raw_response.text}",
            )

        is_structured_output: Final = optional_params.get("_structured_output", False)

        choices: Final[list[Choices]] = []  # mutable-ok: accumulator for building response choices
        for choice in response_json.get("choices", []):
            message_data = choice.get("message", {})
            finish_reason = choice.get("finish_reason", "stop")

            # Transform function_call to tool_calls or content
            if finish_reason == "function_call" and message_data.get("function_call"):
                func_call = message_data["function_call"]
                args = func_call.get("arguments", {})

                if is_structured_output:
                    # Convert to content for structured output
                    if isinstance(args, dict):
                        content = json.dumps(args, ensure_ascii=False)
                    else:
                        content = str(args)
                    message_data["content"] = content
                    message_data.pop("function_call", None)
                    message_data.pop("functions_state_id", None)
                    finish_reason = "stop"
                else:
                    # Convert to tool_calls format
                    if isinstance(args, dict):
                        args = json.dumps(args, ensure_ascii=False)
                    message_data["tool_calls"] = [
                        {
                            "id": f"call_{uuid.uuid4().hex[:24]}",
                            "type": "function",
                            "function": {
                                "name": func_call.get("name", ""),
                                "arguments": args,
                            },
                        }
                    ]
                    message_data.pop("function_call", None)
                    finish_reason = "tool_calls"

            # Clean up GigaChat-specific fields
            message_data.pop("functions_state_id", None)

            choices.append(
                Choices(
                    index=choice.get("index", 0),
                    message=Message(
                        role=message_data.get("role", "assistant"),
                        content=message_data.get("content"),
                        tool_calls=message_data.get("tool_calls"),
                    ),
                    finish_reason=finish_reason,
                )
            )

        # Build usage
        usage_data: Final = response_json.get("usage", {})
        usage: Final = convert_usage(usage_data)

        model_response.id = response_json.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}")
        model_response.created = response_json.get("created", int(time.time()))
        model_response.model = model
        model_response.choices = choices
        setattr(model_response, "usage", usage)

        return model_response

    def get_error_class(
        self,
        error_message: str,
        status_code: int,
        headers: dict | httpx.Headers,
    ) -> BaseLLMException:
        """Return GigaChat error class."""
        return GigaChatError(
            status_code=status_code,
            message=error_message,
            headers=headers,
        )

    def get_model_response_iterator(
        self,
        streaming_response: Iterator[str] | AsyncIterator[str] | ModelResponse,
        sync_stream: bool,
        json_mode: bool | None = False,
    ):
        """Return streaming response iterator."""
        from .streaming import GigaChatModelResponseIterator

        return GigaChatModelResponseIterator(
            streaming_response=streaming_response,
            sync_stream=sync_stream,
            json_mode=json_mode,
        )
