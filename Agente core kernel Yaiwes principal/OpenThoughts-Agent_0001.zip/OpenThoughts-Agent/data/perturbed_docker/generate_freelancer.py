"""
Generate controlled perturbations for Dockerfiles to increase difficulty
"""

from data.commons import (
    create_task_from_dockerfiles_and_questions,
    filter_tasks_by_docker_start_working,
    upload_tasks_to_hf,
    upsample_tasks_directory,
)
from data.perturbed_docker.utils import generate_dockerfiles_with_perturbations
from data.freelancer.generate import scrape_freelancer_projects


def main() -> None:
    questions = scrape_freelancer_projects(
        use_discovery=True, max_projects=None, use_all_categories=True
    )
    dockerfiles = generate_dockerfiles_with_perturbations(questions)
    output_dir = create_task_from_dockerfiles_and_questions(dockerfiles, questions)
    print(f"Generated dataset at: {output_dir}")
    filtered_dataset_dir = filter_tasks_by_docker_start_working(output_dir)
    print(f"Filtered dataset at: {filtered_dataset_dir}")
    upsampled_dataset_dir = upsample_tasks_directory(filtered_dataset_dir, 10_000)
    upload_tasks_to_hf(
        upsampled_dataset_dir, "DCAgent/perturbed-docker-exp-freelancer-tasks"
    )
    # hf_dataset = run_dataset_to_traces(output_dir, model_name="gpt-5-nano-2025-08-07", agent_name="terminus-2", n_concurrent=256, agent_kwargs={"max_episodes": 8})
    # upload_traces_to_hf(hf_dataset, "DCAgent/perturbed-docker-exp-freelancer-traces", "SFT")


if __name__ == "__main__":
    main()
