from data.taskmaster2.generate import (
    download_taskmaster2_data,
    extract_questions_from_conversations,
    generate_tasks_from_questions,
    subsample_tasks_directory,
    upload_tasks_to_hf,
    upload_traces_to_hf,
)
from scripts.harbor.run_and_export_traces import run_dataset_to_traces


def main() -> None:
    """Main function - coordinates the pipeline with temp directories"""
    conversations = download_taskmaster2_data()
    questions = extract_questions_from_conversations(conversations)
    final_dataset_dir = generate_tasks_from_questions(questions, "taskmaster2")
    subsampled_dataset_dir = subsample_tasks_directory(final_dataset_dir, 10_000)
    upload_tasks_to_hf(subsampled_dataset_dir, "DCAgent/taskmaster2-sandboxes")
    hf_dataset = run_dataset_to_traces(
        subsampled_dataset_dir,
        model_name="gpt-5-mini-2025-08-07",
        agent_name="terminus-2",
        n_concurrent=256,
        agent_kwargs={"max_episodes": 8},
    )
    upload_traces_to_hf(hf_dataset, "DCAgent/taskmaster2-gpt5mini", "SFT")


if __name__ == "__main__":
    main()
