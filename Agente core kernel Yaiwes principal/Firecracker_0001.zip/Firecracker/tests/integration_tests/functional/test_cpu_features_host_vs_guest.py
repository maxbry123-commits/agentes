# Copyright 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

# pylint: disable=too-many-statements
# pylint: disable=too-many-branches

"""
Check CPU features in the host vs the guest.

This test can highlight differences between the host and what the guest sees.

No CPU templates as we are interested only on what is passed through to the guest by default.
For that, check test_feat_parity.py
"""

import os

from framework import utils
from framework.properties import global_props
from framework.utils_cpuid import CPU_FEATURES_CMD, CpuModel

CPU_MODEL = global_props.cpu_codename

INTEL_HOST_ONLY_FEATS = {
    "acpi",
    "aperfmperf",
    "arch_perfmon",
    "art",
    "bts",
    "cat_l3",
    "cdp_l3",
    "cqm",
    "cqm_llc",
    "cqm_mbm_local",
    "cqm_mbm_total",
    "cqm_occup_llc",
    "dca",
    "ds_cpl",
    "dtes64",
    "dtherm",
    "dts",
    "epb",
    "ept",
    "ept_ad",
    "est",
    "flexpriority",
    "flush_l1d",
    "hwp",
    "hwp_act_window",
    "hwp_epp",
    "hwp_pkg_req",
    "ibpb_exit_to_user",
    "ida",
    "intel_ppin",
    "intel_pt",
    "mba",
    "monitor",
    "pbe",
    "pdcm",
    "pebs",
    "pln",
    "pts",
    "rdt_a",
    "sdbg",
    "smx",
    "tm",
    "tm2",
    "tpr_shadow",
    "vmx",
    "vnmi",
    "vpid",
    "xtpr",
}

INTEL_GUEST_ONLY_FEATS = {
    "hypervisor",
    "tsc_known_freq",
    "umip",
}

AMD_MILAN_HOST_ONLY_FEATS = {
    "amd_ppin",
    "aperfmperf",
    "bpext",
    "cat_l3",
    "cdp_l3",
    "cpb",
    "cqm",
    "cqm_llc",
    "cqm_mbm_local",
    "cqm_mbm_total",
    "cqm_occup_llc",
    "decodeassists",
    "extapic",
    "flushbyasid",
    "hw_pstate",
    "ibpb_exit_to_user",
    "ibs",
    "irperf",
    "lbrv",
    "mba",
    "monitor",
    "mwaitx",
    "overflow_recov",
    "pausefilter",
    "perfctr_llc",
    "perfctr_nb",
    "pfthreshold",
    "rdpru",
    "rdt_a",
    "sev",
    "sev_es",
    "skinit",
    "smca",
    "sme",
    "succor",
    "svm_lock",
    "tce",
    "tsc_scale",
    "v_vmsave_vmload",
    "vgif",
    "vmcb_clean",
    "wdt",
    "npt",
    "nrip_save",
    "svm",
}

AMD_GUEST_ONLY_FEATS = {
    "hypervisor",
    "tsc_adjust",
    "tsc_deadline_timer",
    "tsc_known_freq",
}

AMD_MILAN_HOST_ONLY_FEATS_6_1 = AMD_MILAN_HOST_ONLY_FEATS - {
    "sme",
} | {"brs", "rapl", "v_spec_ctrl"}

# Since v6.11, flags declared in cpufeatures.h without a quoted /proc/cpuinfo name
# are hidden. VMSCAPE added IBPB_EXIT_TO_USER without one, so v6.18+ amzn2023 hides it.
# https://github.com/torvalds/linux/commit/78ce84b9e0a54a0c91a7449f321c1f852c0cd3fc
AMD_MILAN_HOST_ONLY_FEATS_6_18 = AMD_MILAN_HOST_ONLY_FEATS_6_1 - {
    "ibpb_exit_to_user",
}

AMD_GENOA_HOST_ONLY_FEATS = AMD_MILAN_HOST_ONLY_FEATS | {
    "avic",
    "flush_l1d",
    "ibrs_enhanced",
}

AMD_GENOA_HOST_ONLY_FEATS_6_1 = AMD_MILAN_HOST_ONLY_FEATS_6_1 - {"brs"} | {
    "avic",
    "amd_lbr_v2",
    "cppc",
    "flush_l1d",
    "ibrs_enhanced",
    "perfmon_v2",
    "x2avic",
}

AMD_GENOA_HOST_ONLY_FEATS_6_18 = AMD_GENOA_HOST_ONLY_FEATS_6_1 - {
    # Since v6.11, flags declared in cpufeatures.h without a quoted /proc/cpuinfo name
    # are hidden. VMSCAPE added IBPB_EXIT_TO_USER without one, so v6.18+ amzn2023 hides it.
    # https://github.com/torvalds/linux/commit/78ce84b9e0a54a0c91a7449f321c1f852c0cd3fc
    "ibpb_exit_to_user",
    # Propagated to the guest since:
    # https://github.com/torvalds/linux/commit/8c19b6f257fa (KVM AUTOIBRS, v6.3)
    # https://github.com/torvalds/linux/commit/e7862eda309e (guest synthesises ibrs_enhanced
    # from AUTOIBRS, v6.3; backported to 5.10 and 6.1 LTSs, so our guest kernels pick it up)
    "ibrs_enhanced",
    # Propagated to the guest since:
    # https://github.com/torvalds/linux/commit/45cf86f26148 (KVM advertises FLUSH_L1D, v6.2)
    # https://github.com/torvalds/linux/commit/da3db168fb67 (KVM virtualises MSR_IA32_FLUSH_CMD on SVM, v6.4)
    "flush_l1d",
} | {"cpuid_fault", "la57", "vnmi"}

INTEL_SPR_GNR_HOST_ONLY_FEATS_6_18_REMOVED = {
    # Since v6.11, flags declared in cpufeatures.h without a quoted /proc/cpuinfo name
    # are hidden. VMSCAPE added IBPB_EXIT_TO_USER without one, so v6.18+ amzn2023 hides it.
    # https://github.com/torvalds/linux/commit/78ce84b9e0a54a0c91a7449f321c1f852c0cd3fc
    "ibpb_exit_to_user",
    "pebs",
    # Propagated to the guest since:
    # https://github.com/torvalds/linux/commit/45cf86f26148 (KVM advertises FLUSH_L1D, v6.2)
    "flush_l1d",
    "dts",
    "dtes64",
    "bts",
}
INTEL_SPR_GNR_HOST_ONLY_FEATS_6_18_ADDED = {"la57"}

# Intel Ice Lake is not vulnerable to VMScape (BHB clearing software mitigation), so
# "ibpb_exit_to_user" is not needed.
# https://docs.kernel.org/admin-guide/hw-vuln/vmscape.html#affected-processors
INTEL_ICELAKE_HOST_ONLY_FEATS_5_10 = INTEL_HOST_ONLY_FEATS - {
    "ibpb_exit_to_user",
    "cdp_l3",
} | {"pconfig", "tme", "split_lock_detect"}

INTEL_ICELAKE_HOST_ONLY_FEATS_6_1 = INTEL_ICELAKE_HOST_ONLY_FEATS_5_10 - {
    "bts",
    "dtes64",
    "dts",
    "pebs",
}

INTEL_ICELAKE_HOST_ONLY_FEATS_6_18 = INTEL_ICELAKE_HOST_ONLY_FEATS_6_1 - {
    "flush_l1d",
} | {"la57"}

# CPU features not available when running in a non-metal EC2 C8i, M8i, and R8i instance
EC2_CMR8i_VIRT_UNAVAILABLE = {
    "acpi",
    "arch_lbr",
    "art",
    "bts",
    "cat_l2",
    "cat_l3",
    "cdp_l2",
    "cdp_l3",
    "cqm",
    "cqm_llc",
    "cqm_mbm_local",
    "cqm_mbm_total",
    "cqm_occup_llc",
    "dca",
    "ds_cpl",
    "dtes64",
    "dtherm",
    "dts",
    "enqcmd",
    "epb",
    "est",
    "hwp",
    "hwp_act_window",
    "hwp_epp",
    "hwp_pkg_req",
    "ibpb_exit_to_user",
    "ibt",
    "intel_ppin",
    "intel_pt",
    "la57",
    "mba",
    "pbe",
    "pconfig",
    "pebs",
    "pln",
    "pts",
    "rdt_a",
    "sdbg",
    "smx",
    "split_lock_detect",
    "tm",
    "tm2",
    "xtpr",
}


def test_host_vs_guest_cpu_features(uvm):
    """Check CPU features host vs guest"""

    vm = uvm
    vm.spawn()
    vm.basic_config()
    vm.add_net_iface()
    vm.start()
    host_feats = set(utils.check_output(CPU_FEATURES_CMD).stdout.split())
    guest_feats = set(vm.ssh.check_output(CPU_FEATURES_CMD).stdout.split())

    match CPU_MODEL:
        case CpuModel.AMD_MILAN:
            host_version = global_props.host_linux_version_tpl
            if host_version < (6, 1):
                expected_host_minus_guest = AMD_MILAN_HOST_ONLY_FEATS.copy()
            elif host_version < (6, 18):
                expected_host_minus_guest = AMD_MILAN_HOST_ONLY_FEATS_6_1.copy()
            else:
                expected_host_minus_guest = AMD_MILAN_HOST_ONLY_FEATS_6_18.copy()

            expected_guest_minus_host = AMD_GUEST_ONLY_FEATS.copy()

            # Linux kernel v6.6+ drops the "invpcid_single" synthetic bit.
            # https://github.com/torvalds/linux/commit/54e3d9434ef61b97fd3263c141b928dc5635e50d
            host_has_invpcid_single = host_version < (6, 6)
            guest_has_invpcid_single = vm.guest_kernel_version < (6, 6)
            if host_has_invpcid_single and not guest_has_invpcid_single:
                expected_host_minus_guest |= {"invpcid_single"}
            if not host_has_invpcid_single and guest_has_invpcid_single:
                expected_guest_minus_host |= {"invpcid_single"}

            # Since v6.9, xtopology is reported in /proc/cpuinfo on AMD/HYGON CPUs.
            # https://github.com/torvalds/linux/commit/3d41009425225ca5e09016c634ecee513b4713bb
            # https://github.com/torvalds/linux/commit/f7fb3b2dd92c633871b7037773b89531c488a371
            host_has_xtopology = host_version >= (6, 9)
            guest_has_xtopology = vm.guest_kernel_version >= (6, 9)

            if host_has_xtopology and not guest_has_xtopology:
                expected_host_minus_guest |= {"xtopology"}
            if not host_has_xtopology and guest_has_xtopology:
                expected_guest_minus_host |= {"xtopology"}

            # Since v6.6, debug_swap is reported in /proc/cpuinfo.
            # https://github.com/torvalds/linux/commit/d1f85fbe836e
            # Starting v5.13, KVM masks it out via cpuid_entry_override.
            # https://github.com/torvalds/linux/commit/d9db0fd6c5c9fa7c9a462a2c54d5e91455a74fca
            # Therefore, on older kernels KVM passes the raw CPUID bit through to guests unfiltered.
            host_has_debug_swap = host_version >= (6, 6)
            guest_has_debug_swap = host_version < (
                5,
                13,
            ) and vm.guest_kernel_version >= (6, 6)
            if host_has_debug_swap and not guest_has_debug_swap:
                expected_host_minus_guest |= {"debug_swap"}
            if not host_has_debug_swap and guest_has_debug_swap:
                expected_guest_minus_host |= {"debug_swap"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case CpuModel.AMD_GENOA:
            host_version = global_props.host_linux_version_tpl
            if host_version < (6, 1):
                expected_host_minus_guest = AMD_GENOA_HOST_ONLY_FEATS.copy()
            elif host_version < (6, 18):
                expected_host_minus_guest = AMD_GENOA_HOST_ONLY_FEATS_6_1.copy()
            else:
                # KVM advertises AMD PerfMonV2 to guests since v6.5, so a v6.18 host
                # (KVM >= 6.5) passes it through. The guest only reports "perfmon_v2" if its
                # kernel knows the flag (added in v5.19), so it stays host-only for older
                # guests (e.g. 5.10).
                # https://github.com/torvalds/linux/commit/4a2771895ca6 (KVM AMD PerfMonV2, v6.5)
                expected_host_minus_guest = AMD_GENOA_HOST_ONLY_FEATS_6_18.copy()
                if vm.guest_kernel_version >= (5, 19):
                    expected_host_minus_guest -= {"perfmon_v2"}

            expected_guest_minus_host = AMD_GUEST_ONLY_FEATS.copy()

            # Linux kernel v6.6+ drops the "invpcid_single" synthetic bit.
            # https://github.com/torvalds/linux/commit/54e3d9434ef61b97fd3263c141b928dc5635e50d
            host_has_invpcid_single = host_version < (6, 6)
            guest_has_invpcid_single = vm.guest_kernel_version < (6, 6)
            if host_has_invpcid_single and not guest_has_invpcid_single:
                expected_host_minus_guest |= {"invpcid_single"}
            if not host_has_invpcid_single and guest_has_invpcid_single:
                expected_guest_minus_host |= {"invpcid_single"}

            # Since v6.9, xtopology is reported in /proc/cpuinfo on AMD/HYGON CPUs.
            # https://github.com/torvalds/linux/commit/3d41009425225ca5e09016c634ecee513b4713bb
            # https://github.com/torvalds/linux/commit/f7fb3b2dd92c633871b7037773b89531c488a371
            host_has_xtopology = host_version >= (6, 9)
            guest_has_xtopology = vm.guest_kernel_version >= (6, 9)

            if host_has_xtopology and not guest_has_xtopology:
                expected_host_minus_guest |= {"xtopology"}
            if not host_has_xtopology and guest_has_xtopology:
                expected_guest_minus_host |= {"xtopology"}

            # Since v6.6, debug_swap is reported in /proc/cpuinfo.
            # https://github.com/torvalds/linux/commit/d1f85fbe836e
            # Starting v5.13, KVM masks it out via cpuid_entry_override.
            # https://github.com/torvalds/linux/commit/d9db0fd6c5c9fa7c9a462a2c54d5e91455a74fca
            # Therefore, on older kernels KVM passes the raw CPUID bit through to guests unfiltered.
            host_has_debug_swap = host_version >= (6, 6)
            guest_has_debug_swap = host_version < (
                5,
                13,
            ) and vm.guest_kernel_version >= (6, 6)
            if host_has_debug_swap and not guest_has_debug_swap:
                expected_host_minus_guest |= {"debug_swap"}
            if not host_has_debug_swap and guest_has_debug_swap:
                expected_guest_minus_host |= {"debug_swap"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case CpuModel.INTEL_CASCADELAKE:
            expected_host_minus_guest = INTEL_HOST_ONLY_FEATS.copy()
            expected_guest_minus_host = INTEL_GUEST_ONLY_FEATS.copy()

            # Ubuntu hasn't backported the patch for VMScape yet.
            # This is only requried for Intel Cascade Lake since we only run
            # tests on Intel Cascade Lake for Ubuntu.
            # Since v6.11, flags declared in cpufeatures.h without a quoted /proc/cpuinfo name
            # are hidden. VMSCAPE added IBPB_EXIT_TO_USER without one, so v6.18+ amzn2023 hides it.
            # https://github.com/torvalds/linux/commit/78ce84b9e0a54a0c91a7449f321c1f852c0cd3fc
            host_version = global_props.host_linux_version_tpl
            if "amzn" not in global_props.host_os or host_version >= (6, 18):
                expected_host_minus_guest -= {"ibpb_exit_to_user"}

            # Linux kernel v6.4+ passes through the CPUID bit for "flush_l1d" to guests.
            # https://github.com/torvalds/linux/commit/45cf86f26148e549c5ba4a8ab32a390e4bde216e
            #
            # Our test ubuntu host kernel is v6.14 and has the commit.
            if global_props.host_linux_version_tpl >= (6, 4):
                expected_host_minus_guest -= {"flush_l1d"}

            # Linux kernel v6.6+ drops the "invpcid_single" synthetic feature bit.
            # https://github.com/torvalds/linux/commit/54e3d9434ef61b97fd3263c141b928dc5635e50d
            #
            # Our test ubuntu host kernel is v6.14 and has the commit.
            host_has_invpcid_single = host_version < (6, 6)
            guest_has_invpcid_single = vm.guest_kernel_version < (6, 6)
            if host_has_invpcid_single and not guest_has_invpcid_single:
                expected_host_minus_guest |= {"invpcid_single"}
            if not host_has_invpcid_single and guest_has_invpcid_single:
                expected_guest_minus_host |= {"invpcid_single"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case CpuModel.INTEL_ICELAKE:
            host_version = global_props.host_linux_version_tpl
            if host_version < (6, 1):
                expected_host_minus_guest = INTEL_ICELAKE_HOST_ONLY_FEATS_5_10.copy()
            elif host_version < (6, 18):
                expected_host_minus_guest = INTEL_ICELAKE_HOST_ONLY_FEATS_6_1.copy()
            else:
                expected_host_minus_guest = INTEL_ICELAKE_HOST_ONLY_FEATS_6_18.copy()

            expected_guest_minus_host = INTEL_GUEST_ONLY_FEATS - {"umip"}

            # Linux kernel v6.6+ drops the "invpcid_single" synthetic bit.
            # https://github.com/torvalds/linux/commit/54e3d9434ef61b97fd3263c141b928dc5635e50d
            host_has_invpcid_single = host_version < (6, 6)
            guest_has_invpcid_single = vm.guest_kernel_version < (6, 6)
            if host_has_invpcid_single and not guest_has_invpcid_single:
                expected_host_minus_guest |= {"invpcid_single"}
            if not host_has_invpcid_single and guest_has_invpcid_single:
                expected_guest_minus_host |= {"invpcid_single"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host
        case CpuModel.INTEL_SAPPHIRE_RAPIDS | CpuModel.INTEL_GRANITE_RAPIDS:
            expected_host_minus_guest = INTEL_HOST_ONLY_FEATS.copy()
            expected_guest_minus_host = INTEL_GUEST_ONLY_FEATS.copy()

            host_version = global_props.host_linux_version_tpl
            guest_version = vm.guest_kernel_version

            # KVM does not support virtualization of the following hardware features yet for several
            # reasons (e.g. security, simply difficulty of implementation).
            expected_host_minus_guest |= {
                # Intel Total Memory Encryption (TME) is the capability to encrypt the entirety of
                # physical memory of a system. TME is enabled by system BIOS/hardware and applies to
                # the phyiscal memory as a whole.
                "tme",
                # PCONFIG instruction allows software to configure certain platform features. It
                # supports these features with multiple leaf functions, selecting a leaf function
                # using the value in EAX. As of this writing, the only defined PCONFIG leaf function
                # is for key programming for total memory encryption-multi-key (TME-MK).
                "pconfig",
                # Architectural Last Branch Record (Arch LBR) that is a feature that logs the most
                # recently executed branch instructions (e.g. source and destination addresses).
                # Traditional LBR implementations have existed in Intel CPUs for years and the MSR
                # interface varied by CPU model. Arch LBR is a standardized version. There is a
                # kernel patch created in 2022 but didn't get merged due to a mess.
                # https://lore.kernel.org/all/20221125040604.5051-1-weijiang.yang@intel.com/
                "arch_lbr",
                # ENQCMD/ENQCMDS are instructions that allow software to atomically write 64-byte
                # commands to enqueue registers, which are special device registers accessed using
                # memory-mapped I/O.
                "enqcmd",
                # Intel Resource Director Technology (RDT) feature set provides a set of allocation
                # (resource control) capabilities including Cache Allocation Technology (CAT) and
                # Code and Data Prioritization (CDP).
                # L3 variants are listed in INTEL_HOST_ONLY_FEATS.
                "cat_l2",
                "cdp_l2",
                # Firecracker disables WAITPKG in CPUID normalization.
                # https://github.com/firecracker-microvm/firecracker/pull/5118
                "waitpkg",
            }

            # FIX: Split lock detection should be enabled on Granite Rapids too. This is a temporary patch
            # to prevent recurrent, known test failures. Once addressed, split lock detection will be enabled
            # on both Sapphire and Granite Rapids.
            if CPU_MODEL == CpuModel.INTEL_SAPPHIRE_RAPIDS:
                # This is a synthesized bit for split lock detection that raise an Alignment Check
                # (#AC) exception if an operand of an atomic operation crosses two cache lines. It
                # is not enumerated on CPUID, instead detected by actually attempting to read from
                # MSR address 0x33 (MSR_MEMORY_CTRL in Intel SDM, MSR_TEST_CTRL in Linux kernel).
                expected_host_minus_guest |= {"split_lock_detect"}

            # FIX: VMScape mitigation has not yet been backported to 5.10.
            elif host_version < (6, 1) and CPU_MODEL == CpuModel.INTEL_GRANITE_RAPIDS:
                expected_host_minus_guest -= {
                    "ibpb_exit_to_user",
                }

            # The following features are also not virtualized by KVM yet but are only supported on
            # newer kernel versions.
            if host_version >= (5, 18):
                expected_host_minus_guest |= {
                    # Indirect Brach Tracking (IBT) is a feature where the CPU ensures that indirect
                    # branch targets start with ENDBRANCH instruction (`endbr32` or `endbr64`),
                    # which executes as a no-op; if anything else is found, a control-protection
                    # (#CP) fault will be raised.
                    # https://github.com/torvalds/linux/commit/991625f3dd2cbc4b787deb0213e2bcf8fa264b21
                    "ibt",
                }

                if CPU_MODEL == CpuModel.INTEL_SAPPHIRE_RAPIDS:
                    expected_host_minus_guest |= {
                        # Hardware Feedback Interface (HFI) is a feature that gives OSes a performance
                        # and energy efficiency capability data for each CPU that can be used to
                        # influence task placement decisions. Only available on Sapphire Rapids.
                        # https://github.com/torvalds/linux/commit/7b8f40b3de75c971a4e5f9308b06deb59118dbac
                        "hfi",
                    }

            # FIX: This should also be backported to 5.10. Lower priority than split_lock_detect
            # though.
            elif host_version < (5, 19) and CPU_MODEL == CpuModel.INTEL_GRANITE_RAPIDS:
                expected_host_minus_guest -= {
                    # From v5.19 onwards, PPIN is detected by reading MSRs. On versions before,
                    # a static list of architectures is enumerated. As of now, Granite Rapids has
                    # not been backported to this list, and hence PPIN is not enabled.
                    "intel_ppin",
                }

            # AVX512 FP16 is supported and passed through on v5.11+.
            # https://github.com/torvalds/linux/commit/e1b35da5e624f8b09d2e98845c2e4c84b179d9a4
            # https://github.com/torvalds/linux/commit/2224fc9efb2d6593fbfb57287e39ba4958b188ba
            if host_version >= (5, 11) and guest_version < (5, 11):
                expected_host_minus_guest |= {"avx512_fp16"}

            # AVX VNNI support is supported and passed through on v5.12+.
            # https://github.com/torvalds/linux/commit/b85a0425d8056f3bd8d0a94ecdddf2a39d32a801
            # https://github.com/torvalds/linux/commit/1085a6b585d7d1c441cd10fdb4c7a4d96a22eba7
            if host_version >= (5, 12) and guest_version < (5, 12):
                expected_host_minus_guest |= {"avx_vnni"}

            # Bus lock detection is supported on v5.12+ and passed through on v5.13+.
            # https://github.com/torvalds/linux/commit/f21d4d3b97a8603567e5d4250bd75e8ebbd520af
            # https://github.com/torvalds/linux/commit/76ea438b4afcd9ee8da3387e9af4625eaccff58f
            if host_version >= (5, 13) and guest_version < (5, 12):
                expected_host_minus_guest |= {"bus_lock_detect"}

            # Intel AMX is supported and passed through on v5.17+.
            # https://github.com/torvalds/linux/commit/690a757d610e50c2c3acd2e4bc3992cfc63feff2
            if host_version >= (5, 17) and guest_version < (5, 17):
                expected_host_minus_guest |= {"amx_bf16", "amx_int8", "amx_tile"}

            expected_guest_minus_host -= {
                # UMIP can be emulated by KVM on Intel processors, but is supported in hardware on
                # Intel Sapphire Rapids and passed through.
                "umip",
                # This is a synthesized bit and it is always set on guest thanks to kvm-clock. But
                # Intel Sapphire Rapids reports TSC frequency on CPUID leaf 0x15, so the bit is also
                # set on host.
                "tsc_known_freq",
            }

            # Linux kernel v6.6+ drops the "invpcid_single" synthetic bit.
            # https://github.com/torvalds/linux/commit/54e3d9434ef61b97fd3263c141b928dc5635e50d
            host_has_invpcid_single = host_version < (6, 6)
            guest_has_invpcid_single = guest_version < (6, 6)
            if host_has_invpcid_single and not guest_has_invpcid_single:
                expected_host_minus_guest |= {"invpcid_single"}
            if not host_has_invpcid_single and guest_has_invpcid_single:
                expected_guest_minus_host |= {"invpcid_single"}

            if host_version >= (6, 18):
                expected_host_minus_guest -= INTEL_SPR_GNR_HOST_ONLY_FEATS_6_18_REMOVED
                expected_host_minus_guest |= INTEL_SPR_GNR_HOST_ONLY_FEATS_6_18_ADDED

                # KVM now advertises IBT to the guest, so it's no longer host-only for
                # guests new enough to know the flag (added in v5.18).
                if guest_version >= (5, 18):
                    expected_host_minus_guest -= {"ibt"}

                if CPU_MODEL == CpuModel.INTEL_GRANITE_RAPIDS:
                    # Granite Rapids host kernel 6.18 enables split lock detection (a
                    # host-only synthesized bit; the guest can't read MSR 0x33).
                    expected_host_minus_guest |= {"split_lock_detect"}

            if global_props.is_ec2_virt:
                # These features aren't available in the host
                expected_host_minus_guest -= EC2_CMR8i_VIRT_UNAVAILABLE
                # Both host and guest run under an hypervisor
                expected_guest_minus_host -= {"hypervisor"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host
        case CpuModel.ARM_NEOVERSE_N1:
            expected_guest_minus_host = set()
            expected_host_minus_guest = set()

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case CpuModel.ARM_NEOVERSE_V1 | CpuModel.ARM_NEOVERSE_V2:
            expected_guest_minus_host = set()
            # KVM does not enable PAC or SVE features by default
            # and Firecracker does not enable them either.
            expected_host_minus_guest = {"paca", "pacg", "sve", "svebf16", "svei8mm"}

            if CPU_MODEL == CpuModel.ARM_NEOVERSE_V2:
                expected_host_minus_guest |= {
                    "svebitperm",
                    "svesha3",
                    "sveaes",
                    "sve2",
                    "svepmull",
                }

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case CpuModel.ARM_NEOVERSE_V3:
            expected_guest_minus_host = set()
            expected_host_minus_guest = {
                "paca",
                "pacg",
                "sve",
                "sve2",
                "sveaes",
                "svebf16",
                "svebitperm",
                "svei8mm",
                "svepmull",
                "svesha3",
            }

            # The "wfxt" hwcap and its KVM exposure landed in kernel v5.19.
            # https://github.com/torvalds/linux/commit/69bb02ebc38ace438c9cd7c5315cfe43862b51fe
            # https://github.com/torvalds/linux/commit/06e0b802583d7bbc075476d90da995ee3e6053d5
            host_has_wfxt = global_props.host_linux_version_tpl >= (5, 19)
            guest_has_wfxt = host_has_wfxt and vm.guest_kernel_version >= (5, 19)

            if host_has_wfxt and not guest_has_wfxt:
                expected_host_minus_guest |= {"wfxt"}

            assert host_feats - guest_feats == expected_host_minus_guest
            assert guest_feats - host_feats == expected_guest_minus_host

        case _:
            # only fail if running in CI
            if os.environ.get("BUILDKITE") is not None:
                assert (
                    guest_feats == host_feats
                ), f"Cpu model {CPU_MODEL} is not supported"
