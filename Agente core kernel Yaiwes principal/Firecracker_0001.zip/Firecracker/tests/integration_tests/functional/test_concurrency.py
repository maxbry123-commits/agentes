# Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Ensure multiple microVMs work correctly when spawned simultaneously."""

from concurrent.futures import ThreadPoolExecutor

NO_OF_MICROVMS = 20


def test_run_concurrency(microvm_factory, guest_kernel, rootfs, pci_enabled):
    """
    Check we can spawn multiple microvms.
    """

    def launch1():
        microvm = microvm_factory.build_booted(
            guest_kernel,
            rootfs,
            pci=pci_enabled,
            vcpu_count=1,
            mem_size_mib=128,
        )
        microvm.time_api_requests = False  # is flaky because of parallelism

    with ThreadPoolExecutor(max_workers=NO_OF_MICROVMS) as tpe:
        for _ in range(NO_OF_MICROVMS):
            tpe.submit(launch1)
