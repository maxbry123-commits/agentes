# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Tests that ensure the correctness of the command line parameters."""

import subprocess
from pathlib import Path

import pytest

from framework.artifacts import GUEST_KERNEL_DEFAULT, pin_guest_kernel
from framework.utils import check_output
from host_tools.fcmetrics import validate_fc_metrics


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_describe_snapshot(uvm):
    """
    Test `--describe-snapshot` correctness for all snapshot versions.

    For each release create a snapshot and verify the data version of the
    snapshot state file.
    """

    vm = uvm
    fc_binary = vm.fc_binary_path

    cmd = [fc_binary, "--snapshot-version"]
    snap_version_tuple = check_output(cmd).stdout.strip().split("\n")[0].split(".")
    snap_version = ".".join(str(x) for x in snap_version_tuple)

    vm.spawn()
    vm.basic_config(track_dirty_pages=True)
    vm.start()
    snapshot = vm.snapshot_diff()
    vm.kill()

    cmd = [fc_binary, "--describe-snapshot", snapshot.vmstate]
    _, stdout, stderr = check_output(cmd)
    assert stderr == ""
    assert snap_version in stdout


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cli_metrics_path(uvm):
    """
    Test --metrics-path parameter
    """
    microvm = uvm
    metrics_path = Path(microvm.path) / "my_metrics.ndjson"
    microvm.spawn(metrics_path=metrics_path)
    microvm.basic_config()
    microvm.start()
    metrics = microvm.flush_metrics()
    validate_fc_metrics(metrics)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cli_metrics_path_if_metrics_initialized_twice_fail(uvm):
    """
    Given: a running firecracker with metrics configured with the CLI option
    When: Configure metrics via API
    Then: API returns an error
    """
    microvm = uvm

    # First configure the µvm metrics with --metrics-path
    metrics_path = Path(microvm.path) / "metrics.ndjson"
    metrics_path.touch()
    microvm.spawn(metrics_path=metrics_path)

    # Then try to configure it with PUT /metrics
    metrics2_path = Path(microvm.path) / "metrics2.ndjson"
    metrics2_path.touch()

    # It should fail with because it's already configured
    with pytest.raises(RuntimeError, match="Reinitialization of metrics not allowed."):
        microvm.api.metrics.put(
            metrics_path=microvm.create_jailed_resource(metrics2_path)
        )


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cli_metrics_if_resume_no_metrics(uvm, microvm_factory):
    """
    Check that metrics configuration is not part of the snapshot
    """
    # Given: a snapshot of a FC with metrics configured with the CLI option
    uvm1 = uvm
    metrics_path = Path(uvm1.path) / "metrics.ndjson"
    metrics_path.touch()
    uvm1.spawn(metrics_path=metrics_path)
    uvm1.basic_config()
    uvm1.start()
    snapshot = uvm1.snapshot_full()

    # When: restoring from the snapshot
    uvm2 = microvm_factory.build_from_snapshot(snapshot)

    # Then: the old metrics configuration does not exist
    metrics2 = Path(uvm2.jailer.chroot_path()) / metrics_path.name
    assert not metrics2.exists()


def test_cli_no_params(microvm_factory):
    """
    Test running firecracker with no parameters should work
    """

    fc_binary = microvm_factory.fc_binary_path
    process = subprocess.Popen(fc_binary)
    try:
        process.communicate(timeout=3)
        assert process.returncode is None
    except subprocess.TimeoutExpired:
        # The good case
        process.kill()
