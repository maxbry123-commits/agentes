# Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Tests that verify the jailer's behavior."""

import http.client as http_client
import os
import resource
import stat
import subprocess
import time
from pathlib import Path

import pytest
import requests
import urllib3

from framework.artifacts import GUEST_KERNEL_DEFAULT, pin_guest_kernel
from framework.defs import FC_BINARY_NAME
from framework.jailer import JailerContext

# These are the permissions that all files/dirs inside the jailer have.
REG_PERMS = (
    stat.S_IRUSR
    | stat.S_IWUSR
    | stat.S_IXUSR
    | stat.S_IRGRP
    | stat.S_IXGRP
    | stat.S_IROTH
    | stat.S_IXOTH
)
DIR_STATS = stat.S_IFDIR | stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR
FILE_STATS = stat.S_IFREG | REG_PERMS
SOCK_STATS = stat.S_IFSOCK | REG_PERMS
# These are the stats of the devices created by tha jailer.
CHAR_STATS = stat.S_IFCHR | stat.S_IRUSR | stat.S_IWUSR
# Limit on file size in bytes.
FSIZE = 2097151
# Limit on number of file descriptors.
NOFILE = 1024
# Resource limits to be set by the jailer.
RESOURCE_LIMITS = [
    "no-file={}".format(NOFILE),
    "fsize={}".format(FSIZE),
]


def check_stats(filepath, stats, uid, gid):
    """Assert on uid, gid and expected stats for the given path."""
    st = os.stat(filepath)

    assert st.st_gid == gid
    assert st.st_uid == uid
    assert st.st_mode ^ stats == 0


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_empty_jailer_id(uvm):
    """
    Test that the jailer ID cannot be empty.
    """
    test_microvm = uvm

    # Set the jailer ID to None.
    test_microvm.jailer = JailerContext(
        jailer_id="",
        exec_file=test_microvm.fc_binary_path,
    )

    # If the exception is not thrown, it means that Firecracker was
    # started successfully, hence there's a bug in the code due to which
    # we can set an empty ID.
    with pytest.raises(
        ChildProcessError,
        match=r"Invalid instance ID: Invalid len \(0\);  the length must be between 1 and 64",
    ):
        test_microvm.spawn()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_exec_file_not_exist(uvm, tmp_path):
    """
    Test the jailer option `--exec-file`
    """
    test_microvm = uvm

    # Error case 1: No such file exists
    pseudo_exec_file_path = tmp_path / "pseudo_firecracker_exec_file"
    fc_dir = Path("/srv/jailer") / pseudo_exec_file_path.name / test_microvm.id
    fc_dir.mkdir(parents=True, exist_ok=True)
    test_microvm.jailer.exec_file = pseudo_exec_file_path

    with pytest.raises(
        Exception,
        match=rf"Failed to canonicalize path {pseudo_exec_file_path}:"
        rf" No such file or directory \(os error 2\)",
    ):
        test_microvm.spawn()

    # Error case 2: Not a file
    pseudo_exec_dir_path = tmp_path / "firecracker_test_dir"
    pseudo_exec_dir_path.mkdir()
    fc_dir = Path("/srv/jailer") / pseudo_exec_dir_path.name / test_microvm.id
    fc_dir.mkdir(parents=True, exist_ok=True)
    test_microvm.jailer.exec_file = pseudo_exec_dir_path

    with pytest.raises(
        Exception,
        match=rf"{pseudo_exec_dir_path} is not a file",
    ):
        test_microvm.spawn()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_exec_destination_path_is_symlink(uvm):
    """
    Test the jailer correctly refuses to copy binary into symlink
    """
    test_microvm = uvm

    firecracker_root_dir = Path(test_microvm.chroot())
    firecracker_bin_path = firecracker_root_dir / "firecracker"
    dummy_path = Path("/srv/dummy")
    dummy_path.unlink(missing_ok=True)
    dummy_path.touch()
    firecracker_bin_path.symlink_to(dummy_path)
    with pytest.raises(
        Exception,
        match=f"Failed to open {firecracker_bin_path}",
    ):
        test_microvm.spawn()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_exec_destination_path_is_hardlink(uvm):
    """
    Test the jailer correctly refuses to copy binary into hardlink
    """
    test_microvm = uvm

    firecracker_root_dir = Path(test_microvm.chroot())
    firecracker_bin_path = firecracker_root_dir / "firecracker"
    dummy_path = Path("/srv/dummy")
    dummy_path.unlink(missing_ok=True)
    dummy_path.touch()
    firecracker_bin_path.hardlink_to(dummy_path)
    with pytest.raises(
        Exception,
        match=f"Detected hard link at: {firecracker_bin_path}",
    ):
        test_microvm.spawn()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_default_chroot_hierarchy(uvm):
    """
    Test the folder hierarchy created by default by the jailer.
    """
    test_microvm = uvm

    test_microvm.spawn()

    # We do checks for all the things inside the chroot that the jailer crates
    # by default.
    check_stats(
        test_microvm.jailer.chroot_path(),
        DIR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "dev"),
        DIR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "dev/net"),
        DIR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "run"),
        DIR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "dev/net/tun"),
        CHAR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "dev/kvm"),
        CHAR_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )
    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "firecracker"),
        FILE_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_arbitrary_usocket_location(uvm):
    """
    Test arbitrary location scenario for the api socket.
    """
    test_microvm = uvm
    test_microvm.jailer.extra_args = {"api-sock": "api.socket"}

    test_microvm.spawn(serial_out_path=None)

    check_stats(
        os.path.join(test_microvm.jailer.chroot_path(), "api.socket"),
        SOCK_STATS,
        test_microvm.jailer.uid,
        test_microvm.jailer.gid,
    )


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_jailer_bind_mount_propagation(uvm):
    """
    Test that host bind-mounts inside the chroot propagate into the jail.

    Mounts that exist before the jailer starts, covering the recursive
    self-bind fix (MS_BIND -> MS_BIND | MS_REC).

    Regression test for #1089.
    """
    test_microvm = uvm
    chroot = Path(test_microvm.chroot())

    kernel_jail_name = "vmlinux.bin"
    rootfs_jail_name = "rootfs.img"
    kernel_mount_point = chroot / kernel_jail_name
    rootfs_mount_point = chroot / rootfs_jail_name
    kernel_mount_point.touch()
    rootfs_mount_point.touch()
    try:
        subprocess.check_call(
            ["mount", "--bind", str(test_microvm.kernel_file), str(kernel_mount_point)]
        )
        subprocess.check_call(
            ["mount", "--bind", str(test_microvm.rootfs_file), str(rootfs_mount_point)]
        )
        test_microvm.spawn()

        # Drive the API directly: basic_config() would hardlink over our
        # bind-mount points and mask what we are testing.
        test_microvm.api.machine_config.put(vcpu_count=2, mem_size_mib=256)
        test_microvm.boot_args = (
            "reboot=k panic=1 nomodule swiotlb=noforce console=ttyS0 cryptomgr.notests"
        )
        if not test_microvm.pci_enabled:
            test_microvm.boot_args += " pci=off"
        test_microvm.api.boot.put(
            kernel_image_path=f"/{kernel_jail_name}",
            boot_args=test_microvm.boot_args,
        )
        test_microvm.api.drive.put(
            drive_id="rootfs",
            path_on_host=f"/{rootfs_jail_name}",
            is_root_device=True,
            is_read_only=True,
        )
        test_microvm.add_net_iface()
        test_microvm.start()
        test_microvm.ssh.check_output("true")
    finally:
        # Unmount before the framework's chroot rmtree so it never
        # recurses into the bind-mount sources.
        test_microvm.kill()
        for mp in (rootfs_mount_point, kernel_mount_point):
            subprocess.run(["umount", str(mp)], check=False)


class Cgroups:
    """Helper class to work with cgroups"""

    def __init__(self):
        self.root = Path("/sys/fs/cgroup")
        self.version = 2
        # https://rootlesscontaine.rs/getting-started/common/cgroup2/#checking-whether-cgroup-v2-is-already-enabled
        if not self.root.joinpath("cgroup.controllers").exists():
            self.version = 1

    def new_cgroup(self, cgname):
        """Create a new cgroup"""
        self.root.joinpath(cgname).mkdir(parents=True, exist_ok=True)

    def move_pid(self, cgname, pid):
        """Move a PID to a cgroup"""
        cg_pids = self.root.joinpath(f"{cgname}/cgroup.procs")
        cg_pids.write_text(f"{pid}\n", encoding="ascii")

    def enable_controller_in_subtree(self, cgname, controller):
        """Enable a controller in subtree_control of a cgroup and its ancestors"""
        # Enable the controller in all ancestors if not already enabled.
        parent_cg = self.root.joinpath(cgname).parent
        parent_subtree_control = parent_cg.joinpath("cgroup.subtree_control")
        if controller not in parent_subtree_control.read_text(encoding="ascii"):
            self.enable_controller_in_subtree(
                parent_cg.relative_to(self.root), controller
            )

        subtree_control = self.root.joinpath(f"{cgname}/cgroup.subtree_control")
        subtree_control.write_text(f"+{controller}", encoding="ascii")
        assert controller in subtree_control.read_text(encoding="ascii")


@pytest.fixture(scope="session", autouse=True)
def cgroups_info():
    """Return a fixture with the cgroups available in the system"""
    return Cgroups()


def check_cgroups_v1(cgroups, jailer_id, parent_cgroup=FC_BINARY_NAME):
    """Assert that every cgroupv1 in cgroups is correctly set."""
    # We assume sysfs cgroups are mounted here.
    cgroup_location = "/sys/fs/cgroup"
    assert os.path.isdir(cgroup_location)

    for cgroup in cgroups:
        controller = cgroup.split(".")[0]
        file_name, value = cgroup.split("=")
        location = cgroup_location + "/{}/{}/{}/".format(
            controller, parent_cgroup, jailer_id
        )
        tasks_file = location + "tasks"
        file = location + file_name

        assert open(file, "r", encoding="utf-8").readline().strip() == value
        assert open(tasks_file, "r", encoding="utf-8").readline().strip().isdigit()


def check_cgroups_v2(vm):
    """Assert that every cgroupv2 in cgroups is correctly set."""
    cg = Cgroups()
    assert cg.root.is_dir()
    parent_cgroup = vm.jailer.parent_cgroup
    if parent_cgroup is None:
        parent_cgroup = FC_BINARY_NAME
    cg_parent = cg.root / parent_cgroup
    cg_jail = cg_parent / vm.jailer.jailer_id

    assert len(vm.jailer.cgroups) > 0

    for cgroup in vm.jailer.cgroups:
        controller = cgroup.split(".")[0]
        file_name, value = cgroup.split("=")
        procs = cg_jail.joinpath("cgroup.procs").read_text().splitlines()
        file = cg_jail / file_name

        assert file.read_text().strip() == value

        assert all(x.isnumeric() for x in procs)
        assert str(vm.firecracker_pid) in procs

        for cgroup in [cg.root, cg_parent, cg_jail]:
            assert controller in cgroup.joinpath("cgroup.controllers").read_text(
                encoding="ascii"
            )
            # don't check since there are no children cgroups
            if cgroup == cg_jail:
                continue
            assert controller in cgroup.joinpath("cgroup.subtree_control").read_text(
                encoding="ascii"
            )


def get_cpus(node):
    """Retrieve CPUs from NUMA node."""
    sys_node = "/sys/devices/system/node/node" + str(node)
    assert os.path.isdir(sys_node)
    node_cpus_path = sys_node + "/cpulist"

    return open(node_cpus_path, "r", encoding="utf-8").readline().strip()


def check_limits(pid, no_file, fsize):
    """Verify resource limits against expected values."""
    # Fetch firecracker process limits for number of open fds
    soft, hard = resource.prlimit(pid, resource.RLIMIT_NOFILE)
    assert soft == no_file
    assert hard == no_file

    # Fetch firecracker process limits for maximum file size
    soft, hard = resource.prlimit(pid, resource.RLIMIT_FSIZE)
    assert soft == fsize
    assert hard == fsize


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cgroups(uvm, cgroups_info):
    """
    Test the cgroups are correctly set by the jailer.
    """
    test_microvm = uvm
    test_microvm.jailer.cgroup_ver = cgroups_info.version
    if test_microvm.jailer.cgroup_ver == 2:
        test_microvm.jailer.cgroups = ["cpu.weight.nice=10"]
    else:
        test_microvm.jailer.cgroups = ["cpu.shares=2", "cpu.cfs_period_us=200000"]

    # Retrieve CPUs from NUMA node 0.
    node_cpus = get_cpus(0)

    # Appending the cgroups for numa node 0.
    test_microvm.jailer.cgroups = test_microvm.jailer.cgroups + [
        "cpuset.mems=0",
        "cpuset.cpus={}".format(node_cpus),
    ]

    test_microvm.spawn()

    if test_microvm.jailer.cgroup_ver == 1:
        check_cgroups_v1(test_microvm.jailer.cgroups, test_microvm.jailer.jailer_id)
    else:
        check_cgroups_v2(test_microvm)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cgroups_custom_parent(uvm, cgroups_info):
    """
    Test cgroups when a custom parent cgroup is used.
    """
    test_microvm = uvm
    test_microvm.jailer.cgroup_ver = cgroups_info.version
    test_microvm.jailer.parent_cgroup = "custom_cgroup/group2"
    if test_microvm.jailer.cgroup_ver == 2:
        test_microvm.jailer.cgroups = ["cpu.weight=2"]
    else:
        test_microvm.jailer.cgroups = ["cpu.shares=2", "cpu.cfs_period_us=200000"]

    # Retrieve CPUs from NUMA node 0.
    node_cpus = get_cpus(0)

    test_microvm.jailer.cgroups = test_microvm.jailer.cgroups + [
        "cpuset.mems=0",
        "cpuset.cpus={}".format(node_cpus),
    ]

    test_microvm.spawn()

    if test_microvm.jailer.cgroup_ver == 1:
        check_cgroups_v1(
            test_microvm.jailer.cgroups,
            test_microvm.jailer.jailer_id,
            test_microvm.jailer.parent_cgroup,
        )
    else:
        check_cgroups_v2(test_microvm)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_node_cgroups(uvm, cgroups_info):
    """
    Test the numa node cgroups are correctly set by the jailer.
    """
    test_microvm = uvm
    test_microvm.jailer.cgroup_ver = cgroups_info.version

    # Retrieve CPUs from NUMA node 0.
    node_cpus = get_cpus(0)

    # Appending the cgroups for numa node 0
    test_microvm.jailer.cgroups = ["cpuset.mems=0", "cpuset.cpus={}".format(node_cpus)]

    test_microvm.spawn()

    if test_microvm.jailer.cgroup_ver == 1:
        check_cgroups_v1(test_microvm.jailer.cgroups, test_microvm.jailer.jailer_id)
    else:
        check_cgroups_v2(test_microvm)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cgroups_without_numa(uvm, cgroups_info):
    """
    Test the cgroups are correctly set by the jailer, without numa assignment.
    """
    test_microvm = uvm
    test_microvm.jailer.cgroup_ver = cgroups_info.version
    if test_microvm.jailer.cgroup_ver == 2:
        test_microvm.jailer.cgroups = ["cpu.weight=2"]
    else:
        test_microvm.jailer.cgroups = ["cpu.shares=2", "cpu.cfs_period_us=200000"]

    test_microvm.spawn()

    if test_microvm.jailer.cgroup_ver == 1:
        check_cgroups_v1(test_microvm.jailer.cgroups, test_microvm.jailer.jailer_id)
    else:
        check_cgroups_v2(test_microvm)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_v1_default_cgroups(uvm, cgroups_info):
    """
    Test if the jailer is using cgroup-v1 by default.
    """
    if cgroups_info.version != 1:
        pytest.skip(reason="Requires system with cgroup-v1 enabled.")
    test_microvm = uvm
    test_microvm.jailer.cgroups = ["cpu.shares=2"]
    test_microvm.spawn()
    check_cgroups_v1(test_microvm.jailer.cgroups, test_microvm.jailer.jailer_id)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
@pytest.mark.parametrize(
    "parent_exists,domain_controller_in_subtree",
    [(True, False), (True, True), (False, None)],
)
def test_cgroups_parent_cgroup_but_no_cgroup(
    uvm, cgroups_info, parent_exists, domain_controller_in_subtree
):
    """
    Test cgroups when `--parent-cgroup` is used but no `--cgroup` are specified.

    If the cgroup specified with `--parent-cgroup` exists, the jailer should
    move to the specified cgroup instead of creating a new cgroup under it.
    However, if the specified cgroup has domain controllers (e.g. `memory`)
    enabled in `cgroup.subtree_control`, the move should fail.

    If the specified cgroup does not exist, the jailer does not move the process
    to any cgroup and proceeds without error.
    """
    if cgroups_info.version != 2:
        pytest.skip("cgroupsv2 only")
    test_microvm = uvm
    test_microvm.jailer.cgroup_ver = cgroups_info.version
    # Make it somewhat unique so it doesn't conflict with other test runs
    parent_cgroup = f"custom_cgroup/{test_microvm.id[:8]}"
    test_microvm.jailer.parent_cgroup = parent_cgroup

    if parent_exists:
        # Create the parent cgroup.
        cgroups_info.new_cgroup(parent_cgroup)
        if domain_controller_in_subtree:
            # Enable "memory" controller in cgroup.subtree_control of the parent.
            cgroups_info.enable_controller_in_subtree(parent_cgroup, "memory")

    # Check no --cgroups are specified just in case.
    assert len(test_microvm.jailer.cgroups) == 0

    cg_parent = cgroups_info.root / parent_cgroup

    if parent_exists:
        if domain_controller_in_subtree:
            # The jailer should have failed to move to the `parent_cgroup`
            # since it has domain controllers enabled in
            # `cgroup.subtree_control` due to the no internal process
            # constraint.
            # https://docs.kernel.org/admin-guide/cgroup-v2.html#no-internal-process-constraint
            with pytest.raises(
                ChildProcessError,
                match=(
                    rf"Failed to move process to cgroup \({cg_parent}\): "
                    r"Resource busy \(os error 16\)"
                ),
            ):
                test_microvm.spawn()
        else:
            # The jailer should have moved to the `parent_cgroup` instead of
            # creating a new cgroup under it and move to the new cgroup.
            test_microvm.spawn()
            procs = cg_parent.joinpath("cgroup.procs").read_text().splitlines()
            assert str(test_microvm.firecracker_pid) in procs
    else:
        # The jailer should not have moved to any cgroup and the parent
        # still does not exist.
        test_microvm.spawn()
        assert not cg_parent.exists()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_args_default_resource_limits(uvm):
    """
    Test the default resource limits are correctly set by the jailer.
    """
    test_microvm = uvm
    test_microvm.spawn()
    # Get firecracker's PID
    pid = test_microvm.firecracker_pid
    assert pid != 0

    # Fetch firecracker process limits for number of open fds
    soft, hard = resource.prlimit(pid, resource.RLIMIT_NOFILE)
    # Check that the default limit was set.
    assert soft == 2048
    assert hard == 2048

    # Fetch firecracker process limits for number of open fds
    soft, hard = resource.prlimit(pid, resource.RLIMIT_FSIZE)
    # Check that no limit was set
    assert soft == -1
    assert hard == -1


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_args_resource_limits(uvm):
    """
    Test the resource limits are correctly set by the jailer.
    """
    test_microvm = uvm
    test_microvm.jailer.resource_limits = RESOURCE_LIMITS
    test_microvm.spawn()
    # Get firecracker's PID
    pid = test_microvm.firecracker_pid
    assert pid != 0

    # Check limit values were correctly set.
    check_limits(pid, NOFILE, FSIZE)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_positive_file_size_limit(uvm):
    """
    Test creating vm succeeds when memory size is under `fsize` limit.
    """

    vm_mem_size = 128
    jail_limit = (vm_mem_size + 1) << 20

    test_microvm = uvm
    test_microvm.jailer.resource_limits = [f"fsize={jail_limit}"]
    test_microvm.spawn()
    test_microvm.basic_config(mem_size_mib=vm_mem_size)

    # Attempt to start a vm.
    test_microvm.start()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_negative_file_size_limit(uvm):
    """
    Test creating snapshot file fails when size exceeds `fsize` limit.
    """
    test_microvm = uvm
    # limit to 1MB, to account for logs and metrics
    test_microvm.jailer.resource_limits = [f"fsize={2**20}"]
    test_microvm.spawn()
    test_microvm.basic_config()
    test_microvm.start()

    test_microvm.pause()

    # Attempt to create a snapshot.
    try:
        test_microvm.api.snapshot_create.put(
            mem_file_path="/vm.mem",
            snapshot_path="/vm.vmstate",
        )
    except (
        http_client.RemoteDisconnected,
        urllib3.exceptions.ProtocolError,
        requests.exceptions.ConnectionError,
    ) as _error:
        # Check the microVM received signal `SIGXFSZ` (25),
        # which corresponds to exceeding file size limit.
        msg = "Shutting down VM after intercepting signal 25, code 0"
        test_microvm.check_log_message(msg)
        time.sleep(1)

        test_microvm.mark_killed()
    else:
        assert False, "Negative test failed"


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_negative_no_file_limit(uvm):
    """
    Test microVM is killed when exceeding `no-file` limit.
    """
    test_microvm = uvm
    test_microvm.jailer.resource_limits = ["no-file=3"]

    # pylint: disable=W0703
    try:
        test_microvm.spawn()
    except ChildProcessError as error:
        assert "No file descriptors available (os error 24)" in str(error)

        test_microvm.mark_killed()
    else:
        assert False, "Negative test failed"


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_new_pid_ns_resource_limits(uvm):
    """
    Test that Firecracker process inherits jailer resource limits.
    """
    test_microvm = uvm
    test_microvm.jailer.resource_limits = RESOURCE_LIMITS
    test_microvm.spawn()

    # Get Firecracker's PID.
    fc_pid = test_microvm.firecracker_pid

    # Check limit values were correctly set.
    check_limits(fc_pid, NOFILE, FSIZE)


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_new_pid_namespace(uvm):
    """
    Test that Firecracker is spawned in a new PID namespace if requested.
    """
    test_microvm = uvm
    test_microvm.spawn()
    # Check that the PID file exists.
    fc_pid = test_microvm.firecracker_pid

    # Validate the PID.
    stdout = subprocess.check_output("pidof firecracker", shell=True)
    assert str(fc_pid) in stdout.strip().decode()

    # Get the thread group IDs in each of the PID namespaces of which
    # Firecracker process is a member of.
    nstgid_cmd = "cat /proc/{}/status | grep NStgid".format(fc_pid)
    nstgid_list = (
        subprocess.check_output(nstgid_cmd, shell=True)
        .decode("utf-8")
        .strip()
        .split("\t")[1:]
    )

    # Check that Firecracker's PID namespace is nested. `NStgid` should
    # report two values and the last one should be 1, because Firecracker
    # becomes the init(1) process of the new PID namespace it is spawned in.
    assert len(nstgid_list) == 2
    assert int(nstgid_list[1]) == 1
    assert int(nstgid_list[0]) == fc_pid


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
@pytest.mark.parametrize(
    "daemonize",
    [True, False],
)
@pytest.mark.parametrize(
    "new_pid_ns",
    [True, False],
)
def test_firecracker_kill_by_pid(uvm, daemonize, new_pid_ns):
    """
    Test that Firecracker is spawned in a new PID namespace if requested.
    """
    microvm = uvm
    microvm.jailer.daemonize = daemonize
    microvm.jailer.new_pid_ns = new_pid_ns
    microvm.spawn()
    microvm.basic_config()
    microvm.add_net_iface()
    microvm.start()

    # before killing microvm make sure the Jailer config is what we set it to be.
    assert (
        microvm.jailer.daemonize == daemonize
        and microvm.jailer.new_pid_ns == new_pid_ns
    )
    microvm.kill()


@pin_guest_kernel(GUEST_KERNEL_DEFAULT)
def test_cgroupsv2_written_only_once(uvm, cgroups_info):
    """
    Test that we only write to cgroup.procs once when using CgroupsV2

    Assert that the jailer doesn't perform unneccessary create_dir_all
    and attach_pid calls. This is a regression test for #2856
    """
    if cgroups_info.version != 2:
        pytest.skip(reason="Requires system with cgroup-v2 enabled.")

    strace_output_path = Path(uvm.path, "strace.out")
    strace_cmd = [
        "strace",
        "-tt",
        "--syscall-times=ns",
        "-y",
        "-e",
        "write,mkdir,mkdirat",
        "-o",
        strace_output_path,
    ]
    uvm.add_pre_cmd(strace_cmd)

    parent_cgroup = "custom_cgroup/group2"
    uvm.jailer.cgroup_ver = cgroups_info.version
    uvm.jailer.parent_cgroup = parent_cgroup
    # create the parent so that mkdirs doesn't need to
    cgroups_info.new_cgroup(parent_cgroup)

    cgroups = {
        "cpuset.cpus": get_cpus(0),
        "cpu.weight": 2,
        "memory.max": 256 * 2**20,
        "memory.min": 1 * 2**20,
    }
    uvm.jailer.cgroups = [f"{k}={v}" for k, v in cgroups.items()]
    uvm.spawn()
    uvm.basic_config()
    uvm.add_net_iface()
    uvm.start()
    strace_out = strace_output_path.read_text(encoding="utf-8").splitlines()
    write_lines = [
        line
        for line in strace_out
        if "write" in line and f"{uvm.id}/cgroup.procs" in line
    ]
    mkdir_lines = [
        line
        for line in strace_out
        if "mkdir" in line and f"{parent_cgroup}/{uvm.id}" in line
    ]
    assert len(write_lines) != len(cgroups), "writes equal to number of cgroups"
    assert len(write_lines) == 1
    assert len(mkdir_lines) != len(cgroups), "mkdir equal to number of cgroups"
    assert len(mkdir_lines) == 1
