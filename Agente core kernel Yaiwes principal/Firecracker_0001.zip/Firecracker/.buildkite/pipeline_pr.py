#!/usr/bin/env python3
# Copyright 2022 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""Generate Buildkite pipelines dynamically"""

from common import (
    BKPipeline,
    ci_artifacts_change_mode,
    get_changed_files,
    run_all_tests,
)

# Buildkite default job priority is 0. Setting this to 1 prioritizes PRs over
# scheduled jobs and other batch jobs.
DEFAULT_PRIORITY = 1
DEFAULTS_PERF = {
    "priority": DEFAULT_PRIORITY + 1,
    "agents": {"ag": 1},
}

changed_files = get_changed_files()
DOC_ONLY_CHANGE = False
if changed_files and all(f.suffix == ".md" for f in changed_files):
    DOC_ONLY_CHANGE = True
pipeline = BKPipeline(
    priority=DEFAULT_PRIORITY,
    timeout_in_minutes=45,
    with_build_step=not DOC_ONLY_CHANGE,
)

pipeline.add_step(
    {
        "command": "./tools/devtool -y checkstyle",
        "label": "style",
    },
    depends_on_build=False,
)

# run sanity build of devtool if Dockerfile is changed
if any(x.parent.name == "devctr" for x in changed_files):
    pipeline.build_group_per_arch(
        "dev-container-sanity-build",
        "./tools/devtool -y build_devctr && DEVCTR_IMAGE_TAG=latest ./tools/devtool test --no-build -- integration_tests/functional/test_api.py",
    )

# run sanity build of the CI guest artifacts (kernels/rootfs) if any of their
# source files changed. Rebuild only the affected half when possible, pulling
# the unchanged half from S3 so a guest can still boot.
artifacts_mode = ci_artifacts_change_mode(changed_files)
if artifacts_mode is not None:
    pipeline.build_group_per_arch(
        "ci-artifacts-sanity-build",
        f"./tools/devtool -y build_ci_artifacts {artifacts_mode} && "
        f"./tools/devtool -y stage_ci_artifacts {artifacts_mode} && "
        "./tools/devtool -y test --no-build -- integration_tests/functional/test_api.py",
        timeout_in_minutes=75,
    )

if any(
    x.parent.name == "tools" and ("release" in x.name or x.name == "devtool")
    for x in changed_files
):
    pipeline.build_group_per_arch(
        "release-sanity-build",
        "./tools/devtool -y make_release",
        depends_on_build=False,
    )

if not pipeline.args.no_kani and (
    not changed_files
    or any(x.suffix in [".rs", ".toml", ".lock"] for x in changed_files)
    or any(x.parent.name == "devctr" for x in changed_files)
    or any(x.name == "test_kani.py" for x in changed_files)
):
    kani_grp = pipeline.build_group(
        "kani",
        "./tools/devtool -y test --no-build -- ../tests/integration_tests/test_kani.py -n auto",
        # Kani step default
        # Kani runs fastest on m6a.metal (x86) and m9g.metal-48xl (aarch64)
        instances=["m6a.metal", "m9g.metal-48xl"],
        platforms=[("al2023", "linux_6.1")],
        timeout_in_minutes=300,
        **DEFAULTS_PERF,
        depends_on_build=False,
    )

if run_all_tests(changed_files):
    pipeline.build_group(
        "build",
        pipeline.devtool_test(pytest_opts="integration_tests/build/"),
        depends_on_build=False,
    )

    pipeline.build_group(
        "functional-and-security",
        pipeline.devtool_test(
            pytest_opts="-n 16 --dist worksteal integration_tests/{{functional,security}}",
        ),
    )

    pipeline.build_group(
        "performance",
        pipeline.devtool_test(
            devtool_opts="--performance -c 1-10 -m 0",
            pytest_opts="../tests/integration_tests/performance/",
        ),
        **DEFAULTS_PERF,
    )

print(pipeline.to_json())
