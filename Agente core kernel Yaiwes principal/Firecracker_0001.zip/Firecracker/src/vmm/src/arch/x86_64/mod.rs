// Copyright © 2020, Oracle and/or its affiliates.
//
// Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
//
// Portions Copyright 2017 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the THIRD-PARTY file.

/// Logic for handling x86_64 CPU models.
pub mod cpu_model;
mod gdt;
/// Contains logic for setting up Advanced Programmable Interrupt Controller (local version).
pub mod interrupts;
/// Architecture specific KVM-related code
pub mod kvm;
/// Layout for the x86_64 system.
pub mod layout;
mod mptable;
/// Logic for configuring x86_64 model specific registers (MSRs).
pub mod msr;
/// Logic for configuring x86_64 registers.
pub mod regs;
/// Architecture specific vCPU code
pub mod vcpu;
/// Architecture specific VM state code
pub mod vm;
/// Logic for configuring XSTATE features.
pub mod xstate;

#[allow(missing_docs)]
pub mod generated;

use std::cmp::max;
use std::fs::File;

use super::EntryPoint;
use crate::acpi::create_acpi_tables;
use crate::arch::{BootProtocol, SYSTEM_MEM_SIZE, SYSTEM_MEM_START, arch_memory_regions_with_gap};
use crate::cpu_config::templates::{CustomCpuTemplate, GuestConfigError};
use crate::cpu_config::x86_64::{apply_template_to_cpuid, apply_template_to_msrs, cpuid::Cpuid};
use crate::device_manager::DeviceManager;
use crate::initrd::InitrdConfig;
use crate::logger::debug;
use crate::utils::{u64_to_usize, usize_to_u64};
use crate::vmm_config::machine_config::MachineConfig;
use crate::vstate::memory::{
    Address, GuestAddress, GuestMemoryMmap, GuestMemoryRegion, GuestRegionType,
};
use crate::vstate::vcpu::KvmVcpuConfigureError;
use crate::vstate::vm::KvmVm;
use crate::{Vcpu, align_down, logger};
use kvm::Kvm;
use layout::{
    CMDLINE_START, MMIO32_MEM_SIZE, MMIO32_MEM_START, MMIO64_MEM_SIZE, MMIO64_MEM_START,
    PCI_MMCONFIG_SIZE, PCI_MMCONFIG_START,
};
use linux_loader::configurator::linux::LinuxBootConfigurator;
use linux_loader::configurator::pvh::PvhBootConfigurator;
use linux_loader::configurator::{BootConfigurator, BootParams};
use linux_loader::loader::bootparam::{XLF_KERNEL_64, boot_params, setup_header};
use linux_loader::loader::bzimage::BzImage as BzImageLoader;
use linux_loader::loader::elf::Elf as ElfLoader;
use linux_loader::loader::elf::Error as ElfError;
use linux_loader::loader::elf::start_info::{
    hvm_memmap_table_entry, hvm_modlist_entry, hvm_start_info,
};
use linux_loader::loader::{
    Cmdline, Error as KernelLoaderError, KernelLoader, PvhBootCapability, load_cmdline,
};
use vm_memory::GuestMemoryBackend;

// Value taken from https://elixir.bootlin.com/linux/v5.10.68/source/arch/x86/include/uapi/asm/e820.h#L31
// Usable normal RAM
const E820_RAM: u32 = 1;

// Reserved area that should be avoided during memory allocations
const E820_RESERVED: u32 = 2;
const MEMMAP_TYPE_RAM: u32 = 1;

/// Errors thrown while configuring x86_64 system.
#[derive(Debug, thiserror::Error, displaydoc::Display)]
pub enum ConfigurationError {
    /// Invalid e820 setup params.
    E820Configuration,
    /// Error writing MP table to memory: {0}
    MpTableSetup(#[from] mptable::MptableError),
    /// Error writing the zero page of guest memory.
    ZeroPageSetup,
    /// Error writing module entry to guest memory.
    ModlistSetup,
    /// Error writing memory map table to guest memory.
    MemmapTableSetup,
    /// Error writing hvm_start_info to guest memory.
    StartInfoSetup,
    /// Cannot copy kernel file fd
    KernelFile,
    /// Cannot load kernel due to invalid memory configuration or invalid kernel image: {0}
    KernelLoader(linux_loader::loader::Error),
    /// bzImage does not provide a 64-bit entry point
    BzImageMissing64BitEntry,
    /// Cannot load command line string: {0}
    LoadCommandline(linux_loader::loader::Error),
    /// Failed to create guest config: {0}
    CreateGuestConfig(#[from] GuestConfigError),
    /// Error configuring the vcpu for boot: {0}
    VcpuConfigure(#[from] KvmVcpuConfigureError),
    /// Error configuring ACPI: {0}
    Acpi(#[from] crate::acpi::AcpiError),
}

/// Returns a Vec of the valid memory addresses.
/// These should be used to configure the GuestMemoryMmap structure for the platform.
/// For x86_64 all addresses are valid from the start of the kernel except an 1GB
/// carve out at the end of 32bit address space and a second 256GB one at the 256GB limit.
pub fn arch_memory_regions(size: usize) -> Vec<(GuestAddress, usize)> {
    // If we get here with size == 0 something has seriously gone wrong. Firecracker should never
    // try to allocate guest memory of size 0
    assert!(size > 0, "Attempt to allocate guest memory of length 0");

    let dram_size = std::cmp::min(
        usize::MAX - u64_to_usize(MMIO32_MEM_SIZE) - u64_to_usize(MMIO64_MEM_SIZE),
        size,
    );

    if dram_size != size {
        logger::warn!(
            "Requested memory size {} exceeds architectural maximum (1022GiB). Size has been \
             truncated to {}",
            size,
            dram_size
        );
    }

    let mut regions = vec![];

    if let Some((start_past_32bit_gap, remaining_past_32bit_gap)) = arch_memory_regions_with_gap(
        &mut regions,
        0,
        dram_size,
        u64_to_usize(MMIO32_MEM_START),
        u64_to_usize(MMIO32_MEM_SIZE),
    ) && let Some((start_past_64bit_gap, remaining_past_64bit_gap)) =
        arch_memory_regions_with_gap(
            &mut regions,
            start_past_32bit_gap,
            remaining_past_32bit_gap,
            u64_to_usize(MMIO64_MEM_START),
            u64_to_usize(MMIO64_MEM_SIZE),
        )
    {
        regions.push((
            GuestAddress(start_past_64bit_gap as u64),
            remaining_past_64bit_gap,
        ));
    }

    regions
}

/// Returns the memory address where the kernel could be loaded.
pub fn get_kernel_start() -> u64 {
    layout::HIMEM_START
}

/// Returns the memory address where the initrd could be loaded.
pub fn initrd_load_addr(guest_mem: &GuestMemoryMmap, initrd_size: usize) -> Option<u64> {
    let first_region = guest_mem.find_region(GuestAddress::new(0))?;
    let lowmem_size = u64_to_usize(first_region.len());

    if lowmem_size < initrd_size {
        return None;
    }

    Some(align_down!(
        usize_to_u64(lowmem_size - initrd_size),
        usize_to_u64(super::GUEST_PAGE_SIZE)
    ))
}

/// Configures the vCPUs for booting Linux.
///
/// KVM determines support for CPUID-dependent MSRs from guest CPUID. Install
/// guest CPUID before retrieving MSRs for CPU templates; otherwise,
/// `KVM_GET_MSRS` returns zero for an MSR that guest CPUID does not support.
///
/// CPU configuration follows this order:
///
/// 1. Apply CPUID modifiers.
/// 2. Set each vCPU's normalized CPUID with `KVM_SET_CPUID2`.
/// 3. Retrieve CPUID-dependent MSRs from vCPU 0 with `KVM_GET_MSRS`.
/// 4. Apply MSR modifiers.
/// 5. Add Linux boot MSRs and update CPUID-derived MSR snapshot bookkeeping.
/// 6. Set each vCPU's MSRs with `KVM_SET_MSRS`.
///
/// The remaining Linux boot state is configured after CPU configuration.
fn configure_vcpus_for_boot(
    kvm: &Kvm,
    vcpus: &mut [Vcpu],
    machine_config: &MachineConfig,
    cpu_template: &CustomCpuTemplate,
    guest_mem: &GuestMemoryMmap,
    entry_point: EntryPoint,
) -> Result<(), ConfigurationError> {
    // Phase 1: construct the shared, templated guest CPUID.
    let cpuid = Cpuid::try_from(kvm.supported_cpuid.clone()).map_err(GuestConfigError::from)?;
    let cpuid = apply_template_to_cpuid(cpuid, cpu_template)?;

    // Phase 2: set each normalized CPUID before reading CPUID-dependent MSRs.
    let configured_cpuids = vcpus
        .iter()
        .map(|vcpu| {
            vcpu.kvm_vcpu
                .configure_cpuid(&cpuid, machine_config.vcpu_count, machine_config.smt)
        })
        .collect::<Result<Vec<_>, _>>()?;

    // Phase 3: construct the shared, templated MSRs from vCPU 0's post-CPUID state.
    let msrs = vcpus[0]
        .kvm_vcpu
        .get_msrs(cpu_template.msr_index_iter())
        .map_err(GuestConfigError::from)?;
    let msrs = apply_template_to_msrs(msrs, cpu_template)?;

    // Phase 4: set MSRs and the remaining Linux boot state on each vCPU.
    for (vcpu, configured_cpuid) in vcpus.iter_mut().zip(&configured_cpuids) {
        vcpu.kvm_vcpu
            .configure_msrs_for_boot(&msrs, configured_cpuid)?;
        vcpu.kvm_vcpu.configure_boot_state(guest_mem, entry_point)?;
    }

    Ok(())
}

/// Configures the system for booting Linux.
#[allow(clippy::too_many_arguments)]
pub fn configure_system_for_boot(
    kvm: &Kvm,
    vm: &KvmVm,
    device_manager: &mut DeviceManager,
    vcpus: &mut [Vcpu],
    machine_config: &MachineConfig,
    cpu_template: &CustomCpuTemplate,
    entry_point: EntryPoint,
    initrd: &Option<InitrdConfig>,
    boot_cmdline: Cmdline,
) -> Result<(), ConfigurationError> {
    configure_vcpus_for_boot(
        kvm,
        vcpus,
        machine_config,
        cpu_template,
        vm.guest_memory(),
        entry_point,
    )?;

    // Write the kernel command line to guest memory. This is x86_64 specific, since on
    // aarch64 the command line will be specified through the FDT.
    let cmdline_size = boot_cmdline
        .as_cstring()
        .map(|cmdline_cstring| cmdline_cstring.as_bytes_with_nul().len())
        .expect("Cannot create cstring from cmdline string");

    load_cmdline(
        vm.guest_memory(),
        GuestAddress(crate::arch::x86_64::layout::CMDLINE_START),
        &boot_cmdline,
    )
    .map_err(ConfigurationError::LoadCommandline)?;

    // Note that this puts the mptable at the last 1k of Linux's 640k base RAM
    mptable::setup_mptable(
        vm.guest_memory(),
        &mut vm.resource_allocator(),
        machine_config.vcpu_count,
    )
    .map_err(ConfigurationError::MpTableSetup)?;

    match entry_point.protocol {
        BootProtocol::PvhBoot => {
            configure_pvh(vm.guest_memory(), GuestAddress(CMDLINE_START), initrd)?;
        }
        BootProtocol::LinuxBoot => {
            configure_64bit_boot(
                vm.guest_memory(),
                GuestAddress(CMDLINE_START),
                cmdline_size,
                initrd,
                entry_point.setup_header,
            )?;
        }
    }

    // Create ACPI tables and write them in guest memory
    // For the time being we only support ACPI in x86_64
    create_acpi_tables(
        vm.guest_memory(),
        device_manager,
        &mut vm.resource_allocator(),
        vcpus,
    )?;
    Ok(())
}

fn configure_pvh(
    guest_mem: &GuestMemoryMmap,
    cmdline_addr: GuestAddress,
    initrd: &Option<InitrdConfig>,
) -> Result<(), ConfigurationError> {
    const XEN_HVM_START_MAGIC_VALUE: u32 = 0x336e_c578;
    let himem_start = GuestAddress(layout::HIMEM_START);

    // Vector to hold modules (currently either empty or holding initrd).
    let mut modules: Vec<hvm_modlist_entry> = Vec::new();
    if let Some(initrd_config) = initrd {
        // The initrd has been written to guest memory already, here we just need to
        // create the module structure that describes it.
        modules.push(hvm_modlist_entry {
            paddr: initrd_config.address.raw_value(),
            size: initrd_config.size as u64,
            ..Default::default()
        });
    }

    // Vector to hold the memory maps which needs to be written to guest memory
    // at MEMMAP_START after all of the mappings are recorded.
    let mut memmap: Vec<hvm_memmap_table_entry> = Vec::new();

    // Create the memory map entries.
    memmap.push(hvm_memmap_table_entry {
        addr: 0,
        size: SYSTEM_MEM_START,
        type_: MEMMAP_TYPE_RAM,
        ..Default::default()
    });
    memmap.push(hvm_memmap_table_entry {
        addr: SYSTEM_MEM_START,
        size: SYSTEM_MEM_SIZE,
        type_: E820_RESERVED,
        ..Default::default()
    });
    memmap.push(hvm_memmap_table_entry {
        addr: PCI_MMCONFIG_START,
        size: PCI_MMCONFIG_SIZE,
        type_: E820_RESERVED,
        ..Default::default()
    });

    for region in guest_mem
        .iter()
        .filter(|region| region.region_type == GuestRegionType::Dram)
    {
        // the first 1MB is reserved for the kernel
        let addr = max(himem_start, region.start_addr());
        memmap.push(hvm_memmap_table_entry {
            addr: addr.raw_value(),
            size: region.last_addr().unchecked_offset_from(addr) + 1,
            type_: MEMMAP_TYPE_RAM,
            ..Default::default()
        });
    }

    // Construct the hvm_start_info structure and serialize it into
    // boot_params.  This will be stored at PVH_INFO_START address, and %rbx
    // will be initialized to contain PVH_INFO_START prior to starting the
    // guest, as required by the PVH ABI.
    #[allow(clippy::cast_possible_truncation)] // the vec lengths are single digit integers
    let mut start_info = hvm_start_info {
        magic: XEN_HVM_START_MAGIC_VALUE,
        version: 1,
        cmdline_paddr: cmdline_addr.raw_value(),
        memmap_paddr: layout::MEMMAP_START,
        memmap_entries: memmap.len() as u32,
        nr_modules: modules.len() as u32,
        ..Default::default()
    };
    if !modules.is_empty() {
        start_info.modlist_paddr = layout::MODLIST_START;
    }
    let mut boot_params =
        BootParams::new::<hvm_start_info>(&start_info, GuestAddress(layout::PVH_INFO_START));

    // Copy the vector with the memmap table to the MEMMAP_START address
    // which is already saved in the memmap_paddr field of hvm_start_info struct.
    boot_params.set_sections::<hvm_memmap_table_entry>(&memmap, GuestAddress(layout::MEMMAP_START));

    // Copy the vector with the modules list to the MODLIST_START address.
    // Note that we only set the modlist_paddr address if there is a nonzero
    // number of modules, but serializing an empty list is harmless.
    boot_params.set_modules::<hvm_modlist_entry>(&modules, GuestAddress(layout::MODLIST_START));

    // Write the hvm_start_info struct to guest memory.
    PvhBootConfigurator::write_bootparams(&boot_params, guest_mem)
        .map_err(|_| ConfigurationError::StartInfoSetup)
}

fn configure_64bit_boot(
    guest_mem: &GuestMemoryMmap,
    cmdline_addr: GuestAddress,
    cmdline_size: usize,
    initrd: &Option<InitrdConfig>,
    setup_header: Option<setup_header>,
) -> Result<(), ConfigurationError> {
    const KERNEL_BOOT_FLAG_MAGIC: u16 = 0xaa55;
    const KERNEL_HDR_MAGIC: u32 = 0x5372_6448;
    const KERNEL_LOADER_OTHER: u8 = 0xff;
    const KERNEL_MIN_ALIGNMENT_BYTES: u32 = 0x0100_0000; // Must be non-zero.

    let himem_start = GuestAddress(layout::HIMEM_START);

    // A bzImage carries its own setup header; for ELF there is none, so
    // start from a zeroed header with the minimum required alignment.
    let mut hdr = setup_header.unwrap_or_else(|| setup_header {
        kernel_alignment: KERNEL_MIN_ALIGNMENT_BYTES,
        ..Default::default()
    });
    hdr.type_of_loader = KERNEL_LOADER_OTHER;
    hdr.boot_flag = KERNEL_BOOT_FLAG_MAGIC;
    hdr.header = KERNEL_HDR_MAGIC;
    hdr.cmd_line_ptr = u32::try_from(cmdline_addr.raw_value()).unwrap();
    hdr.cmdline_size = u32::try_from(cmdline_size).unwrap();
    if let Some(initrd_config) = initrd {
        hdr.ramdisk_image = u32::try_from(initrd_config.address.raw_value()).unwrap();
        hdr.ramdisk_size = u32::try_from(initrd_config.size).unwrap();
    }

    // Set the location of RSDP in Boot Parameters to help the guest kernel find it faster.
    let mut params = boot_params {
        hdr,
        acpi_rsdp_addr: layout::RSDP_ADDR,
        ..Default::default()
    };

    // We mark first [0x0, SYSTEM_MEM_START) region as usable RAM and the subsequent
    // [SYSTEM_MEM_START, (SYSTEM_MEM_START + SYSTEM_MEM_SIZE)) as reserved (note
    // SYSTEM_MEM_SIZE + SYSTEM_MEM_SIZE == HIMEM_START).
    add_e820_entry(&mut params, 0, layout::SYSTEM_MEM_START, E820_RAM)?;
    add_e820_entry(
        &mut params,
        layout::SYSTEM_MEM_START,
        layout::SYSTEM_MEM_SIZE,
        E820_RESERVED,
    )?;
    add_e820_entry(
        &mut params,
        PCI_MMCONFIG_START,
        PCI_MMCONFIG_SIZE,
        E820_RESERVED,
    )?;

    for region in guest_mem
        .iter()
        .filter(|region| region.region_type == GuestRegionType::Dram)
    {
        // the first 1MB is reserved for the kernel
        let addr = max(himem_start, region.start_addr());
        add_e820_entry(
            &mut params,
            addr.raw_value(),
            region.last_addr().unchecked_offset_from(addr) + 1,
            E820_RAM,
        )?;
    }

    LinuxBootConfigurator::write_bootparams(
        &BootParams::new(&params, GuestAddress(layout::ZERO_PAGE_START)),
        guest_mem,
    )
    .map_err(|_| ConfigurationError::ZeroPageSetup)
}

/// Add an e820 region to the e820 map.
/// Returns Ok(()) if successful, or an error if there is no space left in the map.
fn add_e820_entry(
    params: &mut boot_params,
    addr: u64,
    size: u64,
    mem_type: u32,
) -> Result<(), ConfigurationError> {
    if params.e820_entries as usize >= params.e820_table.len() {
        return Err(ConfigurationError::E820Configuration);
    }

    params.e820_table[params.e820_entries as usize].addr = addr;
    params.e820_table[params.e820_entries as usize].size = size;
    params.e820_table[params.e820_entries as usize].r#type = mem_type;
    params.e820_entries += 1;

    Ok(())
}

/// Offset of the 64-bit entry point from the start of a loaded bzImage,
/// per the Linux/x86 64-bit boot protocol.
const BZIMAGE_64BIT_ENTRY_OFFSET: u64 = 0x200;

/// Load a linux kernel into guest memory.
///
/// Supports uncompressed ELF (`vmlinux`) and `bzImage`; ELF is tried
/// first, falling back to the bzImage loader.
pub fn load_kernel(
    kernel: &File,
    guest_memory: &GuestMemoryMmap,
) -> Result<EntryPoint, ConfigurationError> {
    // Need to clone the File because reading from it
    // mutates it.
    let mut kernel_file = kernel
        .try_clone()
        .map_err(|_| ConfigurationError::KernelFile)?;

    let highmem_start = Some(GuestAddress(get_kernel_start()));

    // Try to load the image as an ELF (vmlinux); if it has no ELF magic,
    // we try to load it as a bzImage.
    match ElfLoader::load(guest_memory, None, &mut kernel_file, highmem_start) {
        Ok(elf_result) => {
            let mut entry_point_addr: GuestAddress = elf_result.kernel_load;
            let mut boot_prot: BootProtocol = BootProtocol::LinuxBoot;
            if let PvhBootCapability::PvhEntryPresent(pvh_entry_addr) = elf_result.pvh_boot_cap {
                // Use the PVH kernel entry point to boot the guest
                entry_point_addr = pvh_entry_addr;
                boot_prot = BootProtocol::PvhBoot;
            }

            debug!("Kernel loaded using {boot_prot}");

            Ok(EntryPoint {
                entry_addr: entry_point_addr,
                protocol: boot_prot,
                setup_header: None,
            })
        }
        // Not an ELF image: fall back to the bzImage loader.
        Err(KernelLoaderError::Elf(ElfError::InvalidElfMagicNumber)) => {
            let bzimage_result =
                BzImageLoader::load(guest_memory, None, &mut kernel_file, highmem_start)
                    .map_err(ConfigurationError::KernelLoader)?;

            // We jump to the 64-bit entry point, which only exists when the
            // image advertises it via XLF_KERNEL_64 (boot protocol >= 2.12).
            let hdr = bzimage_result
                .setup_header
                .expect("bzImage load always yields a setup header");
            if hdr.version < 0x020c || hdr.xloadflags & XLF_KERNEL_64 == 0 {
                return Err(ConfigurationError::BzImageMissing64BitEntry);
            }

            // Enter at the 64-bit entry point (BZIMAGE_64BIT_ENTRY_OFFSET
            // past the load address); the setup header seeds the zero page.
            let entry_addr = bzimage_result
                .kernel_load
                .checked_add(BZIMAGE_64BIT_ENTRY_OFFSET)
                .ok_or(ConfigurationError::KernelLoader(
                    KernelLoaderError::MemoryOverflow,
                ))?;

            debug!("Kernel loaded using {} (bzImage)", BootProtocol::LinuxBoot);

            Ok(EntryPoint {
                entry_addr,
                protocol: BootProtocol::LinuxBoot,
                setup_header: bzimage_result.setup_header,
            })
        }
        Err(err) => Err(ConfigurationError::KernelLoader(err)),
    }
}

#[cfg(kani)]
mod verification {

    use crate::arch::arch_memory_regions;
    use crate::arch::x86_64::layout::{
        FIRST_ADDR_PAST_32BITS, FIRST_ADDR_PAST_64BITS_MMIO, MMIO32_MEM_SIZE, MMIO32_MEM_START,
        MMIO64_MEM_SIZE, MMIO64_MEM_START,
    };
    use crate::utils::u64_to_usize;

    #[kani::proof]
    #[kani::unwind(4)]
    fn verify_arch_memory_regions() {
        let len: u64 = kani::any::<u64>();

        kani::assume(len > 0);

        let regions = arch_memory_regions(len as usize);

        // There are two MMIO gaps, so we can get either 1, 2 or 3 regions
        assert!(regions.len() <= 3);
        assert!(regions.len() >= 1);

        // The first address is always 0
        assert_eq!(regions[0].0.0, 0);

        // The total length of all regions is what we requested
        let actual_size = regions.iter().map(|&(_, len)| len).sum::<usize>();
        assert!(actual_size <= len as usize);
        if actual_size < u64_to_usize(len) {
            assert_eq!(
                actual_size,
                usize::MAX - u64_to_usize(MMIO32_MEM_SIZE) - u64_to_usize(MMIO64_MEM_SIZE)
            );
        }

        // No region overlaps the MMIO gap
        assert!(
            regions
                .iter()
                .all(|&(start, len)| (start.0 >= FIRST_ADDR_PAST_32BITS
                    || start.0 + len as u64 <= MMIO32_MEM_START)
                    && (start.0 >= FIRST_ADDR_PAST_64BITS_MMIO
                        || start.0 + len as u64 <= MMIO64_MEM_START))
        );

        // All regions have non-zero length
        assert!(regions.iter().all(|&(_, len)| len > 0));

        // If there's at least two regions, they perfectly snuggle up to one of the two MMIO gaps
        if regions.len() >= 2 {
            kani::cover!();

            assert_eq!(regions[0].0.0 + regions[0].1 as u64, MMIO32_MEM_START);
            assert_eq!(regions[1].0.0, FIRST_ADDR_PAST_32BITS);
        }

        // If there are three regions, the last two perfectly snuggle up to the 64bit
        // MMIO gap
        if regions.len() == 3 {
            kani::cover!();

            assert_eq!(regions[1].0.0 + regions[1].1 as u64, MMIO64_MEM_START);
            assert_eq!(regions[2].0.0, FIRST_ADDR_PAST_64BITS_MMIO);
        }
    }
}

#[cfg(test)]
mod tests {
    use linux_loader::loader::bootparam::boot_e820_entry;

    use super::*;
    use crate::arch::x86_64::layout::FIRST_ADDR_PAST_32BITS;
    use crate::test_utils::{arch_mem, single_region_mem};
    use crate::utils::mib_to_bytes;
    use crate::vstate::resources::ResourceAllocator;

    #[test]
    fn regions_lt_4gb() {
        let regions = arch_memory_regions(1usize << 29);
        assert_eq!(1, regions.len());
        assert_eq!(GuestAddress(0), regions[0].0);
        assert_eq!(1usize << 29, regions[0].1);
    }

    #[test]
    fn regions_gt_4gb() {
        const MEMORY_SIZE: usize = (1 << 32) + 0x8000;

        let regions = arch_memory_regions(MEMORY_SIZE);
        assert_eq!(2, regions.len());
        assert_eq!(GuestAddress(0), regions[0].0);
        assert_eq!(GuestAddress(1u64 << 32), regions[1].0);

        assert_eq!(
            regions[1],
            (
                GuestAddress(FIRST_ADDR_PAST_32BITS),
                MEMORY_SIZE - regions[0].1
            )
        )
    }

    #[test]
    fn test_system_configuration() {
        let no_vcpus = 4;
        let gm = single_region_mem(0x10000);
        let mut resource_allocator = ResourceAllocator::new();
        let err = mptable::setup_mptable(&gm, &mut resource_allocator, 1);
        assert!(matches!(
            err.unwrap_err(),
            mptable::MptableError::NotEnoughMemory
        ));

        // Now assigning some memory that falls before the 32bit memory hole.
        let mem_size = mib_to_bytes(128);
        let gm = arch_mem(mem_size);
        let mut resource_allocator = ResourceAllocator::new();
        mptable::setup_mptable(&gm, &mut resource_allocator, no_vcpus).unwrap();
        configure_64bit_boot(&gm, GuestAddress(0), 0, &None, None).unwrap();
        configure_pvh(&gm, GuestAddress(0), &None).unwrap();

        // Now assigning some memory that is equal to the start of the 32bit memory hole.
        let mem_size = mib_to_bytes(3328);
        let gm = arch_mem(mem_size);
        let mut resource_allocator = ResourceAllocator::new();
        mptable::setup_mptable(&gm, &mut resource_allocator, no_vcpus).unwrap();
        configure_64bit_boot(&gm, GuestAddress(0), 0, &None, None).unwrap();
        configure_pvh(&gm, GuestAddress(0), &None).unwrap();

        // Now assigning some memory that falls after the 32bit memory hole.
        let mem_size = mib_to_bytes(3330);
        let gm = arch_mem(mem_size);
        let mut resource_allocator = ResourceAllocator::new();
        mptable::setup_mptable(&gm, &mut resource_allocator, no_vcpus).unwrap();
        configure_64bit_boot(&gm, GuestAddress(0), 0, &None, None).unwrap();
        configure_pvh(&gm, GuestAddress(0), &None).unwrap();
    }

    /// Builds a minimal bzImage that satisfies `linux_loader`'s bzImage
    /// loader checks, with the given `xloadflags`. Not a runnable kernel, only
    /// enough to exercise loader selection and zero-page seeding in
    /// `load_kernel`.
    fn make_fake_bzimage(xloadflags: u16) -> Vec<u8> {
        const SETUP_SECTS: u8 = 4;
        // Setup area (`(setup_sects + 1) * 512`) followed by a small protected-mode payload.
        let setup_len = (SETUP_SECTS as usize + 1) * 512;
        let mut image = vec![0u8; setup_len + 0x1000];

        // setup_sects @ 0x1f1
        image[0x1f1] = SETUP_SECTS;
        // boot_flag (0xaa55) @ 0x1fe
        image[0x1fe] = 0x55;
        image[0x1ff] = 0xaa;
        // "HdrS" header magic @ 0x202
        image[0x202..0x206].copy_from_slice(&0x5372_6448u32.to_le_bytes());
        // version @ 0x206 (>= 0x020c so xloadflags is defined)
        image[0x206..0x208].copy_from_slice(&0x020fu16.to_le_bytes());
        // loadflags @ 0x211 with LOADED_HIGH (bit 0) set
        image[0x211] = 0x01;
        // code32_start @ 0x214: default load address, must be >= HIMEM_START
        let code32_start = u32::try_from(get_kernel_start()).unwrap();
        image[0x214..0x218].copy_from_slice(&code32_start.to_le_bytes());
        // xloadflags @ 0x236
        image[0x236..0x238].copy_from_slice(&xloadflags.to_le_bytes());

        image
    }

    #[test]
    fn test_load_kernel_bzimage() {
        use std::io::{Seek, SeekFrom, Write};

        use vmm_sys_util::tempfile::TempFile;

        let gm = arch_mem(mib_to_bytes(128));

        let image = make_fake_bzimage(XLF_KERNEL_64);
        let tempfile = TempFile::new().unwrap();
        let mut file = tempfile.into_file();
        file.write_all(&image).unwrap();
        file.seek(SeekFrom::Start(0)).unwrap();

        let entry_point = load_kernel(&file, &gm).unwrap();

        assert_eq!(entry_point.protocol, BootProtocol::LinuxBoot);
        assert_eq!(
            entry_point.entry_addr,
            GuestAddress(get_kernel_start() + BZIMAGE_64BIT_ENTRY_OFFSET)
        );
        let hdr = entry_point
            .setup_header
            .expect("bzImage must yield a setup header");
        // Copy out of the packed struct to avoid unaligned references.
        let (header, setup_sects) = (hdr.header, hdr.setup_sects);
        assert_eq!(header, 0x5372_6448);
        assert_eq!(setup_sects, 4);
    }

    #[test]
    fn test_load_kernel_bzimage_without_64bit_entry() {
        use std::io::{Seek, SeekFrom, Write};

        use vmm_sys_util::tempfile::TempFile;

        let gm = arch_mem(mib_to_bytes(128));

        // A valid bzImage that does not advertise a 64-bit entry point.
        let image = make_fake_bzimage(0);
        let tempfile = TempFile::new().unwrap();
        let mut file = tempfile.into_file();
        file.write_all(&image).unwrap();
        file.seek(SeekFrom::Start(0)).unwrap();

        assert!(matches!(
            load_kernel(&file, &gm),
            Err(ConfigurationError::BzImageMissing64BitEntry)
        ));
    }

    #[test]
    fn test_load_kernel_elf_has_no_setup_header() {
        use std::fs::File;

        use crate::test_utils::mock_resources::kernel_image_path;

        let gm = arch_mem(mib_to_bytes(128));

        let file = File::open(kernel_image_path(None)).unwrap();
        let entry_point = load_kernel(&file, &gm).unwrap();
        assert!(entry_point.setup_header.is_none());
    }

    #[test]
    fn test_load_kernel_invalid_image_is_rejected() {
        use std::io::{Seek, SeekFrom, Write};

        use vmm_sys_util::tempfile::TempFile;

        let gm = arch_mem(mib_to_bytes(128));

        // Neither valid ELF nor valid bzImage.
        let tempfile = TempFile::new().unwrap();
        let mut file = tempfile.into_file();
        file.write_all(&[0u8; 8192]).unwrap();
        file.seek(SeekFrom::Start(0)).unwrap();

        load_kernel(&file, &gm).unwrap_err();
    }

    #[test]
    fn test_add_e820_entry() {
        let e820_map = [(boot_e820_entry {
            addr: 0x1,
            size: 4,
            r#type: 1,
        }); 128];

        let expected_params = boot_params {
            e820_table: e820_map,
            e820_entries: 1,
            ..Default::default()
        };

        let mut params: boot_params = Default::default();
        add_e820_entry(
            &mut params,
            e820_map[0].addr,
            e820_map[0].size,
            e820_map[0].r#type,
        )
        .unwrap();
        assert_eq!(
            format!("{:?}", params.e820_table[0]),
            format!("{:?}", expected_params.e820_table[0])
        );
        assert_eq!(params.e820_entries, expected_params.e820_entries);

        // Exercise the scenario where the field storing the length of the e820 entry table is
        // is bigger than the allocated memory.
        params.e820_entries = u8::try_from(params.e820_table.len()).unwrap() + 1;
        assert!(
            add_e820_entry(
                &mut params,
                e820_map[0].addr,
                e820_map[0].size,
                e820_map[0].r#type
            )
            .is_err()
        );
    }
}
