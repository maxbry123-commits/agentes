// Copyright 2025 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// Copyright 2018 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE-BSD-3-Clause file.
//
// SPDX-License-Identifier: Apache-2.0 AND BSD-3-Clause

use std::fmt::Debug;
use std::sync::{Arc, Barrier, Mutex};

use byteorder::{ByteOrder, LittleEndian};

use crate::pci::configuration::PciConfiguration;
use crate::pci::{PciBridgeSubclass, PciClassCode, PciDevice};
use crate::utils::u64_to_usize;
use crate::vstate::bus::BusDevice;

/// Errors for device manager.
#[derive(Debug, thiserror::Error, displaydoc::Display)]
pub enum PciRootError {
    /// Could not find an available device slot on the PCI bus.
    NoPciDeviceSlotAvailable,
    /// PCI device ID {0} is already in use.
    DuplicateDeviceId(u8),
}

const VENDOR_ID_INTEL: u16 = 0x8086;
const DEVICE_ID_INTEL_VIRT_PCIE_HOST: u16 = 0x0d57;
const NUM_DEVICE_IDS: usize = 32;

#[derive(Debug)]
/// Emulates the PCI Root bridge device.
pub struct PciRoot {
    /// Configuration space.
    config: PciConfiguration,
}

impl PciRoot {
    /// Create an empty PCI root bridge.
    pub fn new(config: Option<PciConfiguration>) -> Self {
        if let Some(config) = config {
            PciRoot { config }
        } else {
            PciRoot {
                config: PciConfiguration::new_type0(
                    VENDOR_ID_INTEL,
                    DEVICE_ID_INTEL_VIRT_PCIE_HOST,
                    0,
                    PciClassCode::Bridge,
                    PciBridgeSubclass::HostBridge as u8,
                    0,
                    0,
                ),
            }
        }
    }
}

impl BusDevice for PciRoot {}

impl PciDevice for PciRoot {
    fn write_config_register(
        &mut self,
        reg_idx: u16,
        offset: u8,
        data: &[u8],
    ) -> Option<Arc<Barrier>> {
        self.config.write_config_register(reg_idx, offset, data);
        None
    }

    fn read_config_register(&mut self, reg_idx: u16) -> u32 {
        self.config.read_reg(reg_idx)
    }
}

/// A PCI bus definition
#[derive(Default)]
pub struct PciBus {
    /// Devices attached to this bus. Slot 0 is reserved for host bridge.
    devices: [Option<Arc<Mutex<dyn PciDevice>>>; NUM_DEVICE_IDS],
}

impl Debug for PciBus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let occupied: [bool; NUM_DEVICE_IDS] = std::array::from_fn(|i| self.devices[i].is_some());
        f.debug_struct("Root Firecracker PCI Bus")
            .field("device_ids", &occupied)
            .finish()
    }
}

impl PciBus {
    /// Create a new PCI bus
    pub fn new(pci_root: PciRoot) -> Self {
        let mut bus: Self = Default::default();
        bus.devices[0] = Some(Arc::new(Mutex::new(pci_root)));
        bus
    }

    /// Get a reference to the device at index
    pub fn get_device(&self, device_id: u8) -> Option<&Mutex<dyn PciDevice>> {
        self.devices[device_id as usize].as_deref()
    }

    /// Insert a device in the bus at the specified slot (`device_id`).
    pub fn add_device(
        &mut self,
        device_id: u8,
        device: Arc<Mutex<dyn PciDevice>>,
    ) -> Result<(), PciRootError> {
        let slot = &mut self.devices[device_id as usize];
        if slot.is_some() {
            return Err(PciRootError::DuplicateDeviceId(device_id));
        }
        *slot = Some(device);
        Ok(())
    }

    /// Remove a device from the bus at the specified slot (`device_id`).
    pub fn remove_device(&mut self, device_id: u8) {
        self.devices[device_id as usize] = None;
    }

    /// Get the next unused device ID.
    ///
    /// Note: this is non-reserving — repeated calls without an intervening `add_device` will
    /// return the same ID.
    #[allow(clippy::cast_possible_truncation)]
    pub fn next_device_id(&self) -> Result<u8, PciRootError> {
        if let Some(position) = self.devices.iter().position(Option::is_none) {
            Ok(position as u8)
        } else {
            Err(PciRootError::NoPciDeviceSlotAvailable)
        }
    }
}

#[cfg(target_arch = "x86_64")]
/// IO port used for configuring PCI over the legacy bus
pub const PCI_CONFIG_IO_PORT: u64 = 0xcf8;
#[cfg(target_arch = "x86_64")]
/// Size of IO ports we are using to configure PCI over the legacy bus. We have two ports, 0xcf8
/// and 0xcfc 32bits long.
pub const PCI_CONFIG_IO_PORT_SIZE: u64 = 0x8;

/// Wrapper that allows handling PCI configuration over the legacy Bus
#[derive(Debug)]
pub struct PciConfigIo {
    /// Config space register.
    config_address: u32,
    pci_bus: Arc<Mutex<PciBus>>,
}

impl PciConfigIo {
    /// New Port IO configuration handler
    pub fn new(pci_bus: Arc<Mutex<PciBus>>) -> Self {
        PciConfigIo {
            config_address: 0,
            pci_bus,
        }
    }

    /// Handle a configuration space read over Port IO
    pub fn config_space_read(&self) -> u32 {
        let enabled = (self.config_address & 0x8000_0000) != 0;
        if !enabled {
            return 0xffff_ffff;
        }

        let (bus, device, function, register) =
            parse_io_config_address(self.config_address & !0x8000_0000);

        // Only support one bus.
        if bus != 0 {
            return 0xffff_ffff;
        }

        // Don't support multi-function devices.
        if function > 0 {
            return 0xffff_ffff;
        }

        // NOTE: Potential contention among vCPU threads on this lock. This should not
        // be a problem currently, since we mainly access this when we are setting up devices.
        // We might want to do some profiling to ensure this does not become a bottleneck.
        let pci_bus = self.pci_bus.as_ref().lock().unwrap();
        if let Some(d) = pci_bus.get_device(device) {
            d.lock().unwrap().read_config_register(register)
        } else {
            0xffff_ffff
        }
    }

    /// Handle a configuration space write over Port IO
    // offset is validated to be < 4 at the top of this function.
    #[allow(clippy::cast_possible_truncation)]
    pub fn config_space_write(&mut self, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        if u64_to_usize(offset) + data.len() > 4 {
            return None;
        }

        let enabled = (self.config_address & 0x8000_0000) != 0;
        if !enabled {
            return None;
        }

        let (bus, device, function, register) =
            parse_io_config_address(self.config_address & !0x8000_0000);

        // Only support one bus.
        if bus != 0 {
            return None;
        }

        // Don't support multi-function devices.
        if function > 0 {
            return None;
        }

        // NOTE: Potential contention among vCPU threads on this lock. This should not
        // be a problem currently, since we mainly access this when we are setting up devices.
        // We might want to do some profiling to ensure this does not become a bottleneck.
        let pci_bus = self.pci_bus.as_ref().lock().unwrap();
        if let Some(d) = pci_bus.get_device(device) {
            let mut device = d.lock().unwrap();

            // offset is validated to be < 4 at the top of this function.
            #[allow(clippy::cast_possible_truncation)]
            let offset = offset as u8;

            // Update the register value
            device.write_config_register(register, offset, data)
        } else {
            None
        }
    }

    fn set_config_address(&mut self, offset: u64, data: &[u8]) {
        if u64_to_usize(offset) + data.len() > 4 {
            return;
        }
        let (mask, value): (u32, u32) = match data.len() {
            1 => (
                0x0000_00ff << (offset * 8),
                u32::from(data[0]) << (offset * 8),
            ),
            2 => (
                0x0000_ffff << (offset * 8),
                ((u32::from(data[1]) << 8) | u32::from(data[0])) << (offset * 8),
            ),
            4 => (0xffff_ffff, LittleEndian::read_u32(data)),
            _ => return,
        };
        self.config_address = (self.config_address & !mask) | value;
    }
}

impl BusDevice for PciConfigIo {
    fn read(&mut self, _base: u64, offset: u64, data: &mut [u8]) {
        // Only allow reads to the register boundary.
        let start = u64_to_usize(offset) % 4;
        let end = start + data.len();
        if end > 4 {
            for d in data.iter_mut() {
                *d = 0xff;
            }
            return;
        }

        // `offset` is relative to 0xcf8
        let value = match offset {
            0..=3 => self.config_address,
            4..=7 => self.config_space_read(),
            _ => 0xffff_ffff,
        };

        for i in start..end {
            data[i - start] = ((value >> (i * 8)) & 0xff) as u8;
        }
    }

    fn write(&mut self, _base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        // `offset` is relative to 0xcf8
        match offset {
            o @ 0..=3 => {
                self.set_config_address(o, data);
                None
            }
            o @ 4..=7 => self.config_space_write(o - 4, data),
            _ => None,
        }
    }
}

#[derive(Debug)]
/// Emulates PCI memory-mapped configuration access mechanism.
pub struct PciConfigMmio {
    pci_bus: Arc<Mutex<PciBus>>,
}

impl PciConfigMmio {
    /// New MMIO configuration handler object
    pub fn new(pci_bus: Arc<Mutex<PciBus>>) -> Self {
        PciConfigMmio { pci_bus }
    }

    fn config_space_read(&self, config_address: u32) -> u32 {
        let (bus, device, function, register) = parse_mmio_config_address(config_address);

        // Only support one bus.
        if bus != 0 {
            return 0xffff_ffff;
        }

        // Don't support multi-function devices.
        if function > 0 {
            return 0xffff_ffff;
        }

        let pci_bus = self.pci_bus.lock().unwrap();
        if let Some(d) = pci_bus.get_device(device) {
            d.lock().unwrap().read_config_register(register)
        } else {
            0xffff_ffff
        }
    }

    fn config_space_write(&mut self, config_address: u32, offset: u64, data: &[u8]) {
        if u64_to_usize(offset) + data.len() > 4 {
            return;
        }

        let (bus, device, function, register) = parse_mmio_config_address(config_address);

        // Only support one bus.
        if bus != 0 {
            return;
        }

        // Don't support multi-function devices.
        if function > 0 {
            return;
        }

        let pci_bus = self.pci_bus.lock().unwrap();
        if let Some(d) = pci_bus.get_device(device) {
            let mut device = d.lock().unwrap();

            // offset is validated to be < 4 at the top of this function.
            #[allow(clippy::cast_possible_truncation)]
            let offset = offset as u8;

            // Update the register value
            device.write_config_register(register, offset, data);
        }
    }
}

impl BusDevice for PciConfigMmio {
    fn read(&mut self, _base: u64, offset: u64, data: &mut [u8]) {
        // Only allow reads to the register boundary.
        let start = u64_to_usize(offset) % 4;
        let end = start + data.len();
        if end > 4 || offset > u64::from(u32::MAX) {
            for d in data {
                *d = 0xff;
            }
            return;
        }

        // offset is checked to fit in u32 before narrowing.
        #[allow(clippy::cast_possible_truncation)]
        let offset = offset as u32;

        let value = self.config_space_read(offset);
        for i in start..end {
            data[i - start] = ((value >> (i * 8)) & 0xff) as u8;
        }
    }

    fn write(&mut self, _base: u64, offset: u64, data: &[u8]) -> Option<Arc<Barrier>> {
        if offset > u64::from(u32::MAX) {
            return None;
        }

        // offset is checked to fit in u32 before narrowing.
        #[allow(clippy::cast_possible_truncation)]
        let offset_u32 = offset as u32;

        self.config_space_write(offset_u32, offset % 4, data);

        None
    }
}

fn shift_and_mask(value: u32, offset: usize, mask: u32) -> u32 {
    (value >> offset) & mask
}

// Parse the MMIO address offset to a (bus, device, function, register) tuple.
// See section 7.2.2 PCI Express Enhanced Configuration Access Mechanism (ECAM)
// from the Pci Express Base Specification Revision 5.0 Version 1.0.
//
// The masks used below guarantee the values fit in the narrower return types.
#[allow(clippy::cast_possible_truncation)]
fn parse_mmio_config_address(config_address: u32) -> (u8, u8, u8, u16) {
    const BUS_NUMBER_OFFSET: usize = 20;
    const BUS_NUMBER_MASK: u32 = 0x00ff;
    const DEVICE_NUMBER_OFFSET: usize = 15;
    const DEVICE_NUMBER_MASK: u32 = 0x1f;
    const FUNCTION_NUMBER_OFFSET: usize = 12;
    const FUNCTION_NUMBER_MASK: u32 = 0x07;
    const REGISTER_NUMBER_OFFSET: usize = 2;
    const REGISTER_NUMBER_MASK: u32 = 0x3ff;

    (
        shift_and_mask(config_address, BUS_NUMBER_OFFSET, BUS_NUMBER_MASK) as u8,
        shift_and_mask(config_address, DEVICE_NUMBER_OFFSET, DEVICE_NUMBER_MASK) as u8,
        shift_and_mask(config_address, FUNCTION_NUMBER_OFFSET, FUNCTION_NUMBER_MASK) as u8,
        shift_and_mask(config_address, REGISTER_NUMBER_OFFSET, REGISTER_NUMBER_MASK) as u16,
    )
}

// Parse the CONFIG_ADDRESS register to a (bus, device, function, register) tuple.
// The masks used below guarantee the values fit in the narrower return types.
#[allow(clippy::cast_possible_truncation)]
fn parse_io_config_address(config_address: u32) -> (u8, u8, u8, u16) {
    const BUS_NUMBER_OFFSET: usize = 16;
    const BUS_NUMBER_MASK: u32 = 0x00ff;
    const DEVICE_NUMBER_OFFSET: usize = 11;
    const DEVICE_NUMBER_MASK: u32 = 0x1f;
    const FUNCTION_NUMBER_OFFSET: usize = 8;
    const FUNCTION_NUMBER_MASK: u32 = 0x07;
    const REGISTER_NUMBER_OFFSET: usize = 2;
    const REGISTER_NUMBER_MASK: u32 = 0x3f;

    (
        shift_and_mask(config_address, BUS_NUMBER_OFFSET, BUS_NUMBER_MASK) as u8,
        shift_and_mask(config_address, DEVICE_NUMBER_OFFSET, DEVICE_NUMBER_MASK) as u8,
        shift_and_mask(config_address, FUNCTION_NUMBER_OFFSET, FUNCTION_NUMBER_MASK) as u8,
        shift_and_mask(config_address, REGISTER_NUMBER_OFFSET, REGISTER_NUMBER_MASK) as u16,
    )
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, Mutex};

    use super::{PciBus, PciConfigIo, PciConfigMmio, PciRoot};
    use crate::pci::bus::{DEVICE_ID_INTEL_VIRT_PCIE_HOST, VENDOR_ID_INTEL};
    use crate::pci::configuration::PciConfiguration;
    use crate::pci::{PciClassCode, PciDevice, PciMassStorageSubclass};
    use crate::vstate::bus::BusDevice;

    struct PciDevMock(PciConfiguration);

    impl PciDevMock {
        fn new() -> Self {
            let config = PciConfiguration::new_type0(
                0x42,
                0x0,
                0x0,
                PciClassCode::MassStorageController,
                PciMassStorageSubclass::SerialScsiController as u8,
                0x13,
                0x12,
            );
            PciDevMock(config)
        }
    }

    impl PciDevice for PciDevMock {
        fn write_config_register(
            &mut self,
            reg_idx: u16,
            offset: u8,
            data: &[u8],
        ) -> Option<Arc<std::sync::Barrier>> {
            self.0.write_config_register(reg_idx, offset, data);
            None
        }

        fn read_config_register(&mut self, reg_idx: u16) -> u32 {
            self.0.read_reg(reg_idx)
        }
    }

    #[test]
    fn test_writing_io_config_address() {
        let root = PciRoot::new(None);
        let mut bus = PciConfigIo::new(Arc::new(Mutex::new(PciBus::new(root))));

        assert_eq!(bus.config_address, 0);
        // Writing more than 32 bits will should fail
        bus.write(0, 0, &[0x42; 8]);
        assert_eq!(bus.config_address, 0);
        // Write all the address at once
        bus.write(0, 0, &[0x13, 0x12, 0x11, 0x10]);
        assert_eq!(bus.config_address, 0x10111213);
        // Not writing 32bits at offset 0 should have no effect
        bus.write(0, 1, &[0x0; 4]);
        assert_eq!(bus.config_address, 0x10111213);

        // Write two bytes at a time
        bus.write(0, 0, &[0x42, 0x42]);
        assert_eq!(bus.config_address, 0x10114242);
        bus.write(0, 1, &[0x43, 0x43]);
        assert_eq!(bus.config_address, 0x10434342);
        bus.write(0, 2, &[0x44, 0x44]);
        assert_eq!(bus.config_address, 0x44444342);
        // Writing two bytes at offset 3 should overflow, so it shouldn't have any effect
        bus.write(0, 3, &[0x45, 0x45]);
        assert_eq!(bus.config_address, 0x44444342);

        // Write one byte at a time
        bus.write(0, 0, &[0x0]);
        assert_eq!(bus.config_address, 0x44444300);
        bus.write(0, 1, &[0x0]);
        assert_eq!(bus.config_address, 0x44440000);
        bus.write(0, 2, &[0x0]);
        assert_eq!(bus.config_address, 0x44000000);
        bus.write(0, 3, &[0x0]);
        assert_eq!(bus.config_address, 0x00000000);
        // Writing past 4 bytes should have no effect
        bus.write(0, 4, &[0x13]);
        assert_eq!(bus.config_address, 0x0);
    }

    #[test]
    fn test_reading_io_config_address() {
        let root = PciRoot::new(None);
        let mut bus = PciConfigIo::new(Arc::new(Mutex::new(PciBus::new(root))));

        let mut buffer = [0u8; 4];

        bus.config_address = 0x13121110;

        // First 4 bytes are the config address
        // Next 4 bytes are the values read from the configuration space.
        //
        // Reading past offset 7 should not return nothing (all 1s)
        bus.read(0, 8, &mut buffer);
        assert_eq!(buffer, [0xff; 4]);

        // offset + buffer.len() needs to be smaller or equal than 4
        bus.read(0, 1, &mut buffer);
        assert_eq!(buffer, [0xff; 4]);
        bus.read(0, 2, &mut buffer[..3]);
        assert_eq!(buffer, [0xff; 4]);
        bus.read(0, 3, &mut buffer[..2]);
        assert_eq!(buffer, [0xff; 4]);

        // reading one byte at a time
        bus.read(0, 0, &mut buffer[0..1]);
        assert_eq!(buffer, [0x10, 0xff, 0xff, 0xff]);
        bus.read(0, 1, &mut buffer[1..2]);
        assert_eq!(buffer, [0x10, 0x11, 0xff, 0xff]);
        bus.read(0, 2, &mut buffer[2..3]);
        assert_eq!(buffer, [0x10, 0x11, 0x12, 0xff]);
        bus.read(0, 3, &mut buffer[3..4]);
        assert_eq!(buffer, [0x10, 0x11, 0x12, 0x13]);

        // reading two bytes at a time
        bus.config_address = 0x42434445;
        bus.read(0, 0, &mut buffer[..2]);
        assert_eq!(buffer, [0x45, 0x44, 0x12, 0x13]);
        bus.read(0, 1, &mut buffer[..2]);
        assert_eq!(buffer, [0x44, 0x43, 0x12, 0x13]);
        bus.read(0, 2, &mut buffer[..2]);
        assert_eq!(buffer, [0x43, 0x42, 0x12, 0x13]);

        // reading all of it at once
        bus.read(0, 0, &mut buffer);
        assert_eq!(buffer, [0x45, 0x44, 0x43, 0x42]);
    }

    fn initialize_bus() -> (PciConfigMmio, PciConfigIo) {
        let root = PciRoot::new(None);
        let mut bus = PciBus::new(root);
        bus.add_device(1, Arc::new(Mutex::new(PciDevMock::new())))
            .unwrap();

        let bus = Arc::new(Mutex::new(bus));
        (PciConfigMmio::new(bus.clone()), PciConfigIo::new(bus))
    }

    #[test]
    fn test_invalid_register_boundary_reads() {
        let (mut mmio_config, mut io_config) = initialize_bus();

        // Read crossing register boundaries
        let mut buffer = [0u8; 4];
        mmio_config.read(0, 1, &mut buffer);
        assert_eq!(0xffff_ffff, u32::from_le_bytes(buffer));

        let mut buffer = [0u8; 4];
        io_config.read(0, 1, &mut buffer);
        assert_eq!(0xffff_ffff, u32::from_le_bytes(buffer));

        // As well in the config space
        let mut buffer = [0u8; 4];
        io_config.read(0, 5, &mut buffer);
        assert_eq!(0xffff_ffff, u32::from_le_bytes(buffer));
    }

    // MMIO config addresses are of the form
    //
    // | Base address upper bits | Bus Number | Device Number | Function Number | Register number | Byte offset |
    // |         31-28           |    27-20   |     19-15     |      14-12      |      11-2       |     0-1     |
    //
    // Meaning that the offset is built using:
    //
    // `bus << 20 | device << 15 | function << 12 | register << 2 | byte`
    fn mmio_offset(bus: u8, device: u8, function: u8, register: u16, byte: u8) -> u32 {
        assert!(device < 32);
        assert!(function < 8);
        assert!(register < 1024);
        assert!(byte < 4);

        (bus as u32) << 20
            | (device as u32) << 15
            | (function as u32) << 12
            | (register as u32) << 2
            | (byte as u32)
    }

    fn read_mmio_config(
        config: &mut PciConfigMmio,
        bus: u8,
        device: u8,
        function: u8,
        register: u16,
        byte: u8,
        data: &mut [u8],
    ) {
        config.read(
            0,
            mmio_offset(bus, device, function, register, byte) as u64,
            data,
        );
    }

    fn write_mmio_config(
        config: &mut PciConfigMmio,
        bus: u8,
        device: u8,
        function: u8,
        register: u16,
        byte: u8,
        data: &[u8],
    ) {
        config.write(
            0,
            mmio_offset(bus, device, function, register, byte) as u64,
            data,
        );
    }

    // Similarly, when using the IO mechanism the config addresses have the following format
    //
    // | Enabled | zeros | Bus Number | Device Number | Function Number | Register number | zeros |
    // |    31   | 30-24 |   23-16    |     15-11     |      10-8       |       7-2       |  1-0  |
    //
    //
    // Meaning that the address is built using:
    //
    // 0x8000_0000 | bus << 16 | device << 11 | function << 8 | register << 2;
    //
    // Only 32-bit aligned accesses are allowed here.
    fn pio_offset(enabled: bool, bus: u8, device: u8, function: u8, register: u8) -> u32 {
        assert!(device < 32);
        assert!(function < 8);
        assert!(register < 64);

        let offset = if enabled { 0x8000_0000 } else { 0u32 };

        offset
            | (bus as u32) << 16
            | (device as u32) << 11
            | (function as u32) << 8
            | (register as u32) << 2
    }

    fn set_io_address(
        config: &mut PciConfigIo,
        enabled: bool,
        bus: u8,
        device: u8,
        function: u8,
        register: u8,
    ) {
        let address = u32::to_le_bytes(pio_offset(enabled, bus, device, function, register));
        config.write(0, 0, &address);
    }

    fn read_io_config(
        config: &mut PciConfigIo,
        enabled: bool,
        bus: u8,
        device: u8,
        function: u8,
        register: u8,
        data: &mut [u8],
    ) {
        set_io_address(config, enabled, bus, device, function, register);
        config.read(0, 4, data);
    }

    fn write_io_config(
        config: &mut PciConfigIo,
        enabled: bool,
        bus: u8,
        device: u8,
        function: u8,
        register: u8,
        data: &[u8],
    ) {
        set_io_address(config, enabled, bus, device, function, register);
        config.write(0, 4, data);
    }

    #[test]
    fn test_mmio_invalid_bus_number() {
        let (mut mmio_config, _) = initialize_bus();
        let mut buffer = [0u8; 4];

        // Asking for Bus 1 should return all 1s
        read_mmio_config(&mut mmio_config, 1, 0, 0, 0, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));
        // Writing the same
        buffer[0] = 0x42;
        write_mmio_config(&mut mmio_config, 1, 0, 0, 15, 0, &buffer);
        read_mmio_config(&mut mmio_config, 1, 0, 0, 15, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));
        read_mmio_config(&mut mmio_config, 0, 0, 0, 15, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0x0));

        // Asking for Bus 0 should work
        read_mmio_config(&mut mmio_config, 0, 0, 0, 0, 0, &mut buffer);
        assert_eq!(&buffer[..2], &u16::to_le_bytes(VENDOR_ID_INTEL));
        assert_eq!(
            &buffer[2..],
            &u16::to_le_bytes(DEVICE_ID_INTEL_VIRT_PCIE_HOST)
        );
    }

    #[test]
    fn test_io_invalid_bus_number() {
        let (_, mut pio_config) = initialize_bus();
        let mut buffer = [0u8; 4];

        // Asking for Bus 1 should return all 1s
        read_io_config(&mut pio_config, true, 1, 0, 0, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));

        // Asking for Bus 0 should work
        read_io_config(&mut pio_config, true, 0, 0, 0, 0, &mut buffer);
        assert_eq!(&buffer[..2], &u16::to_le_bytes(VENDOR_ID_INTEL));
        assert_eq!(
            &buffer[2..],
            &u16::to_le_bytes(DEVICE_ID_INTEL_VIRT_PCIE_HOST)
        );
    }

    #[test]
    fn test_mmio_invalid_function() {
        let (mut mmio_config, _) = initialize_bus();
        let mut buffer = [0u8; 4];

        // Asking for Bus 1 should return all 1s
        read_mmio_config(&mut mmio_config, 0, 0, 1, 0, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));
        // Writing the same
        buffer[0] = 0x42;
        write_mmio_config(&mut mmio_config, 0, 0, 1, 15, 0, &buffer);
        read_mmio_config(&mut mmio_config, 0, 0, 1, 15, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));
        read_mmio_config(&mut mmio_config, 0, 0, 0, 15, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0x0));

        // Asking for Bus 0 should work
        read_mmio_config(&mut mmio_config, 0, 0, 0, 0, 0, &mut buffer);
        assert_eq!(&buffer[..2], &u16::to_le_bytes(VENDOR_ID_INTEL));
        assert_eq!(
            &buffer[2..],
            &u16::to_le_bytes(DEVICE_ID_INTEL_VIRT_PCIE_HOST)
        );
    }

    #[test]
    fn test_io_invalid_function() {
        let (_, mut pio_config) = initialize_bus();
        let mut buffer = [0u8; 4];

        // Asking for Bus 1 should return all 1s
        read_io_config(&mut pio_config, true, 0, 0, 1, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));

        // Asking for Bus 0 should work
        read_io_config(&mut pio_config, true, 0, 0, 0, 0, &mut buffer);
        assert_eq!(&buffer[..2], &u16::to_le_bytes(VENDOR_ID_INTEL));
        assert_eq!(
            &buffer[2..],
            &u16::to_le_bytes(DEVICE_ID_INTEL_VIRT_PCIE_HOST)
        );
    }

    #[test]
    fn test_io_disabled_reads() {
        let (_, mut pio_config) = initialize_bus();
        let mut buffer = [0u8; 4];

        // Trying to read without enabling should return all 1s
        read_io_config(&mut pio_config, false, 0, 0, 0, 0, &mut buffer);
        assert_eq!(buffer, u32::to_le_bytes(0xffff_ffff));

        // Asking for Bus 0 should work
        read_io_config(&mut pio_config, true, 0, 0, 0, 0, &mut buffer);
        assert_eq!(&buffer[..2], &u16::to_le_bytes(VENDOR_ID_INTEL));
        assert_eq!(
            &buffer[2..],
            &u16::to_le_bytes(DEVICE_ID_INTEL_VIRT_PCIE_HOST)
        );
    }

    #[test]
    fn test_io_disabled_writes() {
        let (_, mut pio_config) = initialize_bus();

        // Try to write the IRQ line used for the root port.
        let mut buffer = [0u8; 4];

        // First read the current value (use `enabled` bit)
        read_io_config(&mut pio_config, true, 0, 0, 0, 15, &mut buffer);
        let irq_line = buffer[0];

        // Write without setting the `enabled` bit.
        buffer[0] = 0x42;
        write_io_config(&mut pio_config, false, 0, 0, 0, 15, &buffer);

        // IRQ line shouldn't have changed
        read_io_config(&mut pio_config, true, 0, 0, 0, 15, &mut buffer);
        assert_eq!(buffer[0], irq_line);

        // Write with `enabled` bit set.
        buffer[0] = 0x42;
        write_io_config(&mut pio_config, true, 0, 0, 0, 15, &buffer);

        // IRQ line should change
        read_io_config(&mut pio_config, true, 0, 0, 0, 15, &mut buffer);
        assert_eq!(buffer[0], 0x42);
    }

    #[test]
    fn test_mmio_writes() {
        let (mut mmio_config, _) = initialize_bus();
        let mut buffer = [0u8; 4];

        read_mmio_config(&mut mmio_config, 0, 0, 0, 15, 0, &mut buffer);
        assert_eq!(buffer[0], 0x0);
        write_mmio_config(&mut mmio_config, 0, 0, 0, 15, 0, &[0x42]);
        read_mmio_config(&mut mmio_config, 0, 0, 0, 15, 0, &mut buffer);
        assert_eq!(buffer[0], 0x42);
    }
}
