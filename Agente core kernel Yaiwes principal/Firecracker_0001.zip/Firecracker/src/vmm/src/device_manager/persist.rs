// Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

//! Provides functionality for saving/restoring the MMIO device manager and its devices.

use std::fmt::{self, Debug};
use std::sync::{Arc, Mutex};

use serde::{Deserialize, Serialize};

use super::acpi::ACPIDeviceManager;
use super::mmio::*;
use crate::EventManager;
use crate::device_manager::DevicePersistError;
use crate::device_manager::acpi::ACPIDeviceError;
use crate::devices::acpi::vmclock::{VmClock, VmClockState};
use crate::devices::acpi::vmgenid::{VMGenIDState, VmGenId};
#[cfg(target_arch = "aarch64")]
use crate::devices::legacy::RTCDevice;
use crate::devices::virtio::balloon::Balloon;
use crate::devices::virtio::balloon::persist::{BalloonConstructorArgs, BalloonState};
use crate::devices::virtio::block::device::Block;
use crate::devices::virtio::block::persist::{BlockConstructorArgs, BlockState};
use crate::devices::virtio::device::{VirtioDevice, VirtioDeviceType};
use crate::devices::virtio::mem::VirtioMem;
use crate::devices::virtio::mem::persist::{VirtioMemConstructorArgs, VirtioMemState};
use crate::devices::virtio::net::Net;
use crate::devices::virtio::net::persist::{NetConstructorArgs, NetState};
use crate::devices::virtio::persist::{MmioTransportConstructorArgs, MmioTransportState};
use crate::devices::virtio::pmem::device::Pmem;
use crate::devices::virtio::pmem::persist::{PmemConstructorArgs, PmemState};
use crate::devices::virtio::rng::Entropy;
use crate::devices::virtio::rng::persist::{EntropyConstructorArgs, EntropyState};
use crate::devices::virtio::transport::mmio::{IrqTrigger, MmioTransport};
use crate::devices::virtio::vsock::persist::{
    VsockConstructorArgs, VsockState, VsockUdsConstructorArgs,
};
use crate::devices::virtio::vsock::{Vsock, VsockUnixBackend};
use crate::mmds::data_store::MmdsVersion;
use crate::resources::VmResources;
use crate::snapshot::Persist;
use crate::vmm_config::memory_hotplug::MemoryHotplugConfig;
use crate::vstate::memory::GuestMemoryMmap;
use crate::vstate::vm::KvmVm;

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct SerialState {
    pub baud_divisor_low: u8,
    pub baud_divisor_high: u8,
    pub interrupt_enable: u8,
    pub interrupt_identification: u8,
    pub line_control: u8,
    pub line_status: u8,
    pub modem_control: u8,
    pub modem_status: u8,
    pub scratch: u8,
    pub in_buffer: Vec<u8>,
}

impl From<vm_superio::serial::SerialState> for SerialState {
    fn from(s: vm_superio::serial::SerialState) -> Self {
        Self {
            baud_divisor_low: s.baud_divisor_low,
            baud_divisor_high: s.baud_divisor_high,
            interrupt_enable: s.interrupt_enable,
            interrupt_identification: s.interrupt_identification,
            line_control: s.line_control,
            line_status: s.line_status,
            modem_control: s.modem_control,
            modem_status: s.modem_status,
            scratch: s.scratch,
            in_buffer: s.in_buffer,
        }
    }
}

impl From<&SerialState> for vm_superio::serial::SerialState {
    fn from(s: &SerialState) -> Self {
        Self {
            baud_divisor_low: s.baud_divisor_low,
            baud_divisor_high: s.baud_divisor_high,
            interrupt_enable: s.interrupt_enable,
            interrupt_identification: s.interrupt_identification,
            line_control: s.line_control,
            line_status: s.line_status,
            modem_control: s.modem_control,
            modem_status: s.modem_status,
            scratch: s.scratch,
            in_buffer: s.in_buffer.clone(),
        }
    }
}

/// Holds the state of a MMIO VirtIO device
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VirtioDeviceState<T> {
    /// Device identifier.
    pub device_id: String,
    /// Device state.
    pub device_state: T,
    /// Mmio transport state.
    pub transport_state: MmioTransportState,
    /// VmmResources.
    pub device_info: MMIODeviceInfo,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MmdsState {
    pub version: MmdsVersion,
    pub imds_compat: bool,
}

/// Holds the states of the virtio devices connected over the MMIO transport.
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct DeviceStates {
    /// Block device states.
    pub block_devices: Vec<VirtioDeviceState<BlockState>>,
    /// Net device states.
    pub net_devices: Vec<VirtioDeviceState<NetState>>,
    /// Vsock device state.
    pub vsock_device: Option<VirtioDeviceState<VsockState>>,
    /// Balloon device state.
    pub balloon_device: Option<VirtioDeviceState<BalloonState>>,
    /// Mmds version.
    pub mmds: Option<MmdsState>,
    /// Entropy device state.
    pub entropy_device: Option<VirtioDeviceState<EntropyState>>,
    /// Pmem device states.
    pub pmem_devices: Vec<VirtioDeviceState<PmemState>>,
    /// Memory device state.
    pub memory_device: Option<VirtioDeviceState<VirtioMemState>>,
}

pub struct MMIODevManagerConstructorArgs<'a> {
    pub mem: &'a GuestMemoryMmap,
    pub vm: &'a Arc<KvmVm>,
    pub event_manager: &'a mut EventManager,
    pub vm_resources: &'a mut VmResources,
    pub instance_id: &'a str,
}

pub struct MMIOPlatformDevicesConstructorArgs<'a> {
    pub vm: &'a Arc<KvmVm>,
    pub event_manager: &'a mut EventManager,
    pub vm_resources: &'a mut VmResources,
    pub serial_state: Option<&'a SerialState>,
}

impl fmt::Debug for MMIOPlatformDevicesConstructorArgs<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MMIOPlatformDevicesConstructorArgs")
            .field("vm", &self.vm)
            .field("event_manager", &"?")
            .field("vm_resources", &self.vm_resources)
            .finish()
    }
}

impl fmt::Debug for MMIODevManagerConstructorArgs<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MMIODevManagerConstructorArgs")
            .field("mem", &self.mem)
            .field("vm", &self.vm)
            .field("event_manager", &"?")
            .field("for_each_restored_device", &"?")
            .field("vm_resources", &self.vm_resources)
            .field("instance_id", &self.instance_id)
            .finish()
    }
}

#[derive(Default, Debug, Clone, Serialize, Deserialize)]
pub struct ACPIDeviceManagerState {
    vmgenid: VMGenIDState,
    vmclock: VmClockState,
}

/// Holds the states of the non-virtio (platform) devices connected over the MMIO transport.
#[derive(Default, Debug, Clone, Serialize, Deserialize)]
pub struct MMIOPlatformDevicesState {
    #[cfg(target_arch = "aarch64")]
    /// State of the serial device in MMIO space.
    pub serial: Option<MMIODeviceInfo>,
    #[cfg(target_arch = "aarch64")]
    /// State of the RTC device in MMIO space.
    pub rtc: Option<MMIODeviceInfo>,
}

impl<'a> Persist<'a> for ACPIDeviceManager {
    type State = ACPIDeviceManagerState;
    type ConstructorArgs = &'a KvmVm;
    type Error = ACPIDeviceError;

    fn save(&self) -> Self::State {
        ACPIDeviceManagerState {
            vmgenid: self.vmgenid().save(),
            vmclock: self.vmclock().save(),
        }
    }

    fn restore(vm: Self::ConstructorArgs, state: &Self::State) -> Result<Self, Self::Error> {
        let mut acpi_devices = ACPIDeviceManager::new(
            VmGenId::restore((), &state.vmgenid)?,
            VmClock::restore((), &state.vmclock)?,
        );

        acpi_devices.replay_gsi_allocations(vm)?;

        acpi_devices.activate_vmgenid(vm)?;
        acpi_devices.do_post_restore_vmgenid()?;

        acpi_devices.activate_vmclock(vm)?;
        acpi_devices.do_post_restore_vmclock(vm.guest_memory())?;

        Ok(acpi_devices)
    }
}

impl<'a> Persist<'a> for MMIOPlatformDevices {
    type State = MMIOPlatformDevicesState;
    type ConstructorArgs = MMIOPlatformDevicesConstructorArgs<'a>;
    type Error = DevicePersistError;

    fn save(&self) -> Self::State {
        MMIOPlatformDevicesState {
            #[cfg(target_arch = "aarch64")]
            serial: self.serial.as_ref().map(|device| device.resources),
            #[cfg(target_arch = "aarch64")]
            rtc: self.rtc.as_ref().map(|device| device.resources),
        }
    }

    #[allow(unused_variables)]
    #[cfg_attr(not(target_arch = "aarch64"), allow(unused_mut))]
    fn restore(
        constructor_args: Self::ConstructorArgs,
        state: &Self::State,
    ) -> Result<Self, Self::Error> {
        let mut platform_devices = MMIOPlatformDevices::new();

        #[cfg(target_arch = "aarch64")]
        {
            if let Some(device_info) = state.serial {
                let serial_state = constructor_args.serial_state.map(Into::into);
                let serial = crate::DeviceManager::setup_serial_device(
                    constructor_args.event_manager,
                    constructor_args.vm_resources.serial_out_path.as_ref(),
                    serial_state.as_ref(),
                    constructor_args.vm_resources.serial_rate_limiter(),
                )?;

                platform_devices.register_mmio_serial(
                    constructor_args.vm,
                    serial,
                    Some(device_info),
                )?;
            }

            if let Some(device_info) = state.rtc {
                let rtc = Arc::new(Mutex::new(RTCDevice::new()));
                platform_devices.register_mmio_rtc(constructor_args.vm, rtc, Some(device_info))?;
            }
        }

        Ok(platform_devices)
    }
}

impl<'a> Persist<'a> for MMIOVirtioDevices {
    type State = DeviceStates;
    type ConstructorArgs = MMIODevManagerConstructorArgs<'a>;
    type Error = DevicePersistError;

    fn save(&self) -> Self::State {
        let mut states = DeviceStates::default();

        let _: Result<(), ()> = self.for_each_virtio_mmio_device(|_, devid, device| {
            let mmio_transport_locked = device.inner.lock().expect("Poisoned lock");
            let mut locked_device = mmio_transport_locked.locked_device();
            // We need to call `prepare_save()` on the device before saving the transport
            // so that, if we modify the transport state while preparing the device, e.g. sending
            // an interrupt to the guest, this is correctly captured in the saved transport state.
            locked_device.prepare_save();
            let transport_state = mmio_transport_locked.save();
            let device_info = device.resources;
            let device_id = devid.clone();

            match locked_device.device_type() {
                VirtioDeviceType::Balloon => {
                    let device_state = locked_device
                        .as_any()
                        .downcast_ref::<Balloon>()
                        .unwrap()
                        .save();
                    states.balloon_device = Some(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
                // Both virtio-block and vhost-user-block share same device type.
                VirtioDeviceType::Block => {
                    let block = locked_device.as_mut_any().downcast_mut::<Block>().unwrap();
                    assert!(
                        !block.is_vhost_user(),
                        "vhost-user-block does not support snapshotting yet"
                    );
                    let device_state = block.save();
                    states.block_devices.push(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
                VirtioDeviceType::Net => {
                    let net = locked_device.as_mut_any().downcast_mut::<Net>().unwrap();
                    if let (Some(mmds_ns), None) = (net.mmds_ns.as_ref(), states.mmds.as_ref()) {
                        let mmds_guard = mmds_ns.mmds.lock().expect("Poisoned lock");
                        states.mmds = Some(MmdsState {
                            version: mmds_guard.version(),
                            imds_compat: mmds_guard.imds_compat(),
                        });
                    }

                    let device_state = net.save();
                    states.net_devices.push(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
                VirtioDeviceType::Vsock => {
                    let vsock = locked_device
                        .as_mut_any()
                        // Currently, VsockUnixBackend is the only implementation of VsockBackend.
                        .downcast_mut::<Vsock<VsockUnixBackend>>()
                        .unwrap();

                    // Save state after potential notification to the guest. This
                    // way we save changes to the queue the notification can cause.
                    let device_state = VsockState {
                        backend: vsock.backend().save(),
                        frontend: vsock.save(),
                    };

                    states.vsock_device = Some(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
                VirtioDeviceType::Rng => {
                    let entropy = locked_device
                        .as_mut_any()
                        .downcast_mut::<Entropy>()
                        .unwrap();
                    let device_state = entropy.save();

                    states.entropy_device = Some(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
                VirtioDeviceType::Pmem => {
                    let pmem = locked_device.as_mut_any().downcast_mut::<Pmem>().unwrap();
                    let device_state = pmem.save();
                    states.pmem_devices.push(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    })
                }
                VirtioDeviceType::Mem => {
                    let mem = locked_device
                        .as_mut_any()
                        .downcast_mut::<VirtioMem>()
                        .unwrap();
                    let device_state = mem.save();

                    states.memory_device = Some(VirtioDeviceState {
                        device_id,
                        device_state,
                        transport_state,
                        device_info,
                    });
                }
            };

            Ok(())
        });
        states
    }

    fn restore(
        constructor_args: Self::ConstructorArgs,
        state: &Self::State,
    ) -> Result<Self, Self::Error> {
        let mut dev_manager = MMIOVirtioDevices::new();
        let mem = constructor_args.mem;
        let vm = constructor_args.vm;

        let mut restore_helper = |device: Arc<Mutex<dyn VirtioDevice>>,
                                  activated: bool,
                                  is_vhost_user: bool,
                                  id: &String,
                                  state: &MmioTransportState,
                                  device_info: &MMIODeviceInfo,
                                  event_manager: &mut EventManager|
         -> Result<(), Self::Error> {
            let interrupt = Arc::new(IrqTrigger::new());
            let restore_args = MmioTransportConstructorArgs {
                mem: mem.clone(),
                interrupt: interrupt.clone(),
                device: device.clone(),
                is_vhost_user,
            };
            let mmio_transport = Arc::new(Mutex::new(
                MmioTransport::restore(restore_args, state)
                    .map_err(|()| DevicePersistError::MmioTransport)?,
            ));

            vm.resource_allocator()
                .gsi_legacy_allocator
                .allocate_id_at(device_info.gsi.ok_or(MmioError::InvalidIrqConfig)?)?;

            dev_manager.register_mmio_virtio(
                vm,
                id.clone(),
                MMIODevice {
                    resources: *device_info,
                    inner: mmio_transport,
                    sub_id: None,
                },
                event_manager,
            )?;

            if activated {
                device
                    .lock()
                    .expect("Poisoned lock")
                    .activate(mem.clone(), interrupt)?;
            }

            Ok(())
        };

        if let Some(balloon_state) = &state.balloon_device {
            let device = Arc::new(Mutex::new(Balloon::restore(
                BalloonConstructorArgs { mem: mem.clone() },
                &balloon_state.device_state,
            )?));

            constructor_args
                .vm_resources
                .balloon
                .set_device(device.clone());

            restore_helper(
                device,
                balloon_state.device_state.virtio_state.activated,
                false,
                &balloon_state.device_id,
                &balloon_state.transport_state,
                &balloon_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        for block_state in &state.block_devices {
            let device = Arc::new(Mutex::new(Block::restore(
                BlockConstructorArgs { mem: mem.clone() },
                &block_state.device_state,
            )?));

            constructor_args
                .vm_resources
                .block
                .add_virtio_device(device.clone());

            restore_helper(
                device,
                block_state.device_state.is_activated(),
                false,
                &block_state.device_id,
                &block_state.transport_state,
                &block_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        // Initialize MMDS if MMDS state is included.
        if let Some(mmds) = &state.mmds {
            constructor_args.vm_resources.set_mmds_basic_config(
                mmds.version,
                mmds.imds_compat,
                constructor_args.instance_id,
            )?;
        }

        for net_state in &state.net_devices {
            let device = Arc::new(Mutex::new(Net::restore(
                NetConstructorArgs {
                    mem: mem.clone(),
                    mmds: constructor_args
                        .vm_resources
                        .mmds
                        .as_ref()
                        // Clone the Arc reference.
                        .cloned(),
                },
                &net_state.device_state,
            )?));

            constructor_args
                .vm_resources
                .net_builder
                .add_device(device.clone());

            restore_helper(
                device,
                net_state.device_state.virtio_state.activated,
                false,
                &net_state.device_id,
                &net_state.transport_state,
                &net_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        if let Some(vsock_state) = &state.vsock_device {
            let ctor_args = VsockUdsConstructorArgs {
                cid: vsock_state.device_state.frontend.cid,
            };
            let backend = VsockUnixBackend::restore(ctor_args, &vsock_state.device_state.backend)?;
            let device = Arc::new(Mutex::new(Vsock::restore(
                VsockConstructorArgs {
                    mem: mem.clone(),
                    backend,
                },
                &vsock_state.device_state.frontend,
            )?));

            constructor_args
                .vm_resources
                .vsock
                .set_device(device.clone());

            restore_helper(
                device,
                vsock_state.device_state.frontend.virtio_state.activated,
                false,
                &vsock_state.device_id,
                &vsock_state.transport_state,
                &vsock_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        if let Some(entropy_state) = &state.entropy_device {
            let ctor_args = EntropyConstructorArgs { mem: mem.clone() };

            let device = Arc::new(Mutex::new(Entropy::restore(
                ctor_args,
                &entropy_state.device_state,
            )?));

            constructor_args
                .vm_resources
                .entropy
                .set_device(device.clone());

            restore_helper(
                device,
                entropy_state.device_state.virtio_state.activated,
                false,
                &entropy_state.device_id,
                &entropy_state.transport_state,
                &entropy_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        for pmem_state in &state.pmem_devices {
            let device = Arc::new(Mutex::new(Pmem::restore(
                PmemConstructorArgs {
                    mem,
                    vm: vm.clone(),
                },
                &pmem_state.device_state,
            )?));

            constructor_args
                .vm_resources
                .pmem
                .configs
                .push(pmem_state.device_state.config.clone());

            restore_helper(
                device,
                pmem_state.device_state.virtio_state.activated,
                false,
                &pmem_state.device_id,
                &pmem_state.transport_state,
                &pmem_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        if let Some(memory_state) = &state.memory_device {
            let ctor_args = VirtioMemConstructorArgs::new(Arc::clone(vm));
            let device = VirtioMem::restore(ctor_args, &memory_state.device_state)?;

            constructor_args.vm_resources.memory_hotplug = Some(MemoryHotplugConfig {
                total_size_mib: device.total_size_mib(),
                block_size_mib: device.block_size_mib(),
                slot_size_mib: device.slot_size_mib(),
            });

            let arcd_device = Arc::new(Mutex::new(device));

            restore_helper(
                arcd_device,
                memory_state.device_state.virtio_state.activated,
                false,
                &memory_state.device_id,
                &memory_state.transport_state,
                &memory_state.device_info,
                constructor_args.event_manager,
            )?;
        }

        Ok(dev_manager)
    }
}

#[cfg(test)]
mod tests {
    use vmm_sys_util::tempfile::TempFile;

    use super::*;
    use crate::builder::tests::*;
    use crate::device_manager;
    use crate::devices::virtio::block::CacheType;
    use crate::resources::VmmConfig;
    use crate::vmm_config::balloon::BalloonDeviceConfig;
    use crate::vmm_config::entropy::EntropyDeviceConfig;
    use crate::vmm_config::memory_hotplug::MemoryHotplugConfig;
    use crate::vmm_config::net::NetworkInterfaceConfig;
    use crate::vmm_config::pmem::PmemConfig;
    use crate::vmm_config::vsock::VsockDeviceConfig;

    impl<T> PartialEq for VirtioDeviceState<T> {
        fn eq(&self, other: &VirtioDeviceState<T>) -> bool {
            // Actual device state equality is checked by the device's tests.
            self.transport_state == other.transport_state && self.device_info == other.device_info
        }
    }

    impl PartialEq for DeviceStates {
        fn eq(&self, other: &DeviceStates) -> bool {
            self.balloon_device == other.balloon_device
                && self.block_devices == other.block_devices
                && self.net_devices == other.net_devices
                && self.vsock_device == other.vsock_device
                && self.entropy_device == other.entropy_device
                && self.memory_device == other.memory_device
        }
    }

    impl<T> PartialEq for MMIODevice<T> {
        fn eq(&self, other: &Self) -> bool {
            self.resources == other.resources
        }
    }

    impl PartialEq for MMIOVirtioDevices {
        fn eq(&self, other: &MMIOVirtioDevices) -> bool {
            // We only care about the device hashmap.
            if self.virtio_devices.len() != other.virtio_devices.len() {
                return false;
            }
            for (key, val) in &self.virtio_devices {
                match other.virtio_devices.get(key) {
                    Some(other_val) if val == other_val => continue,
                    _ => return false,
                }
            }

            true
        }
    }

    #[test]
    fn test_device_manager_persistence() {
        // These need to survive so the restored blocks find them.
        let _block_files;
        let _pmem_files;
        let mut tmp_sock_file = TempFile::new().unwrap();
        tmp_sock_file.remove().unwrap();

        let serialized_data;
        // Set up a vmm with one of each device, and get the serialized DeviceStates.
        {
            let mut event_manager = EventManager::new().expect("Unable to create EventManager");
            let mut vmm = default_vmm();
            let mut cmdline = default_kernel_cmdline();

            // Add a balloon device.
            let balloon_cfg = BalloonDeviceConfig {
                amount_mib: 123,
                deflate_on_oom: false,
                stats_polling_interval_s: 1,
                free_page_hinting: false,
                free_page_reporting: false,
            };
            insert_balloon_device(&mut vmm, &mut cmdline, &mut event_manager, balloon_cfg);
            // Add a block device.
            let drive_id = String::from("root");
            let block_configs = vec![CustomBlockConfig::new(
                drive_id,
                true,
                None,
                true,
                CacheType::Unsafe,
            )];
            _block_files =
                insert_block_devices(&mut vmm, &mut cmdline, &mut event_manager, block_configs);
            // Add a net device.
            let network_interface = NetworkInterfaceConfig {
                iface_id: String::from("netif"),
                host_dev_name: String::from("hostname"),
                guest_mac: None,
                mtu: None,
                rx_rate_limiter: None,
                tx_rate_limiter: None,
            };
            insert_net_device_with_mmds(
                &mut vmm,
                &mut cmdline,
                &mut event_manager,
                network_interface,
                MmdsVersion::V2,
            );
            // Add a vsock device.
            let vsock_dev_id = "vsock";
            let vsock_config = VsockDeviceConfig {
                vsock_id: Some(vsock_dev_id.to_string()),
                guest_cid: 3,
                uds_path: tmp_sock_file.as_path().to_str().unwrap().to_string(),
            };
            insert_vsock_device(&mut vmm, &mut cmdline, &mut event_manager, vsock_config);
            // Add an entropy device.
            let entropy_config = EntropyDeviceConfig::default();
            insert_entropy_device(&mut vmm, &mut cmdline, &mut event_manager, entropy_config);
            // Add a pmem device.
            let pmem_id = String::from("pmem");
            let pmem_configs = vec![PmemConfig {
                id: pmem_id,
                path_on_host: "".into(),
                root_device: true,
                read_only: true,
                ..Default::default()
            }];
            _pmem_files =
                insert_pmem_devices(&mut vmm, &mut cmdline, &mut event_manager, pmem_configs);

            let memory_hotplug_config = MemoryHotplugConfig {
                total_size_mib: 1024,
                block_size_mib: 2,
                slot_size_mib: 128,
            };
            insert_virtio_mem_device(
                &mut vmm,
                &mut cmdline,
                &mut event_manager,
                memory_hotplug_config,
            );

            let device_state = vmm.device_manager.save();
            serialized_data = bitcode::serialize(&device_state).unwrap();
        }

        tmp_sock_file.remove().unwrap();

        let mut event_manager = EventManager::new().expect("Unable to create EventManager");
        let vmm = default_vmm();
        let device_manager_state: device_manager::DevicesState =
            bitcode::deserialize(&serialized_data).unwrap();
        let device_manager::VirtioDevicesState::Mmio(mmio_state) =
            &device_manager_state.virtio_state
        else {
            panic!("expected MMIO virtio device state");
        };
        let vm_resources = &mut VmResources::default();
        let kvm_vm = vmm.vm.as_kvm().unwrap().clone();
        let restore_args = MMIODevManagerConstructorArgs {
            mem: kvm_vm.guest_memory(),
            vm: &kvm_vm,
            event_manager: &mut event_manager,
            vm_resources,
            instance_id: "microvm-id",
        };
        let _restored_dev_manager = MMIOVirtioDevices::restore(restore_args, mmio_state).unwrap();

        let expected_vm_resources = format!(
            r#"{{
  "balloon": {{
    "amount_mib": 123,
    "deflate_on_oom": false,
    "stats_polling_interval_s": 1,
    "free_page_hinting": false,
    "free_page_reporting": false
  }},
  "drives": [
    {{
      "drive_id": "root",
      "partuuid": null,
      "is_root_device": true,
      "cache_type": "Unsafe",
      "is_read_only": true,
      "path_on_host": "{}",
      "rate_limiter": null,
      "io_engine": "Sync",
      "blk_size": 512,
      "topology": {{
        "physical_block_exp": 0,
        "alignment_offset": 0,
        "min_io_size": 0,
        "opt_io_size": 128
      }},
      "socket": null
    }}
  ],
  "boot-source": {{
    "kernel_image_path": "",
    "initrd_path": null,
    "boot_args": null
  }},
  "cpu-config": null,
  "logger": null,
  "machine-config": {{
    "vcpu_count": 1,
    "mem_size_mib": 128,
    "smt": false,
    "track_dirty_pages": false,
    "huge_pages": "None"
  }},
  "metrics": null,
  "mmds-config": {{
    "version": "V2",
    "network_interfaces": [
      "netif"
    ],
    "ipv4_address": "169.254.169.254",
    "imds_compat": false
  }},
  "network-interfaces": [
    {{
      "iface_id": "netif",
      "host_dev_name": "hostname",
      "guest_mac": null,
      "mtu": null,
      "rx_rate_limiter": null,
      "tx_rate_limiter": null
    }}
  ],
  "vsock": {{
    "guest_cid": 3,
    "uds_path": "{}"
  }},
  "entropy": {{
    "rate_limiter": null
  }},
  "pmem": [
    {{
      "id": "pmem",
      "path_on_host": "{}",
      "root_device": true,
      "read_only": true,
      "rate_limiter": null
    }}
  ],
  "memory-hotplug": {{
    "total_size_mib": 1024,
    "block_size_mib": 2,
    "slot_size_mib": 128
  }}
}}"#,
            _block_files.last().unwrap().as_path().to_str().unwrap(),
            tmp_sock_file.as_path().to_str().unwrap(),
            _pmem_files.last().unwrap().as_path().to_str().unwrap(),
        );

        assert_eq!(
            vm_resources
                .mmds
                .as_ref()
                .unwrap()
                .lock()
                .unwrap()
                .version(),
            MmdsVersion::V2
        );
        assert_eq!(mmio_state.mmds.as_ref().unwrap().version, MmdsVersion::V2);
        assert_eq!(
            expected_vm_resources,
            serde_json::to_string_pretty(&VmmConfig::from(&*vm_resources)).unwrap()
        );
    }
}
