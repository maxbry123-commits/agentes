/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import io.atomix.cluster.BrokerMemberId;
import io.atomix.utils.net.Address;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.service.exception.ErrorMapper;
import io.camunda.service.exception.ServiceException;
import io.camunda.service.exception.ServiceException.Status;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.broker.client.api.BrokerClusterState;
import io.camunda.zeebe.dynamic.config.state.PartitionState;
import io.camunda.zeebe.protocol.record.PartitionHealthStatus;
import io.camunda.zeebe.util.VersionUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TopologyServices extends PhysicalTenantScopedApiServices<TopologyServices> {

  private static final Logger LOGGER = LoggerFactory.getLogger(TopologyServices.class);

  public TopologyServices(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter) {
    super(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        executorProvider,
        brokerRequestAuthorizationConverter);
  }

  public CompletableFuture<ClusterStatus> getStatus() {
    try {
      if (!hasAPartitionWithAHealthyLeader()) {
        return CompletableFuture.completedFuture(ClusterStatus.UNHEALTHY);
      }

      return CompletableFuture.completedFuture(ClusterStatus.HEALTHY);
    } catch (final Exception ex) {
      return CompletableFuture.failedFuture(ErrorMapper.mapError(ex));
    }
  }

  private boolean hasAPartitionWithAHealthyLeader() {
    final var topology = brokerClient.getTopologyManager().getTopology(getPhysicalTenantId());

    if (topology == null) {
      return false;
    }

    final var partitions = topology.getPartitions();

    return partitions.stream()
        .anyMatch(
            partition -> {
              final var leader = topology.getLeaderForPartition(partition);
              return leader != null
                  && topology.getPartitionHealth(leader, partition)
                      == PartitionHealthStatus.HEALTHY;
            });
  }

  public CompletableFuture<Topology> getTopology() {
    try {
      final var clusterState = brokerClient.getTopologyManager().getTopology(getPhysicalTenantId());
      if (clusterState == null) {
        return CompletableFuture.failedFuture(
            new ServiceException(
                "Cluster topology is not yet available. The gateway has not received cluster state from any broker.",
                Status.UNAVAILABLE));
      }

      final var topology = Topology.Builder.create();

      final var gatewayVersion = VersionUtil.getVersion();
      if (gatewayVersion != null && !gatewayVersion.isBlank()) {
        topology.gatewayVersion(gatewayVersion);
      }

      topology
          .clusterId(clusterState.getClusterId())
          .clusterSize(clusterState.getClusterSize())
          .partitionsCount(clusterState.getPartitionsCount())
          .replicationFactor(clusterState.getReplicationFactor())
          .lastCompletedChangeId(clusterState.getLastCompletedChangeId());

      clusterState
          .getBrokers()
          .forEach(
              brokerId -> {
                final var broker = Broker.Builder.create();
                addBrokerInfo(broker, brokerId, clusterState);
                addPartitionInfoToBrokerInfo(broker, brokerId, clusterState);

                topology.addBroker(broker.build());
              });

      return CompletableFuture.completedFuture(topology.build());
    } catch (final Exception ex) {
      return CompletableFuture.failedFuture(ErrorMapper.mapError(ex));
    }
  }

  private void addBrokerInfo(
      final Broker.Builder broker,
      final BrokerMemberId brokerId,
      final BrokerClusterState topology) {
    final var brokerAddress = topology.getBrokerAddress(brokerId);
    final var address = Address.from(brokerAddress);

    broker
        .brokerId(brokerId)
        .host(address.host())
        .port(address.port())
        .version(topology.getBrokerVersion(brokerId));
  }

  private void addPartitionInfoToBrokerInfo(
      final Broker.Builder broker,
      final BrokerMemberId brokerId,
      final BrokerClusterState topology) {
    topology
        .getPartitions()
        .forEach(
            partitionId -> {
              final var partition = Partition.Builder.create();

              partition.partitionId(partitionId);
              final var isRoleSet = setRole(brokerId, partitionId, topology, partition);
              if (!isRoleSet) {
                return;
              }

              final var status = topology.getPartitionHealth(brokerId, partitionId);

              switch (status) {
                case HEALTHY -> partition.health(Health.HEALTHY);
                case UNHEALTHY -> partition.health(Health.UNHEALTHY);
                case DEAD -> partition.health(Health.DEAD);
                case null, default ->
                    LOGGER.debug(
                        "Unsupported partition broker health status '{}'",
                        Optional.ofNullable(status)
                            .map(PartitionHealthStatus::name)
                            .orElse("null"));
              }
              partition.state(mapState(topology.getPartitionState(brokerId, partitionId)));
              broker.addPartition(partition.build());
            });
  }

  private boolean setRole(
      final BrokerMemberId brokerId,
      final Integer partitionId,
      final BrokerClusterState topology,
      final Partition.Builder partition) {
    final var partitionLeader = topology.getLeaderForPartition(partitionId);
    final var partitionFollowers = topology.getFollowersForPartition(partitionId);
    final var partitionInactives = topology.getInactiveNodesForPartition(partitionId);

    if (brokerId.equals(partitionLeader)) {
      partition.role(Role.LEADER);
    } else if (partitionFollowers != null && partitionFollowers.contains(brokerId)) {
      partition.role(Role.FOLLOWER);
    } else if (partitionInactives != null && partitionInactives.contains(brokerId)) {
      partition.role(Role.INACTIVE);
    } else {
      return false;
    }

    return true;
  }

  private static State mapState(final PartitionState.State state) {
    return switch (state) {
      case UNKNOWN, BOOTSTRAPPING -> State.UNKNOWN;
      case JOINING -> State.JOINING;
      case ACTIVE -> State.ACTIVE;
      case LEAVING -> State.LEAVING;
      case RECOVERING -> State.RECOVERING;
    };
  }

  public record Topology(
      List<Broker> brokers,
      String clusterId,
      Integer clusterSize,
      Integer partitionsCount,
      Integer replicationFactor,
      String gatewayVersion,
      Long lastCompletedChangeId) {

    static class Builder {
      List<Broker> brokers = new ArrayList<>();
      String clusterId;
      Integer clusterSize;
      Integer partitionsCount;
      Integer replicationFactor;
      String gatewayVersion;
      Long lastCompletedChangeId;

      public static Builder create() {
        return new Builder();
      }

      public Builder addBroker(final Broker broker) {
        brokers.add(broker);
        return this;
      }

      public Builder clusterId(final String clusterId) {
        this.clusterId = clusterId;
        return this;
      }

      public Builder clusterSize(final Integer clusterSize) {
        this.clusterSize = clusterSize;
        return this;
      }

      public Builder partitionsCount(final Integer partitionsCount) {
        this.partitionsCount = partitionsCount;
        return this;
      }

      public Builder replicationFactor(final Integer replicationFactor) {
        this.replicationFactor = replicationFactor;
        return this;
      }

      public Builder gatewayVersion(final String gatewayVersion) {
        this.gatewayVersion = gatewayVersion;
        return this;
      }

      public Builder lastCompletedChangeId(final long lastCompletedChangeId) {
        this.lastCompletedChangeId = lastCompletedChangeId;
        return this;
      }

      public Topology build() {
        return new Topology(
            brokers,
            clusterId,
            clusterSize,
            partitionsCount,
            replicationFactor,
            gatewayVersion,
            lastCompletedChangeId);
      }
    }
  }

  public record Broker(
      BrokerMemberId brokerId,
      String host,
      Integer port,
      List<Partition> partitions,
      String version) {

    public Broker(
        @Nullable final String zone,
        final int nodeId,
        final String host,
        final Integer port,
        final List<Partition> partitions,
        final String version) {
      this(BrokerMemberId.from(zone, nodeId), host, port, partitions, version);
    }

    public Broker {
      Objects.requireNonNull(brokerId, "Expected brokerId to not be null");
    }

    public int nodeIdx() {
      return brokerId.nodeIdx();
    }

    public @Nullable String zone() {
      return brokerId.zone();
    }

    public String brokerIdStr() {
      return brokerId.id();
    }

    static class Builder {
      BrokerMemberId brokerId;
      String host;
      Integer port;
      List<Partition> partitions = new ArrayList<>();
      String version;

      public static Builder create() {
        return new Builder();
      }

      public Builder brokerId(final BrokerMemberId brokerId) {
        this.brokerId = brokerId;
        return this;
      }

      public Builder host(final String host) {
        this.host = host;
        return this;
      }

      public Builder port(final Integer port) {
        this.port = port;
        return this;
      }

      public Builder addPartition(final Partition partition) {
        partitions.add(partition);
        return this;
      }

      public Builder version(final String version) {
        this.version = version;
        return this;
      }

      public Broker build() {
        return new Broker(brokerId, host, port, partitions, version);
      }
    }
  }

  public record Partition(Integer partitionId, Role role, Health health, State state) {
    static class Builder {
      Integer partitionId;
      Role role;
      Health health;
      State state;

      public static Builder create() {
        return new Builder();
      }

      public Builder partitionId(final Integer partitionId) {
        this.partitionId = partitionId;
        return this;
      }

      public Builder role(final Role role) {
        this.role = role;
        return this;
      }

      public Builder health(final Health health) {
        this.health = health;
        return this;
      }

      public Builder state(final State state) {
        this.state = state;
        return this;
      }

      public Partition build() {
        return new Partition(partitionId, role, health, state);
      }
    }
  }

  /** Describes the Raft role of the broker for a given partition. */
  public enum Role {
    LEADER,
    FOLLOWER,
    INACTIVE
  }

  /** Describes the current health of the partition. */
  public enum Health {
    HEALTHY,
    UNHEALTHY,
    DEAD
  }

  /** Describes the current operational state of the partition in the cluster configuration. */
  public enum State {
    UNKNOWN,
    JOINING,
    ACTIVE,
    LEAVING,
    RECOVERING
  }

  public enum ClusterStatus {
    HEALTHY,
    UNHEALTHY
  }
}
