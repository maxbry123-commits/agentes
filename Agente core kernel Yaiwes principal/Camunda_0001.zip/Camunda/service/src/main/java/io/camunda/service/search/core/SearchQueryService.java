/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service.search.core;

import io.camunda.search.exception.CamundaSearchException;
import io.camunda.search.query.SearchQueryBase;
import io.camunda.search.query.SearchQueryResult;
import io.camunda.security.api.model.CamundaAuthentication;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.service.ApiServicesExecutorProvider;
import io.camunda.service.PhysicalTenantScopedApiServices;
import io.camunda.service.exception.ErrorMapper;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import java.util.function.Supplier;

public abstract class SearchQueryService<
        T extends PhysicalTenantScopedApiServices<T>, Q extends SearchQueryBase, D>
    extends PhysicalTenantScopedApiServices<T> {

  protected SearchQueryService(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter) {
    super(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        executorProvider,
        brokerRequestAuthorizationConverter);
  }

  public abstract SearchQueryResult<D> search(
      final Q query, final CamundaAuthentication authentication);

  protected <R> R executeSearchRequest(final Supplier<R> searchRequest) {
    try {
      return searchRequest.get();
    } catch (final CamundaSearchException cse) {
      throw ErrorMapper.mapSearchError(cse);
    }
  }
}
