/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import static io.camunda.service.authorization.Authorizations.JOB_READ_AUTHORIZATION;

import io.camunda.search.clients.JobSearchClient;
import io.camunda.search.entities.GlobalJobStatisticsEntity;
import io.camunda.search.entities.JobEntity;
import io.camunda.search.entities.JobErrorStatisticsEntity;
import io.camunda.search.entities.JobTimeSeriesStatisticsEntity;
import io.camunda.search.entities.JobTypeStatisticsEntity;
import io.camunda.search.entities.JobWorkerStatisticsEntity;
import io.camunda.search.filter.JobFilter;
import io.camunda.search.query.GlobalJobStatisticsQuery;
import io.camunda.search.query.JobErrorStatisticsQuery;
import io.camunda.search.query.JobQuery;
import io.camunda.search.query.JobTimeSeriesStatisticsQuery;
import io.camunda.search.query.JobTypeStatisticsQuery;
import io.camunda.search.query.JobWorkerStatisticsQuery;
import io.camunda.search.query.SearchQueryResult;
import io.camunda.security.api.model.CamundaAuthentication;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.security.core.auth.RequiredAuthorization;
import io.camunda.service.search.core.SearchQueryService;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerActivateJobsRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerCompleteJobRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerCreateBatchOperationRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerFailJobRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerThrowErrorRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerUpdateJobRequest;
import io.camunda.zeebe.gateway.impl.job.ActivateJobsHandler;
import io.camunda.zeebe.gateway.impl.job.ResponseObserver;
import io.camunda.zeebe.gateway.validation.VariableNameLengthValidator;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationCreationRecord;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationJobUpdatePlan;
import io.camunda.zeebe.protocol.impl.record.value.job.JobRecord;
import io.camunda.zeebe.protocol.impl.record.value.job.JobResult;
import io.camunda.zeebe.protocol.record.value.BatchOperationType;
import io.camunda.zeebe.protocol.record.value.TenantFilter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public final class JobServices<T> extends SearchQueryService<JobServices<T>, JobQuery, JobEntity> {

  private final ActivateJobsHandler<T> activateJobsHandler;
  private final JobSearchClient jobSearchClient;
  private final int maxVariableNameLength;

  public JobServices(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final ActivateJobsHandler<T> activateJobsHandler,
      final JobSearchClient jobSearchClient,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter) {
    this(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        activateJobsHandler,
        jobSearchClient,
        executorProvider,
        brokerRequestAuthorizationConverter,
        VariableNameLengthValidator.DEFAULT_MAX_NAME_FIELD_LENGTH);
  }

  public JobServices(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final ActivateJobsHandler<T> activateJobsHandler,
      final JobSearchClient jobSearchClient,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter,
      final int maxVariableNameLength) {
    super(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        executorProvider,
        brokerRequestAuthorizationConverter);
    this.activateJobsHandler = activateJobsHandler;
    this.jobSearchClient = jobSearchClient;
    this.maxVariableNameLength = maxVariableNameLength;
  }

  public void activateJobs(
      final ActivateJobsRequest request,
      final ResponseObserver<T> responseObserver,
      final Consumer<Runnable> cancelationHandlerConsumer,
      final CamundaAuthentication authentication) {
    final var brokerRequest =
        new BrokerActivateJobsRequest(request.type())
            .setMaxJobsToActivate(request.maxJobsToActivate())
            .setTenantIds(request.tenantIds())
            .setTenantFilter(request.tenantFilter())
            .setTimeout(request.timeout())
            .setWorker(request.worker())
            .setVariables(request.fetchVariable())
            .setWithLease(request.withLease());
    // Apply the full mutator set (authorization AND, for physical-tenant-scoped services, the
    // partition group) so job activation round-robins over the tenant's partition group. The
    // handler reads brokerRequest.getPartitionGroup() when selecting partitions.
    applyBrokerRequestMutators(brokerRequest, authentication);
    activateJobsHandler.activateJobs(
        brokerRequest, responseObserver, cancelationHandlerConsumer, request.requestTimeout());
  }

  public CompletableFuture<JobRecord> failJob(
      final long jobKey,
      final int retries,
      final String errorMessage,
      final Long retryBackOff,
      final Map<String, Object> variables,
      final String leaseToken,
      final CamundaAuthentication authentication) {
    final var request =
        new BrokerFailJobRequest(jobKey, retries, retryBackOff)
            .setVariables(getDocumentOrEmpty(variables))
            .setErrorMessage(errorMessage);
    if (leaseToken != null) {
      request.setLeaseToken(leaseToken);
    }
    return sendBrokerRequest(request, authentication);
  }

  public CompletableFuture<JobRecord> errorJob(
      final long jobKey,
      final String errorCode,
      final String errorMessage,
      final Map<String, Object> variables,
      final String leaseToken,
      final CamundaAuthentication authentication) {
    final var request =
        new BrokerThrowErrorRequest(jobKey, errorCode)
            .setErrorMessage(errorMessage)
            .setVariables(getDocumentOrEmpty(variables));
    if (leaseToken != null) {
      request.setLeaseToken(leaseToken);
    }
    return sendBrokerRequest(request, authentication);
  }

  public CompletableFuture<JobRecord> completeJob(
      final long jobKey,
      final Map<String, Object> variables,
      final JobResult result,
      final String leaseToken,
      final String businessId,
      final CamundaAuthentication authentication) {
    final var request =
        new BrokerCompleteJobRequest(
            jobKey, getDocumentOrEmpty(variables), result, maxVariableNameLength);
    if (leaseToken != null) {
      request.setLeaseToken(leaseToken);
    }
    if (businessId != null) {
      request.setBusinessId(businessId);
    }
    return sendBrokerRequest(request, authentication);
  }

  public CompletableFuture<JobRecord> updateJob(
      final long jobKey,
      final Long operationReference,
      final UpdateJobChangeset changeset,
      final String leaseToken,
      final CamundaAuthentication authentication) {
    final var brokerRequest =
        new BrokerUpdateJobRequest(
            jobKey, changeset.retries(), changeset.timeout(), changeset.priority());
    if (operationReference != null) {
      brokerRequest.setOperationReference(operationReference);
    }
    if (leaseToken != null) {
      brokerRequest.setLeaseToken(leaseToken);
    }
    return sendBrokerRequest(brokerRequest, authentication);
  }

  @Override
  public SearchQueryResult<JobEntity> search(
      final JobQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, JOB_READ_AUTHORIZATION))
                .searchJobs(query));
  }

  public GlobalJobStatisticsEntity getGlobalStatistics(
      final GlobalJobStatisticsQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, RequiredAuthorization.of(a -> a.system().readJobMetric())))
                .getGlobalJobStatistics(query));
  }

  public SearchQueryResult<JobTypeStatisticsEntity> getJobTypeStatistics(
      final JobTypeStatisticsQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, RequiredAuthorization.of(a -> a.system().readJobMetric())))
                .getJobTypeStatistics(query));
  }

  public SearchQueryResult<JobWorkerStatisticsEntity> getJobWorkerStatistics(
      final JobWorkerStatisticsQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, RequiredAuthorization.of(a -> a.system().readJobMetric())))
                .getJobWorkerStatistics(query));
  }

  public SearchQueryResult<JobTimeSeriesStatisticsEntity> getJobTimeSeriesStatistics(
      final JobTimeSeriesStatisticsQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, RequiredAuthorization.of(a -> a.system().readJobMetric())))
                .getJobTimeSeriesStatistics(query));
  }

  public SearchQueryResult<JobErrorStatisticsEntity> getJobErrorStatistics(
      final JobErrorStatisticsQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            jobSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, JOB_READ_AUTHORIZATION))
                .getJobErrorStatistics(query));
  }

  public CompletableFuture<BatchOperationCreationRecord> updateJobsBatchOperation(
      final BatchUpdateJobRequest request, final CamundaAuthentication authentication) {
    final var plan = new BatchOperationJobUpdatePlan();
    if (request.changeset().retries() != null) {
      plan.setRetries(request.changeset().retries());
    }
    if (request.changeset().timeout() != null) {
      plan.setTimeout(request.changeset().timeout());
    }
    if (request.changeset().priority() != null) {
      plan.setPriority(request.changeset().priority());
    }

    final var brokerRequest =
        new BrokerCreateBatchOperationRequest()
            .setFilter(request.filter())
            .setJobUpdatePlan(plan)
            .setBatchOperationType(BatchOperationType.UPDATE_JOB)
            .setAuthentication(authentication);

    return sendBrokerRequest(brokerRequest, authentication);
  }

  public record ActivateJobsRequest(
      String type,
      int maxJobsToActivate,
      List<String> tenantIds,
      TenantFilter tenantFilter,
      long timeout,
      String worker,
      List<String> fetchVariable,
      long requestTimeout,
      boolean withLease) {}

  public record UpdateJobChangeset(Integer retries, Long timeout, Integer priority) {}

  public record BatchUpdateJobRequest(JobFilter filter, UpdateJobChangeset changeset) {}
}
