/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import static io.camunda.security.core.auth.RequiredAuthorization.withRequiredAuthorization;
import static io.camunda.service.authorization.Authorizations.ELEMENT_INSTANCE_READ_AUTHORIZATION;

import io.camunda.search.clients.FlowNodeInstanceSearchClient;
import io.camunda.search.clients.WaitStateSearchClient;
import io.camunda.search.entities.FlowNodeInstanceEntity;
import io.camunda.search.entities.IncidentEntity;
import io.camunda.search.entities.WaitStateEntity;
import io.camunda.search.filter.Operation;
import io.camunda.search.query.ElementInstanceWaitStateQuery;
import io.camunda.search.query.FlowNodeInstanceQuery;
import io.camunda.search.query.IncidentQuery;
import io.camunda.search.query.SearchQueryResult;
import io.camunda.security.api.model.CamundaAuthentication;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.security.core.auth.SecurityContext;
import io.camunda.service.cache.ProcessCache;
import io.camunda.service.cache.ProcessCacheItem;
import io.camunda.service.search.core.SearchQueryService;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerSetVariablesRequest;
import io.camunda.zeebe.protocol.impl.record.value.variable.VariableDocumentRecord;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public final class ElementInstanceServices
    extends SearchQueryService<
        ElementInstanceServices, FlowNodeInstanceQuery, FlowNodeInstanceEntity> {

  private static final String FNI_ELEMENT_INSTANCE_PATTERN = "*FNI_%d*";
  private final FlowNodeInstanceSearchClient flowNodeInstanceSearchClient;
  private final WaitStateSearchClient waitStateSearchClient;
  private final ProcessCache processCache;
  private final IncidentServices incidentServices;

  public ElementInstanceServices(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final FlowNodeInstanceSearchClient flowNodeInstanceSearchClient,
      final WaitStateSearchClient waitStateSearchClient,
      final ProcessCache processCache,
      final IncidentServices incidentServices,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter) {
    super(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        executorProvider,
        brokerRequestAuthorizationConverter);
    this.flowNodeInstanceSearchClient = flowNodeInstanceSearchClient;
    this.waitStateSearchClient = waitStateSearchClient;
    this.processCache = processCache;
    this.incidentServices = incidentServices;
  }

  @Override
  public SearchQueryResult<FlowNodeInstanceEntity> search(
      final FlowNodeInstanceQuery query, final CamundaAuthentication authentication) {
    return search(
        query,
        securityContextProvider.provideSecurityContext(
            authentication, ELEMENT_INSTANCE_READ_AUTHORIZATION));
  }

  public FlowNodeInstanceEntity getByKey(
      final Long key, final CamundaAuthentication authentication) {
    final var result =
        executeSearchRequest(
            () ->
                flowNodeInstanceSearchClient
                    .withSecurityContext(
                        securityContextProvider.provideSecurityContext(
                            authentication,
                            withRequiredAuthorization(
                                ELEMENT_INSTANCE_READ_AUTHORIZATION,
                                FlowNodeInstanceEntity::processDefinitionId)))
                    .getFlowNodeInstance(key));

    final var cachedItem = processCache.getCacheItem(result.processDefinitionKey());
    return toCacheEnrichedFlowNodeInstanceEntity(result, cachedItem);
  }

  private SearchQueryResult<FlowNodeInstanceEntity> search(
      final FlowNodeInstanceQuery query, final SecurityContext securityContext) {

    final var result =
        executeSearchRequest(
            () ->
                flowNodeInstanceSearchClient
                    .withSecurityContext(securityContext)
                    .searchFlowNodeInstances(query));

    return toCacheEnrichedResult(result);
  }

  public CompletableFuture<VariableDocumentRecord> setVariables(
      final ElementInstanceServices.SetVariablesRequest request,
      final CamundaAuthentication authentication) {
    final var brokerRequest =
        new BrokerSetVariablesRequest()
            .setElementInstanceKey(request.elementInstanceKey())
            .setVariables(getDocumentOrEmpty(request.variables()))
            .setLocal(request.local());

    if (request.operationReference() != null) {
      brokerRequest.setOperationReference(request.operationReference());
    }
    return sendBrokerRequest(brokerRequest, authentication);
  }

  private SearchQueryResult<FlowNodeInstanceEntity> toCacheEnrichedResult(
      final SearchQueryResult<FlowNodeInstanceEntity> result) {
    final var processDefinitionKeys =
        result.items().stream()
            .filter(u -> !u.hasFlowNodeName())
            .map(FlowNodeInstanceEntity::processDefinitionKey)
            .collect(Collectors.toSet());

    if (processDefinitionKeys.isEmpty()) {
      return result;
    }

    final var cacheResult = processCache.getCacheItems(processDefinitionKeys);

    return result.withItems(
        result.items().stream()
            .map(
                item ->
                    toCacheEnrichedFlowNodeInstanceEntity(
                        item, cacheResult.getProcessItem(item.processDefinitionKey())))
            .collect(Collectors.toList()));
  }

  private FlowNodeInstanceEntity toCacheEnrichedFlowNodeInstanceEntity(
      final FlowNodeInstanceEntity item, final ProcessCacheItem cachedItem) {
    return item.hasFlowNodeName()
        ? item
        : item.withFlowNodeName(cachedItem.getElementName(item.flowNodeId()));
  }

  public SearchQueryResult<IncidentEntity> searchIncidents(
      final long elementInstanceKey,
      final IncidentQuery query,
      final CamundaAuthentication authentication) {
    final var elementInstance = getByKey(elementInstanceKey, authentication);
    return incidentServices.search(
        IncidentQuery.of(
            b ->
                b.filter(
                        query.filter().toBuilder()
                            .treePathOperations(
                                Operation.like(
                                    String.format(
                                        FNI_ELEMENT_INSTANCE_PATTERN,
                                        elementInstance.flowNodeInstanceKey())))
                            .build())
                    .sort(query.sort())
                    .page(query.page())),
        authentication);
  }

  public SearchQueryResult<WaitStateEntity> searchWaitStates(
      final ElementInstanceWaitStateQuery query, final CamundaAuthentication authentication) {
    return executeSearchRequest(
        () ->
            waitStateSearchClient
                .withSecurityContext(
                    securityContextProvider.provideSecurityContext(
                        authentication, ELEMENT_INSTANCE_READ_AUTHORIZATION))
                .searchWaitStates(query));
  }

  public record SetVariablesRequest(
      long elementInstanceKey,
      Map<String, Object> variables,
      Boolean local,
      Long operationReference) {}
}
