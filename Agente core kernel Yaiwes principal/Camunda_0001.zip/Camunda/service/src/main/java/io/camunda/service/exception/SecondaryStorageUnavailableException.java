/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service.exception;

import static io.camunda.spring.utils.DatabaseTypeUtils.UNIFIED_CONFIG_PROPERTY_CAMUNDA_DATABASE_TYPE;

/**
 * Thrown when secondary storage is not configured at all ({@code
 * camunda.data.secondary-storage.type=none}). HTTP 403 — contrast with {@link
 * SecondaryStorageDegradedException}, which is HTTP 503 for a configured but currently-degraded
 * physical tenant.
 */
public class SecondaryStorageUnavailableException extends ServiceException {
  public static final String NO_SECONDARY_STORAGE_MESSAGE =
      "This endpoint requires a secondary storage, but none is set. Secondary storage can be configured using the '%s' property."
          .formatted(UNIFIED_CONFIG_PROPERTY_CAMUNDA_DATABASE_TYPE);

  public SecondaryStorageUnavailableException() {
    super(NO_SECONDARY_STORAGE_MESSAGE, ServiceException.Status.FORBIDDEN);
  }
}
