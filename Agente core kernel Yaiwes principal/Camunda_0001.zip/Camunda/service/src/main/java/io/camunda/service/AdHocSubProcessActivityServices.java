/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import io.camunda.security.api.model.CamundaAuthentication;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerActivateAdHocSubProcessActivityRequest;
import io.camunda.zeebe.protocol.impl.record.value.adhocsubprocess.AdHocSubProcessInstructionRecord;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class AdHocSubProcessActivityServices
    extends PhysicalTenantScopedApiServices<AdHocSubProcessActivityServices> {

  public AdHocSubProcessActivityServices(
      final String physicalTenantId,
      final BrokerClient brokerClient,
      final SecurityContextProvider securityContextProvider,
      final ApiServicesExecutorProvider executorProvider,
      final BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter) {
    super(
        physicalTenantId,
        brokerClient,
        securityContextProvider,
        executorProvider,
        brokerRequestAuthorizationConverter);
  }

  public CompletableFuture<AdHocSubProcessInstructionRecord> activateActivities(
      final AdHocSubProcessActivateActivitiesRequest request,
      final CamundaAuthentication authentication) {
    final var brokerRequest =
        new BrokerActivateAdHocSubProcessActivityRequest()
            .setAdHocSubProcessInstanceKey(request.adHocSubProcessInstanceKey());

    request
        .elements()
        .forEach(
            element ->
                brokerRequest.addElement(
                    element.elementId(), getDocumentOrEmpty(element.variables())));

    brokerRequest.cancelRemainingInstances(request.cancelRemainingInstances());

    return sendBrokerRequest(brokerRequest, authentication);
  }

  public record AdHocSubProcessActivateActivitiesRequest(
      long adHocSubProcessInstanceKey,
      List<AdHocSubProcessActivateActivityReference> elements,
      boolean cancelRemainingInstances) {
    public record AdHocSubProcessActivateActivityReference(
        String elementId, Map<String, Object> variables) {}
  }
}
