/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import io.atomix.cluster.BrokerMemberId;
import io.camunda.service.TopologyServices.Broker;
import io.camunda.service.TopologyServices.ClusterStatus;
import io.camunda.service.TopologyServices.Health;
import io.camunda.service.TopologyServices.Partition;
import io.camunda.service.TopologyServices.Role;
import io.camunda.service.TopologyServices.State;
import io.camunda.service.TopologyServices.Topology;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.broker.client.api.BrokerClusterState;
import io.camunda.zeebe.broker.client.api.BrokerTopologyManager;
import io.camunda.zeebe.dynamic.config.state.PartitionState;
import io.camunda.zeebe.protocol.record.PartitionHealthStatus;
import io.camunda.zeebe.util.VersionUtil;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;
import org.assertj.core.api.Assertions;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mockito;

@NullMarked
public class TopologyServiceTest {

  private static final String PHYSICAL_TENANT_ID = "test-tenant";
  private final int partitionId1 = 1;
  private final int partitionId2 = 2;
  private final int partitionId3 = 3;
  private final BrokerMemberId leaderId1 = BrokerMemberId.from(1);
  private final BrokerMemberId leaderId2 = BrokerMemberId.from(2);
  private final BrokerMemberId leaderId3 = BrokerMemberId.from(3);
  private BrokerClient brokerClient;
  private BrokerClusterState clusterState;
  private TopologyServices services;
  private BrokerTopologyManager topologyManager;

  @BeforeEach
  public void before() {
    brokerClient = mock(BrokerClient.class);
    clusterState = mock(BrokerClusterState.class);
    topologyManager = mock(BrokerTopologyManager.class);
    when(brokerClient.getTopologyManager()).thenReturn(topologyManager);
    when(topologyManager.getTopology(PHYSICAL_TENANT_ID)).thenReturn(clusterState);
    services =
        new TopologyServices(
            PHYSICAL_TENANT_ID,
            brokerClient,
            mock(SecurityContextProvider.class),
            mock(ApiServicesExecutorProvider.class),
            null);
  }

  @Test
  void shouldReturnHealthyWhenAtLeastOnePartitionHasHealthyLeader() {
    when(clusterState.getPartitions()).thenReturn(List.of(partitionId1, partitionId2));
    when(clusterState.getLeaderForPartition(partitionId1)).thenReturn(leaderId1);
    when(clusterState.getLeaderForPartition(partitionId2)).thenReturn(leaderId2);
    when(clusterState.getPartitionHealth(leaderId1, partitionId1))
        .thenReturn(PartitionHealthStatus.HEALTHY);
    when(clusterState.getPartitionHealth(leaderId2, partitionId2))
        .thenReturn(PartitionHealthStatus.UNHEALTHY);

    // when
    final var status = services.getStatus().join();

    // then
    Assertions.assertThat(status).isEqualTo(ClusterStatus.HEALTHY);

    verify(brokerClient).getTopologyManager();
    verify(topologyManager).getTopology(PHYSICAL_TENANT_ID);
    verify(clusterState).getPartitions();
    verify(clusterState).getLeaderForPartition(partitionId1);
    verify(clusterState).getPartitionHealth(leaderId1, partitionId1);
  }

  @ParameterizedTest
  @EnumSource(
      value = PartitionHealthStatus.class,
      names = {"HEALTHY"},
      mode = EnumSource.Mode.EXCLUDE)
  void shouldReturnUnhealthyWhenNoPartitionHasHealthyLeader(
      final PartitionHealthStatus unhealthyStatus) {
    when(clusterState.getPartitions()).thenReturn(List.of(partitionId1, partitionId2));
    when(clusterState.getLeaderForPartition(partitionId1)).thenReturn(leaderId1);
    when(clusterState.getLeaderForPartition(partitionId2)).thenReturn(leaderId2);
    when(clusterState.getPartitionHealth(leaderId1, partitionId1)).thenReturn(unhealthyStatus);
    when(clusterState.getPartitionHealth(leaderId2, partitionId2)).thenReturn(unhealthyStatus);

    // when
    final var status = services.getStatus().join();

    // then
    Assertions.assertThat(status).isEqualTo(ClusterStatus.UNHEALTHY);

    verify(brokerClient).getTopologyManager();
    verify(topologyManager).getTopology(PHYSICAL_TENANT_ID);
    verify(clusterState).getPartitions();
    verify(clusterState).getLeaderForPartition(partitionId1);
    verify(clusterState).getPartitionHealth(leaderId1, partitionId1);
    verify(clusterState).getLeaderForPartition(partitionId2);
    verify(clusterState).getPartitionHealth(leaderId2, partitionId2);
  }

  @Test
  void shouldReturnUnhealthyWhenNoPartitionsExist() {
    // given
    when(clusterState.getPartitions()).thenReturn(List.of());

    // when
    final var status = services.getStatus().join();

    // then
    Assertions.assertThat(status).isEqualTo(ClusterStatus.UNHEALTHY);

    verify(brokerClient).getTopologyManager();
    verify(topologyManager).getTopology(PHYSICAL_TENANT_ID);
    verify(clusterState).getPartitions();
  }

  @Test
  void shouldReturnUnhealthyWhenNoTopologyExist() {
    // given
    when(topologyManager.getTopology(PHYSICAL_TENANT_ID)).thenReturn(null);

    // when
    final var status = services.getStatus().join();

    // then
    Assertions.assertThat(status).isEqualTo(ClusterStatus.UNHEALTHY);

    verify(brokerClient).getTopologyManager();
    verify(topologyManager).getTopology(PHYSICAL_TENANT_ID);
    verifyNoInteractions(clusterState);
  }

  @Test
  void shouldHandleMixedPartitionHealthStatuses() {
    // given

    when(clusterState.getPartitions())
        .thenReturn(List.of(partitionId1, partitionId2, partitionId3));
    when(clusterState.getLeaderForPartition(partitionId1)).thenReturn(leaderId1);
    when(clusterState.getLeaderForPartition(partitionId2)).thenReturn(leaderId2);
    when(clusterState.getLeaderForPartition(partitionId3)).thenReturn(leaderId3);
    when(clusterState.getPartitionHealth(leaderId1, partitionId1))
        .thenReturn(PartitionHealthStatus.DEAD);
    when(clusterState.getPartitionHealth(leaderId2, partitionId2))
        .thenReturn(PartitionHealthStatus.UNHEALTHY);
    when(clusterState.getPartitionHealth(leaderId3, partitionId3))
        .thenReturn(PartitionHealthStatus.HEALTHY);

    // when
    final var status = services.getStatus().join();

    // then
    Assertions.assertThat(status).isEqualTo(ClusterStatus.HEALTHY);

    verify(brokerClient).getTopologyManager();
    verify(topologyManager).getTopology(PHYSICAL_TENANT_ID);
    verify(clusterState).getPartitions();
    verify(clusterState).getLeaderForPartition(partitionId1);
    verify(clusterState).getPartitionHealth(leaderId1, partitionId1);
    verify(clusterState).getLeaderForPartition(partitionId2);
    verify(clusterState).getPartitionHealth(leaderId2, partitionId2);
    verify(clusterState).getLeaderForPartition(partitionId3);
    verify(clusterState).getPartitionHealth(leaderId3, partitionId3);
  }

  @ParameterizedTest
  @ValueSource(strings = {"", "us-east1"})
  public void shouldGetTopology(String zone) {
    // given
    final var version = VersionUtil.getVersion();
    final var clusterId = "cluster-id";

    // null cannot be used in ValueSource
    if (zone.isEmpty()) {
      zone = null;
    }
    when(topologyManager.getTopology(PHYSICAL_TENANT_ID))
        .thenReturn(new TestBrokerClusterState(zone, version, clusterId));

    final var expectedTopology =
        new Topology(
            List.of(
                new Broker(
                    zone,
                    0,
                    "localhost",
                    26501,
                    List.of(new Partition(1, Role.LEADER, Health.HEALTHY, State.UNKNOWN)),
                    version),
                new Broker(
                    zone,
                    1,
                    "localhost",
                    26502,
                    List.of(new Partition(1, Role.FOLLOWER, Health.HEALTHY, State.UNKNOWN)),
                    version),
                new Broker(
                    zone,
                    2,
                    "localhost",
                    26503,
                    List.of(new Partition(1, Role.INACTIVE, Health.UNHEALTHY, State.UNKNOWN)),
                    version)),
            "cluster-id",
            3,
            1,
            3,
            version,
            1L);

    // when
    final var topology = services.getTopology().join();

    // then
    Assertions.assertThat(topology).isEqualTo(expectedTopology);
  }

  @ParameterizedTest
  @EnumSource(PartitionState.State.class)
  public void shouldExposePartitionOperationalState(final PartitionState.State dynamicConfigState) {
    // given
    final var version = VersionUtil.getVersion();
    when(topologyManager.getTopology(PHYSICAL_TENANT_ID))
        .thenReturn(new TestBrokerClusterState(null, version, "cluster-id", dynamicConfigState));

    // when
    final var topology = services.getTopology().join();

    // then
    final var leaderPartitionState =
        topology.brokers().stream()
            .filter(broker -> broker.nodeIdx() == 0)
            .findFirst()
            .orElseThrow()
            .partitions()
            .getFirst()
            .state();
    Assertions.assertThat(leaderPartitionState).isEqualTo(expectedState(dynamicConfigState));
  }

  private static State expectedState(final PartitionState.State dynamicConfigState) {
    return switch (dynamicConfigState) {
      case UNKNOWN, BOOTSTRAPPING -> State.UNKNOWN;
      case JOINING -> State.JOINING;
      case ACTIVE -> State.ACTIVE;
      case LEAVING -> State.LEAVING;
      case RECOVERING -> State.RECOVERING;
    };
  }

  @Test
  void shouldFailWithUnavailableWhenClusterStateNotYetReceived() {
    // given
    Mockito.when(topologyManager.getTopology(PHYSICAL_TENANT_ID)).thenReturn(null);

    // when / then
    Assertions.assertThatThrownBy(() -> services.getTopology().join())
        .hasCauseInstanceOf(io.camunda.service.exception.ServiceException.class)
        .cause()
        .satisfies(
            ex -> {
              final var se = (io.camunda.service.exception.ServiceException) ex;
              Assertions.assertThat(se.getStatus())
                  .isEqualTo(io.camunda.service.exception.ServiceException.Status.UNAVAILABLE);
              Assertions.assertThat(se.getMessage())
                  .contains("Cluster topology is not yet available");
            });
  }

  /**
   * Topology stub which returns a static topology with 3 brokers, 1 partition, replication factor
   * 3, where 0 is the leader (healthy), 1 is the follower (healthy), and 2 is inactive (unhealthy).
   */
  private record TestBrokerClusterState(
      @Nullable String zone,
      String version,
      String clusterId,
      PartitionState.State leaderPartitionState)
      implements BrokerClusterState {

    TestBrokerClusterState(
        final @Nullable String zone, final String version, final String clusterId) {
      this(zone, version, clusterId, PartitionState.State.UNKNOWN);
    }

    @Override
    public boolean isInitialized() {
      return true;
    }

    @Override
    public int getClusterSize() {
      return 3;
    }

    @Override
    public int getPartitionsCount() {
      return 1;
    }

    @Override
    public int getReplicationFactor() {
      return 3;
    }

    @Override
    public BrokerMemberId getLeaderForPartition(final int partition) {
      return BrokerMemberId.from(zone, 0);
    }

    @Override
    public Set<BrokerMemberId> getFollowersForPartition(final int partition) {
      return Set.of(BrokerMemberId.from(zone, 1));
    }

    @Override
    public Set<BrokerMemberId> getInactiveNodesForPartition(final int partition) {
      return Set.of(BrokerMemberId.from(zone, 2));
    }

    @Override
    public BrokerMemberId getRandomBroker() {
      return BrokerMemberId.from(zone, ThreadLocalRandom.current().nextInt(0, 3));
    }

    @Override
    public List<Integer> getPartitions() {
      return List.of(1);
    }

    @Override
    public List<BrokerMemberId> getBrokers() {
      return Stream.of(0, 1, 2).map(id -> BrokerMemberId.from(zone, id)).toList();
    }

    @Override
    public String getBrokerAddress(final BrokerMemberId brokerId) {
      return "localhost:" + (26501 + brokerId.nodeIdx());
    }

    @Override
    public String getBrokerVersion(final BrokerMemberId brokerId) {
      return version;
    }

    @Override
    public PartitionHealthStatus getPartitionHealth(
        final BrokerMemberId brokerId, final int partition) {
      if (partition != 1) {
        return PartitionHealthStatus.NULL_VAL;
      }

      return switch (brokerId.nodeIdx()) {
        case 0, 1 -> PartitionHealthStatus.HEALTHY;
        case 2 -> PartitionHealthStatus.UNHEALTHY;
        default -> PartitionHealthStatus.NULL_VAL;
      };
    }

    @Override
    public PartitionState.State getPartitionState(
        final BrokerMemberId brokerId, final int partition) {
      if (partition == 1 && brokerId.nodeIdx() == 0) {
        return leaderPartitionState;
      }
      return PartitionState.State.UNKNOWN;
    }

    @Override
    public long getLastCompletedChangeId() {
      return 1;
    }

    @Override
    public String getClusterId() {
      return clusterId;
    }
  }
}
