/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.service;

import static io.camunda.search.exception.ErrorMessages.ERROR_ENTITY_BY_KEY_NOT_FOUND;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.instancio.Select.field;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import io.camunda.search.clients.ProcessInstanceSearchClient;
import io.camunda.search.clients.SequenceFlowSearchClient;
import io.camunda.search.clients.WaitStateSearchClient;
import io.camunda.search.entities.IncidentEntity;
import io.camunda.search.entities.ProcessInstanceEntity;
import io.camunda.search.entities.ProcessInstanceEntity.ProcessInstanceState;
import io.camunda.search.entities.SequenceFlowEntity;
import io.camunda.search.entities.WaitStateStatisticsEntity;
import io.camunda.search.exception.CamundaSearchException;
import io.camunda.search.exception.CamundaSearchException.Reason;
import io.camunda.search.exception.ResourceAccessDeniedException;
import io.camunda.search.filter.FilterBuilders;
import io.camunda.search.filter.Operation;
import io.camunda.search.filter.ProcessInstanceFilter;
import io.camunda.search.query.IncidentQuery;
import io.camunda.search.query.ProcessInstanceQuery;
import io.camunda.search.query.SearchQueryBuilders;
import io.camunda.search.query.SearchQueryResult;
import io.camunda.search.query.SequenceFlowQuery;
import io.camunda.security.api.model.CamundaAuthentication;
import io.camunda.security.auth.BrokerRequestAuthorizationConverter;
import io.camunda.security.core.auth.RequiredAuthorization;
import io.camunda.service.ProcessInstanceServices.AssignProcessInstanceBusinessIdRequest;
import io.camunda.service.ProcessInstanceServices.ProcessInstanceMigrateBatchOperationRequest;
import io.camunda.service.ProcessInstanceServices.ProcessInstanceModifyBatchOperationRequest;
import io.camunda.service.authorization.Authorizations;
import io.camunda.service.exception.ServiceException;
import io.camunda.service.exception.ServiceException.Status;
import io.camunda.service.security.SecurityContextProvider;
import io.camunda.zeebe.broker.client.api.BrokerClient;
import io.camunda.zeebe.broker.client.api.BrokerErrorException;
import io.camunda.zeebe.broker.client.api.dto.BrokerError;
import io.camunda.zeebe.broker.client.api.dto.BrokerResponse;
import io.camunda.zeebe.gateway.api.util.StubbedTopologyManager;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerAssignProcessInstanceBusinessIdRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerCreateBatchOperationRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerCreateProcessInstanceRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerCreateProcessInstanceWithResultRequest;
import io.camunda.zeebe.gateway.impl.broker.request.BrokerDeleteHistoryRequest;
import io.camunda.zeebe.protocol.impl.encoding.MsgPackConverter;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationCreationRecord;
import io.camunda.zeebe.protocol.impl.record.value.history.HistoryDeletionRecord;
import io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceBusinessIdRecord;
import io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceCreationRecord;
import io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceMigrationMappingInstruction;
import io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceModificationMoveInstruction;
import io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceResultRecord;
import io.camunda.zeebe.protocol.record.ErrorCode;
import io.camunda.zeebe.protocol.record.value.BatchOperationType;
import io.camunda.zeebe.protocol.record.value.HistoryDeletionType;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ForkJoinPool;
import java.util.stream.Stream;
import org.assertj.core.api.ThrowableAssert.ThrowingCallable;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Named;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;

public final class ProcessInstanceServiceTest {

  private static final String PHYSICAL_TENANT_ID = "test-tenant";
  private ProcessInstanceServices services;
  private ProcessInstanceSearchClient processInstanceSearchClient;
  private SequenceFlowSearchClient sequenceFlowSearchClient;
  private WaitStateSearchClient waitStateSearchClient;
  private IncidentServices incidentServices;
  private SecurityContextProvider securityContextProvider;
  private CamundaAuthentication authentication;
  private RequiredAuthorization<BatchOperationCreationRecord> authorizationCheck;
  private BrokerClient brokerClient;
  private ApiServicesExecutorProvider executorProvider;
  private BrokerRequestAuthorizationConverter brokerRequestAuthorizationConverter;

  @BeforeEach
  public void before() {
    processInstanceSearchClient = mock(ProcessInstanceSearchClient.class);
    sequenceFlowSearchClient = mock(SequenceFlowSearchClient.class);
    waitStateSearchClient = mock(WaitStateSearchClient.class);
    authentication = CamundaAuthentication.none();
    authorizationCheck =
        RequiredAuthorization.withRequiredAuthorization(
            RequiredAuthorization.of(a -> a.processDefinition().updateProcessInstance()),
            "myProcess");
    incidentServices = mock(IncidentServices.class);
    when(processInstanceSearchClient.withSecurityContext(any()))
        .thenReturn(processInstanceSearchClient);
    when(sequenceFlowSearchClient.withSecurityContext(any())).thenReturn(sequenceFlowSearchClient);
    when(waitStateSearchClient.withSecurityContext(any())).thenReturn(waitStateSearchClient);
    securityContextProvider = mock(SecurityContextProvider.class);
    brokerClient = mock(BrokerClient.class);
    when(brokerClient.getTopologyManager()).thenReturn(new StubbedTopologyManager(3));
    executorProvider = mock(ApiServicesExecutorProvider.class);
    when(executorProvider.getExecutor()).thenReturn(ForkJoinPool.commonPool());
    brokerRequestAuthorizationConverter = mock(BrokerRequestAuthorizationConverter.class);
    services =
        new ProcessInstanceServices(
            PHYSICAL_TENANT_ID,
            brokerClient,
            securityContextProvider,
            processInstanceSearchClient,
            sequenceFlowSearchClient,
            waitStateSearchClient,
            incidentServices,
            executorProvider,
            brokerRequestAuthorizationConverter);
  }

  @Test
  public void shouldReturnProcessInstance() {
    // given
    final var result = mock(SearchQueryResult.class);
    when(processInstanceSearchClient.searchProcessInstances(any())).thenReturn(result);

    final ProcessInstanceQuery searchQuery =
        SearchQueryBuilders.processInstanceSearchQuery().build();

    // when
    final SearchQueryResult<ProcessInstanceEntity> searchQueryResult =
        services.search(searchQuery, authentication);

    // then
    assertThat(searchQueryResult).isEqualTo(result);
  }

  @Test
  public void shouldReturnProcessInstanceSequenceFlows() {
    // given
    final SearchQueryResult<SequenceFlowEntity> result =
        SearchQueryResult.of(
            r ->
                r.items(
                    List.of(
                        new SequenceFlowEntity(
                            "pi1_sequenceFlow1", "node1", 1L, 37L, 1L, "pd1", "<default>"),
                        new SequenceFlowEntity(
                            "pi1_sequenceFlow2", "node1", 1L, 37L, 1L, "pd1", "<default>"))));
    when(sequenceFlowSearchClient.searchSequenceFlows(any())).thenReturn(result);

    // when
    final var actual = services.sequenceFlows(123L, authentication);

    // then
    verify(sequenceFlowSearchClient)
        .searchSequenceFlows(SequenceFlowQuery.of(q -> q.filter(f -> f.processInstanceKey(123L))));
    assertThat(actual).isEqualTo(result.items());
  }

  @Test
  public void shouldReturnProcessInstanceByKey() {
    // given
    final var key = 123L;
    final var entity =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), key)
            .create();
    when(processInstanceSearchClient.getProcessInstance(eq(123L))).thenReturn(entity);

    // when
    final var searchQueryResult = services.getByKey(key, authentication);

    // then
    assertThat(searchQueryResult.processInstanceKey()).isEqualTo(key);
  }

  @Test
  public void getByKeyShouldThrowForbiddenExceptionIfNotAuthorized() {
    // given
    final var entity = mock(ProcessInstanceEntity.class);
    when(entity.processDefinitionId()).thenReturn("processId");
    when(processInstanceSearchClient.getProcessInstance(any(Long.class)))
        .thenThrow(
            new ResourceAccessDeniedException(Authorizations.PROCESS_INSTANCE_READ_AUTHORIZATION));
    // when
    final ThrowingCallable executeGetByKey = () -> services.getByKey(1L, authentication);
    // then
    final var exception =
        (ServiceException)
            assertThatThrownBy(executeGetByKey).isInstanceOf(ServiceException.class).actual();
    assertThat(exception.getMessage())
        .isEqualTo(
            "Unauthorized to perform operation 'READ_PROCESS_INSTANCE' on resource 'PROCESS_DEFINITION'");
    assertThat(exception.getStatus()).isEqualTo(Status.FORBIDDEN);
  }

  @Test
  void shouldDelegateWaitStateStatisticsToWaitStateClient() {
    // given
    final var processInstanceKey = 42L;
    final var entity =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), processInstanceKey)
            .create();
    when(processInstanceSearchClient.getProcessInstance(processInstanceKey)).thenReturn(entity);
    when(waitStateSearchClient.waitStateStatistics(processInstanceKey))
        .thenReturn(List.of(new WaitStateStatisticsEntity("task-a", 3L)));

    // when
    final var result = services.waitStateStatistics(processInstanceKey, authentication);

    // then
    assertThat(result).containsExactly(new WaitStateStatisticsEntity("task-a", 3L));
    verify(waitStateSearchClient).waitStateStatistics(processInstanceKey);
  }

  @Test
  void shouldThrowNotFoundForUnknownProcessInstanceOnWaitStateStatistics() {
    // given
    final var processInstanceKey = 99L;
    when(processInstanceSearchClient.getProcessInstance(processInstanceKey))
        .thenThrow(
            new CamundaSearchException(
                ERROR_ENTITY_BY_KEY_NOT_FOUND.formatted("Process Instance", processInstanceKey),
                Reason.NOT_FOUND));

    // when
    final ThrowingCallable executeWaitStateStatistics =
        () -> services.waitStateStatistics(processInstanceKey, authentication);

    // then
    final var exception =
        (ServiceException)
            assertThatThrownBy(executeWaitStateStatistics)
                .isInstanceOf(ServiceException.class)
                .actual();
    assertThat(exception.getStatus()).isEqualTo(Status.NOT_FOUND);
    verify(waitStateSearchClient, never()).waitStateStatistics(anyLong());
  }

  @Test
  void shouldCancelProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.CANCEL_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result =
        services.cancelProcessInstanceBatchOperationWithResult(filter, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.CANCEL_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);
  }

  @Test
  void shouldSuspendProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.SUSPEND_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result =
        services.suspendProcessInstanceBatchOperationWithResult(filter, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.SUSPEND_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);
  }

  @Test
  void shouldResumeProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 456L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.RESUME_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result =
        services.resumeProcessInstanceBatchOperationWithResult(filter, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.RESUME_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);
  }

  @Test
  void shouldResolveProcessInstanceIncidentsWithResult() {
    // given
    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.RESOLVE_INCIDENT);

    final var entity = mock(ProcessInstanceEntity.class);
    when(entity.processDefinitionId()).thenReturn("myProcess");
    when(processInstanceSearchClient.getProcessInstance(any(Long.class))).thenReturn(entity);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result = services.resolveProcessInstanceIncidents(345L, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType()).isEqualTo(BatchOperationType.RESOLVE_INCIDENT);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthorizationCheckBuffer(), RequiredAuthorization.class))
        .isEqualTo(authorizationCheck);
  }

  @Test
  public void shouldReturnOrderedProcessHierarchy() {
    // given
    final var childProcess =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), 789L)
            .set(field(ProcessInstanceEntity::treePath), "PI_123/FN_A/FNI_456/PI_789/FN_B/FNI_654")
            .create();

    final var parentProcess =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), 123L)
            .create();

    when(processInstanceSearchClient.getProcessInstance(eq(789L))).thenReturn(childProcess);
    when(processInstanceSearchClient.searchProcessInstances(any()))
        .thenReturn(
            new SearchQueryResult<>(1, false, List.of(childProcess, parentProcess), null, null));

    // when
    final var result = services.callHierarchy(childProcess.processInstanceKey(), authentication);

    // then
    assertThat(result).hasSize(2);
    assertThat(result.get(0).processInstanceKey()).isEqualTo(123L); // Parent comes first
    assertThat(result.get(1).processInstanceKey()).isEqualTo(789L); // Child comes next
  }

  @Test
  public void shouldReturnEmptyListForBlankTreePath() {
    // given
    final var rootInstance =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), 123L)
            .set(field(ProcessInstanceEntity::treePath), null)
            .create();

    when(processInstanceSearchClient.getProcessInstance(eq(123L))).thenReturn(rootInstance);

    // when
    final var result = services.callHierarchy(123L, authentication);

    // then
    assertThat(result).isEmpty(); // No hierarchy should return an empty list
  }

  @Test
  public void shouldReturnEmptyListForRootTreePath() {
    // given
    final var rootInstance =
        Instancio.of(ProcessInstanceEntity.class)
            .set(field(ProcessInstanceEntity::processInstanceKey), 123L)
            .set(field(ProcessInstanceEntity::treePath), "PI_123")
            .create();

    when(processInstanceSearchClient.getProcessInstance(eq(123L))).thenReturn(rootInstance);

    // when
    final var result = services.callHierarchy(123L, authentication);

    // then
    assertThat(result).isEmpty(); // No hierarchy should return an empty list
  }

  @Test
  void shouldResolveIncidentBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.RESOLVE_INCIDENT);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result =
        services.resolveIncidentsBatchOperationWithResult(filter, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType()).isEqualTo(BatchOperationType.RESOLVE_INCIDENT);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);
  }

  @Test
  void shouldMigrateProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.MIGRATE_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    final var request =
        new ProcessInstanceMigrateBatchOperationRequest(
            filter,
            42L,
            List.of(
                new ProcessInstanceMigrationMappingInstruction()
                    .setSourceElementId("source1")
                    .setTargetElementId("target1")));

    // when
    final var result =
        services.migrateProcessInstancesBatchOperation(request, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.MIGRATE_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);

    final var modificationPlan = enrichedRecord.getMigrationPlan();
    assertThat(modificationPlan.getTargetProcessDefinitionKey()).isEqualTo(42L);
    assertThat(modificationPlan.getMappingInstructions().getFirst().getSourceElementId())
        .isEqualTo("source1");
    assertThat(modificationPlan.getMappingInstructions().getFirst().getTargetElementId())
        .isEqualTo("target1");
  }

  @Test
  void shouldModifyProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.MODIFY_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    final var request =
        new ProcessInstanceModifyBatchOperationRequest(
            filter,
            List.of(
                new ProcessInstanceModificationMoveInstruction()
                    .setSourceElementId("source1")
                    .setTargetElementId("target1")));

    // when
    final var result =
        services.modifyProcessInstancesBatchOperation(request, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.MODIFY_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);

    final var filterBuffer = enrichedRecord.getEntityFilterBuffer();
    final var enhancedFilter =
        MsgPackConverter.convertToObject(filterBuffer, ProcessInstanceFilter.class);
    assertThat(enhancedFilter.stateOperations())
        .containsExactly(Operation.eq(ProcessInstanceState.ACTIVE.name()));

    final var modificationPlan = captor.getValue().getRequestWriter().getModificationPlan();
    assertThat(modificationPlan.getMoveInstructions()).hasSize(1);
    assertThat(modificationPlan.getMoveInstructions().getFirst().getSourceElementId())
        .isEqualTo("source1");
    assertThat(modificationPlan.getMoveInstructions().getFirst().getTargetElementId())
        .isEqualTo("target1");
  }

  @Test
  void shouldReturnIncidentsForProcessInstanceKey() {
    // given
    final var processInstanceKey = 123L;
    final var query = SearchQueryBuilders.incidentSearchQuery().build();
    final SearchQueryResult<IncidentEntity> queryResult = mock(SearchQueryResult.class);

    final var processInstance = mock(ProcessInstanceEntity.class);
    when(processInstance.treePath()).thenReturn("PI_123/FN_A/FNI_456/PI_789/FN_B/FNI_654");
    when(processInstance.processInstanceKey()).thenReturn(processInstanceKey);
    when(processInstance.processDefinitionId()).thenReturn("processId");
    when(processInstanceSearchClient.getProcessInstance(eq(processInstanceKey)))
        .thenReturn(processInstance);

    when(incidentServices.search(any(IncidentQuery.class), any())).thenReturn(queryResult);

    // when
    final var result = services.searchIncidents(processInstanceKey, query, authentication);

    // then
    assertThat(result).isEqualTo(queryResult);

    final var incidentQueryCaptor = ArgumentCaptor.forClass(IncidentQuery.class);
    verify(incidentServices).search(incidentQueryCaptor.capture(), any());
    final var incidentQuery = incidentQueryCaptor.getValue();
    assertThat(incidentQuery.filter().treePathOperations())
        .containsExactly(Operation.like(processInstance.treePath() + "*"));
    assertThat(incidentQuery.page()).isEqualTo(query.page());
    assertThat(incidentQuery.sort()).isEqualTo(query.sort());
  }

  @Test
  void incidentsShouldThrowForbiddenExceptionIfNotAuthorizedToReadProcessInstance() {
    // given
    final var processInstanceKey = 123L;

    final var processInstance = mock(ProcessInstanceEntity.class);
    when(processInstance.processDefinitionId()).thenReturn("processId");
    when(processInstanceSearchClient.getProcessInstance(eq(processInstanceKey)))
        .thenThrow(
            new ResourceAccessDeniedException(
                RequiredAuthorization.of(a -> a.processDefinition().readProcessInstance())));

    final var query = new IncidentQuery.Builder().build();

    // when
    final ThrowingCallable executeGetByKey =
        () -> services.searchIncidents(processInstanceKey, query, authentication);

    // then
    final var exception =
        (ServiceException)
            assertThatThrownBy(executeGetByKey).isInstanceOf(ServiceException.class).actual();
    assertThat(exception.getMessage())
        .isEqualTo(
            "Unauthorized to perform operation 'READ_PROCESS_INSTANCE' on resource 'PROCESS_DEFINITION'");
    assertThat(exception.getStatus()).isEqualTo(Status.FORBIDDEN);
    verifyNoInteractions(incidentServices);
  }

  @Test
  void shouldDeleteProcessInstanceBatchOperationWithResult() {
    // given
    final var filter =
        FilterBuilders.processInstance(b -> b.processDefinitionIds("test-process-definition-id"));

    final long batchOperationKey = 123L;
    final var record = new BatchOperationCreationRecord();
    record.setBatchOperationKey(batchOperationKey);
    record.setBatchOperationType(BatchOperationType.DELETE_PROCESS_INSTANCE);

    final var captor = ArgumentCaptor.forClass(BrokerCreateBatchOperationRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    final var result = services.deleteProcessInstancesBatchOperation(filter, authentication).join();

    // then
    assertThat(result.getBatchOperationKey()).isEqualTo(batchOperationKey);
    assertThat(result.getBatchOperationType())
        .isEqualTo(BatchOperationType.DELETE_PROCESS_INSTANCE);

    // and our request got enriched
    final var enrichedRecord = captor.getValue().getRequestWriter();

    assertThat(
            MsgPackConverter.convertToObject(
                enrichedRecord.getAuthenticationBuffer(), CamundaAuthentication.class))
        .isEqualTo(authentication);
  }

  @Test
  void shouldDeleteProcessInstanceWithResult() {
    // given
    final long processInstanceKey = 123L;
    final var processId = "processId";
    final var tenantId = "tenantId";

    final var entity = mock(ProcessInstanceEntity.class);
    when(entity.processInstanceKey()).thenReturn(processInstanceKey);
    when(entity.processDefinitionId()).thenReturn(processId);
    when(entity.tenantId()).thenReturn(tenantId);
    when(processInstanceSearchClient.getProcessInstance(eq(processInstanceKey))).thenReturn(entity);

    final var record =
        new HistoryDeletionRecord()
            .setResourceKey(processInstanceKey)
            .setResourceType(HistoryDeletionType.PROCESS_INSTANCE)
            .setProcessId(processId)
            .setTenantId(tenantId);
    final var captor = ArgumentCaptor.forClass(BrokerDeleteHistoryRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    services.deleteProcessInstance(processInstanceKey, null, authentication).join();

    // then
    assertThat(captor.getValue().getPartitionGroup()).isEqualTo(PHYSICAL_TENANT_ID);
    final var brokerRequest = (HistoryDeletionRecord) captor.getValue().getRequestWriter();
    assertThat(brokerRequest.getResourceKey()).isEqualTo(processInstanceKey);
    assertThat(brokerRequest.getResourceType()).isEqualTo(HistoryDeletionType.PROCESS_INSTANCE);
    assertThat(brokerRequest.getProcessId()).isEqualTo(processId);
    assertThat(brokerRequest.getTenantId()).isEqualTo(tenantId);
  }

  @Test
  void shouldNotDeleteProcessInstanceWithResult() {
    // given
    final long processInstanceKey = 123L;

    when(processInstanceSearchClient.getProcessInstance(eq(processInstanceKey)))
        .thenThrow(
            new CamundaSearchException(
                ERROR_ENTITY_BY_KEY_NOT_FOUND.formatted("Process Instance", processInstanceKey),
                Reason.NOT_FOUND));

    // when/then
    assertThatThrownBy(
            () -> services.deleteProcessInstance(processInstanceKey, null, authentication).join())
        .isInstanceOf(ServiceException.class)
        .hasMessage("Process Instance with key '123' not found");
  }

  @Test
  void shouldAssignProcessInstanceBusinessId() {
    // given
    final long processInstanceKey = 123L;
    final var businessId = "order-12345";

    final var record =
        new ProcessInstanceBusinessIdRecord()
            .setProcessInstanceKey(processInstanceKey)
            .setBusinessId(businessId);
    final var captor = ArgumentCaptor.forClass(BrokerAssignProcessInstanceBusinessIdRequest.class);
    when(brokerClient.sendRequest(captor.capture()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(record)));

    // when
    services
        .assignProcessInstanceBusinessId(
            new AssignProcessInstanceBusinessIdRequest(processInstanceKey, businessId),
            authentication)
        .join();

    // then
    final var brokerRequest = captor.getValue();
    final var enrichedRecord = brokerRequest.getRequestWriter();
    assertThat(enrichedRecord.getProcessInstanceKey()).isEqualTo(processInstanceKey);
    assertThat(enrichedRecord.getBusinessId()).isEqualTo(businessId);
  }

  @Test
  void shouldCreateProcessInstanceWithResultUsingCustomRequestTimeout() {
    // given
    final var request =
        new ProcessInstanceServices.ProcessInstanceCreateRequest(
            123L, // processDefinitionKey
            "", // bpmnProcessId
            -1, // version
            null, // variables
            "<default>", // tenantId
            true, // awaitCompletion
            600000L, // requestTimeout (10 minutes)
            null, // operationReference
            List.of(), // startInstructions
            List.of(), // runtimeInstructions
            List.of(), // fetchVariables
            null, // tags
            null // businessId
            );

    final var mockResponse =
        new io.camunda.zeebe.protocol.impl.record.value.processinstance
            .ProcessInstanceResultRecord();
    when(brokerClient.sendRequest(any(), any(java.time.Duration.class)))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse)));

    // when
    services.createProcessInstanceWithResult(request, authentication).join();

    // then
    verify(brokerClient)
        .sendRequest(
            any(
                io.camunda.zeebe.gateway.impl.broker.request
                    .BrokerCreateProcessInstanceWithResultRequest.class),
            eq(java.time.Duration.ofMillis(600000L)));
  }

  @Test
  void shouldCreateProcessInstanceWithResultUsingDefaultTimeoutWhenNotProvided() {
    // given
    final var request =
        new ProcessInstanceServices.ProcessInstanceCreateRequest(
            123L, // processDefinitionKey
            "", // bpmnProcessId
            -1, // version
            null, // variables
            "<default>", // tenantId
            true, // awaitCompletion
            null, // requestTimeout (not provided)
            null, // operationReference
            List.of(), // startInstructions
            List.of(), // runtimeInstructions
            List.of(), // fetchVariables
            null, // tags
            null // businessId
            );

    final var mockResponse =
        new io.camunda.zeebe.protocol.impl.record.value.processinstance
            .ProcessInstanceResultRecord();
    when(brokerClient.sendRequest(any()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse)));

    // when
    services.createProcessInstanceWithResult(request, authentication).join();

    // then
    verify(brokerClient)
        .sendRequest(
            any(
                io.camunda.zeebe.gateway.impl.broker.request
                    .BrokerCreateProcessInstanceWithResultRequest.class));
    verify(brokerClient, org.mockito.Mockito.never())
        .sendRequest(any(), any(java.time.Duration.class));
  }

  @Test
  void shouldCreateProcessInstanceWithResultUsingDefaultTimeoutWhenRequestTimeoutIsZero() {
    // given
    final var request =
        new ProcessInstanceServices.ProcessInstanceCreateRequest(
            123L, // processDefinitionKey
            "", // bpmnProcessId
            -1, // version
            null, // variables
            "<default>", // tenantId
            true, // awaitCompletion
            0L, // requestTimeout explicitly set to zero
            null, // operationReference
            List.of(), // startInstructions
            List.of(), // runtimeInstructions
            List.of(), // fetchVariables
            null, // tags
            null // businessId
            );

    final var mockResponse =
        new io.camunda.zeebe.protocol.impl.record.value.processinstance
            .ProcessInstanceResultRecord();
    when(brokerClient.sendRequest(any()))
        .thenReturn(CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse)));

    // when
    services.createProcessInstanceWithResult(request, authentication).join();

    // then
    verify(brokerClient)
        .sendRequest(
            any(
                io.camunda.zeebe.gateway.impl.broker.request
                    .BrokerCreateProcessInstanceWithResultRequest.class));
    verify(brokerClient, org.mockito.Mockito.never())
        .sendRequest(any(), any(java.time.Duration.class));
  }

  @Nested
  @DisplayName("Retry on different partitions")
  class RetryPartitionsTest {

    private static Stream<Named<Throwable>> retryableErrors() {
      return Stream.of(
          Named.of(
              "PARTITION_LEADER_MISMATCH",
              new BrokerErrorException(
                  new BrokerError(ErrorCode.PARTITION_LEADER_MISMATCH, "leader mismatch"))),
          Named.of(
              "RESOURCE_EXHAUSTED",
              new BrokerErrorException(
                  new BrokerError(ErrorCode.RESOURCE_EXHAUSTED, "resource exhausted"))),
          Named.of("ConnectException", new ConnectException("connection refused")));
    }

    @ParameterizedTest
    @MethodSource("retryableErrors")
    void shouldRetryCreateProcessInstanceOnRetryableError(final Throwable retryableError) {
      // given
      final var request = createProcessInstanceRequest(null);
      final var mockResponse = new ProcessInstanceCreationRecord();
      final var triedPartitions = new ArrayList<Integer>();
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceRequest.class)))
          .thenAnswer(
              invocation -> {
                final var brokerRequest =
                    invocation.getArgument(0, BrokerCreateProcessInstanceRequest.class);
                triedPartitions.add(brokerRequest.getPartitionId());
                if (triedPartitions.size() == 1) {
                  return CompletableFuture.failedFuture(retryableError);
                }
                return CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse));
              });

      // when
      final var result = services.createProcessInstance(request, authentication).join();

      // then - retried on a different partition and succeeded
      assertThat(result).isNotNull();
      assertThat(triedPartitions).hasSize(2);
      assertThat(triedPartitions.get(0)).isNotEqualTo(triedPartitions.get(1));
    }

    @ParameterizedTest
    @MethodSource("retryableErrors")
    void shouldRetryCreateProcessInstanceWithResultOnRetryableError(
        final Throwable retryableError) {
      // given
      final var request = createProcessInstanceWithResultRequest(null, null);
      final var mockResponse = new ProcessInstanceResultRecord();
      final var triedPartitions = new ArrayList<Integer>();
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceWithResultRequest.class)))
          .thenAnswer(
              invocation -> {
                final var brokerRequest =
                    invocation.getArgument(0, BrokerCreateProcessInstanceWithResultRequest.class);
                triedPartitions.add(brokerRequest.getPartitionId());
                if (triedPartitions.size() == 1) {
                  return CompletableFuture.failedFuture(retryableError);
                }
                return CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse));
              });

      // when
      final var result = services.createProcessInstanceWithResult(request, authentication).join();

      // then
      assertThat(result).isNotNull();
      assertThat(triedPartitions).hasSize(2);
      assertThat(triedPartitions.get(0)).isNotEqualTo(triedPartitions.get(1));
    }

    @Test
    void shouldExhaustRetriesForCreateProcessInstanceWhenAllPartitionsFail() {
      // given - topology has 3 partitions, all fail with retryable errors
      final var request = createProcessInstanceRequest(null);
      final var triedPartitions = new ArrayList<Integer>();
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceRequest.class)))
          .thenAnswer(
              invocation -> {
                final var brokerRequest =
                    invocation.getArgument(0, BrokerCreateProcessInstanceRequest.class);
                triedPartitions.add(brokerRequest.getPartitionId());
                return CompletableFuture.failedFuture(
                    new BrokerErrorException(
                        new BrokerError(ErrorCode.PARTITION_LEADER_MISMATCH, "leader mismatch")));
              });

      // when / then - all 3 partitions tried with distinct IDs, then RESOURCE_EXHAUSTED error
      assertThatThrownBy(() -> services.createProcessInstance(request, authentication).join())
          .isInstanceOf(CompletionException.class)
          .hasCauseInstanceOf(ServiceException.class)
          .extracting(Throwable::getCause)
          .satisfies(
              cause -> {
                final var serviceException = (ServiceException) cause;
                assertThat(serviceException.getStatus()).isEqualTo(Status.RESOURCE_EXHAUSTED);
              });
      assertThat(triedPartitions).hasSize(3);
      assertThat(triedPartitions).doesNotHaveDuplicates();
    }

    @Test
    void shouldExhaustRetriesForCreateProcessInstanceWithResultWhenAllPartitionsFail() {
      // given
      final var request = createProcessInstanceWithResultRequest(null, null);
      final var triedPartitions = new ArrayList<Integer>();
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceWithResultRequest.class)))
          .thenAnswer(
              invocation -> {
                final var brokerRequest =
                    invocation.getArgument(0, BrokerCreateProcessInstanceWithResultRequest.class);
                triedPartitions.add(brokerRequest.getPartitionId());
                return CompletableFuture.failedFuture(
                    new BrokerErrorException(
                        new BrokerError(ErrorCode.RESOURCE_EXHAUSTED, "resource exhausted")));
              });

      // when / then
      assertThatThrownBy(
              () -> services.createProcessInstanceWithResult(request, authentication).join())
          .isInstanceOf(CompletionException.class)
          .hasCauseInstanceOf(ServiceException.class)
          .extracting(Throwable::getCause)
          .satisfies(
              cause -> {
                final var serviceException = (ServiceException) cause;
                assertThat(serviceException.getStatus()).isEqualTo(Status.RESOURCE_EXHAUSTED);
              });
      assertThat(triedPartitions).hasSize(3);
      assertThat(triedPartitions).doesNotHaveDuplicates();
    }

    @Test
    void shouldNotRetryCreateProcessInstanceOnNonRetryableError() {
      // given - a non-retryable error like PROCESS_NOT_FOUND
      final var request = createProcessInstanceRequest(null);
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceRequest.class)))
          .thenReturn(
              CompletableFuture.failedFuture(
                  new BrokerErrorException(
                      new BrokerError(ErrorCode.PROCESS_NOT_FOUND, "process not found"))));

      // when / then - only tried once, no retry
      assertThatThrownBy(() -> services.createProcessInstance(request, authentication).join())
          .isInstanceOf(CompletionException.class)
          .hasCauseInstanceOf(ServiceException.class);
      verify(brokerClient, times(1)).sendRequest(any(BrokerCreateProcessInstanceRequest.class));
    }

    @Test
    void shouldNotRetryCreateProcessInstanceWhenBusinessIdIsSet() {
      // given - businessId is set, so a fixed dispatch strategy is used (no retry across
      // partitions)
      final var request = createProcessInstanceRequest("my-business-id");
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceRequest.class)))
          .thenReturn(CompletableFuture.failedFuture(new ConnectException("connection refused")));

      // when / then - only one attempt, error propagated directly without retrying other
      // partitions
      assertThatThrownBy(() -> services.createProcessInstance(request, authentication).join())
          .isInstanceOf(CompletionException.class)
          .hasCauseInstanceOf(ServiceException.class);
      verify(brokerClient, times(1)).sendRequest(any(BrokerCreateProcessInstanceRequest.class));
    }

    @Test
    void shouldRetryCreateProcessInstanceWithResultUsingCustomTimeout() {
      // given
      final var request = createProcessInstanceWithResultRequest(600_000L, null);
      final var mockResponse = new ProcessInstanceResultRecord();
      final var triedPartitions = new ArrayList<Integer>();
      when(brokerClient.sendRequest(
              any(BrokerCreateProcessInstanceWithResultRequest.class),
              eq(java.time.Duration.ofMillis(600_000L))))
          .thenAnswer(
              invocation -> {
                final var brokerRequest =
                    invocation.getArgument(0, BrokerCreateProcessInstanceWithResultRequest.class);
                triedPartitions.add(brokerRequest.getPartitionId());
                if (triedPartitions.size() == 1) {
                  return CompletableFuture.failedFuture(
                      new BrokerErrorException(
                          new BrokerError(ErrorCode.PARTITION_LEADER_MISMATCH, "leader mismatch")));
                }
                return CompletableFuture.completedFuture(new BrokerResponse<>(mockResponse));
              });

      // when
      final var result = services.createProcessInstanceWithResult(request, authentication).join();

      // then
      assertThat(result).isNotNull();
      assertThat(triedPartitions).hasSize(2);
      assertThat(triedPartitions.get(0)).isNotEqualTo(triedPartitions.get(1));
      verify(brokerClient, times(2))
          .sendRequest(
              any(BrokerCreateProcessInstanceWithResultRequest.class),
              eq(java.time.Duration.ofMillis(600_000L)));
    }

    @Test
    void shouldNotRetryCreateProcessInstanceWithResultWhenBusinessIdIsSet() {
      // given - businessId is set, so a fixed dispatch strategy is used
      final var request = createProcessInstanceWithResultRequest(null, "my-business-id");
      when(brokerClient.sendRequest(any(BrokerCreateProcessInstanceWithResultRequest.class)))
          .thenReturn(CompletableFuture.failedFuture(new ConnectException("connection refused")));

      // when / then - only one attempt
      assertThatThrownBy(
              () -> services.createProcessInstanceWithResult(request, authentication).join())
          .isInstanceOf(CompletionException.class)
          .hasCauseInstanceOf(ServiceException.class);
      verify(brokerClient, times(1))
          .sendRequest(any(BrokerCreateProcessInstanceWithResultRequest.class));
    }

    private ProcessInstanceServices.ProcessInstanceCreateRequest createProcessInstanceRequest(
        final String businessId) {
      return new ProcessInstanceServices.ProcessInstanceCreateRequest(
          123L, // processDefinitionKey
          "test-process", // bpmnProcessId
          -1, // version
          null, // variables
          "<default>", // tenantId
          false, // awaitCompletion
          null, // requestTimeout
          null, // operationReference
          List.of(), // startInstructions
          List.of(), // runtimeInstructions
          List.of(), // fetchVariables
          null, // tags
          businessId // businessId
          );
    }

    private ProcessInstanceServices.ProcessInstanceCreateRequest
        createProcessInstanceWithResultRequest(final Long requestTimeout, final String businessId) {
      return new ProcessInstanceServices.ProcessInstanceCreateRequest(
          123L, // processDefinitionKey
          "test-process", // bpmnProcessId
          -1, // version
          null, // variables
          "<default>", // tenantId
          true, // awaitCompletion
          requestTimeout, // requestTimeout
          null, // operationReference
          List.of(), // startInstructions
          List.of(), // runtimeInstructions
          List.of(), // fetchVariables
          null, // tags
          businessId // businessId
          );
    }
  }
}
