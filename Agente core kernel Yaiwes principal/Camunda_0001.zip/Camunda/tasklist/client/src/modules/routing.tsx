/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {useParams} from 'react-router-dom';
import {getClientConfig} from 'modules/config/getClientConfig';

/* istanbul ignore file */

const pages = {
  initial: '/',
  login: '/login',
  forbidden: '/forbidden',
  taskDetails(id: string = ':id') {
    return `/${id}`;
  },
  taskDetailsProcess(id: string = ':id') {
    return `/${id}/process`;
  },
  taskDetailsHistory(id: string = ':id') {
    return `/${id}/history`;
  },
  taskDetailsHistoryAuditLog(
    id: string = ':id',
    auditLogKey: string = ':auditLogKey',
  ) {
    return `/${id}/history/${auditLogKey}`;
  },
  processes(
    options: {tenantId?: string; matchAllChildren?: boolean} = {
      matchAllChildren: false,
    },
  ) {
    const {tenantId, matchAllChildren: matchAllChildren = false} = options;
    const baseRoute = matchAllChildren ? 'processes/*' : 'processes';
    if (tenantId !== undefined && getClientConfig().isMultiTenancyEnabled) {
      return `${baseRoute}?tenantId=${tenantId}`;
    }

    return baseRoute;
  },
  internalStartProcessFromForm(
    processDefinitionKey: string = ':processDefinitionKey',
  ) {
    return `/processes/${processDefinitionKey}/start`;
  },
} as const;

function useTaskDetailsParams(): {id: string} {
  const {id} = useParams<'id'>();

  return {id: id ?? ''};
}

function useHistoryItemDetailsParams(): {id: string; auditLogKey: string} {
  const {id, auditLogKey} = useParams<'id' | 'auditLogKey'>();

  return {id: id ?? '', auditLogKey: auditLogKey ?? ''};
}

export {pages, useTaskDetailsParams, useHistoryItemDetailsParams};
