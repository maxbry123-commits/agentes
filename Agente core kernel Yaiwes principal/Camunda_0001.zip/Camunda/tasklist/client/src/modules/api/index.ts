/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {
  endpoints,
  type CompleteTaskRequestBody,
  type QueryUserTasksRequestBody,
  type UserTask,
  type QueryVariablesByUserTaskRequestBody,
  type QueryProcessDefinitionsRequestBody,
  type ProcessDefinition,
  type CreateProcessInstanceRequestBody,
  type QueryUserTaskAuditLogsRequestBody,
} from '@camunda/camunda-api-zod-schemas/8.10';
import {buildDocumentMultipart} from 'modules/document-handling/buildDocumentMultipart';
import {mergePathname} from './mergePathname';
import {getClientConfig} from 'modules/config/getClientConfig';

const BASE_REQUEST_OPTIONS: RequestInit = {
  credentials: 'include',
  mode: 'cors',
};
function getFullURL(url: string) {
  if (typeof window.location.origin !== 'string') {
    throw new Error('window.location.origin is not a set');
  }

  return new URL(
    mergePathname(getClientConfig().contextPath, url),
    window.location.origin,
  );
}
const api = {
  login: (body: {username: string; password: string}) => {
    return new Request(getFullURL('/login'), {
      ...BASE_REQUEST_OPTIONS,
      method: 'POST',
      body: new URLSearchParams(body).toString(),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
  },
  logout: () =>
    new Request(getFullURL('/logout'), {
      ...BASE_REQUEST_OPTIONS,
      method: 'POST',
    }),
  sessionHeartbeatUrl: () => getFullURL('/session/heartbeat').toString(),
  getCurrentUser: () =>
    new Request(getFullURL(endpoints.getCurrentUser.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getCurrentUser.method,
      headers: {
        'Content-Type': 'application/json',
      },
    }),
  getLicense: () => {
    return new Request(getFullURL(endpoints.getLicense.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getLicense.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  uploadDocuments: ({files}: {files: Map<string, File[]>}) => {
    const {body, headers} = buildDocumentMultipart(files);

    return new Request(getFullURL(endpoints.createDocuments.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.createDocuments.method,
      body,
      headers,
    });
  },
  getDocument: (documentId: string) => {
    return new Request(getFullURL(endpoints.getDocument.getUrl({documentId})), {
      method: endpoints.getDocument.method,
      ...BASE_REQUEST_OPTIONS,
    });
  },
  queryTasks: (body: QueryUserTasksRequestBody = {}) => {
    return new Request(getFullURL(endpoints.queryUserTasks.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.queryUserTasks.method,
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
        'x-is-polling': 'true',
      },
    });
  },
  queryProcesses: (body: QueryProcessDefinitionsRequestBody = {}) => {
    return new Request(getFullURL(endpoints.queryProcessDefinitions.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.queryProcessDefinitions.method,
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  getProcessDefinitionXml: (
    body: Pick<ProcessDefinition, 'processDefinitionKey'>,
  ) => {
    return new Request(
      getFullURL(endpoints.getProcessDefinitionXml.getUrl(body)),
      {
        ...BASE_REQUEST_OPTIONS,
        method: endpoints.getProcessDefinitionXml.method,
      },
    );
  },
  getTask: (body: Pick<UserTask, 'userTaskKey'>) => {
    return new Request(getFullURL(endpoints.getTask.getUrl(body)), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getTask.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  assignTask: (
    params: Pick<UserTask, 'userTaskKey'> & {
      assignee: string;
      allowOverride: boolean;
    },
  ) => {
    const {userTaskKey, ...body} = params;
    return new Request(getFullURL(endpoints.assignTask.getUrl({userTaskKey})), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.assignTask.method,
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  unassignTask: (body: Pick<UserTask, 'userTaskKey'>) => {
    return new Request(getFullURL(endpoints.unassignTask.getUrl(body)), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.unassignTask.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  queryVariablesByUserTask: (
    params: Pick<UserTask, 'userTaskKey'> &
      QueryVariablesByUserTaskRequestBody & {truncateValues?: boolean},
  ) => {
    const {userTaskKey, truncateValues, ...body} = params;

    return new Request(
      getFullURL(
        endpoints.queryVariablesByUserTask.getUrl({
          userTaskKey,
          truncateValues,
        }),
      ),
      {
        ...BASE_REQUEST_OPTIONS,
        method: endpoints.queryVariablesByUserTask.method,
        body: JSON.stringify(body),
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
  },
  completeTask: (
    params: Pick<UserTask, 'userTaskKey'> & CompleteTaskRequestBody,
  ) => {
    const {userTaskKey, variables, ...body} = params;

    return new Request(
      getFullURL(endpoints.completeTask.getUrl({userTaskKey})),
      {
        ...BASE_REQUEST_OPTIONS,
        method: endpoints.completeTask.method,
        body: JSON.stringify({...body, variables}),
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
  },
  getVariable: (variableKey: string) => {
    return new Request(
      getFullURL(endpoints.getVariable.getUrl({variableKey})),
      {
        ...BASE_REQUEST_OPTIONS,
        method: endpoints.getVariable.method,
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
  },
  getUserTaskForm: (params: Pick<UserTask, 'userTaskKey'>) => {
    return new Request(getFullURL(endpoints.getUserTaskForm.getUrl(params)), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getUserTaskForm.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  createProcessInstance: (params: CreateProcessInstanceRequestBody) => {
    return new Request(getFullURL(endpoints.createProcessInstance.getUrl()), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.createProcessInstance.method,
      body: JSON.stringify(params),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  getSaasUserToken: () => {
    return new Request(getFullURL('/v2/authentication/me/token'), {
      ...BASE_REQUEST_OPTIONS,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  getProcessStartForm: (
    body: Pick<ProcessDefinition, 'processDefinitionKey'>,
  ) => {
    return new Request(getFullURL(endpoints.getProcessStartForm.getUrl(body)), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getProcessStartForm.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  queryUserTaskAuditLogs: (
    params: {userTaskKey: string} & QueryUserTaskAuditLogsRequestBody,
  ) => {
    const {userTaskKey, ...body} = params;
    return new Request(
      getFullURL(endpoints.queryUserTaskAuditLogs.getUrl({userTaskKey})),
      {
        ...BASE_REQUEST_OPTIONS,
        method: endpoints.queryUserTaskAuditLogs.method,
        body: JSON.stringify(body),
        headers: {
          'Content-Type': 'application/json',
        },
      },
    );
  },
  getAuditLog: (params: {auditLogKey: string}) => {
    return new Request(getFullURL(endpoints.getAuditLog.getUrl(params)), {
      ...BASE_REQUEST_OPTIONS,
      method: endpoints.getAuditLog.method,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
} as const;

export {api};
