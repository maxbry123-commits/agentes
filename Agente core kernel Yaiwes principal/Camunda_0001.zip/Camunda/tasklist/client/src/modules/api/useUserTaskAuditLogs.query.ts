/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {infiniteQueryOptions} from '@tanstack/react-query';
import {api} from 'modules/api';
import {request} from 'modules/api/request';
import {
  type QueryUserTaskAuditLogsResponseBody,
  auditLogSortFieldEnum,
} from '@camunda/camunda-api-zod-schemas/8.10';

const MAX_AUDIT_LOGS_PER_REQUEST = 50;

const AUDIT_LOG_SORT_FIELDS = auditLogSortFieldEnum.options;
type AuditLogSortField = (typeof AUDIT_LOG_SORT_FIELDS)[number];

type AuditLogSort = {
  field: AuditLogSortField;
  order: 'asc' | 'desc';
};

const DEFAULT_SORT: AuditLogSort = {
  field: 'timestamp',
  order: 'desc',
};

function getUserTaskAuditLogsQueryOptions(
  userTaskKey: string,
  sort: AuditLogSort = DEFAULT_SORT,
) {
  return infiniteQueryOptions({
    queryKey: ['userTaskAuditLogs', userTaskKey, sort],
    queryFn: async ({pageParam}) => {
      const {response, error} = await request(
        api.queryUserTaskAuditLogs({
          userTaskKey,
          sort: [sort],
          filter: {result: 'SUCCESS'},
          page: {
            from: pageParam,
            limit: MAX_AUDIT_LOGS_PER_REQUEST,
          },
        }),
      );

      if (response !== null) {
        return response.json() as Promise<QueryUserTaskAuditLogsResponseBody>;
      }

      throw error;
    },
    initialPageParam: 0,
    getNextPageParam: (lastPage, _, lastPageParam) => {
      const {page} = lastPage;
      const nextPage = lastPageParam + MAX_AUDIT_LOGS_PER_REQUEST;

      if (nextPage > page.totalItems) {
        return null;
      }

      return nextPage;
    },
    getPreviousPageParam: (_, __, firstPageParam) => {
      const previousPage = firstPageParam - MAX_AUDIT_LOGS_PER_REQUEST;

      if (previousPage < 0) {
        return null;
      }

      return previousPage;
    },
    refetchInterval: 5000,
  });
}

export {
  getUserTaskAuditLogsQueryOptions,
  DEFAULT_SORT,
  AUDIT_LOG_SORT_FIELDS,
  type AuditLogSort,
  type AuditLogSortField,
};
