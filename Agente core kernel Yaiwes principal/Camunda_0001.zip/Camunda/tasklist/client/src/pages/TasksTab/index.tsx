/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {useCallback, useEffect, useMemo, useState} from 'react';
import cn from 'classnames';
import {Outlet, useLocation} from 'react-router-dom';
import {Stack} from '@carbon/react';
import {observer} from 'mobx-react-lite';
import {useTasks} from 'modules/api/useTasks.query';
import {useTaskFilters} from 'modules/features/tasks/filters/useTaskFilters';
import {useAutoSelectNextTask} from 'modules/tasks/next-task/useAutoSelectNextTask';
import {useTranslation} from 'react-i18next';
import {autoSelectNextTaskStore} from 'modules/tasks/next-task/autoSelectFirstTask';
import {pages} from 'modules/routing';
import {Options} from 'modules/tasks/available-tasks/Options';
import {Filters} from 'modules/tasks/available-tasks/Filters';
import {AvailableTasks} from './AvailableTasks';
import styles from 'modules/tasks/page.module.scss';
import {CollapsiblePanel} from 'modules/tasks/available-tasks/CollapsiblePanel';
import {IS_NAV_V2_ENABLED} from 'modules/featureFlags';

function useAutoSelectNextTaskSideEffects() {
  const {enabled} = autoSelectNextTaskStore;
  const filters = useTaskFilters();
  const {isLoading, isFetching, data} = useTasks(filters);
  const location = useLocation();
  const tasks = useMemo(() => data?.pages[0] ?? [], [data?.pages]);

  const {goToTask} = useAutoSelectNextTask();

  // We cannot call `navigate` during a render, we need to defer this with useEffect

  // If the filters change, pick the first task when we finish fetching...
  const filtersKey = JSON.stringify(filters);
  const [previousFilters, setPreviousFilters] = useState<string>(filtersKey);
  useEffect(() => {
    if (previousFilters !== filtersKey && !isFetching) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPreviousFilters(filtersKey);
      const firstTask = tasks[0];

      if (
        enabled &&
        firstTask !== undefined &&
        location.pathname !==
          pages.taskDetails(firstTask.userTaskKey.toString())
      ) {
        goToTask(firstTask.userTaskKey.toString());
      }
    }
  }, [
    enabled,
    filters,
    filtersKey,
    goToTask,
    isFetching,
    location.pathname,
    previousFilters,
    tasks,
  ]);

  // If we are on the initial page, when we finish loading tasks...
  const [isFinishedLoading, setIsFinishedLoading] = useState(false);
  useEffect(() => {
    if (!isFinishedLoading && !isLoading) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setIsFinishedLoading(true);
      const firstTask = tasks[0];

      if (
        enabled &&
        firstTask !== undefined &&
        location.pathname === pages.initial
      ) {
        goToTask(firstTask.userTaskKey.toString());
      }
    }
  }, [
    location.pathname,
    tasks,
    isLoading,
    isFinishedLoading,
    enabled,
    goToTask,
  ]);
}

const TasksTab: React.FC = observer(() => {
  const filters = useTaskFilters();
  const {t} = useTranslation();
  const {
    fetchPreviousPage,
    fetchNextPage,
    isLoading,
    isPending,
    data,
    hasNextPage,
    hasPreviousPage,
  } = useTasks(filters);
  const tasks = useMemo(() => data?.pages.flat() ?? [], [data]);

  useAutoSelectNextTaskSideEffects();

  const {goToTask: autoSelectGoToTask} = useAutoSelectNextTask();

  const onAutoSelectToggle = useCallback(
    (state: boolean) => {
      if (state && location.pathname === pages.initial) {
        const firstOpenTask = tasks.find(({state}) => state === 'CREATED');

        if (firstOpenTask !== undefined) {
          autoSelectGoToTask(firstOpenTask.userTaskKey.toString());
        }
      }
    },
    [autoSelectGoToTask, tasks],
  );

  const handleScrollDown = useCallback(async () => {
    const result = await fetchNextPage();
    return result.data?.pages[result.data.pages.length - 1] ?? [];
  }, [fetchNextPage]);

  const handleScrollUp = useCallback(async () => {
    const result = await fetchPreviousPage();
    return result.data?.pages[0] ?? [];
  }, [fetchPreviousPage]);

  return (
    <main
      className={cn(styles.container, {
        [styles.navV2!]: IS_NAV_V2_ENABLED,
      })}
    >
      {!IS_NAV_V2_ENABLED && <CollapsiblePanel />}
      <Stack
        as="section"
        className={styles.tasksPanel}
        aria-label={t('tasksPanelLabel')}
      >
        <Filters disabled={isPending} />
        <AvailableTasks
          loading={isLoading}
          onScrollDown={handleScrollDown}
          onScrollUp={handleScrollUp}
          hasNextPage={hasNextPage}
          hasPreviousPage={hasPreviousPage}
          tasks={tasks}
        />
        <Options onAutoSelectToggle={onAutoSelectToggle} />
      </Stack>
      <div
        className={styles.detailsPanel}
        aria-label={t('availableTasksTitle')}
      >
        <Outlet />
      </div>
    </main>
  );
});

TasksTab.displayName = 'Tasks';

export {TasksTab as Component};
