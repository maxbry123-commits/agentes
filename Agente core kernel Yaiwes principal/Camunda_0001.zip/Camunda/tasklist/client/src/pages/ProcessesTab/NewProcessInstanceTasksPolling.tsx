/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {pages} from 'modules/routing';
import {useLocation, useNavigate} from 'react-router-dom';
import {tracking} from 'modules/tracking';
import {useQuery} from '@tanstack/react-query';
import {request} from 'modules/api/request';
import {api} from 'modules/api';
import type {QueryUserTasksResponseBody} from '@camunda/camunda-api-zod-schemas/8.10';
import type {NewProcessInstance} from 'modules/processes/newProcessInstance';
import {observer} from 'mobx-react-lite';

type Props = {
  newInstance: NewProcessInstance;
};

const NewProcessInstanceTasksPolling: React.FC<Props> = observer(
  ({newInstance}) => {
    const {instance} = newInstance;
    const navigate = useNavigate();
    const location = useLocation();

    const {data: response} = useQuery({
      queryKey: ['newTasks', instance?.id],
      enabled: instance !== null,
      refetchInterval: 1000,
      queryFn: async () => {
        const id = instance?.id;
        if (id === undefined) {
          throw new Error('Process instance id is undefined');
        }

        const {response, error} = await request(
          api.queryTasks({
            filter: {
              processInstanceKey: id,
              state: 'CREATED',
            },
            page: {
              limit: 10,
            },
          }),
        );

        if (response !== null) {
          return (await response.json()) as QueryUserTasksResponseBody;
        }

        if (error !== null) {
          throw error;
        }

        throw new Error('No tasks found');
      },
      gcTime: 0,
      refetchOnWindowFocus: false,
    });

    const items = response?.items ?? [];

    if (items.length > 0) {
      newInstance.removeInstance();
    }

    if (
      items.length === 1 &&
      items[0] !== undefined &&
      location.pathname === `/${pages.processes()}`
    ) {
      const [{userTaskKey}] = items;

      tracking.track({
        eventName: 'process-tasks-polling-ended',
        outcome: 'single-task-found',
      });

      navigate({pathname: pages.taskDetails(userTaskKey)});

      return null;
    }

    return null;
  },
);

export {NewProcessInstanceTasksPolling};
