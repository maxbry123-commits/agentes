/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

/* istanbul ignore file */

import {Outlet, useMatch} from 'react-router-dom';
import {Header} from './Header';
import {AuthenticationCheck} from 'modules/auth/AuthenticationCheck';
import {AuthorizationCheck} from 'modules/auth/AuthorizationCheck';
import {SessionHeartbeat} from 'modules/auth/SessionHeartbeat';
import {pages} from 'modules/routing';
import {OSNotifications} from './OSNotifications';
import {C3Provider} from './C3Provider';
import styles from './styles.module.scss';

const Layout: React.FC = () => {
  const isForbiddenRoute = useMatch(pages.forbidden) !== null;

  return (
    <C3Provider>
      <AuthenticationCheck redirectPath={pages.login}>
        <SessionHeartbeat />
        <AuthorizationCheck>
          <OSNotifications />
          <Header hideNavLinks={isForbiddenRoute} />
          <div id="main-content" tabIndex={-1} className={styles.mainContent}>
            <Outlet />
          </div>
        </AuthorizationCheck>
      </AuthenticationCheck>
    </C3Provider>
  );
};

Layout.displayName = 'Layout';

export {Layout as Component};
