/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {vi} from 'vitest';
vi.mock('modules/featureFlags', () => ({IS_NAV_V2_ENABLED: true}));

import {render, screen} from 'modules/testing/testing-library';
import {nodeMockServer} from 'modules/testing/nodeMockServer';
import {http, HttpResponse} from 'msw';
import {Header} from '..';
import {getWrapper} from './mocks';
import {
  currentUser,
  invalidLicense,
  saasLicense,
  validLicense,
  commercialExpired,
  validNonCommercial,
} from '@camunda/c8-mocks';

describe('license note', () => {
  beforeEach(() => {
    nodeMockServer.use(
      http.get(
        '/v2/authentication/me',
        () => {
          return HttpResponse.json(currentUser);
        },
        {
          once: true,
        },
      ),
    );
  });

  it('should show and hide license information', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(invalidLicense);
        },
        {
          once: true,
        },
      ),
    );

    const {user} = render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByRole('banner', {name: 'Camunda Tasklist'}),
    ).toBeInTheDocument();

    await user.click(await screen.findByText('Non-production license'));

    expect(
      screen.getByText(
        /Non-production license. For production usage details, visit/,
      ),
    ).toBeInTheDocument();
  });

  it('should show license note in CCSM free/trial environment', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(invalidLicense);
        },
        {
          once: true,
        },
      ),
    );

    render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByText('Non-production license'),
    ).toBeInTheDocument();
  });

  it('should not show license note in SaaS environment', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(saasLicense);
        },
        {
          once: true,
        },
      ),
    );

    render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByRole('banner', {name: 'Camunda Tasklist'}),
    ).toBeInTheDocument();
    expect(
      screen.queryByText('Non-production license'),
    ).not.toBeInTheDocument();
  });

  it('should show production license note in CCSM enterprise environment', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(validLicense);
        },
        {
          once: true,
        },
      ),
    );

    render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByRole('banner', {name: 'Camunda Tasklist'}),
    ).toBeInTheDocument();
    expect(await screen.findByText('Production license')).toBeInTheDocument();
  });

  it('should hide commercial license note in self-managed if license is commercial', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(commercialExpired);
        },
        {
          once: true,
        },
      ),
    );

    render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByRole('banner', {name: 'Camunda Tasklist'}),
    ).toBeInTheDocument();

    expect(
      screen.queryByText(/^Non-commercial license - expired$/i),
    ).not.toBeInTheDocument();
  });

  it('should show non-commercial license expiry date', async () => {
    nodeMockServer.use(
      http.get(
        '/v2/license',
        () => {
          return HttpResponse.json(validNonCommercial);
        },
        {
          once: true,
        },
      ),
    );

    render(<Header />, {
      wrapper: getWrapper(),
    });

    expect(
      await screen.findByRole('banner', {name: 'Camunda Tasklist'}),
    ).toBeInTheDocument();
    expect(
      await screen.findByText(/^Non-commercial license - 0 day left$/i),
    ).toBeInTheDocument();
  });
});
