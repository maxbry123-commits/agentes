// import sleep from '@hatchet-dev/typescript-sdk/util/sleep';
import { hatchet } from '../hatchet-client';

export const durableSleep = hatchet.workflow({
  name: 'durable-sleep',
});

// > Durable Sleep
durableSleep.durableTask({
  name: 'durable-sleep',
  executionTimeout: '10m',
  fn: async (_, ctx) => {
    ctx.logger.info('sleeping for 5s');
    const sleepRes = await ctx.sleepFor('5s');
    ctx.logger.info('done sleeping for 5s', { sleepRes });

    return {
      Value: 'done',
    };
  },
});
