import {
  makeZodVerifiedAPICall,
  makeAPICall,
} from "@/src/__tests__/test-utils";
import { prisma } from "@langfuse/shared/src/db";
import { z } from "zod";
import { randomUUID } from "crypto";
import {
  createAndAddApiKeysToDb,
  createBasicAuthHeader,
} from "@langfuse/shared/src/server";
import {
  OBSERVATION_FIELD_GROUPS_FULL,
  LEGACY_EXPORT_PROJECT_CUTOFF,
  LEGACY_BLOB_EXPORTER_CUTOFF,
} from "@langfuse/shared";
import { decrypt } from "@langfuse/shared/encryption";

const MS_PER_DAY = 24 * 60 * 60 * 1000;
const PRE_CUTOFF = new Date(
  LEGACY_EXPORT_PROJECT_CUTOFF.getTime() - MS_PER_DAY,
);
const POST_CUTOFF = new Date(
  LEGACY_EXPORT_PROJECT_CUTOFF.getTime() + MS_PER_DAY,
);
const INTEGRATION_PRE_CUTOFF = new Date(
  LEGACY_BLOB_EXPORTER_CUTOFF.getTime() - MS_PER_DAY,
);
const INTEGRATION_POST_CUTOFF = new Date(
  LEGACY_BLOB_EXPORTER_CUTOFF.getTime() + MS_PER_DAY,
);

// Schemas based on Fern schema definition
const BlobStorageIntegrationResponseSchema = z.object({
  id: z.string(),
  projectId: z.string(),
  type: z.enum(["S3", "S3_COMPATIBLE", "AZURE_BLOB_STORAGE"]),
  bucketName: z.string(),
  endpoint: z.string().nullable(),
  region: z.string(),
  accessKeyId: z.string().nullable(),
  prefix: z.string(),
  exportFrequency: z.enum(["every_20_minutes", "hourly", "daily", "weekly"]),
  enabled: z.boolean(),
  forcePathStyle: z.boolean(),
  fileType: z.enum(["JSON", "CSV", "JSONL", "PARQUET"]),
  exportMode: z.enum(["FULL_HISTORY", "FROM_TODAY", "FROM_CUSTOM_DATE"]),
  exportStartDate: z.coerce.date().nullable(),
  compressed: z.boolean(),
  exportSource: z.enum([
    "LEGACY_TRACES_OBSERVATIONS",
    "OBSERVATIONS_V2",
    "LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS",
  ]),
  exportFieldGroups: z.array(z.enum(OBSERVATION_FIELD_GROUPS_FULL)).nullable(),
  nextSyncAt: z.coerce.date().nullable(),
  lastSyncAt: z.coerce.date().nullable(),
  createdAt: z.coerce.date(),
  updatedAt: z.coerce.date(),
});

const BlobStorageIntegrationsResponseSchema = z.object({
  data: z.array(BlobStorageIntegrationResponseSchema),
});

const BlobStorageIntegrationDeletionResponseSchema = z.object({
  message: z.string(),
});

// Valid blob storage integration request payload
const validBlobStorageConfig = {
  projectId: "",
  type: "S3" as const,
  bucketName: "test-bucket",
  endpoint: null,
  region: "us-east-1",
  accessKeyId: "AKIA123456789",
  secretAccessKey: "secret123456789",
  prefix: "langfuse-exports/",
  exportFrequency: "daily" as const,
  enabled: true,
  forcePathStyle: false,
  fileType: "JSONL" as const,
  exportMode: "FULL_HISTORY" as const,
  exportStartDate: null,
};

describe("Blob Storage Integrations API", () => {
  // Test data
  let testOrgId: string;
  let testProject1Id: string;
  let testProject2Id: string;
  let testApiKey: string;
  let testApiSecretKey: string;
  let testApiKeyId: string;
  let otherOrgId: string;
  let otherProjectId: string;

  beforeAll(async () => {
    // Create test organization
    const testOrg = await prisma.organization.create({
      data: {
        name: `Blob Storage Test Org ${randomUUID().substring(0, 8)}`,
        cloudConfig: { plan: "Team" },
      },
    });
    testOrgId = testOrg.id;

    // Create test projects
    const testProject1 = await prisma.project.create({
      data: {
        name: `Blob Storage Test Project 1 ${randomUUID().substring(0, 8)}`,
        orgId: testOrgId,
      },
    });
    testProject1Id = testProject1.id;

    const testProject2 = await prisma.project.create({
      data: {
        name: `Blob Storage Test Project 2 ${randomUUID().substring(0, 8)}`,
        orgId: testOrgId,
      },
    });
    testProject2Id = testProject2.id;

    // Create organization API key
    const orgApiKey = await createAndAddApiKeysToDb({
      prisma,
      entityId: testOrgId,
      scope: "ORGANIZATION",
      note: "Test API Key for Blob Storage API",
      predefinedKeys: {
        publicKey: `pk-lf-blob-${randomUUID().substring(0, 8)}`,
        secretKey: `sk-lf-blob-${randomUUID().substring(0, 8)}`,
      },
    });
    testApiKey = orgApiKey.publicKey;
    testApiSecretKey = orgApiKey.secretKey;
    testApiKeyId = orgApiKey.id;

    // Create another organization for cross-org tests
    const otherOrg = await prisma.organization.create({
      data: {
        name: `Other Blob Storage Org ${randomUUID().substring(0, 8)}`,
        cloudConfig: { plan: "Team" },
      },
    });
    otherOrgId = otherOrg.id;

    const otherProject = await prisma.project.create({
      data: {
        name: `Other Blob Storage Project ${randomUUID().substring(0, 8)}`,
        orgId: otherOrgId,
      },
    });
    otherProjectId = otherProject.id;
  });

  afterAll(async () => {
    // Clean up test data
    await prisma.organization.delete({
      where: { id: testOrgId },
    });
    await prisma.organization.delete({
      where: { id: otherOrgId },
    });
  });

  describe("GET /api/public/integrations/blob-storage", () => {
    let testIntegrationId: string;

    beforeAll(async () => {
      // Create a test blob storage integration
      const integration = await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "test-bucket",
          region: "us-east-1",
          accessKeyId: "test-access-key",
          secretAccessKey: "encrypted-secret",
          prefix: "langfuse-exports/",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
        },
      });
      testIntegrationId = integration.projectId;
    });

    afterAll(async () => {
      // Clean up test integration
      await prisma.blobStorageIntegration.deleteMany({
        where: { projectId: testProject1Id },
      });
    });

    it("should get all blob storage integrations for the organization", async () => {
      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationsResponseSchema,
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.data.length).toBe(1);

      const integration = response.body.data.find(
        (i) => i.id === testIntegrationId,
      );
      expect(integration).toBeDefined();
      expect(integration?.projectId).toBe(testProject1Id);
      expect(integration?.type).toBe("S3");
      expect(integration?.bucketName).toBe("test-bucket");
      expect(integration?.accessKeyId).toBe("test-access-key");
      // Verify that secretAccessKey is not returned
      expect(integration).not.toHaveProperty("secretAccessKey");
    });

    it("should return 401 with invalid API key", async () => {
      const result = await makeAPICall(
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader("invalid-key", "invalid-secret"),
      );
      expect(result.status).toBe(401);
    });

    it("should return 403 with project-scoped API key", async () => {
      // Create project API key
      const projectApiKey = await createAndAddApiKeysToDb({
        prisma,
        entityId: testProject1Id,
        scope: "PROJECT",
        note: "Project API Key",
        predefinedKeys: {
          publicKey: `pk-lf-proj-${randomUUID().substring(0, 8)}`,
          secretKey: `sk-lf-proj-${randomUUID().substring(0, 8)}`,
        },
      });

      const result = await makeAPICall<{ message: string }>(
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(projectApiKey.publicKey, projectApiKey.secretKey),
      );
      expect(result.status).toBe(403);
      expect(result.body.message).toContain(
        "Organization-scoped API key required",
      );

      // Clean up
      await prisma.apiKey.delete({ where: { id: projectApiKey.id } });
    });
  });

  describe("PUT /api/public/integrations/blob-storage", () => {
    afterEach(async () => {
      // Clean up any created integrations
      await prisma.blobStorageIntegration.deleteMany({
        where: {
          projectId: {
            in: [testProject1Id, testProject2Id],
          },
        },
      });
    });

    it("should create a new blob storage integration", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      expect(response.status).toBe(200);
      expect(response.body.projectId).toBe(testProject1Id);
      expect(response.body.type).toBe("S3");
      expect(response.body.bucketName).toBe("test-bucket");
      expect(response.body.enabled).toBe(true);
      // Verify secretAccessKey is not returned
      expect(response.body).not.toHaveProperty("secretAccessKey");

      // Verify it was saved to database
      const savedIntegration = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(savedIntegration).toBeDefined();
      expect(savedIntegration?.bucketName).toBe("test-bucket");
    });

    it("should update an existing blob storage integration", async () => {
      // Backdated: the row keeps the legacy exportSource column default,
      // which only grandfathered (pre-integration-cutoff) rows may carry.
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "old-bucket",
          region: "us-west-1",
          accessKeyId: "old-key",
          secretAccessKey: "old-secret",
          prefix: "old-prefix/",
          exportFrequency: "hourly",
          enabled: false,
          forcePathStyle: true,
          fileType: "JSON",
          exportMode: "FROM_TODAY",
          createdAt: INTEGRATION_PRE_CUTOFF,
        },
      });

      const updateBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        bucketName: "updated-bucket",
        enabled: true,
        exportFrequency: "weekly" as const,
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        updateBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      expect(response.status).toBe(200);
      expect(response.body.bucketName).toBe("updated-bucket");
      expect(response.body.enabled).toBe(true);
      expect(response.body.exportFrequency).toBe("weekly");
    });

    it("should validate required fields", async () => {
      const invalidBody = {
        projectId: testProject1Id,
        type: "S3",
        // Missing bucketName
        region: "us-east-1",
      };

      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        invalidBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.message).toContain("Invalid request data");
    });

    it("should validate enum values", async () => {
      const invalidBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        type: "INVALID_TYPE",
      };

      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        invalidBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.message).toContain("Invalid request data");
    });

    it("should validate prefix format", async () => {
      const invalidBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        prefix: "invalid-prefix", // Should end with /
      };

      const result = await makeAPICall<{ error: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        invalidBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.error).toBeDefined();
    });

    it("should return 404 for non-existent project", async () => {
      const nonExistentProjectId = randomUUID();
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: nonExistentProjectId,
      };

      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(404);
      expect(result.body.message).toContain("Project not found");
    });

    it("should return 404 for project from different organization", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: otherProjectId,
      };

      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(404);
      expect(result.body.message).toContain("Project not found");
    });

    it("should return 401 with invalid API key", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
      };

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader("invalid-key", "invalid-secret"),
      );
      expect(result.status).toBe(401);
    });

    it("should handle different blob storage types", async () => {
      const azureConfig = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        type: "AZURE_BLOB_STORAGE" as const,
        endpoint: "https://example.com",
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        azureConfig,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      expect(response.status).toBe(200);
      expect(response.body.type).toBe("AZURE_BLOB_STORAGE");
      expect(response.body.endpoint).toBe("https://example.com");
    });

    it("should reject invalid Azure container names", async () => {
      const azureConfig = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        type: "AZURE_BLOB_STORAGE" as const,
        endpoint: "https://example.com",
        bucketName: "Feedback N8N Bot",
      };

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        azureConfig,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
    });

    it("should handle export modes with dates", async () => {
      const customDateConfig = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportMode: "FROM_CUSTOM_DATE" as const,
        exportStartDate: "2024-01-01T00:00:00Z",
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        customDateConfig,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      expect(response.status).toBe(200);
      expect(response.body.exportMode).toBe("FROM_CUSTOM_DATE");
      expect(response.body.exportStartDate).toBeDefined();
    });

    it("should store secretAccessKey encrypted in database", async () => {
      const testSecretKey = "my-super-secret-key-12345";
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        secretAccessKey: testSecretKey,
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      expect(response.status).toBe(200);

      // Query database directly to check how secretAccessKey is stored
      const savedIntegration = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });

      expect(savedIntegration).toBeDefined();

      // Verify secretAccessKey is NOT stored in plaintext
      expect(savedIntegration?.secretAccessKey).not.toBe(testSecretKey);

      // Verify the encrypted value can be decrypted back to the original
      expect(decrypt(savedIntegration!.secretAccessKey!)).toBe(testSecretKey);
    });

    it("should create integration with compressed=true by default", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
      };
      // Do not pass compressed — should default to true

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      expect(response.status).toBe(200);
      expect(response.body.compressed).toBe(true);
    });

    it("should create integration with compressed=false when specified", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        compressed: false,
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      expect(response.status).toBe(200);
      expect(response.body.compressed).toBe(false);

      const savedIntegration = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(savedIntegration?.compressed).toBe(false);
    });

    it("should store all exportFieldGroups by default when creating via REST", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
      };

      await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportFieldGroups).toHaveLength(11);
    });

    it("should preserve exportFieldGroups in DB when updating via REST", async () => {
      // Seed a custom subset. Backdated: the row keeps the legacy exportSource
      // column default, which only grandfathered rows may carry.
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "initial-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportFieldGroups: ["core", "io"],
          createdAt: INTEGRATION_PRE_CUTOFF,
        },
      });

      // Update via REST — exportFieldGroups is not part of the REST API schema
      await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...validBlobStorageConfig,
          projectId: testProject1Id,
          bucketName: "updated-bucket",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
    });
  });

  describe("PUT/GET exportSource + exportFieldGroups behavior", () => {
    // Pin projects to a pre-cutoff date so legacy-source tests remain valid
    // once the clock crosses LEGACY_EXPORT_PROJECT_CUTOFF (CI runs with
    // NEXT_PUBLIC_LANGFUSE_CLOUD_REGION set, so the gate would otherwise
    // reject LEGACY_TRACES_OBSERVATIONS for projects created at now()).
    beforeAll(async () => {
      await prisma.project.updateMany({
        where: { id: { in: [testProject1Id, testProject2Id] } },
        data: { createdAt: PRE_CUTOFF },
      });
    });

    afterAll(async () => {
      await prisma.project.updateMany({
        where: { id: { in: [testProject1Id, testProject2Id] } },
        data: { createdAt: new Date() },
      });
    });

    afterEach(async () => {
      await prisma.blobStorageIntegration.deleteMany({
        where: {
          projectId: { in: [testProject1Id, testProject2Id] },
        },
      });
    });

    // Pre-integration-cutoff legacy row: lets a legacy-source PUT pass the
    // integration-level gate (new Cloud rows can no longer be legacy, so these
    // tests exercise the UPDATE path).
    const seedGrandfatheredLegacyRow = (
      data: { exportFieldGroups?: string[] } = {},
    ) =>
      prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "seed-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "TRACES_OBSERVATIONS",
          createdAt: INTEGRATION_PRE_CUTOFF,
          ...data,
        },
      });

    // ---- OBSERVATIONS_V2 / LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS path ----

    it("OBSERVATIONS_V2 + exportFieldGroups=[core,io] -> 200 and GET returns same value", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "OBSERVATIONS_V2" as const,
        exportFieldGroups: ["core", "io"],
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);
      expect(putResponse.body.exportSource).toBe("OBSERVATIONS_V2");
      expect(putResponse.body.exportFieldGroups).toStrictEqual(["core", "io"]);

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );
      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportSource).toBe("OBSERVATIONS_V2");
      expect(integration?.exportFieldGroups).toStrictEqual(["core", "io"]);
    });

    it("OBSERVATIONS_V2 + exportFieldGroups=[io] (missing core) -> 400", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "OBSERVATIONS_V2" as const,
        exportFieldGroups: ["io"],
      };

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
    });

    it("OBSERVATIONS_V2 + exportFieldGroups omitted -> 200 and GET returns all 11 groups", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "OBSERVATIONS_V2" as const,
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );
      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportSource).toBe("OBSERVATIONS_V2");
      expect(integration?.exportFieldGroups).toBeDefined();
      expect(integration?.exportFieldGroups).toHaveLength(
        OBSERVATION_FIELD_GROUPS_FULL.length,
      );
      expect(new Set(integration?.exportFieldGroups)).toStrictEqual(
        new Set(OBSERVATION_FIELD_GROUPS_FULL),
      );
    });

    it("OBSERVATIONS_V2 + exportFieldGroups=null -> 200 and GET returns all 11 groups", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "OBSERVATIONS_V2" as const,
        exportFieldGroups: null,
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );
      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportFieldGroups).toBeDefined();
      expect(integration?.exportFieldGroups).toHaveLength(
        OBSERVATION_FIELD_GROUPS_FULL.length,
      );
      expect(new Set(integration?.exportFieldGroups)).toStrictEqual(
        new Set(OBSERVATION_FIELD_GROUPS_FULL),
      );
    });

    // ---- LEGACY_TRACES_OBSERVATIONS path ----

    it("LEGACY_TRACES_OBSERVATIONS + exportFieldGroups omitted -> 200; GET returns all 11 groups", async () => {
      await seedGrandfatheredLegacyRow();
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );
      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportSource).toBe("LEGACY_TRACES_OBSERVATIONS");
      expect(integration?.exportFieldGroups).toHaveLength(
        OBSERVATION_FIELD_GROUPS_FULL.length,
      );
    });

    it("LEGACY_TRACES_OBSERVATIONS + exportFieldGroups=null -> 200; GET returns all 11 groups", async () => {
      await seedGrandfatheredLegacyRow();
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
        exportFieldGroups: null,
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );
      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportFieldGroups).toHaveLength(
        OBSERVATION_FIELD_GROUPS_FULL.length,
      );
    });

    it("LEGACY_TRACES_OBSERVATIONS + exportFieldGroups=[] (missing core) -> 400", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
        exportFieldGroups: [],
      };

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      const message = JSON.stringify(result.body);
      expect(message.toLowerCase()).toContain("core");
    });

    it("LEGACY_TRACES_OBSERVATIONS + exportFieldGroups=[core,io] -> 200 and GET returns same value", async () => {
      await seedGrandfatheredLegacyRow();
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
        exportFieldGroups: ["core", "io"],
      };

      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);
      expect(putResponse.body.exportFieldGroups).toStrictEqual(["core", "io"]);

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
    });

    it("GET returns exportFieldGroups for LEGACY_TRACES_OBSERVATIONS rows seeded via Prisma", async () => {
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "legacy-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "TRACES_OBSERVATIONS",
          exportFieldGroups: ["core", "io", "metadata"],
        },
      });

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportSource).toBe("LEGACY_TRACES_OBSERVATIONS");
      expect(integration?.exportFieldGroups).toStrictEqual([
        "core",
        "io",
        "metadata",
      ]);
    });

    it("PUT LEGACY_TRACES_OBSERVATIONS preserves existing export_field_groups column in DB", async () => {
      // Seed a grandfathered row with a custom subset
      await seedGrandfatheredLegacyRow({ exportFieldGroups: ["core", "io"] });

      await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...validBlobStorageConfig,
          projectId: testProject1Id,
          exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
          bucketName: "updated-bucket",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.bucketName).toBe("updated-bucket");
      // Omitting exportFieldGroups on update preserves the stored value.
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
    });

    // ---- Response shape ----

    it("PUT response includes exportSource and exportFieldGroups for LEGACY_TRACES_OBSERVATIONS", async () => {
      await seedGrandfatheredLegacyRow();
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "LEGACY_TRACES_OBSERVATIONS" as const,
      };

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty(
        "exportSource",
        "LEGACY_TRACES_OBSERVATIONS",
      );
      expect(response.body.exportFieldGroups).toHaveLength(
        OBSERVATION_FIELD_GROUPS_FULL.length,
      );
    });

    it("GET response includes exportSource and exportFieldGroups for all sources", async () => {
      // Seed two integrations on different projects with different sources
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "bucket-1",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "TRACES_OBSERVATIONS",
          exportFieldGroups: ["core", "io", "metadata"],
        },
      });
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject2Id,
          type: "S3",
          bucketName: "bucket-2",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "EVENTS",
          exportFieldGroups: ["core", "io"],
        },
      });

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      const legacyIntegration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      const enrichedIntegration = getResponse.body.data.find(
        (i) => i.projectId === testProject2Id,
      );
      expect(legacyIntegration?.exportSource).toBe(
        "LEGACY_TRACES_OBSERVATIONS",
      );
      expect(legacyIntegration?.exportFieldGroups).toStrictEqual([
        "core",
        "io",
        "metadata",
      ]);
      expect(enrichedIntegration?.exportSource).toBe("OBSERVATIONS_V2");
      expect(enrichedIntegration?.exportFieldGroups).toStrictEqual([
        "core",
        "io",
      ]);
    });

    it("GET response maps internal TRACES_OBSERVATIONS_EVENTS to public LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS", async () => {
      // Seed via Prisma with the third internal enum value to exercise the
      // mapping for LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS through the public REST surface.
      // satisfies-enforced exhaustiveness in INTERNAL_TO_PUBLIC_EXPORT_SOURCE
      // catches a missing key at compile time, but only a runtime assertion
      // catches a copy-paste regression (e.g. "OBSERVATIONS_V2" written twice).
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "bucket-mixed",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "TRACES_OBSERVATIONS_EVENTS",
          exportFieldGroups: ["core", "io", "metadata"],
        },
      });

      const getResponse = await makeZodVerifiedAPICall(
        z.object({ data: z.array(BlobStorageIntegrationResponseSchema) }),
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      const integration = getResponse.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration).toBeDefined();
      expect(integration?.exportSource).toBe(
        "LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS",
      );
      // exportFieldGroups is only masked to null for LEGACY_TRACES_OBSERVATIONS — the
      // LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS source returns the raw DB array.
      expect(integration?.exportFieldGroups).toStrictEqual([
        "core",
        "io",
        "metadata",
      ]);
    });

    it("PUT without exportSource preserves existing OBSERVATIONS_V2 source and field groups", async () => {
      // Pre-seed an OBSERVATIONS_V2 row with a custom field-group subset
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "initial-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "EVENTS",
          exportFieldGroups: ["core", "io"],
        },
      });

      // PUT update with exportSource and exportFieldGroups both omitted
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        bucketName: "updated-bucket",
      };
      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);
      expect(putResponse.body.exportSource).toBe("OBSERVATIONS_V2");
      expect(putResponse.body.exportFieldGroups).toStrictEqual(["core", "io"]);

      // DB row preserved on both columns; bucket updated
      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportSource).toBe("EVENTS");
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
      expect(saved?.bucketName).toBe("updated-bucket");
    });

    it("PUT exportSource=null preserves existing OBSERVATIONS_V2 source and field groups", async () => {
      // Pre-seed an OBSERVATIONS_V2 row with a custom field-group subset
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "initial-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "EVENTS",
          exportFieldGroups: ["core", "io"],
        },
      });

      // PUT with exportSource explicitly null — mirrors what an OpenAPI/SDK
      // client would emit for a not-provided value
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: null,
        bucketName: "updated-bucket",
      };
      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);
      expect(putResponse.body.exportSource).toBe("OBSERVATIONS_V2");
      expect(putResponse.body.exportFieldGroups).toStrictEqual(["core", "io"]);

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportSource).toBe("EVENTS");
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
    });

    it("PUT exportSource=OBSERVATIONS_V2 without exportFieldGroups on existing OBSERVATIONS_V2 row preserves field groups", async () => {
      // Pre-seed an OBSERVATIONS_V2 row with a custom field-group subset
      await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "initial-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "EVENTS",
          exportFieldGroups: ["core", "io"],
        },
      });

      // PUT with explicit exportSource=OBSERVATIONS_V2 but exportFieldGroups omitted
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportSource: "OBSERVATIONS_V2" as const,
        bucketName: "updated-bucket",
      };
      const putResponse = await makeZodVerifiedAPICall(
        BlobStorageIntegrationResponseSchema,
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(putResponse.status).toBe(200);
      expect(putResponse.body.exportSource).toBe("OBSERVATIONS_V2");
      expect(putResponse.body.exportFieldGroups).toStrictEqual(["core", "io"]);

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportFieldGroups).toStrictEqual(["core", "io"]);
      expect(saved?.bucketName).toBe("updated-bucket");
    });

    it("PUT with exportFieldGroups but no exportSource -> 400", async () => {
      const requestBody = {
        ...validBlobStorageConfig,
        projectId: testProject1Id,
        exportFieldGroups: ["core", "io"],
      };

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        requestBody,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      const message = JSON.stringify(result.body).toLowerCase();
      expect(message).toContain("exportsource is required");
    });
  });

  describe("DELETE /api/public/integrations/blob-storage/{id}", () => {
    let testIntegrationId: string;

    beforeEach(async () => {
      // Create test integration
      const integration = await prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "test-bucket",
          region: "us-east-1",
          accessKeyId: "test-key",
          secretAccessKey: "test-secret",
          prefix: "test/",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
        },
      });
      testIntegrationId = integration.projectId; // Based on current implementation, ID is projectId
    });

    afterEach(async () => {
      // Clean up
      await prisma.blobStorageIntegration.deleteMany({
        where: { projectId: testProject1Id },
      });
    });

    it("should delete a blob storage integration", async () => {
      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationDeletionResponseSchema,
        "DELETE",
        `/api/public/integrations/blob-storage/${testIntegrationId}`,
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      expect(response.status).toBe(200);
      expect(response.body.message).toBeDefined();

      // Verify it was deleted from database
      const deletedIntegration = await prisma.blobStorageIntegration.findUnique(
        {
          where: { projectId: testIntegrationId },
        },
      );
      expect(deletedIntegration).toBeNull();
    });

    it("should create an audit log entry for delete", async () => {
      const auditLogWhere = {
        resourceType: "blobStorageIntegration",
        resourceId: testIntegrationId,
        action: "delete",
        orgId: testOrgId,
        projectId: testIntegrationId,
        apiKeyId: testApiKeyId,
      };
      const auditLogCountBefore = await prisma.auditLog.count({
        where: auditLogWhere,
      });

      await makeZodVerifiedAPICall(
        BlobStorageIntegrationDeletionResponseSchema,
        "DELETE",
        `/api/public/integrations/blob-storage/${testIntegrationId}`,
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      const auditLogCountAfter = await prisma.auditLog.count({
        where: auditLogWhere,
      });
      expect(auditLogCountAfter).toBe(auditLogCountBefore + 1);
    });

    it("should return 404 for non-existent integration", async () => {
      const nonExistentId = randomUUID();
      const result = await makeAPICall(
        "DELETE",
        `/api/public/integrations/blob-storage/${nonExistentId}`,
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(404);
    });

    it("should return 404 for integration from different organization", async () => {
      // Create integration in other org
      const otherOrgIntegration = await prisma.blobStorageIntegration.create({
        data: {
          projectId: otherProjectId,
          type: "S3",
          bucketName: "other-bucket",
          region: "us-east-1",
          accessKeyId: "other-key",
          secretAccessKey: "other-secret",
          prefix: "other/",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
        },
      });

      const result = await makeAPICall(
        "DELETE",
        `/api/public/integrations/blob-storage/${otherOrgIntegration.projectId}`,
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(404);

      // Check config still exists
      const integrations = await prisma.blobStorageIntegration.findMany({
        where: { projectId: otherProjectId },
      });
      expect(integrations).toHaveLength(1);

      // Clean up
      await prisma.blobStorageIntegration.delete({
        where: { projectId: otherProjectId },
      });
    });

    it("should return 401 with invalid API key", async () => {
      const result = await makeAPICall(
        "DELETE",
        `/api/public/integrations/blob-storage/${testIntegrationId}`,
        undefined,
        createBasicAuthHeader("invalid-key", "invalid-secret"),
      );
      expect(result.status).toBe(401);
    });

    it("should return 403 with project-scoped API key", async () => {
      const projectApiKey = await createAndAddApiKeysToDb({
        prisma,
        entityId: testProject1Id,
        scope: "PROJECT",
        note: "Project API Key",
        predefinedKeys: {
          publicKey: `pk-lf-proj-del-${randomUUID().substring(0, 8)}`,
          secretKey: `sk-lf-proj-del-${randomUUID().substring(0, 8)}`,
        },
      });

      const result = await makeAPICall(
        "DELETE",
        `/api/public/integrations/blob-storage/${testIntegrationId}`,
        undefined,
        createBasicAuthHeader(projectApiKey.publicKey, projectApiKey.secretKey),
      );
      expect(result.status).toBe(403);

      // Clean up
      await prisma.apiKey.delete({ where: { id: projectApiKey.id } });
    });
  });

  describe("Method validation", () => {
    it("should return 405 for unsupported methods", async () => {
      const result = await makeAPICall<{ message: string }>(
        "PATCH",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(405);
      expect(result.body.message).toContain("Method not allowed");
    });
  });

  describe("legacy blob export source cutoff gate", () => {
    const basePayload = {
      type: "S3" as const,
      bucketName: "test-bucket",
      endpoint: null,
      region: "us-east-1",
      accessKeyId: "AKIA123456789",
      secretAccessKey: "secret123456789",
      prefix: "exports/",
      exportFrequency: "daily",
      enabled: true,
      forcePathStyle: false,
      fileType: "JSONL",
      exportMode: "FULL_HISTORY",
      exportStartDate: null,
    };

    afterEach(() => {
      vi.restoreAllMocks();
    });

    // All REST cutoff-gate tests rely on the CI server already running in Cloud
    // mode (NEXT_PUBLIC_LANGFUSE_CLOUD_REGION is set in .env.dev.example). The
    // makeAPICall goes over HTTP to a separate process whose env is frozen at
    // boot, so any (env as any).NEXT_PUBLIC_LANGFUSE_CLOUD_REGION mutation in
    // the test process never reaches the server and would be dead code.

    it("Cloud + pre-cutoff project + LEGACY_TRACES_OBSERVATIONS → 200", async () => {
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: PRE_CUTOFF },
        });
        // Grandfathered row: legacy sources are only allowed on existing
        // pre-integration-cutoff rows.
        await prisma.blobStorageIntegration.create({
          data: {
            projectId: testProject1Id,
            type: "S3",
            bucketName: "seed-bucket",
            region: "us-east-1",
            accessKeyId: "key",
            secretAccessKey: "secret",
            prefix: "",
            exportFrequency: "daily",
            enabled: true,
            forcePathStyle: false,
            fileType: "JSONL",
            exportMode: "FULL_HISTORY",
            exportSource: "TRACES_OBSERVATIONS",
            createdAt: INTEGRATION_PRE_CUTOFF,
          },
        });
        const result = await makeAPICall(
          "PUT",
          "/api/public/integrations/blob-storage",
          {
            ...basePayload,
            projectId: testProject1Id,
            exportSource: "LEGACY_TRACES_OBSERVATIONS",
          },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(200);
      } finally {
        await prisma.blobStorageIntegration.deleteMany({
          where: { projectId: testProject1Id },
        });
      }
    });

    it("Cloud + post-cutoff project + LEGACY_TRACES_OBSERVATIONS → 400", async () => {
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: POST_CUTOFF },
        });
        const result = await makeAPICall<{ message: string }>(
          "PUT",
          "/api/public/integrations/blob-storage",
          {
            ...basePayload,
            projectId: testProject1Id,
            exportSource: "LEGACY_TRACES_OBSERVATIONS",
          },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(400);
        expect(result.body.message).toContain("OBSERVATIONS_V2");
      } finally {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: new Date() },
        });
      }
    });

    it("Cloud + post-cutoff project + LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS → 400", async () => {
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: POST_CUTOFF },
        });
        const result = await makeAPICall<{ message: string }>(
          "PUT",
          "/api/public/integrations/blob-storage",
          {
            ...basePayload,
            projectId: testProject1Id,
            exportSource: "LEGACY_TRACES_AND_ENRICHED_OBSERVATIONS",
          },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(400);
        expect(result.body.message).toContain("OBSERVATIONS_V2");
      } finally {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: new Date() },
        });
      }
    });

    it("Cloud + post-cutoff project + OBSERVATIONS_V2 → 200", async () => {
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: POST_CUTOFF },
        });
        const result = await makeAPICall(
          "PUT",
          "/api/public/integrations/blob-storage",
          {
            ...basePayload,
            projectId: testProject1Id,
            exportSource: "OBSERVATIONS_V2",
          },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(200);
      } finally {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: new Date() },
        });
        await prisma.blobStorageIntegration.deleteMany({
          where: { projectId: testProject1Id },
        });
      }
    });
    it("Cloud + post-cutoff project + no exportSource + CREATE → defaults to OBSERVATIONS_V2", async () => {
      // No existing row → CREATE path: handler forces EVENTS (OBSERVATIONS_V2).
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: POST_CUTOFF },
        });
        const result = await makeAPICall<{ exportSource: string }>(
          "PUT",
          "/api/public/integrations/blob-storage",
          { ...basePayload, projectId: testProject1Id },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(200);
        expect(result.body.exportSource).toBe("OBSERVATIONS_V2");
      } finally {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: new Date() },
        });
        await prisma.blobStorageIntegration.deleteMany({
          where: { projectId: testProject1Id },
        });
      }
    });

    it("Cloud + post-cutoff project + no exportSource + UPDATE → preserves existing value", async () => {
      // Existing row with OBSERVATIONS_V2 → UPDATE path: omitting exportSource
      // must not overwrite the persisted value.
      try {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: POST_CUTOFF },
        });
        await prisma.blobStorageIntegration.create({
          data: {
            projectId: testProject1Id,
            type: "S3",
            bucketName: "test-bucket",
            region: "us-east-1",
            prefix: "",
            exportFrequency: "daily",
            enabled: true,
            forcePathStyle: false,
            fileType: "JSONL",
            exportMode: "FULL_HISTORY",
            exportSource: "EVENTS",
          },
        });
        const result = await makeAPICall<{ exportSource: string }>(
          "PUT",
          "/api/public/integrations/blob-storage",
          { ...basePayload, projectId: testProject1Id },
          createBasicAuthHeader(testApiKey, testApiSecretKey),
        );
        expect(result.status).toBe(200);
        expect(result.body.exportSource).toBe("OBSERVATIONS_V2");
      } finally {
        await prisma.project.update({
          where: { id: testProject1Id },
          data: { createdAt: new Date() },
        });
        await prisma.blobStorageIntegration.deleteMany({
          where: { projectId: testProject1Id },
        });
      }
    });
  });

  describe("integration-level legacy exporter cutoff gate", () => {
    // Cloud mode comes from the server process env (see note in the
    // project-level gate suite). The project is pinned pre-cutoff, so every
    // 400 here is the integration-level cutoff. The self-hosted bypass cannot
    // be tested over HTTP (frozen server env); the tRPC suite covers it
    // through the same shared gate.
    const basePayload = {
      ...validBlobStorageConfig,
      projectId: "", // set per test
    };

    const seedIntegration = (createdAt: Date) =>
      prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "existing-bucket",
          region: "us-east-1",
          accessKeyId: "key",
          secretAccessKey: "secret",
          prefix: "",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "JSONL",
          exportMode: "FULL_HISTORY",
          exportSource: "TRACES_OBSERVATIONS",
          createdAt,
        },
      });

    beforeAll(async () => {
      await prisma.project.update({
        where: { id: testProject1Id },
        data: { createdAt: PRE_CUTOFF },
      });
    });

    afterAll(async () => {
      await prisma.project.update({
        where: { id: testProject1Id },
        data: { createdAt: new Date() },
      });
    });

    afterEach(async () => {
      await prisma.blobStorageIntegration.deleteMany({
        where: { projectId: testProject1Id },
      });
    });

    it("no existing row + legacy source → 400 mentioning the integration cutoff", async () => {
      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...basePayload,
          projectId: testProject1Id,
          exportSource: "LEGACY_TRACES_OBSERVATIONS",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.message).toContain("integrations created on or after");
      expect(result.body.message).toContain(
        LEGACY_BLOB_EXPORTER_CUTOFF.toISOString(),
      );
      expect(result.body.message).toContain("OBSERVATIONS_V2");
    });

    it("pre-cutoff existing row + legacy source → 200 (grandfathered)", async () => {
      await seedIntegration(INTEGRATION_PRE_CUTOFF);
      const result = await makeAPICall<{ exportSource: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...basePayload,
          projectId: testProject1Id,
          exportSource: "LEGACY_TRACES_OBSERVATIONS",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(200);
      expect(result.body.exportSource).toBe("LEGACY_TRACES_OBSERVATIONS");
    });

    it("existing row created exactly at the cutoff + legacy source → 400", async () => {
      // Boundary: only rows created strictly before the cutoff are
      // grandfathered.
      await seedIntegration(LEGACY_BLOB_EXPORTER_CUTOFF);
      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...basePayload,
          projectId: testProject1Id,
          exportSource: "LEGACY_TRACES_OBSERVATIONS",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.message).toContain("integrations created on or after");
    });

    it("post-cutoff existing row + legacy source → 400", async () => {
      await seedIntegration(INTEGRATION_POST_CUTOFF);
      const result = await makeAPICall<{ message: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...basePayload,
          projectId: testProject1Id,
          exportSource: "LEGACY_TRACES_OBSERVATIONS",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(400);
      expect(result.body.message).toContain("integrations created on or after");
    });

    it("no existing row + OBSERVATIONS_V2 → 200", async () => {
      const result = await makeAPICall<{ exportSource: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...basePayload,
          projectId: testProject1Id,
          exportSource: "OBSERVATIONS_V2",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(200);
      expect(result.body.exportSource).toBe("OBSERVATIONS_V2");
    });

    it("no existing row + omitted exportSource → 200 and persists EVENTS", async () => {
      // New Cloud rows must never get the legacy column default, even on a
      // pre-cutoff project.
      const result = await makeAPICall<{ exportSource: string }>(
        "PUT",
        "/api/public/integrations/blob-storage",
        { ...basePayload, projectId: testProject1Id },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(200);
      expect(result.body.exportSource).toBe("OBSERVATIONS_V2");

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.exportSource).toBe("EVENTS");
    });
  });

  describe("Parquet fileType", () => {
    const seedParquetIntegration = () =>
      prisma.blobStorageIntegration.create({
        data: {
          projectId: testProject1Id,
          type: "S3",
          bucketName: "test-bucket",
          region: "us-east-1",
          accessKeyId: "test-access-key",
          secretAccessKey: "encrypted-secret",
          prefix: "langfuse-exports/",
          exportFrequency: "daily",
          enabled: true,
          forcePathStyle: false,
          fileType: "PARQUET",
          exportMode: "FULL_HISTORY",
          // Non-legacy source so updates aren't rejected by the Cloud
          // legacy-export-source cutoff gate (orthogonal to fileType here).
          exportSource: "EVENTS",
        },
      });

    beforeEach(async () => {
      await prisma.blobStorageIntegration.deleteMany({
        where: { projectId: testProject1Id },
      });
    });

    afterAll(async () => {
      await prisma.blobStorageIntegration.deleteMany({
        where: { projectId: testProject1Id },
      });
    });

    it("accepts PARQUET as a request fileType", async () => {
      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...validBlobStorageConfig,
          projectId: testProject1Id,
          fileType: "PARQUET",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(200);

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.fileType).toBe("PARQUET");
    });

    it("allows changing the fileType of a Parquet-configured integration", async () => {
      await seedParquetIntegration();

      const result = await makeAPICall(
        "PUT",
        "/api/public/integrations/blob-storage",
        {
          ...validBlobStorageConfig,
          projectId: testProject1Id,
          exportSource: "OBSERVATIONS_V2",
        },
        createBasicAuthHeader(testApiKey, testApiSecretKey),
      );
      expect(result.status).toBe(200);

      const saved = await prisma.blobStorageIntegration.findUnique({
        where: { projectId: testProject1Id },
      });
      expect(saved?.fileType).toBe(validBlobStorageConfig.fileType);
    });

    it("GET reports fileType PARQUET for a Parquet-configured integration", async () => {
      await seedParquetIntegration();

      const response = await makeZodVerifiedAPICall(
        BlobStorageIntegrationsResponseSchema,
        "GET",
        "/api/public/integrations/blob-storage",
        undefined,
        createBasicAuthHeader(testApiKey, testApiSecretKey),
        200,
      );

      const integration = response.body.data.find(
        (i) => i.projectId === testProject1Id,
      );
      expect(integration?.fileType).toBe("PARQUET");
    });
  });
});
