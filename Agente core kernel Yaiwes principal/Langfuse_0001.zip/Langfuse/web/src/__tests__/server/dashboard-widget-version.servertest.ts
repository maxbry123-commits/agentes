import { v4 as uuidv4 } from "uuid";
import {
  createOrgProjectAndApiKey,
  DashboardService,
} from "@langfuse/shared/src/server";
import { DashboardWidgetViews, prisma } from "@langfuse/shared/src/db";
import { env as sharedEnv } from "@langfuse/shared/src/env";
import {
  LANGFUSE_HOME_DASHBOARD_DEFINITION,
  LANGFUSE_HOME_DASHBOARD_ID,
} from "@langfuse/shared";
import { appRouter } from "@/src/server/api/root";
import { createInnerTRPCContext } from "@/src/server/api/trpc";
import type { Session } from "next-auth";
import { requiresV2 } from "@langfuse/shared/query";
import {
  mapLegacyUiTableFilterToView,
  mapWidgetUiTableFilterToView,
} from "@/src/features/dashboard/lib/dashboardUiTableToViewMapping";

describe("dashboard widget minVersion", () => {
  let projectId: string;
  let orgId: string;
  let userId: string;
  const originalWriteMode = sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE;

  beforeAll(async () => {
    const org = await createOrgProjectAndApiKey();
    projectId = org.projectId;
    orgId = org.orgId;

    const user = await prisma.user.create({
      data: {
        id: uuidv4(),
        email: `test-dashboard-widget-${uuidv4().substring(0, 8)}@test.com`,
        name: "Test User",
      },
    });
    userId = user.id;

    await prisma.organizationMembership.create({
      data: {
        orgId,
        userId: user.id,
        role: "OWNER",
      },
    });
  });

  afterEach(() => {
    sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE = originalWriteMode;
  });

  function makeCaller(v4BetaEnabled = false) {
    const session: Session = {
      expires: "1",
      user: {
        id: userId,
        canCreateOrganizations: true,
        name: "Test User",
        organizations: [
          {
            id: orgId,
            name: "Test Organization",
            role: "OWNER",
            plan: "cloud:hobby",
            cloudConfig: undefined,
            metadata: {},
            aiFeaturesEnabled: false,
            aiTelemetryEnabled: true,
            projects: [
              {
                id: projectId,
                role: "ADMIN",
                retentionDays: 30,
                deletedAt: null,
                name: "Test Project",
                hasTraces: true,
                metadata: {},
                createdAt: new Date().toISOString(),
              },
            ],
          },
        ],
        featureFlags: {
          excludeClickhouseRead: false,
          templateFlag: true,
          v4BetaToggleVisible: false,
          observationEvals: false,
          experimentsV4Enabled: false,
          searchBar: false,
        },
        v4BetaEnabled,
        admin: true,
      },
      environment: {} as any,
    };
    const ctx = createInnerTRPCContext({ session, headers: {} });
    return appRouter.createCaller({ ...ctx, prisma });
  }

  const baseWidgetInput = {
    name: "Test Widget",
    description: "A test widget",
    view: DashboardWidgetViews.OBSERVATIONS,
    dimensions: [{ field: "name" }],
    metrics: [{ measure: "count", agg: "count" }],
    filters: [],
    chartType: "LINE_TIME_SERIES" as const,
    chartConfig: { type: "LINE_TIME_SERIES" as const },
  };

  // ── requiresV2 helper tests ─────────────────────────────────────────

  describe("requiresV2", () => {
    it.each([
      // v2-only dimensions
      ["observations", [{ field: "costType" }], [], [], true],
      ["observations", [{ field: "usageType" }], [], [], true],
      // v2-only measures
      ["observations", [], [{ measure: "costByType" }], [], true],
      ["observations", [], [{ measure: "usageByType" }], [], true],
      ["observations", [], [{ measure: "traceId" }], [], true],
      // v2-only filters
      [
        "observations",
        [],
        [{ measure: "count" }],
        [{ column: "release" }],
        true,
      ],
      // v2-only experiment filters
      [
        "observations",
        [],
        [{ measure: "count" }],
        [{ column: "experimentId" }],
        true,
      ],
      [
        "observations",
        [],
        [{ measure: "count" }],
        [{ column: "experimentName" }],
        true,
      ],
      [
        "observations",
        [],
        [{ measure: "count" }],
        [{ column: "experimentDatasetId" }],
        true,
      ],
      [
        "observations",
        [],
        [{ measure: "count" }],
        [{ column: "isRootObservation" }],
        true,
      ],
      // v1-compatible fields
      [
        "observations",
        [{ field: "name" }],
        [{ measure: "count" }],
        [{ column: "traceRelease" }],
        false,
      ],
      // views where v1 and v2 share all fields
      ["traces", [{ field: "name" }], [{ measure: "count" }], [], false],
      [
        "scores-numeric",
        [{ field: "name" }],
        [{ measure: "count" }],
        [],
        false,
      ],
      // unknown view
      ["nonexistent", [{ field: "name" }], [{ measure: "count" }], [], false],
    ])(
      "requiresV2(%s, dims=%j, measures=%j, filters=%j) → %s",
      (view, dimensions, measures, filters, expected) => {
        expect(requiresV2({ view, dimensions, measures, filters })).toBe(
          expected,
        );
      },
    );
  });

  it("rejects v2 widget shapes at the tRPC boundary on a legacy deployment", async () => {
    sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE = "legacy";

    await expect(
      makeCaller().dashboardWidgets.create({
        ...baseWidgetInput,
        view: "observations",
        projectId,
        metrics: [{ measure: "traceId", agg: "uniq" }],
      }),
    ).rejects.toThrow(/v2-only fields/i);
  });

  describe("observations release filter mapping", () => {
    it("keeps legacy observations Release filters on traceRelease for v1 compatibility", () => {
      expect(
        mapLegacyUiTableFilterToView("observations", [
          {
            column: "Release",
            operator: "=",
            value: "2026.04",
            type: "string",
          },
        ]),
      ).toEqual([
        {
          column: "traceRelease",
          operator: "=",
          value: "2026.04",
          type: "string",
        },
      ]);
    });

    it("keeps the retired Observation Release label on the release field", () => {
      expect(
        mapLegacyUiTableFilterToView("observations", [
          {
            column: "Observation Release",
            operator: "=",
            value: "2026.04",
            type: "string",
          },
        ]),
      ).toEqual([
        {
          column: "release",
          operator: "=",
          value: "2026.04",
          type: "string",
        },
      ]);
    });

    it("maps an editor Release row to the v2 release field", () => {
      expect(
        mapWidgetUiTableFilterToView("observations", [
          {
            column: "Release",
            operator: "=",
            value: "2026.04",
            type: "string",
          },
        ]),
      ).toEqual([
        {
          column: "release",
          operator: "=",
          value: "2026.04",
          type: "string",
        },
      ]);
    });
  });

  // ── Service layer tests ─────────────────────────────────────────────

  describe("DashboardService", () => {
    it("persists v1 shapes and rejects v2 creates and updates on legacy deployments", async () => {
      sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE = "legacy";
      const v2Input = {
        ...baseWidgetInput,
        metrics: [{ measure: "traceId", agg: "uniq" }],
      };

      await expect(
        DashboardService.createWidget(projectId, v2Input, userId),
      ).rejects.toThrow(/v2-only fields/i);

      const widget = await DashboardService.createWidget(
        projectId,
        baseWidgetInput,
        userId,
      );
      expect(widget.minVersion).toBe(1);

      await expect(
        DashboardService.updateWidget(projectId, widget.id, v2Input, userId),
      ).rejects.toThrow(/v2-only fields/i);
    });

    it("derives v2, preserves it on dual writes, and heals it on legacy", async () => {
      const widget = await DashboardService.createWidget(
        projectId,
        {
          ...baseWidgetInput,
          metrics: [{ measure: "traceId", agg: "uniq" }],
        },
        userId,
      );

      expect(widget.minVersion).toBe(2);

      const updated = await DashboardService.updateWidget(
        projectId,
        widget.id,
        { ...baseWidgetInput, name: "Updated Widget" },
        userId,
      );

      expect(updated).toMatchObject({
        minVersion: 2,
        name: "Updated Widget",
      });

      sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE = "legacy";
      const healed = await DashboardService.updateWidget(
        projectId,
        widget.id,
        baseWidgetInput,
        userId,
      );
      expect(healed.minVersion).toBe(1);
    });

    it("derives minVersion from the shape instead of v4 session state", async () => {
      sharedEnv.LANGFUSE_MIGRATION_V4_WRITE_MODE = "dual";
      const result = await makeCaller(true).dashboardWidgets.create({
        ...baseWidgetInput,
        view: "observations",
        projectId,
      });
      expect(result.widget.minVersion).toBe(1);
    });

    it("should preserve minVersion when copying widget to project", async () => {
      const sourceWidget = await prisma.dashboardWidget.create({
        data: {
          name: "Langfuse Widget",
          description: "A Langfuse-managed widget",
          view: DashboardWidgetViews.OBSERVATIONS,
          dimensions: [{ field: "name" }],
          metrics: [{ measure: "count", agg: "count" }],
          filters: [],
          chartType: "LINE_TIME_SERIES",
          chartConfig: { type: "LINE_TIME_SERIES" },
          minVersion: 2,
          projectId: null,
        },
      });

      const dashboard = await DashboardService.createDashboard(
        projectId,
        "Test Dashboard",
        "A test dashboard",
        userId,
      );

      const placementId = "placement-1";
      await DashboardService.updateDashboardDefinition(
        dashboard.id,
        projectId,
        {
          widgets: [
            {
              type: "widget" as const,
              id: placementId,
              widgetId: sourceWidget.id,
              x: 0,
              y: 0,
              x_size: 6,
              y_size: 4,
            },
          ],
        },
        userId,
      );

      const newWidgetId = await DashboardService.copyWidgetToProject({
        sourceWidgetId: sourceWidget.id,
        projectId,
        dashboardId: dashboard.id,
        placementId,
        userId: userId,
      });

      const copiedWidget = await DashboardService.getWidget(
        newWidgetId,
        projectId,
      );

      expect(copiedWidget).not.toBeNull();
      expect(copiedWidget!.minVersion).toBe(2);
      expect(copiedWidget!.owner).toBe("PROJECT");
    });

    it("should round-trip preset placements in the dashboard definition", async () => {
      const dashboard = await DashboardService.createDashboard(
        projectId,
        "Preset Dashboard",
        "A dashboard mixing widget and preset placements",
        userId,
      );

      const definition = {
        widgets: [
          {
            type: "widget" as const,
            id: "placement-widget",
            widgetId: uuidv4(),
            x: 0,
            y: 0,
            x_size: 6,
            y_size: 4,
          },
          {
            type: "preset" as const,
            id: "placement-preset",
            presetId: "home-traces",
            x: 6,
            y: 0,
            x_size: 6,
            y_size: 4,
          },
        ],
      };

      await DashboardService.updateDashboardDefinition(
        dashboard.id,
        projectId,
        definition,
        userId,
      );

      const fetched = await DashboardService.getDashboard(
        dashboard.id,
        projectId,
      );

      expect(fetched).not.toBeNull();
      expect(fetched!.definition.widgets).toEqual(definition.widgets);
    });
  });

  describe("home dashboard pointer", () => {
    beforeAll(async () => {
      // The worker upserts the curated Home dashboard at startup; ensure it
      // exists in this test database.
      await prisma.dashboard.upsert({
        where: { id: LANGFUSE_HOME_DASHBOARD_ID },
        update: {},
        create: {
          id: LANGFUSE_HOME_DASHBOARD_ID,
          projectId: null,
          name: "Langfuse Home",
          description: "Curated home dashboard",
          definition: LANGFUSE_HOME_DASHBOARD_DEFINITION,
        },
      });
    });

    afterEach(async () => {
      // Pointer state is project-level; reset so tests stay independent.
      await prisma.project.update({
        where: { id: projectId },
        data: { homeDashboardId: null },
      });
    });

    it("falls back to the curated default when no pointer is set", async () => {
      const caller = makeCaller();

      const res = await caller.dashboard.getHomeDashboard({ projectId });

      expect(res.homeDashboardId).toBeNull();
      expect(res.dashboard?.id).toBe(LANGFUSE_HOME_DASHBOARD_ID);
      expect(res.dashboard?.owner).toBe("LANGFUSE");
    });

    it("resolves a set pointer and clears back to the default", async () => {
      const caller = makeCaller();
      const dashboard = await DashboardService.createDashboard(
        projectId,
        "My Home",
        "Project home dashboard",
        userId,
      );

      await caller.dashboard.setHomeDashboard({
        projectId,
        dashboardId: dashboard.id,
      });
      const res = await caller.dashboard.getHomeDashboard({ projectId });
      expect(res.homeDashboardId).toBe(dashboard.id);
      expect(res.dashboard?.id).toBe(dashboard.id);
      expect(res.dashboard?.owner).toBe("PROJECT");

      await caller.dashboard.setHomeDashboard({ projectId, dashboardId: null });
      const cleared = await caller.dashboard.getHomeDashboard({ projectId });
      expect(cleared.homeDashboardId).toBeNull();
      expect(cleared.dashboard?.id).toBe(LANGFUSE_HOME_DASHBOARD_ID);
    });

    it("rejects pointing at a nonexistent dashboard", async () => {
      const caller = makeCaller();

      await expect(
        caller.dashboard.setHomeDashboard({
          projectId,
          dashboardId: uuidv4(),
        }),
      ).rejects.toThrow("Dashboard not found");
    });

    it("falls back to the curated default when the pointed dashboard is deleted", async () => {
      const caller = makeCaller();
      const dashboard = await DashboardService.createDashboard(
        projectId,
        "Doomed Home",
        "Will be deleted",
        userId,
      );
      await caller.dashboard.setHomeDashboard({
        projectId,
        dashboardId: dashboard.id,
      });

      await DashboardService.deleteDashboard(dashboard.id, projectId);

      // The FK is ON DELETE SET NULL, so the pointer clears at the DB level.
      const res = await caller.dashboard.getHomeDashboard({ projectId });
      expect(res.homeDashboardId).toBeNull();
      expect(res.dashboard?.id).toBe(LANGFUSE_HOME_DASHBOARD_ID);
    });

    it("numbers clone names when copies already exist", async () => {
      const caller = makeCaller();
      const source = await DashboardService.createDashboard(
        projectId,
        "Numbering Source",
        "Clone naming test",
        userId,
      );

      const first = await caller.dashboard.cloneDashboard({
        projectId,
        dashboardId: source.id,
      });
      const second = await caller.dashboard.cloneDashboard({
        projectId,
        dashboardId: source.id,
      });
      const third = await caller.dashboard.cloneDashboard({
        projectId,
        dashboardId: source.id,
      });

      expect(first.name).toBe("Numbering Source (Clone)");
      expect(second.name).toBe("Numbering Source (Clone 2)");
      expect(third.name).toBe("Numbering Source (Clone 3)");
    });

    it("clones with a definition override and sets the clone as home", async () => {
      const caller = makeCaller();
      const overrideDefinition = {
        widgets: [
          {
            type: "preset" as const,
            id: "home-traces",
            presetId: "home-traces",
            x: 0,
            y: 0,
            x_size: 6,
            y_size: 4,
          },
        ],
      };

      const clone = await caller.dashboard.cloneDashboard({
        projectId,
        dashboardId: LANGFUSE_HOME_DASHBOARD_ID,
        definition: overrideDefinition,
        setAsHome: true,
      });

      expect(clone.owner).toBe("PROJECT");
      expect(clone.definition.widgets).toEqual(overrideDefinition.widgets);

      const res = await caller.dashboard.getHomeDashboard({ projectId });
      expect(res.homeDashboardId).toBe(clone.id);
      expect(res.dashboard?.id).toBe(clone.id);
    });
  });

  // ── tRPC measure-aggregation validation ──────────────────────────────
  // Note: basic CRUD and minVersion round-trips are covered by the
  // DashboardService tests above. These tests exercise the
  // validateMetricAggregations guard that lives in the tRPC router.

  describe("tRPC measure-aggregation validation", () => {
    it("should return stored metrics from get without additional client-side parsing", async () => {
      const caller = makeCaller();
      const created = await caller.dashboardWidgets.create({
        projectId,
        name: "Get Widget",
        description: "fetch metrics unchanged",
        view: "observations",
        dimensions: [],
        metrics: [{ measure: "count", agg: "count" }],
        filters: [],
        chartType: "NUMBER",
        chartConfig: { type: "NUMBER" },
      });

      const fetched = await caller.dashboardWidgets.get({
        projectId,
        widgetId: created.widget.id,
      });

      expect(fetched.metrics).toEqual([{ measure: "count", agg: "count" }]);
    });

    it("should reject invalid aggregation on a string measure", async () => {
      const caller = makeCaller();
      await expect(
        caller.dashboardWidgets.create({
          projectId,
          name: "Invalid Widget",
          description: "histogram on traceId",
          view: "observations",
          dimensions: [],
          metrics: [{ measure: "traceId", agg: "histogram" }],
          filters: [],
          chartType: "HISTOGRAM",
          chartConfig: { type: "HISTOGRAM", bins: 10 },
        }),
      ).rejects.toThrow(/not valid for measure/);
    });

    it("should allow creating a widget with uniq on a string measure", async () => {
      const caller = makeCaller();
      const result = await caller.dashboardWidgets.create({
        projectId,
        name: "Valid traceId Widget",
        description: "uniq on traceId",
        view: "observations",
        dimensions: [],
        metrics: [{ measure: "traceId", agg: "uniq" }],
        filters: [],
        chartType: "NUMBER",
        chartConfig: { type: "NUMBER" },
      });

      expect(result.success).toBe(true);
    });

    it("should reject updating a valid widget to an invalid aggregation", async () => {
      const caller = makeCaller();
      const created = await caller.dashboardWidgets.create({
        projectId,
        name: "Widget to update",
        description: "will try invalid update",
        view: "observations",
        dimensions: [],
        metrics: [{ measure: "traceId", agg: "uniq" }],
        filters: [],
        chartType: "NUMBER",
        chartConfig: { type: "NUMBER" },
      });

      await expect(
        caller.dashboardWidgets.update({
          projectId,
          widgetId: created.widget.id,
          name: "Widget to update",
          description: "invalid aggregation",
          view: "observations",
          dimensions: [],
          metrics: [{ measure: "traceId", agg: "sum" }],
          filters: [],
          chartType: "NUMBER",
          chartConfig: { type: "NUMBER" },
        }),
      ).rejects.toThrow(/not valid for measure/);
    });

    it("should allow numeric measures with any aggregation", async () => {
      const caller = makeCaller();
      const result = await caller.dashboardWidgets.create({
        projectId,
        name: "Numeric Widget",
        description: "histogram on latency",
        view: "observations",
        dimensions: [],
        metrics: [{ measure: "latency", agg: "histogram" }],
        filters: [],
        chartType: "HISTOGRAM",
        chartConfig: { type: "HISTOGRAM", bins: 10 },
      });

      expect(result.success).toBe(true);
    });
  });

  // ── tRPC uiHidden dimension validation ────────────────────────────────

  describe("tRPC uiHidden dimension validation", () => {
    it.each([
      ["id", true],
      ["traceId", true],
      ["parentObservationId", true],
      ["isRootObservation", true],
      ["name", false],
    ])(
      "create with dimension '%s' on shape-required v2 observations → rejected=%s",
      async (field, shouldReject) => {
        const caller = makeCaller();
        const promise = caller.dashboardWidgets.create({
          projectId,
          name: "uiHidden test widget",
          description: `${field} dimension on v2`,
          view: "observations",
          dimensions: [{ field }],
          metrics: [{ measure: "traceId", agg: "uniq" }],
          filters: [],
          chartType: "NUMBER",
          chartConfig: { type: "NUMBER" },
        });

        if (shouldReject) {
          await expect(promise).rejects.toThrow(/not available for widgets/);
        } else {
          await expect(promise).resolves.toMatchObject({ success: true });
        }
      },
    );

    it("should validate uiHidden dimensions on update mutation", async () => {
      const caller = makeCaller();
      const created = await caller.dashboardWidgets.create({
        projectId,
        name: "Widget to update",
        description: "will try hidden dim update",
        view: "observations",
        dimensions: [{ field: "name" }],
        metrics: [{ measure: "traceId", agg: "uniq" }],
        filters: [],
        chartType: "NUMBER",
        chartConfig: { type: "NUMBER" },
      });

      await expect(
        caller.dashboardWidgets.update({
          projectId,
          widgetId: created.widget.id,
          name: "Widget to update",
          description: "hidden dim update",
          view: "observations",
          dimensions: [{ field: "id" }],
          metrics: [{ measure: "count", agg: "count" }],
          filters: [],
          chartType: "NUMBER",
          chartConfig: { type: "NUMBER" },
        }),
      ).rejects.toThrow(/not available for widgets/);
    });

    it.each([undefined, 1])(
      "rejects isRootObservation as a breakdown when minVersion is %s",
      async (minVersion) => {
        const caller = makeCaller();

        await expect(
          caller.dashboardWidgets.create({
            projectId,
            name: "semantic root breakdown",
            description: "root status is filter-only",
            view: "observations",
            dimensions: [{ field: "isRootObservation" }],
            metrics: [{ measure: "count", agg: "count" }],
            filters: [],
            chartType: "NUMBER",
            chartConfig: { type: "NUMBER" },
            ...(minVersion === undefined ? {} : { minVersion }),
          }),
        ).rejects.toThrow(/not available for widgets/);
      },
    );
  });
});
