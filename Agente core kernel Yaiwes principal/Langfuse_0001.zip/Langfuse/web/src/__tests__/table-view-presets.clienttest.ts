// @vitest-environment node

import {
  validateOrderBy,
  validateFilters,
} from "@/src/components/table/table-view-presets/validation";
import {
  type ColumnDefinition,
  type FilterState,
  type OrderByState,
} from "@langfuse/shared";

// Mock data for testing
const mockColumns = [
  { id: "name", enableSorting: true, accessorKey: "name" },
  { id: "traceName", enableSorting: true, accessorKey: "traceName" },
  { id: "status", enableSorting: true, accessorKey: "status" },
  { id: "age", enableSorting: false, accessorKey: "age" },
];

const mockTraceTableColumns = [
  { id: "name", enableSorting: true, accessorKey: "name" },
  { id: "status", enableSorting: true, accessorKey: "status" },
];

const mockFilterDefinitions: ColumnDefinition[] = [
  {
    id: "traceName",
    name: "Name",
    type: "string",
    internal: "name",
    aliases: ["name"],
  },
  { id: "status", name: "status", type: "string", internal: "status" },
  { id: "city", name: "city", type: "string", internal: "city" },
  {
    id: "traceTags",
    name: "Tags",
    type: "arrayOptions",
    internal: "tags",
    options: [],
    aliases: ["tags"],
  },
];

describe("table view presets validation functions", () => {
  describe("validateOrderBy", () => {
    it("should return null if orderBy is null", () => {
      expect(validateOrderBy(null, mockColumns)).toBeNull();
    });

    it("should return null if columns are empty", () => {
      expect(validateOrderBy({ column: "name", order: "ASC" }, [])).toBeNull();
    });

    it("should return orderBy if column exists and supports sorting", () => {
      const orderBy: OrderByState = { column: "name", order: "ASC" };
      expect(validateOrderBy(orderBy, mockColumns)).toEqual(orderBy);
    });

    it("should normalize legacy orderBy columns via aliases", () => {
      const orderBy: OrderByState = { column: "traceName", order: "ASC" };
      expect(
        validateOrderBy(orderBy, mockTraceTableColumns, mockFilterDefinitions),
      ).toEqual({
        column: "name",
        order: "ASC",
      });
    });

    it("should return null if column does not exist", () => {
      const orderBy: OrderByState = { column: "nonexistent", order: "ASC" };
      expect(validateOrderBy(orderBy, mockColumns)).toBeNull();
    });

    it("should return null if column exists but does not support sorting", () => {
      const orderBy: OrderByState = { column: "age", order: "ASC" };
      expect(validateOrderBy(orderBy, mockColumns)).toBeNull();
    });

    it("should find a sortable column nested inside a column group", () => {
      // e.g. the events table nests totalTokens under a "Usage" group def; a
      // flat lookup dropped the saved orderBy of any view sorting by it.
      const groupedColumns = [
        { id: "name", enableSorting: true, accessorKey: "name" },
        {
          id: "usage",
          accessorKey: "usage",
          columns: [
            {
              id: "totalTokens",
              enableSorting: true,
              accessorKey: "totalTokens",
            },
            { id: "inputTokens", enableSorting: false, accessorKey: "input" },
          ],
        },
      ];
      const orderBy: OrderByState = { column: "totalTokens", order: "DESC" };
      expect(validateOrderBy(orderBy, groupedColumns)).toEqual(orderBy);
      // A nested column that opts out of sorting still returns null.
      expect(
        validateOrderBy(
          { column: "inputTokens", order: "DESC" },
          groupedColumns,
        ),
      ).toBeNull();
    });
  });

  describe("validateFilters", () => {
    it("should return all filters if filter definitions are empty", () => {
      const filters: FilterState = [
        {
          type: "string",
          value: "John",
          column: "name",
          operator: "=",
        },
      ];

      expect(validateFilters(filters, [])).toEqual(filters);
    });

    it("should filter out invalid columns", () => {
      const filters: FilterState = [
        {
          type: "string",
          value: "John",
          column: "name",
          operator: "=",
        },
        {
          type: "string",
          value: "New York",
          column: "nonexistent",
          operator: "=",
        },
      ];
      const expected = [
        {
          type: "string",
          value: "John",
          column: "traceName",
          operator: "=",
        },
      ];
      expect(validateFilters(filters, mockFilterDefinitions)).toEqual(expected);
    });

    it("should match on both id and name", () => {
      const filters: FilterState = [
        {
          type: "string",
          value: "John",
          column: "traceName",
          operator: "=",
        },
        {
          type: "string",
          value: "New York",
          column: "city",
          operator: "=",
        },
      ];
      expect(validateFilters(filters, mockFilterDefinitions)).toEqual(filters);
    });

    it("should normalize legacy aliases to canonical trace filter ids", () => {
      const filters: FilterState = [
        {
          type: "string",
          value: "John",
          column: "name",
          operator: "=",
        },
        {
          type: "arrayOptions",
          value: ["prod"],
          column: "tags",
          operator: "any of",
        },
      ];

      expect(validateFilters(filters, mockFilterDefinitions)).toEqual([
        {
          type: "string",
          value: "John",
          column: "traceName",
          operator: "=",
        },
        {
          type: "arrayOptions",
          value: ["prod"],
          column: "traceTags",
          operator: "any of",
        },
      ]);
    });

    it("should return empty array if no filters are valid", () => {
      const filters: FilterState = [
        {
          type: "string",
          value: "value1",
          column: "nonexistent1",
          operator: "=",
        },
        {
          type: "string",
          value: "value2",
          column: "nonexistent2",
          operator: "=",
        },
      ];
      expect(validateFilters(filters, mockFilterDefinitions)).toEqual([]);
    });
  });
});
