import { prisma } from "@langfuse/shared/src/db";
import {
  getObservationsFromEventsTableForPublicApi,
  getObservationsCountFromEventsTableForPublicApi,
} from "@langfuse/shared/src/server";

import {
  LEGACY_PUBLIC_API_OBSERVATIONS_CLICKHOUSE_RESOURCE_ERROR_MESSAGE,
  withMiddlewares,
} from "@/src/features/public-api/server/withMiddlewares";
import { createAuthedProjectAPIRoute } from "@/src/features/public-api/server/createAuthedProjectAPIRoute";

import {
  GetObservationsV1Query,
  GetObservationsV1Response,
  transformDbToApiObservation,
} from "@/src/features/public-api/types/observations";
import {
  generateObservationsForPublicApi,
  getObservationsCountForPublicApi,
} from "@/src/features/public-api/server/observations";
import { legacyPublicApiRateLimitUpgradePaths } from "@/src/features/public-api/server/rateLimitUpgradePaths";
import { OBSERVATIONS_V1_DEPRECATION } from "@/src/features/public-api/server/deprecations";
import { clampToDataAccessDays } from "@/src/features/entitlements/server/hasEntitlementLimit";

export default withMiddlewares(
  {
    GET: createAuthedProjectAPIRoute({
      name: "Get Observations",
      allowInAppAgentKey: true,
      rateLimitResource: "public-api-legacy",
      querySchema: GetObservationsV1Query,
      responseSchema: GetObservationsV1Response,
      rateLimitUpgradePath:
        legacyPublicApiRateLimitUpgradePaths.observationsList,
      rejectInEventsOnlyMode: true,
      deprecation: OBSERVATIONS_V1_DEPRECATION,
      fn: async ({ query, auth }) => {
        const dataAccessWindow = clampToDataAccessDays({
          plan: auth.scope.plan,
          fromTimestamp: query.fromStartTime ?? undefined,
        });
        const advancedFilters = dataAccessWindow.accessFloor
          ? [
              ...(query.filter ?? []),
              {
                column: "startTime",
                operator: ">=" as const,
                value: dataAccessWindow.effectiveFromTimestamp!,
                type: "datetime" as const,
              },
              ...(query.toStartTime
                ? [
                    {
                      column: "startTime",
                      operator: "<" as const,
                      value: new Date(query.toStartTime),
                      type: "datetime" as const,
                    },
                  ]
                : []),
            ]
          : query.filter;

        const filterProps = {
          projectId: auth.scope.projectId,
          page: query.page,
          limit: query.limit,
          traceId: query.traceId ?? undefined,
          userId: query.userId ?? undefined,
          level: query.level ?? undefined,
          name: query.name ?? undefined,
          type: query.type ?? undefined,
          environment: query.environment ?? undefined,
          parentObservationId: query.parentObservationId ?? undefined,
          fromStartTime: dataAccessWindow.effectiveFromTimestamp?.toISOString(),
          toStartTime: query.toStartTime ?? undefined,
          version: query.version ?? undefined,
          advancedFilters,
        };

        if (query.useEventsTable) {
          const [items, count] = await Promise.all([
            getObservationsFromEventsTableForPublicApi(filterProps),
            getObservationsCountFromEventsTableForPublicApi(filterProps),
          ]);

          return {
            data: items.map(transformDbToApiObservation),
            meta: {
              page: query.page,
              limit: query.limit,
              totalItems: count,
              totalPages: Math.ceil(count / query.limit),
            },
          };
        }

        // Legacy code path using observations table
        const [items, count] = await Promise.all([
          generateObservationsForPublicApi(filterProps),
          getObservationsCountForPublicApi(filterProps),
        ]);
        const uniqueModels: string[] = Array.from(
          new Set(
            items
              .map((r) => r.internalModelId)
              .filter((r): r is string => Boolean(r)),
          ),
        );

        const models =
          uniqueModels.length > 0
            ? await prisma.model.findMany({
                where: {
                  id: {
                    in: uniqueModels,
                  },
                  OR: [
                    { projectId: auth.scope.projectId },
                    { projectId: null },
                  ],
                },
                include: {
                  Price: {
                    where: { pricingTier: { isDefault: true } },
                  },
                },
              })
            : [];
        const finalCount = count ? count : 0;

        return {
          data: items
            .map((i) => {
              const model = models.find((m) => m.id === i.internalModelId);
              return {
                ...i,
                modelId: model?.id ?? null,
                inputPrice:
                  model?.Price?.find((m) => m.usageType === "input")?.price ??
                  null,
                outputPrice:
                  model?.Price?.find((m) => m.usageType === "output")?.price ??
                  null,
                totalPrice:
                  model?.Price?.find((m) => m.usageType === "total")?.price ??
                  null,
              };
            })
            .map(transformDbToApiObservation),
          meta: {
            page: query.page,
            limit: query.limit,
            totalItems: finalCount,
            totalPages: Math.ceil(finalCount / query.limit),
          },
        };
      },
    }),
  },
  {
    clickHouseResourceErrorMessage:
      LEGACY_PUBLIC_API_OBSERVATIONS_CLICKHOUSE_RESOURCE_ERROR_MESSAGE,
  },
);
