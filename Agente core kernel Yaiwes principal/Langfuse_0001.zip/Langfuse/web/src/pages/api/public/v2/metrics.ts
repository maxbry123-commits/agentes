import { withMiddlewares } from "@/src/features/public-api/server/withMiddlewares";
import { createAuthedProjectAPIRoute } from "@/src/features/public-api/server/createAuthedProjectAPIRoute";
import { env } from "@/src/env.mjs";
import { logger } from "@langfuse/shared/src/server";
import {
  GetMetricsV2Query,
  GetMetricsV2Response,
} from "@/src/features/public-api/types/metrics";
import { InvalidRequestError, LangfuseNotFoundError } from "@langfuse/shared";
import { executeQuery } from "@langfuse/shared/query/server";
import { validateQuery } from "@langfuse/shared/query";
import { clampToDataAccessDays } from "@/src/features/entitlements/server/hasEntitlementLimit";
const DEFAULT_ROW_LIMIT = 100;

export function isMetricsV2Available(): boolean {
  return (
    env.LANGFUSE_MIGRATION_V4_ALLOW_PREVIEW_OPT_IN === "true" &&
    env.LANGFUSE_MIGRATION_V4_WRITE_MODE !== "legacy"
  );
}

export default withMiddlewares({
  GET: createAuthedProjectAPIRoute({
    name: "Get Metrics V2",
    rateLimitResource: "public-api-v2-metrics",
    querySchema: GetMetricsV2Query,
    responseSchema: GetMetricsV2Response,
    fn: async ({ query, auth }) => {
      if (!isMetricsV2Available()) {
        throw new LangfuseNotFoundError(
          "The metrics v2 API is only available in a Langfuse v4 write mode. Learn more at: https://langfuse.com/docs/v4",
        );
      }

      try {
        const dataAccessWindow = clampToDataAccessDays({
          plan: auth.scope.plan,
          fromTimestamp: query.query.fromTimestamp,
        });
        const effectiveQuery = {
          ...query.query,
          fromTimestamp:
            dataAccessWindow.effectiveFromTimestamp?.toISOString() ??
            query.query.fromTimestamp,
        };

        // Validate query (high cardinality checks) BEFORE applying defaults
        // This ensures users must explicitly opt-in with row_limit for high cardinality queries
        const validation = validateQuery(effectiveQuery as any, "v2");

        if (!validation.valid) {
          throw new InvalidRequestError(validation.reason);
        }

        // Apply default row_limit AFTER validation
        const queryParams = {
          ...effectiveQuery,
          config: {
            ...effectiveQuery.config,
            row_limit: effectiveQuery.config?.row_limit ?? DEFAULT_ROW_LIMIT,
          },
        };

        logger.info("Received v2 metrics query", {
          query: queryParams,
          version: "v2",
          projectId: auth.scope.projectId,
        });

        // Explicitly use v2 (events table)
        const result = await executeQuery(
          auth.scope.projectId,
          queryParams,
          "v2",
          true /* always enable single-level SELECT optimization for public API v2 */,
        );

        return { data: result };
      } catch (error) {
        logger.error("Error in v2 metrics API", { error, query });
        throw error;
      }
    },
  }),
});
