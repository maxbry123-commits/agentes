import { DatasetRunsTable } from "@/src/features/datasets/components/DatasetRunsTable";
import { api } from "@/src/utils/api";
import { useRouter } from "next/router";
import Link from "next/link";
import { DetailPageNav } from "@/src/features/navigate-detail-pages/DetailPageNav";
import { UpdateDatasetDialogController } from "@/src/features/datasets/components/UpdateDatasetDialogController";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItemWithSecondaryAction,
  DropdownMenuTrigger,
  DropdownMenuItem,
} from "@/src/components/ui/dropdown-menu";
import { DeleteDatasetButton } from "@/src/components/deleteButton";
import { DuplicateDatasetButton } from "@/src/features/datasets/components/DuplicateDatasetButton";
import { useState, useCallback } from "react";
import { Bot, Edit, FlaskConical, LockIcon, MoreVertical } from "lucide-react";
import { useHasProjectAccess } from "@/src/features/rbac/utils/checkProjectAccess";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/src/components/ui/dialog";
import { Button } from "@/src/components/ui/button";
import { CreateExperimentsForm } from "@/src/features/experiments/components/CreateExperimentsForm";
import { showSuccessToast } from "@/src/features/notifications/showSuccessToast";
import { DatasetAnalytics } from "@/src/features/datasets/components/DatasetAnalytics";
import { RESOURCE_METRICS } from "@/src/features/dashboard/lib/score-analytics-utils";
import { usePostHogClientCapture } from "@/src/features/posthog-analytics/usePostHogClientCapture";
import Page from "@/src/components/layouts/page";
import {
  getDatasetTabs,
  DATASET_TABS,
} from "@/src/features/navigation/utils/dataset-tabs";
import { TemplateSelector } from "@/src/features/evals/components/template-selector";
import { useEvaluatorDefaults } from "@/src/features/experiments/hooks/useEvaluatorDefaults";
import { useExperimentEvaluatorData } from "@/src/features/experiments/hooks/useExperimentEvaluatorData";
import { useExperimentAccess } from "@/src/features/experiments/hooks/useExperimentAccess";
import { EvaluatorForm } from "@/src/features/evals/components/evaluator-form";
import useLocalStorage from "@/src/components/useLocalStorage";
import { getDatasetBreadcrumb } from "@/src/features/datasets/utils/getDatasetBreadcrumb";
import { ExperimentsTable } from "@/src/features/experiments/components/table";
import { singleRunToExperimentsUrl } from "@/src/features/experiments/utils/experimentUrlTranslation";
import { Skeleton } from "@/src/components/ui/skeleton";

export default function Dataset() {
  const router = useRouter();
  const capture = usePostHogClientCapture();
  const projectId = router.query.projectId as string;
  const datasetId = router.query.datasetId as string;
  const utils = api.useUtils();
  const [isCreateExperimentDialogOpen, setIsCreateExperimentDialogOpen] =
    useState(false);
  const [selectedMetrics, setSelectedMetrics] = useLocalStorage<string[]>(
    `${projectId}-${datasetId}-chart-metrics`,
    RESOURCE_METRICS.map((metric) => metric.key),
  );

  const [scoreOptions, setScoreOptions] = useState<
    {
      key: string;
      value: string;
    }[]
  >([]);

  const dataset = api.datasets.byId.useQuery({
    datasetId,
    projectId,
  });

  const hasReadAccess = useHasProjectAccess({
    projectId,
    scope: "evalJobExecution:read",
  });

  const hasExperimentWriteAccess = useHasProjectAccess({
    projectId,
    scope: "promptExperiments:CUD",
  });
  const { isExperimentsBetaActive, isInitializing } = useExperimentAccess();

  const handleExperimentSuccess = async (data?: {
    success: boolean;
    datasetId: string;
    runId: string;
    runName: string;
  }) => {
    setIsCreateExperimentDialogOpen(false);
    if (!data) return;

    if (isExperimentsBetaActive) {
      utils.experiments.all.invalidate();
      utils.experiments.countAll.invalidate();
    } else {
      utils.datasets.runsByDatasetId.invalidate();
      utils.datasets.baseRunDataByDatasetId.invalidate();
    }

    showSuccessToast({
      title: "Experiment triggered successfully",
      description: "Waiting for experiment to complete...",
      link: {
        text: "View experiment",
        href: isExperimentsBetaActive
          ? singleRunToExperimentsUrl(projectId, data.runId)
          : `/project/${projectId}/datasets/${data.datasetId}/compare?runs=${data.runId}`,
      },
    });
  };

  const hasEvaluationRuleReadAccess = useHasProjectAccess({
    projectId,
    scope: "evaluationRule:read",
  });

  const hasEvaluationRuleWriteAccess = useHasProjectAccess({
    projectId,
    scope: "evaluationRule:CUD",
  });

  const hasEvaluatorReadAccess = useHasProjectAccess({
    projectId,
    scope: "evaluator:read",
  });

  const evalTemplates = api.evals.latestTemplates.useQuery(
    { projectId },
    { enabled: !isExperimentsBetaActive && hasEvaluatorReadAccess },
  );

  const evaluators = api.evals.jobConfigsByTarget.useQuery(
    { projectId, targetObject: ["dataset", "experiment"] },
    {
      enabled:
        !isExperimentsBetaActive && hasEvaluationRuleReadAccess && !!datasetId,
    },
  );

  const { createDefaultEvaluator } = useEvaluatorDefaults();

  const {
    selectedEvaluatorData,
    showEvaluatorForm,
    handleConfigureEvaluator,
    handleCloseEvaluatorForm,
    handleEvaluatorSuccess,
    handleSelectEvaluator,
  } = useExperimentEvaluatorData({
    datasetId,
    createDefaultEvaluator,
    evaluatorsData: evaluators.data,
    evalTemplatesData: evalTemplates.data,
    refetchEvaluators: evaluators.refetch,
  });
  // Callback for preprocessing evaluator form values
  // For experiment evaluators, we only run on new data (not historic)
  const preprocessFormValues = useCallback((values: any) => values, []);

  const breadcrumb = getDatasetBreadcrumb(
    projectId,
    datasetId,
    dataset.data?.name,
  );

  if (isInitializing) {
    return <Skeleton className="h-full w-full" />;
  }

  if (isExperimentsBetaActive) {
    return (
      <Page
        headerProps={{
          title: dataset.data?.name ?? "",
          itemType: "DATASET",
          breadcrumb,
          tabsProps: {
            tabs: getDatasetTabs(projectId, datasetId),
            activeTab: DATASET_TABS.EXPERIMENTS,
          },
          actionButtonsRight: (
            <>
              <Dialog
                open={isCreateExperimentDialogOpen}
                onOpenChange={setIsCreateExperimentDialogOpen}
              >
                <DialogTrigger asChild disabled={!hasExperimentWriteAccess}>
                  <Button
                    disabled={!hasExperimentWriteAccess}
                    onClick={() => capture("dataset_run:new_form_open")}
                  >
                    <FlaskConical className="h-4 w-4" />
                    <span className="ml-2 hidden md:block">Run experiment</span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
                  <CreateExperimentsForm
                    key={`create-experiment-form-${datasetId}`}
                    projectId={projectId as string}
                    setFormOpen={setIsCreateExperimentDialogOpen}
                    defaultValues={{
                      datasetId,
                    }}
                    handleExperimentSuccess={handleExperimentSuccess}
                    showSDKRunInfoPage
                  />
                </DialogContent>
              </Dialog>
            </>
          ),
        }}
      >
        <ExperimentsTable
          projectId={projectId}
          fixedFilter={[
            {
              column: "experimentDatasetId",
              type: "stringOptions",
              operator: "any of",
              value: [datasetId],
            },
          ]}
          sessionFilterContextId={`dataset-${datasetId}`}
          showControlsInPageHeader
        />
      </Page>
    );
  }

  return (
    <Page
      headerProps={{
        title: dataset.data?.name ?? "",
        itemType: "DATASET",
        breadcrumb,
        help: dataset.data?.description
          ? {
              description: dataset.data.description,
            }
          : undefined,
        tabsProps: {
          tabs: getDatasetTabs(projectId, datasetId),
          activeTab: DATASET_TABS.EXPERIMENTS,
        },
        actionButtonsRight: (
          <>
            <Dialog
              open={isCreateExperimentDialogOpen}
              onOpenChange={setIsCreateExperimentDialogOpen}
            >
              <DialogTrigger asChild disabled={!hasExperimentWriteAccess}>
                <Button
                  disabled={!hasExperimentWriteAccess}
                  onClick={() => capture("dataset_run:new_form_open")}
                >
                  <FlaskConical className="h-4 w-4" />
                  <span className="ml-2 hidden md:block">Run experiment</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
                <CreateExperimentsForm
                  key={`create-experiment-form-${datasetId}`}
                  projectId={projectId as string}
                  setFormOpen={setIsCreateExperimentDialogOpen}
                  defaultValues={{
                    datasetId,
                  }}
                  handleExperimentSuccess={handleExperimentSuccess}
                  showSDKRunInfoPage
                />
              </DialogContent>
            </Dialog>

            {hasEvaluationRuleReadAccess && hasEvaluatorReadAccess ? (
              <div className="w-fit">
                <TemplateSelector
                  projectId={projectId}
                  datasetId={datasetId}
                  evalTemplates={evalTemplates.data?.templates ?? []}
                  onConfigureTemplate={handleConfigureEvaluator}
                  onSelectEvaluator={handleSelectEvaluator}
                  disabled={!hasEvaluationRuleWriteAccess}
                />
              </div>
            ) : null}

            <DatasetAnalytics
              key="dataset-analytics"
              scoreOptions={scoreOptions}
              selectedMetrics={selectedMetrics}
              setSelectedMetrics={setSelectedMetrics}
            />

            <DetailPageNav
              currentId={datasetId}
              path={(entry) =>
                `/project/${projectId}/datasets/${entry.id}/experiments`
              }
              listKey="datasets"
            />
            <UpdateDatasetDialogController
              projectId={projectId}
              datasetId={datasetId}
              datasetName={dataset.data?.name ?? ""}
              datasetDescription={dataset.data?.description ?? undefined}
              datasetMetadata={dataset.data?.metadata}
              datasetInputSchema={dataset.data?.inputSchema ?? undefined}
              datasetExpectedOutputSchema={
                dataset.data?.expectedOutputSchema ?? undefined
              }
              source="dataset"
            >
              {({ disabled, openDialog }) => (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="flex flex-col *:w-full *:justify-start">
                    <DropdownMenuItemWithSecondaryAction
                      disabled={disabled}
                      icon={disabled === undefined ? Edit : LockIcon}
                      title="Edit"
                      onClick={openDialog}
                    />
                    <DropdownMenuItem asChild>
                      <DuplicateDatasetButton
                        datasetId={datasetId}
                        projectId={projectId}
                      />
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      asChild
                      onSelect={(event) => {
                        event.preventDefault();
                        return false;
                      }}
                    >
                      <DeleteDatasetButton
                        itemId={datasetId}
                        projectId={projectId}
                        redirectUrl={`/project/${projectId}/datasets`}
                        deleteConfirmation={dataset.data?.name}
                      />
                    </DropdownMenuItem>
                    {hasReadAccess && (
                      <DropdownMenuItem asChild>
                        <Link
                          href={`/project/${projectId}/evals?target=dataset`}
                        >
                          <Bot className="mr-2 ml-1 h-4 w-4" />
                          Manage Evaluators
                        </Link>
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </UpdateDatasetDialogController>
          </>
        ),
      }}
    >
      <DatasetRunsTable
        projectId={projectId}
        datasetId={datasetId}
        selectedMetrics={selectedMetrics}
        setScoreOptions={setScoreOptions}
      />
      {/* Dialog for configuring evaluators */}
      {selectedEvaluatorData && (
        <Dialog
          open={showEvaluatorForm}
          onOpenChange={(open) => {
            if (!open) {
              handleCloseEvaluatorForm();
            }
          }}
        >
          <DialogContent className="max-h-[90vh] max-w-(--breakpoint-md) overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedEvaluatorData.evaluator.id ? "Edit" : "Configure"}{" "}
                Evaluator
              </DialogTitle>
            </DialogHeader>
            <EvaluatorForm
              useDialog={true}
              projectId={projectId}
              evalTemplates={evalTemplates.data?.templates ?? []}
              templateId={selectedEvaluatorData.templateId}
              existingEvaluator={selectedEvaluatorData.evaluator}
              mode={selectedEvaluatorData.evaluator.id ? "edit" : "create"}
              hideTargetSection={!selectedEvaluatorData.evaluator.id}
              onFormSuccess={handleEvaluatorSuccess}
              preprocessFormValues={preprocessFormValues}
            />
          </DialogContent>
        </Dialog>
      )}
    </Page>
  );
}
