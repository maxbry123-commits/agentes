import { api } from "@/src/utils/api";
import {
  getDatasetTabs,
  DATASET_TABS,
} from "@/src/features/navigation/utils/dataset-tabs";
import { DatasetItemsTable } from "@/src/features/datasets/components/DatasetItemsTable";
import { DetailPageNav } from "@/src/features/navigate-detail-pages/DetailPageNav";
import { UpdateDatasetDialogController } from "@/src/features/datasets/components/UpdateDatasetDialogController";
import { DeleteDatasetButton } from "@/src/components/deleteButton";
import { NewDatasetItemButton } from "@/src/features/datasets/components/NewDatasetItemButton";
import { DuplicateDatasetButton } from "@/src/features/datasets/components/DuplicateDatasetButton";
import { UploadDatasetCsvButton } from "@/src/features/datasets/components/UploadDatasetCsvButton";
import { Button } from "@/src/components/ui/button";
import { Edit, History, LockIcon, MoreVertical } from "lucide-react";
import Page from "@/src/components/layouts/page";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuItemWithSecondaryAction,
} from "@/src/components/ui/dropdown-menu";
import { DatasetItemsOnboarding } from "@/src/components/onboarding/DatasetItemsOnboarding";
import { SidePanel, SidePanelContent } from "@/src/components/ui/side-panel";
import { DatasetVersionHistoryPanel } from "@/src/features/datasets/components/DatasetVersionHistoryPanel";
import { DatasetVersionWarningBanner } from "@/src/features/datasets/components/DatasetVersionWarningBanner";
import { useState } from "react";
import { useDatasetVersion } from "@/src/features/datasets/hooks/useDatasetVersion";
import { getDatasetBreadcrumb } from "@/src/features/datasets/utils/getDatasetBreadcrumb";
import {
  RouteParamsPendingFallback,
  useReadyRouteParams,
} from "@/src/hooks/useReadyRouteParams";

export default function DatasetItemsPage() {
  const route = useReadyRouteParams(["projectId", "datasetId"]);
  if (!route.ready) return <RouteParamsPendingFallback />;
  return (
    <DatasetItemsView
      projectId={route.params.projectId}
      datasetId={route.params.datasetId}
    />
  );
}

function DatasetItemsView({
  projectId,
  datasetId,
}: {
  projectId: string;
  datasetId: string;
}) {
  const { selectedVersion, resetToLatest } = useDatasetVersion();
  const isViewingOldVersion = selectedVersion !== null;

  const [isVersionPanelOpen, setIsVersionPanelOpen] = useState(false);

  const dataset = api.datasets.byId.useQuery(
    {
      datasetId,
      projectId,
    },
    { enabled: Boolean(projectId) && Boolean(datasetId) },
  );

  const totalDatasetItemCount = api.datasets.countItemsByDatasetId.useQuery(
    {
      projectId,
      datasetId,
    },
    { enabled: Boolean(projectId) && Boolean(datasetId) },
  );

  const showOnboarding =
    totalDatasetItemCount.isSuccess && totalDatasetItemCount.data === 0;

  // Fetch change counts since selected version
  const changeCounts = api.datasets.countChangesSinceVersion.useQuery(
    {
      projectId,
      datasetId,
      version: selectedVersion!,
    },
    {
      enabled: selectedVersion !== null,
    },
  );

  const handlePanelOpenChange = (open: boolean) => {
    setIsVersionPanelOpen(open);
  };

  const breadcrumb = getDatasetBreadcrumb(
    projectId,
    datasetId,
    dataset.data?.name,
  );

  return (
    <Page
      headerProps={{
        title: dataset.data?.name ?? "",
        itemType: "DATASET",
        breadcrumb,
        tabsProps: {
          tabs: getDatasetTabs(projectId, datasetId),
          activeTab: DATASET_TABS.ITEMS,
        },
        actionButtonsRight: (
          <>
            {!showOnboarding && (
              <>
                <NewDatasetItemButton
                  projectId={projectId}
                  datasetId={datasetId}
                />
                <UploadDatasetCsvButton
                  projectId={projectId}
                  datasetId={datasetId}
                />
              </>
            )}
            <DetailPageNav
              currentId={datasetId}
              path={(entry) =>
                `/project/${projectId}/datasets/${entry.id}/items/`
              }
              listKey="datasets"
            />
            <UpdateDatasetDialogController
              projectId={projectId}
              datasetId={datasetId}
              datasetName={dataset.data?.name ?? ""}
              datasetDescription={dataset.data?.description ?? undefined}
              datasetMetadata={dataset.data?.metadata}
              datasetInputSchema={dataset.data?.inputSchema ?? undefined}
              datasetExpectedOutputSchema={
                dataset.data?.expectedOutputSchema ?? undefined
              }
              source="dataset"
            >
              {({ disabled, openDialog }) => (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="flex flex-col *:w-full *:justify-start">
                    <DropdownMenuItemWithSecondaryAction
                      disabled={disabled}
                      icon={disabled === undefined ? Edit : LockIcon}
                      title="Edit"
                      onClick={openDialog}
                    />
                    <DropdownMenuItem asChild>
                      <DuplicateDatasetButton
                        datasetId={datasetId}
                        projectId={projectId}
                      />
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      asChild
                      onSelect={(event) => {
                        event.preventDefault();
                        return false;
                      }}
                    >
                      <DeleteDatasetButton
                        itemId={datasetId}
                        projectId={projectId}
                        redirectUrl={`/project/${projectId}/datasets`}
                        deleteConfirmation={dataset.data?.name}
                      />
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </UpdateDatasetDialogController>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsVersionPanelOpen(!isVersionPanelOpen)}
              title="Version History"
            >
              <History className="h-4 w-4" />
            </Button>
          </>
        ),
      }}
    >
      {showOnboarding ? (
        <DatasetItemsOnboarding projectId={projectId} datasetId={datasetId} />
      ) : (
        <div className="grid flex-1 grid-cols-[1fr_auto] overflow-hidden">
          <div className="flex h-full flex-col overflow-hidden">
            {isViewingOldVersion && selectedVersion && (
              <DatasetVersionWarningBanner
                selectedVersion={selectedVersion}
                resetToLatest={resetToLatest}
                changeCounts={changeCounts.data}
              />
            )}
            <DatasetItemsTable projectId={projectId} datasetId={datasetId} />
          </div>
          <SidePanel
            id="version-history-panel"
            openState={{
              open: isVersionPanelOpen,
              onOpenChange: handlePanelOpenChange,
            }}
            mobileTitle="Version History"
          >
            <SidePanelContent className="h-full">
              <DatasetVersionHistoryPanel
                projectId={projectId}
                datasetId={datasetId}
              />
            </SidePanelContent>
          </SidePanel>
        </div>
      )}
    </Page>
  );
}
