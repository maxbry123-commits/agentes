import { useRouter } from "next/router";
import Page from "@/src/components/layouts/page";
import { api } from "@/src/utils/api";
import { WidgetForm } from "@/src/features/widgets/components/WidgetForm";
import { type WidgetSavePayload } from "@/src/features/widgets/components/widgetFormSchema";
import { showErrorToast } from "@/src/features/notifications/showErrorToast";
import { showSuccessToast } from "@/src/features/notifications/showSuccessToast";
import { type metricAggregations, type views } from "@langfuse/shared/query";
import { type z } from "zod";
import { usePostHogClientCapture } from "@/src/features/posthog-analytics/usePostHogClientCapture";

export default function EditWidget() {
  const router = useRouter();
  const { projectId, widgetId, dashboardId } = router.query as {
    projectId: string;
    widgetId: string;
    dashboardId?: string;
  };

  // Fetch the widget details
  const utils = api.useUtils();
  const capture = usePostHogClientCapture();
  const { data: widgetData, isLoading: isWidgetLoading } =
    api.dashboardWidgets.get.useQuery(
      {
        projectId,
        widgetId,
      },
      {
        enabled: Boolean(projectId) && Boolean(widgetId),
      },
    );

  // Update widget mutation
  const updateWidgetMutation = api.dashboardWidgets.update.useMutation({
    onSettled: () => {
      utils.dashboardWidgets.invalidate();
    },
    onSuccess: (data, variables) => {
      // Which measure/aggregation/chart shapes do users actually save?
      capture("dashboard:widget_saved", {
        isNew: false,
        view: variables.view,
        chartType: variables.chartType,
        measures: variables.metrics.map((m) => `${m.agg}:${m.measure}`),
        dimensionCount: variables.dimensions.length,
        filterCount: variables.filters.length,
      });
      showSuccessToast({
        title: "Widget updated successfully",
        description: "Your widget has been updated.",
      });
      // Navigate back to dashboard if provided else widgets list
      if (dashboardId) {
        router.push(
          `/project/${projectId}/dashboards/${dashboardId}?addWidgetId=${widgetId}`,
        );
      } else {
        router.push(`/project/${projectId}/widgets`);
      }
    },
    onError: (error) => {
      showErrorToast("Failed to update widget", error.message);
    },
  });

  // Handle update widget
  const handleUpdateWidget = (widgetFormData: WidgetSavePayload) => {
    if (!widgetId) return;

    updateWidgetMutation.mutate({
      projectId,
      widgetId,
      name: widgetFormData.name,
      description: widgetFormData.description,
      view: widgetFormData.view as z.infer<typeof views>,
      dimensions: widgetFormData.dimensions,
      metrics: widgetFormData.metrics.map((metric) => ({
        measure: metric.measure,
        agg: metric.agg as z.infer<typeof metricAggregations>,
      })),
      filters: widgetFormData.filters,
      chartType: widgetFormData.chartType,
      chartConfig: widgetFormData.chartConfig,
    });
  };

  return (
    <Page
      withPadding
      headerProps={{
        title: "Edit Widget",
        help: {
          description: "Edit an existing widget",
        },
      }}
    >
      {!isWidgetLoading && widgetData ? (
        <WidgetForm
          // Remount when the edited widget changes so its loaded values seed
          // the form defaults once, rather than syncing via an effect.
          key={widgetId}
          projectId={projectId}
          widgetId={widgetId}
          onSave={handleUpdateWidget}
          initialValues={{
            name: widgetData.name,
            description: widgetData.description,
            view: widgetData.view as z.infer<typeof views>,
            // Pass complete arrays for editing mode
            metrics: widgetData.metrics,
            dimensions: widgetData.dimensions,
            // Keep single values for backward compatibility and fallbacks
            dimension: widgetData.dimensions.slice().shift()?.field ?? "none",
            measure: widgetData.metrics.slice().shift()?.measure ?? "count",
            aggregation:
              (widgetData.metrics.slice().shift()?.agg as z.infer<
                typeof metricAggregations
              >) ?? "count",
            filters: widgetData.filters,
            chartType: widgetData.chartType,
            chartConfig: widgetData.chartConfig,
            minVersion: widgetData.minVersion,
          }}
        />
      ) : (
        <div className="flex h-[300px] items-center justify-center">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      )}
    </Page>
  );
}
