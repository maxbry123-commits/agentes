# Agent Guidelines for `web`

## Purpose

- Next.js application with UI, tRPC backend, and public REST API routes.
- Check `web/package.json` for current Next.js, React, and tRPC versions before
  version-sensitive work.
- Primary package for frontend and most request/response surface changes.

## Maintenance Contract

- Update this file in the same PR when entry points, commands, or contracts
  change.

## High-Signal Entry Points

- App shell/providers: `src/pages/_app.tsx`
- tRPC context/procedures: `src/server/api/trpc.ts`
- tRPC router registry: `src/server/api/root.ts`
- tRPC routers: `src/server/api/routers/*`, `src/features/*/server/*`
- Public REST API routes: `src/pages/api/public/*`
- Unstable public eval APIs: `src/pages/api/public/unstable/{evaluators,evaluation-rules}/*`
- Feature modules: `src/features/*`
- Reusable UI components: `src/components/*`
- Tests:
  - Server integration tests: `src/__tests__/server/*.servertest.ts`
  - Server unit tests: `src/__tests__/server/unit/*.servertest.ts`
  - Client tests: `src/**/*.clienttest.ts(x)`
  - E2E: `src/__e2e__/*`

## Shared Package Imports

- Prefer `@langfuse/shared` in frontend-safe web code for shared types, zod
  schemas, domain contracts, table definitions, prompt/eval/model-pricing
  helpers, and other cross-runtime utilities.
- Use `@langfuse/shared/src/server` only from server-only web code such as
  `src/server/**`, `src/pages/api/**`, and server tests.
- Use `@langfuse/shared/src/db` only in backend or test code that needs direct
  Prisma access; never route it into client bundles.
- Use narrower subpaths such as `@langfuse/shared/src/env` or
  `@langfuse/shared/encryption` only when that focused surface is the clearest
  dependency.
- The in-app-agent execution runtime lives in the worker. Shared exposes its
  durable browser-safe contracts plus explicit server-only persistence,
  lifecycle, policy, tool-result, compaction, and prompt subpaths. Web owns the
  UI, IDs, feedback/source/rate-limit schemas, conversation access, tRPC run
  adapters, snapshot construction, watch framing/service, and the authenticated
  watch route in `src/app/api/in-app-agent/watch/`.
- See `../packages/shared/AGENTS.md` for the full shared export map and what
  each entrypoint contains.
- For the higher-level platform topology across web, worker, Postgres,
  ClickHouse, Redis, and S3, also read the architecture handbook:
  [langfuse.com/handbook/product-engineering/architecture](https://langfuse.com/handbook/product-engineering/architecture)
  with source markdown in
  `../langfuse-docs/content/handbook/product-engineering/architecture.mdx`
  (GitHub mirror:
  [architecture.mdx](https://github.com/langfuse/langfuse-docs/blob/4188c1ba453240c90a763a8067ef442d68839323/content/handbook/product-engineering/architecture.mdx#L4)).

## Package-Local Skills

- Shared browser-review workflow for user-visible frontend changes:
  [`../.agents/skills/frontend-browser-review/SKILL.md`](../.agents/skills/frontend-browser-review/SKILL.md)
- Large frontend feature, virtualized-list, local state, and React
  effect-free data-flow architecture:
  [`../.agents/skills/frontend-large-feature-architecture/SKILL.md`](../.agents/skills/frontend-large-feature-architecture/SKILL.md)
- Avoidable React effect audits, refactors, and module migrations:
  [`../.agents/skills/refactor-react-effects/SKILL.md`](../.agents/skills/refactor-react-effects/SKILL.md)
- React composition and component API design:
  [`web/.agents/skills/vercel-composition-patterns/SKILL.md`](.agents/skills/vercel-composition-patterns/SKILL.md)
- React/Next.js performance and rendering best practices:
  [`web/.agents/skills/vercel-react-best-practices/SKILL.md`](.agents/skills/vercel-react-best-practices/SKILL.md)
- PostHog product analytics — when and how to instrument user actions:
  [`../.agents/skills/posthog-instrumentation/SKILL.md`](../.agents/skills/posthog-instrumentation/SKILL.md)
- Sentry error capture — whether and how an error path should report:
  [`../.agents/skills/sentry-instrumentation/SKILL.md`](../.agents/skills/sentry-instrumentation/SKILL.md)

Read these package-local skills before substantial frontend refactors when the
task involves component composition, reusable component APIs, rendering
performance, virtualized lists, local feature stores, bundle size,
React/Next.js performance patterns, or browser-based signoff of user-visible
changes. If you are about to write a `useEffect` or wire form initial values
from loaded data, read the frontend-large-feature-architecture skill first —
most effects that derive or sync state should not exist. When adding a
meaningful user action (button, handler, form, mutation, feature surface),
read the PostHog instrumentation skill and decide explicitly whether the
action should emit an analytics event. When adding or touching an error path —
a `captureException` or `console.error` call, an error boundary, a `catch`
block, a Worker `onerror`, or a Sentry `beforeSend`/denylist filter — read the
Sentry instrumentation skill first and decide whether it should capture at all
(and, for any suppression change, answer "does this rule hide a real error?").

## Web Conventions

- **Before adding or modifying a chart, dashboard, or chart formatter, read
  `src/features/widgets/chart-library/ARCHITECTURE.md` first** — the charts
  manifesto. It owns the data → preparer → visualiser contract: presentation
  decisions (formatting, colors, axis scale, overload) live in the preparer,
  not the chart components.
- **When working on the search bar or any filtering UI/grammar, read
  `src/features/search-bar/README.md` first.** It owns the grammar ↔
  `FilterState` contract, the validate/lower parity invariants, and the
  cross-view extension playbook — the bar is intended to become the primary
  filter interface for every filterable view, so new filtering work extends it
  through that contract rather than forking it.
- When fixing an isolated styling issue in an individual component, create or
  update a component story first, following
  `../.agents/skills/storybook/SKILL.md`.
- Put net-new feature code under `src/features/<feature>/*`; put broadly reusable
  components under `src/components/*`.
- We use tRPC for full-stack web features; register routers in
  `src/server/api/root.ts`.
- RBAC lives in `src/features/rbac`: role definitions in
  `src/features/rbac/constants`, access checks in
  `src/features/rbac/utils/checkProjectAccess.ts` and
  `src/features/rbac/utils/checkOrganizationAccess.ts`.
- Entitlements guidance lives in `src/features/entitlements/README.md`.
- Prefer Shadcn/ui primitives from `src/components/ui`; if a missing component
  must be installed, ask the user before doing so.
- When you surface a score in the UI, always show its level
  (trace/observation/session/experiment) with the `<ScoreTag>` component
  (`src/components/score-tag.tsx`) and its global color coding (see the
  ScoreTag Storybook story).
- Tailwind is the default styling layer; use the shared palette and globals in
  `src/styles/globals.css`.
- Do not add `useEffect` by default. Use it only when a component must
  synchronize with a concrete system outside React, such as a subscription,
  browser event listener, observer, timer, or imperative third-party API.
  Before writing an effect, name that external system and its setup/cleanup
  lifecycle. If there is no external system, do not use an effect. In
  particular, do not use effects to derive render state, mirror props or query
  data into local state, react to user actions, or reset state when an ID
  changes. Derive during render, run work in the initiating event handler, use
  query APIs for server state, or mount a keyed child once required data is
  available. Do not evade this rule with `useLayoutEffect`, a custom wrapper
  hook, an ESLint suppression, or disabled dependency checks. Use
  `../.agents/skills/refactor-react-effects/SKILL.md` for effect work.
- In flex layouts, prefer `gap-*` over margin-based `space-x-*`/`space-y-*`.
- Treat `!` Tailwind classes as a smell. Step back and fix the owning layout,
  variant, or primitive before overriding with higher specificity.
- When changing shared UI/table patterns, update sibling variants consistently,
  including default-visible and hidden columns or states.
- For component style variants, prefer `cva` with `VariantProps` and merge
  caller classes through `cn`, following existing `src/components/ui/*`
  components:

  ```tsx
  const cardVariants = cva("rounded-md border", {
    variants: {
      intent: { default: "bg-background", error: "border-destructive" },
    },
    defaultVariants: { intent: "default" },
  });

  type CardProps = React.HTMLAttributes<HTMLDivElement> &
    VariantProps<typeof cardVariants>;

  const className = cn(cardVariants({ intent }), props.className);
  ```

- When anchoring sticky, fixed, or absolute elements to the viewport, use
  `top-banner-offset`, `pt-banner-offset`, `h-screen-with-banner`, or
  `min-h-screen-with-banner` instead of raw `top-0` so banners do not overlap
  the UI.
- **Z-index / layers — key idea: we are migrating from z-indexes to a layer
  system** (start of a developing design system; extend it, don't work around
  it). **To put something on top of something else, use a layer, not a
  z-index.** The app renders inside `#__next`, isolated into one stacking
  context (`globals.css`), so its z-indexes can't escape; overlays go in layers
  that sit outside it and always win. `LAYER_ORDER` is
  `["panel", "agent", "modal", "popover", "tooltip", "toast"]` — containers declared
  in `_document.tsx`, ordered by that array (later = on top), carrying NO z-index.
  `panel` is for docked side surfaces like Sheet, Drawer, and the table peek;
  `modal` is for true blocking Dialog and AlertDialog surfaces.
  **THE RULE (see `src/components/ui/layer.tsx` JSDoc — source of truth): every
  overlay portals through a layer container; never let a Radix/Vaul `*.Portal`
  fall back to `<body>`.** Radix/Vaul primitives route via their `*.Portal`'s
  `container` (the `ui/*` wrappers do this with `useLayerContainer`); bespoke
  imperatively-positioned content renders via `<Layer name="…">`. z-index stays
  local to a layer or component (1–2 max), never to escape the app — the
  `@repo/no-overlay-zindex` lint rule enforces it.
- **Overlay lifecycle — a dropdown that opens a modal should close first**, not
  linger under it (a lifecycle bug, not z-order — don't fix it by re-ranking
  layers). Radix unmounts a Select/DropdownMenu's content on close, so render the
  Dialog as a SIBLING (trigger inside, dialog outside), as
  `useAddLlmConnectionSelect` in `src/components/ModelParameters/index.tsx` does
  (LFE-10615).
- Never import `prettier/plugins/typescript` in client code — it embeds the
  TypeScript compiler, which the SWC minifier miscompiles (dropped bindings →
  production-only `ReferenceError`; caught by the CI client-bundle scan,
  LFE-10645). Format TypeScript with `parser: "babel-ts"` +
  `prettier/plugins/babel` instead, as the eval-template editor does
  (`src/features/evals/components/code-eval-template-form-body.tsx`).
- Public API routes should use
  `src/features/public-api/server/withMiddlewares.ts`, define strict request and
  response types in `src/features/public-api/types/*`, add server tests, and
  update Fern sources when the contract changes.
- Public eval endpoints should keep the split between reusable `evaluators`
  and ingestion-scoped `evaluation-rules`; do not leak `EvalTemplate` or
  `JobConfiguration` naming into the public contract.
- Keep tests independent; in `src/__tests__/server/**`, prefer scoped cleanup or
  unique test data over global reset helpers.
- Put pure server unit tests that do not need Postgres bootstrap under
  `src/__tests__/server/unit/**` so they skip the shared DB setup hook.
- Server tests that drive the public REST API over HTTP need a web server on
  port 3000 **serving the test database**. `web/vitest.config.mts` loads
  `../.env.test`, which points `DATABASE_URL` at its own database, while
  `pnpm run dev:web` loads only `.env` — so that server talks to a different
  database, finds none of the API keys the tests just created, and every
  authenticated call comes back 401 `Invalid credentials`. Start it with
  `pnpm exec dotenv -e .env.test -e .env -- pnpm --filter web run dev`.
- Preserve the server-test project split in `vitest.config.mts`. Most tests
  consume the built `@langfuse/shared` package; only tests importing
  `@langfuse/shared/in-app-agent` or `@langfuse/shared/src/env` use the
  `server-shared-source*` projects. Do not move `sharedSourceResolve` back to
  the root config: applying those aliases globally increased server-test
  transforms/imports and made Vitest about 27–30% slower. The integration and
  unit source projects stay separate because only integration tests run the
  database `globalSetup`.
- Keep CI web server tests at eight workers on an eight-vCPU runner unless a
  new benchmark supports changing both together. With the current 4,237-test
  suite, median Vitest duration was 82s at 8 workers/8 vCPUs, 115s at
  4 workers/8 vCPUs, and 145s at 8 workers/4 vCPUs (measured 2026-08-06).
- For small utility functions, prefer Vitest in-source tests when colocated
  coverage is the simplest option, especially when the test needs access to
  private implementation details without widening the module API.
- Do not extract private utility functions into separate files only to make
  them testable. Keep them local unless the user explicitly asks for extraction
  or the utility is meaningfully reused.

## Quick Commands

- Dev: `pnpm --filter web run dev`
- Lint: `pnpm --filter web run lint`
- Lint fix: `pnpm --filter web run lint:fix`
- Typecheck: `pnpm --filter web run typecheck`
- Server tests: `pnpm --filter web run test <args>`
- In-source tests: `pnpm --filter web run test:in-source <args>`
- Client tests: `pnpm --filter web run test-client <args>`
- E2E tests: `pnpm --filter web run test:e2e`
- Agent browser install to the default user-level Playwright cache: `pnpm run playwright:install`
- Build: `pnpm --filter web run build`
- Structure-RFC violation counts: `pnpm --filter web run structure:stats`
- Move files/folders with every importer rewritten:
  `pnpm --filter web run structure:move <from...> <to-dir>` — never hand-edit
  import specifiers for a move, and never `mv` a source file without it
  (see `web/scripts/structure/README.md`)

## Playbooks

### Add/Change tRPC endpoint

1. Implement router/procedure in `src/server/api/routers/*` or
   `src/features/<feature>/server/*`.
2. Register in `src/server/api/root.ts`.
3. Reuse auth/error patterns from `src/server/api/trpc.ts`.
4. Add/adjust server tests under `src/__tests__/server/*`.

### Add/Change public API endpoint

1. Add route in `src/pages/api/public/*`.
2. Define/update contract types in `src/features/public-api/types/*`.
3. Add/adjust server tests in `src/__tests__/server/*`.
4. If API contract changed, update Fern source (`../fern/apis/**`) and regenerate
   outputs (do not hand-edit `../generated/**`).

### Error handling (tRPC + REST)

1. Throw `BaseError` subclasses (eg `LangfuseNotFoundError`) from handlers and services.
2. Let `BaseError`s bubble up to the tRPC and REST middlewares (eg. don't `try/catch` and rethrow in to `TRPCError` the handler)
3. Extend the `BaseError` or its subclasses in [`packages/shared/src/errors/`](../packages/shared/src/errors/) as needed.

### Add frontend feature

1. Prefer `src/features/<feature>/*` for feature-local code.
2. Put broadly reusable components in `src/components/*`.
3. Keep server logic near feature server folders when possible.
4. For meaningful user actions (buttons, form submits, mode switches), decide
   explicitly whether to instrument them with PostHog. Use
   `../.agents/skills/posthog-instrumentation/SKILL.md`.
5. Review the affected user flow in a real browser with the Playwright MCP
   server before signoff. Use
   `../.agents/skills/frontend-browser-review/SKILL.md`.

### Agent browser loop

1. Start the app with `pnpm run dev:web` unless an existing local server is already running.
2. Install Chromium with `pnpm run playwright:install` if Playwright has not been set up on this machine yet.
3. Use the workspace `playwright` MCP server from `.mcp.json`, `.cursor/mcp.json`, or `.vscode/mcp.json` for browser-driven review of user-visible frontend changes, not just debugging.
4. Exercise the primary changed flow and check the resulting UI state for obvious visual regressions before signoff.
5. Inspect traces and other artifacts under `/tmp/playwright-mcp` when a browser session fails.

## Package-Specific Rules

- Router style is Pages Router-centric; follow existing routing patterns.
- In `src/pages`, do not keep both `foo.ts(x)` and a `foo/` folder. If the
  folder exists, put the route implementation in `foo/index.ts(x)` instead.
- Keep tests independent; no reliance on test execution order.
- Confirm the target `*.clienttest.*` or `*.servertest.*` file exists before passing a pattern to `vitest run`; source files do not always have a matching colocated test file.
- When passing a Vitest file or pattern through `pnpm --filter web ...`, make it
  relative to `web/` because the script runs with `web` as the working
  directory. Example: use `src/features/widgets/chart-library/BigNumber.tsx`,
  not `web/src/features/widgets/chart-library/BigNumber.tsx`.
- Prefer separate test files for components, integration coverage, and broader
  behaviors; use Vitest in-source tests mainly for small-scoped utilities.
- Run Vitest in-source utility coverage with `pnpm --filter web run test:in-source`;
  do not try to target these through `test-client` or by assuming a separate
  `*.clienttest.*`/`*.servertest.*` file exists.
- Do not hand-edit build artifacts: `.next/*`, `.next-check/*`, `dist/*`.

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
