package annotation

import (
	"context"
	"encoding/json"
	"net/url"
	"strconv"
	"time"

	authtypes "github.com/grafana/authlib/types"
	"github.com/grafana/grafana-app-sdk/app"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	annotationV0 "github.com/grafana/grafana/apps/annotation/pkg/apis/annotation/v0alpha1"
	"github.com/grafana/grafana/pkg/apimachinery/utils"
	"github.com/grafana/grafana/pkg/infra/log"
)

func newSearchHandler(
	store Store,
	accessClient authtypes.AccessClient,
	folderResolver DashboardFolderResolver,
	metrics *Metrics,
	logger log.Logger,
) func(ctx context.Context, writer app.CustomRouteResponseWriter, request *app.CustomRouteRequest) error {
	return func(ctx context.Context, writer app.CustomRouteResponseWriter, request *app.CustomRouteRequest) (err error) {
		namespace := request.ResourceIdentifier.Namespace

		ctx, span := tracer.Start(ctx, "annotation.k8s.search", trace.WithAttributes(
			attribute.String("namespace", namespace),
		))
		defer span.End()
		start := time.Now()
		defer func() { observe(ctx, logger, metrics.RequestDuration, "search", start, err) }()

		queryParams := request.URL.Query()
		opts := listOptionsFromQueryParams(queryParams)

		result, err := store.List(ctx, namespace, opts)
		if err != nil {
			return err
		}

		allowed, err := canAccessAnnotations(ctx, accessClient, folderResolver, namespace, result.Items, utils.VerbList)
		if err != nil {
			return err
		}

		filtered := make([]annotationV0.Annotation, 0, len(result.Items))
		for i, anno := range result.Items {
			if allowed[i] {
				filtered = append(filtered, anno)
			}
		}
		span.SetAttributes(
			attribute.Int("item_count", len(result.Items)),
			attribute.Int("filtered_count", len(filtered)),
		)

		response := &annotationV0.AnnotationList{
			Items:    filtered,
			ListMeta: metav1.ListMeta{Continue: result.Continue},
		}

		writer.Header().Set("Content-Type", "application/json")
		return json.NewEncoder(writer).Encode(response)
	}
}

func listOptionsFromQueryParams(queryParams url.Values) ListOptions {
	opts := ListOptions{}

	if v := queryParams.Get("dashboardUID"); v != "" {
		opts.DashboardUID = v
	}

	if v := queryParams.Get("panelID"); v != "" {
		if panelID, err := strconv.ParseInt(v, 10, 64); err == nil {
			opts.PanelID = panelID
		}
	}

	if v := queryParams.Get("from"); v != "" {
		if from, err := strconv.ParseInt(v, 10, 64); err == nil {
			opts.From = from
		}
	}

	if v := queryParams.Get("to"); v != "" {
		if to, err := strconv.ParseInt(v, 10, 64); err == nil {
			opts.To = to
		}
	}

	opts.Limit = 100
	if v := queryParams.Get("limit"); v != "" {
		if limit, err := strconv.ParseInt(v, 10, 64); err == nil && limit > 0 {
			opts.Limit = limit
		}
	}

	if v := queryParams.Get("continue"); v != "" {
		opts.Continue = v
	}

	if tags, ok := queryParams["tag"]; ok {
		opts.Tags = tags
	}

	if v := queryParams.Get("tagsMatchAny"); v != "" {
		if matchAny, err := strconv.ParseBool(v); err == nil {
			opts.TagsMatchAny = matchAny
		}
	}

	if scopes, ok := queryParams["scope"]; ok {
		opts.Scopes = scopes
	}

	// Scopes default to matching any of the requested values to align with other scope-based filtering in Grafana.
	opts.ScopesMatchAny = true
	if v := queryParams.Get("scopesMatchAny"); v != "" {
		if matchAny, err := strconv.ParseBool(v); err == nil {
			opts.ScopesMatchAny = matchAny
		}
	}

	// createdBy accepts a user uid
	if v := queryParams.Get("createdBy"); v != "" {
		opts.CreatedBy = v
	}

	if v := queryParams.Get("legacyID"); v != "" {
		if id, err := strconv.ParseInt(v, 10, 64); err == nil && id > 0 {
			opts.LegacyID = id
		}
	}

	switch queryParams.Get("deleted") {
	case "include":
		opts.Deleted = DeletedInclude
	case "only":
		opts.Deleted = DeletedOnly
	default:
		opts.Deleted = DeletedExclude
	}

	return opts
}
