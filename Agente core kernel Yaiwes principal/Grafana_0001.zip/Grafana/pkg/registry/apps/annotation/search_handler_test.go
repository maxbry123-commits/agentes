package annotation

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/url"
	"testing"

	authtypes "github.com/grafana/authlib/types"
	"github.com/grafana/grafana-app-sdk/app"
	"github.com/grafana/grafana-app-sdk/resource"
	annotationV0 "github.com/grafana/grafana/apps/annotation/pkg/apis/annotation/v0alpha1"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	"github.com/grafana/grafana/pkg/infra/log"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	k8srequest "k8s.io/apiserver/pkg/endpoints/request"
)

func TestSearchHandler(t *testing.T) {
	ctx := k8srequest.WithNamespace(identity.WithServiceIdentityContext(t.Context(), 1), metav1.NamespaceDefault)

	seedAnnotations := []*annotationV0.Annotation{
		{
			ObjectMeta: metav1.ObjectMeta{Name: "a-1", Namespace: metav1.NamespaceDefault},
			Spec:       annotationV0.AnnotationSpec{Text: "test", Time: 1000, Tags: []string{"tag1"}, Scopes: []string{"scope1"}},
		},
		{
			ObjectMeta: metav1.ObjectMeta{Name: "a-2", Namespace: metav1.NamespaceDefault},
			Spec:       annotationV0.AnnotationSpec{Text: "test", Time: 1000, Tags: []string{"tag2"}, Scopes: []string{"scope2"}},
		},
		{
			ObjectMeta: metav1.ObjectMeta{Name: "a-3", Namespace: metav1.NamespaceDefault},
			Spec:       annotationV0.AnnotationSpec{Text: "test", Time: 1000, Tags: []string{"tag3"}, Scopes: []string{"scope3"}},
		},
		{
			ObjectMeta: metav1.ObjectMeta{Name: "a-4", Namespace: metav1.NamespaceDefault},
			Spec:       annotationV0.AnnotationSpec{Text: "test", Time: 1000, Tags: []string{"tag1", "tag2"}, Scopes: []string{"scope1", "scope2"}},
		},
		{
			ObjectMeta: metav1.ObjectMeta{Name: "a-5", Namespace: metav1.NamespaceDefault},
			Spec:       annotationV0.AnnotationSpec{Text: "test", Time: 1000, Tags: []string{}, Scopes: []string{}},
		},
	}

	accessClient := &fakeAccessClient{fn: func(_ authtypes.BatchCheckItem) bool { return true }}
	dashClient := newFakeFolderResolver(nil)

	tests := []struct {
		name          string
		queryParams   url.Values
		deleteFirst   []string
		expectedNames []string
	}{
		{
			name: "Filter by single tag",
			queryParams: url.Values{
				"tag": []string{"tag1"},
			},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name: "Filter by multiple tags with matchAny=true (OR)",
			queryParams: url.Values{
				"tag":          []string{"tag1", "tag2"},
				"tagsMatchAny": []string{"true"},
			},
			expectedNames: []string{"a-1", "a-2", "a-4"},
		},
		{
			name: "Filter by multiple tags without matchAny (AND - default)",
			queryParams: url.Values{
				"tag": []string{"tag1", "tag2"},
			},
			expectedNames: []string{"a-4"},
		},
		{
			name: "Filter by three tags with matchAny=true",
			queryParams: url.Values{
				"tag":          []string{"tag1", "tag2", "tag3"},
				"tagsMatchAny": []string{"true"},
			},
			expectedNames: []string{"a-1", "a-2", "a-3", "a-4"},
		},
		{
			name: "Filter by single scope",
			queryParams: url.Values{
				"scope": []string{"scope1"},
			},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name: "Filter by multiple scopes with matchAny=true (OR)",
			queryParams: url.Values{
				"scope":          []string{"scope1", "scope2"},
				"scopesMatchAny": []string{"true"},
			},
			expectedNames: []string{"a-1", "a-2", "a-4"},
		},
		{
			name: "Filter by multiple scopes without matchAny (OR - default)",
			queryParams: url.Values{
				"scope": []string{"scope1", "scope2"},
			},
			expectedNames: []string{"a-1", "a-2", "a-4"},
		},
		{
			name: "Filter by multiple scopes with matchAny=false (AND)",
			queryParams: url.Values{
				"scope":          []string{"scope1", "scope2"},
				"scopesMatchAny": []string{"false"},
			},
			expectedNames: []string{"a-4"},
		},
		{
			name: "Filter by both tags and scopes",
			queryParams: url.Values{
				"tag":   []string{"tag1"},
				"scope": []string{"scope1"},
			},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name: "Filter by tags (OR) and scopes (OR by default)",
			queryParams: url.Values{
				"tag":          []string{"tag1", "tag2"},
				"tagsMatchAny": []string{"true"},
				"scope":        []string{"scope1", "scope2"},
			},
			expectedNames: []string{"a-1", "a-2", "a-4"},
		},
		{
			name: "Filter by tags (AND by default) and scopes (AND)",
			queryParams: url.Values{
				"tag":            []string{"tag1", "tag2"},
				"scope":          []string{"scope1", "scope2"},
				"scopesMatchAny": []string{"false"},
			},
			expectedNames: []string{"a-4"},
		},
		{
			name: "Invalid tagsMatchAny value (should be ignored, defaults to false)",
			queryParams: url.Values{
				"tag":          []string{"tag1"},
				"tagsMatchAny": []string{"not-valid"},
			},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name: "Invalid scopesMatchAny value (should be ignored, defaults to true)",
			queryParams: url.Values{
				"scope":          []string{"scope1"},
				"scopesMatchAny": []string{"not-valid"},
			},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name:          "Soft-deleted annotations are excluded by default",
			queryParams:   url.Values{"tag": []string{"tag1"}},
			deleteFirst:   []string{"a-1"},
			expectedNames: []string{"a-4"},
		},
		{
			name: "Soft-deleted annotations are included with deleted=include",
			queryParams: url.Values{
				"tag":     []string{"tag1"},
				"deleted": []string{"include"},
			},
			deleteFirst:   []string{"a-1"},
			expectedNames: []string{"a-1", "a-4"},
		},
		{
			name: "Only soft-deleted annotations are returned with deleted=only",
			queryParams: url.Values{
				"tag":     []string{"tag1"},
				"deleted": []string{"only"},
			},
			deleteFirst:   []string{"a-1"},
			expectedNames: []string{"a-1"},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			store := NewMemoryStore()
			for _, anno := range seedAnnotations {
				_, err := store.Create(ctx, anno.DeepCopy())
				require.NoError(t, err)
			}
			for _, name := range tt.deleteFirst {
				require.NoError(t, store.Delete(ctx, metav1.NamespaceDefault, name))
			}
			handler := newSearchHandler(store, accessClient, dashClient, ProvideMetrics(nil), log.NewNopLogger())

			u := &url.URL{
				Scheme:   "http",
				Host:     "localhost",
				Path:     "/apis/annotation.grafana.app/v0alpha1/namespaces/default/search",
				RawQuery: tt.queryParams.Encode(),
			}

			mockRequest := &app.CustomRouteRequest{
				ResourceIdentifier: resource.FullIdentifier{
					Namespace: metav1.NamespaceDefault,
				},
				URL:    u,
				Method: "GET",
			}

			writer := &mockResponseWriter{
				header: make(http.Header),
				body:   &bytes.Buffer{},
			}

			err := handler(ctx, writer, mockRequest)
			require.NoError(t, err)

			var result annotationV0.AnnotationList
			err = json.Unmarshal(writer.body.Bytes(), &result)
			require.NoError(t, err)

			// verify that the expected annotations were returned
			if len(tt.expectedNames) > 0 {
				resultNames := make([]string, len(result.Items))
				for i, item := range result.Items {
					resultNames[i] = item.Name
				}
				assert.ElementsMatch(t, tt.expectedNames, resultNames, "Result names should match expected names")
			} else if tt.expectedNames != nil {
				assert.Empty(t, result.Items, "Expected no results")
			}
		})
	}
}

// mockResponseWriter implements app.CustomRouteResponseWriter for testing
type mockResponseWriter struct {
	header http.Header
	body   *bytes.Buffer
	code   int
}

func (m *mockResponseWriter) Header() http.Header {
	return m.header
}

func (m *mockResponseWriter) Write(b []byte) (int, error) {
	return m.body.Write(b)
}

func (m *mockResponseWriter) WriteHeader(statusCode int) {
	m.code = statusCode
}
