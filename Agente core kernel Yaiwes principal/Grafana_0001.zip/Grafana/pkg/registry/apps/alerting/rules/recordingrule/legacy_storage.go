package recordingrule

import (
	"context"
	"errors"
	"fmt"
	"strconv"

	k8serrors "k8s.io/apimachinery/pkg/api/errors"
	"k8s.io/apimachinery/pkg/apis/meta/internalversion"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/selection"
	"k8s.io/apimachinery/pkg/types"
	"k8s.io/apiserver/pkg/registry/rest"

	model "github.com/grafana/grafana/apps/alerting/rules/pkg/apis/alerting/v0alpha1"
	"github.com/grafana/grafana/pkg/apimachinery/identity"
	grafanarest "github.com/grafana/grafana/pkg/apiserver/rest"
	"github.com/grafana/grafana/pkg/registry/apps/alerting/rules/common"
	"github.com/grafana/grafana/pkg/services/apiserver/endpoints/request"
	ngmodels "github.com/grafana/grafana/pkg/services/ngalert/models"
	"github.com/grafana/grafana/pkg/services/ngalert/provisioning"
)

// onlyRecordingVersions filters versions to those representing recording rules. Versions of
// alerting rules share storage but should not surface through the RecordingRule resource.
func onlyRecordingVersions(versions []*ngmodels.AlertRuleVersion) []*ngmodels.AlertRuleVersion {
	out := versions[:0]
	for _, v := range versions {
		if v == nil {
			continue
		}
		if v.Type() != ngmodels.RuleTypeRecording {
			continue
		}
		out = append(out, v)
	}
	return out
}

// onlyRecordingRules filters deleted rules to those representing recording rules.
func onlyRecordingRules(rules []*ngmodels.AlertRule) []*ngmodels.AlertRule {
	out := rules[:0]
	for _, r := range rules {
		if r == nil {
			continue
		}
		if r.Type() != ngmodels.RuleTypeRecording {
			continue
		}
		out = append(out, r)
	}
	return out
}

var (
	_ grafanarest.Storage = (*legacyStorage)(nil)
)

type legacyStorage struct {
	service        provisioning.AlertRuleService
	namespacer     request.NamespaceMapper
	tableConverter rest.TableConvertor
}

func (s *legacyStorage) New() runtime.Object {
	return ResourceInfo.NewFunc()
}

func (s *legacyStorage) Destroy() {}

func (s *legacyStorage) NamespaceScoped() bool {
	return true
}

func (s *legacyStorage) GetSingularName() string {
	return ResourceInfo.GetSingularName()
}

func (s *legacyStorage) NewList() runtime.Object {
	return ResourceInfo.NewListFunc()
}

func (s *legacyStorage) ConvertToTable(ctx context.Context, object runtime.Object, tableOptions runtime.Object) (*metav1.Table, error) {
	return s.tableConverter.ConvertToTable(ctx, object, tableOptions)
}

func (s *legacyStorage) List(ctx context.Context, opts *internalversion.ListOptions) (runtime.Object, error) {
	info, err := request.NamespaceInfoFrom(ctx, true)
	if err != nil {
		return nil, err
	}

	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, err
	}

	mode, ruleName, err := common.ParseListMode(opts.LabelSelector, opts.FieldSelector)
	if err != nil {
		return nil, k8serrors.NewBadRequest(err.Error())
	}
	switch mode {
	case common.ListModeHistory:
		versions, err := s.service.GetAlertRuleVersions(ctx, user, ruleName)
		if err != nil {
			if errors.Is(err, ngmodels.ErrAlertRuleNotFound) {
				return nil, k8serrors.NewNotFound(ResourceInfo.GroupResource(), ruleName)
			}
			return nil, err
		}
		return convertVersionsToK8sResources(info.OrgID, onlyRecordingVersions(versions), s.namespacer)
	case common.ListModeTrash:
		deleted, err := s.service.GetDeletedAlertRules(ctx, user)
		if err != nil {
			return nil, err
		}
		return convertDeletedToK8sResources(info.OrgID, onlyRecordingRules(deleted), s.namespacer)
	case common.ListModeNormal:
		// fall through to the normal list pipeline below.
	}

	groupFilter, err := common.ParseLabelSelectorFilter(opts.LabelSelector, model.GroupLabelKey)
	if err != nil {
		return nil, k8serrors.NewBadRequest(fmt.Sprintf("invalid label selector for %s: %s", model.GroupLabelKey, err))
	}
	folderFilter, err := common.ParseLabelSelectorFilter(opts.LabelSelector, model.FolderLabelKey)
	if err != nil {
		return nil, k8serrors.NewBadRequest(fmt.Sprintf("invalid label selector for %s: %s", model.FolderLabelKey, err))
	}

	var (
		titleFilter               provisioning.ListRuleStringFilter
		pausedFilter              provisioning.ListRuleBoolFilter
		metricFilter              provisioning.ListRuleStringFilter
		targetDatasourceUIDFilter provisioning.ListRuleStringFilter
	)
	if opts.FieldSelector != nil && !opts.FieldSelector.Empty() {
		for _, r := range opts.FieldSelector.Requirements() {
			switch r.Field {
			case "spec.title":
				if err := common.ApplyFieldSelectorRequirement(&titleFilter, r, nil); err != nil {
					return nil, k8serrors.NewBadRequest(err.Error())
				}
			case "spec.paused":
				v, err := strconv.ParseBool(r.Value)
				if err != nil {
					return nil, k8serrors.NewBadRequest(fmt.Sprintf("invalid value for spec.paused: %s", r.Value))
				}
				switch r.Operator {
				case selection.Equals, selection.DoubleEquals:
					pausedFilter.Value = &v
				case selection.NotEquals:
					negated := !v
					pausedFilter.Value = &negated
				default:
					return nil, k8serrors.NewBadRequest(fmt.Sprintf("unsupported operator %q for spec.paused (only =, ==, != are supported)", r.Operator))
				}
			case "spec.metric":
				if err := common.ApplyFieldSelectorRequirement(&metricFilter, r, nil); err != nil {
					return nil, k8serrors.NewBadRequest(err.Error())
				}
			case "spec.targetDatasourceUID":
				if err := common.ApplyFieldSelectorRequirement(&targetDatasourceUIDFilter, r, nil); err != nil {
					return nil, k8serrors.NewBadRequest(err.Error())
				}
			default:
				return nil, k8serrors.NewBadRequest(fmt.Sprintf("unknown field selector: %s", r.Field))
			}
		}
	}

	rules, managerPropsMap, continueToken, err := s.service.ListAlertRules(ctx, user, provisioning.ListAlertRulesOptions{
		RuleType:                  ngmodels.RuleTypeFilterRecording,
		Limit:                     opts.Limit,
		ContinueToken:             opts.Continue,
		GroupFilter:               groupFilter,
		FolderFilter:              folderFilter,
		TitleFilter:               titleFilter,
		PausedFilter:              pausedFilter,
		MetricFilter:              metricFilter,
		TargetDatasourceUIDFilter: targetDatasourceUIDFilter,
	})
	if err != nil {
		return nil, err
	}
	return convertToK8sResources(info.OrgID, rules, managerPropsMap, s.namespacer, continueToken)
}

func (s *legacyStorage) Get(ctx context.Context, name string, _ *metav1.GetOptions) (runtime.Object, error) {
	info, err := request.NamespaceInfoFrom(ctx, true)
	if err != nil {
		return nil, err
	}

	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, err
	}

	rule, managerProps, err := s.service.GetAlertRule(ctx, user, name)
	if err != nil {
		if errors.Is(err, ngmodels.ErrAlertRuleNotFound) {
			return nil, k8serrors.NewNotFound(ResourceInfo.GroupResource(), name)
		}
		return nil, err
	}

	obj, err := convertToK8sResource(info.OrgID, &rule, managerProps, s.namespacer)
	if err != nil && errors.Is(err, errInvalidRule) {
		return nil, k8serrors.NewNotFound(ResourceInfo.GroupResource(), name)
	}
	return obj, err
}

func (s *legacyStorage) Create(ctx context.Context, obj runtime.Object, createValidation rest.ValidateObjectFunc, _ *metav1.CreateOptions) (runtime.Object, error) {
	info, err := request.NamespaceInfoFrom(ctx, true)
	if err != nil {
		return nil, err
	}

	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, err
	}
	if createValidation != nil {
		if err := createValidation(ctx, obj); err != nil {
			return nil, err
		}
	}

	p, ok := obj.(*model.RecordingRule)
	if !ok {
		return nil, k8serrors.NewBadRequest("expected valid recording rule object")
	}

	if p.GenerateName != "" {
		return nil, k8serrors.NewBadRequest("generate-name is not supported in legacy storage mode")
	}
	// TODO: move this to the validation function
	if p.Labels[model.GroupLabelKey] != "" || p.Labels[model.GroupIndexLabelKey] != "" {
		return nil, k8serrors.NewBadRequest("cannot set group label when creating recording rule")
	}

	domainModel, managerProps, err := convertToDomainModel(info.OrgID, p)
	if err != nil {
		return nil, err
	}

	rule, err := s.service.CreateAlertRule(ctx, user, *domainModel, managerProps)
	if err != nil {
		return nil, err
	}

	return convertToK8sResource(info.OrgID, &rule, managerProps, s.namespacer)
}

func (s *legacyStorage) Update(ctx context.Context, name string, objInfo rest.UpdatedObjectInfo, _ rest.ValidateObjectFunc, updateValidation rest.ValidateObjectUpdateFunc, _ bool, options *metav1.UpdateOptions) (runtime.Object, bool, error) {
	info, err := request.NamespaceInfoFrom(ctx, true)
	if err != nil {
		return nil, false, err
	}

	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, false, err
	}

	old, err := s.Get(ctx, name, nil)
	if err != nil {
		return nil, false, err
	}

	obj, err := objInfo.UpdatedObject(ctx, old)
	if err != nil {
		return old, false, err
	}
	if updateValidation != nil {
		if err := updateValidation(ctx, obj, old); err != nil {
			return nil, false, err
		}
	}

	new, ok := obj.(*model.RecordingRule)
	if !ok {
		return nil, false, k8serrors.NewBadRequest("expected valid recording rule object")
	}
	// FIXME(@rwwiv): this shouldn't be necessary
	if new.Name != "" {
		new.UID = types.UID(new.Name)
	}

	domainModel, managerProps, err := convertToDomainModel(info.OrgID, new)
	if err != nil {
		return nil, false, err
	}

	_, err = s.service.UpdateAlertRule(ctx, user, *domainModel, managerProps)
	if err != nil {
		return nil, false, err
	}

	updated, managerProps, err := s.service.GetAlertRule(ctx, user, name)
	if err != nil {
		return nil, false, err
	}

	rule, err := convertToK8sResource(info.OrgID, &updated, managerProps, s.namespacer)
	if err != nil {
		return nil, false, err
	}

	return rule, true, nil
}

func (s *legacyStorage) Delete(ctx context.Context, name string, deleteValidation rest.ValidateObjectFunc, opts *metav1.DeleteOptions) (runtime.Object, bool, error) {
	info, err := request.NamespaceInfoFrom(ctx, true)
	if err != nil {
		return nil, false, err
	}

	user, err := identity.GetRequester(ctx)
	if err != nil {
		return nil, false, err
	}

	old, err := s.Get(ctx, name, nil)
	if err != nil {
		return old, false, err
	}
	if deleteValidation != nil {
		if err := deleteValidation(ctx, old); err != nil {
			return nil, false, err
		}
	}
	p, ok := old.(*model.RecordingRule)
	if !ok {
		return nil, false, k8serrors.NewBadRequest("expected valid recording rule object")
	}

	// Derive manager properties the same way create/update do, so a resource managed
	// by a specific manager (e.g. Terraform) is deleted with the matching manager and
	// not the coarser provenance-derived equivalent.
	_, managerProps, err := convertToDomainModel(info.OrgID, p)
	if err != nil {
		return nil, false, err
	}

	err = s.service.DeleteAlertRule(ctx, user, name, managerProps)
	if err != nil {
		return old, false, err
	}

	return old, false, nil
}

func (s *legacyStorage) DeleteCollection(_ context.Context, _ rest.ValidateObjectFunc, _ *metav1.DeleteOptions, _ *internalversion.ListOptions) (runtime.Object, error) {
	// TODO: support this once a pattern is established for bulk delete operations
	return nil, k8serrors.NewMethodNotSupported(ResourceInfo.GroupResource(), "delete")
}
