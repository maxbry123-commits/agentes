package io.kestra.jdbc.repository;

import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Function;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.jooq.Condition;
import org.jooq.Configuration;
import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Name;
import org.jooq.Record;
import org.jooq.Record1;
import org.jooq.SelectConditionStep;
import org.jooq.Table;
import org.jooq.impl.DSL;

import io.kestra.core.exceptions.TypeConversionException;
import io.kestra.core.models.QueryFilter;
import io.kestra.core.repositories.ArrayListTotal;
import io.kestra.core.repositories.ServiceInstanceRepositoryInterface;
import io.kestra.core.runners.TransactionContext;
import io.kestra.core.server.Service;
import io.kestra.core.server.ServiceInstance;
import io.kestra.core.server.ServiceLivenessStore;
import io.kestra.core.server.ServiceStateTransition;
import io.kestra.core.server.ServiceType;
import io.kestra.core.utils.TypeConverter;
import io.kestra.jdbc.runner.JdbcTransactionContext;

import io.micronaut.data.model.Pageable;
import jakarta.annotation.Nullable;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import static org.jooq.impl.DSL.quotedName;
import static org.jooq.impl.DSL.using;

@Getter
@Slf4j
public abstract class AbstractJdbcServiceInstanceRepository extends AbstractJdbcRepository implements ServiceInstanceRepositoryInterface, ServiceLivenessStore {

    private static final Field<Object> STATE = field("state");
    private static final Field<Object> TYPE = field("service_type");
    private static final Field<Instant> UPDATED_AT = field("updated_at", Instant.class);
    private static final Field<Instant> CREATED_AT = field("created_at", Instant.class);
    private static final Field<Object> SERVICE_ID = field("service_id");

    protected io.kestra.jdbc.AbstractJdbcRepository<ServiceInstance> jdbcRepository;

    public AbstractJdbcServiceInstanceRepository(final io.kestra.jdbc.AbstractJdbcRepository<ServiceInstance> jdbcRepository) {
        this.jdbcRepository = jdbcRepository;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public Optional<ServiceInstance> findById(final String id) {
        return jdbcRepository.getDslContextWrapper().transactionResult(
            configuration -> findById(id, DSL.using(configuration), false)
        );
    }

    private Optional<ServiceInstance> findById(final String id,
        final DSLContext dslContext,
        final boolean isForUpdate) {

        SelectConditionStep<Record1<Object>> query = dslContext
            .select(VALUE_FIELD)
            .from(table())
            .where(SERVICE_ID.eq(id));

        return isForUpdate ? this.jdbcRepository.fetchOne(query.forUpdate()) : this.jdbcRepository.fetchOne(query);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public List<ServiceInstance> findAllInstancesInStates(final Set<Service.ServiceState> states) {
        return this.jdbcRepository.getDslContextWrapper()
            .transactionResult(configuration -> findAllInstancesInStates(configuration, states, false));
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public List<ServiceInstance> findAllInstancesInState(final Service.ServiceState state) {
        return this.jdbcRepository.getDslContextWrapper()
            .transactionResult(configuration ->
            {
                var query = using(configuration)
                    .select(VALUE_FIELD)
                    .from(table())
                    .where(STATE.eq(state.name()));
                return this.jdbcRepository.fetch(query);
            });
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public List<ServiceInstance> findAllInstancesBetween(final ServiceType type, final Instant from, final Instant to) {
        return jdbcRepository.getDslContextWrapper().transactionResult(configuration ->
        {
            SelectConditionStep<Record1<Object>> query = using(configuration)
                .select(VALUE_FIELD)
                .from(table())
                .where(TYPE.eq(type.name()))
                .and(CREATED_AT.lt(to))
                .and(UPDATED_AT.ge(from));

            return this.jdbcRepository.fetch(query);
        });
    }

    public List<ServiceInstance> findAllInstancesInStates(final Configuration configuration,
        final Set<Service.ServiceState> states,
        final boolean isForUpdate) {
        SelectConditionStep<Record1<Object>> query = using(configuration)
            .select(VALUE_FIELD)
            .from(table())
            .where(STATE.in(states.stream().map(Enum::name).toList()));

        return isForUpdate ? this.jdbcRepository.fetch(query.forUpdate().skipLocked()) : this.jdbcRepository.fetch(query);
    }

    @Override
    public void processAllNonRunningInstances(BiConsumer<TransactionContext, ServiceInstance> consumer) {
        jdbcRepository.getDslContextWrapper().transaction(configuration ->
        {
            var dslContext = DSL.using(configuration);
            var query = dslContext
                .select(VALUE_FIELD)
                .from(table())
                .where(STATE.notIn(Service.ServiceState.CREATED.name(), Service.ServiceState.RUNNING.name(), Service.ServiceState.INACTIVE.name()));

            var txContext = new JdbcTransactionContext(dslContext);
            this.jdbcRepository.fetch(query.forUpdate().skipLocked()).forEach(instance -> consumer.accept(txContext, instance));
        });
    }

    @Override
    public void processInstanceInStates(Set<Service.ServiceState> states, BiConsumer<TransactionContext, ServiceInstance> consumer) {
        jdbcRepository.getDslContextWrapper().transaction(configuration ->
        {
            var dslContext = DSL.using(configuration);
            var query = dslContext
                .select(VALUE_FIELD)
                .from(table())
                .where(STATE.in(states.stream().map(Enum::name).toList()));

            var txContext = new JdbcTransactionContext(dslContext);
            this.jdbcRepository.fetch(query.forUpdate().skipLocked()).forEach(instance -> consumer.accept(txContext, instance));
        });
    }

    /**
     * Finds all service instances which are {@link Service.ServiceState#NOT_RUNNING}.
     *
     * @return the list of {@link ServiceInstance}.
     */
    public List<ServiceInstance> findAllInstancesInNotRunningState() {
        return jdbcRepository.getDslContextWrapper().transactionResult(
            configuration -> findAllInstancesInNotRunningState(configuration, false)
        );
    }

    /**
     * Finds all service instances which are {@link Service.ServiceState#NOT_RUNNING}.
     *
     * @return the list of {@link ServiceInstance}.
     */
    public List<ServiceInstance> findAllInstancesInNotRunningState(final Configuration configuration,
        final boolean isForUpdate) {
        SelectConditionStep<Record1<Object>> query = using(configuration)
            .select(VALUE_FIELD)
            .from(table())
            .where(STATE.eq(Service.ServiceState.NOT_RUNNING.name()));

        return isForUpdate ? this.jdbcRepository.fetch(query.forUpdate().skipLocked()) : this.jdbcRepository.fetch(query);
    }

    @Override
    public int purgeEmptyInstances(Instant until) {
        return jdbcRepository.getDslContextWrapper().transactionResult(
            configuration -> using(configuration).delete(table())
                .where(STATE.in(Service.ServiceState.INACTIVE.name(), "EMPTY"))
                .and(UPDATED_AT.lessOrEqual(until))
                .execute()
        );
    }

    public void delete(DSLContext context, ServiceInstance instance) {
        this.jdbcRepository.delete(context, instance);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public void delete(final ServiceInstance instance) {
        this.jdbcRepository.delete(instance);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ServiceInstance save(final ServiceInstance instance) {
        this.jdbcRepository.persist(instance, this.jdbcRepository.persistFields(instance));
        return instance;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public List<ServiceInstance> findAll() {
        return this.jdbcRepository
            .getDslContextWrapper()
            .transactionResult(
                configuration -> this.jdbcRepository.fetch(
                    using(configuration).select(VALUE_FIELD).from(table())
                )
            );
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ArrayListTotal<ServiceInstance> find(final Pageable pageable,
        @Nullable final List<QueryFilter> filters) {
        return this.jdbcRepository
            .getDslContextWrapper()
            .transactionResult(configuration ->
            {
                DSLContext context = using(configuration);
                SelectConditionStep<Record1<Object>> select = context.select(VALUE_FIELD).from(table()).where("1=1");
                if (filters != null && !filters.isEmpty()) {
                    select = select.and(
                        this.filter(filters, CREATED_AT.getName(), QueryFilter.Resource.SERVICE_INSTANCE)
                    );
                }
                return this.jdbcRepository.fetchPage(context, select, pageable);
            });
    }

    /** {@inheritDoc} **/
    @Override
    protected Condition filter(List<QueryFilter> filters, String dateColumn, QueryFilter.Resource resource) {
        return super.filter(ServiceInstanceRepositoryInterface.expandStateNamesForFilterQueryBackwardCompat(filters), dateColumn, resource);
    }

    /** {@inheritDoc} **/
    @Override
    protected Name getColumnName(QueryFilter.Field field) {
        if (field == QueryFilter.Field.TYPE) {
            // The service type column is named "service_type", not "type"
            return quotedName("service_type");
        }
        return super.getColumnName(field);
    }

    /** {@inheritDoc} **/
    @Override
    protected Condition createdCondition(Object value, QueryFilter.Op operation, @Nullable String dateColumn) {
        String column = dateColumn != null ? dateColumn : CREATED_AT.getName();
        // Accept ISO-8601 durations (e.g. PT5M) as a "now minus duration" threshold;
        // the supplied operation is applied against that threshold.
        try {
            Duration duration = TypeConverter.toDuration(value);
            ZonedDateTime threshold = ZonedDateTime.now().minus(duration);
            return applyDateCondition(threshold.toOffsetDateTime(), operation, column);
        } catch (TypeConversionException ignored) {
            // Not a duration — fall through to absolute date parsing
        }
        return super.createdCondition(value, operation, column);
    }

    @Override
    protected Condition generateStateCondition(Object value, QueryFilter.Op operation) {
        List<String> stateNames = switch (value) {
            case List<?> list -> list.stream().map(Object::toString).toList();
            case String s -> List.of(s);
            default -> throw new io.kestra.core.exceptions.InvalidQueryFiltersException(
                "Field 'state' requires a String or List<String> value for service instances"
            );
        };
        Field<String> stateField = DSL.field(org.jooq.impl.DSL.quotedName("state"), String.class);
        return switch (operation) {
            case EQUALS, IN -> stateField.in(stateNames);
            case NOT_EQUALS, NOT_IN -> stateField.notIn(stateNames);
            default -> throw new io.kestra.core.exceptions.InvalidQueryFiltersException(
                "Unsupported operation for STATE: " + operation
            );
        };
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ServiceStateTransition.Response mayTransitServiceTo(final TransactionContext txContext,
        final ServiceInstance instance,
        final Service.ServiceState newState,
        final String reason) {
        ImmutablePair<ServiceInstance, ServiceInstance> result = mayUpdateStatusById(
            txContext,
            instance,
            newState,
            reason
        );
        return ServiceStateTransition.logTransitionAndGetResponse(instance, newState, result);
    }

    /**
     * Attempt to transition the state of a given service to given new state.
     * This method may not update the service if the transition is not valid.
     *
     * @param instance the new service instance.
     * @param newState the new state of the service.
     * @return an {@link Optional} of {@link ImmutablePair} holding the old (left), and new {@link ServiceInstance} or {@code null} if transition failed (right).
     *         Otherwise, an {@link Optional#empty()} if the no service can be found.
     */
    private ImmutablePair<ServiceInstance, ServiceInstance> mayUpdateStatusById(final TransactionContext txContext,
        final ServiceInstance instance,
        final Service.ServiceState newState,
        final String reason) {
        // Find the ServiceInstance to be updated
        var dslContext = txContext.unwrap(JdbcTransactionContext.class).getDslContext();
        Optional<ServiceInstance> optional = findById(instance.uid(), dslContext, true);

        // Check whether service was found.
        if (optional.isEmpty()) {
            return null;
        }

        // Check whether the status transition is valid before saving.
        final ServiceInstance before = optional.get();
        if (before.state().isValidTransition(newState)) {
            ServiceInstance updated = before
                .state(newState, Instant.now(), reason)
                .server(instance.server())
                .metrics(instance.metrics());
            // Synchronize
            save(updated);
            return new ImmutablePair<>(before, updated);
        }
        return new ImmutablePair<>(before, null);
    }

    private Table<Record> table() {
        return this.jdbcRepository.getTable();
    }

    /** {@inheritDoc} **/
    @Override
    public Function<String, String> sortMapping() {
        Map<String, String> mapper = Map.of(
            "createdAt", CREATED_AT.getName(),
            "updatedAt", UPDATED_AT.getName(),
            "serviceId", SERVICE_ID.getName()
        );
        return mapper::get;
    }
}
