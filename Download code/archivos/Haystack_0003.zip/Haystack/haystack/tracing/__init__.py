# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

# ruff: noqa: F401

from haystack.tracing.tracer import (  # noqa: I001 (otherwise we end up with partial imports)
    Span,
    Tracer,
    disable_tracing,
    enable_tracing,
    is_tracing_enabled,
    tracer,
)
