# SPDX-FileCopyrightText: 2022-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

import sys
from typing import TYPE_CHECKING

from lazy_imports import LazyImporter

_import_structure = {
    "auto_merging_retriever": ["AutoMergingRetriever"],
    "filter_retriever": ["FilterRetriever"],
    "in_memory": ["InMemoryBM25Retriever", "InMemoryEmbeddingRetriever"],
    "multi_retriever": ["MultiRetriever"],
    "multi_query_embedding_retriever": ["MultiQueryEmbeddingRetriever"],
    "multi_query_text_retriever": ["MultiQueryTextRetriever"],
    "sentence_window_retriever": ["SentenceWindowRetriever"],
    "text_embedding_retriever": ["TextEmbeddingRetriever"],
}

if TYPE_CHECKING:
    from .auto_merging_retriever import AutoMergingRetriever as AutoMergingRetriever
    from .filter_retriever import FilterRetriever as FilterRetriever
    from .in_memory import InMemoryBM25Retriever as InMemoryBM25Retriever
    from .in_memory import InMemoryEmbeddingRetriever as InMemoryEmbeddingRetriever
    from .multi_query_embedding_retriever import MultiQueryEmbeddingRetriever as MultiQueryEmbeddingRetriever
    from .multi_query_text_retriever import MultiQueryTextRetriever as MultiQueryTextRetriever
    from .multi_retriever import MultiRetriever as MultiRetriever
    from .sentence_window_retriever import SentenceWindowRetriever as SentenceWindowRetriever
    from .text_embedding_retriever import TextEmbeddingRetriever as TextEmbeddingRetriever

else:
    sys.modules[__name__] = LazyImporter(name=__name__, module_file=__file__, import_structure=_import_structure)
