package io.kestra.cli.commands.namespaces;

import io.kestra.cli.AbstractCommand;
import io.kestra.cli.Kestra;
import io.kestra.cli.commands.namespaces.kv.KvCommand;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import picocli.CommandLine;

@CommandLine.Command(
    name = "namespace",
    description = "Manage namespaces",
    mixinStandardHelpOptions = true,
    subcommands = {
        KvCommand.class
    }
)
@Slf4j
public class NamespaceCommand extends AbstractCommand {
    @SneakyThrows
    @Override
    public Integer call() throws Exception {
        super.call();

        return Kestra.runCli(new String[] { "namespace", "--help" });
    }
}
