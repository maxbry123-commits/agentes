package io.kestra.cli.commands.namespaces.kv;

import io.kestra.cli.AbstractCommand;
import io.kestra.cli.Kestra;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import picocli.CommandLine;

@CommandLine.Command(
    name = "kv",
    description = "Manage KV Store",
    mixinStandardHelpOptions = true,
    subcommands = {
        KvUpdateCommand.class,
    }
)
@Slf4j
public class KvCommand extends AbstractCommand {
    @SneakyThrows
    @Override
    public Integer call() throws Exception {
        super.call();

        return Kestra.runCli(new String[] { "namespace", "kv", "--help" });
    }
}
