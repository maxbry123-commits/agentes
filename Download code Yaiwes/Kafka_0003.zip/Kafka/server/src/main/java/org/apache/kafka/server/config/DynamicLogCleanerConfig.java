/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.kafka.server.config;

import org.apache.kafka.storage.internals.log.CleanerConfig;
import org.apache.kafka.storage.internals.log.LogCleaner;

import java.util.Set;

public class DynamicLogCleanerConfig implements BrokerReconfigurable {
    private final LogCleaner logCleaner;

    public DynamicLogCleanerConfig(LogCleaner logCleaner) {
        this.logCleaner = logCleaner;
    }

    @Override
    public Set<String> reconfigurableConfigs() {
        return logCleaner.reconfigurableConfigs();
    }

    @Override
    public void validateReconfiguration(AbstractKafkaConfig newConfig) {
        logCleaner.validateReconfiguration(new CleanerConfig(newConfig));
    }

    @Override
    public void reconfigure(AbstractKafkaConfig oldConfig, AbstractKafkaConfig newConfig) {
        logCleaner.reconfigure(new CleanerConfig(oldConfig), new CleanerConfig(newConfig));
    }

    @Override
    public String toString() {
        return "DynamicLogCleanerConfig";
    }
}
