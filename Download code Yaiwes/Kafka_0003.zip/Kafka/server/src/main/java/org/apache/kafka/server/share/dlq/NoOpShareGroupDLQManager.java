/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.kafka.server.share.dlq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;

/**
 * A no op implementation of {@link ShareGroupDLQManager}. This will be useful
 * in development cycle and testing. All methods return immediately with
 * a successfully completed future.
 */
public class NoOpShareGroupDLQManager implements ShareGroupDLQManager {
    private static final Logger log = LoggerFactory.getLogger(NoOpShareGroupDLQManager.class);

    @Override
    public CompletableFuture<Void> enqueue(ShareGroupDLQRecordParameter param) {
        log.warn("Enqueuing share group dlq record parameter: {}", param);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void stop() {
        // noop
    }
}
