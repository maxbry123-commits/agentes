/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.kafka.server.partition;

import org.apache.kafka.metadata.LeaderAndIsr;
import org.apache.kafka.server.common.TopicIdPartition;

import java.util.concurrent.CompletableFuture;

/**
 * Handles updating the ISR by sending AlterPartition requests to the controller. Updating the ISR is an asynchronous
 * operation, so partitions will learn about the result of their request through a callback.
 * <p>
 * Note that ISR state changes can still be initiated by the controller and sent to the partitions via LeaderAndIsr
 * requests.
 */
public interface AlterPartitionManager {
    void start();

    void shutdown() throws InterruptedException;

    CompletableFuture<LeaderAndIsr> submit(TopicIdPartition topicIdPartition, LeaderAndIsr leaderAndIsr);
}
