/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.kafka.tiered.storage.integration;

import org.apache.kafka.clients.consumer.GroupProtocol;
import org.apache.kafka.common.test.ClusterInstance;
import org.apache.kafka.common.test.api.ClusterConfig;
import org.apache.kafka.common.test.api.ClusterTemplate;
import org.apache.kafka.common.test.api.Type;
import org.apache.kafka.tiered.storage.TieredStorageTestBuilder;
import org.apache.kafka.tiered.storage.specs.KeyValueSpec;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import static org.apache.kafka.common.utils.Utils.mkEntry;
import static org.apache.kafka.common.utils.Utils.mkMap;
import static org.apache.kafka.server.log.remote.storage.LocalTieredStorageEvent.EventType.DELETE_SEGMENT;
import static org.apache.kafka.tiered.storage.utils.TieredStorageTestUtils.createServerPropsForRemoteStorage;

public final class DeleteSegmentsDueToLogStartOffsetBreachTest {

    private static final int BROKER_COUNT = 3;
    private static final int NUM_REMOTE_LOG_METADATA_PARTITIONS = 5;

    private static List<ClusterConfig> clusterConfig() {
        return List.of(ClusterConfig.defaultBuilder()
                .setTypes(Set.of(Type.KRAFT))
                .setBrokers(BROKER_COUNT)
                .setServerProperties(createServerPropsForRemoteStorage(
                        DeleteSegmentsDueToLogStartOffsetBreachTest.class.getSimpleName().toLowerCase(Locale.ROOT),
                        BROKER_COUNT,
                        NUM_REMOTE_LOG_METADATA_PARTITIONS))
                .build());
    }

    @ClusterTemplate("clusterConfig")
    public void testDeleteSegmentsDueToLogStartOffsetBreachWithClassicGroupProtocol(ClusterInstance clusterInstance) throws Exception {
        executeDeleteSegmentsDueToLogStartOffsetBreachTest(clusterInstance, GroupProtocol.CLASSIC);
    }

    @ClusterTemplate("clusterConfig")
    public void testDeleteSegmentsDueToLogStartOffsetBreachWithConsumerGroupProtocol(ClusterInstance clusterInstance) throws Exception {
        executeDeleteSegmentsDueToLogStartOffsetBreachTest(clusterInstance, GroupProtocol.CONSUMER);
    }

    private void executeDeleteSegmentsDueToLogStartOffsetBreachTest(ClusterInstance clusterInstance,
                                                                    GroupProtocol groupProtocol) throws Exception {
        final int broker0 = 0;
        final int broker1 = 1;
        final String topicA = "topicA";
        final int p0 = 0;
        final int partitionCount = 1;
        final int replicationFactor = 2;
        final int maxBatchCountPerSegment = 2;
        final Map<Integer, List<Integer>> replicaAssignment = mkMap(mkEntry(p0, List.of(broker0, broker1)));
        final boolean enableRemoteLogStorage = true;
        final int beginEpoch = 0;
        final long startOffset = 3;
        final long beforeOffset = 3L;
        final long beforeOffset1 = 7L;

        TieredStorageTestBuilder builder = new TieredStorageTestBuilder();

        // Create topicA with 1 partition and 2 RF
        builder.createTopic(topicA, partitionCount, replicationFactor, maxBatchCountPerSegment, replicaAssignment,
                        enableRemoteLogStorage)
                // produce events to partition 0 and expect 2 segments to be offloaded
                .expectSegmentToBeOffloaded(broker0, topicA, p0, 0, new KeyValueSpec("k0", "v0"),
                        new KeyValueSpec("k1", "v1"))
                .expectSegmentToBeOffloaded(broker0, topicA, p0, 2, new KeyValueSpec("k2", "v2"),
                        new KeyValueSpec("k3", "v3"))
                .expectEarliestLocalOffsetInLogDirectory(topicA, p0, 4L)
                .produce(topicA, p0, new KeyValueSpec("k0", "v0"), new KeyValueSpec("k1", "v1"),
                        new KeyValueSpec("k2", "v2"), new KeyValueSpec("k3", "v3"), new KeyValueSpec("k4", "v4"))
                // Use DELETE_RECORDS API to delete the records upto offset 3 and expect one remote segment to be deleted
                .expectDeletionInRemoteStorage(broker0, topicA, p0, DELETE_SEGMENT, 1)
                .deleteRecords(topicA, p0, beforeOffset)
                // expect that the leader epoch checkpoint is updated
                .expectLeaderEpochCheckpoint(broker0, topicA, p0, beginEpoch, startOffset)
                // consume from the offset-3 of the topic to read data from local and remote storage
                .expectFetchFromTieredStorage(broker0, topicA, p0, 1)
                .consume(topicA, p0, 3L, 2, 1)

                // switch leader to change the leader-epoch from 0 to 1
                .expectLeader(topicA, p0, broker1, true)
                // produce some more messages and move the log-start-offset such that earliest-epoch changes from 0 to 1
                .expectSegmentToBeOffloaded(broker1, topicA, p0, 4, new KeyValueSpec("k4", "v4"),
                        new KeyValueSpec("k5", "v5"))
                .expectSegmentToBeOffloaded(broker1, topicA, p0, 6, new KeyValueSpec("k6", "v6"),
                        new KeyValueSpec("k7", "v7"))
                .expectEarliestLocalOffsetInLogDirectory(topicA, p0, 8L)
                .produce(topicA, p0, new KeyValueSpec("k5", "v5"), new KeyValueSpec("k6", "v6"),
                        new KeyValueSpec("k7", "v7"), new KeyValueSpec("k8", "v8"), new KeyValueSpec("k9", "v9"))
                // Use DELETE_RECORDS API to delete the records upto offset 7 and expect 2 remote segments to be deleted
                .expectDeletionInRemoteStorage(broker1, topicA, p0, DELETE_SEGMENT, 2)
                .deleteRecords(topicA, p0, beforeOffset1)
                // consume from the topic with fetch-offset 7 to read data from local and remote storage
                .expectFetchFromTieredStorage(broker1, topicA, p0, 1)
                .consume(topicA, p0, 7L, 3, 1);

        builder.build().execute(clusterInstance, groupProtocol);
    }
}
