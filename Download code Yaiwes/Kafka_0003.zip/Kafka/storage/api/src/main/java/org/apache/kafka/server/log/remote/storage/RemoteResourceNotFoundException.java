/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.kafka.server.log.remote.storage;

import org.apache.kafka.common.annotation.InterfaceAudience;

/**
 * Exception thrown when a resource is not found on the remote storage.
 * <p>
 * A resource can be a log segment, any of the indexes or any which was stored in remote storage for a particular log
 * segment.
 */
@InterfaceAudience.Public
public class RemoteResourceNotFoundException extends RemoteStorageException {
    private static final long serialVersionUID = 1L;

    public RemoteResourceNotFoundException(final String message) {
        super(message);
    }

    public RemoteResourceNotFoundException(final Throwable cause) {
        super("Requested remote resource was not found", cause);
    }

    public RemoteResourceNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
