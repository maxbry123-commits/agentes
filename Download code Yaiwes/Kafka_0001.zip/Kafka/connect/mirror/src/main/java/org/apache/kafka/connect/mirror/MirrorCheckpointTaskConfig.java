/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.kafka.connect.mirror;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.metrics.PluginMetrics;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MirrorCheckpointTaskConfig extends MirrorCheckpointConfig {

    private static final String TASK_CONSUMER_GROUPS_DOC = "Consumer groups assigned to this task to replicate.";

    public MirrorCheckpointTaskConfig(Map<String, String> props) {
        super(TASK_CONFIG_DEF, props);
    }

    Set<String> taskConsumerGroups() {
        return new HashSet<>(getList(TASK_CONSUMER_GROUPS));
    }

    MirrorCheckpointLegacyMetrics legacyMetrics() {
        MirrorCheckpointLegacyMetrics metrics = new MirrorCheckpointLegacyMetrics(this);
        metricsReporters().forEach(metrics::addReporter);
        return metrics;
    }

    MirrorCheckpointMetrics metrics(PluginMetrics pluginMetrics) {
        return new MirrorCheckpointMetrics(pluginMetrics, this);
    }

    @Override
    String entityLabel() {
        return super.entityLabel() + "-" + (getInt(TASK_INDEX) == null ? "?" : getInt(TASK_INDEX));
    }

    protected static final ConfigDef TASK_CONFIG_DEF = new ConfigDef(CONNECTOR_CONFIG_DEF)
            .define(
                    TASK_CONSUMER_GROUPS,
                    ConfigDef.Type.LIST,
                    ConfigDef.NO_DEFAULT_VALUE,
                    ConfigDef.ValidList.anyNonDuplicateValues(false, false),
                    ConfigDef.Importance.LOW,
                    TASK_CONSUMER_GROUPS_DOC)
            .define(TASK_INDEX,
                    ConfigDef.Type.INT,
                    null,
                    ConfigDef.Importance.LOW,
                    "The index of the task");
}
