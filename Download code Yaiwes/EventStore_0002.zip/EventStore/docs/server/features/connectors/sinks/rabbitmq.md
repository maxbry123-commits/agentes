---
title: "RabbitMQ Sink"
---

<Badge type="info" vertical="middle" text="License Required"/>

## Overview

This sink is responsible for sending messages to a RabbitMQ exchange using a specified routing key. It efficiently
handles message delivery by abstracting the complexities of RabbitMQ's exchange and queue management, ensuring that
messages are routed to the appropriate destinations based on the provided routing key. This sink is designed for high
reliability and supports graceful error handling and recovery mechanisms to ensure consistent message delivery in a
production environment.

## Prerequisites

Before using the RabbitMQ sink connector, ensure you have:

- A data protection token configured in your KurrentDB instance (required to encrypt sensitive fields like passwords)
- A RabbitMQ server instance with accessible host and port
- Appropriate authentication credentials (username and password)

::: tip
See the [Data Protection](../features.md#data-protection) documentation for instructions on configuring the encryption token.
:::

## Quickstart

You can create the RabbitMQ Sink connector as follows. Replace `{id}` with your desired connector ID:

```http
POST /connectors/{id}
Host: localhost:2113
Content-Type: application/json

{
  "settings": {
    "instanceTypeName": "rabbit-mq-sink",
    "exchange:name": "example-exchange",
    "exchange:type": "direct",
    "routingKey": "my-routing-key",
    "subscription:filter:scope": "stream",
    "subscription:filter:filterType": "streamId",
    "subscription:filter:expression": "example-stream"
  }
}
```

After creating and starting the RabbitMQ sink connector, every time an event is
appended to the `example-stream`, the RabbitMQ sink connector will send the
record to the specified queue in RabbitMQ. You can find a list of available
management API endpoints in the [API Reference](../manage.md).

## Settings

Adjust these settings to specify the behavior and interaction of your RabbitMQ sink connector with KurrentDB, ensuring it operates according to your requirements and preferences.

::: tip
The RabbitMQ sink inherits a set of common settings that are used to configure the connector. The settings can be found in
the [Sink Options](../settings.md#sink-options) page.
:::

The RabbitMQ sink can be configured with the following options:

| Option                            | Description                                                                                                                                                                                                                                                                    |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `exchange:name`                   | _required_<br><br>**Description:**<br>Exchange's name.                                                                                                                                                                                                                         |
| `exchange:type`                   | **Description:**<br>Exchange's type.<br><br>**Default**: `"fanout"`                                                                                                                                                                                                            |
| `routingKey`                      | **Description:**<br>Used by the exchange to determine how to route a message to the appropriate queue(s). The routing key is evaluated against the binding rules of the queues associated with the exchange, influencing the message's delivery path.<br><br>**Default**: `""` |
| `host`                            | **Description:**<br>Hostname of the server.<br><br>**Default**: `"localhost"`                                                                                                                                                                                                  |
| `port`                            | **Description:**<br>Port number of the server.<br><br>**Default**: `"5672"`                                                                                                                                                                                                    |
| `connectionName`                  | **Description:**<br>Connection name used for logging and diagnostics. The default value is the connector ID.Connection name used for logging and diagnostics.<br><br>**Default**: The connector id                                                                             |
| `virtualHost`                     | **Description:**<br>Represents the VirtualHost (vhost) used in RabbitMQ. <br><br>**Default**: `/`                                                                                                                                                                              |
| `waitForBrokerAck`                | **Description:**<br>Whether the channel waits for broker acknowledgment before considering the send operation complete.<br><br>**Default**: `"false"`                                                                                                                          |
| `authentication:username`         | **Description:**<br>Username for authentication.<br><br>**Default**: `"guest"`                                                                                                                                                                                                 |
| `authentication:password`         | **Description:**<br>Password for authentication.<br><br>**Default**: `"guest"`                                                                                                                                                                                                 |
| `autoDelete`                      | **Description:**<br>Whether the exchange is automatically deleted when no longer in use.<br><br>**Default**: `"false"`                                                                                                                                                         |
| `durable`                         | **Description:**<br>Whether the exchange is durable.<br><br>**Default**: `"true"`                                                                                                                                                                                              |

#### Resilience

The RabbitMQ sink connector relies on its own RabbitMQ retry mechanism and doesn't include the configuration from [Resilience configuration](../settings.md#resilience-configuration).

| Option                            | Description                                                                                                                                                                                                                                                                    |
| --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `resilience:connectionTimeoutMs`  | **Description:**<br>Connection TCP establishment timeout in milliseconds. 0 for infinite.<br><br>**Default**: `"60000"`                                                                                                                                                        |
| `resilience:handshakeTimeoutMs`   | **Description:**<br>The protocol handshake timeout in milliseconds.<br><br>**Default**: `"10000"`                                                                                                                                                                              |
| `resilience:requestedHeartbeatMs` | **Description:**<br>The requested heartbeat timeout in milliseconds. 0 means "heartbeats are disabled". Should be no lower than 1 second.<br><br>**Default**: `"60000"`                                                                                                        |

## Broker Acknowledgment

By default, the connector waits for broker acknowledgment. Enabling broker acknowledgment ensures that each message sent
to RabbitMQ is confirmed by the broker before the publish operation is considered complete:

```http
POST /connectors/{id}
Host: localhost:2113
Content-Type: application/json

{
  "WaitForBrokerAck": true
}
```

Disabling broker acknowledgment can significantly increase throughput by allowing the producer to continue sending
messages without waiting for confirmation from the broker. This is ideal for high-throughput scenarios where performance
is prioritized over delivery guarantees, despite a slight increase in the risk of message loss or duplication.

## Headers

The RabbitMQ sink connector automatically includes these [default headers](../features.md#headers) in each message sent to the exchange. 

## Tutorial
[Learn how to set up and use a RabbitMQ Sink connector in KurrentDB through a tutorial.](/tutorials/RabbitMQ_Sink.md)
