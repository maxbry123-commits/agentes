# V2 upgrade

Compared with the original MAXBRY Continuous Loop, V2 adds the missing
control-plane capabilities suggested by inspection of OpenMythos.

## OpenMythos-inspired concepts

OpenMythos currently exposes:
- recurrent depth / configurable loop count
- loop-index embedding
- ACT adaptive halting
- stable LTI injection
- KV cache separation per recurrent iteration
- MoE routing
- Prelude → Recurrent Block → Coda

These are model-internal mechanisms, not workflow persistence mechanisms.

## External-loop equivalents added here

- AdaptiveLoopController: chooses more/less external iterations.
- ConvergenceMonitor: detects stagnation.
- ChangeImpact: invalidates downstream completed tasks when an upstream task changes.
- AppendOnlyLedger: hash-chained audit trail.
- ArtifactStore: immutable content-addressed artifacts.
- WorkflowManifest: deterministic structural fingerprint.
- RecoveryManager: newest-checkpoint recovery.

## What is intentionally NOT copied

MoE, attention, RoPE, LTI recurrence and ACT are neural-network internals.
Putting those into the workflow controller would not reproduce their behavior.
Instead, V2 maps the useful control principles to an external task/workflow
layer.

## Recommended final architecture

Model -> Agent Adapter -> Task Executor -> Verifier
                                  |
                                  v
                            MAXBRY Loop
                         /      |       \
                    Trace     Gaps    Convergence
                      |        |          |
                      +--------+----------+
                               |
                         Persistent Store
                      /       |        |       \
                   State    Ledger  Artifacts Manifest
                               |
                          Recovery/Resume
