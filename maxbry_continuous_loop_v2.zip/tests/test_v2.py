from maxbry_loop.models import Goal, State, Task
from maxbry_loop.change_impact import ChangeImpact
from maxbry_loop.ledger import AppendOnlyLedger
from maxbry_loop.artifacts import ArtifactStore

def state():
    a = Task(id="A", title="A", description="A", status="done")
    b = Task(id="B", title="B", description="B", depends_on=["A"], status="done")
    c = Task(id="C", title="C", description="C", depends_on=["B"], status="done")
    return State("1", Goal("x"), {"A":a,"B":b,"C":c})

def test_impact():
    s = state()
    impact = ChangeImpact(s)
    assert impact.affected("A") == ["B","C"]
    impact.invalidate_downstream("A", "changed")
    assert s.tasks["B"].status == "needs_revision"
    assert s.tasks["C"].status == "needs_revision"

def test_hash_ledger(tmp_path):
    p = tmp_path / "ledger.jsonl"
    l = AppendOnlyLedger(p)
    l.append("x", {"a":1}, 1)
    l.append("y", {"b":2}, 2)
    assert l.verify()

def test_artifact(tmp_path):
    a = ArtifactStore(tmp_path / "artifacts")
    h = a.put("hello", "world")
    assert a.verify(h)
