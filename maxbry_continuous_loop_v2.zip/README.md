# MAXBRY Continuous Loop

A model-agnostic continuous agent harness inspired by public descriptions of agentic/goal loops and recurrent refinement.

## What it does

1. Loads a goal/document.
2. Builds a persistent task graph.
3. Executes tasks in dependency order.
4. After every iteration, runs:
   - traceability/diff detection
   - gap detection
   - regression/structure checks
   - completion scoring
5. Can append new tasks without changing existing task IDs.
6. Can add improvement tasks when a gap is discovered.
7. Checkpoints state after every iteration.
8. Stops only when the completion policy is satisfied, or a safety/iteration budget is reached.
9. Keeps an append-only event ledger for auditability.

The loop is a harness around an LLM; it is NOT a reproduction of Anthropic's proprietary Mythos system. Public/open implementations describe recurrent refinement and goal-loop harnesses, but the internal Anthropic system is not publicly reproducible.

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python -m maxbry_loop.cli run \
  --goal "Build the requested system and verify every requirement" \
  --config config/loop.yaml
```

For a document:

```bash
python -m maxbry_loop.cli run \
  --document ./goal.md \
  --config config/loop.yaml
```

The default `mock` model lets you test the engine without an API key.

## Real model

Set:

```bash
export LLM_BASE_URL="https://your-openai-compatible-endpoint/v1"
export LLM_API_KEY="..."
export LLM_MODEL="your-model"
```

Then use:

```yaml
model:
  provider: openai_compatible
```

## Important invariant

The workflow structure is versioned. Existing task IDs are never silently replaced. New work is appended as new tasks with provenance pointing to the gap/change that caused them.


## V2 additions

See `UPGRADE_NOTES.md`. V2 adds adaptive external loop depth, convergence/stagnation detection, downstream change impact, immutable content-addressed artifacts, hash-chained audit ledger, deterministic workflow manifests, and checkpoint recovery.
