import json, hashlib
from pathlib import Path
from datetime import datetime, timezone

def _now():
    return datetime.now(timezone.utc).isoformat()

class AppendOnlyLedger:
    """Hash-chained audit ledger.

    Each event contains prev_hash and event_hash, making silent deletion or
    modification detectable.
    """
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _last_hash(self):
        if not self.path.exists():
            return "GENESIS"
        last = None
        with self.path.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last = json.loads(line)
        return last.get("event_hash", "GENESIS") if last else "GENESIS"

    def append(self, event_type, payload, iteration):
        record = {
            "timestamp": _now(),
            "iteration": iteration,
            "type": event_type,
            "payload": payload,
            "prev_hash": self._last_hash(),
        }
        canonical = json.dumps(record, sort_keys=True, ensure_ascii=False)
        record["event_hash"] = hashlib.sha256(canonical.encode()).hexdigest()
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record["event_hash"]

    def verify(self):
        prev = "GENESIS"
        if not self.path.exists():
            return True
        with self.path.open(encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                r = json.loads(line)
                claimed = r.pop("event_hash")
                if r["prev_hash"] != prev:
                    return False
                canonical = json.dumps(r, sort_keys=True, ensure_ascii=False)
                actual = hashlib.sha256(canonical.encode()).hexdigest()
                if actual != claimed:
                    return False
                prev = claimed
        return True
