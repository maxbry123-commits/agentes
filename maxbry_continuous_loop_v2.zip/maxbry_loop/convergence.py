class ConvergenceMonitor:
    def __init__(self, window=4, min_delta=0.005):
        self.window = window
        self.min_delta = min_delta
        self.history = []

    def update(self, score):
        self.history.append(float(score))
        if len(self.history) < self.window:
            return {"stagnating": False, "delta": None}
        recent = self.history[-self.window:]
        delta = recent[-1] - recent[0]
        return {
            "stagnating": delta < self.min_delta,
            "delta": round(delta, 6),
        }
