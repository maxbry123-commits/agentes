from pathlib import Path
import json

class RecoveryManager:
    """Finds the newest valid checkpoint and restores it through Store."""
    def __init__(self, checkpoint_dir):
        self.root = Path(checkpoint_dir)

    def newest(self):
        files = sorted(self.root.glob("iteration-*.json"), reverse=True)
        for p in files:
            try:
                raw = json.loads(p.read_text(encoding="utf-8"))
                if "tasks" in raw and "goal" in raw:
                    return p, raw
            except Exception:
                continue
        return None, None
