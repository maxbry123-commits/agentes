import hashlib, json
from pathlib import Path
from datetime import datetime, timezone

class ArtifactStore:
    """Content-addressed artifact registry.

    Artifacts are immutable by hash. A logical name can point to a newer
    version while the old content remains recoverable.
    """
    def __init__(self, root=".maxbry/artifacts"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / "objects").mkdir(exist_ok=True)
        (self.root / "refs").mkdir(exist_ok=True)

    def put(self, name, content, provenance=None):
        raw = content.encode("utf-8") if isinstance(content, str) else content
        digest = hashlib.sha256(raw).hexdigest()
        obj = self.root / "objects" / digest
        if not obj.exists():
            obj.write_bytes(raw)
        ref = {
            "name": name,
            "sha256": digest,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "provenance": provenance or {},
        }
        (self.root / "refs" / f"{name}.json").write_text(
            json.dumps(ref, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return digest

    def get(self, digest):
        return (self.root / "objects" / digest).read_bytes()

    def verify(self, digest):
        raw = self.get(digest)
        return hashlib.sha256(raw).hexdigest() == digest
