import json, hashlib
from pathlib import Path

class WorkflowManifest:
    """Deterministic manifest of the loop's structural state."""
    def build(self, state):
        tasks = {}
        for tid in sorted(state.tasks):
            t = state.tasks[tid]
            tasks[tid] = {
                "title": t.title,
                "description": t.description,
                "status": t.status,
                "priority": t.priority,
                "depends_on": sorted(t.depends_on),
                "acceptance": t.acceptance,
                "provenance": t.provenance,
            }
        payload = {
            "schema_version": state.schema_version,
            "workflow_version": state.workflow_version,
            "tasks": tasks,
        }
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        payload["manifest_sha256"] = hashlib.sha256(canonical.encode()).hexdigest()
        return payload

    def save(self, state, path=".maxbry/workflow_manifest.json"):
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.build(state), indent=2, ensure_ascii=False), encoding="utf-8")
