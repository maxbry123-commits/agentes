from dataclasses import dataclass
from typing import List, Dict

@dataclass
class LoopDecision:
    loops: int
    reason: str
    confidence: float

class AdaptiveLoopController:
    """Workflow analogue of compute-adaptive recurrence.

    It does not alter the model's latent recurrence. It chooses how much
    external workflow compute to spend based on blockers, gaps, stagnation,
    and recent progress.
    """
    def __init__(self, min_loops=1, max_loops=50):
        self.min_loops = min_loops
        self.max_loops = max_loops

    def decide(self, state, gaps: int, progress: float, stagnation: int):
        blockers = len(state.blockers)
        pending = sum(t.status == "pending" for t in state.tasks.values())
        if blockers:
            n = min(self.max_loops, max(self.min_loops, 8 + blockers * 3))
            return LoopDecision(n, "blockers_present", 0.95)
        if gaps:
            n = min(self.max_loops, max(self.min_loops, 6 + gaps * 2))
            return LoopDecision(n, "gaps_present", 0.90)
        if stagnation >= 3:
            return LoopDecision(min(self.max_loops, 12), "stagnation_recovery", 0.85)
        if pending:
            return LoopDecision(min(self.max_loops, max(2, pending)), "pending_work", 0.80)
        return LoopDecision(self.min_loops, "verification_pass", 0.70)
