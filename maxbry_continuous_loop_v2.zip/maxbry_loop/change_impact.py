from collections import defaultdict, deque

class ChangeImpact:
    """Tracks which tasks are affected by a changed task/artifact."""
    def __init__(self, state):
        self.state = state

    def affected(self, changed_task_id):
        reverse = defaultdict(list)
        for tid, task in self.state.tasks.items():
            for dep in task.depends_on:
                reverse[dep].append(tid)

        seen, q = set(), deque([changed_task_id])
        while q:
            cur = q.popleft()
            for nxt in reverse[cur]:
                if nxt not in seen:
                    seen.add(nxt)
                    q.append(nxt)
        return sorted(seen)

    def invalidate_downstream(self, changed_task_id, reason):
        affected = self.affected(changed_task_id)
        for tid in affected:
            task = self.state.tasks[tid]
            if task.status == "done":
                task.status = "needs_revision"
                task.result = None
                task.evidence.append(f"invalidated:{reason}")
        return affected
