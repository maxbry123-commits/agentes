"""Tenant Alpha asset modules."""
