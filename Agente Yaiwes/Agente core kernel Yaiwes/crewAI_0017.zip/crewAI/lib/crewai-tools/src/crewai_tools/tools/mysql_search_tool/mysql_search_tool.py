import re
from typing import Any

from pydantic import BaseModel, Field

from crewai_tools.rag.data_types import DataType
from crewai_tools.tools.rag.rag_tool import RagTool


_MYSQL_IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")


def _quote_mysql_table_name(table_name: str) -> str:
    identifier_parts = table_name.split(".")
    if (
        not identifier_parts
        or len(identifier_parts) > 2
        or any(
            not _MYSQL_IDENTIFIER_PATTERN.fullmatch(part) for part in identifier_parts
        )
    ):
        raise ValueError(
            "MySQL table_name must be a valid table identifier or schema.table "
            "identifier"
        )

    return ".".join(f"`{part}`" for part in identifier_parts)


class MySQLSearchToolSchema(BaseModel):
    """Input for MySQLSearchTool."""

    search_query: str = Field(
        ...,
        description="Mandatory semantic search query you want to use to search the database's content",
    )


class MySQLSearchTool(RagTool):
    name: str = "Search a database's table content"
    description: str = "A tool that can be used to semantic search a query from a database table's content."
    args_schema: type[BaseModel] = MySQLSearchToolSchema
    db_uri: str = Field(..., description="Mandatory database URI")

    def __init__(self, table_name: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.add(table_name, data_type=DataType.MYSQL, metadata={"db_uri": self.db_uri})
        self.description = f"A tool that can be used to semantic search a query the {table_name} database table's content."
        self._generate_description()

    def add(  # type: ignore[override]
        self,
        table_name: str,
        **kwargs: Any,
    ) -> None:
        quoted_table_name = _quote_mysql_table_name(table_name)
        super().add(f"SELECT * FROM {quoted_table_name};", **kwargs)  # noqa: S608

    def _run(  # type: ignore[override]
        self,
        search_query: str,
        similarity_threshold: float | None = None,
        limit: int | None = None,
        **kwargs: Any,
    ) -> Any:
        return super()._run(
            query=search_query, similarity_threshold=similarity_threshold, limit=limit
        )
