import os
import socket
import subprocess
import tempfile
import time
from collections.abc import Iterator

import docker
import docker.errors
import pytest
from dagster import file_relative_path
from dagster._core.instance import DagsterInstance
from dagster._core.test_utils import environ, instance_for_test
from dagster_test.test_project import build_and_tag_test_image, get_test_project_docker_image

from dagster_celery_tests.utils import start_celery_worker

IS_BUILDKITE = os.getenv("BUILDKITE") is not None


def _wait_for_tcp_port(host: str, port: int, timeout: float = 60.0) -> None:
    deadline = time.monotonic() + timeout
    last_err: Exception | None = None
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=2.0):
                return
        except OSError as e:
            last_err = e
            time.sleep(1.0)
    raise RuntimeError(
        f"Timed out waiting for {host}:{port} to accept connections after {timeout}s: {last_err}"
    )


@pytest.fixture(scope="session")
def rabbitmq():
    if IS_BUILDKITE:
        # The celery_extra_cmds shell starts the rabbitmq sibling container with
        # `docker compose up -d`, which returns once the container is created --
        # not once rabbitmq's TCP listener is bound. Wait for the AMQP port to
        # actually accept connections before yielding, otherwise test_start_worker
        # races the broker and fails with `[Errno 111] Connection refused`.
        broker_host = os.getenv("DAGSTER_CELERY_BROKER_HOST", "localhost")
        _wait_for_tcp_port(broker_host, 5672, timeout=60.0)
        # Set the enviornment variable that celery uses in the start_worker() test function
        # to find the broker host
        with environ({"TEST_BROKER": broker_host}):
            yield
        return

    docker_compose_file = file_relative_path(__file__, "../docker-compose.yaml")

    service_name = "test-rabbitmq"

    try:
        subprocess.check_output(
            ["docker", "compose", "-f", docker_compose_file, "stop", service_name],
        )
        subprocess.check_output(
            ["docker", "compose", "-f", docker_compose_file, "rm", "-f", service_name],
        )
    except Exception:
        pass

    subprocess.check_output(
        ["docker", "compose", "-f", docker_compose_file, "up", "-d", service_name]
    )

    print("Waiting for rabbitmq to be ready...")  # noqa: T201
    while True:
        logs = str(subprocess.check_output(["docker", "logs", service_name]))
        if "started TCP listener on [::]:5672" in logs:
            break
        time.sleep(1)

    try:
        yield
    finally:
        try:
            subprocess.check_output(
                ["docker", "compose", "-f", docker_compose_file, "stop", service_name]
            )
            subprocess.check_output(
                ["docker", "compose", "-f", docker_compose_file, "rm", "-f", service_name]
            )
        except Exception:
            pass


@pytest.fixture(scope="function")
def tempdir():
    with tempfile.TemporaryDirectory() as the_dir:
        yield the_dir


@pytest.fixture(scope="function")
def instance(tempdir):
    with instance_for_test(temp_dir=tempdir) as test_instance:
        yield test_instance


@pytest.fixture(scope="function")
def dagster_celery_worker(rabbitmq, instance: DagsterInstance) -> Iterator[None]:
    with start_celery_worker():
        yield


@pytest.fixture(scope="session")
def dagster_docker_image():
    docker_image = get_test_project_docker_image()

    if not IS_BUILDKITE:
        try:
            client = docker.from_env()
            client.images.get(docker_image)
            print(  # noqa: T201
                f"Found existing image tagged {docker_image}, skipping image build. To rebuild, first run: "
                f"docker rmi {docker_image}"
            )
        except docker.errors.ImageNotFound:
            build_and_tag_test_image(docker_image)

    return docker_image
