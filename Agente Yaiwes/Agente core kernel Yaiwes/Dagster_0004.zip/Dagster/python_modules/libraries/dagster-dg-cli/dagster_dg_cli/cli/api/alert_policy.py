"""Alert policy API commands following GitHub CLI patterns."""

import click
from dagster_dg_core.utils import DgClickCommand, DgClickGroup
from dagster_dg_core.utils.telemetry import cli_telemetry_wrapper
from dagster_shared.plus.config import DagsterPlusCliConfig
from dagster_shared.plus.config_utils import dg_api_options
from dagster_shared.yaml_utils import safe_load_yaml

from dagster_dg_cli.cli.api.client import create_dg_api_graphql_client
from dagster_dg_cli.cli.api.formatters import format_alert_policies, format_alert_policy_sync_result
from dagster_dg_cli.cli.api.shared import handle_api_errors
from dagster_dg_cli.cli.response_schema import dg_response_schema


@click.command(name="list", cls=DgClickCommand)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format for machine readability",
)
@dg_response_schema(
    module="dagster_rest_resources.schemas.alert_policy", cls="DgApiAlertPolicyDocument"
)
@dg_api_options(deployment_scoped=True)
@cli_telemetry_wrapper
@click.pass_context
def list_alert_policies_command(
    ctx: click.Context,
    output_json: bool,
    organization: str,
    deployment: str,
    api_token: str,
    view_graphql: bool,
) -> None:
    """List alert policies for a deployment.

    Example::

        $ dg api alert-policy list
        alert_policies:
        - name: failed_run_alert
          description: Alert on failed runs
          enabled: true
          alert_targets:
          - email_target:
              email_addresses:
              - oncall@example.com
          event_types:
          - JOB_FAILURE
        - name: long_running_alert
          description: Alert when runs exceed 1 hour
          enabled: true
          alert_targets:
          - slack_target:
              channel: '#data-alerts'
          event_types:
          - JOB_LONG_RUNNING
    """
    config = DagsterPlusCliConfig.create_for_deployment(
        deployment=deployment,
        organization=organization,
        user_token=api_token,
    )
    client = create_dg_api_graphql_client(ctx, config, view_graphql=view_graphql)
    from dagster_rest_resources.api.alert_policy import DgApiAlertPolicyApi

    api = DgApiAlertPolicyApi(client)

    with handle_api_errors(ctx, output_json):
        policies = api.list_alert_policies_as_document()
        output = format_alert_policies(policies, as_json=output_json)
        click.echo(output)


@click.command(name="sync", cls=DgClickCommand)
@click.argument("file_path", required=True, type=click.Path(exists=True))
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output in JSON format for machine readability",
)
@dg_response_schema(
    module="dagster_rest_resources.schemas.alert_policy", cls="DgApiAlertPolicySyncResult"
)
@dg_api_options(deployment_scoped=True)
@cli_telemetry_wrapper
@click.pass_context
def sync_alert_policies_command(
    ctx: click.Context,
    file_path: str,
    output_json: bool,
    organization: str,
    deployment: str,
    api_token: str,
    view_graphql: bool,
) -> None:
    """Sync alert policies from a YAML file.

    Example::

        $ dg api alert-policy sync alert_policies.yaml
        Synced alert policies: failed_run_alert, long_running_alert
    """
    with open(file_path, encoding="utf-8") as f:
        config = safe_load_yaml(f)

    if not isinstance(config, (list, dict)):
        raise click.ClickException(
            f"Expected a YAML list or mapping in {file_path}, got {type(config).__name__}"
        )

    # Support both raw list and dict with "alert_policies" key
    if isinstance(config, dict):
        alert_policies = config.get("alert_policies", [])
    else:
        alert_policies = config

    cli_config = DagsterPlusCliConfig.create_for_deployment(
        deployment=deployment,
        organization=organization,
        user_token=api_token,
    )
    client = create_dg_api_graphql_client(ctx, cli_config, view_graphql=view_graphql)
    from dagster_rest_resources.api.alert_policy import DgApiAlertPolicyApi

    api = DgApiAlertPolicyApi(client)

    with handle_api_errors(ctx, output_json):
        result = api.action_sync_alert_policies(alert_policies)
        output = format_alert_policy_sync_result(result, as_json=output_json)
        click.echo(output)


@click.group(
    name="alert-policy",
    cls=DgClickGroup,
    commands={
        "list": list_alert_policies_command,
        "sync": sync_alert_policies_command,
    },
)
def alert_policy_group():
    """Manage alert policies in Dagster Plus."""
