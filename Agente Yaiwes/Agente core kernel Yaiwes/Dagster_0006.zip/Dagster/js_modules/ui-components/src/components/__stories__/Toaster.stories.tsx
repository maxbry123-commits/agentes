import {Box} from '../Box';
import {Button} from '../Button';
import {showToast} from '../Toaster';

// eslint-disable-next-line import/no-default-export
export default {
  title: 'Toaster',
};

export const Sizes = () => {
  return (
    <Box flex={{direction: 'column', gap: 16, alignItems: 'flex-start'}}>
      <Button
        onClick={async () =>
          showToast({
            intent: 'none',
            message: 'Code location reloaded',
            timeout: 300000,
            icon: 'done',
          })
        }
      >
        Basic Toast with Icon
      </Button>
      <Button
        onClick={async () =>
          showToast({
            intent: 'success',
            timeout: 300000,
            message: (
              <div>
                Created backfill job:{' '}
                <strong>
                  <code>12345</code>
                </strong>
              </div>
            ),
          })
        }
      >
        Success Toast with React Content
      </Button>
      <Button
        onClick={async () =>
          showToast({
            intent: 'danger',
            timeout: 300000,
            message: 'This is an error message',
            icon: 'error',
          })
        }
      >
        Error Toast
      </Button>
      <Button
        onClick={async () =>
          showToast({
            intent: 'primary',
            timeout: 5000,
            message: 'This is a primary toaster',
            icon: 'account_circle',
          })
        }
      >
        Primary Toast
      </Button>
      <Button
        onClick={async () =>
          showToast({
            intent: 'danger',
            message: 'Oh no an error! Look at the console!',
            timeout: 300000,
            action: {
              type: 'button',
              text: 'View error',
              onClick: () => {
                console.log('HERE IS AN ERROR IN THE CONSOLE');
              },
            },
          })
        }
      >
        Toast with Action
      </Button>
    </Box>
  );
};
