package teamresources

import "testing"

func TestInventoryTracksBlockingResources(t *testing.T) {
	inventory := &Inventory{TeamID: "team-1"}
	if inventory.HasBlockingResources() {
		t.Fatal("empty inventory should not block deletion")
	}

	inventory.AddBlocking("sandboxes", 2)
	inventory.AddBlocking("api_keys", 0)

	if !inventory.HasBlockingResources() {
		t.Fatal("inventory with blocking resources should block deletion")
	}
	if len(inventory.BlockingResources) != 1 {
		t.Fatalf("blocking resources = %d, want 1", len(inventory.BlockingResources))
	}
	if inventory.BlockingResources[0].Category != "sandboxes" || inventory.BlockingResources[0].Count != 2 {
		t.Fatalf("blocking resource = %#v, want sandboxes count 2", inventory.BlockingResources[0])
	}
}

func TestRepositoryBlockingQueriesCoverTeamScopedStores(t *testing.T) {
	repo := NewRepository(nil)
	got := map[string]bool{}
	for _, query := range repo.blockingQueries() {
		got[query.category] = true
	}

	want := []string{
		"api_keys",
		"ssh_public_keys",
		"scheduler_templates",
		"scheduler_template_builds",
		"credential_sources",
		"credential_source_versions",
		"sandbox_egress_credential_bindings",
		"sandboxes",
		"sandbox_lifecycle_transactions",
		"sandbox_rootfs_bindings",
		"rootfs_filesystems",
		"rootfs_snapshots",
		"rootfs_generations",
		"rootfs_materialization_objects",
		"rootfs_object_deletions",
		"team_quota_limits",
	}
	for _, category := range want {
		if !got[category] {
			t.Fatalf("missing blocking query category %q", category)
		}
	}
}

func TestRepositoryRetainsBoundedWebhookDeliveriesWithoutQueryingPostgresMetering(t *testing.T) {
	repo := NewRepository(nil)
	got := repo.retainedQueries()
	if len(got) != 1 || got[0].category != "sandbox_deletion_webhook_deliveries" {
		t.Fatalf("retained queries = %#v, want sandbox deletion webhook deliveries only", got)
	}
	if MeteringRetentionPolicy == "" {
		t.Fatal("metering retention policy must be explicit")
	}
}

func TestDiscoveryHelpers(t *testing.T) {
	schemas := compactSchemas([]string{"shared_gateway", "", "manager", "shared_gateway", " "})
	if len(schemas) != 2 || schemas[0] != "shared_gateway" || schemas[1] != "manager" {
		t.Fatalf("schemas = %#v, want shared_gateway and manager", schemas)
	}

	if !isIgnoredDiscoveredTable("shared_gateway", "team_members") {
		t.Fatal("team_members should be ignored because team deletion cascades membership")
	}
	if !isIgnoredDiscoveredTable("shared_gateway", "team_admission_states") {
		t.Fatal("team_admission_states should be ignored because team deletion triggers admission state cleanup")
	}
	if isIgnoredDiscoveredTable("manager", "sandboxes") {
		t.Fatal("sandboxes should not be ignored")
	}
	if got := discoveredCategory("manager", "custom_team_table"); got != "manager.custom_team_table" {
		t.Fatalf("category = %q, want manager.custom_team_table", got)
	}
}
