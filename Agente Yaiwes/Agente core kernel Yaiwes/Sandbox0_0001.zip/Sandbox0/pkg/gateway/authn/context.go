package authn

import (
	"context"
)

type contextKey string

const authContextKey contextKey = "auth_context"

// AuthMethod defines authentication methods.
type AuthMethod string

const (
	AuthMethodAPIKey   AuthMethod = "api_key"
	AuthMethodJWT      AuthMethod = "jwt"
	AuthMethodInternal AuthMethod = "internal"
)

// PrincipalKind identifies the authenticated principal type.
type PrincipalKind string

const (
	PrincipalKindHuman           PrincipalKind = "human"
	PrincipalKindAPIKey          PrincipalKind = "api_key"
	PrincipalKindInternal        PrincipalKind = "internal"
	PrincipalKindService         PrincipalKind = "service"
	PrincipalKindSandboxWorkload PrincipalKind = "sandbox_workload"
)

// Principal is a transport-agnostic identity for authorization decisions.
type Principal struct {
	Kind       PrincipalKind
	ID         string
	TeamID     string
	UserID     string
	APIKeyID   string
	Service    string
	AuthMethod AuthMethod
}

// AuthContext contains authentication information for a request.
type AuthContext struct {
	AuthMethod AuthMethod
	TeamID     string
	UserID     string
	APIKeyID   string

	TeamRole      string
	IsSystemAdmin bool
	Permissions   []string

	// Caller is the authenticated service for the current internal transport.
	Caller string
	// OriginalPrincipal is the signed edge principal delegated across internal
	// hops. It never changes authorization semantics.
	OriginalPrincipal *Principal
	OperationID       string
	RequestID         string
}

// Principal returns the normalized principal for this auth context.
func (ac *AuthContext) Principal() Principal {
	if ac.OriginalPrincipal != nil {
		principal := *ac.OriginalPrincipal
		principal.TeamID = ac.TeamID
		return principal
	}
	switch ac.AuthMethod {
	case AuthMethodAPIKey:
		return Principal{Kind: PrincipalKindAPIKey, ID: ac.APIKeyID, TeamID: ac.TeamID, UserID: ac.UserID, APIKeyID: ac.APIKeyID, AuthMethod: ac.AuthMethod}
	case AuthMethodInternal:
		return Principal{Kind: PrincipalKindService, ID: ac.Caller, TeamID: ac.TeamID, UserID: ac.UserID, Service: ac.Caller, AuthMethod: ac.AuthMethod}
	default:
		return Principal{Kind: PrincipalKindHuman, ID: ac.UserID, TeamID: ac.TeamID, UserID: ac.UserID, AuthMethod: ac.AuthMethod}
	}
}

// Predefined permissions.
const (
	PermSandboxCreate = "sandbox:create"
	PermSandboxRead   = "sandbox:read"
	PermSandboxWrite  = "sandbox:write"
	PermSandboxDelete = "sandbox:delete"

	PermTemplateCreate = "template:create"
	PermTemplateRead   = "template:read"
	PermTemplateWrite  = "template:write"
	PermTemplateDelete = "template:delete"

	PermRegistryWrite = "registry:write"

	PermAPIKeyManage = "apikey:manage"

	PermCredentialSourceRead   = "credentialsource:read"
	PermCredentialSourceWrite  = "credentialsource:write"
	PermCredentialSourceDelete = "credentialsource:delete"

	PermQuotaRead = "quota:read"
	PermUsageRead = "usage:read"

	PermSandboxObservabilityWrite = "sandboxobservability:write"
	PermSandboxAuditRead          = "sandboxaudit:read"
)

// RolePermissions maps team roles to their permissions.
var RolePermissions = map[string][]string{
	"admin": {
		PermSandboxCreate,
		PermSandboxRead,
		PermSandboxWrite,
		PermSandboxDelete,
		PermTemplateCreate,
		PermTemplateRead,
		PermTemplateWrite,
		PermTemplateDelete,
		PermRegistryWrite,
		PermAPIKeyManage,
		PermCredentialSourceRead,
		PermCredentialSourceWrite,
		PermCredentialSourceDelete,
		PermQuotaRead,
		PermUsageRead,
		PermSandboxAuditRead,
	},
	"developer": {
		PermSandboxCreate,
		PermSandboxRead,
		PermSandboxWrite,
		PermSandboxDelete,
		PermTemplateRead,
		PermRegistryWrite,
		PermCredentialSourceRead,
		PermCredentialSourceWrite,
		PermCredentialSourceDelete,
		PermQuotaRead,
		PermUsageRead,
	},
	"builder": {
		PermTemplateRead,
		PermRegistryWrite,
	},
	"viewer": {
		PermSandboxRead,
		PermTemplateRead,
		PermCredentialSourceRead,
		PermQuotaRead,
		PermUsageRead,
	},
}

// WithAuthContext adds auth context to the context.
func WithAuthContext(ctx context.Context, authCtx *AuthContext) context.Context {
	return context.WithValue(ctx, authContextKey, authCtx)
}

// FromContext extracts auth context from the context.
func FromContext(ctx context.Context) *AuthContext {
	if v := ctx.Value(authContextKey); v != nil {
		return v.(*AuthContext)
	}
	return nil
}

// HasPermission checks if the auth context has a specific permission.
func (ac *AuthContext) HasPermission(permission string) bool {
	for _, p := range ac.Permissions {
		if p == permission || p == "*:*" || p == "*" {
			return true
		}
	}
	return false
}

// HasRole checks if the auth context has a specific role.
func (ac *AuthContext) HasRole(role string) bool {
	return ac.TeamRole == role
}

// ExpandRolePermissions expands a team role into permissions.
func ExpandRolePermissions(role string) []string {
	permSet := make(map[string]struct{})
	if perms, ok := RolePermissions[role]; ok {
		for _, p := range perms {
			permSet[p] = struct{}{}
		}
	}

	permissions := make([]string, 0, len(permSet))
	for p := range permSet {
		permissions = append(permissions, p)
	}
	return permissions
}

// ExpandRolesPermissions expands a list of roles into permissions.
func ExpandRolesPermissions(roles []string) []string {
	permSet := make(map[string]struct{})
	for _, role := range roles {
		if perms, ok := RolePermissions[role]; ok {
			for _, p := range perms {
				permSet[p] = struct{}{}
			}
		}
	}

	permissions := make([]string, 0, len(permSet))
	for p := range permSet {
		permissions = append(permissions, p)
	}
	return permissions
}
