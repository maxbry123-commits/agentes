package objectstore

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/aws/smithy-go"
	"github.com/aws/smithy-go/middleware"
	smithyhttp "github.com/aws/smithy-go/transport/http"
	"golang.org/x/oauth2/google"
)

const (
	TypeS3  = "s3"
	TypeOSS = "oss"
	TypeGCS = "gs"
	TypeMem = "mem"
)

type Config struct {
	Type         string
	Bucket       string
	Region       string
	Endpoint     string
	AccessKey    string
	SecretKey    string
	SessionToken string
	// RequestObserver receives provider HTTP attempts. It is intentionally
	// separate from Metrics because attributed request counts belong in the
	// durable metering ledger, not in high-cardinality Prometheus labels.
	RequestObserver RequestObserver
}

type Info struct {
	Key      string
	Size     int64
	Modified time.Time
	IsPrefix bool
}

type Store interface {
	String() string
	Create() error
	Get(key string, off, limit int64) (io.ReadCloser, error)
	Put(key string, in io.Reader) error
	Delete(key string) error
	Head(key string) (Info, error)
	List(prefix, startAfter, token, delimiter string, limit int64) ([]Info, bool, string, error)
}

// ConditionalStore can create an immutable object without overwriting an
// existing key. created=false is not an error; callers must verify that the
// existing object has the expected immutable content.
type ConditionalStore interface {
	Store
	PutIfAbsent(key string, in io.Reader) (created bool, err error)
}

// ContextConditionalStore is required by bounded workers whose object reads
// and immutable writes must stop when their operation context is canceled.
type ContextConditionalStore interface {
	ConditionalStore
	GetContext(ctx context.Context, key string, off, limit int64) (io.ReadCloser, error)
	PutIfAbsentContext(ctx context.Context, key string, in io.Reader) (created bool, err error)
}

type conditionalCreateCapability interface {
	supportsConditionalCreate() bool
}

type contextConditionalCreateCapability interface {
	supportsContextConditionalCreate() bool
}

// SupportsConditionalCreate follows wrappers instead of relying only on their
// method set. Wrappers expose PutIfAbsent so callers can use one interface, but
// they cannot add atomic create semantics to an unsupported provider.
func SupportsConditionalCreate(store Store) bool {
	if store == nil {
		return false
	}
	if capability, ok := store.(conditionalCreateCapability); ok {
		return capability.supportsConditionalCreate()
	}
	_, ok := store.(ConditionalStore)
	return ok
}

// SupportsContextConditionalCreate follows wrappers and verifies that
// cancellation reaches both collision reads and conditional writes.
func SupportsContextConditionalCreate(store Store) bool {
	if store == nil || !SupportsConditionalCreate(store) {
		return false
	}
	if capability, ok := store.(contextConditionalCreateCapability); ok {
		return capability.supportsContextConditionalCreate()
	}
	_, ok := store.(ContextConditionalStore)
	return ok
}

type contextObjectReader struct {
	ctx    context.Context
	reader io.Reader
}

func withObjectReadContext(ctx context.Context, reader io.Reader) io.Reader {
	if reader == nil {
		return nil
	}
	contextual := contextObjectReader{ctx: ctx, reader: reader}
	if seeker, ok := reader.(io.Seeker); ok {
		return contextObjectReadSeeker{contextObjectReader: contextual, seeker: seeker}
	}
	return contextual
}

func (r contextObjectReader) Read(payload []byte) (int, error) {
	if err := r.ctx.Err(); err != nil {
		return 0, err
	}
	read, err := r.reader.Read(payload)
	if read == 0 && err == nil {
		if contextErr := r.ctx.Err(); contextErr != nil {
			return 0, contextErr
		}
	}
	return read, err
}

type contextObjectReadSeeker struct {
	contextObjectReader
	seeker io.Seeker
}

func (r contextObjectReadSeeker) Seek(offset int64, whence int) (int64, error) {
	if err := r.ctx.Err(); err != nil {
		return 0, err
	}
	return r.seeker.Seek(offset, whence)
}

func NormalizeType(raw string) string {
	value := strings.TrimSpace(strings.ToLower(raw))
	switch value {
	case "", "builtin", TypeS3:
		return TypeS3
	case TypeOSS:
		return TypeOSS
	case "gcs", TypeGCS:
		return TypeGCS
	case TypeMem:
		return TypeMem
	default:
		return value
	}
}

func BuildEndpoint(cfg Config) (string, string, error) {
	storageType := NormalizeType(cfg.Type)
	bucket := strings.TrimSpace(cfg.Bucket)
	if bucket == "" && storageType != TypeMem {
		return "", "", fmt.Errorf("object storage bucket is required")
	}

	switch storageType {
	case TypeS3:
		endpoint := strings.TrimRight(strings.TrimSpace(cfg.Endpoint), "/")
		if endpoint == "" {
			region := strings.TrimSpace(cfg.Region)
			if region == "" {
				return "", "", fmt.Errorf("object storage region or endpoint is required for s3")
			}
			endpoint = fmt.Sprintf("https://s3.%s.amazonaws.com", region)
		}
		return storageType, endpoint, nil
	case TypeOSS:
		endpoint := strings.TrimRight(strings.TrimSpace(cfg.Endpoint), "/")
		if endpoint == "" {
			return "", "", fmt.Errorf("object storage endpoint is required for oss")
		}
		return storageType, endpoint, nil
	case TypeGCS:
		return storageType, fmt.Sprintf("gs://%s", bucket), nil
	case TypeMem:
		return storageType, "mem://" + bucket, nil
	default:
		return "", "", fmt.Errorf("unsupported object storage type: %s", storageType)
	}
}

func Create(cfg Config) (Store, error) {
	storageType := NormalizeType(cfg.Type)
	switch storageType {
	case TypeMem:
		return NewMemoryStore(strings.TrimSpace(cfg.Bucket)), nil
	case TypeS3, TypeOSS:
		store, err := newS3Store(cfg)
		if err != nil {
			return nil, err
		}
		return store, nil
	case TypeGCS:
		store, err := newGCSStore(cfg)
		if err != nil {
			return nil, err
		}
		return store, nil
	default:
		return nil, fmt.Errorf("unsupported object storage type: %s", storageType)
	}
}

func IsNotFound(err error) bool {
	if err == nil {
		return false
	}
	var apiErr smithy.APIError
	if errors.As(err, &apiErr) {
		switch strings.ToLower(apiErr.ErrorCode()) {
		case "notfound", "nosuchkey", "nosuchbucket", "404":
			return true
		}
	}
	message := strings.ToLower(err.Error())
	return strings.Contains(message, "not found") ||
		strings.Contains(message, "nosuchkey") ||
		strings.Contains(message, "no such key") ||
		strings.Contains(message, "status=404")
}

func Prefix(store Store, prefix string) Store {
	prefix = strings.Trim(strings.TrimSpace(prefix), "/")
	if store == nil || prefix == "" {
		return store
	}
	return &prefixedStore{
		store:  store,
		prefix: prefix + "/",
	}
}

var sharedMemoryNamespaces sync.Map

func NewMemoryStore(namespace string) Store {
	namespace = strings.TrimSpace(namespace)
	state := &memoryStoreState{
		objects: make(map[string][]byte),
	}
	if namespace != "" {
		shared, _ := sharedMemoryNamespaces.LoadOrStore(namespace, state)
		state = shared.(*memoryStoreState)
	}
	return &memoryStore{
		namespace: namespace,
		state:     state,
	}
}

type s3Store struct {
	client    *s3.Client
	bucket    string
	endpoint  string
	provider  string
	pathStyle bool
}

func newS3Store(cfg Config) (Store, error) {
	storageType, endpoint, err := BuildEndpoint(cfg)
	if err != nil {
		return nil, err
	}

	region := strings.TrimSpace(cfg.Region)
	if region == "" {
		region = "us-east-1"
	}

	loadOptions := []func(*awsconfig.LoadOptions) error{
		awsconfig.WithRegion(region),
		awsconfig.WithRequestChecksumCalculation(aws.RequestChecksumCalculationWhenRequired),
		awsconfig.WithResponseChecksumValidation(aws.ResponseChecksumValidationWhenRequired),
	}
	if cfg.AccessKey != "" || cfg.SecretKey != "" || cfg.SessionToken != "" {
		loadOptions = append(loadOptions, awsconfig.WithCredentialsProvider(credentials.NewStaticCredentialsProvider(
			cfg.AccessKey,
			cfg.SecretKey,
			cfg.SessionToken,
		)))
	}

	awsCfg, err := awsconfig.LoadDefaultConfig(context.Background(), loadOptions...)
	if err != nil {
		return nil, fmt.Errorf("load object storage config: %w", err)
	}
	if cfg.RequestObserver != nil {
		awsCfg.HTTPClient = newRequestObservingHTTPClient(
			awsCfg.HTTPClient,
			storageType,
			strings.TrimSpace(cfg.Bucket),
			cfg.RequestObserver,
		)
	}

	pathStyle := storageType != TypeOSS
	options := func(o *s3.Options) {
		// OSS S3-compatible endpoints require virtual-hosted bucket addressing.
		// Generic S3-compatible stores keep the existing path-style contract.
		o.UsePathStyle = pathStyle
		if endpoint != "" {
			o.BaseEndpoint = aws.String(endpoint)
		}
	}

	return &s3Store{
		client:    s3.NewFromConfig(awsCfg, options),
		bucket:    strings.TrimSpace(cfg.Bucket),
		endpoint:  endpoint,
		provider:  storageType,
		pathStyle: pathStyle,
	}, nil
}

func (s *s3Store) String() string {
	return fmt.Sprintf("%s://%s", s.provider, s.bucket)
}

func (s *s3Store) Create() error {
	if s.provider == TypeOSS {
		// OSS bucket lifecycle belongs to regional infrastructure. Runtime
		// credentials are intentionally object-scoped and must not require
		// HeadBucket or CreateBucket permissions just to open that bucket.
		return nil
	}
	ctx := context.Background()
	if _, err := s.client.HeadBucket(ctx, &s3.HeadBucketInput{Bucket: aws.String(s.bucket)}); err == nil {
		return nil
	} else if !IsNotFound(err) {
		return fmt.Errorf("check object storage bucket before create: %w", err)
	}
	_, err := s.client.CreateBucket(ctx, &s3.CreateBucketInput{
		Bucket: aws.String(s.bucket),
	})
	if err != nil && isBucketCreateRace(err) {
		// A concurrent creator or providers such as OSS can report a generic
		// already-exists result. Only accept it after these credentials can HEAD
		// the exact configured bucket; this never treats another owner's bucket
		// as successfully initialized.
		if _, headErr := s.client.HeadBucket(ctx, &s3.HeadBucketInput{Bucket: aws.String(s.bucket)}); headErr == nil {
			return nil
		}
	}
	return err
}

func (s *s3Store) Get(key string, off, limit int64) (io.ReadCloser, error) {
	return s.GetContext(context.Background(), key, off, limit)
}

func (s *s3Store) GetContext(ctx context.Context, key string, off, limit int64) (io.ReadCloser, error) {
	if ctx == nil {
		return nil, fmt.Errorf("object read context is required")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	input := &s3.GetObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(strings.TrimLeft(key, "/")),
	}
	if off > 0 || limit >= 0 {
		switch {
		case limit < 0:
			input.Range = aws.String(fmt.Sprintf("bytes=%d-", off))
		case limit == 0:
			return io.NopCloser(bytes.NewReader(nil)), nil
		default:
			input.Range = aws.String(fmt.Sprintf("bytes=%d-%d", off, off+limit-1))
		}
	}
	resp, err := s.client.GetObject(ctx, input)
	if err != nil {
		return nil, err
	}
	return resp.Body, nil
}

func (s *s3Store) Put(key string, in io.Reader) error {
	_, err := s.client.PutObject(context.Background(), &s3.PutObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(strings.TrimLeft(key, "/")),
		Body:   in,
	})
	return err
}

func (s *s3Store) PutIfAbsent(key string, in io.Reader) (bool, error) {
	return s.PutIfAbsentContext(context.Background(), key, in)
}

func (s *s3Store) PutIfAbsentContext(ctx context.Context, key string, in io.Reader) (bool, error) {
	if ctx == nil {
		return false, fmt.Errorf("conditional object write context is required")
	}
	if err := ctx.Err(); err != nil {
		return false, err
	}
	input := &s3.PutObjectInput{
		Bucket: aws.String(s.bucket), Key: aws.String(strings.TrimLeft(key, "/")),
		Body: withObjectReadContext(ctx, in),
	}
	options := make([]func(*s3.Options), 0, 1)
	if s.provider == TypeOSS {
		// OSS rejects the standard S3 If-None-Match conditional on PutObject.
		// Its signed x-oss-forbid-overwrite header provides the corresponding
		// atomic create-only operation and returns FileAlreadyExists on collision.
		options = append(options, withOSSForbidOverwrite)
	} else {
		input.IfNoneMatch = aws.String("*")
	}
	_, err := s.client.PutObject(ctx, input, options...)
	if isConditionalCreateConflict(err) {
		return false, nil
	}
	return err == nil, err
}

type ossForbidOverwriteMiddleware struct{}

func (ossForbidOverwriteMiddleware) ID() string { return "Sandbox0OSSForbidOverwrite" }

func (ossForbidOverwriteMiddleware) HandleFinalize(
	ctx context.Context,
	input middleware.FinalizeInput,
	next middleware.FinalizeHandler,
) (middleware.FinalizeOutput, middleware.Metadata, error) {
	request, ok := input.Request.(*smithyhttp.Request)
	if !ok || request == nil || request.Request == nil {
		return middleware.FinalizeOutput{}, middleware.Metadata{},
			fmt.Errorf("OSS conditional create request is unavailable before signing")
	}
	request.Header.Set("x-oss-forbid-overwrite", "true")
	return next.HandleFinalize(ctx, input)
}

func withOSSForbidOverwrite(options *s3.Options) {
	options.APIOptions = append(options.APIOptions, func(stack *middleware.Stack) error {
		return stack.Finalize.Insert(ossForbidOverwriteMiddleware{}, "Signing", middleware.Before)
	})
}

func (s *s3Store) Delete(key string) error {
	_, err := s.client.DeleteObject(context.Background(), &s3.DeleteObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(strings.TrimLeft(key, "/")),
	})
	return err
}

func (s *s3Store) Head(key string) (Info, error) {
	if strings.TrimSpace(key) == "" {
		_, err := s.client.HeadBucket(context.Background(), &s3.HeadBucketInput{
			Bucket: aws.String(s.bucket),
		})
		return Info{}, err
	}
	resp, err := s.client.HeadObject(context.Background(), &s3.HeadObjectInput{
		Bucket: aws.String(s.bucket),
		Key:    aws.String(strings.TrimLeft(key, "/")),
	})
	if err != nil {
		return Info{}, err
	}
	return Info{
		Key:      strings.TrimLeft(key, "/"),
		Size:     aws.ToInt64(resp.ContentLength),
		Modified: aws.ToTime(resp.LastModified),
	}, nil
}

func (s *s3Store) List(prefix, startAfter, token, delimiter string, limit int64) ([]Info, bool, string, error) {
	maxKeys := int32(limit)
	if limit <= 0 || limit > 1000 {
		maxKeys = 1000
	}
	resp, err := s.client.ListObjectsV2(context.Background(), &s3.ListObjectsV2Input{
		Bucket:            aws.String(s.bucket),
		Prefix:            aws.String(strings.TrimLeft(prefix, "/")),
		StartAfter:        aws.String(strings.TrimLeft(startAfter, "/")),
		ContinuationToken: emptyStringPtr(token),
		Delimiter:         emptyStringPtr(delimiter),
		MaxKeys:           aws.Int32(maxKeys),
	})
	if err != nil {
		return nil, false, "", err
	}
	objects := make([]Info, 0, len(resp.Contents)+len(resp.CommonPrefixes))
	for _, item := range resp.Contents {
		objects = append(objects, Info{
			Key:      aws.ToString(item.Key),
			Size:     aws.ToInt64(item.Size),
			Modified: aws.ToTime(item.LastModified),
		})
	}
	for _, item := range resp.CommonPrefixes {
		prefix := aws.ToString(item.Prefix)
		if prefix == "" {
			continue
		}
		objects = append(objects, Info{Key: prefix, IsPrefix: true})
	}
	sortInfos(objects)
	return objects, resp.IsTruncated != nil && *resp.IsTruncated, aws.ToString(resp.NextContinuationToken), nil
}

func emptyStringPtr(value string) *string {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil
	}
	return aws.String(value)
}

type gcsStore struct {
	client    *http.Client
	bucket    string
	projectID string
	baseURL   string
}

func newGCSStore(cfg Config) (Store, error) {
	bucket := strings.TrimSpace(cfg.Bucket)
	if bucket == "" {
		return nil, fmt.Errorf("object storage bucket is required")
	}
	client, err := google.DefaultClient(context.Background(), "https://www.googleapis.com/auth/devstorage.full_control")
	if err != nil {
		return nil, fmt.Errorf("create gcs client: %w", err)
	}
	return &gcsStore{
		client:    client,
		bucket:    bucket,
		projectID: gcsProjectID(cfg),
		baseURL:   gcsBaseURL(cfg),
	}, nil
}

func gcsBaseURL(cfg Config) string {
	if endpoint := strings.TrimRight(strings.TrimSpace(cfg.Endpoint), "/"); endpoint != "" {
		return endpoint
	}
	return "https://storage.googleapis.com"
}

func gcsProjectID(cfg Config) string {
	for _, value := range []string{
		cfg.Region,
		os.Getenv("GOOGLE_CLOUD_PROJECT"),
		os.Getenv("GCLOUD_PROJECT"),
		os.Getenv("GCP_PROJECT"),
	} {
		if trimmed := strings.TrimSpace(value); trimmed != "" {
			return trimmed
		}
	}
	return ""
}

func (s *gcsStore) String() string {
	return fmt.Sprintf("gs://%s", s.bucket)
}

func (s *gcsStore) Create() error {
	if s.projectID == "" {
		return fmt.Errorf("gcs project id is required to create bucket %q; pre-create the bucket or set GOOGLE_CLOUD_PROJECT", s.bucket)
	}
	body, err := json.Marshal(map[string]string{"name": s.bucket})
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(context.Background(), http.MethodPost, s.bucketCollectionURL("project", s.projectID), bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	return s.doNoContent(req)
}

func (s *gcsStore) Get(key string, off, limit int64) (io.ReadCloser, error) {
	return s.GetContext(context.Background(), key, off, limit)
}

func (s *gcsStore) GetContext(ctx context.Context, key string, off, limit int64) (io.ReadCloser, error) {
	if ctx == nil {
		return nil, fmt.Errorf("object read context is required")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if limit == 0 {
		return io.NopCloser(bytes.NewReader(nil)), nil
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, s.objectURL(gcsObjectName(key), "alt", "media"), nil)
	if err != nil {
		return nil, err
	}
	if off > 0 || limit >= 0 {
		switch {
		case limit < 0:
			req.Header.Set("Range", fmt.Sprintf("bytes=%d-", off))
		default:
			req.Header.Set("Range", fmt.Sprintf("bytes=%d-%d", off, off+limit-1))
		}
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		defer resp.Body.Close()
		return nil, gcsHTTPError(resp)
	}
	return resp.Body, nil
}

func (s *gcsStore) Put(key string, in io.Reader) error {
	req, err := http.NewRequestWithContext(context.Background(), http.MethodPost, s.uploadURL(gcsObjectName(key)), in)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	return s.doNoContent(req)
}

func (s *gcsStore) PutIfAbsent(key string, in io.Reader) (bool, error) {
	return s.PutIfAbsentContext(context.Background(), key, in)
}

func (s *gcsStore) PutIfAbsentContext(ctx context.Context, key string, in io.Reader) (bool, error) {
	if ctx == nil {
		return false, fmt.Errorf("conditional object write context is required")
	}
	if err := ctx.Err(); err != nil {
		return false, err
	}
	values := url.Values{}
	values.Set("uploadType", "media")
	values.Set("name", gcsObjectName(key))
	values.Set("ifGenerationMatch", "0")
	rawURL := strings.TrimRight(s.baseURL, "/") + "/upload/storage/v1/b/" + url.PathEscape(s.bucket) + "/o?" + values.Encode()
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, rawURL, withObjectReadContext(ctx, in))
	if err != nil {
		return false, err
	}
	req.Header.Set("Content-Type", "application/octet-stream")
	resp, err := s.client.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusPreconditionFailed || resp.StatusCode == http.StatusConflict {
		return false, nil
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return false, gcsHTTPError(resp)
	}
	return true, nil
}

func (s *gcsStore) Delete(key string) error {
	req, err := http.NewRequestWithContext(context.Background(), http.MethodDelete, s.objectURL(gcsObjectName(key)), nil)
	if err != nil {
		return err
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNotFound {
		return nil
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return gcsHTTPError(resp)
	}
	return nil
}

func (s *gcsStore) Head(key string) (Info, error) {
	key = strings.TrimSpace(key)
	if key == "" {
		req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, s.bucketURL(), nil)
		if err != nil {
			return Info{}, err
		}
		return Info{}, s.doNoContent(req)
	}
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, s.objectURL(gcsObjectName(key)), nil)
	if err != nil {
		return Info{}, err
	}
	var attrs gcsObjectAttrs
	err = s.doJSON(req, &attrs)
	if err != nil {
		return Info{}, err
	}
	size, err := strconv.ParseInt(attrs.Size, 10, 64)
	if err != nil {
		return Info{}, fmt.Errorf("parse gcs object size %q: %w", attrs.Size, err)
	}
	return Info{
		Key:      gcsObjectName(attrs.Name),
		Size:     size,
		Modified: attrs.Updated,
	}, nil
}

func (s *gcsStore) List(prefix, startAfter, token, delimiter string, limit int64) ([]Info, bool, string, error) {
	pageSize := int(limit)
	if pageSize <= 0 || pageSize > 1000 {
		pageSize = 1000
	}
	values := url.Values{}
	values.Set("maxResults", strconv.Itoa(pageSize))
	values.Set("prefix", strings.TrimLeft(prefix, "/"))
	if delimiter = strings.TrimSpace(delimiter); delimiter != "" {
		values.Set("delimiter", delimiter)
	}
	if startAfter = strings.TrimLeft(startAfter, "/"); startAfter != "" {
		values.Set("startOffset", startAfter+"\x00")
	}
	if token = strings.TrimSpace(token); token != "" {
		values.Set("pageToken", token)
	}
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, s.bucketObjectsURL(values), nil)
	if err != nil {
		return nil, false, "", err
	}
	var result gcsListResult
	err = s.doJSON(req, &result)
	if err != nil {
		return nil, false, "", err
	}
	objects := make([]Info, 0, len(result.Items)+len(result.Prefixes))
	for _, item := range result.Items {
		if item.Name == "" {
			continue
		}
		size, err := strconv.ParseInt(item.Size, 10, 64)
		if err != nil {
			return nil, false, "", fmt.Errorf("parse gcs object size %q: %w", item.Size, err)
		}
		objects = append(objects, Info{
			Key:      gcsObjectName(item.Name),
			Size:     size,
			Modified: item.Updated,
		})
	}
	for _, prefix := range result.Prefixes {
		if prefix == "" {
			continue
		}
		objects = append(objects, Info{Key: gcsObjectName(prefix), IsPrefix: true})
	}
	sortInfos(objects)
	return objects, result.NextPageToken != "", result.NextPageToken, nil
}

func gcsObjectName(key string) string {
	return strings.TrimLeft(key, "/")
}

type gcsObjectAttrs struct {
	Name    string    `json:"name"`
	Size    string    `json:"size"`
	Updated time.Time `json:"updated"`
}

type gcsListResult struct {
	Items         []gcsObjectAttrs `json:"items"`
	Prefixes      []string         `json:"prefixes"`
	NextPageToken string           `json:"nextPageToken"`
}

func (s *gcsStore) bucketURL() string {
	return strings.TrimRight(s.baseURL, "/") + "/storage/v1/b/" + url.PathEscape(s.bucket)
}

func (s *gcsStore) bucketCollectionURL(keyValues ...string) string {
	values := url.Values{}
	for i := 0; i+1 < len(keyValues); i += 2 {
		if value := strings.TrimSpace(keyValues[i+1]); value != "" {
			values.Set(keyValues[i], value)
		}
	}
	raw := strings.TrimRight(s.baseURL, "/") + "/storage/v1/b"
	if encoded := values.Encode(); encoded != "" {
		raw += "?" + encoded
	}
	return raw
}

func (s *gcsStore) bucketObjectsURL(values url.Values) string {
	raw := s.bucketURL() + "/o"
	if encoded := values.Encode(); encoded != "" {
		raw += "?" + encoded
	}
	return raw
}

func (s *gcsStore) objectURL(name string, keyValues ...string) string {
	values := url.Values{}
	for i := 0; i+1 < len(keyValues); i += 2 {
		if value := strings.TrimSpace(keyValues[i+1]); value != "" {
			values.Set(keyValues[i], value)
		}
	}
	raw := s.bucketURL() + "/o/" + url.PathEscape(name)
	if encoded := values.Encode(); encoded != "" {
		raw += "?" + encoded
	}
	return raw
}

func (s *gcsStore) uploadURL(name string) string {
	values := url.Values{}
	values.Set("uploadType", "media")
	values.Set("name", name)
	return strings.TrimRight(s.baseURL, "/") + "/upload/storage/v1/b/" + url.PathEscape(s.bucket) + "/o?" + values.Encode()
}

func (s *gcsStore) doNoContent(req *http.Request) error {
	resp, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return gcsHTTPError(resp)
	}
	return nil
}

func (s *gcsStore) doJSON(req *http.Request, out any) error {
	resp, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return gcsHTTPError(resp)
	}
	return json.NewDecoder(resp.Body).Decode(out)
}

func gcsHTTPError(resp *http.Response) error {
	body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
	return fmt.Errorf("gcs request failed: status=%d body=%s", resp.StatusCode, strings.TrimSpace(string(body)))
}

type prefixedStore struct {
	store  Store
	prefix string
}

func (s *prefixedStore) String() string {
	return s.store.String()
}

func (s *prefixedStore) Create() error {
	return s.store.Create()
}

func (s *prefixedStore) Get(key string, off, limit int64) (io.ReadCloser, error) {
	return s.store.Get(s.prefixed(key), off, limit)
}

func (s *prefixedStore) GetContext(ctx context.Context, key string, off, limit int64) (io.ReadCloser, error) {
	contextual, ok := s.store.(ContextConditionalStore)
	if !ok || !SupportsContextConditionalCreate(s.store) {
		return nil, fmt.Errorf("underlying object store does not support contextual conditional access")
	}
	return contextual.GetContext(ctx, s.prefixed(key), off, limit)
}

func (s *prefixedStore) Put(key string, in io.Reader) error {
	return s.store.Put(s.prefixed(key), in)
}

func (s *prefixedStore) PutIfAbsent(key string, in io.Reader) (bool, error) {
	conditional, ok := s.store.(ConditionalStore)
	if !ok {
		return false, fmt.Errorf("underlying object store does not support conditional create")
	}
	return conditional.PutIfAbsent(s.prefixed(key), in)
}

func (s *prefixedStore) PutIfAbsentContext(ctx context.Context, key string, in io.Reader) (bool, error) {
	contextual, ok := s.store.(ContextConditionalStore)
	if !ok || !SupportsContextConditionalCreate(s.store) {
		return false, fmt.Errorf("underlying object store does not support contextual conditional access")
	}
	return contextual.PutIfAbsentContext(ctx, s.prefixed(key), in)
}

func (s *prefixedStore) supportsConditionalCreate() bool {
	return s != nil && SupportsConditionalCreate(s.store)
}

func (s *prefixedStore) supportsContextConditionalCreate() bool {
	return s != nil && SupportsContextConditionalCreate(s.store)
}

func (s *prefixedStore) Delete(key string) error {
	return s.store.Delete(s.prefixed(key))
}

func (s *prefixedStore) Head(key string) (Info, error) {
	info, err := s.store.Head(s.prefixed(key))
	if err != nil {
		return Info{}, err
	}
	info.Key = strings.TrimPrefix(info.Key, s.prefix)
	return info, nil
}

func (s *prefixedStore) List(prefix, startAfter, token, delimiter string, limit int64) ([]Info, bool, string, error) {
	listPrefix := s.prefixed(prefix)
	if strings.TrimLeft(strings.TrimSpace(prefix), "/") == "" {
		listPrefix = s.prefix
	}
	listStartAfter := ""
	if strings.TrimLeft(strings.TrimSpace(startAfter), "/") != "" {
		listStartAfter = s.prefixed(startAfter)
	}
	objects, hasMore, nextToken, err := s.store.List(listPrefix, listStartAfter, token, delimiter, limit)
	if err != nil {
		return nil, false, "", err
	}
	for i := range objects {
		objects[i].Key = strings.TrimPrefix(objects[i].Key, s.prefix)
	}
	return objects, hasMore, nextToken, nil
}

func (s *prefixedStore) prefixed(key string) string {
	key = strings.TrimLeft(strings.TrimSpace(key), "/")
	if key == "" {
		return strings.TrimRight(s.prefix, "/")
	}
	return s.prefix + key
}

type memoryStore struct {
	namespace string
	state     *memoryStoreState
}

type memoryStoreState struct {
	mu      sync.RWMutex
	objects map[string][]byte
}

func (s *memoryStore) String() string {
	if s.namespace == "" {
		return "mem://"
	}
	return "mem://" + s.namespace
}

func (s *memoryStore) Create() error {
	return nil
}

func (s *memoryStore) Get(key string, off, limit int64) (io.ReadCloser, error) {
	return s.GetContext(context.Background(), key, off, limit)
}

func (s *memoryStore) GetContext(ctx context.Context, key string, off, limit int64) (io.ReadCloser, error) {
	if ctx == nil {
		return nil, fmt.Errorf("object read context is required")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	s.state.mu.RLock()
	defer s.state.mu.RUnlock()
	payload, ok := s.state.objects[strings.TrimLeft(key, "/")]
	if !ok {
		return nil, errors.New("object not found")
	}
	if off > int64(len(payload)) {
		off = int64(len(payload))
	}
	end := int64(len(payload))
	if limit >= 0 && off+limit < end {
		end = off + limit
	}
	copyPayload := append([]byte(nil), payload[off:end]...)
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return io.NopCloser(bytes.NewReader(copyPayload)), nil
}

func (s *memoryStore) Put(key string, in io.Reader) error {
	payload, err := io.ReadAll(in)
	if err != nil {
		return err
	}
	s.state.mu.Lock()
	defer s.state.mu.Unlock()
	s.state.objects[strings.TrimLeft(key, "/")] = payload
	return nil
}

func (s *memoryStore) PutIfAbsent(key string, in io.Reader) (bool, error) {
	return s.PutIfAbsentContext(context.Background(), key, in)
}

func (s *memoryStore) PutIfAbsentContext(ctx context.Context, key string, in io.Reader) (bool, error) {
	if ctx == nil {
		return false, fmt.Errorf("conditional object write context is required")
	}
	if err := ctx.Err(); err != nil {
		return false, err
	}
	payload, err := io.ReadAll(withObjectReadContext(ctx, in))
	if err != nil {
		return false, err
	}
	if err := ctx.Err(); err != nil {
		return false, err
	}
	s.state.mu.Lock()
	defer s.state.mu.Unlock()
	key = strings.TrimLeft(key, "/")
	if _, ok := s.state.objects[key]; ok {
		return false, nil
	}
	s.state.objects[key] = payload
	return true, nil
}

func isConditionalCreateConflict(err error) bool {
	if err == nil {
		return false
	}
	var apiErr smithy.APIError
	if !errors.As(err, &apiErr) {
		return false
	}
	switch strings.ToLower(apiErr.ErrorCode()) {
	case "preconditionfailed", "conditionnotmatch", "filealreadyexists", "412":
		return true
	default:
		return false
	}
}

func isBucketCreateRace(err error) bool {
	if err == nil {
		return false
	}
	var apiErr smithy.APIError
	if !errors.As(err, &apiErr) {
		return false
	}
	switch strings.ToLower(apiErr.ErrorCode()) {
	case "bucketalreadyexists", "bucketalreadyownedbyyou":
		return true
	default:
		return false
	}
}

func (s *memoryStore) Delete(key string) error {
	s.state.mu.Lock()
	defer s.state.mu.Unlock()
	delete(s.state.objects, strings.TrimLeft(key, "/"))
	return nil
}

func (s *memoryStore) Head(key string) (Info, error) {
	if strings.TrimSpace(key) == "" {
		return Info{}, nil
	}
	s.state.mu.RLock()
	defer s.state.mu.RUnlock()
	payload, ok := s.state.objects[strings.TrimLeft(key, "/")]
	if !ok {
		return Info{}, errors.New("object not found")
	}
	return Info{
		Key:  strings.TrimLeft(key, "/"),
		Size: int64(len(payload)),
	}, nil
}

func (s *memoryStore) List(prefix, startAfter, token, delimiter string, limit int64) ([]Info, bool, string, error) {
	s.state.mu.RLock()
	defer s.state.mu.RUnlock()
	prefix = strings.TrimLeft(prefix, "/")
	cursor := strings.TrimLeft(token, "/")
	if cursor == "" {
		cursor = strings.TrimLeft(startAfter, "/")
	}
	delimiter = strings.TrimSpace(delimiter)
	seenPrefixes := make(map[string]struct{})
	objects := make([]Info, 0, len(s.state.objects))
	for key := range s.state.objects {
		if !strings.HasPrefix(key, prefix) || key <= cursor {
			continue
		}
		if delimiter != "" {
			suffix := strings.TrimPrefix(key, prefix)
			if idx := strings.Index(suffix, delimiter); idx >= 0 {
				dir := prefix + suffix[:idx+len(delimiter)]
				if dir <= cursor {
					continue
				}
				if _, ok := seenPrefixes[dir]; ok {
					continue
				}
				seenPrefixes[dir] = struct{}{}
				objects = append(objects, Info{Key: dir, IsPrefix: true})
				continue
			}
		}
		objects = append(objects, Info{Key: key, Size: int64(len(s.state.objects[key]))})
	}
	sortInfos(objects)
	max := len(objects)
	hasMore := false
	nextToken := ""
	if limit > 0 && int(limit) < max {
		hasMore = true
		max = int(limit)
		nextToken = objects[max-1].Key
	}
	return objects[:max], hasMore, nextToken, nil
}

var (
	_ ContextConditionalStore = (*s3Store)(nil)
	_ ContextConditionalStore = (*gcsStore)(nil)
	_ ContextConditionalStore = (*prefixedStore)(nil)
	_ ContextConditionalStore = (*memoryStore)(nil)
)

func sortInfos(values []Info) {
	sort.Slice(values, func(i, j int) bool {
		return values[i].Key < values[j].Key
	})
}

type Encryptor interface {
	Encrypt([]byte) ([]byte, error)
	Decrypt([]byte) ([]byte, error)
}
