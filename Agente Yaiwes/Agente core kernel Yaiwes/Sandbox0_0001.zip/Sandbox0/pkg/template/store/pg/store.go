package pg

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"
	v1alpha1 "github.com/sandbox0-ai/sandbox0/pkg/sandboxspec"
	"github.com/sandbox0-ai/sandbox0/pkg/template"
	"github.com/sandbox0-ai/sandbox0/pkg/template/store"
)

// Store implements the region-authoritative template store in PostgreSQL.
type Store struct {
	pool *pgxpool.Pool
}

// NewStore creates a new Store.
func NewStore(pool *pgxpool.Pool) *Store {
	return &Store{pool: pool}
}

// Ping checks database connectivity.
func (s *Store) Ping(ctx context.Context) error {
	return s.pool.Ping(ctx)
}

// ListImageSourcesForRootFSImport scans ready image templates with a bounded
// keyset cursor. Every manager may run the scan because import creation is
// idempotent in the shared PostgreSQL authority.
func (s *Store) ListImageSourcesForRootFSImport(
	ctx context.Context,
	cursor store.ImageSourceCursor,
	limit int,
) ([]store.ImageSource, error) {
	if s == nil || s.pool == nil {
		return nil, fmt.Errorf("template image source store is not configured")
	}
	if limit <= 0 || limit > 1000 {
		return nil, fmt.Errorf("template image source limit must be within 1..1000")
	}
	rows, err := s.pool.Query(ctx, `
		SELECT scope, team_id, template_id,
			COALESCE(spec #>> '{mainContainer,image}', ''),
			COALESCE(spec #>> '{mainContainer,resources,ephemeralStorage}', '')
		FROM scheduler_templates
		WHERE creation_state = 'ready'
			AND rootfs_snapshot_id IS NULL
			AND ROW(scope, team_id, template_id) > ROW($1, $2, $3)
		ORDER BY scope, team_id, template_id
		LIMIT $4
	`, cursor.Scope, cursor.TeamID, cursor.TemplateID, limit)
	if err != nil {
		return nil, fmt.Errorf("list template image sources for RootFS import: %w", err)
	}
	defer rows.Close()

	sources := make([]store.ImageSource, 0, limit)
	for rows.Next() {
		var source store.ImageSource
		if err := rows.Scan(
			&source.Cursor.Scope,
			&source.Cursor.TeamID,
			&source.Cursor.TemplateID,
			&source.Image,
			&source.EphemeralStorage,
		); err != nil {
			return nil, fmt.Errorf("scan template image source for RootFS import: %w", err)
		}
		sources = append(sources, source)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("iterate template image sources for RootFS import: %w", err)
	}
	return sources, nil
}

const templateSelectColumns = `
	template_id, scope, team_id, user_id, spec, created_at, updated_at,
	creation_build_id::text, creation_idempotency_key, creation_request_hash,
	creation_state, creation_stage, creation_started_at, creation_captured_at,
	creation_completed_at, creation_reason, creation_message,
	rootfs_storage_format, rootfs_snapshot_id, rootfs_generation_id,
	rootfs_source_oci_digest, rootfs_base_artifact_digest, rootfs_format_generation,
	rootfs_platform_os, rootfs_platform_architecture, rootfs_platform_variant
`

type rowScanner interface {
	Scan(dest ...any) error
}

func scanTemplate(row rowScanner) (*template.Template, error) {
	var tpl template.Template
	var specJSON []byte
	var buildID, idempotencyKey, requestHash *string
	var creationState string
	var creationStage, reason, message *string
	var rootFSStorageFormat, rootFSSnapshotID, rootFSGenerationID *string
	var rootFSSourceOCIDigest, rootFSBaseArtifactDigest *string
	var rootFSFormatGeneration *int
	var rootFSPlatformOS, rootFSPlatformArchitecture, rootFSPlatformVariant *string
	var startedAt, capturedAt, completedAt *time.Time
	if err := row.Scan(
		&tpl.TemplateID,
		&tpl.Scope,
		&tpl.TeamID,
		&tpl.UserID,
		&specJSON,
		&tpl.CreatedAt,
		&tpl.UpdatedAt,
		&buildID,
		&idempotencyKey,
		&requestHash,
		&creationState,
		&creationStage,
		&startedAt,
		&capturedAt,
		&completedAt,
		&reason,
		&message,
		&rootFSStorageFormat,
		&rootFSSnapshotID,
		&rootFSGenerationID,
		&rootFSSourceOCIDigest,
		&rootFSBaseArtifactDigest,
		&rootFSFormatGeneration,
		&rootFSPlatformOS,
		&rootFSPlatformArchitecture,
		&rootFSPlatformVariant,
	); err != nil {
		return nil, err
	}
	if err := json.Unmarshal(specJSON, &tpl.Spec); err != nil {
		return nil, fmt.Errorf("unmarshal spec: %w", err)
	}

	tpl.CreationBuildID = stringValue(buildID)
	tpl.CreationIdempotencyKey = stringValue(idempotencyKey)
	tpl.CreationRequestHash = stringValue(requestHash)
	if buildID != nil {
		tpl.Status = &v1alpha1.SandboxTemplateStatus{
			Creation: &v1alpha1.TemplateCreationStatus{
				State:       v1alpha1.TemplateCreationState(creationState),
				Stage:       v1alpha1.TemplateCreationStage(stringValue(creationStage)),
				StartedAt:   utcTime(startedAt),
				CapturedAt:  utcTime(capturedAt),
				CompletedAt: utcTime(completedAt),
				Reason:      stringValue(reason),
				Message:     stringValue(message),
			},
		}
	}
	if rootFSSnapshotID != nil {
		tpl.RootFS = &template.RootFSTemplateSource{
			StorageFormat: stringValue(rootFSStorageFormat),
			SnapshotID:    stringValue(rootFSSnapshotID), GenerationID: stringValue(rootFSGenerationID),
			SourceOCIDigest:    stringValue(rootFSSourceOCIDigest),
			BaseArtifactDigest: stringValue(rootFSBaseArtifactDigest),
			Platform: ocispec.Platform{OS: stringValue(rootFSPlatformOS),
				Architecture: stringValue(rootFSPlatformArchitecture), Variant: stringValue(rootFSPlatformVariant)},
		}
		if rootFSFormatGeneration != nil {
			tpl.RootFS.FormatGeneration = *rootFSFormatGeneration
		}
	}
	return &tpl, nil
}

func stringValue(value *string) string {
	if value == nil {
		return ""
	}
	return *value
}

func utcTime(value *time.Time) *time.Time {
	if value == nil {
		return nil
	}
	out := value.UTC()
	return &out
}

// CreateTemplate creates a new template.
func (s *Store) CreateTemplate(ctx context.Context, tpl *template.Template) error {
	specJSON, err := json.Marshal(tpl.Spec)
	if err != nil {
		return fmt.Errorf("marshal spec: %w", err)
	}

	_, err = s.pool.Exec(ctx, `
		INSERT INTO scheduler_templates (template_id, scope, team_id, user_id, spec)
		VALUES ($1, $2, $3, $4, $5)
	`, tpl.TemplateID, tpl.Scope, tpl.TeamID, tpl.UserID, specJSON)
	if err != nil {
		return fmt.Errorf("create template: %w", err)
	}
	return nil
}

// CreateTemplateBuild atomically creates a template and its durable build.
func (s *Store) CreateTemplateBuild(ctx context.Context, tpl *template.Template, build *template.TemplateBuild) (*template.Template, bool, error) {
	if tpl == nil || build == nil {
		return nil, false, fmt.Errorf("template and build are required")
	}
	specJSON, err := json.Marshal(tpl.Spec)
	if err != nil {
		return nil, false, fmt.Errorf("marshal spec: %w", err)
	}
	if strings.TrimSpace(build.BuildID) == "" {
		return nil, false, fmt.Errorf("build_id is required")
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, false, fmt.Errorf("begin template build transaction: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	now := time.Now().UTC()
	if !tpl.CreatedAt.IsZero() {
		now = tpl.CreatedAt.UTC()
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO scheduler_templates (
			template_id, scope, team_id, user_id, spec,
			creation_build_id, creation_idempotency_key, creation_request_hash,
			creation_state, creation_stage, creation_started_at
		)
		VALUES ($1, $2, $3, $4, $5, $6::uuid, NULLIF($7, ''), $8,
			'creating', 'capturing', $9)
	`, tpl.TemplateID, tpl.Scope, tpl.TeamID, tpl.UserID, specJSON,
		build.BuildID, build.IdempotencyKey, build.RequestHash, now)
	if err != nil {
		if isUniqueViolation(err) {
			_ = tx.Rollback(ctx)
			return s.resolveTemplateBuildConflict(ctx, tpl, build)
		}
		return nil, false, fmt.Errorf("create template for build: %w", err)
	}

	nextAttemptAt := build.NextAttemptAt
	if nextAttemptAt.IsZero() {
		nextAttemptAt = now
	}
	_, err = tx.Exec(ctx, `
		INSERT INTO scheduler_template_builds (
			build_id, template_id, scope, team_id, user_id,
			source_sandbox_id, target_cluster_id, request_hash,
			idempotency_key, status, stage, snapshot_id, next_attempt_at
		)
		VALUES ($1::uuid, $2, $3, $4, $5, $6, $7, $8,
			NULLIF($9, ''), 'queued', 'capturing', NULLIF($10, ''), $11)
	`, build.BuildID, tpl.TemplateID, tpl.Scope, tpl.TeamID, tpl.UserID,
		build.SourceSandboxID, build.TargetClusterID, build.RequestHash,
		build.IdempotencyKey, build.SnapshotID, nextAttemptAt)
	if err != nil {
		return nil, false, fmt.Errorf("create template build: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return nil, false, fmt.Errorf("commit template build: %w", err)
	}

	created, err := s.GetTemplate(ctx, tpl.Scope, tpl.TeamID, tpl.TemplateID)
	if err != nil {
		return nil, false, err
	}
	return created, true, nil
}

func (s *Store) resolveTemplateBuildConflict(ctx context.Context, tpl *template.Template, build *template.TemplateBuild) (*template.Template, bool, error) {
	if key := strings.TrimSpace(build.IdempotencyKey); key != "" {
		existing, err := scanTemplate(s.pool.QueryRow(ctx, `
			SELECT `+templateSelectColumns+`
			FROM scheduler_templates
			WHERE scope = $1 AND team_id = $2 AND creation_idempotency_key = $3
		`, tpl.Scope, tpl.TeamID, key))
		if err == nil {
			if existing.CreationRequestHash == build.RequestHash {
				return existing, false, nil
			}
			return nil, false, template.ErrTemplateIdempotencyConflict
		}
		if err != pgx.ErrNoRows {
			return nil, false, fmt.Errorf("resolve idempotency conflict: %w", err)
		}
	}
	existing, err := s.GetTemplate(ctx, tpl.Scope, tpl.TeamID, tpl.TemplateID)
	if err != nil {
		return nil, false, err
	}
	if existing != nil {
		return nil, false, template.ErrTemplateAlreadyExists
	}
	return nil, false, template.ErrTemplateAlreadyExists
}

// GetTemplateByIdempotencyKey resolves a prior from-sandbox request.
func (s *Store) GetTemplateByIdempotencyKey(ctx context.Context, scope, teamID, idempotencyKey string) (*template.Template, error) {
	if strings.TrimSpace(idempotencyKey) == "" {
		return nil, nil
	}
	tpl, err := scanTemplate(s.pool.QueryRow(ctx, `
		SELECT `+templateSelectColumns+`
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND creation_idempotency_key = $3
	`, scope, teamID, idempotencyKey))
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get template by idempotency key: %w", err)
	}
	return tpl, nil
}

func isUniqueViolation(err error) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "23505"
}

// GetTemplate gets a template by primary key (scope, team_id, template_id).
func (s *Store) GetTemplate(ctx context.Context, scope, teamID, templateID string) (*template.Template, error) {
	tpl, err := scanTemplate(s.pool.QueryRow(ctx, `
		SELECT `+templateSelectColumns+`
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
	`, scope, teamID, templateID))
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("get template: %w", err)
	}
	return tpl, nil
}

// GetTemplateForTeam gets a template visible to a team.
// It prefers the team's private template (scope=team) and falls back to public.
func (s *Store) GetTemplateForTeam(ctx context.Context, teamID, templateID string) (*template.Template, error) {
	if teamID != "" {
		privateTpl, err := s.GetTemplate(ctx, "team", teamID, templateID)
		if err != nil {
			return nil, err
		}
		if privateTpl != nil {
			return privateTpl, nil
		}
	}
	return s.GetTemplate(ctx, "public", "", templateID)
}

// ListTemplates lists all templates.
func (s *Store) ListTemplates(ctx context.Context) ([]*template.Template, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT `+templateSelectColumns+`
		FROM scheduler_templates
		ORDER BY scope, team_id, template_id
	`)
	if err != nil {
		return nil, fmt.Errorf("list templates: %w", err)
	}
	defer rows.Close()

	var templates []*template.Template
	for rows.Next() {
		tpl, err := scanTemplate(rows)
		if err != nil {
			return nil, fmt.Errorf("scan template: %w", err)
		}
		templates = append(templates, tpl)
	}
	return templates, nil
}

// ListVisibleTemplates lists templates visible to a team (public + that team's private).
func (s *Store) ListVisibleTemplates(ctx context.Context, teamID string) ([]*template.Template, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT `+templateSelectColumns+`
		FROM scheduler_templates
		WHERE scope = 'public' OR (scope = 'team' AND team_id = $1)
		ORDER BY scope, template_id
	`, teamID)
	if err != nil {
		return nil, fmt.Errorf("list visible templates: %w", err)
	}
	defer rows.Close()

	var templates []*template.Template
	for rows.Next() {
		tpl, err := scanTemplate(rows)
		if err != nil {
			return nil, fmt.Errorf("scan template: %w", err)
		}
		templates = append(templates, tpl)
	}
	return templates, nil
}

// UpdateTemplate updates a template.
func (s *Store) UpdateTemplate(ctx context.Context, tpl *template.Template) error {
	specJSON, err := json.Marshal(tpl.Spec)
	if err != nil {
		return fmt.Errorf("marshal spec: %w", err)
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin update template: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()
	var oldSpecJSON []byte
	var snapshotID *string
	err = tx.QueryRow(ctx, `
		SELECT spec, rootfs_snapshot_id
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
		FOR UPDATE
	`, tpl.Scope, tpl.TeamID, tpl.TemplateID).Scan(&oldSpecJSON, &snapshotID)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("lock template for update: %w", err)
	}
	clearRootFS := false
	if snapshotID != nil {
		var oldSpec v1alpha1.SandboxTemplateSpec
		if err := json.Unmarshal(oldSpecJSON, &oldSpec); err != nil {
			return fmt.Errorf("decode stored template spec: %w", err)
		}
		clearRootFS = strings.TrimSpace(oldSpec.MainContainer.Image) !=
			strings.TrimSpace(tpl.Spec.MainContainer.Image)
		if clearRootFS {
			if err := enqueueTemplateRootFSDeletion(ctx, tx, stringValue(snapshotID), tpl.TeamID); err != nil {
				return err
			}
		}
	}
	_, err = tx.Exec(ctx, `
		UPDATE scheduler_templates
		SET spec = $5, user_id = $4,
			rootfs_storage_format = CASE WHEN $6 THEN NULL ELSE rootfs_storage_format END,
			rootfs_snapshot_id = CASE WHEN $6 THEN NULL ELSE rootfs_snapshot_id END,
			rootfs_generation_id = CASE WHEN $6 THEN NULL ELSE rootfs_generation_id END,
			rootfs_source_oci_digest = CASE WHEN $6 THEN NULL ELSE rootfs_source_oci_digest END,
			rootfs_base_artifact_digest = CASE WHEN $6 THEN NULL ELSE rootfs_base_artifact_digest END,
			rootfs_format_generation = CASE WHEN $6 THEN NULL ELSE rootfs_format_generation END,
			rootfs_platform_os = CASE WHEN $6 THEN NULL ELSE rootfs_platform_os END,
			rootfs_platform_architecture = CASE WHEN $6 THEN NULL ELSE rootfs_platform_architecture END,
			rootfs_platform_variant = CASE WHEN $6 THEN NULL ELSE rootfs_platform_variant END
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
	`, tpl.Scope, tpl.TeamID, tpl.TemplateID, tpl.UserID, specJSON, clearRootFS)
	if err != nil {
		return fmt.Errorf("update template: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit update template: %w", err)
	}
	return nil
}

// DeleteTemplate deletes a template.
func (s *Store) DeleteTemplate(ctx context.Context, scope, teamID, templateID string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin delete template: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()
	var snapshotID *string
	err = tx.QueryRow(ctx, `
		SELECT rootfs_snapshot_id
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
		FOR UPDATE
	`, scope, teamID, templateID).Scan(&snapshotID)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("lock template for deletion: %w", err)
	}
	if err := enqueueTemplateRootFSDeletion(ctx, tx, stringValue(snapshotID), teamID); err != nil {
		return err
	}
	if _, err = tx.Exec(ctx, `
		DELETE FROM scheduler_templates WHERE scope = $1 AND team_id = $2 AND template_id = $3
	`, scope, teamID, templateID); err != nil {
		return fmt.Errorf("delete template: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit delete template: %w", err)
	}
	return nil
}

const templateBuildSelectColumns = `
	build_id::text, template_id, scope, team_id, user_id,
	source_sandbox_id, target_cluster_id, request_hash, idempotency_key,
	status, stage, snapshot_id, capture_metadata,
	attempt_count, next_attempt_at, lease_owner, lease_expires_at,
	cancel_requested_at, last_error, created_at, updated_at
`

func scanTemplateBuild(row rowScanner) (*template.TemplateBuild, error) {
	var build template.TemplateBuild
	var idempotencyKey, snapshotID, leaseOwner, lastError *string
	var captureMetadata []byte
	var leaseExpiresAt, cancelRequestedAt *time.Time
	var stage string
	if err := row.Scan(
		&build.BuildID,
		&build.TemplateID,
		&build.Scope,
		&build.TeamID,
		&build.UserID,
		&build.SourceSandboxID,
		&build.TargetClusterID,
		&build.RequestHash,
		&idempotencyKey,
		&build.Status,
		&stage,
		&snapshotID,
		&captureMetadata,
		&build.AttemptCount,
		&build.NextAttemptAt,
		&leaseOwner,
		&leaseExpiresAt,
		&cancelRequestedAt,
		&lastError,
		&build.CreatedAt,
		&build.UpdatedAt,
	); err != nil {
		return nil, err
	}
	build.IdempotencyKey = stringValue(idempotencyKey)
	build.Stage = v1alpha1.TemplateCreationStage(stage)
	build.SnapshotID = stringValue(snapshotID)
	build.CaptureMetadata = append([]byte(nil), captureMetadata...)
	build.LeaseOwner = stringValue(leaseOwner)
	if leaseExpiresAt != nil {
		build.LeaseExpiresAt = leaseExpiresAt.UTC()
	}
	if cancelRequestedAt != nil {
		build.CancelRequestedAt = cancelRequestedAt.UTC()
	}
	build.LastError = stringValue(lastError)
	return &build, nil
}

// ClaimTemplateBuild leases one build to a manager in the local region.
// Capturing remains bound to the source cluster. Once capture is durable,
// publishing and cancellation cleanup may be taken over by any manager that
// shares the region's PostgreSQL and object storage. The source cluster still
// owns capture because it owns the source sandbox runtime.
func (s *Store) ClaimTemplateBuild(
	ctx context.Context,
	targetClusterID, workerID string,
	leaseDuration time.Duration,
) (*template.TemplateBuild, error) {
	if strings.TrimSpace(targetClusterID) == "" || strings.TrimSpace(workerID) == "" {
		return nil, fmt.Errorf("target_cluster_id and worker_id are required")
	}
	if leaseDuration <= 0 {
		leaseDuration = 2 * time.Minute
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, fmt.Errorf("begin claim template build: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	leaseMillis := leaseDuration.Milliseconds()
	if leaseMillis < 1 {
		leaseMillis = 1
	}
	build, err := scanTemplateBuild(tx.QueryRow(ctx, `
		WITH candidate AS (
			SELECT b.build_id
			FROM scheduler_template_builds b
			LEFT JOIN scheduler_templates t
			  ON t.scope = b.scope
			 AND t.team_id = b.team_id
			 AND t.template_id = b.template_id
			 AND t.creation_build_id = b.build_id
			WHERE b.next_attempt_at <= NOW()
			  AND (b.lease_expires_at IS NULL OR b.lease_expires_at <= NOW())
			  AND (
				(
					b.cancel_requested_at IS NOT NULL
					AND (
						b.capture_metadata IS NULL
						OR b.capture_metadata->>'version' = '2'
					)
				)
				OR (
					b.cancel_requested_at IS NULL
					AND t.creation_build_id IS NOT NULL
					AND (
						(
							b.stage = 'capturing'
							AND b.target_cluster_id = $1
							AND t.creation_state = 'creating'
							AND t.creation_stage = 'capturing'
						)
						OR (
							b.stage = 'publishing'
							AND b.capture_metadata->>'version' = '2'
							AND t.creation_state = 'creating'
							AND t.creation_stage = 'publishing'
							AND (
								b.target_cluster_id = $1
								OR (
									NULLIF(b.snapshot_id, '') IS NOT NULL
									AND b.capture_metadata IS NOT NULL
									AND t.creation_captured_at IS NOT NULL
								)
							)
						)
					)
				)
			  )
			ORDER BY (b.cancel_requested_at IS NOT NULL) DESC, b.created_at
			FOR UPDATE OF b SKIP LOCKED
			LIMIT 1
		)
		UPDATE scheduler_template_builds b
		SET status = 'running',
			lease_owner = $2,
			lease_expires_at = NOW() + ($3 * INTERVAL '1 millisecond'),
			attempt_count = attempt_count + 1
		FROM candidate
		WHERE b.build_id = candidate.build_id
		RETURNING `+templateBuildSelectColumnsWithAlias("b")+`
	`, targetClusterID, workerID, leaseMillis))
	if err == pgx.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("claim template build: %w", err)
	}

	var specJSON []byte
	err = tx.QueryRow(ctx, `
		SELECT spec
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
		  AND creation_build_id = $4::uuid
	`, build.Scope, build.TeamID, build.TemplateID, build.BuildID).Scan(&specJSON)
	if err != nil && err != pgx.ErrNoRows {
		return nil, fmt.Errorf("load claimed template spec: %w", err)
	}
	if len(specJSON) > 0 {
		if err := json.Unmarshal(specJSON, &build.DesiredSpec); err != nil {
			return nil, fmt.Errorf("unmarshal claimed template spec: %w", err)
		}
	}
	if err := tx.Commit(ctx); err != nil {
		return nil, fmt.Errorf("commit template build claim: %w", err)
	}
	return build, nil
}

// FailCapturingTemplateBuildsForCluster terminally fails builds whose source
// rootfs was not captured before their owning cluster became unavailable.
// Captured builds are deliberately left claimable by another regional manager.
func (s *Store) FailCapturingTemplateBuildsForCluster(ctx context.Context, clusterID, reason, message string) (int64, error) {
	clusterID = strings.TrimSpace(clusterID)
	if clusterID == "" {
		return 0, fmt.Errorf("cluster_id is required")
	}
	reason = strings.TrimSpace(reason)
	if reason == "" {
		reason = "source_cluster_unavailable"
	}
	message = strings.TrimSpace(message)
	if message == "" {
		message = "source cluster became unavailable before rootfs capture completed"
	}

	rows, err := s.pool.Query(ctx, `
		WITH affected AS MATERIALIZED (
			SELECT b.build_id
			FROM scheduler_template_builds b
			JOIN scheduler_templates t
			  ON t.scope = b.scope
			 AND t.team_id = b.team_id
			 AND t.template_id = b.template_id
			 AND t.creation_build_id = b.build_id
			WHERE b.target_cluster_id = $1
			  AND b.stage = 'capturing'
			  AND b.cancel_requested_at IS NULL
			  AND t.creation_state = 'creating'
			  AND t.creation_stage = 'capturing'
			FOR UPDATE OF b, t
		),
		cancelled AS (
			UPDATE scheduler_template_builds b
			SET status = 'cancelled',
				cancel_requested_at = COALESCE(cancel_requested_at, NOW()),
				next_attempt_at = NOW(),
				last_error = $3
			FROM affected a
			WHERE b.build_id = a.build_id
			RETURNING b.build_id
		)
		UPDATE scheduler_templates t
		SET creation_state = 'failed',
			creation_completed_at = NOW(),
			creation_reason = $2,
			creation_message = $3
		FROM cancelled c
		WHERE t.creation_build_id = c.build_id
		  AND t.creation_state = 'creating'
		  AND t.creation_stage = 'capturing'
		RETURNING t.creation_build_id::text
	`, clusterID, reason, message)
	if err != nil {
		return 0, fmt.Errorf("fail capturing template builds for cluster: %w", err)
	}
	defer rows.Close()

	var count int64
	for rows.Next() {
		var buildID string
		if err := rows.Scan(&buildID); err != nil {
			return 0, fmt.Errorf("scan failed capturing template build: %w", err)
		}
		count++
	}
	if err := rows.Err(); err != nil {
		return 0, fmt.Errorf("iterate failed capturing template builds: %w", err)
	}
	return count, nil
}

func templateBuildSelectColumnsWithAlias(alias string) string {
	columns := strings.Split(templateBuildSelectColumns, ",")
	for i, column := range columns {
		column = strings.TrimSpace(column)
		if column == "" {
			continue
		}
		columns[i] = alias + "." + column
	}
	return strings.Join(columns, ", ")
}

// RenewTemplateBuildLease extends a worker's current lease.
func (s *Store) RenewTemplateBuildLease(ctx context.Context, buildID, workerID string, leaseDuration time.Duration) error {
	if leaseDuration <= 0 {
		leaseDuration = 2 * time.Minute
	}
	result, err := s.pool.Exec(ctx, `
		UPDATE scheduler_template_builds
		SET lease_expires_at = NOW() + ($3 * INTERVAL '1 millisecond')
		WHERE build_id = $1::uuid AND lease_owner = $2
		  AND status = 'running' AND cancel_requested_at IS NULL
	`, buildID, workerID, maxInt64(leaseDuration.Milliseconds(), 1))
	if err != nil {
		return fmt.Errorf("renew template build lease: %w", err)
	}
	return requireBuildRow(result.RowsAffected())
}

// MarkTemplateBuildCaptured records the immutable rootfs snapshot and advances
// both the job and public template status to publishing.
func (s *Store) MarkTemplateBuildCaptured(ctx context.Context, buildID, workerID, snapshotID string, captureMetadata json.RawMessage, capturedAt time.Time) error {
	snapshotID = strings.TrimSpace(snapshotID)
	if snapshotID == "" {
		return fmt.Errorf("captured template snapshot_id is required")
	}
	var metadataVersion struct {
		Version int `json:"version"`
	}
	if len(captureMetadata) == 0 || json.Unmarshal(captureMetadata, &metadataVersion) != nil ||
		metadataVersion.Version != template.TemplateBuildCaptureVersion {
		return fmt.Errorf("captured template metadata has no runtime-native version")
	}
	if capturedAt.IsZero() {
		capturedAt = time.Now().UTC()
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin mark template build captured: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	result, err := tx.Exec(ctx, `
		UPDATE scheduler_template_builds
		SET stage = 'publishing',
			snapshot_id = $3,
			capture_metadata = $4,
			last_error = NULL
		WHERE build_id = $1::uuid AND lease_owner = $2
		  AND status = 'running' AND cancel_requested_at IS NULL
		  AND (
			stage = 'capturing'
			OR (
				stage = 'publishing' AND snapshot_id = $3
				AND capture_metadata->>'version' = $5
				AND capture_metadata = $4::jsonb
			)
		  )
	`, buildID, workerID, snapshotID, nullableJSON(captureMetadata), fmt.Sprintf("%d", metadataVersion.Version))
	if err != nil {
		return fmt.Errorf("mark build captured: %w", err)
	}
	if err := requireBuildRow(result.RowsAffected()); err != nil {
		return err
	}
	result, err = tx.Exec(ctx, `
		UPDATE scheduler_templates
		SET creation_stage = 'publishing',
			creation_captured_at = COALESCE(creation_captured_at, $2),
			creation_message = NULL
		WHERE creation_build_id = $1::uuid
		  AND creation_state = 'creating'
		  AND creation_stage IN ('capturing', 'publishing')
	`, buildID, capturedAt)
	if err != nil {
		return fmt.Errorf("update captured template status: %w", err)
	}
	if err := requireBuildRow(result.RowsAffected()); err != nil {
		return err
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit captured template build: %w", err)
	}
	return nil
}

// PublishRootFSTemplateBuild atomically retains an immutable regional RootFS
// snapshot, makes the template claimable, and removes its queue row. Unlike an
// OCI image build, no temporary capture may be deleted after this commit.
func (s *Store) PublishRootFSTemplateBuild(
	ctx context.Context,
	buildID, workerID string,
	source template.RootFSTemplateSource,
	capturedAt time.Time,
) error {
	if err := source.Validate(); err != nil {
		return fmt.Errorf("validate published template RootFS: %w", err)
	}
	if capturedAt.IsZero() {
		capturedAt = time.Now().UTC()
	}
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin publish RootFS template build: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	var templateID, scope, teamID string
	err = tx.QueryRow(ctx, `
		DELETE FROM scheduler_template_builds
		WHERE build_id = $1::uuid AND lease_owner = $2
		  AND status = 'running' AND cancel_requested_at IS NULL
		  AND stage = 'publishing' AND snapshot_id = $3
		  AND capture_metadata->>'version' = '2'
		  AND capture_metadata->>'storage_format' = $4
		  AND capture_metadata->>'head_generation_id' = $5
		  AND capture_metadata->>'source_oci_digest' = $6
		  AND capture_metadata->>'base_artifact_digest' = $7
		  AND capture_metadata->>'format_generation' = $8
		  AND capture_metadata#>>'{platform,os}' = $9
		  AND capture_metadata#>>'{platform,architecture}' = $10
		  AND COALESCE(capture_metadata#>>'{platform,variant}', '') = $11
		RETURNING template_id, scope, team_id
	`, buildID, workerID, source.SnapshotID, source.StorageFormat,
		source.GenerationID, source.SourceOCIDigest, source.BaseArtifactDigest,
		fmt.Sprintf("%d", source.FormatGeneration), source.Platform.OS,
		source.Platform.Architecture, source.Platform.Variant,
	).Scan(&templateID, &scope, &teamID)
	if errors.Is(err, pgx.ErrNoRows) {
		return template.ErrTemplateBuildLeaseLost
	}
	if err != nil {
		return fmt.Errorf("finish published RootFS template build: %w", err)
	}
	result, err := tx.Exec(ctx, `
		UPDATE scheduler_templates
		SET creation_state = 'ready',
			creation_stage = 'publishing',
			creation_captured_at = COALESCE(creation_captured_at, $5),
			creation_completed_at = COALESCE(creation_completed_at, NOW()),
			creation_reason = NULL,
			creation_message = NULL,
			rootfs_storage_format = $6,
			rootfs_snapshot_id = $7,
			rootfs_generation_id = $8,
			rootfs_source_oci_digest = $9,
			rootfs_base_artifact_digest = $10,
			rootfs_format_generation = $11,
			rootfs_platform_os = $12,
			rootfs_platform_architecture = $13,
			rootfs_platform_variant = $14
		WHERE creation_build_id = $1::uuid
		  AND template_id = $2 AND scope = $3 AND team_id = $4
		  AND creation_state = 'creating'
		  AND creation_stage = 'publishing'
	`, buildID, templateID, scope, teamID, capturedAt,
		source.StorageFormat, source.SnapshotID, source.GenerationID,
		source.SourceOCIDigest, source.BaseArtifactDigest, source.FormatGeneration,
		source.Platform.OS, source.Platform.Architecture, source.Platform.Variant)
	if err != nil {
		return fmt.Errorf("install published template RootFS: %w", err)
	}
	if err := requireBuildRow(result.RowsAffected()); err != nil {
		return err
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("%w: commit published RootFS template build: %v",
			template.ErrTemplateRootFSPublicationUncertain, err)
	}
	return nil
}

// FailTemplateBuild records a terminal, user-visible build failure.
func (s *Store) FailTemplateBuild(ctx context.Context, buildID, workerID, reason, message string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin fail template build: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	result, err := tx.Exec(ctx, `
		UPDATE scheduler_template_builds
		SET status = 'cancelled',
			cancel_requested_at = COALESCE(cancel_requested_at, NOW()),
			next_attempt_at = NOW(),
			last_error = $3
		WHERE build_id = $1::uuid AND lease_owner = $2
		  AND status = 'running' AND cancel_requested_at IS NULL
	`, buildID, workerID, message)
	if err != nil {
		return fmt.Errorf("record template build failure: %w", err)
	}
	if err := requireBuildRow(result.RowsAffected()); err != nil {
		return err
	}
	result, err = tx.Exec(ctx, `
		UPDATE scheduler_templates
		SET creation_state = 'failed',
			creation_completed_at = NOW(),
			creation_reason = $2,
			creation_message = $3
		WHERE creation_build_id = $1::uuid AND creation_state = 'creating'
	`, buildID, reason, message)
	if err != nil {
		return fmt.Errorf("mark template creation failed: %w", err)
	}
	if err := requireBuildRow(result.RowsAffected()); err != nil {
		return err
	}
	if err := tx.Commit(ctx); err != nil {
		return fmt.Errorf("commit template build failure: %w", err)
	}
	return nil
}

// ReleaseTemplateBuild returns a transiently failed build to the durable queue.
func (s *Store) ReleaseTemplateBuild(ctx context.Context, buildID, workerID string, retryAt time.Time, lastError string) error {
	if retryAt.IsZero() {
		retryAt = time.Now().UTC()
	}
	result, err := s.pool.Exec(ctx, `
		UPDATE scheduler_template_builds
		SET status = 'queued',
			next_attempt_at = $3,
			lease_owner = NULL,
			lease_expires_at = NULL,
			last_error = $4
		WHERE build_id = $1::uuid AND lease_owner = $2
		  AND status = 'running' AND cancel_requested_at IS NULL
	`, buildID, workerID, retryAt, lastError)
	if err != nil {
		return fmt.Errorf("release template build: %w", err)
	}
	return requireBuildRow(result.RowsAffected())
}

// TemplateBuildCancelled checks the durable cancellation tombstone.
func (s *Store) TemplateBuildCancelled(ctx context.Context, buildID string) (bool, error) {
	var cancelled bool
	err := s.pool.QueryRow(ctx, `
		SELECT cancel_requested_at IS NOT NULL
		FROM scheduler_template_builds
		WHERE build_id = $1::uuid
	`, buildID).Scan(&cancelled)
	if err == pgx.ErrNoRows {
		return true, nil
	}
	if err != nil {
		return false, fmt.Errorf("check template build cancellation: %w", err)
	}
	return cancelled, nil
}

// FinishTemplateBuild removes internal queue state after snapshot cleanup.
func (s *Store) FinishTemplateBuild(ctx context.Context, buildID, workerID string) error {
	result, err := s.pool.Exec(ctx, `
		DELETE FROM scheduler_template_builds
		WHERE build_id = $1::uuid AND lease_owner = $2
	`, buildID, workerID)
	if err != nil {
		return fmt.Errorf("finish template build: %w", err)
	}
	return requireBuildRow(result.RowsAffected())
}

// CancelTemplateBuildAndDeleteTemplate atomically removes the visible template
// and leaves a cancellation tombstone until a worker cleans captured artifacts.
func (s *Store) CancelTemplateBuildAndDeleteTemplate(ctx context.Context, scope, teamID, templateID string) (bool, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return false, fmt.Errorf("begin cancel template build: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	// Build workers lock their queue row before changing the visible template.
	// Read the immutable build identity first, then preserve that same lock
	// order so cancellation cannot deadlock publication.
	var observedBuildID *string
	err = tx.QueryRow(ctx, `
		SELECT creation_build_id::text
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
	`, scope, teamID, templateID).Scan(&observedBuildID)
	if err == pgx.ErrNoRows {
		return false, nil
	}
	if err != nil {
		return false, fmt.Errorf("read template build for cancellation: %w", err)
	}
	if observedBuildID != nil {
		var buildSnapshotID *string
		err := tx.QueryRow(ctx, `
			UPDATE scheduler_template_builds
			SET status = 'cancelled',
				cancel_requested_at = COALESCE(cancel_requested_at, NOW()),
				next_attempt_at = NOW()
			WHERE build_id = $1::uuid
			RETURNING snapshot_id
		`, *observedBuildID).Scan(&buildSnapshotID)
		if err != nil && !errors.Is(err, pgx.ErrNoRows) {
			return false, fmt.Errorf("request template build cancellation: %w", err)
		}
		if err := enqueueTemplateRootFSDeletion(ctx, tx, stringValue(buildSnapshotID), teamID); err != nil {
			return false, err
		}
	}
	var buildID, templateSnapshotID *string
	err = tx.QueryRow(ctx, `
		SELECT creation_build_id::text, rootfs_snapshot_id
		FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
		FOR UPDATE
	`, scope, teamID, templateID).Scan(&buildID, &templateSnapshotID)
	if errors.Is(err, pgx.ErrNoRows) {
		if err := tx.Commit(ctx); err != nil {
			return false, fmt.Errorf("commit absent template build cancellation: %w", err)
		}
		return observedBuildID != nil, nil
	}
	if err != nil {
		return false, fmt.Errorf("lock template for cancellation: %w", err)
	}
	if stringValue(buildID) != stringValue(observedBuildID) {
		return false, fmt.Errorf("template build identity changed during cancellation")
	}
	if err := enqueueTemplateRootFSDeletion(ctx, tx, stringValue(templateSnapshotID), teamID); err != nil {
		return false, err
	}
	if _, err := tx.Exec(ctx, `
		DELETE FROM scheduler_templates
		WHERE scope = $1 AND team_id = $2 AND template_id = $3
	`, scope, teamID, templateID); err != nil {
		return false, fmt.Errorf("delete template during build cancellation: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return false, fmt.Errorf("commit template build cancellation: %w", err)
	}
	return observedBuildID != nil, nil
}

func enqueueTemplateRootFSDeletion(ctx context.Context, tx pgx.Tx, snapshotID, teamID string) error {
	snapshotID = strings.TrimSpace(snapshotID)
	if snapshotID == "" {
		return nil
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO scheduler_template_rootfs_deletions (
			snapshot_id, team_id, next_attempt_at, created_at, updated_at
		) VALUES ($1, $2, NOW(), NOW(), NOW())
		ON CONFLICT (snapshot_id) DO UPDATE SET
			team_id = EXCLUDED.team_id,
			next_attempt_at = LEAST(
				scheduler_template_rootfs_deletions.next_attempt_at,
				EXCLUDED.next_attempt_at
			),
			updated_at = NOW()
	`, snapshotID, strings.TrimSpace(teamID)); err != nil {
		return fmt.Errorf("enqueue template RootFS deletion: %w", err)
	}
	return nil
}

// ClaimTemplateRootFSDeletion leases one due snapshot cleanup tombstone.
func (s *Store) ClaimTemplateRootFSDeletion(
	ctx context.Context,
	workerID string,
	leaseDuration time.Duration,
) (*template.TemplateRootFSDeletion, error) {
	workerID = strings.TrimSpace(workerID)
	if workerID == "" {
		return nil, fmt.Errorf("template RootFS deletion worker_id is required")
	}
	if leaseDuration <= 0 {
		leaseDuration = 2 * time.Minute
	}
	row := s.pool.QueryRow(ctx, `
		WITH due AS (
			SELECT snapshot_id
			FROM scheduler_template_rootfs_deletions
			WHERE next_attempt_at <= NOW()
			  AND (lease_expires_at IS NULL OR lease_expires_at <= NOW())
			  AND NOT EXISTS (
				SELECT 1 FROM scheduler_template_builds b
				WHERE b.snapshot_id = scheduler_template_rootfs_deletions.snapshot_id
			  )
			  AND NOT EXISTS (
				SELECT 1 FROM scheduler_templates t
				WHERE t.rootfs_snapshot_id = scheduler_template_rootfs_deletions.snapshot_id
			  )
			ORDER BY next_attempt_at ASC, created_at ASC
			LIMIT 1
			FOR UPDATE SKIP LOCKED
		)
		UPDATE scheduler_template_rootfs_deletions d
		SET lease_owner = $1,
			lease_expires_at = NOW() + ($2 * INTERVAL '1 millisecond'),
			attempt_count = attempt_count + 1,
			last_error = NULL
		FROM due
		WHERE d.snapshot_id = due.snapshot_id
		RETURNING d.snapshot_id, d.team_id, d.attempt_count,
			d.lease_owner, d.lease_expires_at
	`, workerID, maxInt64(leaseDuration.Milliseconds(), 1))
	var deletion template.TemplateRootFSDeletion
	if err := row.Scan(&deletion.SnapshotID, &deletion.TeamID, &deletion.AttemptCount,
		&deletion.LeaseOwner, &deletion.LeaseExpiresAt); errors.Is(err, pgx.ErrNoRows) {
		return nil, nil
	} else if err != nil {
		return nil, fmt.Errorf("claim template RootFS deletion: %w", err)
	}
	return &deletion, nil
}

// FinishTemplateRootFSDeletion removes a cleanup tombstone after the regional
// snapshot has been released.
func (s *Store) FinishTemplateRootFSDeletion(ctx context.Context, snapshotID, workerID string) error {
	result, err := s.pool.Exec(ctx, `
		DELETE FROM scheduler_template_rootfs_deletions
		WHERE snapshot_id = $1 AND lease_owner = $2
	`, strings.TrimSpace(snapshotID), strings.TrimSpace(workerID))
	if err != nil {
		return fmt.Errorf("finish template RootFS deletion: %w", err)
	}
	return requireBuildRow(result.RowsAffected())
}

// ReleaseTemplateRootFSDeletion returns a failed cleanup to the durable queue.
func (s *Store) ReleaseTemplateRootFSDeletion(
	ctx context.Context,
	snapshotID, workerID string,
	retryAt time.Time,
	lastError string,
) error {
	if retryAt.IsZero() {
		retryAt = time.Now().UTC()
	}
	result, err := s.pool.Exec(ctx, `
		UPDATE scheduler_template_rootfs_deletions
		SET next_attempt_at = $3, lease_owner = NULL, lease_expires_at = NULL,
			last_error = $4
		WHERE snapshot_id = $1 AND lease_owner = $2
	`, strings.TrimSpace(snapshotID), strings.TrimSpace(workerID), retryAt, lastError)
	if err != nil {
		return fmt.Errorf("release template RootFS deletion: %w", err)
	}
	return requireBuildRow(result.RowsAffected())
}

func nullableJSON(value json.RawMessage) any {
	if len(value) == 0 {
		return nil
	}
	return string(value)
}

func requireBuildRow(rows int64) error {
	if rows == 0 {
		return template.ErrTemplateBuildLeaseLost
	}
	return nil
}

func maxInt64(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}
