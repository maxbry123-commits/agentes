package runtimeslot

import (
	"context"
	"encoding/hex"
	"errors"
	"net"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/containerd/errdefs"
	"github.com/sandbox0-ai/sandbox0/pkg/rootfshandoff"
	"github.com/sandbox0-ai/sandbox0/pkg/rootfsrebase"
)

type testNodeChannelExecutor struct {
	claimErr          error
	commandErr        error
	cleanupErr        error
	runningFork       rootfshandoff.RunningForkCheckpointResult
	runningForkErr    error
	runningForkBlock  bool
	pausedRebase      rootfsrebase.WorkerResult
	pausedRebaseErr   error
	pausedRebaseBlock bool
}

type staticNodeChannelResolver struct {
	addresses []net.IPAddr
	err       error
	host      string
}

func (r *staticNodeChannelResolver) LookupIPAddr(_ context.Context, host string) ([]net.IPAddr, error) {
	r.host = host
	return r.addresses, r.err
}

func (e *testNodeChannelExecutor) PrepareNetwork(
	_ context.Context,
	_ NodeChannelTarget,
	request NodeNetworkPrepareControlRequest,
) (rootfshandoff.NetworkPolicyToken, error) {
	return rootfshandoff.NetworkPolicyToken{
		AllocationID: request.AllocationID, NetworkIncarnationID: RuntimeSlotNetworkIncarnationID(request),
		ClaimID: request.ClaimID, NetworkEpoch: 1, PolicyDigest: request.PolicyDigest,
		SourceIP: "192.0.2.2", CtldGeneration: "ctld-1", NetNSIdentity: request.NetNSIdentity,
	}, nil
}

func (e *testNodeChannelExecutor) Claim(
	context.Context,
	NodeChannelTarget,
	NodeClaimControlRequest,
) (NodeControlResponse, error) {
	return NodeControlResponse{Phase: string(StateActive)}, e.claimErr
}

func (e *testNodeChannelExecutor) CommandReady(
	context.Context,
	NodeChannelTarget,
	CommandReadyControlRequest,
) (NodeControlResponse, error) {
	return NodeControlResponse{Phase: string(StateActive)}, e.commandErr
}

func (*testNodeChannelExecutor) PlannedRetire(
	_ context.Context,
	_ NodeChannelTarget,
	request NodePlannedRetireControlRequest,
) (NodePlannedRetireControlProof, error) {
	return NewNodePlannedRetireControlProof(request)
}

func (e *testNodeChannelExecutor) RunningFork(
	ctx context.Context,
	_ NodeChannelTarget,
	_ NodeRunningForkControlRequest,
) (rootfshandoff.RunningForkCheckpointResult, error) {
	if e.runningForkBlock {
		<-ctx.Done()
		return rootfshandoff.RunningForkCheckpointResult{}, ctx.Err()
	}
	return e.runningFork, e.runningForkErr
}

func (e *testNodeChannelExecutor) PausedRebase(
	ctx context.Context,
	_ NodeChannelTarget,
	_ NodePausedRebaseControlRequest,
) (rootfsrebase.WorkerResult, error) {
	if e.pausedRebaseBlock {
		<-ctx.Done()
		return rootfsrebase.WorkerResult{}, ctx.Err()
	}
	return e.pausedRebase, e.pausedRebaseErr
}

func (e *testNodeChannelExecutor) RejectPausedRebase(
	_ context.Context,
	_ NodeChannelTarget,
	request NodePausedRebaseControlRequest,
) (rootfsrebase.WorkerRejection, error) {
	if e.pausedRebaseErr != nil {
		return rootfsrebase.WorkerRejection{}, e.pausedRebaseErr
	}
	return rootfsrebase.RejectWithoutResult(request.Worker)
}

func (e *testNodeChannelExecutor) AcknowledgePausedRebase(
	_ context.Context,
	_ NodeChannelTarget,
	_ NodePausedRebaseControlRequest,
) error {
	return e.pausedRebaseErr
}

func (e *testNodeChannelExecutor) Cleanup(
	_ context.Context,
	_ NodeChannelTarget,
	request NodeCleanupControlRequest,
) (NodeCleanupControlProof, error) {
	if e.cleanupErr != nil {
		return NodeCleanupControlProof{}, e.cleanupErr
	}
	proof := NodeCleanupControlProof{
		Version:     NodeCleanupProofVersion,
		OperationID: request.OperationID, WriterOperationID: request.WriterOperationID,
		WriterRetireKind: request.WriterRetireKind,
		SlotID:           request.SlotID, ClusterID: request.ClusterID, AllocationID: request.AllocationID,
		NodeID: request.NodeID, NodeUID: request.NodeUID, NodeBootID: request.NodeBootID,
		NetNSIdentity: request.NetNSIdentity, RunscContainerID: request.RunscContainerID,
		WriterGrantID: request.WriterGrantID, WriterAuthorityDigest: request.WriterAuthorityDigest,
		Resources: request.Resources, ResourceLeaseID: request.Resources.LeaseID,
		ResourceLeaseDigest: request.ResourceLeaseDigest,
		RunscAbsent:         true, StableMountAbsent: true, RootFSWriterAbsent: true, NetworkPolicyAbsent: true,
		ResourceCgroupAbsent: !request.Resources.IsZero(),
	}
	if request.WriterGrantID != "" {
		proof.RootFSOperationID = request.WriterOperationID
		proof.RootFSProofDigest = strings.Repeat("5", 64)
	}
	digest, err := proof.Digest()
	if err != nil {
		return NodeCleanupControlProof{}, err
	}
	proof.ProofDigest = digest
	return proof, nil
}

func TestNodeChannelAgentExecutesExactCommandsAndClassifiesErrors(t *testing.T) {
	executor := &testNodeChannelExecutor{}
	agent := &NodeChannelAgent{config: NodeChannelAgentConfig{
		Executor: executor, NetworkExecutor: executor,
		OperationTimeout: defaultNodeChannelOperationTimeout,
		Capacity:         testNodeChannelCapacity(),
	}}
	network, err := NewNodeChannelNetworkPrepareCommand(testNodeChannelTarget(false), testNodeChannelNetworkPrepare())
	if err != nil {
		t.Fatal(err)
	}
	result := agent.execute(t.Context(), network)
	if err := result.ValidateFor(network); err != nil || result.NetworkPolicyToken == nil {
		t.Fatalf("network result = %+v, %v", result, err)
	}
	claim, err := NewNodeChannelClaimCommand(testNodeChannelTarget(true), testNodeClaimControlRequest())
	if err != nil {
		t.Fatal(err)
	}
	result = agent.execute(t.Context(), claim)
	if err := result.ValidateFor(claim); err != nil || result.ControlResponse == nil {
		t.Fatalf("claim result = %+v, %v", result, err)
	}

	executor.claimErr = errdefs.ErrFailedPrecondition
	result = agent.execute(t.Context(), claim)
	if err := result.ValidateFor(claim); err != nil {
		t.Fatal(err)
	}
	if result.ErrorClass != NodeChannelErrorFailedPrecondition || result.Error == "" {
		t.Fatalf("classified result = %+v", result)
	}
}

func TestNodeChannelAgentRejectsInvalidExecutorResult(t *testing.T) {
	executor := &testNodeChannelExecutor{}
	agent := &NodeChannelAgent{config: NodeChannelAgentConfig{
		Executor: executor, OperationTimeout: defaultNodeChannelOperationTimeout,
		Capacity: testNodeChannelCapacity(),
	}}
	command, err := NewNodeChannelCommandReadyCommand(
		testNodeChannelTarget(true), CommandReadyControlRequest{Proof: testNodeChannelCommandProof()},
	)
	if err != nil {
		t.Fatal(err)
	}
	executor.commandErr = errors.New(strings.Repeat("x", NodeChannelMaxError+100))
	result := agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil {
		t.Fatal(err)
	}
	if result.ErrorClass != NodeChannelErrorInternal || len(result.Error) > NodeChannelMaxError {
		t.Fatalf("bounded result = class %q, bytes %d", result.ErrorClass, len(result.Error))
	}
}

func TestNodeChannelAgentAcknowledgesExactDurablePlannedRetire(t *testing.T) {
	stage := testNodeChannelClaim().Stage
	binding, err := stage.BindingDigest()
	if err != nil {
		t.Fatal(err)
	}
	request := NodePlannedRetireControlRequest{
		OperationID: rootfshandoff.PlannedRetireOperationID(
			stage.Parent, stage.Identity.WriterGrantID, stage.Identity.WriterEpoch,
		),
		ClaimID: stage.Identity.ClaimID, SlotID: stage.Identity.SlotNonce,
		AllocationID: stage.Identity.AllocationID, WriterGrantID: stage.Identity.WriterGrantID,
		WriterEpoch: stage.Identity.WriterEpoch, BindingVersion: stage.BindingVersion,
		BindingDigest: hex.EncodeToString(binding[:]),
	}
	command, err := NewNodeChannelPlannedRetireCommand(testNodeChannelTarget(false), request)
	if err != nil {
		t.Fatal(err)
	}
	executor := &testNodeChannelExecutor{}
	agent := &NodeChannelAgent{config: NodeChannelAgentConfig{
		Executor: executor, PlannedRetireExecutor: executor,
		OperationTimeout: time.Second, Capacity: testNodeChannelCapacity(),
	}}
	result := agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil || result.PlannedRetireProof == nil {
		t.Fatalf("planned-retire result = %+v, %v", result, err)
	}

	mutated := command
	mutated.PlannedRetire = &NodePlannedRetireControlRequest{}
	if err := result.ValidateFor(mutated); err == nil {
		t.Fatal("planned-retire proof unexpectedly validated for a mutated request")
	}
}

func TestNodeChannelAgentExecutesRunningForkWithDedicatedTimeout(t *testing.T) {
	stage := testNodeChannelClaim().Stage
	binding, err := stage.BindingDigest()
	if err != nil {
		t.Fatal(err)
	}
	fork := rootfshandoff.RunningForkCheckpointRequest{
		OperationID: "fork-operation-1", SourceSandboxID: "sandbox-source",
		TargetSandboxID: "sandbox-target", TargetGenerationID: "generation-target",
	}
	request := NodeRunningForkControlRequest{
		Fork: fork, SourceFilesystemID: stage.Identity.RootFSID,
		SourceWriterGrantID: stage.Identity.WriterGrantID, SourceWriterEpoch: stage.Identity.WriterEpoch,
		BindingVersion: stage.BindingVersion, BindingDigest: hex.EncodeToString(binding[:]),
		ExpectedSourceGenerationID: stage.InitialGeneration,
	}
	command, err := NewNodeChannelRunningForkCommand(testNodeChannelTarget(false), request)
	if err != nil {
		t.Fatal(err)
	}
	executor := &testNodeChannelExecutor{runningFork: testNodeChannelRunningForkCheckpoint(t, *stage, fork)}
	agent := &NodeChannelAgent{config: NodeChannelAgentConfig{
		Executor: executor, RunningForkExecutor: executor,
		OperationTimeout: time.Second, RunningForkTimeout: time.Second,
		Capacity: testNodeChannelCapacity(),
	}}
	result := agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil || result.RunningFork == nil {
		t.Fatalf("running-fork result = %+v, %v", result, err)
	}

	executor.runningForkBlock = true
	agent.config.RunningForkTimeout = time.Millisecond
	result = agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil {
		t.Fatal(err)
	}
	if result.ErrorClass != NodeChannelErrorUnavailable || !strings.Contains(result.Error, context.DeadlineExceeded.Error()) {
		t.Fatalf("timed-out running-fork result = %+v", result)
	}
}

func TestNodeChannelAgentExecutesPausedRebaseWithDedicatedTimeout(t *testing.T) {
	request, workerResult := testNodeChannelPausedRebase(t)
	command, err := NewNodeChannelPausedRebaseCommand(testNodeChannelRebaseTarget(), request)
	if err != nil {
		t.Fatal(err)
	}
	executor := &testNodeChannelExecutor{pausedRebase: workerResult}
	agent := &NodeChannelAgent{config: NodeChannelAgentConfig{
		Executor: executor, PausedRebaseExecutor: executor,
		OperationTimeout: time.Second, PausedRebaseTimeout: time.Second,
		Capacity: testNodeChannelCapacity(),
	}}
	result := agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil || result.PausedRebase == nil {
		t.Fatalf("paused-rebase result = %+v, %v", result, err)
	}
	rejectRequest := request
	rejectRequest.Reject = true
	rejectCommand, err := NewNodeChannelPausedRebaseCommand(testNodeChannelRebaseTarget(), rejectRequest)
	if err != nil {
		t.Fatal(err)
	}
	result = agent.execute(t.Context(), rejectCommand)
	if err := result.ValidateFor(rejectCommand); err != nil || result.PausedRebaseReject == nil {
		t.Fatalf("paused-rebase rejection = %+v, %v", result, err)
	}

	executor.pausedRebaseBlock = true
	agent.config.PausedRebaseTimeout = time.Millisecond
	result = agent.execute(t.Context(), command)
	if err := result.ValidateFor(command); err != nil {
		t.Fatal(err)
	}
	if result.ErrorClass != NodeChannelErrorUnavailable || !strings.Contains(result.Error, context.DeadlineExceeded.Error()) {
		t.Fatalf("timed-out paused-rebase result = %+v", result)
	}

	executor.pausedRebaseBlock = false
	ackRequest := request
	ackRequest.AcknowledgeProofDigest = workerResult.ProofDigest
	ackCommand, err := NewNodeChannelPausedRebaseCommand(testNodeChannelRebaseTarget(), ackRequest)
	if err != nil {
		t.Fatal(err)
	}
	agent.config.PausedRebaseTimeout = time.Second
	result = agent.execute(t.Context(), ackCommand)
	if err := result.ValidateFor(ackCommand); err != nil || result.PausedRebaseAck == nil {
		t.Fatalf("paused-rebase acknowledgement = %+v, %v", result, err)
	}
}

func TestNewNodeChannelAgentRejectsAmbientOrIncompleteIdentity(t *testing.T) {
	directory := t.TempDir()
	config := NodeChannelAgentConfig{
		BaseURL: "https://region.internal:8421", CAFile: filepath.Join(directory, "ca.pem"),
		ClientCertFile: filepath.Join(directory, "client.pem"),
		ClientKeyFile:  filepath.Join(directory, "client-key.pem"), TokenFile: filepath.Join(directory, "token"),
		PeerURISAN: "spiffe://sandbox0.test/region/runtime-slot-channel",
		ClusterID:  "cluster-1", NodeID: "node-1", NodeUID: "node-uid-1",
		NodeBootIDFile: filepath.Join(directory, "boot-id"), Executor: &testNodeChannelExecutor{},
		Capacity: testNodeChannelCapacity(),
	}
	if _, err := NewNodeChannelAgent(config); err != nil {
		t.Fatal(err)
	}
	config.BaseURL = "https://region.internal:8421/"
	if _, err := NewNodeChannelAgent(config); !errdefs.IsInvalidArgument(err) {
		t.Fatalf("non-origin URL error = %v", err)
	}
	config.BaseURL = "https://region.internal:8421"
	config.PeerURISAN = "https://region.internal"
	if _, err := NewNodeChannelAgent(config); !errdefs.IsInvalidArgument(err) {
		t.Fatalf("non-SPIFFE peer error = %v", err)
	}
}

func TestNodeChannelAgentSetResolvesCanonicalExactEndpoints(t *testing.T) {
	directory := t.TempDir()
	resolver := &staticNodeChannelResolver{addresses: []net.IPAddr{
		{IP: net.ParseIP("2001:db8::2")},
		{IP: net.ParseIP("192.0.2.2")},
		{IP: net.ParseIP("192.0.2.2")},
	}}
	set, err := NewNodeChannelAgentSet(NodeChannelAgentSetConfig{
		Agent: NodeChannelAgentConfig{
			BaseURL: "https://manager-nodes.sandbox0-system.svc:8421",
			CAFile:  filepath.Join(directory, "ca.pem"), ClientCertFile: filepath.Join(directory, "client.pem"),
			ClientKeyFile: filepath.Join(directory, "client-key.pem"), TokenFile: filepath.Join(directory, "token"),
			PeerURISAN: "spiffe://sandbox0.test/region/runtime-slot-channel",
			ClusterID:  "cluster-1", NodeID: "node-1", NodeUID: "node-uid-1",
			NodeBootIDFile: filepath.Join(directory, "boot-id"), Executor: &testNodeChannelExecutor{},
			Capacity: testNodeChannelCapacity(),
		},
		Resolver: resolver,
	})
	if err != nil {
		t.Fatal(err)
	}
	addresses, err := set.resolve(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"192.0.2.2:8421", "[2001:db8::2]:8421"}
	if strings.Join(addresses, ",") != strings.Join(want, ",") ||
		resolver.host != "manager-nodes.sandbox0-system.svc" {
		t.Fatalf("resolved endpoints = %#v via %q, want %#v", addresses, resolver.host, want)
	}
}

func TestNodeChannelAgentSetRejectsVirtualOrUnboundedDiscovery(t *testing.T) {
	directory := t.TempDir()
	base := NodeChannelAgentSetConfig{Agent: NodeChannelAgentConfig{
		BaseURL: "https://manager-nodes.sandbox0-system.svc:8421",
		CAFile:  filepath.Join(directory, "ca.pem"), ClientCertFile: filepath.Join(directory, "client.pem"),
		ClientKeyFile: filepath.Join(directory, "client-key.pem"), TokenFile: filepath.Join(directory, "token"),
		PeerURISAN: "spiffe://sandbox0.test/region/runtime-slot-channel",
		ClusterID:  "cluster-1", NodeID: "node-1", NodeUID: "node-uid-1",
		NodeBootIDFile: filepath.Join(directory, "boot-id"), Executor: &testNodeChannelExecutor{},
		Capacity: testNodeChannelCapacity(),
	}, MaxEndpoints: 1}
	base.Agent.BaseURL = "https://192.0.2.10:8421"
	if _, err := NewNodeChannelAgentSet(base); !errdefs.IsInvalidArgument(err) {
		t.Fatalf("IP authority error = %v", err)
	}
	base.Agent.BaseURL = "https://manager-nodes.sandbox0-system.svc:8421"
	base.Resolver = &staticNodeChannelResolver{addresses: []net.IPAddr{
		{IP: net.ParseIP("192.0.2.2")}, {IP: net.ParseIP("192.0.2.3")},
	}}
	set, err := NewNodeChannelAgentSet(base)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := set.resolve(t.Context()); !errdefs.IsInvalidArgument(err) {
		t.Fatalf("endpoint limit error = %v", err)
	}
}
