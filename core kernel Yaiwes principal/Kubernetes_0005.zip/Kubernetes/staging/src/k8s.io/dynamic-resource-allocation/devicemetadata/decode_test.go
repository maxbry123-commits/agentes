/*
Copyright The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package devicemetadata

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/google/go-cmp/cmp"

	resourceapi "k8s.io/api/resource/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/dynamic-resource-allocation/api/metadata"
	"k8s.io/dynamic-resource-allocation/api/metadata/v1alpha1"
	"k8s.io/dynamic-resource-allocation/api/metadata/v1beta1"
	"k8s.io/utils/ptr"
)

var (
	validInternal = &metadata.DeviceMetadata{
		ObjectMeta: metav1.ObjectMeta{
			Name:       "my-claim",
			Namespace:  "default",
			UID:        "uid-1234",
			Generation: 1,
		},
		Requests: []metadata.DeviceMetadataRequest{{
			Name: "gpu",
			Devices: []metadata.Device{{
				Driver: "gpu.example.com",
				Pool:   "worker-0",
				Name:   "gpu-0",
				Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
					"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
				},
			}},
		}},
	}

	validV1Alpha1 = &v1alpha1.DeviceMetadata{
		TypeMeta: metav1.TypeMeta{
			APIVersion: v1alpha1.SchemeGroupVersion.String(),
			Kind:       "DeviceMetadata",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:       "my-claim",
			Namespace:  "default",
			UID:        "uid-1234",
			Generation: 1,
		},
		Requests: []v1alpha1.DeviceMetadataRequest{{
			Name: "gpu",
			Devices: []v1alpha1.Device{{
				Driver: "gpu.example.com",
				Pool:   "worker-0",
				Name:   "gpu-0",
				Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
					"model": {StringValue: new("LATEST-GPU-MODEL")},
				},
			}},
		}},
	}
	validV1Alpha1JSON = mustMarshal(validV1Alpha1)

	validV1Beta1 = &v1beta1.DeviceMetadata{
		TypeMeta: metav1.TypeMeta{
			APIVersion: v1beta1.SchemeGroupVersion.String(),
			Kind:       "DeviceMetadata",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name:       "my-claim",
			Namespace:  "default",
			UID:        "uid-1234",
			Generation: 1,
		},
		Requests: []v1beta1.DeviceMetadataRequest{{
			Name: "gpu",
			Devices: []v1beta1.Device{{
				Driver: "gpu.example.com",
				Pool:   "worker-0",
				Name:   "gpu-0",
				Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
					"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
				},
			}},
		}},
	}
	validV1Beta1JSON = mustMarshal(validV1Beta1)
)

func mustMarshal(obj interface{}) []byte {
	data, err := json.Marshal(obj)
	if err != nil {
		panic(err)
	}
	return append(data, '\n')
}

func TestDecodeMetadataFromStream(t *testing.T) {
	unknownVersionJSON := `{"apiVersion":"metadata.k8s.io/v99","kind":"DeviceMetadata","metadata":{"name":"test"}}` + "\n"
	unknownV2JSON := `{"apiVersion":"metadata.k8s.io/v100","kind":"DeviceMetadata","metadata":{"name":"test"}}` + "\n"
	unknownVersionMissingKindJSON := `{"apiVersion":"metadata.k8s.io/v99","metadata":{"name":"test"}}` + "\n"
	missingKindJSON := `{"apiVersion":"metadata.resource.k8s.io/v1alpha1","metadata":{"name":"test"}}` + "\n"
	missingApiversionJSON := `{"kind":"DeviceMetadata","metadata":{"name":"test"}}` + "\n"
	malformedV1Alpha1JSON := `{"apiVersion":"metadata.resource.k8s.io/v1alpha1","kind":"DeviceMetadata","metadata":{"name":"test"},"requests":"this-should-be-an-array"}` + "\n"

	invalidV1Alpha1JSON := `{"apiVersion":"metadata.resource.k8s.io/v1alpha1","kind":"DeviceMetadata","metadata":{"name":"test"},"podClaimName":"%!$#"}`
	invalidV1Beta1JSON := `{"apiVersion":"metadata.resource.k8s.io/v1beta1","kind":"DeviceMetadata","metadata":{"name":"test"},"podClaimName":"%!$#"}`
	invalidInternal := &metadata.DeviceMetadata{
		ObjectMeta: metav1.ObjectMeta{
			Name: "test",
		},
		PodClaimName: new("%!$#"),
	}

	testcases := map[string]struct {
		isInvalid   bool
		streamInput []byte
		dest        runtime.Object
		expected    runtime.Object
		expectError string
		expectGVK   *schema.GroupVersionKind
	}{
		"decode-v1alpha1-to-v1alpha1": {
			streamInput: validV1Alpha1JSON,
			dest:        &v1alpha1.DeviceMetadata{},
			expected:    validV1Alpha1,
			expectGVK:   new(v1alpha1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-v1alpha1-to-v1beta1": {
			streamInput: validV1Alpha1JSON,
			dest:        &v1beta1.DeviceMetadata{},
			expected:    validV1Beta1,
		},
		"decode-v1alpha1-to-internal": {
			streamInput: validV1Alpha1JSON,
			dest:        &metadata.DeviceMetadata{},
			expected:    validInternal,
			expectGVK:   new(v1alpha1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-v1beta1-to-v1alpha1": {
			streamInput: validV1Beta1JSON,
			dest:        &v1alpha1.DeviceMetadata{},
			expected:    validV1Alpha1,
		},
		"decode-v1beta1-to-v1beta1": {
			streamInput: validV1Beta1JSON,
			dest:        &v1beta1.DeviceMetadata{},
			expected:    validV1Beta1,
			expectGVK:   new(v1beta1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-v1beta1-to-internal": {
			streamInput: validV1Beta1JSON,
			dest:        &metadata.DeviceMetadata{},
			expected:    validInternal,
			expectGVK:   new(v1beta1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-all-to-v1alpha1": {
			streamInput: []byte(string(validV1Beta1JSON) + string(validV1Alpha1JSON)),
			dest:        &v1alpha1.DeviceMetadata{},
			expected:    validV1Alpha1,
		},
		"decode-all-to-v1beta1": {
			streamInput: []byte(string(validV1Beta1JSON) + string(validV1Alpha1JSON)),
			dest:        &v1beta1.DeviceMetadata{},
			expected:    validV1Beta1,
		},
		"decode-all-to-internal": {
			streamInput: []byte(string(validV1Beta1JSON) + string(validV1Alpha1JSON)),
			dest:        &metadata.DeviceMetadata{},
			expected:    validInternal,
			expectGVK:   new(v1beta1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-all-reversed-to-internal": {
			streamInput: []byte(string(validV1Alpha1JSON) + string(validV1Beta1JSON)),
			dest:        &metadata.DeviceMetadata{},
			expected:    validInternal,
			expectGVK:   new(v1alpha1.SchemeGroupVersion.WithKind("DeviceMetadata")),
		},
		"decode-all-to-wrong-type": {
			streamInput: []byte(string(validV1Alpha1JSON) + string(validV1Beta1JSON)),
			dest:        &resourceapi.ResourceClaim{},
			expectError: "determine target type",
		},
		"invalid-v1alpha1": {
			isInvalid:   true,
			streamInput: []byte(invalidV1Alpha1JSON),
			dest:        &metadata.DeviceMetadata{},
			expected:    invalidInternal,
		},
		"invalid-v1beta1": {
			isInvalid:   true,
			streamInput: []byte(invalidV1Beta1JSON),
			dest:        &metadata.DeviceMetadata{},
			expected:    invalidInternal,
		},
		"empty-stream": {
			streamInput: nil,
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "no metadata objects found in stream",
		},
		"invalid-json": {
			streamInput: []byte("{not-json"),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "read metadata object from stream",
		},
		"truncated-json": {
			streamInput: []byte(`{"apiVersion":"metadata.resource.k8s.io/v1alpha1","kind":"DeviceMeta`),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "read metadata object from stream",
		},
		"missing-kind": {
			streamInput: []byte(missingKindJSON),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.resource.k8s.io/v1alpha1",
		},
		"missing-apiversion": {
			streamInput: []byte(missingApiversionJSON),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata object",
		},
		"malformed-registered-version": {
			streamInput: []byte(malformedV1Alpha1JSON),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.resource.k8s.io/v1alpha1",
		},
		"only-unknown-versions": {
			streamInput: []byte(unknownVersionJSON),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "no compatible metadata version found in stream (unknown versions: metadata.k8s.io/v99)",
		},
		"unknown-version-missing-kind": {
			streamInput: []byte(unknownVersionMissingKindJSON),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.k8s.io/v99",
		},
		"multiple-unknown-versions": {
			streamInput: append([]byte(unknownVersionJSON), []byte(unknownV2JSON)...),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "no compatible metadata version found in stream (unknown versions: metadata.k8s.io/v99, metadata.k8s.io/v100)",
		},
		"known-version-then-broken": {
			streamInput: append(validV1Alpha1JSON, []byte("{broken")...),
			dest:        &v1alpha1.DeviceMetadata{},
			expected:    validV1Alpha1,
		},
		"skips-unknown-version": {
			streamInput: append([]byte(unknownVersionJSON), validV1Alpha1JSON...),
			dest:        &v1alpha1.DeviceMetadata{},
			expected:    validV1Alpha1,
		},
		"malformed-registered-then-valid-is-fatal": {
			streamInput: append([]byte(malformedV1Alpha1JSON), validV1Alpha1JSON...),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.resource.k8s.io/v1alpha1",
		},
		"missing-kind-then-valid-is-fatal": {
			streamInput: append([]byte(missingKindJSON), validV1Alpha1JSON...),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.resource.k8s.io/v1alpha1",
		},
		"missing-apiversion-then-valid-is-fatal": {
			streamInput: append([]byte(missingApiversionJSON), validV1Alpha1JSON...),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata object",
		},
		"unknown-version-then-malformed-is-fatal": {
			streamInput: append([]byte(unknownVersionJSON), []byte(missingKindJSON)...),
			dest:        &v1alpha1.DeviceMetadata{},
			expectError: "decode metadata.resource.k8s.io/v1alpha1",
		},
	}

	for name, tc := range testcases {
		t.Run(name, func(t *testing.T) {
			for _, withValidation := range []bool{true, false} {
				t.Run(fmt.Sprintf("with-validation-%v", withValidation), func(t *testing.T) {
					var opts []DecodeMetadataOption
					var validationResult error
					if withValidation {
						opts = append(opts, DecodeMetadataWithValidationResult(&validationResult))
					}
					dest := tc.dest.DeepCopyObject()
					err := DecodeMetadataFromStream(json.NewDecoder(bytes.NewReader(tc.streamInput)), dest, opts...)
					if tc.expectError != "" {
						if err == nil {
							t.Fatalf("expected error containing %q, got nil", tc.expectError)
						}
						if !strings.Contains(err.Error(), tc.expectError) {
							t.Fatalf("expected error containing %q, got: %v", tc.expectError, err)
						}
						return
					}
					if err != nil {
						t.Fatalf("DecodeMetadataFromStream: %v", err)
					}

					if diff := cmp.Diff(tc.expected, dest); diff != "" {
						t.Errorf("metadata mismatch (-want +got):\n%s", diff)
					}

					if withValidation && tc.isInvalid && validationResult == nil {
						t.Errorf("validation did not fail as expected")
					}
					if validationResult != nil && (!withValidation || !tc.isInvalid) {
						t.Errorf("unexpected validation error: %v", validationResult)
					}

					if tc.expectGVK != nil {
						var gvk schema.GroupVersionKind
						dest := tc.dest.DeepCopyObject()
						err := DecodeMetadataFromStream(json.NewDecoder(bytes.NewReader(tc.streamInput)), dest, append(opts, DecodeMetadataStoreGVKResult(&gvk))...)
						if err != nil {
							t.Fatalf("DecodeMetadataFromStream with GVK: %v", err)
						}
						if gvk != *tc.expectGVK {
							t.Errorf("expected %s, got %s", tc.expectGVK, gvk)
						}
					}
				})
			}
		})
	}
}

func TestReadMetadata(t *testing.T) {
	dir := t.TempDir()
	validFile := filepath.Join(dir, "valid", "metadata.json")
	if err := os.MkdirAll(filepath.Dir(validFile), 0755); err != nil {
		t.Fatalf("create test dir: %v", err)
	}
	if err := os.WriteFile(validFile, validV1Alpha1JSON, 0644); err != nil {
		t.Fatalf("write test file: %v", err)
	}

	emptyObjectFile := filepath.Join(dir, "empty-object", "metadata.json")
	if err := os.MkdirAll(filepath.Dir(emptyObjectFile), 0755); err != nil {
		t.Fatalf("create test dir: %v", err)
	}
	if err := os.WriteFile(emptyObjectFile, []byte("{}"), 0644); err != nil {
		t.Fatalf("write test file: %v", err)
	}

	expectedInternal := &metadata.DeviceMetadata{
		ObjectMeta: metav1.ObjectMeta{
			Name:       "my-claim",
			Namespace:  "default",
			UID:        "uid-1234",
			Generation: 1,
		},
		Requests: []metadata.DeviceMetadataRequest{{
			Name: "gpu",
			Devices: []metadata.Device{{
				Driver: "gpu.example.com",
				Pool:   "worker-0",
				Name:   "gpu-0",
				Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
					"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
				},
			}},
		}},
	}

	testcases := map[string]struct {
		path        string
		expected    *metadata.DeviceMetadata
		expectError string
	}{
		"valid-file": {
			path:     validFile,
			expected: expectedInternal,
		},
		"missing-file": {
			path:        "/nonexistent/path/metadata.json",
			expectError: "open metadata file",
		},
		"error-includes-path": {
			path:        emptyObjectFile,
			expectError: emptyObjectFile,
		},
	}

	for name, tc := range testcases {
		t.Run(name, func(t *testing.T) {
			dm, err := readMetadata(tc.path)

			if tc.expectError != "" {
				if err == nil {
					t.Fatalf("expected error containing %q, got nil", tc.expectError)
				}
				if !strings.Contains(err.Error(), tc.expectError) {
					t.Fatalf("expected error containing %q, got: %v", tc.expectError, err)
				}
				return
			}
			if err != nil {
				t.Fatalf("readMetadata: %v", err)
			}

			if diff := cmp.Diff(tc.expected, dm); diff != "" {
				t.Errorf("metadata mismatch (-want +got):\n%s", diff)
			}
		})
	}
}

func TestReadRequestDir(t *testing.T) {
	dir := t.TempDir()

	gpuInternal := metadata.DeviceMetadataRequest{
		Name: "gpu",
		Devices: []metadata.Device{{
			Driver: "gpu.example.com",
			Pool:   "worker-0",
			Name:   "gpu-0",
			Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
				"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
			},
		}},
	}
	gpuAltInternal := metadata.DeviceMetadataRequest{
		Name: "gpu",
		Devices: []metadata.Device{{
			Driver: "mlx.example.com",
			Pool:   "worker-1",
			Name:   "gpu-1",
		}},
	}
	nicInternal := metadata.DeviceMetadataRequest{
		Name: "nic",
		Devices: []metadata.Device{{
			Driver: "nic.example.com",
			Pool:   "worker-0",
			Name:   "nic-0",
		}},
	}

	gpuJSON := mustMarshal(&v1alpha1.DeviceMetadata{
		TypeMeta:   metav1.TypeMeta{APIVersion: v1alpha1.SchemeGroupVersion.String(), Kind: "DeviceMetadata"},
		ObjectMeta: metav1.ObjectMeta{Name: "my-claim", Namespace: "default", UID: "uid-1234", Generation: 1},
		Requests: []v1alpha1.DeviceMetadataRequest{{
			Name: "gpu",
			Devices: []v1alpha1.Device{{
				Driver: "gpu.example.com",
				Pool:   "worker-0",
				Name:   "gpu-0",
				Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
					"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
				},
			}},
		}},
	})
	nicJSON := mustMarshal(&v1alpha1.DeviceMetadata{
		TypeMeta:   metav1.TypeMeta{APIVersion: v1alpha1.SchemeGroupVersion.String(), Kind: "DeviceMetadata"},
		ObjectMeta: metav1.ObjectMeta{Name: "my-claim", Namespace: "default", UID: "uid-1234", Generation: 1},
		Requests: []v1alpha1.DeviceMetadataRequest{{
			Name:    "nic",
			Devices: []v1alpha1.Device{{Driver: "nic.example.com", Pool: "worker-0", Name: "nic-0"}},
		}},
	})
	primaryDriverJSON := mustMarshal(&v1alpha1.DeviceMetadata{
		TypeMeta:   metav1.TypeMeta{APIVersion: v1alpha1.SchemeGroupVersion.String(), Kind: "DeviceMetadata"},
		ObjectMeta: metav1.ObjectMeta{Name: "my-claim", Namespace: "default", UID: "uid-1234", Generation: 1},
		Requests: []v1alpha1.DeviceMetadataRequest{
			{
				Name: "gpu-0",
				Devices: []v1alpha1.Device{{
					Driver: "gpu.example.com",
					Pool:   "worker-0",
					Name:   "gpu-0",
					Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
						"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
					},
				}},
			},
			{
				Name: "single-gpu",
				Devices: []v1alpha1.Device{{
					Driver: "gpu.example.com",
					Pool:   "worker-0",
					Name:   "gpu-0",
					Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
						"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
					},
				}},
			},
			{
				Name: "gpu-1",
				Devices: []v1alpha1.Device{{
					Driver: "gpu.example.com",
					Pool:   "worker-0",
					Name:   "gpu-0",
					Attributes: map[resourceapi.QualifiedName]resourceapi.DeviceAttribute{
						"model": {StringValue: ptr.To("LATEST-GPU-MODEL")}, //nolint:modernize
					},
				}},
			},
		},
	})
	secondaryDriverJSON := mustMarshal(&v1alpha1.DeviceMetadata{
		TypeMeta:   metav1.TypeMeta{APIVersion: v1alpha1.SchemeGroupVersion.String(), Kind: "DeviceMetadata"},
		ObjectMeta: metav1.ObjectMeta{Name: "my-claim", Namespace: "default", UID: "uid-1234", Generation: 1},
		Requests: []v1alpha1.DeviceMetadataRequest{
			{
				Name:    "gpu-0",
				Devices: []v1alpha1.Device{{Driver: "mlx.example.com", Pool: "worker-1", Name: "gpu-1"}},
			},
			{
				Name:    "gpu-1",
				Devices: []v1alpha1.Device{{Driver: "mlx.example.com", Pool: "worker-1", Name: "gpu-1"}},
			},
		},
	})
	podClaimJSON := mustMarshal(&v1alpha1.DeviceMetadata{
		TypeMeta:     metav1.TypeMeta{APIVersion: v1alpha1.SchemeGroupVersion.String(), Kind: "DeviceMetadata"},
		ObjectMeta:   metav1.ObjectMeta{Name: "my-claim", Namespace: "default", UID: "uid-1234", Generation: 1},
		PodClaimName: ptr.To("my-gpu"), //nolint:modernize
		Requests: []v1alpha1.DeviceMetadataRequest{{
			Name:    "gpu",
			Devices: []v1alpha1.Device{{Driver: "gpu.example.com", Pool: "worker-0", Name: "gpu-0"}},
		}},
	})

	writeFile := func(subdir, name string, data []byte) string {
		p := filepath.Join(dir, subdir)
		if err := os.MkdirAll(p, 0755); err != nil {
			t.Fatalf("mkdir %s: %v", p, err)
		}
		if err := os.WriteFile(filepath.Join(p, name), data, 0644); err != nil {
			t.Fatalf("write %s/%s: %v", p, name, err)
		}
		return p
	}

	singleDir := writeFile("single", "gpu.example.com"+metadata.MetadataFileSuffix, gpuJSON)
	multiDir := writeFile("multi", "gpu.example.com"+metadata.MetadataFileSuffix, gpuJSON)
	writeFile("multi", "nic.example.com"+metadata.MetadataFileSuffix, nicJSON)
	sameRequestNameDir := writeFile("same-request-name", "gpu.example.com"+metadata.MetadataFileSuffix, primaryDriverJSON)
	writeFile("same-request-name", "mlx.example.com"+metadata.MetadataFileSuffix, secondaryDriverJSON)
	emptyDir := writeFile("empty", "unrelated.txt", []byte("not metadata"))
	mixedDir := writeFile("mixed", "gpu.example.com"+metadata.MetadataFileSuffix, gpuJSON)
	writeFile("mixed", "unrelated.json", []byte(`{"foo":"bar"}`))
	podClaimDir := writeFile("podclaim", "gpu.example.com"+metadata.MetadataFileSuffix, podClaimJSON)

	testcases := map[string]struct {
		dir         string
		expected    *metadata.DeviceMetadata
		expectError string
	}{
		"single-driver": {
			dir: singleDir,
			expected: &metadata.DeviceMetadata{
				Requests: []metadata.DeviceMetadataRequest{gpuInternal},
			},
		},
		"multiple-drivers": {
			dir: multiDir,
			expected: &metadata.DeviceMetadata{
				Requests: []metadata.DeviceMetadataRequest{gpuInternal, nicInternal},
			},
		},
		"merge-same-request-name-across-drivers": {
			dir: sameRequestNameDir,
			expected: &metadata.DeviceMetadata{
				Requests: []metadata.DeviceMetadataRequest{
					{
						Name:    "gpu-0",
						Devices: append(gpuInternal.Devices, gpuAltInternal.Devices...),
					},
					{
						Name:    "single-gpu",
						Devices: gpuInternal.Devices,
					},
					{
						Name:    "gpu-1",
						Devices: append(gpuInternal.Devices, gpuAltInternal.Devices...),
					},
				},
			},
		},
		"empty-directory": {
			dir:         emptyDir,
			expectError: "no metadata files found",
		},
		"nonexistent-directory": {
			dir:         "/nonexistent/path",
			expectError: "no metadata files found",
		},
		"ignores-non-matching-files": {
			dir: mixedDir,
			expected: &metadata.DeviceMetadata{
				Requests: []metadata.DeviceMetadataRequest{gpuInternal},
			},
		},
		"preserves-pod-claim-name": {
			dir: podClaimDir,
			expected: &metadata.DeviceMetadata{
				PodClaimName: ptr.To("my-gpu"), //nolint:modernize
				Requests: []metadata.DeviceMetadataRequest{{
					Name:    "gpu",
					Devices: []metadata.Device{{Driver: "gpu.example.com", Pool: "worker-0", Name: "gpu-0"}},
				}},
			},
		},
	}

	for name, tc := range testcases {
		t.Run(name, func(t *testing.T) {
			dm, err := readRequestDir(tc.dir)

			if tc.expectError != "" {
				if err == nil {
					t.Fatalf("expected error containing %q, got nil", tc.expectError)
				}
				if !strings.Contains(err.Error(), tc.expectError) {
					t.Fatalf("expected error containing %q, got: %v", tc.expectError, err)
				}
				return
			}
			if err != nil {
				t.Fatalf("readRequestDir: %v", err)
			}

			if diff := cmp.Diff(tc.expected, dm); diff != "" {
				t.Errorf("metadata mismatch (-want +got):\n%s", diff)
			}
		})
	}
}
