import platform
import uuid
from xml.etree import ElementTree

import pytest
from _pytest.main import ExitCode
from flask import jsonify, request

from test.apps.catalog.openapi.modifiers.stateful import (
    InvalidParameter,
    OmitRequiredField,
    ReturnPlainText,
)
from test.utils import flaky, load_yaml_or_fail


@pytest.mark.snapshot(replace_reproduce_with=True)
@pytest.mark.parametrize("workers", [1, 2])
@pytest.mark.skipif(platform.system() == "Windows", reason="Simpler to setup on Linux")
def test_default(ctx, cli, snapshot_cli, workers):
    api = ctx.openapi.apps.users_crud()
    assert (
        cli.run(
            api.schema_url,
            "-c not_a_server_error",
            f"--workers={workers}",
            "--mode=positive",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True)
@flaky(max_runs=3, min_passes=1)
def test_sanitization(ctx, cli, tmp_path):
    api = ctx.openapi.apps.users_crud()
    cassette_path = tmp_path / "output.yaml"
    token = "secret"
    result = cli.run_and_assert(
        api.schema_url,
        "--phases=stateful",
        "-c not_a_server_error",
        f"--header=Authorization: Bearer {token}",
        f"--report-vcr-path={cassette_path}",
        "--max-failures=1",
        exit_code=ExitCode.TESTS_FAILED,
    )
    assert token not in result.stdout


@pytest.mark.snapshot(replace_reproduce_with=True)
@flaky(max_runs=5, min_passes=1)
def test_max_failures(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud_with_failure()
    assert (
        cli.run(
            api.schema_url,
            "--no-shrink",
            "--max-examples=80",
            "--max-failures=2",
            "-c not_a_server_error",
            "--phases=fuzzing,stateful",
            "--mode=positive",
        )
        == snapshot_cli
    )


def test_with_cassette(ctx, tmp_path, cli):
    api = ctx.openapi.apps.users_crud()
    cassette_path = tmp_path / "output.yaml"
    cli.run(
        api.schema_url,
        "--max-examples=40",
        "--max-failures=1",
        "-c not_a_server_error",
        f"--report-vcr-path={cassette_path}",
    )
    assert cassette_path.exists()
    cassette = load_yaml_or_fail(cassette_path)
    assert len(cassette["http_interactions"]) >= 20
    assert cassette["seed"] not in (None, "None")


def test_with_cassette_stateful_only(ctx, tmp_path, cli):
    api = ctx.openapi.apps.users_crud()
    cassette_path = tmp_path / "output.yaml"
    cli.run(
        api.schema_url,
        "--max-examples=5",
        "--max-failures=1",
        "--phases=stateful",
        "-c not_a_server_error",
        f"--report-vcr-path={cassette_path}",
    )
    assert cassette_path.exists()
    cassette = load_yaml_or_fail(cassette_path)
    for interaction in cassette["http_interactions"]:
        assert interaction["phase"]["name"] == "stateful"


def test_junit(ctx, tmp_path, cli):
    api = ctx.openapi.apps.users_crud()
    junit_path = tmp_path / "junit.xml"
    cli.run_and_assert(
        api.schema_url,
        "--phases=stateful",
        "--no-shrink",
        "--max-examples=80",
        "--max-failures=1",
        "-c not_a_server_error",
        f"--report-junit-path={junit_path}",
        exit_code=ExitCode.TESTS_FAILED,
    )
    assert junit_path.exists()
    xml_content = junit_path.read_text()
    root = ElementTree.fromstring(xml_content)
    structure = (
        root.tag,
        [
            (suite.attrib.get("name"), [(case.attrib.get("name"), [child.tag for child in case]) for case in suite])
            for suite in root
        ],
    )
    expected = ("testsuites", [("schemathesis", [("Stateful tests", ["failure"])])])
    assert structure == expected, xml_content


@pytest.mark.snapshot(replace_reproduce_with=True)
def test_stateful_only(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud()
    assert (
        cli.run(
            api.schema_url,
            "--phases=stateful",
            "--mode=positive",
            "--no-shrink",
            "--max-examples=200",
            "-c not_a_server_error",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True, replace_phase_statistic=True)
def test_stateful_only_with_error(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud()
    assert (
        cli.run(
            api.schema_url,
            "--url=http://127.0.0.1:1/api",
            "--phases=stateful",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True)
def test_filtered_out(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud_with_success()
    assert (
        cli.run(
            api.schema_url,
            "--max-examples=40",
            "--include-path=/api/success",
            "--max-failures=1",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True, replace_phase_statistic=True)
@pytest.mark.skipif(platform.system() == "Windows", reason="Linux specific error")
def test_proxy_error(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud_with_success()
    assert (
        cli.run(
            api.schema_url,
            "--proxy=http://127.0.0.1",
            "--phases=stateful",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True)
def test_keyboard_interrupt(ctx, cli, mocker, snapshot_cli):
    def mocked(*args, **kwargs):
        raise KeyboardInterrupt

    api = ctx.openapi.apps.users_crud_with_success()
    mocker.patch("schemathesis.Case.call", wraps=mocked)
    assert cli.run(api.schema_url, "--phases=stateful") == snapshot_cli


@pytest.mark.snapshot(replace_reproduce_with=True)
def test_missing_link(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_create_only()
    assert cli.run(api.schema_url, "--phases=stateful") == snapshot_cli


@pytest.mark.snapshot(replace_reproduce_with=True)
def test_not_enough_links(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.users_crud()
    assert cli.run(api.schema_url, "--phases=stateful", "--include-method=POST") == snapshot_cli


def test_invalid_parameter_reference(ctx, cli, snapshot_cli):
    # When a link references a non-existent parameter
    api = ctx.openapi.apps.stateful_users(InvalidParameter())
    assert cli.run(api.schema_url, "--phases=stateful", "-n 1") == snapshot_cli


def test_missing_body_parameter(ctx, cli, snapshot_cli):
    api = ctx.openapi.apps.stateful_users(OmitRequiredField())
    assert (
        cli.run(
            api.schema_url,
            "--phases=stateful",
            "-n 30",
            "-c not_a_server_error",
            "--mode=positive",
            config={"phases": {"stateful": {"inference": {"algorithms": []}}}},
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True)
@flaky(max_runs=3, min_passes=1)
def test_link_requestbody_extraction_fails_when_producer_missing_id(ctx, cli, snapshot_cli):
    openapi = {
        "openapi": "3.0.0",
        "info": {"title": "Minimal API", "version": "1.0.0"},
        "paths": {
            "/products": {
                "post": {
                    "operationId": "createProduct",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string", "enum": ["Product"]},
                                        "price": {"type": "number", "enum": [9.99]},
                                    },
                                    "required": ["name", "price"],
                                }
                            }
                        }
                    },
                    "responses": {
                        "201": {
                            "description": "Created product",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "id": {"type": "string"},
                                            "name": {"type": "string"},
                                            "price": {"type": "number"},
                                        },
                                        "required": ["id", "name", "price"],
                                    }
                                }
                            },
                            # Link: createOrder should take product id from response body
                            "links": {
                                "CreateOrder": {
                                    "operationId": "createOrder",
                                    # Attempt to populate order requestBody from response body id.
                                    # This runtime expression will fail because producer omits `id`.
                                    "requestBody": {"product_id": "$response.body#/id", "quantity": 1},
                                }
                            },
                        }
                    },
                }
            },
            "/orders": {
                "post": {
                    "operationId": "createOrder",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "product_id": {"type": "string"},
                                        "quantity": {"type": "integer"},
                                    },
                                    "required": ["product_id", "quantity"],
                                }
                            }
                        }
                    },
                    "responses": {
                        "201": {
                            "description": "Order created",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {"id": {"type": "string"}},
                                        "required": ["id"],
                                    }
                                }
                            },
                        }
                    },
                }
            },
        },
    }

    # Minimal Flask app that stores products internally but returns a response that omits `id`.
    app = ctx.openapi.make_flask_app_from_schema(openapi)
    products = {}
    next_id = 1
    next_order_id = 1

    @app.route("/products", methods=["POST"])
    def create_product():
        nonlocal next_id
        data = request.get_json() or {}
        if not isinstance(data, dict):
            return {"error": "Invalid input"}, 400

        name = data.get("name", "Product")
        if not isinstance(name, str) or not name:
            return {"error": "Invalid name"}, 400

        price = data.get("price", 9.99)
        if not isinstance(price, (int | float)):
            return {"error": "Invalid price"}, 400

        product_id = str(next_id)
        next_id += 1

        products[product_id] = {
            "id": product_id,
            "name": name,
            "price": float(price),
        }

        return jsonify({"name": products[product_id]["name"], "price": products[product_id]["price"]}), 201

    @app.route("/orders", methods=["POST"])
    def create_order():
        nonlocal next_order_id
        data = request.get_json() or {}
        if not isinstance(data, dict):
            return {"error": "Invalid input"}, 400

        product_id = data.get("product_id")
        if not isinstance(product_id, str):
            return {"error": "Invalid product_id"}, 400

        if product_id not in products:
            return jsonify({"detail": "product not found"}), 404
        order_id = str(next_order_id)
        next_order_id += 1
        return jsonify({"id": order_id}), 201

    assert (
        cli.run_openapi_app(
            app,
            "--max-examples=5",
            "-c not_a_server_error",
            "--phases=stateful",
        )
        == snapshot_cli
    )


@flaky(max_runs=3, min_passes=1)
@pytest.mark.parametrize("content", ["", "User data as plain text"])
def test_non_json_response(ctx, cli, snapshot_cli, content):
    api = ctx.openapi.apps.stateful_users(ReturnPlainText(body=content))
    assert (
        cli.run(
            api.schema_url,
            "--phases=stateful",
            "-n 80",
            "-c not_a_server_error",
            "--mode=positive",
            config={"phases": {"stateful": {"inference": {"algorithms": []}}}},
        )
        == snapshot_cli
    )


def test_unique_inputs(ctx, cli, snapshot_cli):
    # See GH-2977
    api = ctx.openapi.apps.success()
    schema_path = ctx.openapi.write_schema(
        {
            "/items": {
                "post": {
                    "responses": {
                        "200": {
                            "links": {"getItem": {"operationId": "GetById"}},
                        }
                    }
                }
            },
            "/item/{id}": {
                "get": {
                    "operationId": "GetById",
                    "responses": {"200": {"descrionn": "Ok"}},
                },
            },
        }
    )
    assert (
        cli.run(
            str(schema_path),
            f"--url={api.base_url}/api",
            "--phases=stateful",
            "--generation-unique-inputs",
            "--max-examples=10",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_stateful_statistic=False)
def test_stateful_link_coverage_with_no_parameters_or_body(cli, snapshot_cli, ctx):
    session_schema = {
        "type": "object",
        "properties": {"id": {"type": "string"}},
        "required": ["id"],
    }

    sessions_list_schema = {
        "type": "object",
        "properties": {
            "sessions": {
                "type": "array",
                "items": session_schema,
            }
        },
        "required": ["sessions"],
    }

    app, _ = ctx.openapi.make_flask_app(
        {
            "/sessions": {
                "post": {
                    "operationId": "createSession",
                    "responses": {
                        "200": {
                            "description": "Session created",
                            "content": {"application/json": {"schema": session_schema}},
                            "links": {
                                "GetSessions": {
                                    "operationId": "getSessions",
                                }
                            },
                        }
                    },
                },
                "get": {
                    "operationId": "getSessions",
                    "responses": {
                        "200": {
                            "description": "List of sessions",
                            "content": {"application/json": {"schema": sessions_list_schema}},
                        }
                    },
                },
            },
        }
    )

    sessions = {}
    next_id = 1

    @app.route("/sessions", methods=["POST"])
    def create_session():
        nonlocal next_id
        session_id = str(next_id)
        next_id += 1
        sessions[session_id] = {"id": session_id}
        return jsonify({"id": session_id}), 200

    @app.route("/sessions", methods=["GET"])
    def get_sessions():
        return jsonify({"sessions": list(sessions.values())}), 200

    assert (
        cli.run_openapi_app(
            app,
            "--max-examples=10",
            "-c not_a_server_error",
            "--phases=stateful",
        )
        == snapshot_cli
    )


def test_nested_link_refs(cli, snapshot_cli, ctx):
    # GH-3394: Links with nested $refs should be fully resolved
    app, _ = ctx.openapi.make_flask_app(
        {
            "/foo": {
                "get": {
                    "operationId": "getFoo",
                    "responses": {
                        "200": {
                            "description": "OK",
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {"id": {"type": "integer"}},
                                    }
                                }
                            },
                            "links": {
                                "Top": {"$ref": "#/components/links/Middle"},
                            },
                        }
                    },
                }
            },
            "/foo/{id}": {
                "parameters": [{"name": "id", "in": "path", "required": True, "schema": {"type": "integer"}}],
                "get": {
                    "operationId": "get-by-id",
                    "responses": {"200": {"description": "OK"}},
                },
            },
        },
        version="3.1.0",
        components={
            "links": {
                "Bottom": {
                    "operationId": "get-by-id",
                    "parameters": {"id": "$response.body#/id"},
                },
                "Middle": {"$ref": "#/components/links/Bottom"},
            }
        },
    )

    next_id = 1

    @app.route("/foo", methods=["GET"])
    def get_foo():
        nonlocal next_id
        result = {"id": next_id}
        next_id += 1
        return jsonify(result), 200

    @app.route("/foo/<int:id>", methods=["GET"])
    def get_foo_by_id(id):
        return jsonify({"id": id}), 200

    assert (
        cli.run_openapi_app(
            app,
            "--phases=stateful",
            "--max-examples=5",
            "-c not_a_server_error",
        )
        == snapshot_cli
    )


@pytest.mark.snapshot(replace_reproduce_with=True)
@pytest.mark.parametrize("phase", ["stateful", "fuzzing"])
def test_nested_path_shared_parameter_propagation(cli, ctx, snapshot_cli, phase):
    app, _ = ctx.openapi.make_flask_app(
        {
            "/users": {
                "post": {
                    "operationId": "createUser",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["name"],
                                    "properties": {"name": {"type": "string", "minLength": 1, "maxLength": 20}},
                                    "additionalProperties": False,
                                }
                            }
                        },
                    },
                    "responses": {
                        "201": {
                            "description": "User created",
                            "content": {"application/json": {"schema": {"$ref": "#/components/schemas/User"}}},
                        },
                    },
                },
            },
            "/users/{userId}/posts": {
                "parameters": [
                    {"in": "path", "name": "userId", "required": True, "schema": {"type": "string", "format": "uuid"}}
                ],
                "post": {
                    "operationId": "createPost",
                    "requestBody": {
                        "required": True,
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["content"],
                                    "properties": {"content": {"type": "string", "minLength": 11, "maxLength": 100}},
                                    "additionalProperties": False,
                                }
                            }
                        },
                    },
                    "responses": {
                        "201": {
                            "description": "Post created",
                            "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Post"}}},
                        },
                        "404": {"description": "User not found"},
                    },
                },
            },
            "/users/{userId}/posts/{postId}": {
                "parameters": [
                    {"in": "path", "name": "userId", "required": True, "schema": {"type": "string", "format": "uuid"}},
                    {"in": "path", "name": "postId", "required": True, "schema": {"type": "string", "format": "uuid"}},
                ],
                "get": {
                    "operationId": "getPost",
                    "responses": {
                        "200": {
                            "description": "Post found",
                            "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Post"}}},
                        },
                        "404": {"description": "Post not found"},
                        "500": {"description": "Server error"},
                    },
                },
            },
        },
        components={
            "schemas": {
                "User": {
                    "type": "object",
                    "properties": {"id": {"type": "string", "format": "uuid"}, "name": {"type": "string"}},
                    "required": ["id", "name"],
                },
                "Post": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string", "format": "uuid"},
                        "userId": {"type": "string", "format": "uuid"},
                        "content": {"type": "string"},
                    },
                    "required": ["id", "userId", "content"],
                },
            }
        },
    )

    users = {}
    posts = {}

    @app.route("/users", methods=["POST"])
    def create_user():
        data = request.get_json(force=True, silent=True) or {}
        if not isinstance(data.get("name"), str) or not data["name"]:
            return jsonify({"error": "Invalid name"}), 400
        user_id = str(uuid.uuid4())
        users[user_id] = {"id": user_id, "name": data["name"]}
        return jsonify(users[user_id]), 201

    @app.route("/users/<user_id>/posts", methods=["POST"])
    def create_post(user_id):
        if user_id not in users:
            return jsonify({"error": "User not found"}), 404
        data = request.get_json(force=True, silent=True) or {}
        content = data.get("content", "")
        if not isinstance(content, str) or not content:
            return jsonify({"error": "Invalid content"}), 400
        post_id = str(uuid.uuid4())
        posts[post_id] = {"id": post_id, "userId": user_id, "content": content}
        return jsonify(posts[post_id]), 201

    @app.route("/users/<user_id>/posts/<post_id>", methods=["GET"])
    def get_post(user_id, post_id):
        post = posts.get(post_id)
        if post is None or post["userId"] != user_id:
            return jsonify({"error": "Post not found"}), 404
        # Bug only discoverable when both IDs are correct
        if len(post["content"]) > 10:
            return jsonify({"error": "Internal server error"}), 500
        return jsonify(post), 200

    assert (
        cli.run_openapi_app(
            app,
            f"--phases={phase}",
            "--max-examples=50",
            "-c not_a_server_error",
            "--mode=positive",
        )
        == snapshot_cli
    )
