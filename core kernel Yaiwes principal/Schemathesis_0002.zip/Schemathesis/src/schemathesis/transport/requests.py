from __future__ import annotations

import binascii
import inspect
import json
import os
import time
from collections.abc import Mapping, MutableMapping
from io import BytesIO
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlencode, urlparse

import requests
from typing_extensions import override

from schemathesis.core import Body, NotSet, media_types
from schemathesis.core.errors import IncorrectUsage, SerializationNotPossible
from schemathesis.core.jsonschema import maybe_resolve_bundled, schema_with_bundle
from schemathesis.core.parameters import RAW_QUERY_STRING_KEY, RawQueryString, split_delimited_query
from schemathesis.core.rate_limit import ratelimit
from schemathesis.core.transforms import merge_at
from schemathesis.core.transport import DEFAULT_RESPONSE_TIMEOUT, Response
from schemathesis.generation.overrides import Override
from schemathesis.transport import BaseTransport, SerializationContext
from schemathesis.transport.prepare import get_exclude_headers, prepare_body, prepare_headers, prepare_url
from schemathesis.transport.serialization import Binary, serialize_binary, serialize_json, serialize_xml, serialize_yaml

if TYPE_CHECKING:
    from schemathesis.generation.case import Case


class ManagedCookiesSession(requests.Session):
    """`requests.Session` whose response cookies are dropped between generated requests."""


def _normalize_query_component(params: Any) -> str:
    if params is None:
        return ""
    if isinstance(params, str):
        return params.lstrip("?")
    if isinstance(params, Mapping):
        return urlencode(params, doseq=True)
    if isinstance(params, tuple | list):
        return urlencode(params, doseq=True)
    return str(params)


def _merge_query_components(left: Any, right: Any) -> str:
    left_chunk = _normalize_query_component(left)
    right_chunk = _normalize_query_component(right)
    if not left_chunk:
        return right_chunk
    if not right_chunk:
        return left_chunk
    return f"{left_chunk}&{right_chunk}"


class RequestsTransport(BaseTransport["requests.Session"]):
    @override
    def serialize_case(self, case: Case, **kwargs: Any) -> dict[str, Any]:
        base_url = kwargs.get("base_url")
        headers = kwargs.get("headers")
        params_override = kwargs.get("params")
        cookies = kwargs.get("cookies")

        final_headers = prepare_headers(case, headers)

        media_type = case.media_type

        # Set content type header if needed
        if (
            media_type
            and media_type != "multipart/form-data"
            and not isinstance(case.body, NotSet)
            and "content-type" not in final_headers
        ):
            final_headers["Content-Type"] = media_type

        url = prepare_url(case, base_url)

        # Handle serialization
        if not isinstance(case.body, NotSet) and media_type is not None:
            serializer = self._get_serializer(media_type)
            context = SerializationContext(case=case)
            extra = serializer(context, prepare_body(case))
        else:
            extra = {}

        if case._auth is not None:
            extra["auth"] = case._auth

        # Additional headers from serializer
        additional_headers = extra.pop("headers", None)
        if additional_headers:
            for key, value in additional_headers.items():
                final_headers.setdefault(key, value)

        params: dict[str, Any] | str | None = case.query
        raw_query = None
        if isinstance(params, Mapping):
            params = dict(params)
            marker_value = params.get(RAW_QUERY_STRING_KEY)
            if isinstance(marker_value, RawQueryString):
                raw_query = str(params.pop(RAW_QUERY_STRING_KEY))
            delimited_raw, params = split_delimited_query(params)
            if delimited_raw:
                raw_query = delimited_raw if raw_query is None else _merge_query_components(raw_query, delimited_raw)
        if raw_query is not None:
            params = _merge_query_components(raw_query, params)

        # Replace empty dictionaries with empty strings, so the parameters actually present in the query string
        if isinstance(params, Mapping) and any(value == {} for value in (params or {}).values()):
            params = dict(params)
            for key, value in params.items():
                if value == {}:
                    params[key] = ""

        data = {
            "method": case.method,
            "url": url,
            "cookies": case.cookies,
            "headers": final_headers,
            "params": params,
            **extra,
        }

        if params_override is not None:
            if isinstance(data.get("params"), str) or isinstance(params_override, str):
                data["params"] = _merge_query_components(data.get("params"), params_override)
            else:
                merge_at(data, "params", params_override)
        if cookies is not None:
            merge_at(data, "cookies", cookies)

        excluded_headers = get_exclude_headers(case)
        for name in excluded_headers:
            data["headers"].pop(name, None)

        return data

    def _build_request_data(self, case: Case, kwargs: dict[str, Any]) -> dict[str, Any]:
        """Merge the serialized case with transport settings from config and explicit keyword arguments."""
        config = case.operation.schema.config
        data = self.serialize_case(case, **kwargs)

        verify = config.tls_verify_for(operation=case.operation)
        if verify is not None:
            data.setdefault("verify", verify)
        timeout = config.request_timeout_for(operation=case.operation)
        if timeout is not None:
            data.setdefault("timeout", timeout)
        cert = config.request_cert_for(operation=case.operation)
        if cert is not None:
            data.setdefault("cert", cert)

        for key, value in kwargs.items():
            if key == "base_url":
                continue
            if key not in ("headers", "cookies", "params") or key not in data:
                data[key] = value
        data.setdefault("timeout", DEFAULT_RESPONSE_TIMEOUT)
        proxies = config.proxy_for(operation=case.operation)
        if proxies is not None:
            data.setdefault("proxies", {"all": proxies})
        return data

    @override
    def send(self, case: Case, *, session: requests.Session | None = None, **kwargs: Any) -> Response:
        config = case.operation.schema.config

        max_redirects = kwargs.pop("max_redirects", None) or config.max_redirects_for(operation=case.operation)

        if session is not None and session.headers:
            # These headers are explicitly provided via config or CLI args.
            # They have lower priority than ones provided via `kwargs`
            headers = kwargs.setdefault("headers", {}) or {}
            for name, value in session.headers.items():
                headers.setdefault(name, value)
            kwargs["headers"] = headers

        data = self._build_request_data(case, kwargs)

        current_session_headers: MutableMapping[str, Any] = {}
        current_session_auth = None

        if session is None:
            validate_vanilla_requests_kwargs(data, case.operation.schema.declared_base_url)
            session = requests.Session()
            close_session = True
        else:
            current_session_headers = session.headers
            if isinstance(session.auth, tuple):
                excluded_headers = get_exclude_headers(case)
                if "Authorization" in excluded_headers:
                    current_session_auth = session.auth
                    session.auth = None
            close_session = False
        if max_redirects is not None:
            session.max_redirects = max_redirects
        session.headers = {}

        verify = data.get("verify", True)

        try:
            rate_limit = config.rate_limit_for(operation=case.operation)
            retries = config.request_retries_for(operation=case.operation) or 0
            with ratelimit(rate_limit, config.base_url):
                response = _request_with_retries(session, data, retries)
            return Response.from_requests(
                response,
                verify=verify,
                _override=Override(
                    query=kwargs.get("params") or {},
                    headers=kwargs.get("headers") or {},
                    cookies=kwargs.get("cookies") or {},
                    path_parameters={},
                    body={},
                ),
            )
        finally:
            session.headers = current_session_headers
            if current_session_auth is not None:
                session.auth = current_session_auth
            if close_session:
                session.close()
            elif isinstance(session, ManagedCookiesSession):
                session.cookies.clear()


def _request_with_retries(session: requests.Session, data: dict[str, Any], retries: int) -> requests.Response:
    # Retry transient network failures with exponential backoff capped at 10s.
    attempt = 0
    while True:
        try:
            return session.request(**data)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            if attempt >= retries:
                raise
            time.sleep(min(2**attempt, 10))
            attempt += 1


def validate_vanilla_requests_kwargs(data: dict[str, Any], declared_base_url: str | None = None) -> None:
    """Check arguments for `requests.Session.request`.

    Some arguments can be valid for cases like ASGI integration, but at the same time they won't work for the regular
    `requests` calls. In such cases we need to avoid an obscure error message, that comes from `requests`.
    """
    url = data["url"]
    if not urlparse(url).netloc:
        stack = inspect.stack()
        method_name = "call"
        for frame in stack[1:]:
            if frame.function == "call_and_validate":
                method_name = "call_and_validate"
                break
        if declared_base_url is not None:
            suggestion = f"Your schema declares a server at {declared_base_url}:\n"
        else:
            suggestion = ""
        example = declared_base_url or "https://api.example.com"
        raise IncorrectUsage(
            "The `base_url` argument is required when specifying a schema via a file, so Schemathesis knows where to send the data.\n"
            f"{suggestion}"
            f'    schema.config.update(base_url="{example}")\n'
            f"You can also pass `base_url` to `Case.{method_name}`.\n"
            f"If you use the ASGI integration, please supply your test client "
            f"as the `session` argument to `call`.\nURL: {url}"
        )


REQUESTS_TRANSPORT = RequestsTransport()


@REQUESTS_TRANSPORT.serializer("application/json", "text/json")
def json_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    return serialize_json(value)


@REQUESTS_TRANSPORT.serializer(
    "text/yaml", "text/x-yaml", "text/vnd.yaml", "text/yml", "application/yaml", "application/x-yaml"
)
def yaml_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    return serialize_yaml(value)


def _should_coerce_to_bytes(item: object) -> bool:
    """Whether the item should be converted to bytes."""
    # These types are OK in forms, others should be coerced to bytes
    return isinstance(item, Binary) or not isinstance(item, (bytes | str | int))


def _prepare_form_data(data: dict[str, Any]) -> dict[str, Any]:
    """Make the generated data suitable for sending as multipart.

    If the schema is loose, Schemathesis can generate data that can't be sent as multipart. In these cases,
    we convert it to bytes and send it as-is, ignoring any conversion errors.

    NOTE. This behavior might change in the future.
    """
    for name, value in data.items():
        if isinstance(value, list):
            data[name] = [serialize_binary(item) if _should_coerce_to_bytes(item) else item for item in value]
        elif _should_coerce_to_bytes(value):
            data[name] = serialize_binary(value)
    return data


def choose_boundary() -> str:
    """Random boundary name."""
    return binascii.hexlify(os.urandom(16)).decode("ascii")


def _encode_multipart(value: Any, boundary: str) -> bytes:
    """Encode any value as multipart.

    NOTE. It doesn't aim to be 100% correct multipart payload, but rather a way to send data which is not intended to
    be used as multipart, in cases when the API schema dictates so.
    """
    # For such cases we stringify the value and wrap it to a randomly-generated boundary
    body = BytesIO()
    body.write(f"--{boundary}\r\n".encode())
    body.write(str(value).encode())
    body.write(f"--{boundary}--\r\n".encode("latin-1"))
    return body.getvalue()


def _is_structured_schema(schema: dict[str, Any]) -> bool:
    # Arrays of binary parts (e.g. `items.format: binary`) are file uploads, not JSON payloads.
    items = schema.get("items")
    if isinstance(items, dict) and items.get("format") in {"binary", "base64"}:
        return False
    declared = schema.get("type")
    if isinstance(declared, str):
        return declared in {"object", "array"}
    if isinstance(declared, list):
        return any(t in {"object", "array"} for t in declared)
    return "properties" in schema or "items" in schema or "additionalProperties" in schema


def _collect_encoded_fields(ctx: SerializationContext) -> dict[str, str]:
    """Return multipart field names mapped to the content-type declared via `encoding`."""
    operation = ctx.case.operation
    selected = ctx.case.multipart_content_types or {}
    result: dict[str, str] = {}
    for body in operation.body:
        main, sub = media_types.parse(body.media_type)
        if main not in ("*", "multipart") or sub not in ("*", "form-data", "mixed"):
            continue
        for name in body.definition.get("encoding", {}):
            content_type = selected.get(name) or body.get_property_content_type(name)
            if isinstance(content_type, str):
                result[name] = content_type
        # Default nested-object / array form-parts to JSON so the wire payload is parsable.
        schema_node = body.definition.get("schema")
        if isinstance(schema_node, dict):
            properties = schema_node.get("properties")
            if isinstance(properties, dict):
                for name, prop in properties.items():
                    if name in result or not isinstance(prop, dict):
                        continue
                    # Resolve a property-level `$ref` against the body schema's bundle so
                    # a referent like `{type: string}` is left alone and `{type: object}` triggers JSON.
                    spliced = cast("dict[str, Any]", schema_with_bundle(prop, schema_node))
                    if _is_structured_schema(maybe_resolve_bundled(spliced)):
                        result[name] = "application/json"
        break
    return result


def _is_already_serialized(value: object) -> bool:
    """Whether the value is already in a form that can be sent as a multipart part."""
    if isinstance(value, (bytes, str, Binary)):
        return True
    if isinstance(value, list):
        return all(isinstance(item, (bytes, str, Binary)) for item in value)
    return False


def _serialize_part_value(ctx: SerializationContext, value: Any, content_type: str) -> Any:
    """Serialize a multipart field value using the registered serializer for its content-type."""
    if _is_already_serialized(value):
        return value
    pair = REQUESTS_TRANSPORT.get_first_matching_media_type(content_type)
    if pair is None:
        raise SerializationNotPossible.for_media_type(content_type)
    _, serializer = pair
    result = serializer(ctx, value)
    if "data" in result:
        return result["data"]
    if "json" in result:
        return json.dumps(result["json"]).encode()
    return value


@REQUESTS_TRANSPORT.serializer("multipart/form-data", "multipart/mixed")
def multipart_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    if isinstance(value, bytes):
        return {"data": value}
    if isinstance(value, dict):
        encoded_fields = _collect_encoded_fields(ctx)
        for name, content_type in encoded_fields.items():
            if name in value:
                value[name] = _serialize_part_value(ctx, value[name], content_type)
        multipart = _prepare_form_data(value)
        # Surface auto-discovered per-part content types on the wire; case-level overrides still win.
        selected = {**encoded_fields, **(ctx.case.multipart_content_types or {})}
        files, data = ctx.case.operation.prepare_multipart(multipart, selected)
        return {"files": files, "data": data}
    # Uncommon schema. For example - `{"type": "string"}`
    boundary = choose_boundary()
    raw_data = _encode_multipart(value, boundary)
    content_type = f"multipart/form-data; boundary={boundary}"
    return {"data": raw_data, "headers": {"Content-Type": content_type}}


@REQUESTS_TRANSPORT.serializer("application/xml", "text/xml")
def xml_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    return serialize_xml(ctx.case, value)


@REQUESTS_TRANSPORT.serializer("application/x-www-form-urlencoded")
def urlencoded_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    if value is None or isinstance(value, (Mapping, str, bytes)):
        return {"data": value}
    # Out-of-spec non-object bodies (e.g. top-level arrays) ship as JSON-encoded bytes
    # so the request still reaches the server instead of aborting locally.
    return {"data": json.dumps(value).encode("utf-8")}


@REQUESTS_TRANSPORT.serializer("text/plain")
def text_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    if isinstance(value, bytes):
        return {"data": value}
    return {"data": str(value).encode("utf8")}


@REQUESTS_TRANSPORT.serializer("application/octet-stream")
def binary_serializer(ctx: SerializationContext, value: Body) -> dict[str, Any]:
    return {"data": serialize_binary(value)}
