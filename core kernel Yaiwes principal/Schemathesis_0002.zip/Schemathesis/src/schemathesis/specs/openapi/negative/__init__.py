from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from functools import lru_cache
from typing import TYPE_CHECKING, Any
from urllib.parse import urlencode

import jsonschema_rs
from hypothesis import strategies as st
from hypothesis.errors import InvalidArgument

from schemathesis.config import GenerationConfig
from schemathesis.core.errors import InvalidSchema
from schemathesis.core.jsonschema import (
    ALL_KEYWORDS,
    CANONICALIZE_DRAFT_BY_VALIDATOR,
    DRAFT4_SUPPLEMENTAL_FORMATS,
    FANCY_REGEX_OPTIONS,
)
from schemathesis.core.jsonschema.types import JsonSchema, JsonSchemaObject
from schemathesis.core.media_types import is_json
from schemathesis.core.mutations import OperatorKind
from schemathesis.core.parameters import ParameterLocation
from schemathesis.generation.jsonschema import build
from schemathesis.generation.jsonschema.context import Alphabet
from schemathesis.generation.value import GeneratedValue
from schemathesis.specs.openapi.adapter.parameters import _constant_values_at_draws, _prune_modified_constants
from schemathesis.specs.openapi.formats import HEADER_FORMAT, header_alphabet
from schemathesis.specs.openapi.negative.mutations import (
    Mutation,
    MutationChannel,
    MutationContext,
    MutationMetadata,
    MutationTargetDescriptor,
    compute_mutation_targets,
    metadata_with_description_override,
)
from schemathesis.specs.openapi.negative.value_channel import apply_value_channel, collect_value_targets
from schemathesis.transport.serialization import Binary, contains_binary

SYNTAX_FUZZING_PROBABILITY = 0.05
VALUE_CHANNEL_PROBABILITY = 0.15

if TYPE_CHECKING:
    from schemathesis.specs.openapi.negative.types import Draw, Schema


def _is_not_valid_json(data: bytes) -> bool:
    """Check if bytes are NOT valid JSON."""
    try:
        json.loads(data)
        return False  # Valid JSON, reject
    except (json.JSONDecodeError, UnicodeDecodeError):
        return True  # Invalid, keep


def _random_non_json_bytes() -> st.SearchStrategy[bytes]:
    """Generate random bytes that are NOT valid JSON.

    Used for syntax-level fuzzing of JSON endpoints.
    """
    return st.binary(min_size=1, max_size=1024).filter(_is_not_valid_json)


def wrap_filter_hook_for_generated_value(hook: Callable) -> Callable:
    """Adapter so user-supplied filter hooks see plain values when negative-mode wraps them.

    The boolean result is returned directly so `strategy.filter()` can evaluate truthiness;
    re-wrapping in `GeneratedValue` would make every result truthy and break filtering.
    """

    def wrapper(value: Any) -> bool:
        if isinstance(value, GeneratedValue):
            return hook(value.value)
        return hook(value)

    return wrapper


def wrap_map_hook_for_generated_value(hook: Callable, *, prune_constants: bool = True) -> Callable:
    """Adapter so user-supplied map hooks see plain values when negative-mode wraps them."""

    def wrapper(value: Any) -> Any:
        if isinstance(value, GeneratedValue):
            previous_constants = _constant_values_at_draws(value.constants_draws, value.value)
            result = hook(value.value)
            return GeneratedValue(
                value=result,
                meta=value.meta,
                pool_draws=value.pool_draws,
                semantic_draws=value.semantic_draws,
                dictionary_draws=value.dictionary_draws,
                constants_draws=(
                    _prune_modified_constants(value.constants_draws, previous_constants, result)
                    if prune_constants
                    else value.constants_draws
                ),
            )
        return hook(value)

    return wrapper


def wrap_flatmap_hook_for_generated_value(hook: Callable) -> Callable:
    """Adapter so user-supplied flatmap hooks see plain values when negative-mode wraps them.

    Unlike map hooks, flatmap hooks return a `SearchStrategy` — not a value. We unwrap
    `GeneratedValue` before invoking the hook, then re-wrap each drawn result so the
    `GeneratedValue` metadata is preserved through the flatmap.
    """

    def wrapper(value: Any) -> st.SearchStrategy:
        if isinstance(value, GeneratedValue):
            meta = value.meta
            pool_draws = value.pool_draws
            semantic_draws = value.semantic_draws
            dictionary_draws = value.dictionary_draws
            constants_draws = value.constants_draws
            previous_constants = _constant_values_at_draws(constants_draws, value.value)
            return hook(value.value).map(
                lambda v: GeneratedValue(
                    value=v,
                    meta=meta,
                    pool_draws=pool_draws,
                    semantic_draws=semantic_draws,
                    dictionary_draws=dictionary_draws,
                    constants_draws=_prune_modified_constants(constants_draws, previous_constants, v),
                )
            )
        return hook(value)

    return wrapper


@dataclass(slots=True)
class CacheKey:
    """A cache key for API Operation / location.

    Carries the schema around but don't use it for hashing to simplify LRU cache usage.
    """

    operation_name: str
    location: str
    schema: JsonSchema
    validator_cls: type[jsonschema_rs.Validator]
    custom_format_names: frozenset[str]

    def __hash__(self) -> int:
        return hash((self.operation_name, self.location, self.custom_format_names))


def _always_invalid(value: object) -> bool:
    """A format check that always fails."""
    return False


# Formats that should always be treated as invalid for negative testing.
# These are OpenAPI-specific formats that jsonschema-rs doesn't validate,
# so without this, any value would pass validation and get filtered out.
_ALWAYS_INVALID_FORMATS = frozenset({"binary", "byte"})


def _is_unconstrained_binary_schema(schema: JsonSchema) -> bool:
    """Check if schema is an unconstrained binary/byte format that accepts any value.

    A schema like {"format": "binary"} without a type constraint accepts any JSON value,
    since JSON Schema format validation only applies to strings. For such schemas, we can't
    meaningfully filter generated values because everything matches.
    """
    if not isinstance(schema, dict):
        return False
    # Has binary/byte format but no type constraint
    return schema.get("format") in _ALWAYS_INVALID_FORMATS and "type" not in schema


@lru_cache
def get_validator(cache_key: CacheKey) -> jsonschema_rs.Validator:
    """Hook custom formats to always-fail (enables format-violating fuzzing); skip `binary`/`byte` (runtime is permissive)."""
    formats: dict[str, Any] = {}
    if cache_key.validator_cls is jsonschema_rs.Draft4Validator:
        formats.update(DRAFT4_SUPPLEMENTAL_FORMATS)
    formats.update(dict.fromkeys(cache_key.custom_format_names - _ALWAYS_INVALID_FORMATS, _always_invalid))
    return cache_key.validator_cls(
        cache_key.schema,
        formats=formats,
        validate_formats=True,
        pattern_options=FANCY_REGEX_OPTIONS,
    )


def _negates_format(metadata: MutationMetadata) -> bool:
    return any("format" in mutation.keywords for mutation in metadata.mutations)


@lru_cache
def get_real_validator(cache_key: CacheKey) -> jsonschema_rs.Validator:
    """A validator without the always-invalid format hook.

    The schema-channel `filter_values` validator artificially fails any custom
    format so format-violating mutations are recognized as invalid. The value
    channel applies known violators (e.g. `violate_email`) and only needs to
    confirm the resulting body is genuinely invalid against the original schema —
    so it must not treat a still-valid sibling format as a violation.
    """
    formats: dict[str, Any] = {}
    if cache_key.validator_cls is jsonschema_rs.Draft4Validator:
        formats.update(DRAFT4_SUPPLEMENTAL_FORMATS)
    return cache_key.validator_cls(
        cache_key.schema,
        formats=formats,
        validate_formats=True,
        pattern_options=FANCY_REGEX_OPTIONS,
    )


@lru_cache
def split_schema(cache_key: CacheKey) -> tuple[Schema, Schema]:
    """Split the schema in two parts.

    The first one contains only validation JSON Schema keywords, the second one everything else.
    """
    keywords, non_keywords = {}, {}
    schema = {} if isinstance(cache_key.schema, bool) else cache_key.schema
    for keyword, value in schema.items():
        if keyword in ALL_KEYWORDS:
            keywords[keyword] = value
        else:
            non_keywords[keyword] = value
    return keywords, non_keywords


def _strip_binary(value: Any) -> Any:
    # Replace Binary with "" so jsonschema_rs can validate structure; format:binary is annotation-only,
    # so "" passes the format check while required/additionalProperties/sibling constraints still fire.
    if isinstance(value, Binary):
        return ""
    if isinstance(value, dict):
        return {k: _strip_binary(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_strip_binary(v) for v in value]
    return value


def negative_schema(
    schema: JsonSchema,
    operation_name: str,
    location: ParameterLocation,
    media_type: str | None,
    generation_config: GenerationConfig,
    *,
    custom_formats: dict[str, st.SearchStrategy[str]],
    validator_cls: type[jsonschema_rs.Validator],
    validation_schema: JsonSchema | None = None,
    name_to_uri: dict[str, str] | None = None,
    target_descriptors: tuple[MutationTargetDescriptor, ...] | None = None,
) -> st.SearchStrategy:
    """A strategy for instances that DO NOT match the input schema.

    It is used to cover the input space that is not possible to cover with the "positive" strategy.

    Returns a strategy that produces GeneratedValue instances with mutation metadata.

    `validation_schema`, when provided, keeps `prefixItems` intact and is used only to build the
    runtime validator; falls back to `schema`.
    """
    # The mutated schema is passed to `from_schema` and guarded against producing instances valid against
    # the original schema.
    cache_key = CacheKey(operation_name, location, schema, validator_cls, frozenset(custom_formats))
    # Build the validator from the form with `prefixItems` intact so meta-validation accepts it.
    validator_cache_key = (
        cache_key
        if validation_schema is None or validation_schema is schema
        else CacheKey(operation_name, location, validation_schema, validator_cls, frozenset(custom_formats))
    )
    validator = get_validator(validator_cache_key)
    keywords, non_keywords = split_schema(cache_key)

    # For unconstrained binary/byte schemas, skip the validation filter entirely.
    # Such schemas accept any value (no type constraint + format only applies to strings),
    # so we can't meaningfully filter generated values.
    skip_validation_filter = _is_unconstrained_binary_schema(schema)

    if location == ParameterLocation.QUERY:

        def filter_values(value: Any, validator: jsonschema_rs.Validator) -> bool:
            return is_non_empty_query(value) and (
                skip_validation_filter or contains_binary(value) or not validator.is_valid(value)
            )

    else:

        def filter_values(value: Any, validator: jsonschema_rs.Validator) -> bool:
            return skip_validation_filter or contains_binary(value) or not validator.is_valid(value)

    if location.is_in_header:
        # Header names and values answer to the same character rules whoever asks for them.
        alphabet = header_alphabet(generation_config)
        custom_formats = {name: strategy for name, strategy in custom_formats.items() if name != HEADER_FORMAT}
    else:
        alphabet = Alphabet(allow_x00=generation_config.allow_x00, codec=generation_config.codec)

    def generate_value_with_metadata(value: tuple[dict, MutationMetadata]) -> st.SearchStrategy:
        schema, metadata = value
        strategy = build(
            schema, draft=CANONICALIZE_DRAFT_BY_VALIDATOR[validator_cls], formats=custom_formats, alphabet=alphabet
        )
        # Failing every format on principle only speaks for a negated `format`; elsewhere it hides
        # that the mutation left the value conforming.
        chosen = validator if _negates_format(metadata) else get_real_validator(validator_cache_key)
        return strategy.filter(lambda value: filter_values(value, chosen)).map(
            lambda value: GeneratedValue(value, metadata)
        )

    if target_descriptors is None:
        target_descriptors = compute_mutation_targets(schema)

    mutated_strategy = mutated(
        keywords=keywords,
        non_keywords=non_keywords,
        location=location,
        media_type=media_type,
        allow_extra_parameters=generation_config.allow_extra_parameters,
        name_to_uri=name_to_uri,
        target_descriptors=target_descriptors,
    ).flatmap(generate_value_with_metadata)

    positive_strategy: st.SearchStrategy | None = None
    if location == ParameterLocation.BODY:
        try:
            _candidate = build(
                schema, draft=CANONICALIZE_DRAFT_BY_VALIDATOR[validator_cls], formats=custom_formats, alphabet=alphabet
            )
            _candidate.validate()
        except (InvalidArgument, InvalidSchema):
            pass
        else:
            if not _candidate.is_empty:
                positive_strategy = _candidate
    if positive_strategy is not None:
        body_schema: JsonSchemaObject = schema if isinstance(schema, dict) else {}
        inner_mutated_strategy = mutated_strategy
        # Use the real-format validator here: `filter_values` artificially fails
        # custom formats, so a permissive sibling target (e.g. `minLength: 0`)
        # alongside a format-bearing field would let an unchanged-but-valid body
        # slip through as negative data.
        real_validator = get_real_validator(validator_cache_key)

        @st.composite  # type: ignore[untyped-decorator]
        def hybrid(draw: Any) -> GeneratedValue:
            random = draw(st.randoms())
            if random.random() < VALUE_CHANNEL_PROBABILITY:
                positive = draw(positive_strategy)
                targets = collect_value_targets(positive, body_schema)
                if not targets:
                    return draw(inner_mutated_strategy)
                target_path, schema_pointer, _value, keyword, schema_at_path = draw(st.sampled_from(targets))
                new_body, original_value, new_value = apply_value_channel(
                    positive, target_path, keyword, schema_at_path
                )
                # Violators are no-ops on permissive schemas; fall back to schema-channel to avoid
                # false-positive `negative_data_rejection`. Strip Binary to "" before validating —
                # jsonschema_rs rejects the wrapper but structure-level keywords still fire.
                body_for_validation = _strip_binary(new_body) if contains_binary(new_body) else new_body
                if real_validator.is_valid(body_for_validation):
                    return draw(inner_mutated_strategy)
                mutation = Mutation(
                    path=target_path,
                    schema_pointer=schema_pointer,
                    channel=MutationChannel.VALUE,
                    operator=OperatorKind.VALUE_VIOLATOR,
                    keywords=(keyword,),
                    parameter=str(target_path[-1]) if target_path else None,
                    original_value=original_value,
                    new_value=new_value,
                )
                return GeneratedValue(new_body, MutationMetadata(mutations=(mutation,)))
            return draw(inner_mutated_strategy)

        mutated_strategy = hybrid()

    # For JSON bodies, add syntax-level fuzzing with random bytes (~5% of cases)
    if location == ParameterLocation.BODY and media_type is not None and is_json(media_type):
        syntax_fuzzing_strategy = _random_non_json_bytes().map(
            lambda b: GeneratedValue(
                b,
                metadata_with_description_override(
                    operator=OperatorKind.SYNTAX_FUZZING,
                    parameter=None,
                    description="Invalid syntax: random bytes",
                    location=None,
                ),
            )
        )

        @st.composite  # type: ignore[untyped-decorator]
        def with_syntax_fuzzing(draw: Any) -> GeneratedValue:
            random = draw(st.randoms())
            if random.random() < SYNTAX_FUZZING_PROBABILITY:
                return draw(syntax_fuzzing_strategy)
            return draw(mutated_strategy)

        return with_syntax_fuzzing()

    return mutated_strategy


def is_non_empty_query(query: dict[str, Any]) -> bool:
    # Whether this query parameters will be encoded to a non-empty query string
    result = []
    for key, values in query.items():
        if isinstance(values, str) or not hasattr(values, "__iter__"):
            values = [values]
        for value in values:
            if value is not None:
                result.append(
                    (
                        key.encode("utf-8") if isinstance(key, str) else key,
                        value.encode("utf-8") if isinstance(value, str) else value,
                    )
                )
    return urlencode(result, doseq=True) != ""


@st.composite  # type: ignore[untyped-decorator]
def mutated(
    draw: Draw,
    *,
    keywords: Schema,
    non_keywords: Schema,
    location: ParameterLocation,
    media_type: str | None,
    allow_extra_parameters: bool,
    name_to_uri: dict[str, str] | None = None,
    target_descriptors: tuple[MutationTargetDescriptor, ...],
) -> Any:
    return MutationContext(
        keywords=keywords,
        non_keywords=non_keywords,
        location=location,
        media_type=media_type,
        allow_extra_parameters=allow_extra_parameters,
        name_to_uri=name_to_uri,
        target_descriptors=target_descriptors,
    ).mutate(draw)
