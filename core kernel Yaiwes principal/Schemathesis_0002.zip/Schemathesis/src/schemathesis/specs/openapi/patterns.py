from __future__ import annotations

import re
import sys
from collections.abc import Callable
from functools import lru_cache
from typing import Any, Literal, TypeAlias, TypeGuard

import jsonschema_rs

from schemathesis.core.errors import InternalError
from schemathesis.core.jsonschema import FANCY_REGEX_OPTIONS

# Unicode property escape translations (PCRE/Java/JS -> Python approximations)
# These cover Latin-based scripts which handle the majority of real-world APIs
_LETTER_CLASS = r"a-zA-Z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u024F"
_LETTER_UPPER_CLASS = r"A-Z\u00C0-\u00D6\u00D8-\u00DE\u0100-\u0136\u0139-\u0147\u014A-\u0178\u0179-\u017D"
_LETTER_LOWER_CLASS = r"a-z\u00DF-\u00F6\u00F8-\u00FF\u0101-\u0137\u013A-\u0148\u014B-\u0177\u017A-\u017E"
_OTHER_LETTER_CLASS = r"\u00AA\u00BA\u01BB\u01C0-\u01C3\u0294"
_DIGIT_CLASS = r"0-9"
_ALNUM_CLASS = rf"{_LETTER_CLASS}{_DIGIT_CLASS}"
_SPACE_CLASS = r" \t\n\r\f\v"
_XDIGIT_CLASS = r"0-9A-Fa-f"
_ASCII_CLASS = r"\x00-\x7F"
# Punctuation: ASCII + Latin-1 Supplement + General Punctuation
_PUNCT_CLASS = r"!\"#%&'()*,\-./:;?@\[\\\]_{}\u00A1\u00A7\u00AB\u00B6\u00B7\u00BB\u00BF\u2010-\u2027\u2030-\u203E"
# Combining marks (common diacritical marks)
_MARK_CLASS = r"\u0300-\u036F\u0483-\u0489\u1DC0-\u1DFF\u20D0-\u20FF"
# Symbols: currency, math, misc symbols
_SYMBOL_CLASS = r"$+<=>^`|~\u00A2-\u00A6\u00A8\u00A9\u00AC\u00AE-\u00B1\u00B4\u00D7\u00F7\u2200-\u22FF\u2600-\u26FF"
# Control characters
_CONTROL_CLASS = r"\x00-\x1F\x7F-\x9F"
# Graph (visible characters) and Print (graph + space)
_GRAPH_CLASS = r"!-~\u00A1-\u00AC\u00AE-\u00FF"
_PRINT_CLASS = rf" {_GRAPH_CLASS}"
# Blank (horizontal whitespace)
_BLANK_CLASS = r" \t"
# Scripts, kept to the blocks the validating engine agrees are part of them
_HAN_CLASS = (
    r"\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u3005\u3007\u3021-\u3029\u3038-\u303B"
    r"\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFA6D\uFA70-\uFAD9"
)
_GREEK_CLASS = (
    r"\u0370-\u0373\u0375-\u0377\u037A-\u037D\u0384\u0386\u0388-\u038A\u038C\u038E-\u03A1"
    r"\u03A3-\u03E1\u03F0-\u03FF\u1F00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45"
)
_CYRILLIC_CLASS = r"\u0400-\u0481\u048A-\u052F\u1C80-\u1C88\u2DE0-\u2DFF\uA640-\uA69F"
_HIRAGANA_CLASS = r"\u3041-\u3096\u309D-\u309F"
_KATAKANA_CLASS = r"\u30A1-\u30FA\u30FD-\u30FF\u31F0-\u31FF\uFF66-\uFF6F\uFF71-\uFF9D"
_HANGUL_CLASS = (
    r"\u1100-\u11FF\u3131-\u318E\uA960-\uA97C\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB"
    r"\uFFA0-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC"
)

# Escapes standing on their own; the ones inside a class are inlined before these run.
_UNICODE_PROPERTY_MAP = (
    (r"\p{L}", f"[{_LETTER_CLASS}]"),
    (r"\p{Lu}", f"[{_LETTER_UPPER_CLASS}]"),
    (r"\p{Ll}", f"[{_LETTER_LOWER_CLASS}]"),
    (r"\p{Lo}", f"[{_OTHER_LETTER_CLASS}]"),
    (r"\p{N}", f"[{_DIGIT_CLASS}]"),
    (r"\p{Nd}", f"[{_DIGIT_CLASS}]"),
    (r"\p{Alpha}", f"[{_LETTER_CLASS}]"),
    (r"\p{Digit}", f"[{_DIGIT_CLASS}]"),
    (r"\p{XDigit}", f"[{_XDIGIT_CLASS}]"),
    (r"\p{Alnum}", f"[{_ALNUM_CLASS}]"),
    (r"\p{Space}", f"[{_SPACE_CLASS}]"),
    (r"\p{Z}", f"[{_SPACE_CLASS}]"),
    (r"\p{Zs}", f"[{_SPACE_CLASS}]"),
    (r"\p{P}", f"[{_PUNCT_CLASS}]"),
    (r"\p{Punct}", f"[{_PUNCT_CLASS}]"),
    (r"\p{M}", f"[{_MARK_CLASS}]"),
    (r"\p{S}", f"[{_SYMBOL_CLASS}]"),
    (r"\p{C}", f"[{_CONTROL_CLASS}]"),
    (r"\p{Cntrl}", f"[{_CONTROL_CLASS}]"),
    (r"\p{ASCII}", f"[{_ASCII_CLASS}]"),
    (r"\p{Graph}", f"[{_GRAPH_CLASS}]"),
    (r"\p{Print}", f"[{_PRINT_CLASS}]"),
    (r"\p{Blank}", f"[{_BLANK_CLASS}]"),
    (r"\p{Upper}", f"[{_LETTER_UPPER_CLASS}]"),
    (r"\p{IsLetter}", f"[{_LETTER_CLASS}]"),
    (r"\p{Greek}", f"[{_GREEK_CLASS}]"),
    (r"\p{Cyrillic}", f"[{_CYRILLIC_CLASS}]"),
    (r"\p{Han}", f"[{_HAN_CLASS}]"),
    (r"\p{Hiragana}", f"[{_HIRAGANA_CLASS}]"),
    (r"\p{Katakana}", f"[{_KATAKANA_CLASS}]"),
    (r"\p{Hangul}", f"[{_HANGUL_CLASS}]"),
    (r"\P{L}", f"[^{_LETTER_CLASS}]"),
    (r"\P{N}", f"[^{_DIGIT_CLASS}]"),
    (r"\P{Nd}", f"[^{_DIGIT_CLASS}]"),
    (r"\P{C}", f"[^{_CONTROL_CLASS}]"),
    (r"\P{M}", f"[^{_MARK_CLASS}]"),
    # Shorthand standalone forms (single-letter properties without braces)
    (r"\pL", f"[{_LETTER_CLASS}]"),
    (r"\pN", f"[{_DIGIT_CLASS}]"),
    (r"\pP", f"[{_PUNCT_CLASS}]"),
    (r"\pM", f"[{_MARK_CLASS}]"),
    (r"\pS", f"[{_SYMBOL_CLASS}]"),
    (r"\pC", f"[{_CONTROL_CLASS}]"),
    (r"\pZ", f"[{_SPACE_CLASS}]"),
    (r"\PL", f"[^{_LETTER_CLASS}]"),
    (r"\PN", f"[^{_DIGIT_CLASS}]"),
    (r"\PC", f"[^{_CONTROL_CLASS}]"),
    (r"\PM", f"[^{_MARK_CLASS}]"),
)

# Raw class contents (no surrounding brackets) used when `\p{X}` is nested inside a character class.
_UNICODE_PROPERTY_RAW_MAP: dict[str, str] = {
    "L": _LETTER_CLASS,
    "Lu": _LETTER_UPPER_CLASS,
    "Ll": _LETTER_LOWER_CLASS,
    "Lo": _OTHER_LETTER_CLASS,
    "N": _DIGIT_CLASS,
    "Nd": _DIGIT_CLASS,
    "Alpha": _LETTER_CLASS,
    "Digit": _DIGIT_CLASS,
    "XDigit": _XDIGIT_CLASS,
    "Alnum": _ALNUM_CLASS,
    "Space": _SPACE_CLASS,
    "Z": _SPACE_CLASS,
    "Zs": _SPACE_CLASS,
    "P": _PUNCT_CLASS,
    "Punct": _PUNCT_CLASS,
    "M": _MARK_CLASS,
    "S": _SYMBOL_CLASS,
    "C": _CONTROL_CLASS,
    "Cntrl": _CONTROL_CLASS,
    "ASCII": _ASCII_CLASS,
    "Graph": _GRAPH_CLASS,
    "Print": _PRINT_CLASS,
    "Blank": _BLANK_CLASS,
    "Upper": _LETTER_UPPER_CLASS,
    "IsLetter": _LETTER_CLASS,
    "Greek": _GREEK_CLASS,
    "Cyrillic": _CYRILLIC_CLASS,
    "Han": _HAN_CLASS,
    "Hiragana": _HIRAGANA_CLASS,
    "Katakana": _KATAKANA_CLASS,
    "Hangul": _HANGUL_CLASS,
}
# Script classes are the blocks the validating engine agrees are part of a script, not the whole of
# it, so complementing one would admit characters the script still claims.
_PARTIAL_SCRIPT_CLASSES = frozenset({"Greek", "Cyrillic", "Han", "Hiragana", "Katakana", "Hangul"})
# Single-letter shorthand (`\pL`, `\pN`, ...) raw equivalents.
_UNICODE_SHORTHAND_RAW_MAP: dict[str, str] = {
    "L": _LETTER_CLASS,
    "N": _DIGIT_CLASS,
    "P": _PUNCT_CLASS,
    "M": _MARK_CLASS,
    "S": _SYMBOL_CLASS,
    "C": _CONTROL_CLASS,
    "Z": _SPACE_CLASS,
}

# POSIX character classes (only valid inside `[...]` in PCRE; Python's `re` misparses them
# and emits FutureWarning about possible nested sets).
_POSIX_CLASS_RAW_MAP: dict[str, str] = {
    "alpha": _LETTER_CLASS,
    "alnum": _ALNUM_CLASS,
    "digit": _DIGIT_CLASS,
    "upper": _LETTER_UPPER_CLASS,
    "lower": _LETTER_LOWER_CLASS,
    "space": _SPACE_CLASS,
    "xdigit": _XDIGIT_CLASS,
    "print": _PRINT_CLASS,
    "graph": _GRAPH_CLASS,
    "punct": _PUNCT_CLASS,
    "cntrl": _CONTROL_CLASS,
    "blank": _BLANK_CLASS,
    "ascii": _ASCII_CLASS,
}


# `||` is absent here on purpose: the engine behind validation has no such operator, so the two
# characters name a literal `|` and Python reads them the same way.
_PCRE_CLASS_SET_OPERATORS = ("&&", "~~")

_MAX_CODEPOINT = sys.maxunicode
_SURROGATES = (0xD800, 0xDFFF)

_Interval: TypeAlias = tuple[int, int]


def _merged(intervals: list[_Interval]) -> list[_Interval]:
    out: list[_Interval] = []
    for low, high in sorted(intervals):
        if out and low <= out[-1][1] + 1:
            out[-1] = (out[-1][0], max(out[-1][1], high))
        else:
            out.append((low, high))
    return out


def _complemented(intervals: list[_Interval]) -> list[_Interval]:
    # Surrogates join the set being complemented, so no gap can carry one: no JSON string holds them,
    # and Hypothesis turns them down as literals.
    out: list[_Interval] = []
    cursor = 0
    for low, high in _merged([*intervals, _SURROGATES]):
        if low > cursor:
            out.append((cursor, low - 1))
        cursor = max(cursor, high + 1)
    if cursor <= _MAX_CODEPOINT:
        out.append((cursor, _MAX_CODEPOINT))
    return out


def _intersected(left: list[_Interval], right: list[_Interval]) -> list[_Interval]:
    out: list[_Interval] = []
    for low, high in _merged(left):
        for other_low, other_high in _merged(right):
            start, end = max(low, other_low), min(high, other_high)
            if start <= end:
                out.append((start, end))
    return _merged(out)


def _symmetric_difference(left: list[_Interval], right: list[_Interval]) -> list[_Interval]:
    only_left = _intersected(left, _complemented(right))
    only_right = _intersected(right, _complemented(left))
    return _merged([*only_left, *only_right])


def _serialize_intervals(intervals: list[_Interval]) -> str:
    return "".join(_serialize_range(low, high) for low, high in _merged(intervals))


def _complement_class(raw: str) -> str:
    """Raw class contents admitting every codepoint `raw` turns down."""
    intervals = _class_intervals(f"[{raw}]")
    # Every class this is called with is spelled as literals and ranges, so it reads back as one set.
    assert intervals is not None, raw
    return _serialize_intervals(_complemented(intervals))


def _class_intervals(cls: str) -> list[_Interval] | None:
    """The codepoints a flat `[...]` admits, or `None` when it names something beyond literals and ranges."""
    parsed = _parse_regex(cls)
    if parsed is None or len(parsed) != 1:
        return None
    op, value = parsed[0]
    # A one-member class is optimized down to the member itself.
    if op == LITERAL:
        return [(value, value)]
    if op != sre.IN:
        return None
    items = list(value)
    negated = bool(items) and items[0][0] == sre.NEGATE
    intervals: list[_Interval] = []
    for item_op, item_value in items[1:] if negated else items:
        if item_op == LITERAL:
            intervals.append((item_value, item_value))
        elif item_op == sre.RANGE:
            intervals.append(item_value)
        else:
            return None
    return _complemented(intervals) if negated else _merged(intervals)


def _serialize_range(low: int, high: int) -> str:
    if low == high:
        return _serialize_literal_in_class(low)
    return f"{_serialize_literal_in_class(low)}-{_serialize_literal_in_class(high)}"


def _class_extent(pattern: str, start: int) -> int | None:
    """Index just past the `]` closing the class opened at `start`, or `None` when it never closes."""
    i = start + 1
    if pattern[i : i + 1] == "^":
        i += 1
    # A `]` opening the contents is a member, not the close.
    if pattern[i : i + 1] == "]":
        i += 1
    depth = 0
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch == "\\":
            i += 2
            continue
        if ch == "[":
            if pattern[i + 1 : i + 2] == ":":
                end = pattern.find(":]", i + 2)
                if end == -1:
                    return None
                i = end + 2
                continue
            depth += 1
        elif ch == "]":
            if depth == 0:
                return i + 1
            depth -= 1
        i += 1
    return None


def _has_set_algebra(body: str) -> bool:
    """Whether the class body leans on constructs Python `re` reads differently, if at all."""
    i = 0
    n = len(body)
    while i < n:
        if body[i] == "\\":
            i += 2
            continue
        if body[i : i + 2] in _PCRE_CLASS_SET_OPERATORS:
            return True
        if body[i] == "[" and body[i + 1 : i + 2] != ":":
            return True
        i += 1
    return False


def _split_class_operands(body: str) -> tuple[list[str], list[str]]:
    """The class body cut at its set operators, and the operators themselves."""
    operands: list[str] = []
    operators: list[str] = []
    start = 0
    i = 0
    n = len(body)
    while i < n:
        ch = body[i]
        if ch == "\\":
            i += 2
            continue
        if ch == "[":
            end = body.find(":]", i + 2) + 2 if body[i + 1 : i + 2] == ":" else _class_extent(body, i)
            if end is None or end <= i:
                return [body], []
            i = end
            continue
        if body[i : i + 2] in _PCRE_CLASS_SET_OPERATORS:
            operands.append(body[start:i])
            operators.append(body[i : i + 2])
            i += 2
            start = i
            continue
        i += 1
    operands.append(body[start:])
    return operands, operators


def _operand_intervals(operand: str) -> list[_Interval] | None:
    """The codepoints one side of a set operator admits; its members add up."""
    intervals: list[_Interval] = []
    chunk: list[str] = []
    i = 0
    n = len(operand)
    while i < n:
        ch = operand[i]
        if ch == "\\":
            chunk.append(operand[i : i + 2])
            i += 2
            continue
        if ch == "[" and operand[i + 1 : i + 2] != ":":
            end = _class_extent(operand, i)
            if end is None:
                return None
            nested = _resolved_class(operand[i + 1 : end - 1])
            if nested is None:
                return None
            nested_intervals = _class_intervals(nested)
            if nested_intervals is None:
                return None
            intervals.extend(nested_intervals)
            i = end
            continue
        chunk.append(ch)
        i += 1
    if chunk:
        flat = _inline_unicode_in_classes(f"[{''.join(chunk)}]")
        if flat is None:
            return None
        own = _class_intervals(flat)
        if own is None:
            return None
        intervals.extend(own)
    return _merged(intervals)


def _resolved_class(body: str) -> str | None:
    """A class body with set operators and nested classes worked out, spelled as a flat `[...]`."""
    negated = body.startswith("^")
    if negated:
        body = body[1:]
    operands, operators = _split_class_operands(body)
    intervals = _operand_intervals(operands[0])
    if intervals is None:
        return None
    for operator, operand in zip(operators, operands[1:], strict=True):
        current = _operand_intervals(operand)
        if current is None:
            return None
        intervals = _intersected(intervals, current) if operator == "&&" else _symmetric_difference(intervals, current)
    if negated:
        intervals = _complemented(intervals)
    if not intervals:
        # Python has no spelling for a class admitting nothing.
        return None
    return f"[{_serialize_intervals(intervals)}]"


_BRACE_HEX_DIGITS = re.compile(r"[0-9A-Fa-f]{1,6}\Z")


def _inline_unicode_in_classes(pattern: str) -> str | None:
    r"""Inline `\p{X}`, `\P{X}` and `[:X:]` class contents inside `[...]`; bail out on `[:^X:]` (uncomposable)."""
    out: list[str] = []
    i = 0
    in_class = False
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch == "\\" and i + 1 < n:
            next_ch = pattern[i + 1]
            # `[^contents]` cannot compose with sibling class members, so the complement is spelled out.
            if in_class and next_ch == "P" and i + 2 < n and pattern[i + 2] == "{":
                end = pattern.find("}", i + 3)
                name = pattern[i + 3 : end] if end != -1 else ""
                raw = None if name in _PARTIAL_SCRIPT_CLASSES else _UNICODE_PROPERTY_RAW_MAP.get(name)
                # An unknown name, or one standing for part of a script, has nothing to turn inside out.
                if raw is None:
                    return None
                out.append(_complement_class(raw))
                i = end + 1
                continue
            if in_class and next_ch == "P":
                return None
            if in_class and next_ch == "p" and i + 2 < n:
                if pattern[i + 2] == "{":
                    end = pattern.find("}", i + 3)
                    if end != -1:
                        name = pattern[i + 3 : end]
                        raw = _UNICODE_PROPERTY_RAW_MAP.get(name)
                        if raw is not None:
                            out.append(raw)
                            i = end + 1
                            continue
                else:
                    raw = _UNICODE_SHORTHAND_RAW_MAP.get(pattern[i + 2])
                    if raw is not None:
                        out.append(raw)
                        i += 3
                        continue
            # `\x{...}` is how PCRE spells a codepoint; Python wants a fixed-width escape.
            if next_ch == "x" and pattern[i + 2 : i + 3] == "{":
                end = pattern.find("}", i + 3)
                digits = pattern[i + 3 : end] if end != -1 else ""
                if not _BRACE_HEX_DIGITS.match(digits):
                    return None
                code = int(digits, 16)
                if code > _MAX_CODEPOINT:
                    return None
                out.append(f"\\u{code:04x}" if code <= 0xFFFF else f"\\U{code:08x}")
                i = end + 1
                continue
            # Other escapes (`\[`, `\]`, `\\`, unknown `\p{Greek}`) pass through unchanged.
            out.append(pattern[i : i + 2])
            i += 2
            continue
        # PCRE/Java class-set operators have no Python `re` equivalent — silent translation
        # would change semantics (`||` becomes a literal `|`, `&&` a literal `&`, etc.).
        if in_class and pattern[i : i + 2] in _PCRE_CLASS_SET_OPERATORS:
            return None
        # A run of pipes names one literal `|` here, but Python reserves the spelling for a set
        # operator it does not have yet and warns about it.
        if in_class and ch == "|" and pattern[i + 1 : i + 2] == "|":
            while i < n and pattern[i] == "|":
                i += 1
            out.append("\\|")
            continue
        # POSIX character class `[:name:]` nested inside `[...]`.
        if in_class and ch == "[" and i + 1 < n and pattern[i + 1] == ":":
            end = pattern.find(":]", i + 2)
            if end != -1:
                inner = pattern[i + 2 : end]
                # Negated POSIX class `[:^X:]` cannot compose with sibling class members.
                if inner.startswith("^"):
                    return None
                raw = _POSIX_CLASS_RAW_MAP.get(inner)
                if raw is None:
                    # Unknown POSIX name (or not a POSIX class at all) - bail out.
                    return None
                out.append(raw)
                i = end + 2
                continue
        # Nested `[...]` inside an outer class is a PCRE/Java extension; Python `re` has no
        # equivalent and silently treats `[` as a literal, drifting from the source semantics.
        if in_class and ch == "[":
            return None
        if ch == "[" and not in_class:
            class_end = _class_extent(pattern, i)
            if class_end is not None and _has_set_algebra(pattern[i + 1 : class_end - 1]):
                resolved = _resolved_class(pattern[i + 1 : class_end - 1])
                if resolved is None:
                    return None
                out.append(resolved)
                i = class_end
                continue
            in_class = True
        elif ch == "]" and in_class:
            in_class = False
        out.append(ch)
        i += 1
    return "".join(out)


def _strip_group_names(pattern: str) -> str:
    """Named groups as plain ones, leaving lookbehind and literal text alone."""
    # Neither spelling of a name is read by every engine the pattern reaches, and a name carries no
    # constraint, so dropping it keeps the pattern where one spelling or the other would be refused.
    out: list[str] = []
    in_class = False
    i = 0
    n = len(pattern)
    while i < n:
        ch = pattern[i]
        if ch == "\\" and i + 1 < n:
            out.append(pattern[i : i + 2])
            i += 2
            continue
        if in_class:
            if ch == "]":
                in_class = False
        elif ch == "[":
            in_class = True
        elif ch == "(":
            name_start = -1
            if pattern.startswith("(?P<", i):
                name_start = i + 4
            # `(?<=` and `(?<!` open a lookbehind, which names no group.
            elif pattern.startswith("(?<", i) and pattern[i + 3 : i + 4] not in ("=", "!"):
                name_start = i + 3
            if name_start != -1:
                end = pattern.find(">", name_start)
                if end != -1:
                    out.append("(")
                    i = end + 1
                    continue
        out.append(ch)
        i += 1
    return "".join(out)


@lru_cache(maxsize=256)
def normalize_regex(pattern: object) -> str | None:
    r"""Translate PCRE-style Unicode property escapes and Python-specific anchors.

    Handles:
    - PCRE Unicode property escapes (\p{L}, \pL, etc.) -> Python equivalents
    - POSIX character classes ([:alnum:], [:digit:], etc.) -> Python equivalents
    - Python anchors (\A, \Z) -> Rust-compatible equivalents (^, $)
    - Named groups ((?<name>...), (?P<name>...)) -> plain groups

    Returns the translated pattern if successful, None if translation failed
    or the result is not a valid Python regex.
    """
    if not isinstance(pattern, str):
        return None
    stripped = _strip_group_names(pattern)
    has_named_group = stripped != pattern
    # Check for both braced (\p{L}) and shorthand (\pL) forms
    has_braced = r"\p{" in pattern or r"\P{" in pattern
    has_shorthand = any(
        esc in pattern
        for esc in (r"\pL", r"\pN", r"\pP", r"\pM", r"\pS", r"\pC", r"\pZ", r"\PL", r"\PN", r"\PC", r"\PM")
    )
    # Check for POSIX character classes like `[:alnum:]` (only valid inside `[...]`)
    has_posix = "[:" in pattern and ":]" in pattern
    # PCRE class-set operators and brace hex escapes, neither of which Python `re` reads
    has_class_algebra = any(operator in pattern for operator in _PCRE_CLASS_SET_OPERATORS)
    has_brace_hex = r"\x{" in pattern
    # Check for Python-specific anchors that need Rust translation
    has_python_anchors = pattern.startswith(r"\A") or pattern.endswith(r"\Z")

    if not any(
        (has_braced, has_shorthand, has_posix, has_python_anchors, has_class_algebra, has_brace_hex, has_named_group)
    ):
        return None  # No translation needed

    translated = _inline_unicode_in_classes(stripped)
    if translated is None:
        return None
    for pcre_escape, python_equiv in _UNICODE_PROPERTY_MAP:
        translated = translated.replace(pcre_escape, python_equiv)

    # Check if there are still untranslated Unicode property escapes
    if r"\p{" in translated or r"\P{" in translated:
        return None  # Contains unsupported escapes

    # Translate Python-specific anchors to Rust equivalents for jsonschema-rs
    if translated.startswith(r"\A"):
        translated = "^" + translated[2:]
    if translated.endswith(r"\Z"):
        translated = translated[:-2] + "$"

    # Verify the translated pattern is valid
    if is_valid_python_regex(translated):
        return translated
    return None


_POSIX_CLASS_RE = re.compile(r"\[\[:\^?[a-zA-Z]+:\]")


@lru_cache(maxsize=256)
def is_valid_jsonschema_rs_regex(pattern: str) -> bool:
    """Whether the engine behind validation and canonicalization can compile the pattern."""
    try:
        jsonschema_rs.Draft202012Validator({"pattern": pattern}, pattern_options=FANCY_REGEX_OPTIONS)
        return True
    except jsonschema_rs.ValidationError:
        return False


def is_valid_python_regex(pattern: object) -> TypeGuard[str]:
    """Check if a pattern is valid Python regex."""
    if not isinstance(pattern, str):
        return False
    # POSIX character classes nested inside `[...]` are misparsed by Python's `re` (it treats
    # `[:alnum:]` as the literal characters `:`, `a`, `l`, `n`, `u`, `m` and emits a FutureWarning).
    # Treat such patterns as invalid so callers route them through `normalize_regex`.
    if _POSIX_CLASS_RE.search(pattern):
        return False
    try:
        re.compile(pattern)
        return True
    except re.error:
        return False


try:  # pragma: no cover
    import re._constants as sre
    import re._parser as sre_parse
except ImportError:
    import sre_constants as sre
    import sre_parse

ANCHOR = sre.AT
REPEATS: tuple[int, ...]
POSSESSIVE_REPEATS: tuple[int, ...]
if hasattr(sre, "POSSESSIVE_REPEAT"):
    REPEATS = (sre.MIN_REPEAT, sre.MAX_REPEAT, sre.POSSESSIVE_REPEAT)
    POSSESSIVE_REPEATS = (sre.POSSESSIVE_REPEAT,)
else:
    REPEATS = (sre.MIN_REPEAT, sre.MAX_REPEAT)
    POSSESSIVE_REPEATS = ()
LITERAL = sre.LITERAL
NOT_LITERAL = sre.NOT_LITERAL
IN = sre.IN
MAXREPEAT = sre_parse.MAXREPEAT

# sre_parse AST node: (opcode, value)
# Value varies by opcode (int for LITERAL/AT, list for IN, tuple for REPEAT/SUBPATTERN/BRANCH, None for ANY)
# so `Any` is unavoidable here — this is a tagged union that Python's type system cannot express structurally
_Node: TypeAlias = tuple[int, Any]

# Specific value shapes for opcodes that carry structured data
_RepeatValue: TypeAlias = tuple[int, int, list[_Node]]
_SubpatternValue: TypeAlias = tuple[int | None, int, int, list[_Node]]
_BranchValue: TypeAlias = tuple[None, list[list[_Node]]]


@lru_cache(maxsize=256)
def _parse_regex(pattern: str) -> list[_Node] | None:
    """Parse `pattern` to an sre AST node list (None if invalid); the cached result must not be mutated."""
    try:
        return list(sre_parse.parse(pattern))
    except (re.error, InternalError):
        return None


def _nodes_guarantee(nodes: list[_Node], forces: Callable[[int, Any], bool]) -> bool:
    """Return True if every match of `nodes` contains a char that `forces` flags.

    Structural nodes (SUBPATTERN/REPEATS/BRANCH) are walked here, so `forces` only sees leaves.
    """
    for op, value in nodes:
        if op == sre.SUBPATTERN:
            _, _, _, inner = value
            if _nodes_guarantee(list(inner), forces):
                return True
        elif op in REPEATS:
            min_repeat, _, inner = value
            if min_repeat >= 1 and _nodes_guarantee(list(inner), forces):
                return True
        elif op == sre.BRANCH:
            _, alternatives = value
            if all(_nodes_guarantee(list(alt), forces) for alt in alternatives):
                return True
        elif forces(op, value):
            return True
    return False


@lru_cache
def pattern_length_bounds(pattern: str) -> tuple[int, int | None]:
    """Return min and max string length the pattern matches; `max` is `None` when unbounded."""
    parsed = _parse_regex(pattern)
    if parsed is None:
        return (0, None)
    min_length = _calculate_min_repetition_length(parsed)
    max_length = _calculate_max_repetition_length(parsed)
    return (min_length, None if max_length == MAXREPEAT else max_length)


# Anchors, lookaround and back-references make a match depend on where in the string it is tried,
# so an empty match at position 0 is no longer guaranteed.
_POSITION_DEPENDENT_OPS = frozenset({sre.AT, sre.ASSERT, sre.ASSERT_NOT, sre.GROUPREF, sre.GROUPREF_EXISTS})


def _is_position_dependent(nodes: list[_Node]) -> bool:
    for op, value in nodes:
        if op in _POSITION_DEPENDENT_OPS:
            return True
        if op == sre.SUBPATTERN:
            if _is_position_dependent(list(value[3])):
                return True
        elif op in REPEATS:
            if _is_position_dependent(list(value[2])):
                return True
        elif op == sre.BRANCH and any(_is_position_dependent(list(alternative)) for alternative in value[1]):
            return True
    return False


@lru_cache
def matches_every_string(pattern: str) -> bool:
    """Return True if every string contains a match, so no value can violate `pattern`.

    JSON Schema `pattern` is a substring search, so a pattern that accepts the empty string
    matches at position 0 of anything. Conservative: unknown constructs answer False.
    """
    parsed = _parse_regex(pattern)
    if parsed is None or _is_position_dependent(parsed):
        return False
    return all(op in REPEATS and value[0] == 0 for op, value in parsed)


@lru_cache
def pattern_requires_literal(pattern: str, chars: str) -> bool:
    """Return True if every string matching `pattern` must contain at least one char from `chars`."""
    parsed = _parse_regex(pattern)
    if parsed is None:
        return False
    charcodes = frozenset(ord(ch) for ch in chars)
    return _nodes_guarantee(parsed, lambda op, value: op == LITERAL and value in charcodes)


@lru_cache
def pattern_requires_char_outside(pattern: str, allowed: str) -> bool:
    """Return True if every string matching `pattern` must contain at least one char outside `allowed`."""
    parsed = _parse_regex(pattern)
    if parsed is None:
        return False
    allowed_codes = frozenset(ord(ch) for ch in allowed)

    def forces(op: int, value: Any) -> bool:
        if op == LITERAL:
            return value not in allowed_codes
        if op == IN:
            return _char_class_excludes_all(value, allowed_codes)
        return False

    return _nodes_guarantee(parsed, forces)


def _char_class_excludes_all(items: list[_Node], allowed_codes: frozenset[int]) -> bool:
    """Return True if every char matched by the class `[...]` lies outside `allowed_codes`."""
    if not items:
        return False
    # Negated classes (`[^...]`) match almost anything, including allowed chars.
    if items[0][0] == sre.NEGATE:
        return False
    for op, value in items:
        if op == LITERAL:
            if value in allowed_codes:
                return False
        elif op == sre.RANGE:
            lo, hi = value
            if any(lo <= code <= hi for code in allowed_codes):
                return False
        else:
            # Categories like `\d` / `\w` overlap with the allowed set — assume they can match it.
            return False
    return True


@lru_cache
def update_quantifier(pattern: str, min_length: int | None, max_length: int | None) -> str:
    """Update the quantifier of a regular expression based on given min and max lengths."""
    if not pattern or (min_length in (None, 0) and max_length is None):
        return pattern

    try:
        parsed = sre_parse.parse(pattern)
        result = _transform(list(parsed), min_length, max_length)
        if result is None:
            return pattern
        global_flags = parsed.state.flags & ~_DEFAULT_FLAGS
        updated = _serialize(result, global_flags=global_flags)
        try:
            re.compile(updated)
        except re.error:
            return pattern
        return updated
    except (re.error, InternalError):
        # Invalid pattern or unsupported opcode — return unchanged
        return pattern


_REGEX_META = set(r"\.^$*+?{[|()")


def _serialize(nodes: list[_Node], *, global_flags: int = 0) -> str:
    """Serialize sre_parse AST back to regex string."""
    parts = []
    multi = len(nodes) > 1
    for op, value in nodes:
        s = _serialize_node((op, value))
        # BRANCH must be wrapped when concatenated with other nodes,
        # otherwise | extends to the end of the enclosing group
        if op == sre.BRANCH and multi:
            s = f"(?:{s})"
        parts.append(s)
    body = "".join(parts)
    if global_flags:
        prefix = _serialize_flags(global_flags, 0)
        return f"(?{prefix}){body}"
    return body


def _serialize_node(node: _Node) -> str:
    """Serialize a single AST node."""
    op, value = node
    match op, value:
        case sre.LITERAL, int():
            return _serialize_literal(value)
        case sre.NOT_LITERAL, int():
            return f"[^{_serialize_literal_in_class(value)}]"
        case sre.ANY, _:
            return "."
        case sre.AT, int():
            return _serialize_anchor(value)
        case sre.IN, list():
            return _serialize_in(value)
        case sre.BRANCH, tuple():
            return _serialize_branch(value)
        case sre.SUBPATTERN, tuple():
            return _serialize_subpattern(value)
        case op, tuple() if op in REPEATS:
            return _serialize_repeat(op, value)
        case sre.ASSERT, tuple():
            direction, subpattern = value
            inner = _serialize(list(subpattern))
            return f"(?<={inner})" if direction == -1 else f"(?={inner})"
        case sre.ASSERT_NOT, tuple():
            direction, subpattern = value
            inner = _serialize(list(subpattern))
            return f"(?<!{inner})" if direction == -1 else f"(?!{inner})"
        case sre.GROUPREF, int():
            return f"\\{value}"
        case sre.GROUPREF_EXISTS, tuple():
            group_id, yes_pattern, no_pattern = value
            yes = _serialize(list(yes_pattern))
            no = _serialize(list(no_pattern)) if no_pattern else None
            return f"(?({group_id}){yes}|{no})" if no is not None else f"(?({group_id}){yes})"
        case _ if op == getattr(sre, "ATOMIC_GROUP", None):
            return f"(?>{_serialize(list(value))})"
        case _:
            raise InternalError(f"Unsupported sre opcode: {op}")


def _serialize_literal(charcode: int) -> str:
    ch = chr(charcode)
    if ch in _REGEX_META:
        return "\\" + ch
    if not ch.isprintable():
        if charcode <= 0xFF:
            return f"\\x{charcode:02x}"
        if charcode <= 0xFFFF:
            return f"\\u{charcode:04x}"
        return f"\\U{charcode:08x}"
    return ch


def _serialize_anchor(anchor_type: int) -> str:
    match anchor_type:
        case sre.AT_BEGINNING | sre.AT_BEGINNING_STRING:
            return "^"
        case sre.AT_END | sre.AT_END_STRING:
            return "$"
        case sre.AT_BOUNDARY:
            return "\\b"
        case sre.AT_NON_BOUNDARY:
            return "\\B"
        case _:
            return "\\b"


def _serialize_in(items: list[_Node]) -> str:
    match items:
        case [(sre.NEGATE, _), *rest]:
            inner = "".join(_serialize_in_item(item) for item in rest)
            return f"[^{inner}]"
        case [(sre.CATEGORY, val)]:
            return _serialize_category(val)
        case rest:
            inner = "".join(_serialize_in_item(item) for item in rest)
            return f"[{inner}]"


def _serialize_in_item(node: _Node) -> str:
    op, value = node
    match op, value:
        case sre.LITERAL, int():
            return _serialize_literal_in_class(value)
        case sre.RANGE, (int() as lo, int() as hi):
            return f"{_serialize_literal_in_class(lo)}-{_serialize_literal_in_class(hi)}"
        case sre.CATEGORY, int():
            return _serialize_category(value)
        case _:
            return ""


_CLASS_META = set(r"\]^[-")


def _serialize_literal_in_class(charcode: int) -> str:
    ch = chr(charcode)
    if ch in _CLASS_META:
        return "\\" + ch
    if not ch.isprintable():
        if charcode <= 0xFF:
            return f"\\x{charcode:02x}"
        if charcode <= 0xFFFF:
            return f"\\u{charcode:04x}"
        return f"\\U{charcode:08x}"
    return ch


def _serialize_category(cat: int) -> str:
    match cat:
        case sre.CATEGORY_DIGIT:
            return "\\d"
        case sre.CATEGORY_NOT_DIGIT:
            return "\\D"
        case sre.CATEGORY_SPACE:
            return "\\s"
        case sre.CATEGORY_NOT_SPACE:
            return "\\S"
        case sre.CATEGORY_WORD:
            return "\\w"
        case sre.CATEGORY_NOT_WORD:
            return "\\W"
        case _:
            return ""


def _serialize_repeat(op: int, value: _RepeatValue) -> str:
    min_r, max_r, subpattern = value
    inner = _serialize_repeat_inner(subpattern)
    quantifier = _build_quantifier(min_r, max_r)
    match op:
        case sre.MIN_REPEAT:
            suffix = "?"
        case _ if op == getattr(sre, "POSSESSIVE_REPEAT", None):
            suffix = "+"
        case _:
            suffix = ""
    return inner + quantifier + suffix


def _serialize_repeat_inner(subpattern: list[_Node]) -> str:
    """Serialize the inner part of a repeat, wrapping in parens only when needed."""
    # sre_parse returns SubPattern objects (not plain lists) which don't
    # match sequence patterns in match/case — convert to list first.
    items = list(subpattern)
    match items:
        case [(sre.SUBPATTERN, value)]:
            return _serialize_subpattern(value)
        case [(op, _)] if op in (LITERAL, NOT_LITERAL, IN, sre.ANY, sre.CATEGORY):
            # Single atomic node — already a valid quantifier target, no group needed
            return _serialize_node(items[0])
        case _:
            return "(?:" + _serialize(items) + ")"


def _serialize_subpattern(value: _SubpatternValue) -> str:
    group_id, add_flags, del_flags, pattern = value
    inner = _serialize(pattern)
    flags = _serialize_flags(add_flags, del_flags)
    if group_id is None or group_id == 0:
        return f"(?{flags}:{inner})" if flags else f"(?:{inner})"
    if flags:
        # Capturing group with flags — wrap: (?flags:(inner))
        return f"(?{flags}:({inner}))"
    return f"({inner})"


# Flag bit -> letter mapping for inline flag serialization
_FLAG_LETTERS: tuple[tuple[int, str], ...] = (
    (sre.SRE_FLAG_IGNORECASE, "i"),
    (sre.SRE_FLAG_LOCALE, "L"),
    (sre.SRE_FLAG_MULTILINE, "m"),
    (sre.SRE_FLAG_DOTALL, "s"),
    (sre.SRE_FLAG_UNICODE, "u"),
    (sre.SRE_FLAG_VERBOSE, "x"),
)
if hasattr(sre, "SRE_FLAG_ASCII"):
    _FLAG_LETTERS += ((sre.SRE_FLAG_ASCII, "a"),)

# Default flags set by sre_parse (Unicode mode)
_DEFAULT_FLAGS = sre.SRE_FLAG_UNICODE


def _serialize_flags(add_flags: int, del_flags: int) -> str:
    """Serialize inline flags like 'i', 'im', 'i-s'."""
    add = "".join(ch for flag, ch in _FLAG_LETTERS if add_flags & flag)
    sub = "".join(ch for flag, ch in _FLAG_LETTERS if del_flags & flag)
    if sub:
        return f"{add}-{sub}"
    return add


def _serialize_branch(value: _BranchValue) -> str:
    _, alternatives = value
    return "|".join(_serialize(alt) for alt in alternatives)


_AT_BEGINNING: _Node = (sre.AT, sre.AT_BEGINNING)
_AT_END: _Node = (sre.AT, sre.AT_END)


def _transform(parsed: list[_Node], min_length: int | None, max_length: int | None) -> list[_Node] | None:
    """Top-level transformer. Dispatches by pattern structure."""
    nodes = list(parsed)
    match _classify_structure(nodes):
        # For cases without full anchoring: JSON Schema `pattern` is a substring match,
        # so `{1,50}` alone doesn't reject strings longer than 50 chars. Add the missing
        # anchor(s) whenever max_length is being encoded into the quantifier.
        case ("single", content):
            result = _transform_node(content, min_length, max_length)
            if result is None:
                return None
            if max_length is not None:
                return [_AT_BEGINNING, result, _AT_END]
            return [result]
        case ("leading_anchor", anchor, content):
            result = _transform_node(content, min_length, max_length)
            if result is None:
                return None
            if max_length is not None:
                return [anchor, result, _AT_END]
            return [anchor, result]
        case ("trailing_anchor", content, anchor):
            result = _transform_node(content, min_length, max_length)
            if result is None:
                return None
            if max_length is not None:
                return [_AT_BEGINNING, result, anchor]
            return [result, anchor]

        case ("both_anchors", leading, content, trailing):
            return _transform_anchored_single(leading, content, trailing, min_length, max_length)

        case ("anchored_multi", leading, parts, trailing):
            return _transform_anchored_multi(leading, parts, trailing, min_length, max_length)

        case ("leading_anchor_multi", leading, parts):
            distributed = _distribute_multi(parts, min_length, max_length)
            if distributed is None:
                return None
            if max_length is not None:
                return [leading, *distributed, _AT_END]
            return [leading, *distributed]

        case ("unanchored_multi", parts):
            distributed = _distribute_multi(parts, min_length, max_length)
            if distributed is None:
                return None
            if max_length is not None:
                return [_AT_BEGINNING, *distributed, _AT_END]
            return distributed

        case _:
            return None


# Return type for _classify_structure — Literal tags let mypy narrow captures in match/case
_Structure: TypeAlias = (
    tuple[Literal["single"], _Node]
    | tuple[Literal["leading_anchor"], _Node, _Node]
    | tuple[Literal["trailing_anchor"], _Node, _Node]
    | tuple[Literal["both_anchors"], _Node, _Node, _Node]
    | tuple[Literal["anchored_multi"], _Node, list[_Node], _Node]
    | tuple[Literal["leading_anchor_multi"], _Node, list[_Node]]
    | tuple[Literal["unanchored_multi"], list[_Node]]
    | tuple[Literal["unknown"]]
)


def _classify_structure(nodes: list[_Node]) -> _Structure:
    """Classify pattern structure for dispatch."""
    _CONTENT_OPS = (LITERAL, NOT_LITERAL, IN, sre.ANY, sre.SUBPATTERN, *REPEATS)
    match nodes:
        case [content]:
            return ("single", content)
        case [(sre.AT, _) as anchor, content]:
            return ("leading_anchor", anchor, content)
        case [content, (sre.AT, _) as anchor]:
            return ("trailing_anchor", content, anchor)
        case [(sre.AT, _) as leading, content, (sre.AT, _) as trailing]:
            return ("both_anchors", leading, content, trailing)
        case [(sre.AT, _) as leading, *parts, (sre.AT, _) as trailing] if all(op in _CONTENT_OPS for op, _ in parts):
            return ("anchored_multi", leading, parts, trailing)
        case [(sre.AT, _) as leading, *parts] if len(parts) >= 2 and all(op in _CONTENT_OPS for op, _ in parts):
            return ("leading_anchor_multi", leading, parts)
        case [*parts] if len(parts) >= 2 and all(op in _CONTENT_OPS for op, _ in parts):
            return ("unanchored_multi", parts)
        case _:
            return ("unknown",)


def _transform_node(node: _Node, min_l: int | None, max_l: int | None, *, anchored: bool = False) -> _Node | None:
    """Transform a single content node; `anchored` content matches exactly one char, so the budget may only narrow it."""
    op, value = node
    if op in REPEATS:
        return _transform_repeat(op, value, min_l, max_l)
    if op == sre.SUBPATTERN:
        # A group around a single item just relabels it - rewrite the item and put it back inside the group.
        group, add_flags, del_flags, inner = value
        inner_nodes = list(inner)
        if len(inner_nodes) != 1:
            return None
        result = _transform_node(inner_nodes[0], min_l, max_l, anchored=anchored)
        if result is None:
            return None
        return (sre.SUBPATTERN, (group, add_flags, del_flags, [result]))
    if op in (LITERAL, NOT_LITERAL, IN, sre.ANY):
        if anchored:
            return _transform_repeat(sre.MAX_REPEAT, (1, 1, [node]), min_l, max_l)
        if max_l != 0:
            return _wrap_as_repeat(node, min_l, max_l)
    return None


def _transform_repeat(op: int, value: _RepeatValue, min_l: int | None, max_l: int | None) -> _Node | None:
    """Core transform: merge length constraints into repeat bounds."""
    min_repeat, max_repeat, subpattern = value
    inner_length = _calculate_min_repetition_length(subpattern)

    if inner_length == 0:
        if min_l is not None and min_l > 0:
            return None
        return (sre.MAX_REPEAT, (0, 0, subpattern))

    if max_l is not None and 0 < max_l < inner_length:
        return None

    # Convert length constraints to repetition counts
    ext_min = None
    ext_max = None
    if min_l is not None:
        ext_min = -(-min_l // inner_length)  # ceil division
    if max_l is not None:
        ext_max = max_l // inner_length  # floor division

    # Merge with existing bounds
    final_min = min_repeat
    if ext_min is not None:
        final_min = max(min_repeat, ext_min)

    final_max = max_repeat
    if ext_max is not None:
        final_max = ext_max if max_repeat == MAXREPEAT else min(max_repeat, ext_max)

    if final_min > final_max:
        return None

    # Outer bound unchanged (ext_max >= max_repeat) with variable inner: maxLength unrepresentable.
    if final_max == max_repeat and max_repeat != MAXREPEAT and _has_variable_length(list(subpattern)):
        return None

    return (sre.MAX_REPEAT, (final_min, final_max, subpattern))


def _wrap_as_repeat(node: _Node, min_l: int | None, max_l: int | None) -> _Node:
    """Wrap a single-char node as a repeat."""
    min_r = 1 if min_l is None else max(min_l, 1)
    max_r = max_l if max_l is not None else MAXREPEAT
    return (sre.MAX_REPEAT, (min_r, max_r, [node]))


def _transform_anchored_single(
    leading: _Node,
    content: _Node,
    trailing: _Node,
    min_l: int | None,
    max_l: int | None,
) -> list[_Node] | None:
    r"""^content$ with canonicalization of [\w\W] -> . before transform."""
    op, value = content

    # Canonicalize match-anything patterns
    if op == sre.IN and _matches_anything(value):
        content = (sre.ANY, None)
    elif op in REPEATS and len(value[2]) == 1 and value[2][0][0] == sre.IN and _matches_anything(value[2][0][1]):
        content = (op, (value[0], value[1], [(sre.ANY, None)]))

    result = _transform_node(content, min_l, max_l, anchored=True)
    if result is None:
        return None
    return [leading, result, trailing]


def _transform_anchored_multi(
    leading: _Node,
    parts: list[_Node],
    trailing: _Node,
    min_l: int | None,
    max_l: int | None,
) -> list[_Node] | None:
    """^part1 part2 ... partN$ — multiple quantified/fixed parts."""
    new_parts = _distribute_multi(parts, min_l, max_l)
    if new_parts is None:
        return None
    return [leading] + new_parts + [trailing]


def _distribute_multi(parts: list[_Node], min_l: int | None, max_l: int | None) -> list[_Node] | None:
    """Distribute a length budget across the quantified parts; the caller adds any anchors."""
    if any(op in POSSESSIVE_REPEATS for op, _ in parts):
        # A possessive part keeps everything it took, so what follows it never gets those characters
        # back - a rewritten count would admit strings the pattern itself rejects.
        return None
    fixed_length = 0
    quantifier_bounds = []
    repetition_lengths = []
    repetition_max_lengths = []
    quantified_indices = []

    # Slots reached through a group, by part index, so the rewrite puts them back inside it.
    group_headers: dict[int, tuple[int, int, int]] = {}

    for idx, (op, value) in enumerate(parts):
        if op in (LITERAL, NOT_LITERAL, IN, sre.ANY):
            fixed_length += 1
        elif op in REPEATS:
            min_repeat, max_repeat, subpattern = value
            quantifier_bounds.append((min_repeat, max_repeat))
            repetition_lengths.append(_calculate_min_repetition_length(subpattern))
            repetition_max_lengths.append(_calculate_max_repetition_length(list(subpattern)))
            quantified_indices.append(idx)
        elif op == sre.SUBPATTERN:
            group, add_flags, del_flags, inner = value
            inner_nodes = list(inner)
            if len(inner_nodes) == 1 and inner_nodes[0][0] in REPEATS:
                min_repeat, max_repeat, subpattern = inner_nodes[0][1]
                quantifier_bounds.append((min_repeat, max_repeat))
                repetition_lengths.append(_calculate_min_repetition_length(subpattern))
                repetition_max_lengths.append(_calculate_max_repetition_length(list(subpattern)))
                quantified_indices.append(idx)
                group_headers[idx] = (group, add_flags, del_flags)
                continue
            inner_min = _calculate_min_repetition_length(inner_nodes)
            if inner_min != _calculate_max_repetition_length(inner_nodes):
                # Only a group of a known length can be paid for out of the budget.
                return None
            fixed_length += inner_min

    adj_min = None if min_l is None else min_l - fixed_length
    adj_max = None if max_l is None else max_l - fixed_length

    if (adj_min is not None and adj_min < 0) or (adj_max is not None and adj_max < 0):
        return None

    if not quantifier_bounds:
        return None

    # Pin slots whose bounds the distributor must not change:
    #   - Slots whose inner per-tick max is truly unbounded (e.g. `[|]+` inside,
    #     branches with unbounded alternatives): outer count cannot enforce length.
    #     Pinning them keeps the rewrite a superset of the original; siblings can
    #     still tighten for minLength.
    #   - Variable-inner slots in exact-length cases: the exact-length DP can't
    #     distribute a per-tick range, so we keep them and accept that the
    #     resulting pattern won't enforce exact length.
    #   - Optional finite slots with fixed-length inner (range cases only):
    #     collapse-to-zero would produce a strict subset (e.g. `\*?` in
    #     `^geo:\w*\*?$` becoming `\*{0}` rejects "geo:abc*"). For exact-length
    #     the DP picks one concrete shape and collapses are acceptable.
    # Variable-inner slots with finite per-tick max (e.g. `(aa|bbb)`) are NOT
    # pinned — the distributor uses `repetition_max_lengths` to compute outer
    # bounds that actually enforce maxLength.
    exact_length = adj_min == adj_max
    pinned: set[int] = set()
    # Slots dropped to zero repetitions; left open-ended, generation hunts forever for the only matches that fit.
    collapsed: set[int] = set()
    has_unbounded_pinned = False
    for dist_idx in range(len(quantifier_bounds)):
        orig_min, orig_max = quantifier_bounds[dist_idx]
        rep_len_max = repetition_max_lengths[dist_idx]
        rep_len_min = repetition_lengths[dist_idx]
        inner_variable = rep_len_min != rep_len_max
        if exact_length and inner_variable and orig_min == 0 and rep_len_min > 0:
            # Every repetition costs a character the other slots already spent - unless it can match empty.
            collapsed.add(dist_idx)
        elif inner_variable and rep_len_max == MAXREPEAT:
            pinned.add(dist_idx)
            has_unbounded_pinned = True
        elif inner_variable and exact_length:
            pinned.add(dist_idx)
            # Bounded inner length, but exact-length DP can't use the range.
            # Treat contribution as bounded for budget; the resulting rewrite
            # is a superset that no longer enforces exact length.
            has_unbounded_pinned = True
        elif not exact_length and orig_min == 0 and 0 < orig_max < MAXREPEAT and not inner_variable:
            pinned.add(dist_idx)

    if pinned or collapsed:
        sum_pinned_min = 0
        sum_pinned_max = 0
        for dist_idx in pinned:
            min_r, max_r = quantifier_bounds[dist_idx]
            rep_len = repetition_lengths[dist_idx]
            sum_pinned_min += min_r * rep_len
            sum_pinned_max += max_r * rep_len

        np_adj_min = None if adj_min is None else max(0, adj_min - sum_pinned_min)
        # A pinned slot can carry more than its minimum, so the total cannot be pinned to maxLength -
        # but leaving the rest open-ended aims generation orders of magnitude past it, for nothing.
        if has_unbounded_pinned:
            np_adj_max = None if adj_max is None else max(0, adj_max - sum_pinned_min)
        else:
            np_adj_max = None if adj_max is None else adj_max - sum_pinned_max
        if np_adj_max is not None and np_adj_max < 0:
            return None

        np_indices = [i for i in range(len(quantifier_bounds)) if i not in pinned and i not in collapsed]
        if not np_indices:
            # All slots pinned — the rewrite would just re-emit the original bounds.
            return None
        np_bounds = [quantifier_bounds[i] for i in np_indices]
        np_rep_lens = [repetition_lengths[i] for i in np_indices]
        np_rep_max_lens = [repetition_max_lengths[i] for i in np_indices]
        np_distribution = _distribute_length_constraints(
            np_bounds, np_rep_lens, np_adj_min, np_adj_max, max_repetition_lengths=np_rep_max_lens
        )
        if not np_distribution:
            return None

        distribution: list[tuple[int, int]] = []
        np_iter = iter(np_distribution)
        for dist_idx in range(len(quantifier_bounds)):
            if dist_idx in collapsed:
                distribution.append((0, 0))
            elif dist_idx in pinned:
                distribution.append(quantifier_bounds[dist_idx])
            else:
                distribution.append(next(np_iter))
    else:
        full_distribution = _distribute_length_constraints(
            quantifier_bounds,
            repetition_lengths,
            adj_min,
            adj_max,
            max_repetition_lengths=repetition_max_lengths,
        )
        if not full_distribution:
            return None
        distribution = full_distribution

    for dist_idx, (new_min, new_max) in enumerate(distribution):
        if dist_idx in pinned:
            continue
        orig_min, orig_max = quantifier_bounds[dist_idx]
        if (new_min, new_max) == (orig_min, orig_max):
            continue
        # For exact-length cases the rewrite picks one concrete shape. Collapsing
        # an optional sibling to `{0}` is fine — the chosen shape still satisfies
        # the original pattern and the requested length.
        if not exact_length and orig_max != 0 and new_max == 0:
            return None

    # Apply distribution directly to AST nodes
    new_parts = list(parts)
    for dist_idx, part_idx in enumerate(quantified_indices):
        op, value = parts[part_idx]
        new_min, new_max = distribution[dist_idx]
        header = group_headers.get(part_idx)
        if header is not None:
            _, _, _, inner = value
            _, _, subpattern = list(inner)[0][1]
            repeat = (sre.MAX_REPEAT, (new_min, new_max, subpattern))
            new_parts[part_idx] = (sre.SUBPATTERN, (*header, [repeat]))
            continue
        _, _, subpattern = value
        new_parts[part_idx] = (sre.MAX_REPEAT, (new_min, new_max, subpattern))

    return new_parts


def _matches_anything(value: list[_Node]) -> bool:
    """Check if the given pattern is equivalent to '.' (match any character)."""
    return value in (
        [(sre.CATEGORY, sre.CATEGORY_WORD), (sre.CATEGORY, sre.CATEGORY_NOT_WORD)],
        [(sre.CATEGORY, sre.CATEGORY_SPACE), (sre.CATEGORY, sre.CATEGORY_NOT_SPACE)],
        [(sre.CATEGORY, sre.CATEGORY_DIGIT), (sre.CATEGORY, sre.CATEGORY_NOT_DIGIT)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_WORD), (sre.CATEGORY, sre.CATEGORY_WORD)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_SPACE), (sre.CATEGORY, sre.CATEGORY_SPACE)],
        [(sre.CATEGORY, sre.CATEGORY_NOT_DIGIT), (sre.CATEGORY, sre.CATEGORY_DIGIT)],
    )


def _distribute_length_constraints(
    bounds: list[tuple[int, int]],
    repetition_lengths: list[int],
    min_length: int | None,
    max_length: int | None,
    *,
    max_repetition_lengths: list[int],
) -> list[tuple[int, int]] | None:
    """Distribute length constraints among quantified pattern parts."""
    if min_length is not None and min_length == max_length:
        return _distribute_exact_length(bounds, repetition_lengths, min_length)
    return _distribute_length_range(
        bounds, repetition_lengths, min_length, max_length, max_repetition_lengths=max_repetition_lengths
    )


def _distribute_exact_length(
    bounds: list[tuple[int, int]], repetition_lengths: list[int], target: int
) -> list[tuple[int, int]] | None:
    """Find exact repetition counts that sum to target length via dynamic programming."""
    dp: dict[tuple[int, int], list[tuple[int, ...]] | None] = {}

    def find_valid_combination(pos: int, remaining: int) -> list[tuple[int, ...]] | None:
        if (pos, remaining) in dp:
            return dp[(pos, remaining)]

        if pos == len(bounds):
            return [()] if remaining == 0 else None

        max_repeat: int
        min_repeat, max_repeat = bounds[pos]
        repeat_length = repetition_lengths[pos]

        if max_repeat == MAXREPEAT:
            max_repeat = remaining // repeat_length + 1 if repeat_length > 0 else remaining + 1

        # For optional slots that contribute chars, try non-zero counts first so
        # the chosen distribution avoids unnecessary `{0}` collapses (e.g. picks
        # `[a-z]{1}-[0-9]{1}` for `^[a-z]*-[0-9]*$` length 3 instead of leaving
        # one slot at zero). Falls back to zero if no non-zero combination fits.
        if min_repeat == 0 and max_repeat > 0 and repeat_length > 0:
            counts: range | tuple[int, ...] = (*range(1, max_repeat + 1), 0)
        else:
            counts = range(min_repeat, max_repeat + 1)

        for repeat_count in counts:
            used_length = repeat_count * repeat_length
            if used_length > remaining:
                continue

            rest = find_valid_combination(pos + 1, remaining - used_length)
            if rest is not None:
                dp[(pos, remaining)] = [(repeat_count,) + r for r in rest]
                return dp[(pos, remaining)]

        dp[(pos, remaining)] = None
        return None

    distribution = find_valid_combination(0, target)
    if distribution:
        return [(length, length) for length in distribution[0]]
    return None


def _distribute_length_range(
    bounds: list[tuple[int, int]],
    repetition_lengths: list[int],
    min_length: int | None,
    max_length: int | None,
    *,
    max_repetition_lengths: list[int],
) -> list[tuple[int, int]] | None:
    """Distribute min/max length budget across quantifiers.

    When `max_repetition_lengths` differs from `repetition_lengths` (variable inner
    with finite per-tick max), the upper-budget calculation uses the per-tick max
    so the resulting outer count actually bounds the slot's contribution.

    A first pass is greedy: each slot consumes as much of the budget as it can.
    If that collapses an optional sibling to `{0}` (the leading slot ate everything),
    a balanced second pass splits the max budget across slots so each gets headroom.
    """
    greedy = _greedy_distribute_range(bounds, repetition_lengths, max_repetition_lengths, min_length, max_length)
    # Greedy may either succeed with a starved sibling (`{0}`) or fail outright
    # because it gave the leading slot too much. Both are signals that the budget
    # is contested across siblings — fall back to a balanced split. Balanced needs
    # a finite upper budget to redistribute; without one (pinned unbounded inner
    # dropped `max_length`) there is nothing it can do and greedy's result stands.
    needs_balance = max_length is not None and (
        greedy is None or any(new_max == 0 and bounds[idx][1] > 0 for idx, (_, new_max) in enumerate(greedy))
    )
    if needs_balance:
        balanced = _balanced_distribute_range(
            bounds, repetition_lengths, max_repetition_lengths, min_length, max_length
        )
        if balanced is not None:
            return balanced
    return greedy


def _greedy_distribute_range(
    bounds: list[tuple[int, int]],
    repetition_lengths: list[int],
    max_repetition_lengths: list[int],
    min_length: int | None,
    max_length: int | None,
) -> list[tuple[int, int]] | None:
    """Single-pass greedy: each slot maxes out before moving on."""
    result = []
    remaining_min = min_length or 0
    remaining_max = MAXREPEAT if max_length is None else max_length

    for (min_repeat, max_repeat), rep_len_min, rep_len_max in zip(
        bounds, repetition_lengths, max_repetition_lengths, strict=True
    ):
        if rep_len_min == 0 and rep_len_max == 0:
            result.append((0, 0))
            continue

        if remaining_min > 0 and rep_len_min > 0:
            part_min = min(max_repeat, max(min_repeat, -(-remaining_min // rep_len_min)))
        else:
            part_min = min_repeat

        if remaining_max < MAXREPEAT and rep_len_max != MAXREPEAT and rep_len_max > 0:
            part_max = min(max_repeat, remaining_max // rep_len_max)
        else:
            part_max = max_repeat

        if part_min > part_max:
            return None

        result.append((part_min, part_max))

        remaining_min = max(0, remaining_min - part_min * rep_len_min)
        if part_max != MAXREPEAT and rep_len_max != MAXREPEAT:
            remaining_max -= part_max * rep_len_max

    if remaining_min > 0 or remaining_max < 0:
        return None

    return result


def _balanced_distribute_range(
    bounds: list[tuple[int, int]],
    repetition_lengths: list[int],
    max_repetition_lengths: list[int],
    min_length: int | None,
    max_length: int | None,
) -> list[tuple[int, int]] | None:
    """Distribute min/max budgets across slots so every sibling keeps headroom.

    Each slot's max gets the full budget minus what the other slots are *required*
    to consume; an even `max_length // n` cap would reject valid skewed distributions
    the original pattern allowed (e.g. `"A" + "0"*100` for `^[a-zA-Z*]+[a-zA-Z0-9-]*$`
    with `maxLength=128`). The pattern's combined max may exceed `max_length`, so
    callers must keep the schema-level `maxLength` to enforce the total.
    """
    n = len(bounds)
    # Balanced is only invoked when greedy starved a sibling — that requires both
    # a finite max budget and at least one slot. The caller (`_transform_anchored_multi`)
    # already guarantees `bounds` is non-empty.
    assert n > 0 and max_length is not None and max_length < MAXREPEAT
    other_min_chars = []
    for idx in range(n):
        total = 0
        for jdx, ((mn, _), rl) in enumerate(zip(bounds, repetition_lengths, strict=True)):
            if jdx != idx:
                total += mn * rl
        other_min_chars.append(total)
    slot_max_chars = [max(0, max_length - other) for other in other_min_chars]

    # Min budget is distributed only across required slots (orig_min > 0). Optional
    # slots keep `part_min = 0` so they stay optional in the rewrite — forcing them
    # to a non-zero count would reject strings the original schema accepts.
    required_slots_left = sum(1 for (mn, _), rl in zip(bounds, repetition_lengths, strict=True) if mn > 0 and rl > 0)

    result = []
    remaining_min = min_length or 0

    for (min_repeat, max_repeat), rep_len_min, rep_len_max, max_chars in zip(
        bounds, repetition_lengths, max_repetition_lengths, slot_max_chars, strict=True
    ):
        if rep_len_min == 0 and rep_len_max == 0:
            result.append((0, 0))
            continue

        # Slots with unbounded `rep_len_max` are pinned upstream, and `slot_max_chars`
        # are all finite by construction (the caller only invokes balanced when
        # `max_length` is finite).
        part_max = min(max_repeat, max_chars // rep_len_max)

        if min_repeat == 0:
            # Optional slot — keep it optional; min budget is the required slots' job.
            part_min = 0
        elif remaining_min > 0 and rep_len_min > 0 and required_slots_left > 0:
            share_chars = -(-remaining_min // required_slots_left)
            needed_ticks = -(-share_chars // rep_len_min)
            part_min = min(part_max, max(min_repeat, needed_ticks))
            required_slots_left -= 1
        else:
            part_min = min_repeat
            if min_repeat > 0:
                required_slots_left -= 1

        if part_min > part_max:
            return None

        result.append((part_min, part_max))
        remaining_min = max(0, remaining_min - part_min * rep_len_min)

    if remaining_min > 0:
        return None

    return result


def _calculate_min_repetition_length(subpattern: list[_Node]) -> int:
    """Calculate minimum length contribution per repetition of a quantified group."""
    total = 0
    for op, value in subpattern:
        if op in [LITERAL, NOT_LITERAL, IN, sre.ANY]:
            total += 1
        elif op == sre.SUBPATTERN:
            _, _, _, inner_pattern = value
            total += _calculate_min_repetition_length(inner_pattern)
        elif op in REPEATS:
            min_repeat, _, inner_pattern = value
            inner_min = _calculate_min_repetition_length(inner_pattern)
            total += min_repeat * inner_min
        elif op == sre.BRANCH:
            _, alternatives = value
            branch_min = min(_calculate_min_repetition_length(list(alt)) for alt in alternatives)
            total += branch_min
    return total


def _calculate_max_repetition_length(subpattern: list[_Node]) -> int:
    """Calculate maximum length contribution per repetition. Returns MAXREPEAT if unbounded."""
    total = 0
    for op, value in subpattern:
        if op in [LITERAL, NOT_LITERAL, IN, sre.ANY]:
            total += 1
        elif op == sre.SUBPATTERN:
            _, _, _, inner_pattern = value
            inner_max = _calculate_max_repetition_length(list(inner_pattern))
            if inner_max == MAXREPEAT:
                return MAXREPEAT
            total += inner_max
        elif op in REPEATS:
            _, max_repeat, inner_pattern = value
            if max_repeat == 0:
                # Never repeated, so however long the inner pattern could get, none of it is matched.
                continue
            if max_repeat == MAXREPEAT:
                return MAXREPEAT
            inner_max = _calculate_max_repetition_length(list(inner_pattern))
            if inner_max == MAXREPEAT:
                return MAXREPEAT
            total += max_repeat * inner_max
        elif op == sre.BRANCH:
            _, alternatives = value
            alt_maxes = [_calculate_max_repetition_length(list(alt)) for alt in alternatives]
            if MAXREPEAT in alt_maxes:
                return MAXREPEAT
            total += max(alt_maxes)
    return total


def _has_variable_length(nodes: list[_Node]) -> bool:
    """Return True if the nodes can produce strings of variable length (contain *, +, ?, {n,m}, or branches)."""
    for op, value in nodes:
        if op in REPEATS:
            min_r, max_r, inner = value
            if min_r != max_r:
                return True
            if _has_variable_length(list(inner)):
                return True
        elif op == sre.SUBPATTERN:
            _, _, _, inner = value
            if _has_variable_length(list(inner)):
                return True
        elif op == sre.BRANCH:
            return True
    return False


def _build_quantifier(minimum: int | None, maximum: int | None) -> str:
    """Construct a quantifier string based on min and max values."""
    if maximum == MAXREPEAT or maximum is None:
        return f"{{{minimum or 0},}}"
    if minimum == maximum:
        return f"{{{minimum}}}"
    return f"{{{minimum or 0},{maximum}}}"


# Every length a pattern can match is tracked as one bit of an integer, so lengths past this point
# would make the walk cost more than the search it is meant to replace.
_MAX_ANALYSED_LENGTH = 4096


def _length_analysis_limit(min_length: int | None, max_length: int | None) -> int | None:
    """The highest length worth walking for this window, or `None` when the window is out of reach."""
    ceiling = min_length if max_length is None else max_length
    if ceiling is None or ceiling > _MAX_ANALYSED_LENGTH:
        return None
    return ceiling


def _window_mask(min_length: int | None, max_length: int | None, limit: int) -> int:
    low = min_length or 0
    high = limit if max_length is None else min(max_length, limit)
    if low > high:
        return 0
    return ((1 << (high - low + 1)) - 1) << low


def _concat_lengths(left: int, right: int, limit: int) -> int:
    """Lengths reachable by putting a `left` match in front of a `right` one."""
    if left == 0 or right == 0:
        return 0
    full = (1 << (limit + 1)) - 1
    # An unbroken run of reachable lengths at the top shifts as one block, so only the gapped
    # part below it costs a step - which is what keeps this affordable on `.*`-style patterns.
    dense_from = (full & ~left).bit_length()
    lowest_right = (right & -right).bit_length() - 1
    result = (full << (dense_from + lowest_right)) & full
    head = left & ((1 << dense_from) - 1)
    while head:
        result |= right << ((head & -head).bit_length() - 1)
        head &= head - 1
    return result & full


def _power_lengths(base: int, exponent: int, limit: int) -> int:
    """Lengths reachable by putting `exponent` matches of `base` in a row.

    Callers cap the exponent so the shortest run still fits under `limit`, which is what keeps
    every intermediate product non-empty.
    """
    result = 1
    while exponent:
        if exponent & 1:
            result = _concat_lengths(result, base, limit)
        exponent >>= 1
        if exponent:
            base = _concat_lengths(base, base, limit)
    return result


def _repeat_lengths(inner: int, min_repeat: int, max_repeat: int, limit: int) -> int:
    if inner == 0:
        # The body matches nothing, so skipping it entirely is all that is left.
        return 1 if min_repeat == 0 else 0
    if inner == 1:
        return 1
    lowest = (inner & -inner).bit_length() - 1
    if lowest > 0 and min_repeat > limit // lowest:
        return 0
    base = _power_lengths(inner, min(min_repeat, limit), limit)
    extra = limit if max_repeat == MAXREPEAT else min(max_repeat - min_repeat, limit)
    if extra <= 0:
        return base
    # Letting the body match empty turns "up to `extra` more repetitions" into a single power.
    return _concat_lengths(base, _power_lengths(inner | 1, extra, limit), limit)


def _node_lengths(node: _Node, limit: int) -> int | None:
    """Lengths a single node can match, or `None` when it names something the walk cannot follow."""
    op, value = node
    if op in (LITERAL, NOT_LITERAL, IN, sre.ANY):
        return 0b10
    # Anchors and lookaround match no characters of their own; ignoring what they demand of the
    # surrounding text only ever admits more lengths, never fewer.
    if op in (sre.AT, sre.ASSERT, sre.ASSERT_NOT):
        return 0b1
    if op == sre.SUBPATTERN:
        return _nodes_lengths(list(value[3]), limit)
    if op in REPEATS:
        min_repeat, max_repeat, subpattern = value
        inner = _nodes_lengths(list(subpattern), limit)
        if inner is None:
            return None
        return _repeat_lengths(inner, min_repeat, max_repeat, limit)
    if op == sre.BRANCH:
        total = 0
        for alternative in value[1]:
            current = _nodes_lengths(list(alternative), limit)
            if current is None:
                return None
            total |= current
        return total
    if op == getattr(sre, "ATOMIC_GROUP", None):
        return _nodes_lengths(list(value), limit)
    return None


def _nodes_lengths(nodes: list[_Node], limit: int) -> int | None:
    result = 1
    for node in nodes:
        current = _node_lengths(node, limit)
        if current is None:
            return None
        result = _concat_lengths(result, current, limit)
        if result == 0:
            return 0
    return result


@lru_cache(maxsize=256)
def _pattern_lengths(pattern: str, limit: int) -> int | None:
    parsed = _parse_regex(pattern)
    if parsed is None:
        return None
    return _nodes_lengths(parsed, limit)


@lru_cache(maxsize=256)
def pattern_length_is_unreachable(pattern: str, min_length: int | None, max_length: int | None) -> bool:
    """Whether no string of a length inside the window matches the pattern end to end.

    A min/max pair cannot see that a length falls in a hole between two reachable sizes, which is
    where generation spends its whole budget before giving up. Unknown constructs answer False.
    """
    limit = _length_analysis_limit(min_length, max_length)
    if limit is None:
        return False
    reachable = _pattern_lengths(pattern, limit)
    if reachable is None:
        return False
    return not reachable & _window_mask(min_length, max_length, limit)


def _pick_length(available: int, rest: int, remaining: int) -> int | None:
    """The shortest this node can be while leaving the rest of the pattern a length it can reach."""
    candidates = available & ((1 << (remaining + 1)) - 1)
    while candidates:
        choice = (candidates & -candidates).bit_length() - 1
        if rest >> (remaining - choice) & 1:
            return choice
        candidates &= candidates - 1
    return None


def _restrict_nodes(nodes: list[_Node], target: int, limit: int) -> list[_Node] | None:
    """The nodes narrowed to matches of exactly `target` characters, or `None` when the shape resists."""
    lengths = []
    for node in nodes:
        current = _node_lengths(node, limit)
        # Reached only after the walk vetted these very nodes, so a length is always there.
        assert current is not None
        lengths.append(current)
    # What the nodes after each position can still absorb, so no choice strands the remainder.
    suffixes = [1] * (len(nodes) + 1)
    for index in range(len(nodes) - 1, -1, -1):
        suffixes[index] = _concat_lengths(lengths[index], suffixes[index + 1], limit)
    result: list[_Node] = []
    remaining = target
    for index, node in enumerate(nodes):
        choice = _pick_length(lengths[index], suffixes[index + 1], remaining)
        if choice is None:
            return None
        restricted = _restrict_node(node, choice, limit)
        if restricted is None:
            return None
        result.extend(restricted)
        remaining -= choice
    return result if remaining == 0 else None


def _restrict_node(node: _Node, length: int, limit: int) -> list[_Node] | None:
    op, value = node
    if op in (sre.AT, sre.ASSERT, sre.ASSERT_NOT):
        return [node] if length == 0 else None
    if op in (LITERAL, NOT_LITERAL, IN, sre.ANY):
        return [node] if length == 1 else None
    if op == sre.SUBPATTERN:
        group, add_flags, del_flags, inner = value
        restricted = _restrict_nodes(list(inner), length, limit)
        if restricted is None:
            return None
        return [(sre.SUBPATTERN, (group, add_flags, del_flags, restricted))]
    if op == sre.BRANCH:
        for alternative in value[1]:
            restricted = _restrict_nodes(list(alternative), length, limit)
            if restricted is not None:
                return [(sre.BRANCH, (None, [restricted]))]
        return None
    # A possessive part keeps every character it took, so what follows it never gets those back -
    # a rewritten count would admit strings the pattern itself rejects.
    if op in REPEATS and op not in POSSESSIVE_REPEATS:
        return _restrict_repeat(value, length, limit)
    return None


def _restrict_repeat(value: _RepeatValue, length: int, limit: int) -> list[_Node] | None:
    min_repeat, max_repeat, subpattern = value
    body = list(subpattern)
    inner = _nodes_lengths(body, limit)
    if inner is None or inner == 0:
        # A body matching nothing leaves only the option of skipping the repeat altogether.
        return [] if inner == 0 and min_repeat == 0 else None
    lowest = (inner & -inner).bit_length() - 1
    highest = inner.bit_length() - 1
    if length == 0:
        # Repetitions that match no characters add nothing to the text, so dropping them is exact.
        return [] if min_repeat == 0 or lowest == 0 else None
    # Only a body whose reachable lengths run without gaps lets a budget be split evenly across
    # repetitions; anything else needs a search this walk deliberately does not do.
    if highest == 0 or inner != ((1 << (highest - lowest + 1)) - 1) << lowest:
        return None
    # `length` came off this repeat's own reachable set, so a count that fits always exists.
    count = max(min_repeat, 1, -(-length // highest))
    base, remainder = divmod(length, count)
    parts: list[_Node] = []
    for piece_length, piece_count in ((base + 1, remainder), (base, count - remainder)):
        if piece_count == 0 or piece_length == 0:
            continue
        piece = _restrict_nodes(body, piece_length, limit)
        if piece is None:
            return None
        parts.append((sre.MAX_REPEAT, (piece_count, piece_count, piece)))
    return parts


@lru_cache(maxsize=256)
def pin_pattern_length(pattern: str, min_length: int | None, max_length: int | None) -> str:
    """Rewrite the pattern so every match has one length inside the window.

    Rejection sampling never lands on a window far from the sizes a pattern emits on its own, so the
    length has to be spelled into the pattern. Shapes that resist the rewrite come back unchanged.
    """
    limit = _length_analysis_limit(min_length, max_length)
    if limit is None:
        return pattern
    try:
        parsed = sre_parse.parse(pattern)
        nodes = list(parsed)
        reachable = _nodes_lengths(nodes, limit)
        if reachable is None:
            return pattern
        window = reachable & _window_mask(min_length, max_length, limit)
        if window == 0:
            return pattern
        restricted = _restrict_nodes(nodes, (window & -window).bit_length() - 1, limit)
        if restricted is None:
            return pattern
        updated = _serialize(restricted, global_flags=parsed.state.flags & ~_DEFAULT_FLAGS)
        re.compile(updated)
        return updated
    except (re.error, InternalError):
        return pattern
