from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, fields
from typing import TYPE_CHECKING, Any, ClassVar

from schemathesis.config._diff_base import DiffBase
from schemathesis.config._error import ConfigError

if TYPE_CHECKING:
    from typing_extensions import Self

NOT_A_SERVER_ERROR_EXPECTED_STATUSES = ["2xx", "3xx", "4xx"]
NEGATIVE_DATA_REJECTION_EXPECTED_STATUSES = ["400", "401", "403", "404", "405", "406", "409", "422", "428", "5xx"]
POSITIVE_DATA_ACCEPTANCE_EXPECTED_STATUSES = ["2xx", "401", "403", "404", "409", "5xx"]
MISSING_REQUIRED_HEADER_EXPECTED_STATUSES = ["400", "401", "403", "406", "422"]


def validate_status_codes(value: Sequence[str] | None) -> Sequence[str] | None:
    if not value:
        return value

    invalid = []

    for code in value:
        if len(code) != 3:
            invalid.append(code)
            continue

        if code[0] not in {"1", "2", "3", "4", "5"}:
            invalid.append(code)
            continue

        upper_code = code.upper()

        if "X" in upper_code:
            if (
                upper_code[1:] == "XX"
                or (upper_code[1] == "X" and upper_code[2].isdigit())
                or (upper_code[1].isdigit() and upper_code[2] == "X")
            ):
                continue
            else:
                invalid.append(code)
                continue

        if not code.isnumeric():
            invalid.append(code)

    if invalid:
        raise ConfigError(
            f"Invalid status code(s): {', '.join(invalid)}. "
            "Use valid 3-digit codes between 100 and 599, "
            "or wildcards (e.g., 2XX, 2X0, 20X), where X is a wildcard digit."
        )
    return value


@dataclass(repr=False, slots=True)
class SimpleCheckConfig(DiffBase):
    enabled: bool

    def __init__(self, *, enabled: bool = True) -> None:
        self.enabled = enabled

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SimpleCheckConfig:
        return cls(enabled=data.get("enabled", True))


@dataclass(repr=False, slots=True)
class ResponseSchemaConformanceConfig(DiffBase):
    enabled: bool
    validate_formats: bool

    def __init__(self, *, enabled: bool = True, validate_formats: bool = True) -> None:
        self.enabled = enabled
        self.validate_formats = validate_formats

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResponseSchemaConformanceConfig:
        return cls(enabled=data.get("enabled", True), validate_formats=data.get("validate-formats", True))


@dataclass(repr=False, slots=True)
class MaxResponseTimeConfig(DiffBase):
    enabled: bool
    limit: float | None

    def __init__(self, *, limit: float | None = None) -> None:
        self.enabled = limit is not None
        self.limit = limit


@dataclass(repr=False, slots=True)
class CheckConfig(DiffBase):
    enabled: bool
    expected_statuses: list[str]
    _DEFAULT_EXPECTED_STATUSES: ClassVar[list[str]]

    def __init__(self, *, enabled: bool = True, expected_statuses: Sequence[str | int] | None = None) -> None:
        self.enabled = enabled
        if expected_statuses is not None:
            statuses = [str(status) for status in expected_statuses]
            validate_status_codes(statuses)
            self.expected_statuses = statuses
        else:
            self.expected_statuses = self._DEFAULT_EXPECTED_STATUSES

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        enabled = data.get("enabled", True)
        return cls(
            enabled=enabled,
            expected_statuses=data.get("expected-statuses", cls._DEFAULT_EXPECTED_STATUSES),
        )


class NotAServerErrorConfig(CheckConfig):
    _DEFAULT_EXPECTED_STATUSES = NOT_A_SERVER_ERROR_EXPECTED_STATUSES


class PositiveDataAcceptanceConfig(CheckConfig):
    _DEFAULT_EXPECTED_STATUSES = POSITIVE_DATA_ACCEPTANCE_EXPECTED_STATUSES


class NegativeDataRejectionConfig(CheckConfig):
    _DEFAULT_EXPECTED_STATUSES = NEGATIVE_DATA_REJECTION_EXPECTED_STATUSES


class MissingRequiredHeaderConfig(CheckConfig):
    _DEFAULT_EXPECTED_STATUSES = MISSING_REQUIRED_HEADER_EXPECTED_STATUSES


@dataclass(repr=False, slots=True)
class ChecksConfig(DiffBase):
    not_a_server_error: NotAServerErrorConfig
    status_code_conformance: SimpleCheckConfig
    content_type_conformance: SimpleCheckConfig
    response_schema_conformance: ResponseSchemaConformanceConfig
    response_headers_conformance: SimpleCheckConfig
    positive_data_acceptance: PositiveDataAcceptanceConfig
    negative_data_rejection: NegativeDataRejectionConfig
    use_after_free: SimpleCheckConfig
    ensure_resource_availability: SimpleCheckConfig
    missing_required_header: MissingRequiredHeaderConfig
    ignored_auth: SimpleCheckConfig
    unsupported_method: SimpleCheckConfig
    allow_header_conformance: SimpleCheckConfig
    max_response_time: MaxResponseTimeConfig
    _unknown: dict[str, SimpleCheckConfig]
    # Kwargs forwarded to __init__ of class-based checks, keyed by check class name.
    _custom_kwargs: dict[str, dict[str, Any]]

    def __init__(
        self,
        *,
        not_a_server_error: NotAServerErrorConfig | None = None,
        status_code_conformance: SimpleCheckConfig | None = None,
        content_type_conformance: SimpleCheckConfig | None = None,
        response_schema_conformance: ResponseSchemaConformanceConfig | None = None,
        response_headers_conformance: SimpleCheckConfig | None = None,
        positive_data_acceptance: PositiveDataAcceptanceConfig | None = None,
        negative_data_rejection: NegativeDataRejectionConfig | None = None,
        use_after_free: SimpleCheckConfig | None = None,
        ensure_resource_availability: SimpleCheckConfig | None = None,
        missing_required_header: MissingRequiredHeaderConfig | None = None,
        ignored_auth: SimpleCheckConfig | None = None,
        unsupported_method: SimpleCheckConfig | None = None,
        allow_header_conformance: SimpleCheckConfig | None = None,
        max_response_time: MaxResponseTimeConfig | None = None,
    ) -> None:
        self.not_a_server_error = not_a_server_error or NotAServerErrorConfig()
        self.status_code_conformance = status_code_conformance or SimpleCheckConfig()
        self.content_type_conformance = content_type_conformance or SimpleCheckConfig()
        self.response_schema_conformance = response_schema_conformance or ResponseSchemaConformanceConfig()
        self.response_headers_conformance = response_headers_conformance or SimpleCheckConfig()
        self.positive_data_acceptance = positive_data_acceptance or PositiveDataAcceptanceConfig()
        self.negative_data_rejection = negative_data_rejection or NegativeDataRejectionConfig()
        self.use_after_free = use_after_free or SimpleCheckConfig()
        self.ensure_resource_availability = ensure_resource_availability or SimpleCheckConfig()
        self.missing_required_header = missing_required_header or MissingRequiredHeaderConfig()
        self.ignored_auth = ignored_auth or SimpleCheckConfig()
        self.unsupported_method = unsupported_method or SimpleCheckConfig()
        self.allow_header_conformance = allow_header_conformance or SimpleCheckConfig()
        self.max_response_time = max_response_time or MaxResponseTimeConfig()
        self._unknown = {}
        self._custom_kwargs = {}

    @property
    def custom_kwargs(self) -> dict[str, dict[str, Any]]:
        return self._custom_kwargs

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ChecksConfig:
        # Use the outer "enabled" value as default for all checks.
        default_enabled = data.get("enabled", None)

        def merge(sub: dict[str, Any]) -> dict[str, Any]:
            # Merge the default enabled flag with the sub-dict; the sub-dict takes precedence.
            if default_enabled is not None:
                return {"enabled": default_enabled, **sub}
            return sub

        _known_field_names = {f.name for f in fields(cls) if not f.name.startswith("_")}

        config = cls(
            not_a_server_error=NotAServerErrorConfig.from_dict(
                merge(data.get("not_a_server_error", {})),
            ),
            status_code_conformance=SimpleCheckConfig.from_dict(merge(data.get("status_code_conformance", {}))),
            content_type_conformance=SimpleCheckConfig.from_dict(merge(data.get("content_type_conformance", {}))),
            response_schema_conformance=ResponseSchemaConformanceConfig.from_dict(
                merge(data.get("response_schema_conformance", {}))
            ),
            response_headers_conformance=SimpleCheckConfig.from_dict(
                merge(data.get("response_headers_conformance", {}))
            ),
            positive_data_acceptance=PositiveDataAcceptanceConfig.from_dict(
                merge(data.get("positive_data_acceptance", {})),
            ),
            negative_data_rejection=NegativeDataRejectionConfig.from_dict(
                merge(data.get("negative_data_rejection", {})),
            ),
            use_after_free=SimpleCheckConfig.from_dict(merge(data.get("use_after_free", {}))),
            ensure_resource_availability=SimpleCheckConfig.from_dict(
                merge(data.get("ensure_resource_availability", {}))
            ),
            missing_required_header=MissingRequiredHeaderConfig.from_dict(
                merge(data.get("missing_required_header", {})),
            ),
            ignored_auth=SimpleCheckConfig.from_dict(merge(data.get("ignored_auth", {}))),
            unsupported_method=SimpleCheckConfig.from_dict(merge(data.get("unsupported_method", {}))),
            allow_header_conformance=SimpleCheckConfig.from_dict(merge(data.get("allow_header_conformance", {}))),
            max_response_time=MaxResponseTimeConfig(limit=data.get("max_response_time")),
        )
        for name, value in data.items():
            if name in _known_field_names:
                continue
            if not isinstance(value, dict):
                # Top-level non-dict values (e.g. `enabled = true`) are not custom check sections.
                continue
            enabled = value.get("enabled", True)
            kwargs = {k: v for k, v in value.items() if k != "enabled"}
            config._unknown[name] = SimpleCheckConfig(enabled=enabled)
            if kwargs:
                config._custom_kwargs[name] = kwargs
        return config

    @classmethod
    def from_hierarchy(cls, configs: list[ChecksConfig]) -> ChecksConfig:  # type: ignore[override]
        # Bare `super()` breaks under `@dataclass(slots=True)` on Python < 3.13.
        merged: ChecksConfig = DiffBase.from_hierarchy.__func__(cls, configs)  # type: ignore[attr-defined]
        names: set[str] = set()
        for config in configs:
            names.update(config._unknown)
            names.update(config._custom_kwargs)
        for name in names:
            sub_configs = [config._unknown.get(name, SimpleCheckConfig()) for config in configs]
            merged._unknown[name] = SimpleCheckConfig.from_hierarchy(sub_configs)
        custom_kwargs: dict[str, dict[str, Any]] = {}
        for config in reversed(configs):
            for name, kwargs in config._custom_kwargs.items():
                custom_kwargs.setdefault(name, {}).update(kwargs)
        merged._custom_kwargs = custom_kwargs
        return merged

    def get_by_name(self, *, name: str) -> CheckConfig | SimpleCheckConfig | MaxResponseTimeConfig:
        try:
            return getattr(self, name)
        except AttributeError:
            # Read-only: don't record unconfigured names, so `_unknown` stays user-declared.
            existing = self._unknown.get(name)
            return existing if existing is not None else SimpleCheckConfig()

    def _set_enabled(self, name: str, *, known_names: set[str], enabled: bool) -> None:
        if name in known_names:
            self.get_by_name(name=name).enabled = enabled
        else:
            self._unknown[name] = SimpleCheckConfig(enabled=enabled)

    def update(
        self,
        *,
        included_check_names: list[str] | None = None,
        excluded_check_names: list[str] | None = None,
        max_response_time: float | None = None,
    ) -> None:
        from schemathesis.checks import CHECKS

        known_names = {f.name for f in fields(self) if not f.name.startswith("_")}
        # Registered custom checks aren't dataclass fields; apply the same include/exclude rules to
        # them so `included_check_names` disables unlisted custom checks too, not just built-in ones.
        custom_names = set(CHECKS.get_all_names()) - known_names
        all_names = known_names | custom_names | set(included_check_names or []) | set(excluded_check_names or [])
        all_names.discard("all")

        for name in all_names:
            # Check in explicitly excluded or not in explicitly included
            if name in (excluded_check_names or []) or (
                included_check_names is not None
                and "all" not in included_check_names
                and name not in included_check_names
            ):
                self._set_enabled(name, known_names=known_names, enabled=False)
            elif included_check_names is not None and name in included_check_names:
                self._set_enabled(name, known_names=known_names, enabled=True)

        if max_response_time is not None:
            self.max_response_time.enabled = True
            self.max_response_time.limit = max_response_time
