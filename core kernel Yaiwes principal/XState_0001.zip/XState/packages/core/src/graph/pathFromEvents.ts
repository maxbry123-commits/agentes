import {
  ActorScope,
  ActorLogic,
  ActorSystem,
  AnyStateMachine,
  EventObject,
  Snapshot
} from '../index.ts';
import { getAdjacencyMap } from './adjacency.ts';
import {
  SerializedEvent,
  SerializedSnapshot,
  StatePath,
  Steps,
  TraversalOptions
} from './types.ts';
import {
  resolveTraversalOptions,
  createDefaultMachineOptions,
  createDefaultLogicOptions
} from './graph.ts';
import { alterPath } from './alterPath.ts';
import { createMockActorScope } from './actorScope.ts';

function isMachine(value: any): value is AnyStateMachine {
  return !!value && '__xstatenode' in value;
}

export function getPathsFromEvents<
  TSnapshot extends Snapshot<unknown>,
  TEvent extends EventObject,
  TInput,
  TSystem extends ActorSystem<any> = ActorSystem<any>
>(
  logic: ActorLogic<TSnapshot, TEvent, TInput, TSystem>,
  events: TEvent[],
  options?: TraversalOptions<TSnapshot, TEvent, TInput>
): Array<StatePath<TSnapshot, TEvent>> {
  const resolvedOptions = resolveTraversalOptions(
    logic,
    {
      events,
      ...options
    },
    (isMachine(logic)
      ? createDefaultMachineOptions(logic)
      : createDefaultLogicOptions()) as TraversalOptions<
      TSnapshot,
      TEvent,
      TInput
    >
  );
  const actorScope = createMockActorScope() as ActorScope<
    TSnapshot,
    TEvent,
    TSystem
  >;
  const fromState =
    resolvedOptions.fromState ??
    logic.getInitialSnapshot(
      actorScope,
      // TODO: fix this
      options?.input as TInput
    );

  const { serializeState, serializeEvent } = resolvedOptions;

  const adjacency = getAdjacencyMap(logic, resolvedOptions);

  const stateMap = new Map<SerializedSnapshot, TSnapshot>();
  const steps: Steps<TSnapshot, TEvent> = [];

  const serializedFromState = serializeState(
    fromState,
    undefined,
    undefined
  ) as SerializedSnapshot;
  stateMap.set(serializedFromState, fromState);

  let stateSerial = serializedFromState;
  let state = fromState;
  for (const event of events) {
    steps.push({
      state: stateMap.get(stateSerial)!,
      event
    });

    const eventSerial = serializeEvent(event) as SerializedEvent;
    const { state: nextState, event: _nextEvent } =
      adjacency[stateSerial].transitions[eventSerial];

    if (!nextState) {
      throw new Error(
        `Invalid transition from ${stateSerial} with ${eventSerial}`
      );
    }
    const prevState = stateMap.get(stateSerial);
    const nextStateSerial = serializeState(
      nextState,
      event,
      prevState
    ) as SerializedSnapshot;
    stateMap.set(nextStateSerial, nextState);

    stateSerial = nextStateSerial;
    state = nextState;
  }

  // If it is expected to reach a specific state (`toState`) and that state
  // isn't reached, there are no paths
  if (resolvedOptions.toState && !resolvedOptions.toState(state)) {
    return [];
  }

  return [
    alterPath({
      state,
      steps,
      weight: steps.length
    })
  ];
}
