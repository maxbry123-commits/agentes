import { createMachine, raise } from '../../index.ts';
import { createTestModel } from '../index.ts';

describe('Forbidden attributes', () => {
  it('Should not let you declare invocations on your test machine', () => {
    const machine = createMachine({
      invoke: {
        src: 'myInvoke'
      }
    });

    expect(() => {
      createTestModel(machine);
    }).toThrow('Invocations on test machines are not supported');
  });

  it('Should not let you declare after on your test machine', () => {
    const machine = createMachine({
      after: {
        5000: {
          actions: () => {}
        }
      }
    });

    expect(() => {
      createTestModel(machine);
    }).toThrow('After events on test machines are not supported');
  });

  it('Should not let you delayed actions on your machine', () => {
    const machine = createMachine({
      entry: [
        raise(
          {
            type: 'EVENT'
          },
          {
            delay: 1000
          }
        )
      ]
    });

    expect(() => {
      createTestModel(machine);
    }).toThrow('Delayed actions on test machines are not supported');
  });
});
