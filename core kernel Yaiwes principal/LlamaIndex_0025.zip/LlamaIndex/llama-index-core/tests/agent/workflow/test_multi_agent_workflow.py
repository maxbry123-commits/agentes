from typing import List

import pytest
from llama_index.core.agent.workflow import AgentInput
from llama_index.core.agent.workflow.function_agent import FunctionAgent
from llama_index.core.agent.workflow.multi_agent_workflow import AgentWorkflow
from llama_index.core.agent.workflow.react_agent import ReActAgent
from llama_index.core.llms import (
    ChatMessage,
    MessageRole,
)
from llama_index.core.llms.mock import MockFunctionCallingLLM
from llama_index.core.memory import ChatMemoryBuffer
from llama_index.core.tools import FunctionTool, ToolSelection
from workflows import Context
from workflows.events import (
    HumanResponseEvent,
    InputRequiredEvent,
)
from workflows.context import PickleSerializer
from llama_index.core.workflow.errors import WorkflowRuntimeError


def _response_generator_from_list(responses: List[ChatMessage]):
    """Helper to create a response generator from a list of responses."""
    index = 0

    def generator(messages: List[ChatMessage], **kwargs) -> ChatMessage:
        nonlocal index
        if not responses:
            return ChatMessage(role=MessageRole.ASSISTANT, content=None)
        msg = responses[index]
        index = (index + 1) % len(responses)
        return msg

    return generator


def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


def subtract(a: int, b: int) -> int:
    """Subtract two numbers."""
    return a - b


@pytest.fixture()
def calculator_agent():
    return ReActAgent(
        name="calculator",
        description="Performs basic arithmetic operations",
        system_prompt="You are a calculator assistant.",
        tools=[
            FunctionTool.from_defaults(fn=add),
            FunctionTool.from_defaults(fn=subtract),
        ],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content='Thought: I need to add these numbers\nAction: add\nAction Input: {"a": 5, "b": 3}\n',
                    ),
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content=r"Thought: The result is 8\Answer: The sum is 8",
                    ),
                ]
            )
        ),
    )


@pytest.fixture()
def empty_calculator_agent():
    return ReActAgent(
        name="calculator",
        description="Performs basic arithmetic operations",
        system_prompt="You are a calculator assistant.",
        tools=[
            FunctionTool.from_defaults(fn=add),
            FunctionTool.from_defaults(fn=subtract),
        ],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list([])
        ),
    )


@pytest.fixture()
def retriever_agent():
    return FunctionAgent(
        name="retriever",
        description="Manages data retrieval",
        system_prompt="You are a retrieval assistant.",
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="Let me help you with that calculation. I'll hand this off to the calculator.",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="handoff",
                                    tool_kwargs={
                                        "to_agent": "calculator",
                                        "reason": "This requires arithmetic operations.",
                                    },
                                )
                            ]
                        },
                    ),
                ]
            )
        ),
    )


@pytest.fixture()
def empty_retriever_agent():
    return FunctionAgent(
        name="retriever",
        description="Manages data retrieval",
        system_prompt="You are a retrieval assistant.",
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list([])
        ),
    )


@pytest.mark.asyncio
async def test_basic_workflow(calculator_agent, retriever_agent):
    """Test basic workflow initialization and validation."""
    workflow = AgentWorkflow(
        agents=[calculator_agent, retriever_agent],
        root_agent="retriever",
    )

    assert workflow.root_agent == retriever_agent.name
    assert len(workflow.agents) == 2
    assert "calculator" in workflow.agents
    assert "retriever" in workflow.agents


@pytest.mark.asyncio
async def test_workflow_requires_root_agent():
    """Test that workflow requires exactly one root agent."""
    with pytest.raises(ValueError, match="Exactly one root agent must be provided"):
        AgentWorkflow(
            agents=[
                FunctionAgent(
                    name="agent1",
                    description="test",
                    llm=MockFunctionCallingLLM(
                        response_generator=_response_generator_from_list(
                            [
                                ChatMessage(role=MessageRole.ASSISTANT, content="test"),
                            ]
                        )
                    ),
                ),
                ReActAgent(
                    name="agent2",
                    description="test",
                    llm=MockFunctionCallingLLM(
                        response_generator=_response_generator_from_list(
                            [
                                ChatMessage(role=MessageRole.ASSISTANT, content="test"),
                            ]
                        )
                    ),
                ),
            ]
        )


@pytest.mark.asyncio
async def test_workflow_execution(calculator_agent, retriever_agent):
    """Test basic workflow execution with agent handoff."""
    workflow = AgentWorkflow(
        agents=[calculator_agent, retriever_agent],
        root_agent="retriever",
    )

    memory = ChatMemoryBuffer.from_defaults()
    handler = workflow.run(user_msg="Can you add 5 and 3?", memory=memory)

    events = []
    async for event in handler.stream_events():
        events.append(event)

    response = await handler

    # Verify we got events indicating handoff and calculation
    assert any(
        ev.current_agent_name == "retriever"
        if hasattr(ev, "current_agent_name")
        else False
        for ev in events
    )
    assert any(
        ev.current_agent_name == "calculator"
        if hasattr(ev, "current_agent_name")
        else False
        for ev in events
    )
    assert "8" in str(response.response)


@pytest.mark.asyncio
async def test_workflow_execution_empty(empty_calculator_agent, retriever_agent):
    """Test basic workflow execution with agent handoff."""
    workflow = AgentWorkflow(
        agents=[empty_calculator_agent, retriever_agent],
        root_agent="retriever",
    )

    memory = ChatMemoryBuffer.from_defaults()
    handler = workflow.run(user_msg="Can you add 5 and 3?", memory=memory)

    contains_error_message = False
    async for event in handler.stream_events():
        if isinstance(event, AgentInput):
            if "FAILURE: Your previous response was empty" in event.input[-1].content:
                contains_error_message = True

    assert contains_error_message


@pytest.mark.asyncio
async def test_workflow_handoff_empty(calculator_agent, empty_retriever_agent):
    """Test basic workflow execution with agent handoff."""
    workflow = AgentWorkflow(
        agents=[calculator_agent, empty_retriever_agent],
        root_agent="retriever",
    )

    memory = ChatMemoryBuffer.from_defaults()
    handler = workflow.run(user_msg="Can you add 5 and 3?", memory=memory)

    events = []
    async for event in handler.stream_events():
        events.append(event)

    response = await handler
    assert response.response.content is None


@pytest.mark.asyncio
async def test_invalid_handoff():
    """Test handling of invalid agent handoff."""
    agent1 = FunctionAgent(
        name="agent1",
        description="test",
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="handoff invalid_agent Because reasons",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="handoff",
                                    tool_kwargs={
                                        "to_agent": "invalid_agent",
                                        "reason": "Because reasons",
                                    },
                                )
                            ]
                        },
                    ),
                    ChatMessage(
                        role=MessageRole.ASSISTANT, content="guess im stuck here"
                    ),
                ]
            )
        ),
    )

    agent2 = FunctionAgent(
        **agent1.model_dump(exclude={"llm"}),
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list([])
        ),
    )
    agent2.name = "agent2"

    workflow = AgentWorkflow(
        agents=[agent1, agent2],
        root_agent="agent1",
    )

    handler = workflow.run(user_msg="test")
    events = []
    async for event in handler.stream_events():
        events.append(event)

    response = await handler
    assert "Agent invalid_agent not found" in str(events)


@pytest.mark.asyncio
async def test_workflow_with_state():
    """Test workflow with state management."""

    async def modify_state(random_arg: str, ctx_val: Context):
        state = await ctx_val.store.get("state")
        state["counter"] += 1
        await ctx_val.store.set("state", state)
        return f"State updated to {state}"

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[modify_state],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="handing off",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="modify_state",
                                    tool_kwargs={"random_arg": "hello"},
                                )
                            ]
                        },
                    ),
                    ChatMessage(
                        role=MessageRole.ASSISTANT, content="Current state processed"
                    ),
                ]
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
        initial_state={"counter": 0},
        state_prompt="Current state: {state}. User message: {msg}",
    )

    handler = workflow.run(user_msg="test")
    async for ev in handler.stream_events():
        if isinstance(ev, AgentInput):
            for msg in ev.input:
                if msg.role == MessageRole.USER:
                    # ensure we've only formatted the input once
                    assert len(msg.content.split("Current state:")) == 2

    response = await handler
    assert response is not None

    state = await handler.ctx.store.get("state")
    assert state["counter"] == 1


@pytest.mark.asyncio
async def test_agent_with_hitl():
    """Test agent with hitl."""

    async def hitl(ctx: Context):
        resp = await ctx.wait_for_event(
            HumanResponseEvent,
            waiter_event=InputRequiredEvent(prefix="What is your name?"),
        )
        return f"Your name is {resp.response}"

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[hitl],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="handing off",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="hitl",
                                    tool_kwargs={},
                                )
                            ]
                        },
                    ),
                    ChatMessage(role=MessageRole.ASSISTANT, content="HITL successful"),
                ]
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
        root_agent="agent",
    )

    handler = workflow.run(user_msg="test")
    ctx_dict = None
    async for ev in handler.stream_events():
        if isinstance(ev, InputRequiredEvent):
            ctx_dict = handler.ctx.to_dict()
            await handler.cancel_run()
            break

    new_ctx = Context.from_dict(workflow, ctx_dict)
    handler = workflow.run(user_msg="test", ctx=new_ctx)
    handler.ctx.send_event(HumanResponseEvent(response="John Doe"))

    response = await handler

    assert response is not None
    assert "HITL successful" in str(response)


@pytest.mark.asyncio
async def test_max_iterations():
    """Test max iterations."""

    def random_tool() -> str:
        return "random"

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[random_tool],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="handing off",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="random_tool",
                                    tool_kwargs={},
                                )
                            ]
                        },
                    ),
                ]
                * 100
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
    )

    # Default max iterations is 20
    with pytest.raises(WorkflowRuntimeError, match="Either something went wrong"):
        _ = await workflow.run(user_msg="test")

    # Set max iterations to 101 to avoid error
    _ = workflow.run(user_msg="test", max_iterations=101)


@pytest.mark.asyncio
async def test_early_stopping_method_generate_multi_agent():
    """Test early_stopping_method='generate' in AgentWorkflow produces a final response."""

    def random_tool() -> str:
        return "random"

    tool_call_response = ChatMessage(
        role=MessageRole.ASSISTANT,
        content="calling tool",
        additional_kwargs={
            "tool_calls": [
                ToolSelection(
                    tool_id="one",
                    tool_name="random_tool",
                    tool_kwargs={},
                )
            ]
        },
    )
    final_response = ChatMessage(
        role=MessageRole.ASSISTANT,
        content="Here is my final summary based on the information gathered.",
    )

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[random_tool],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [tool_call_response] * 5 + [final_response]
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
        early_stopping_method="generate",
    )

    # With early_stopping_method="generate", should NOT raise error
    handler = workflow.run(user_msg="test", max_iterations=5)
    async for _ in handler.stream_events():
        pass

    response = await handler
    assert response is not None


@pytest.mark.asyncio
async def test_early_stopping_method_override_in_run_multi_agent():
    """Test early_stopping_method can be overridden in run() for AgentWorkflow."""

    def random_tool() -> str:
        return "random"

    tool_call_response = ChatMessage(
        role=MessageRole.ASSISTANT,
        content="calling tool",
        additional_kwargs={
            "tool_calls": [
                ToolSelection(
                    tool_id="one",
                    tool_name="random_tool",
                    tool_kwargs={},
                )
            ]
        },
    )
    final_response = ChatMessage(
        role=MessageRole.ASSISTANT,
        content="Final response after early stopping.",
    )

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[random_tool],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [tool_call_response] * 5 + [final_response]
            )
        ),
    )

    # Workflow defaults to "force"
    workflow = AgentWorkflow(
        agents=[agent],
        early_stopping_method="force",
    )

    # Override to "generate" in run()
    handler = workflow.run(
        user_msg="test",
        max_iterations=5,
        early_stopping_method="generate",
    )
    async for _ in handler.stream_events():
        pass

    response = await handler
    assert response is not None


@pytest.mark.asyncio
async def test_workflow_pickle_serialize_and_resume():
    """Pause workflow, pickle-serialize context, and resume from serialized context."""

    async def hitl(ctx: Context):
        resp = await ctx.wait_for_event(
            HumanResponseEvent,
            waiter_event=InputRequiredEvent(prefix="Provide your name to continue"),
        )
        return f"Your name is {resp.response}"

    agent = FunctionAgent(
        name="agent",
        description="test",
        tools=[hitl],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content="handing off",
                        additional_kwargs={
                            "tool_calls": [
                                ToolSelection(
                                    tool_id="one",
                                    tool_name="hitl",
                                    tool_kwargs={},
                                )
                            ]
                        },
                    ),
                    ChatMessage(role=MessageRole.ASSISTANT, content="HITL successful"),
                ]
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
        root_agent="agent",
    )

    handler = workflow.run(user_msg="test")

    # Wait for pause point, then serialize context with pickle serializer via to_dict
    ctx_dict = None
    async for ev in handler.stream_events():
        if isinstance(ev, InputRequiredEvent):
            serializer = PickleSerializer()
            ctx_dict = handler.ctx.to_dict(serializer=serializer)

            await handler.cancel_run()
            break

    assert ctx_dict is not None

    # Deserialize context and resume workflow using from_dict with serializer
    serializer = PickleSerializer()
    new_ctx = Context.from_dict(workflow, ctx_dict, serializer=serializer)

    handler = workflow.run(user_msg="test", ctx=new_ctx)
    handler.ctx.send_event(HumanResponseEvent(response="Jane Doe"))

    response = await handler

    assert response is not None
    assert "HITL successful" in str(response)


@pytest.mark.asyncio
async def test_retry():
    """Test retry."""

    def add_tool(a: int, b: int) -> int:
        return a + b

    agent = ReActAgent(
        name="agent",
        description="test",
        tools=[add_tool],
        llm=MockFunctionCallingLLM(
            response_generator=_response_generator_from_list(
                [
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content='Thought: I need to add these numbers\nAction: add\n{"a": 5 "b": 3}\n',
                    ),
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content='Thought: I need to add these numbers\nAction: add\nAction Input: {"a": 5, "b": 3}\n',
                    ),
                    ChatMessage(
                        role=MessageRole.ASSISTANT,
                        content=r"Thought: The result is 8\Answer: The sum is 8",
                    ),
                ]
            )
        ),
    )

    workflow = AgentWorkflow(
        agents=[agent],
    )

    memory = ChatMemoryBuffer.from_defaults()
    handler = workflow.run(user_msg="Can you add 5 and 3?", memory=memory)

    events = []
    contains_error_message = False
    async for event in handler.stream_events():
        events.append(event)
        if isinstance(event, AgentInput):
            if "Error while parsing the output" in event.input[-1].content:
                contains_error_message = True

    assert contains_error_message

    response = await handler

    assert "8" in str(response.response)


@pytest.mark.asyncio
async def test_run_id_passthrough(
    empty_calculator_agent: ReActAgent, empty_retriever_agent: FunctionAgent
) -> None:
    """Test that run_id kwarg is forwarded to the WorkflowHandler."""
    workflow = AgentWorkflow(
        agents=[empty_calculator_agent, empty_retriever_agent],
        root_agent="calculator",
    )

    custom_run_id = "test-run-id-12345"
    handler = workflow.run(user_msg="hello", run_id=custom_run_id)
    assert handler.run_id == custom_run_id
    handler.cancel()


@pytest.mark.asyncio
async def test_run_id_default(
    empty_calculator_agent: ReActAgent, empty_retriever_agent: FunctionAgent
) -> None:
    """Test that omitting run_id still generates one automatically."""
    workflow = AgentWorkflow(
        agents=[empty_calculator_agent, empty_retriever_agent],
        root_agent="calculator",
    )

    handler = workflow.run(user_msg="hello")
    assert handler.run_id is not None
    assert isinstance(handler.run_id, str)
    handler.cancel()
