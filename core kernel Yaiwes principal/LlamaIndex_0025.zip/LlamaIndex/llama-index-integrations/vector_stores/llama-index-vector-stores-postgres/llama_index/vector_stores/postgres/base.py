import logging
import re
from typing import (
    Any,
    Dict,
    List,
    NamedTuple,
    Optional,
    Type,
    Union,
    Set,
    Tuple,
    Literal,
    Callable,
)

import asyncpg  # noqa
import pgvector  # noqa
from pgvector.sqlalchemy import HALFVEC
import psycopg2  # noqa
import sqlalchemy
import sqlalchemy.ext.asyncio
from llama_index.core.bridge.pydantic import PrivateAttr
from llama_index.core.schema import BaseNode, MetadataMode, TextNode
from llama_index.core.indices.query.embedding_utils import get_top_k_mmr_embeddings
from llama_index.core.vector_stores.types import (
    BasePydanticVectorStore,
    FilterOperator,
    MetadataFilters,
    MetadataFilter,
    VectorStoreQuery,
    VectorStoreQueryMode,
    VectorStoreQueryResult,
)
from llama_index.core.vector_stores.utils import (
    metadata_dict_to_node,
    node_to_metadata_dict,
)

DEFAULT_MMR_PREFETCH_FACTOR = 4.0

from sqlalchemy import text, select
from sqlalchemy.sql.selectable import Select

PGType = Literal[
    "text",
    "int",
    "integer",
    "numeric",
    "float",
    "double precision",
    "boolean",
    "date",
    "timestamp",
    "uuid",
    # Array type for GIN indexing
    "text[]",
]


class DBEmbeddingRow(NamedTuple):
    node_id: str
    text: str
    metadata: dict
    custom_fields: dict
    similarity: float


_logger = logging.getLogger(__name__)


def get_data_model(
    base: Type,
    index_name: str,
    schema_name: str,
    hybrid_search: bool,
    text_search_config: str,
    cache_okay: bool,
    embed_dim: int = 1536,
    use_jsonb: bool = False,
    use_halfvec: bool = False,
    indexed_metadata_keys: Optional[Set[Tuple[str, PGType]]] = None,
) -> Any:
    """
    This part create a dynamic sqlalchemy model with a new table.
    """
    from pgvector.sqlalchemy import Vector
    from sqlalchemy import Column, Computed
    from sqlalchemy.dialects.postgresql import (
        ARRAY,
        BIGINT,
        JSON,
        JSONB,
        TSVECTOR,
        VARCHAR,
        UUID,
        DOUBLE_PRECISION,
    )
    from sqlalchemy import cast, column
    from sqlalchemy import String, Integer, Numeric, Float, Boolean, Date, DateTime
    from sqlalchemy.schema import Index
    from sqlalchemy.types import TypeDecorator

    pg_type_map = {
        "text": String,
        "int": Integer,
        "integer": Integer,
        "numeric": Numeric,
        "float": Float,
        "double precision": DOUBLE_PRECISION,  # or Float(precision=53)
        "boolean": Boolean,
        "date": Date,
        "timestamp": DateTime,
        "uuid": UUID,
        # Array type for GIN indexing
        "text[]": ARRAY(String),
    }

    indexed_metadata_keys = indexed_metadata_keys or set()
    # check that types are in pg_type_map
    for key, pg_type in indexed_metadata_keys:
        if pg_type not in pg_type_map:
            raise ValueError(
                f"Invalid type {pg_type} for key {key}. "
                f"Must be one of {list(pg_type_map.keys())}"
            )

    class TSVector(TypeDecorator):
        impl = TSVECTOR
        cache_ok = cache_okay

    tablename = "data_%s" % index_name  # dynamic table name
    class_name = "Data%s" % index_name  # dynamic class name
    indexname = "%s_idx" % index_name  # dynamic class name

    metadata_dtype = JSONB if use_jsonb else JSON

    if use_halfvec:
        embedding_col = Column(HALFVEC(embed_dim))  # type: ignore
    else:
        embedding_col = Column(Vector(embed_dim))  # type: ignore

    # BTREE indices for scalar types (existing behavior)
    btree_indices = [
        Index(
            f"{indexname}_{key}_{pg_type.replace(' ', '_')}",
            cast(column("metadata_").op("->>")(key), pg_type_map[pg_type]),
            postgresql_using="btree",
        )
        for key, pg_type in indexed_metadata_keys
        if pg_type != "text[]"
    ]

    # GIN indices for text arrays (enables fast array operations with ?|, ?&, @> operators)
    gin_indices = [
        Index(
            f"{indexname}_{key}_gin",
            cast(
                column("metadata_").op("->")(key), JSONB
            ),  # Cast to JSONB for GIN index compatibility
            postgresql_using="gin",
        )
        for key, pg_type in indexed_metadata_keys
        if pg_type == "text[]"
    ]

    # Combine both types of indices
    metadata_indices = btree_indices + gin_indices

    if hybrid_search:

        class HybridAbstractData(base):  # type: ignore
            __abstract__ = True  # this line is necessary
            id = Column(BIGINT, primary_key=True, autoincrement=True)
            text = Column(VARCHAR, nullable=False)
            metadata_ = Column(metadata_dtype)
            node_id = Column(VARCHAR)
            embedding = embedding_col
            text_search_tsv = Column(  # type: ignore
                TSVector(),
                Computed(
                    "to_tsvector('%s', text)" % text_search_config, persisted=True
                ),
            )

        model = type(
            class_name,
            (HybridAbstractData,),
            {
                "__tablename__": tablename,
                "__table_args__": (*metadata_indices, {"schema": schema_name}),
            },
        )

        Index(
            indexname,
            model.text_search_tsv,  # type: ignore
            postgresql_using="gin",
        )
        Index(
            f"{indexname}_1",
            model.metadata_["ref_doc_id"].astext,  # type: ignore
            postgresql_using="btree",
        )
    else:

        class AbstractData(base):  # type: ignore
            __abstract__ = True  # this line is necessary
            id = Column(BIGINT, primary_key=True, autoincrement=True)
            text = Column(VARCHAR, nullable=False)
            metadata_ = Column(metadata_dtype)
            node_id = Column(VARCHAR)
            embedding = embedding_col

        model = type(
            class_name,
            (AbstractData,),
            {
                "__tablename__": tablename,
                "__table_args__": (*metadata_indices, {"schema": schema_name}),
            },
        )

        Index(
            f"{indexname}_1",
            model.metadata_["ref_doc_id"].astext,  # type: ignore
            postgresql_using="btree",
        )

    return model


class PGVectorStore(BasePydanticVectorStore):
    """
    Postgres Vector Store.

    Examples:
        `pip install llama-index-vector-stores-postgres`

        ```python
        from llama_index.vector_stores.postgres import PGVectorStore

        # Create PGVectorStore instance
        vector_store = PGVectorStore.from_params(
            database="vector_db",
            host="localhost",
            password="password",
            port=5432,
            user="postgres",
            table_name="paul_graham_essay",
            embed_dim=1536  # openai embedding dimension
            use_halfvec=True  # Enable half precision
        )
        ```

    """

    stores_text: bool = True
    flat_metadata: bool = False

    connection_string: str
    async_connection_string: str
    table_name: str
    schema_name: str
    embed_dim: int
    hybrid_search: bool
    text_search_config: str
    cache_ok: bool
    perform_setup: bool
    debug: bool
    use_jsonb: bool
    create_engine_kwargs: Dict
    initialization_fail_on_error: bool = False
    indexed_metadata_keys: Optional[Set[Tuple[str, PGType]]] = None

    hnsw_kwargs: Optional[Dict[str, Any]]

    use_halfvec: bool = False

    _base: Any = PrivateAttr()
    _table_class: Any = PrivateAttr()
    _engine: Optional[sqlalchemy.engine.Engine] = PrivateAttr(default=None)
    _session: sqlalchemy.orm.Session = PrivateAttr()
    _async_engine: Optional[sqlalchemy.ext.asyncio.AsyncEngine] = PrivateAttr(
        default=None
    )
    _async_session: sqlalchemy.ext.asyncio.AsyncSession = PrivateAttr()
    _is_initialized: bool = PrivateAttr(default=False)
    _customize_query_fn: Optional[Callable[[Select, Any, Any], Select]] = PrivateAttr(
        default=None
    )

    def __init__(
        self,
        connection_string: Optional[Union[str, sqlalchemy.engine.URL]] = None,
        async_connection_string: Optional[Union[str, sqlalchemy.engine.URL]] = None,
        table_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        hybrid_search: bool = False,
        text_search_config: str = "english",
        embed_dim: int = 1536,
        cache_ok: bool = False,
        perform_setup: bool = True,
        debug: bool = False,
        use_jsonb: bool = False,
        hnsw_kwargs: Optional[Dict[str, Any]] = None,
        create_engine_kwargs: Optional[Dict[str, Any]] = None,
        initialization_fail_on_error: bool = False,
        use_halfvec: bool = False,
        engine: Optional[sqlalchemy.engine.Engine] = None,
        async_engine: Optional[sqlalchemy.ext.asyncio.AsyncEngine] = None,
        indexed_metadata_keys: Optional[Set[Tuple[str, PGType]]] = None,
        customize_query_fn: Optional[Callable[[Select, Any, Any], Select]] = None,
    ) -> None:
        """
        Constructor.

        Args:
            connection_string (Union[str, sqlalchemy.engine.URL]): Connection string to postgres db.
            async_connection_string (Union[str, sqlalchemy.engine.URL]): Connection string to async pg db.
            table_name (str): Table name.
            schema_name (str): Schema name.
            hybrid_search (bool, optional): Enable hybrid search. Defaults to False.
            text_search_config (str, optional): Text search configuration. Defaults to "english".
            embed_dim (int, optional): Embedding dimensions. Defaults to 1536.
            cache_ok (bool, optional): Enable cache. Defaults to False.
            perform_setup (bool, optional): If db should be set up. Defaults to True.
            debug (bool, optional): Debug mode. Defaults to False.
            use_jsonb (bool, optional): Use JSONB instead of JSON. Defaults to False.
            hnsw_kwargs (Optional[Dict[str, Any]], optional): HNSW kwargs, a dict that
                contains "hnsw_ef_construction", "hnsw_ef_search", "hnsw_m", and optionally "hnsw_dist_method". Defaults to None,
                which turns off HNSW search.
            create_engine_kwargs (Optional[Dict[str, Any]], optional): Engine parameters to pass to create_engine. Defaults to None.
            use_halfvec (bool, optional): If `True`, use half-precision vectors. Defaults to False.
            engine (Optional[sqlalchemy.engine.Engine], optional): SQLAlchemy engine instance to use. Defaults to None.
            async_engine (Optional[sqlalchemy.ext.asyncio.AsyncEngine], optional): SQLAlchemy async engine instance to use. Defaults to None.
            indexed_metadata_keys (Optional[List[Tuple[str, str]]], optional): Set of metadata keys with their type to index. Defaults to None.
            customize_query_fn (Optional[Callable[[Select, Any, Any], Select]], optional): Function used to customize PostgreSQL queries. Defaults to None.

        """
        table_name = table_name.lower() if table_name else "llamaindex"
        schema_name = schema_name.lower() if schema_name else "public"

        if hybrid_search and text_search_config is None:
            raise ValueError(
                "Sparse vector index creation requires "
                "a text search configuration specification."
            )

        from sqlalchemy.orm import declarative_base

        super().__init__(
            connection_string=str(connection_string),
            async_connection_string=str(async_connection_string),
            table_name=table_name,
            schema_name=schema_name,
            hybrid_search=hybrid_search,
            text_search_config=text_search_config,
            embed_dim=embed_dim,
            cache_ok=cache_ok,
            perform_setup=perform_setup,
            debug=debug,
            use_jsonb=use_jsonb,
            hnsw_kwargs=hnsw_kwargs,
            create_engine_kwargs=create_engine_kwargs or {},
            initialization_fail_on_error=initialization_fail_on_error,
            use_halfvec=use_halfvec,
            indexed_metadata_keys=indexed_metadata_keys,
        )

        # sqlalchemy model
        self._base = declarative_base()
        self._table_class = get_data_model(
            self._base,
            table_name,
            schema_name,
            hybrid_search,
            text_search_config,
            cache_ok,
            embed_dim=embed_dim,
            use_jsonb=use_jsonb,
            use_halfvec=use_halfvec,
            indexed_metadata_keys=indexed_metadata_keys,
        )

        # both engine and async_engine must be provided, or both must be None
        if engine is not None and async_engine is not None:
            self._engine = engine
            self._async_engine = async_engine
        elif engine is None and async_engine is None:
            pass
        else:
            raise ValueError(
                "Both engine and async_engine must be provided, or both must be None"
            )

        self._customize_query_fn = customize_query_fn

    async def close(self) -> None:
        if not self._is_initialized:
            return

        if self._engine:
            self._engine.dispose()
        if self._async_engine:
            await self._async_engine.dispose()

    @classmethod
    def class_name(cls) -> str:
        return "PGVectorStore"

    @classmethod
    def from_params(
        cls,
        host: Optional[str] = None,
        port: Optional[str] = None,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        table_name: str = "llamaindex",
        schema_name: str = "public",
        connection_string: Optional[Union[str, sqlalchemy.engine.URL]] = None,
        async_connection_string: Optional[Union[str, sqlalchemy.engine.URL]] = None,
        hybrid_search: bool = False,
        text_search_config: str = "english",
        embed_dim: int = 1536,
        cache_ok: bool = False,
        perform_setup: bool = True,
        debug: bool = False,
        use_jsonb: bool = False,
        hnsw_kwargs: Optional[Dict[str, Any]] = None,
        create_engine_kwargs: Optional[Dict[str, Any]] = None,
        use_halfvec: bool = False,
        indexed_metadata_keys: Optional[Set[Tuple[str, PGType]]] = None,
        customize_query_fn: Optional[Callable[[Select, Any, Any], Select]] = None,
    ) -> "PGVectorStore":
        """
        Construct from params.

        Args:
            host (Optional[str], optional): Host of postgres connection. Defaults to None.
            port (Optional[str], optional): Port of postgres connection. Defaults to None.
            database (Optional[str], optional): Postgres DB name. Defaults to None.
            user (Optional[str], optional): Postgres username. Defaults to None.
            password (Optional[str], optional): Postgres password. Defaults to None.
            table_name (str): Table name. Defaults to "llamaindex".
            schema_name (str): Schema name. Defaults to "public".
            connection_string (Union[str, sqlalchemy.engine.URL]): Connection string to postgres db
            async_connection_string (Union[str, sqlalchemy.engine.URL]): Connection string to async pg db
            hybrid_search (bool, optional): Enable hybrid search. Defaults to False.
            text_search_config (str, optional): Text search configuration. Defaults to "english".
            embed_dim (int, optional): Embedding dimensions. Defaults to 1536.
            cache_ok (bool, optional): Enable cache. Defaults to False.
            perform_setup (bool, optional): If db should be set up. Defaults to True.
            debug (bool, optional): Debug mode. Defaults to False.
            use_jsonb (bool, optional): Use JSONB instead of JSON. Defaults to False.
            hnsw_kwargs (Optional[Dict[str, Any]], optional): HNSW kwargs, a dict that
                contains "hnsw_ef_construction", "hnsw_ef_search", "hnsw_m", and optionally "hnsw_dist_method". Defaults to None,
                which turns off HNSW search.
            create_engine_kwargs (Optional[Dict[str, Any]], optional): Engine parameters to pass to create_engine. Defaults to None.
            use_halfvec (bool, optional): If `True`, use half-precision vectors. Defaults to False.
            indexed_metadata_keys (Optional[Set[Tuple[str, str]]], optional): Set of metadata keys to index. Defaults to None.
            customize_query_fn (Optional[Callable[[Select, Any, Any], Select]], optional): Function used to customize PostgreSQL queries. Defaults to None.

        Returns:
            PGVectorStore: Instance of PGVectorStore constructed from params.

        """
        conn_str = (
            connection_string
            or f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{database}"
        )
        async_conn_str = async_connection_string or (
            f"postgresql+asyncpg://{user}:{password}@{host}:{port}/{database}"
        )
        return cls(
            connection_string=conn_str,
            async_connection_string=async_conn_str,
            table_name=table_name,
            schema_name=schema_name,
            hybrid_search=hybrid_search,
            text_search_config=text_search_config,
            embed_dim=embed_dim,
            cache_ok=cache_ok,
            perform_setup=perform_setup,
            debug=debug,
            use_jsonb=use_jsonb,
            hnsw_kwargs=hnsw_kwargs,
            create_engine_kwargs=create_engine_kwargs,
            use_halfvec=use_halfvec,
            indexed_metadata_keys=indexed_metadata_keys,
            customize_query_fn=customize_query_fn,
        )

    @property
    def client(self) -> Any:
        if not self._is_initialized:
            return None
        return self._engine

    def _connect(self) -> Any:
        from sqlalchemy import create_engine
        from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
        from sqlalchemy.orm import sessionmaker

        self._engine = self._engine or create_engine(
            self.connection_string, echo=self.debug, **self.create_engine_kwargs
        )
        self._session = sessionmaker(self._engine)

        self._async_engine = self._async_engine or create_async_engine(
            self.async_connection_string, **self.create_engine_kwargs
        )
        self._async_session = sessionmaker(self._async_engine, class_=AsyncSession)  # type: ignore

    def _create_schema_if_not_exists(self) -> bool:
        """
        Create the schema if it does not exist.
        Returns True if the schema was created, False if it already existed.
        """
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", self.schema_name):
            raise ValueError(f"Invalid schema_name: {self.schema_name}")
        with self._session() as session, session.begin():
            # Check if the specified schema exists with "CREATE" statement
            check_schema_statement = sqlalchemy.text(
                f"SELECT schema_name FROM information_schema.schemata WHERE schema_name = :schema_name"
            ).bindparams(schema_name=self.schema_name)
            result = session.execute(check_schema_statement).fetchone()

            # If the schema does not exist, then create it
            schema_doesnt_exist = result is None
            if schema_doesnt_exist:
                create_schema_statement = sqlalchemy.text(
                    # DDL won't tolerate quoted string literal here for schema_name,
                    # so use a format string to embed the schema_name directly, instead of a param.
                    f"CREATE SCHEMA IF NOT EXISTS {self.schema_name}"
                )
                session.execute(create_schema_statement)

            session.commit()
            return schema_doesnt_exist

    def _create_tables_if_not_exists(self) -> None:
        with self._session() as session, session.begin():
            self._table_class.__table__.create(session.connection(), checkfirst=True)

    def _create_extension(self) -> None:
        import sqlalchemy

        with self._session() as session, session.begin():
            statement = sqlalchemy.text("CREATE EXTENSION IF NOT EXISTS vector")
            session.execute(statement)
            session.commit()

    def _create_hnsw_index(self) -> None:
        import sqlalchemy

        if (
            "hnsw_ef_construction" not in self.hnsw_kwargs
            or "hnsw_m" not in self.hnsw_kwargs
        ):
            raise ValueError(
                "Make sure hnsw_ef_search, hnsw_ef_construction, and hnsw_m are in hnsw_kwargs."
            )

        hnsw_ef_construction = self.hnsw_kwargs.pop("hnsw_ef_construction")
        hnsw_m = self.hnsw_kwargs.pop("hnsw_m")

        # If user didn’t specify an operator, pick a default based on whether halfvec is used
        if "hnsw_dist_method" in self.hnsw_kwargs:
            hnsw_dist_method = self.hnsw_kwargs.pop("hnsw_dist_method")
        else:
            if self.use_halfvec:
                hnsw_dist_method = "halfvec_l2_ops"
            else:
                # Default to vector_cosine_ops
                hnsw_dist_method = "vector_cosine_ops"

        index_name = f"{self._table_class.__tablename__}_embedding_idx"

        with self._session() as session, session.begin():
            statement = sqlalchemy.text(
                f"CREATE INDEX IF NOT EXISTS {index_name} "
                f"ON {self.schema_name}.{self._table_class.__tablename__} "
                f"USING hnsw (embedding {hnsw_dist_method}) "
                f"WITH (m = {hnsw_m}, ef_construction = {hnsw_ef_construction})"
            )
            session.execute(statement)
            session.commit()

    def _initialize(self) -> None:
        fail_on_error = self.initialization_fail_on_error
        if not self._is_initialized:
            self._connect()
            if self.perform_setup:
                try:
                    self._create_schema_if_not_exists()
                except Exception as e:
                    _logger.warning(f"PG Setup: Error creating schema: {e}")
                    if fail_on_error:
                        raise
                try:
                    self._create_extension()
                except Exception as e:
                    _logger.warning(f"PG Setup: Error creating extension: {e}")
                    if fail_on_error:
                        raise
                try:
                    self._create_tables_if_not_exists()
                except Exception as e:
                    _logger.warning(f"PG Setup: Error creating tables: {e}")
                    if fail_on_error:
                        raise
                if self.hnsw_kwargs is not None:
                    try:
                        self._create_hnsw_index()
                    except Exception as e:
                        _logger.warning(f"PG Setup: Error creating HNSW index: {e}")
                        if fail_on_error:
                            raise
            self._is_initialized = True

    def _node_to_table_row(self, node: BaseNode) -> Any:
        return self._table_class(
            node_id=node.node_id,
            embedding=node.get_embedding(),
            text=node.get_content(metadata_mode=MetadataMode.NONE),
            metadata_=node_to_metadata_dict(
                node,
                remove_text=True,
                flat_metadata=self.flat_metadata,
            ),
        )

    def add(self, nodes: List[BaseNode], **add_kwargs: Any) -> List[str]:
        self._initialize()
        ids = []
        with self._session() as session, session.begin():
            for node in nodes:
                ids.append(node.node_id)
                item = self._node_to_table_row(node)
                session.add(item)
            session.commit()
        return ids

    async def async_add(self, nodes: List[BaseNode], **kwargs: Any) -> List[str]:
        self._initialize()
        ids = []
        async with self._async_session() as session, session.begin():
            for node in nodes:
                ids.append(node.node_id)
                item = self._node_to_table_row(node)
                session.add(item)
            await session.commit()
        return ids

    def _to_postgres_operator(self, operator: FilterOperator) -> str:
        if operator == FilterOperator.EQ:
            return "="
        elif operator == FilterOperator.GT:
            return ">"
        elif operator == FilterOperator.LT:
            return "<"
        elif operator == FilterOperator.NE:
            return "!="
        elif operator == FilterOperator.GTE:
            return ">="
        elif operator == FilterOperator.LTE:
            return "<="
        elif operator == FilterOperator.IN:
            return "IN"
        elif operator == FilterOperator.NIN:
            return "NOT IN"
        elif operator == FilterOperator.CONTAINS:
            return "@>"
        elif operator == FilterOperator.TEXT_MATCH:
            return "LIKE"
        elif operator == FilterOperator.TEXT_MATCH_INSENSITIVE:
            return "ILIKE"
        elif operator == FilterOperator.IS_EMPTY:
            return "IS NULL"
        elif operator == FilterOperator.ANY:
            return "?|"
        elif operator == FilterOperator.ALL:
            return "?&"
        else:
            _logger.warning(f"Unknown operator: {operator}, fallback to '='")
            return "="

    def _build_filter_clause(self, filter_: MetadataFilter) -> Any:
        if filter_.operator in [FilterOperator.IN, FilterOperator.NIN]:
            # Expects a single value in the metadata, and a list to compare

            # In Python, to create a tuple with a single element, you need to include a comma after the element
            # This code will correctly format the IN clause whether there is one element or multiple elements in the list:
            filter_value = ", ".join(f"'{e}'" for e in filter_.value)

            return text(
                f"metadata_->>'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"({filter_value})"
            )
        elif filter_.operator in [FilterOperator.ANY, FilterOperator.ALL]:
            # Expects a text array stored in the metadata, and a list of values to compare
            # Works with text[] arrays using PostgreSQL ?| (ANY) and ?& (ALL) operators
            # Example: metadata_::jsonb->'tags' ?| array['AI', 'ML']
            filter_value = ", ".join(f"'{e}'" for e in filter_.value)

            return text(
                f"metadata_::jsonb->'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"array[{filter_value}]"
            )
        elif filter_.operator == FilterOperator.CONTAINS:
            # Expects a list stored in the metadata, and a single value to compare
            return text(
                f"metadata_::jsonb->'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"'[\"{filter_.value}\"]'"
            )
        elif (
            filter_.operator == FilterOperator.TEXT_MATCH
            or filter_.operator == FilterOperator.TEXT_MATCH_INSENSITIVE
        ):
            # Where the operator is text_match or ilike, we need to wrap the filter in '%' characters
            return text(
                f"metadata_->>'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)} "
                f"'%{filter_.value}%'"
            )
        elif filter_.operator == FilterOperator.IS_EMPTY:
            # Where the operator is is_empty, we need to check if the metadata is null
            return text(
                f"metadata_->>'{filter_.key}' "
                f"{self._to_postgres_operator(filter_.operator)}"
            )
        else:
            # Check if value is a number. If so, cast the metadata value to a float
            # This is necessary because the metadata is stored as a string
            try:
                return text(
                    f"(metadata_->>'{filter_.key}')::float "
                    f"{self._to_postgres_operator(filter_.operator)} "
                    f"{float(filter_.value)}"
                )
            except ValueError:
                # If not a number, then treat it as a string
                return text(
                    f"metadata_->>'{filter_.key}' "
                    f"{self._to_postgres_operator(filter_.operator)} "
                    f"'{filter_.value}'"
                )

    def _recursively_apply_filters(self, filters: List[MetadataFilters]) -> Any:
        """
        Returns a sqlalchemy where clause.
        """
        import sqlalchemy

        sqlalchemy_conditions = {
            "or": sqlalchemy.sql.or_,
            "and": sqlalchemy.sql.and_,
        }

        if filters.condition not in sqlalchemy_conditions:
            raise ValueError(
                f"Invalid condition: {filters.condition}. "
                f"Must be one of {list(sqlalchemy_conditions.keys())}"
            )

        return sqlalchemy_conditions[filters.condition](
            *(
                (
                    self._build_filter_clause(filter_)
                    if not isinstance(filter_, MetadataFilters)
                    else self._recursively_apply_filters(filter_)
                )
                for filter_ in filters.filters
            )
        )

    def _apply_filters_and_limit(
        self,
        stmt: "Select",
        limit: int,
        metadata_filters: Optional[MetadataFilters] = None,
    ) -> Any:
        if metadata_filters:
            stmt = stmt.where(  # type: ignore
                self._recursively_apply_filters(metadata_filters)
            )
        return stmt.limit(limit)  # type: ignore

    def _build_query(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> Any:
        stmt = select(  # type: ignore
            self._table_class.id,
            self._table_class.node_id,
            self._table_class.text,
            self._table_class.metadata_,
            self._table_class.embedding.cosine_distance(embedding).label("distance"),
        ).order_by(text("distance asc"))

        if self._customize_query_fn is not None:
            stmt = self._customize_query_fn(stmt, self._table_class, **kwargs)

        return self._apply_filters_and_limit(stmt, limit, metadata_filters)

    def _get_query_session_settings(self, **kwargs: Any) -> List[Tuple[str, dict]]:
        """Build list of (SQL, params) for index-specific session settings."""
        settings: List[Tuple[str, dict]] = []
        needs_bitmapscan_off = False
        if kwargs.get("ivfflat_probes"):
            settings.append(
                (
                    "SET ivfflat.probes = :ivfflat_probes",
                    {"ivfflat_probes": int(kwargs["ivfflat_probes"])},
                )
            )
            needs_bitmapscan_off = True
        if self.hnsw_kwargs:
            hnsw_ef_search = (
                kwargs.get("hnsw_ef_search") or self.hnsw_kwargs["hnsw_ef_search"]
            )
            settings.append(
                (
                    "SET hnsw.ef_search = :hnsw_ef_search",
                    {"hnsw_ef_search": int(hnsw_ef_search)},
                )
            )
            needs_bitmapscan_off = True
        if needs_bitmapscan_off:
            settings.append(("SET LOCAL enable_bitmapscan = off", {}))
        return settings

    def _query_with_score(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> List[DBEmbeddingRow]:
        stmt = self._build_query(embedding, limit, metadata_filters, **kwargs)
        with self._session() as session, session.begin():
            if kwargs.get("ivfflat_probes"):
                ivfflat_probes = kwargs.get("ivfflat_probes")
                session.execute(
                    text(f"SET ivfflat.probes = :ivfflat_probes"),
                    {"ivfflat_probes": ivfflat_probes},
                )
                session.execute(text("SET LOCAL enable_bitmapscan = off"))
            if self.hnsw_kwargs:
                hnsw_ef_search = (
                    kwargs.get("hnsw_ef_search") or self.hnsw_kwargs["hnsw_ef_search"]
                )
                session.execute(
                    text(f"SET hnsw.ef_search = :hnsw_ef_search"),
                    {"hnsw_ef_search": hnsw_ef_search},
                )
                session.execute(text("SET LOCAL enable_bitmapscan = off"))

            res = session.execute(
                stmt,
            )
            return [
                DBEmbeddingRow(
                    node_id=item.node_id,
                    text=item.text,
                    metadata=item.metadata_,
                    custom_fields={
                        key: val
                        for key, val in item._asdict().items()
                        if key not in ["id", "node_id", "text", "metadata_", "distance"]
                    },
                    similarity=(1 - item.distance) if item.distance is not None else 0,
                )
                for item in res.all()
            ]

    async def _aquery_with_score(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> List[DBEmbeddingRow]:
        stmt = self._build_query(embedding, limit, metadata_filters, **kwargs)
        async with self._async_session() as async_session, async_session.begin():
            if self.hnsw_kwargs:
                hnsw_ef_search = (
                    kwargs.get("hnsw_ef_search") or self.hnsw_kwargs["hnsw_ef_search"]
                )
                await async_session.execute(
                    text(f"SET hnsw.ef_search = {hnsw_ef_search}"),
                )
                await async_session.execute(text("SET LOCAL enable_bitmapscan = off"))
            if kwargs.get("ivfflat_probes"):
                ivfflat_probes = kwargs.get("ivfflat_probes")
                await async_session.execute(
                    text(f"SET ivfflat.probes = :ivfflat_probes"),
                    {"ivfflat_probes": ivfflat_probes},
                )
                await async_session.execute(text("SET LOCAL enable_bitmapscan = off"))

            res = await async_session.execute(stmt)
            return [
                DBEmbeddingRow(
                    node_id=item.node_id,
                    text=item.text,
                    metadata=item.metadata_,
                    custom_fields={
                        key: val
                        for key, val in item._asdict().items()
                        if key not in ["id", "node_id", "text", "metadata_", "distance"]
                    },
                    similarity=(1 - item.distance) if item.distance is not None else 0,
                )
                for item in res.all()
            ]

    def _build_sparse_query(
        self,
        query_str: Optional[str],
        limit: int,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> Any:
        from sqlalchemy import type_coerce
        from sqlalchemy.sql import func, text, select
        from sqlalchemy.types import UserDefinedType

        class REGCONFIG(UserDefinedType):
            # The TypeDecorator.cache_ok class-level flag indicates if this custom TypeDecorator is safe to be used as part of a cache key.
            # If the TypeDecorator is not guaranteed to produce the same bind/result behavior and SQL generation every time,
            # this flag should be set to False; otherwise if the class produces the same behavior each time, it may be set to True.
            cache_ok = True

            def get_col_spec(self, **kw: Any) -> str:
                return "regconfig"

        if query_str is None:
            raise ValueError("query_str must be specified for a sparse vector query.")

        # Remove special characters used by ts_query (essentially, all punctuation except single periods within words)
        # and collapse multiple spaces
        query_str = re.sub(r"(?!\b\.\b)\W+", " ", query_str).strip()

        # Replace space with "|" to perform an OR search for higher recall
        query_str = query_str.replace(" ", "|")

        ts_query = func.to_tsquery(
            type_coerce(self.text_search_config, REGCONFIG),
            query_str,
        )

        stmt = (
            select(  # type: ignore
                self._table_class.id,
                self._table_class.node_id,
                self._table_class.text,
                self._table_class.metadata_,
                func.ts_rank(self._table_class.text_search_tsv, ts_query).label("rank"),
            )
            .where(self._table_class.text_search_tsv.op("@@")(ts_query))
            .order_by(text("rank desc"))
        )

        if self._customize_query_fn is not None:
            stmt = self._customize_query_fn(stmt, self._table_class, **kwargs)

        # type: ignore
        return self._apply_filters_and_limit(stmt, limit, metadata_filters)

    async def _async_sparse_query_with_rank(
        self,
        query_str: Optional[str] = None,
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
    ) -> List[DBEmbeddingRow]:
        stmt = self._build_sparse_query(query_str, limit, metadata_filters)
        async with self._async_session() as async_session, async_session.begin():
            res = await async_session.execute(stmt)
            return [
                DBEmbeddingRow(
                    node_id=item.node_id,
                    text=item.text,
                    metadata=item.metadata_,
                    custom_fields={
                        key: val
                        for key, val in item._asdict().items()
                        if key not in ["id", "node_id", "text", "metadata_", "rank"]
                    },
                    similarity=item.rank,
                )
                for item in res.all()
            ]

    def _sparse_query_with_rank(
        self,
        query_str: Optional[str] = None,
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
    ) -> List[DBEmbeddingRow]:
        stmt = self._build_sparse_query(query_str, limit, metadata_filters)
        with self._session() as session, session.begin():
            res = session.execute(stmt)
            return [
                DBEmbeddingRow(
                    node_id=item.node_id,
                    text=item.text,
                    metadata=item.metadata_,
                    custom_fields={
                        key: val
                        for key, val in item._asdict().items()
                        if key not in ["id", "node_id", "text", "metadata_", "rank"]
                    },
                    similarity=item.rank,
                )
                for item in res.all()
            ]

    async def _async_hybrid_query(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> List[DBEmbeddingRow]:
        import asyncio

        if query.alpha is not None:
            _logger.warning("postgres hybrid search does not support alpha parameter.")

        sparse_top_k = query.sparse_top_k or query.similarity_top_k

        results = await asyncio.gather(
            self._aquery_with_score(
                query.query_embedding,
                query.similarity_top_k,
                query.filters,
                **kwargs,
            ),
            self._async_sparse_query_with_rank(
                query.query_str, sparse_top_k, query.filters
            ),
        )

        dense_results, sparse_results = results
        all_results = dense_results + sparse_results
        return _dedup_results(all_results)

    def _hybrid_query(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> List[DBEmbeddingRow]:
        if query.alpha is not None:
            _logger.warning("postgres hybrid search does not support alpha parameter.")

        sparse_top_k = query.sparse_top_k or query.similarity_top_k

        dense_results = self._query_with_score(
            query.query_embedding,
            query.similarity_top_k,
            query.filters,
            **kwargs,
        )

        sparse_results = self._sparse_query_with_rank(
            query.query_str, sparse_top_k, query.filters
        )

        all_results = dense_results + sparse_results
        return _dedup_results(all_results)

    def _build_query_with_embedding(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> Any:
        """Build a query that also returns embeddings (needed for MMR)."""
        stmt = select(
            self._table_class.id,
            self._table_class.node_id,
            self._table_class.text,
            self._table_class.metadata_,
            self._table_class.embedding,
            self._table_class.embedding.cosine_distance(embedding).label("distance"),
        ).order_by(text("distance asc"))

        if self._customize_query_fn is not None:
            stmt = self._customize_query_fn(stmt, self._table_class, **kwargs)

        return self._apply_filters_and_limit(stmt, limit, metadata_filters)

    def _query_with_embedding(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> List[Tuple[DBEmbeddingRow, List[float]]]:
        """Query and return results with their embeddings."""
        stmt = self._build_query_with_embedding(
            embedding, limit, metadata_filters, **kwargs
        )
        with self._session() as session, session.begin():
            for sql, params in self._get_query_session_settings(**kwargs):
                session.execute(text(sql), params)

            res = session.execute(stmt)
            return [
                (
                    DBEmbeddingRow(
                        node_id=item.node_id,
                        text=item.text,
                        metadata=item.metadata_,
                        custom_fields={
                            key: val
                            for key, val in item._asdict().items()
                            if key
                            not in [
                                "id",
                                "node_id",
                                "text",
                                "metadata_",
                                "distance",
                                "embedding",
                            ]
                        },
                        similarity=(1 - item.distance)
                        if item.distance is not None
                        else 0,
                    ),
                    list(item.embedding) if item.embedding is not None else [],
                )
                for item in res.all()
            ]

    async def _async_query_with_embedding(
        self,
        embedding: Optional[List[float]],
        limit: int = 10,
        metadata_filters: Optional[MetadataFilters] = None,
        **kwargs: Any,
    ) -> List[Tuple[DBEmbeddingRow, List[float]]]:
        """Async query and return results with their embeddings."""
        stmt = self._build_query_with_embedding(
            embedding, limit, metadata_filters, **kwargs
        )
        async with self._async_session() as async_session, async_session.begin():
            for sql, params in self._get_query_session_settings(**kwargs):
                await async_session.execute(text(sql), params)

            res = await async_session.execute(stmt)
            return [
                (
                    DBEmbeddingRow(
                        node_id=item.node_id,
                        text=item.text,
                        metadata=item.metadata_,
                        custom_fields={
                            key: val
                            for key, val in item._asdict().items()
                            if key
                            not in [
                                "id",
                                "node_id",
                                "text",
                                "metadata_",
                                "distance",
                                "embedding",
                            ]
                        },
                        similarity=(1 - item.distance)
                        if item.distance is not None
                        else 0,
                    ),
                    list(item.embedding) if item.embedding is not None else [],
                )
                for item in res.all()
            ]

    def _prepare_mmr_query(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> Tuple[int, Optional[float]]:
        """Validate MMR parameters and compute prefetch_k and mmr_threshold."""
        if query.query_embedding is None:
            raise ValueError("MMR query requires query_embedding")

        if (
            kwargs.get("mmr_prefetch_factor") is not None
            and kwargs.get("mmr_prefetch_k") is not None
        ):
            raise ValueError(
                "'mmr_prefetch_factor' and 'mmr_prefetch_k' "
                "cannot coexist in a call to query()"
            )

        mmr_prefetch_k = kwargs.get("mmr_prefetch_k")
        if mmr_prefetch_k is not None:
            prefetch_k = int(mmr_prefetch_k)
        else:
            prefetch_k = int(
                query.similarity_top_k
                * kwargs.get("mmr_prefetch_factor", DEFAULT_MMR_PREFETCH_FACTOR)
            )
        prefetch_k = max(prefetch_k, query.similarity_top_k)

        mmr_threshold = (
            query.mmr_threshold
            if query.mmr_threshold is not None
            else kwargs.get("mmr_threshold")
        )
        if mmr_threshold is not None and not (0 <= mmr_threshold <= 1):
            raise ValueError(
                f"mmr_threshold must be between 0 and 1, got {mmr_threshold}"
            )

        _logger.debug(
            f"MMR search: prefetching {prefetch_k} candidates for "
            f"{query.similarity_top_k} final results"
        )

        return prefetch_k, mmr_threshold

    def _mmr_rerank_results(
        self,
        query: VectorStoreQuery,
        results_with_embeddings: List[Tuple[DBEmbeddingRow, List[float]]],
        mmr_threshold: Optional[float],
    ) -> Optional[VectorStoreQueryResult]:
        """
        Apply MMR algorithm to prefetched results.

        Returns VectorStoreQueryResult on success, or None if fallback to
        regular search is needed (insufficient valid embeddings).
        """
        if not results_with_embeddings:
            _logger.debug("MMR search: no results found during prefetch")
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        embeddings = [emb for _, emb in results_with_embeddings]
        node_ids = [row.node_id for row, _ in results_with_embeddings]

        valid_indices = [i for i, emb in enumerate(embeddings) if emb]
        if not valid_indices:
            _logger.debug("MMR search: no valid embeddings found")
            return VectorStoreQueryResult(nodes=[], similarities=[], ids=[])

        valid_embeddings = [embeddings[i] for i in valid_indices]
        valid_node_ids = [node_ids[i] for i in valid_indices]

        if len(valid_embeddings) < query.similarity_top_k:
            _logger.warning(
                f"Not enough valid embeddings for MMR: "
                f"{len(valid_embeddings)} < {query.similarity_top_k}. "
                f"Falling back to regular search."
            )
            return None  # Signal caller to fall back

        mmr_similarities, mmr_ids = get_top_k_mmr_embeddings(
            query_embedding=query.query_embedding,
            embeddings=valid_embeddings,
            similarity_top_k=query.similarity_top_k,
            embedding_ids=valid_node_ids,
            mmr_threshold=mmr_threshold,
        )

        result_map = {row.node_id: row for row, _ in results_with_embeddings}
        ordered_rows = []
        for mmr_sim, node_id in zip(mmr_similarities, mmr_ids):
            if node_id in result_map:
                row = result_map[node_id]
                ordered_rows.append(
                    DBEmbeddingRow(
                        node_id=row.node_id,
                        text=row.text,
                        metadata=row.metadata,
                        custom_fields=row.custom_fields,
                        similarity=mmr_sim,
                    )
                )

        _logger.debug(
            f"MMR search completed: {len(ordered_rows)} results selected from "
            f"{len(results_with_embeddings)} candidates"
        )

        return self._db_rows_to_query_result(ordered_rows)

    def _mmr_query(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> VectorStoreQueryResult:
        """
        Perform MMR (Maximal Marginal Relevance) query.

        MMR balances relevance and diversity by iteratively selecting documents
        that are both similar to the query and dissimilar to already selected documents.

        Args:
            query: VectorStoreQuery with mode set to MMR
            **kwargs: Additional arguments including:
                - mmr_threshold: Float between 0 and 1. Higher values favor relevance,
                  lower values favor diversity. Default is 0.5.
                - mmr_prefetch_factor: Multiplier for prefetch count. Default is 4.
                - mmr_prefetch_k: Explicit prefetch count (overrides mmr_prefetch_factor).

        Returns:
            VectorStoreQueryResult with nodes reranked by MMR algorithm.

        """
        prefetch_k, mmr_threshold = self._prepare_mmr_query(query, **kwargs)

        db_kwargs = {
            k: v
            for k, v in kwargs.items()
            if k not in ("mmr_prefetch_factor", "mmr_prefetch_k", "mmr_threshold")
        }

        results_with_embeddings = self._query_with_embedding(
            query.query_embedding, prefetch_k, query.filters, **db_kwargs
        )

        result = self._mmr_rerank_results(query, results_with_embeddings, mmr_threshold)
        if result is not None:
            return result

        # Fallback to regular search
        rows = self._query_with_score(
            query.query_embedding,
            query.similarity_top_k,
            query.filters,
            **db_kwargs,
        )
        return self._db_rows_to_query_result(rows)

    async def _async_mmr_query(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> VectorStoreQueryResult:
        """
        Perform async MMR (Maximal Marginal Relevance) query.

        MMR balances relevance and diversity by iteratively selecting documents
        that are both similar to the query and dissimilar to already selected documents.

        Args:
            query: VectorStoreQuery with mode set to MMR
            **kwargs: Additional arguments including:
                - mmr_threshold: Float between 0 and 1. Higher values favor relevance,
                  lower values favor diversity. Default is 0.5.
                - mmr_prefetch_factor: Multiplier for prefetch count. Default is 4.
                - mmr_prefetch_k: Explicit prefetch count (overrides mmr_prefetch_factor).

        Returns:
            VectorStoreQueryResult with nodes reranked by MMR algorithm.

        """
        prefetch_k, mmr_threshold = self._prepare_mmr_query(query, **kwargs)

        db_kwargs = {
            k: v
            for k, v in kwargs.items()
            if k not in ("mmr_prefetch_factor", "mmr_prefetch_k", "mmr_threshold")
        }

        results_with_embeddings = await self._async_query_with_embedding(
            query.query_embedding, prefetch_k, query.filters, **db_kwargs
        )

        result = self._mmr_rerank_results(query, results_with_embeddings, mmr_threshold)
        if result is not None:
            return result

        # Fallback to regular search
        rows = await self._aquery_with_score(
            query.query_embedding,
            query.similarity_top_k,
            query.filters,
            **db_kwargs,
        )
        return self._db_rows_to_query_result(rows)

    def _db_rows_to_query_result(
        self, rows: List[DBEmbeddingRow]
    ) -> VectorStoreQueryResult:
        nodes = []
        similarities = []
        ids = []
        for db_embedding_row in rows:
            try:
                node = metadata_dict_to_node(db_embedding_row.metadata)
                node.set_content(str(db_embedding_row.text))
            except Exception:
                # NOTE: deprecated legacy logic for backward compatibility
                node = TextNode(
                    id_=db_embedding_row.node_id,
                    text=db_embedding_row.text,
                    metadata=db_embedding_row.metadata,
                )
            if db_embedding_row.custom_fields:
                node.metadata["custom_fields"] = db_embedding_row.custom_fields
            similarities.append(db_embedding_row.similarity)
            ids.append(db_embedding_row.node_id)
            nodes.append(node)

        return VectorStoreQueryResult(
            nodes=nodes,
            similarities=similarities,
            ids=ids,
        )

    async def aquery(
        self, query: VectorStoreQuery, **kwargs: Any
    ) -> VectorStoreQueryResult:
        self._initialize()
        if query.mode == VectorStoreQueryMode.HYBRID:
            results = await self._async_hybrid_query(query, **kwargs)
        elif query.mode in [
            VectorStoreQueryMode.SPARSE,
            VectorStoreQueryMode.TEXT_SEARCH,
        ]:
            sparse_top_k = query.sparse_top_k or query.similarity_top_k
            results = await self._async_sparse_query_with_rank(
                query.query_str, sparse_top_k, query.filters
            )
        elif query.mode == VectorStoreQueryMode.MMR:
            return await self._async_mmr_query(query, **kwargs)
        elif query.mode == VectorStoreQueryMode.DEFAULT:
            results = await self._aquery_with_score(
                query.query_embedding,
                query.similarity_top_k,
                query.filters,
                **kwargs,
            )
        else:
            raise ValueError(f"Invalid query mode: {query.mode}")

        return self._db_rows_to_query_result(results)

    def query(self, query: VectorStoreQuery, **kwargs: Any) -> VectorStoreQueryResult:
        self._initialize()
        if query.mode == VectorStoreQueryMode.HYBRID:
            results = self._hybrid_query(query, **kwargs)
        elif query.mode in [
            VectorStoreQueryMode.SPARSE,
            VectorStoreQueryMode.TEXT_SEARCH,
        ]:
            sparse_top_k = query.sparse_top_k or query.similarity_top_k
            results = self._sparse_query_with_rank(
                query.query_str, sparse_top_k, query.filters
            )
        elif query.mode == VectorStoreQueryMode.MMR:
            return self._mmr_query(query, **kwargs)
        elif query.mode == VectorStoreQueryMode.DEFAULT:
            results = self._query_with_score(
                query.query_embedding,
                query.similarity_top_k,
                query.filters,
                **kwargs,
            )
        else:
            raise ValueError(f"Invalid query mode: {query.mode}")

        return self._db_rows_to_query_result(results)

    def delete(self, ref_doc_id: str, **delete_kwargs: Any) -> None:
        from sqlalchemy import delete

        self._initialize()
        with self._session() as session, session.begin():
            stmt = delete(self._table_class).where(
                self._table_class.metadata_["ref_doc_id"].astext == ref_doc_id
            )

            session.execute(stmt)
            session.commit()

    async def adelete(self, ref_doc_id: str, **delete_kwargs: Any) -> None:
        from sqlalchemy import delete

        self._initialize()
        async with self._async_session() as session, session.begin():
            stmt = delete(self._table_class).where(
                self._table_class.metadata_["ref_doc_id"].astext == ref_doc_id
            )

            await session.execute(stmt)
            await session.commit()

    def delete_nodes(
        self,
        node_ids: Optional[List[str]] = None,
        filters: Optional[MetadataFilters] = None,
        **delete_kwargs: Any,
    ) -> None:
        """
        Deletes nodes.

        Args:
            node_ids (Optional[List[str]], optional): IDs of nodes to delete. Defaults to None.
            filters (Optional[MetadataFilters], optional): Metadata filters. Defaults to None.

        """
        if not node_ids and not filters:
            return

        from sqlalchemy import delete

        self._initialize()
        with self._session() as session, session.begin():
            stmt = delete(self._table_class)

            if node_ids:
                stmt = stmt.where(self._table_class.node_id.in_(node_ids))

            if filters:
                stmt = stmt.where(self._recursively_apply_filters(filters))

            session.execute(stmt)
            session.commit()

    async def adelete_nodes(
        self,
        node_ids: Optional[List[str]] = None,
        filters: Optional[MetadataFilters] = None,
        **delete_kwargs: Any,
    ) -> None:
        """
        Deletes nodes asynchronously.

        Args:
            node_ids (Optional[List[str]], optional): IDs of nodes to delete. Defaults to None.
            filters (Optional[MetadataFilters], optional): Metadata filters. Defaults to None.

        """
        if not node_ids and not filters:
            return

        from sqlalchemy import delete

        self._initialize()
        async with self._async_session() as async_session, async_session.begin():
            stmt = delete(self._table_class)

            if node_ids:
                stmt = stmt.where(self._table_class.node_id.in_(node_ids))

            if filters:
                stmt = stmt.where(self._recursively_apply_filters(filters))

            await async_session.execute(stmt)
            await async_session.commit()

    def clear(self) -> None:
        """Clears table."""
        from sqlalchemy import delete

        self._initialize()
        with self._session() as session, session.begin():
            stmt = delete(self._table_class)

            session.execute(stmt)
            session.commit()

    async def aclear(self) -> None:
        """Asynchronously clears table."""
        from sqlalchemy import delete

        self._initialize()
        async with self._async_session() as async_session, async_session.begin():
            stmt = delete(self._table_class)

            await async_session.execute(stmt)
            await async_session.commit()

    def get_nodes(
        self,
        node_ids: Optional[List[str]] = None,
        filters: Optional[MetadataFilters] = None,
    ) -> List[BaseNode]:
        """Get nodes from vector store."""
        assert node_ids is not None or filters is not None, (
            "Either node_ids or filters must be provided"
        )

        self._initialize()

        stmt = select(
            self._table_class.node_id,
            self._table_class.text,
            self._table_class.metadata_,
            self._table_class.embedding,
        )

        if node_ids:
            stmt = stmt.where(self._table_class.node_id.in_(node_ids))

        if filters:
            filter_clause = self._recursively_apply_filters(filters)
            stmt = stmt.where(filter_clause)

        nodes: List[BaseNode] = []

        with self._session() as session, session.begin():
            res = session.execute(stmt).fetchall()
            for item in res:
                node_id = item.node_id
                text = item.text
                metadata = item.metadata_
                embedding = item.embedding
                custom_fields = {
                    key: val
                    for key, val in item._asdict().items()
                    if key not in ["id", "node_id", "text", "metadata_"]
                }

                try:
                    node = metadata_dict_to_node(metadata)
                    node.set_content(str(text))
                    node.embedding = embedding
                except Exception:
                    node = TextNode(
                        id_=node_id,
                        text=text,
                        metadata=metadata,
                        embedding=embedding,
                    )
                nodes.append(node)
        return nodes

    async def aget_nodes(
        self,
        node_ids: Optional[List[str]] = None,
        filters: Optional[MetadataFilters] = None,
    ) -> List[BaseNode]:
        """Get nodes asynchronously from vector store."""
        assert node_ids is not None or filters is not None, (
            "Either node_ids or filters must be provided"
        )

        self._initialize()

        stmt = select(
            self._table_class.node_id,
            self._table_class.text,
            self._table_class.metadata_,
            self._table_class.embedding,
        )

        if node_ids:
            stmt = stmt.where(self._table_class.node_id.in_(node_ids))

        if filters:
            filter_clause = self._recursively_apply_filters(filters)
            stmt = stmt.where(filter_clause)

        nodes: List[BaseNode] = []

        async with self._async_session() as session, session.begin():
            res = (await session.execute(stmt)).fetchall()
            for item in res:
                node_id = item.node_id
                text = item.text
                metadata = item.metadata_
                embedding = item.embedding
                custom_fields = {
                    key: val
                    for key, val in item._asdict().items()
                    if key not in ["id", "node_id", "text", "metadata_"]
                }

                try:
                    node = metadata_dict_to_node(metadata)
                    node.set_content(str(text))
                    node.embedding = embedding
                except Exception:
                    node = TextNode(
                        id_=node_id,
                        text=text,
                        metadata=metadata,
                        embedding=embedding,
                    )

                nodes.append(node)

            return nodes


def _dedup_results(results: List[DBEmbeddingRow]) -> List[DBEmbeddingRow]:
    seen_ids = set()
    deduped_results = []
    for result in results:
        if result.node_id not in seen_ids:
            deduped_results.append(result)
            seen_ids.add(result.node_id)
    return deduped_results
