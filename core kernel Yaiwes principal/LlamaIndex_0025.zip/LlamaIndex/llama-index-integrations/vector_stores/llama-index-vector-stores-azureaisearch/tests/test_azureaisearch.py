import asyncio
import json
from typing import Any, List, Optional
from unittest.mock import MagicMock, patch

import pytest

from llama_index.core.schema import NodeRelationship, RelatedNodeInfo, TextNode
from llama_index.core.vector_stores.types import VectorStoreQuery, VectorStoreQueryMode
from llama_index.vector_stores.azureaisearch import (
    AzureAISearchVectorStore,
    IndexManagement,
    MetadataIndexFieldType,
)

try:
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.models import VectorizedQuery

    azureaisearch_installed = True
except ImportError:
    azureaisearch_installed = False
    search_client = None  # type: ignore


def mock_client_with_user_agent(client_type: str) -> Any:
    """Helper function to create a mock client with user agent configuration."""
    if client_type == "search":
        client = MagicMock(spec=SearchClient)
    else:
        client = MagicMock(spec=SearchIndexClient)

    # Mock the configuration chain
    client._client = MagicMock()
    client._client._config = MagicMock()
    client._client._config.user_agent_policy = MagicMock()
    client._client._config.user_agent_policy.add_user_agent = MagicMock()

    return client


def create_mock_vector_store(
    search_client: Any,
    index_name: Optional[str] = None,
    index_management: IndexManagement = IndexManagement.NO_VALIDATION,
) -> AzureAISearchVectorStore:
    return AzureAISearchVectorStore(
        search_or_index_client=search_client,
        id_field_key="id",
        chunk_field_key="content",
        embedding_field_key="embedding",
        metadata_string_field_key="metadata",
        doc_id_field_key="doc_id",
        filterable_metadata_field_keys=[],
        hidden_field_keys=["embedding"],
        index_name=index_name,
        index_management=index_management,
        embedding_dimensionality=2,  # Assuming a dimensionality of 2 for simplicity
        semantic_configuration_name="default",
    )


def create_sample_documents(n: int) -> List[TextNode]:
    nodes: List[TextNode] = []

    for i in range(n):
        nodes.append(
            TextNode(
                text=f"test node text {i}",
                relationships={
                    NodeRelationship.SOURCE: RelatedNodeInfo(node_id=f"test doc id {i}")
                },
                embedding=[0.5, 0.5],
            )
        )

    return nodes


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_user_agent_configuration() -> None:
    """Test that user agent is properly configured."""
    # Test with SearchClient
    search_client = mock_client_with_user_agent("search")
    vector_store = create_mock_vector_store(search_client)

    # Verify user agent was added with the correct base agent string
    search_client._client._config.user_agent_policy.add_user_agent.assert_called_with(
        "llamaindex-python"
    )

    # Test with SearchIndexClient
    index_client = mock_client_with_user_agent("index")
    vector_store = create_mock_vector_store(
        index_client,
        index_name="test-index",
        index_management=IndexManagement.NO_VALIDATION,
    )

    # Verify user agent was added with the correct base agent string
    index_client._client._config.user_agent_policy.add_user_agent.assert_called_with(
        "llamaindex-python"
    )


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_add_two_batches() -> None:
    search_client = mock_client_with_user_agent("search")

    with patch("azure.search.documents.IndexDocumentsBatch") as MockIndexDocumentsBatch:
        index_documents_batch_instance = MockIndexDocumentsBatch.return_value
        vector_store = create_mock_vector_store(search_client)

        nodes = create_sample_documents(11)
        ids = vector_store.add(nodes)

        call_count = index_documents_batch_instance.add_upload_actions.call_count

        assert ids is not None
        assert len(ids) == 11
        assert call_count == 11
        assert search_client.index_documents.call_count == 1


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_add_one_batch() -> None:
    search_client = mock_client_with_user_agent("search")

    with patch("azure.search.documents.IndexDocumentsBatch") as MockIndexDocumentsBatch:
        index_documents_batch_instance = MockIndexDocumentsBatch.return_value
        vector_store = create_mock_vector_store(search_client)

        nodes = create_sample_documents(11)
        ids = vector_store.add(nodes)

        call_count = index_documents_batch_instance.add_upload_actions.call_count

        assert ids is not None
        assert len(ids) == 11
        assert call_count == 11
        assert search_client.index_documents.call_count == 1


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_invalid_index_management_for_searchclient() -> None:
    search_client = mock_client_with_user_agent("search")

    # No error
    create_mock_vector_store(
        search_client, index_management=IndexManagement.VALIDATE_INDEX
    )

    # Cannot supply index name
    with pytest.raises(
        ValueError,
        match="index_name cannot be supplied if search_or_index_client is of type azure.search.documents.SearchClient",
    ):
        create_mock_vector_store(search_client, index_name="test01")

    # SearchClient cannot create an index
    with pytest.raises(ValueError):
        create_mock_vector_store(
            search_client,
            index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
        )


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_invalid_index_management_for_searchindexclient() -> None:
    search_client = mock_client_with_user_agent("index")

    # Index name must be supplied
    with pytest.raises(
        ValueError,
        match="index_name must be supplied if search_or_index_client is of type azure.search.documents.SearchIndexClient",
    ):
        create_mock_vector_store(
            search_client, index_management=IndexManagement.VALIDATE_INDEX
        )

    # No error when index name is supplied with SearchIndexClient
    create_mock_vector_store(
        search_client,
        index_name="test01",
        index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
    )


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_query() -> None:
    search_client = mock_client_with_user_agent("search")

    # Mock the search method of the search client
    mock_search_results = [
        {
            "id": "test_id_1",
            "chunk": "test chunk 1",
            "content": "test chunk 1",
            "metadata": json.dumps({"key": "value1"}),
            "doc_id": "doc1",
            "@search.score": 0.9,
        },
        {
            "id": "test_id_2",
            "chunk": "test chunk 2",
            "content": "test chunk 2",
            "metadata": json.dumps({"key": "value2"}),
            "doc_id": "doc2",
            "@search.score": 0.8,
        },
    ]
    search_client.search.return_value = mock_search_results

    vector_store = create_mock_vector_store(search_client)

    # Create a sample query
    query = VectorStoreQuery(
        query_embedding=[0.1, 0.2],
        similarity_top_k=2,
        mode=VectorStoreQueryMode.DEFAULT,
    )

    # Execute the query
    result = vector_store.query(query)

    # Assert the search method was called with correct parameters
    search_client.search.assert_called_once_with(
        search_text="*",
        vector_queries=[
            VectorizedQuery(
                vector=[0.1, 0.2], k_nearest_neighbors=2, fields="embedding"
            )
        ],
        top=2,
        select=["id", "content", "metadata", "doc_id"],
        filter=None,
        semantic_configuration_name=None,
    )

    # Assert the result structure
    assert len(result.nodes) == 2
    assert len(result.ids) == 2
    assert len(result.similarities) == 2

    # Assert the content of the results
    assert result.nodes[0].text == "test chunk 1"
    assert result.nodes[1].text == "test chunk 2"
    assert result.ids == ["test_id_1", "test_id_2"]
    assert result.similarities == [0.9, 0.8]

    # Assert the metadata
    assert result.nodes[0].metadata == {"key": "value1"}
    assert result.nodes[1].metadata == {"key": "value2"}


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_semantic_query() -> None:
    search_client = mock_client_with_user_agent("search")

    # Mock the search method of the search client
    mock_search_results = [
        {
            "id": "test_id_1",
            "chunk": "test chunk 1",
            "content": "test chunk 1",
            "metadata": json.dumps({"key": "value1"}),
            "doc_id": "doc1",
            "@search.score": 0.9,
            "@search.reranker_score": 0.7,
        },
        {
            "id": "test_id_2",
            "chunk": "test chunk 2",
            "content": "test chunk 2",
            "metadata": json.dumps({"key": "value2"}),
            "doc_id": "doc2",
            "@search.score": 0.8,
            "@search.reranker_score": 0.7,
        },
    ]
    search_client.search.return_value = mock_search_results

    vector_store = create_mock_vector_store(search_client)

    # Create a sample query
    query = VectorStoreQuery(
        query_str="test query",
        query_embedding=[0.1, 0.2],
        similarity_top_k=2,
        mode=VectorStoreQueryMode.SEMANTIC_HYBRID,
    )

    # Execute the query
    result = vector_store.query(query)

    # Get the actual call arguments
    call_args = search_client.search.call_args[1]

    # Assert basic parameters
    assert call_args["search_text"] == "test query"
    assert call_args["top"] == 2
    assert call_args["select"] == ["id", "content", "metadata", "doc_id"]
    assert call_args["filter"] is None
    assert call_args["query_type"] == "semantic"
    assert call_args["semantic_configuration_name"] == "default"

    # Assert vector query parameters
    vector_queries = call_args["vector_queries"]
    assert len(vector_queries) == 1
    vector_query = vector_queries[0]
    assert vector_query.vector == [0.1, 0.2]
    assert vector_query.k_nearest_neighbors == 50
    assert vector_query.fields == "embedding"

    # Assert the result structure
    assert len(result.nodes) == 2
    assert len(result.ids) == 2
    assert len(result.similarities) == 2


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_query_raises_for_unsupported_mode() -> None:
    search_client = mock_client_with_user_agent("search")
    vector_store = create_mock_vector_store(search_client)
    query = VectorStoreQuery(
        query_str="test query",
        similarity_top_k=1,
        mode=VectorStoreQueryMode.TEXT_SEARCH,
    )

    with pytest.raises(ValueError, match="Unsupported query mode"):
        vector_store.query(query)

    search_client.search.assert_not_called()


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_aquery_raises_for_unsupported_mode() -> None:
    search_client = mock_client_with_user_agent("search")
    vector_store = create_mock_vector_store(search_client)
    query = VectorStoreQuery(
        query_str="test query",
        similarity_top_k=1,
        mode=VectorStoreQueryMode.TEXT_SEARCH,
    )

    with pytest.raises(ValueError, match="Unsupported query mode"):
        asyncio.run(vector_store.aquery(query))


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_azureaisearch_query_ignores_conflicting_kwargs_and_forwards_extras_for_all_modes() -> (
    None
):
    """
    Ensure extra SDK kwargs are forwarded, and explicit params cannot be overridden.

    1) extra SDK kwargs (e.g. scoring_profile, order_by) get forwarded.
    2) explicit params (top, select, filter) cannot be overridden by user kwargs.
    """
    search_client = mock_client_with_user_agent("search")
    search_client.search.return_value = []
    vector_store = create_mock_vector_store(search_client)

    # Extras including both valid SDK args and attempts to override our explicit params
    extras = {
        "scoring_profile": "myCustomProfile",
        "order_by": ["title asc"],
        "top": 999,  # malicious override
        "filter": "name eq 'override'",  # malicious override
        "select": ["test"],  # malicious override
    }

    modes = [
        VectorStoreQueryMode.DEFAULT,
        VectorStoreQueryMode.SPARSE,
        VectorStoreQueryMode.HYBRID,
        VectorStoreQueryMode.SEMANTIC_HYBRID,
    ]

    expected_top = 1
    expected_select = ["id", "content", "metadata", "doc_id"]
    expected_filter = None

    for mode in modes:
        search_client.search.reset_mock()

        query = VectorStoreQuery(
            query_embedding=[0.1, 0.2],
            similarity_top_k=expected_top,
            mode=mode,
            query_str="test_query",
        )

        vector_store.query(query, **extras)
        called = search_client.search.call_args[1]

        # 1) Legitimate extras still forwarded
        assert called["scoring_profile"] == "myCustomProfile"
        assert called["order_by"] == ["title asc"]

        # 2) Explicit defaults remain intact despite conflict attempts
        assert called["top"] == expected_top
        assert called["select"] == expected_select
        assert called["filter"] is expected_filter
        # And that our explicit values differ from the overridden one's
        assert called["top"] != extras["top"]
        assert called["select"] != extras["select"]
        assert called["filter"] != extras["filter"]


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_ownership_flag_set_when_index_client_provided() -> None:
    """Test that _owns_search_client is True when SearchIndexClient is provided."""
    index_client = mock_client_with_user_agent("index")

    # Create a mock search client that will be returned by get_search_client
    mock_search_client = mock_client_with_user_agent("search")
    index_client.get_search_client = MagicMock(return_value=mock_search_client)

    vector_store = create_mock_vector_store(
        index_client,
        index_name="test-index",
        index_management=IndexManagement.NO_VALIDATION,
    )

    # When SearchIndexClient is provided, we create SearchClient internally
    assert vector_store._owns_search_client is True


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_ownership_flag_false_when_search_client_provided() -> None:
    """Test that _owns_search_client is False when SearchClient is directly provided."""
    search_client = mock_client_with_user_agent("search")

    vector_store = create_mock_vector_store(search_client)

    # When SearchClient is directly provided, we don't own it
    assert vector_store._owns_search_client is False


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_close_calls_internal_client_close() -> None:
    """Test that close() calls close() on internally-created client."""
    index_client = mock_client_with_user_agent("index")

    # Create a mock search client that will be returned by get_search_client
    mock_search_client = mock_client_with_user_agent("search")
    mock_search_client.close = MagicMock()
    index_client.get_search_client = MagicMock(return_value=mock_search_client)

    vector_store = create_mock_vector_store(
        index_client,
        index_name="test-index",
        index_management=IndexManagement.NO_VALIDATION,
    )

    # Call close
    vector_store.close()

    # Verify close was called on the internal search client
    mock_search_client.close.assert_called_once()


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_close_does_not_call_external_client_close() -> None:
    """Test that close() does NOT call close() on externally-provided client."""
    search_client = mock_client_with_user_agent("search")
    search_client.close = MagicMock()

    vector_store = create_mock_vector_store(search_client)

    # Call close
    vector_store.close()

    # Verify close was NOT called on the external search client
    search_client.close.assert_not_called()


@pytest.mark.skipif(
    not azureaisearch_installed, reason="azure-search-documents package not installed"
)
def test_default_index_mapping_preserves_falsy_metadata_values() -> None:
    """
    Regression: falsy metadata values (0, False, '') must not be dropped.

    Previously the guard in ``_default_index_mapping`` was ``if metadata_value:``
    which silently skipped values like 0, False, and empty strings. The fix
    changes it to ``if metadata_value is not None:`` so that only missing keys
    are skipped while falsy-but-present values are preserved.
    """
    search_client = mock_client_with_user_agent("search")
    vector_store = AzureAISearchVectorStore(
        search_or_index_client=search_client,
        id_field_key="id",
        chunk_field_key="content",
        embedding_field_key="embedding",
        metadata_string_field_key="metadata",
        doc_id_field_key="doc_id",
        filterable_metadata_field_keys={
            "score": ("score_field", MetadataIndexFieldType.INT32),
            "active": ("active_field", MetadataIndexFieldType.BOOLEAN),
            "tag": ("tag_field", MetadataIndexFieldType.STRING),
            "missing": ("missing_field", MetadataIndexFieldType.STRING),
        },
        index_management=IndexManagement.NO_VALIDATION,
        embedding_dimensionality=2,
        semantic_configuration_name="default",
    )

    enriched_doc = {
        "id": "1",
        "chunk": "hello",
        "embedding": [0.1, 0.2],
        "metadata": "{}",
        "doc_id": "doc-1",
    }
    metadata = {
        "score": 0,  # falsy int - must be preserved
        "active": False,  # falsy bool - must be preserved
        "tag": "",  # falsy string - must be preserved
        # "missing" is absent - must not appear in the index doc
    }

    index_doc = vector_store._default_index_mapping(enriched_doc, metadata)

    assert index_doc["score_field"] == 0
    assert index_doc["active_field"] is False
    assert index_doc["tag_field"] == ""
    assert "missing_field" not in index_doc
