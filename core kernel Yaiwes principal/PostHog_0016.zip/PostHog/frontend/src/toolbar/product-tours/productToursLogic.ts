import { deepEqual as equal } from 'fast-equals'
import { MakeLogicType, actions, connect, events, kea, listeners, path, reducers, selectors } from 'kea'
import { forms } from 'kea-forms'
import type { DeepPartial, DeepPartialMap, FieldName, ValidationErrorType } from 'kea-forms'
import { loaders } from 'kea-loaders'
import { subscriptions } from 'kea-subscriptions'
import { findElement } from 'posthog-js/dist/element-inference'
import type { PostHog } from 'posthog-js/dist/module'

import { lemonToast } from 'lib/lemon-ui/LemonToast'
import { uuid } from 'lib/utils/dom'
import { retryImport } from 'lib/utils/retryImport'
import { ProductTourEvent } from 'scenes/product-tours/constants'
import { DEFAULT_APPEARANCE } from 'scenes/product-tours/constants'
import {
    createDefaultStep,
    getDefaultStepContent,
    getUpdatedStepOrderHistory,
    hasElementTarget,
    hasIncompleteTargeting,
} from 'scenes/product-tours/stepUtils'

import { toolbarLogic } from '~/toolbar/bar/toolbarLogic'
import { toolbarApi } from '~/toolbar/toolbarApi'
import { toolbarConfigLogic } from '~/toolbar/toolbarConfigLogic'
import { toolbarLogger } from '~/toolbar/toolbarLogger'
import { captureToolbarException, toolbarPosthogJS } from '~/toolbar/toolbarPosthogJS'
import { ToolbarRequestError, isToolbarRequestError } from '~/toolbar/toolbarRequestError'
import { ElementRect } from '~/toolbar/types'
import { urls } from '~/toolbar/urls'
import { TOOLBAR_ID, elementToActionStep, getRectForElement, joinWithUiHost } from '~/toolbar/utils'
import { captureAndUploadElementScreenshot } from '~/toolbar/utils/screenshot'
import { ProductTour, ProductTourStep, ProductTourStepType } from '~/types'

import type { ToolbarUserIntent } from '../../types'
import { inferSelector } from './elementInference'
import { PRODUCT_TOURS_SIDEBAR_TRANSITION_MS } from './utils'

/**
 * Editor state machine - explicit states instead of multiple boolean flags.
 *
 * - idle: Default state, no hover effects, step badges visible. Cmd/ctrl+click passes through.
 * - selecting: User is picking an element from the page. Hover highlighting active.
 */
export type EditorState = { mode: 'idle' } | { mode: 'selecting'; stepIndex: number }

export interface TourStep extends ProductTourStep {
    /** Local-only: reference to DOM element, not persisted */
    element?: HTMLElement
}

export interface TourForm {
    id?: string
    name: string
    steps: TourStep[]
}

export const PRODUCT_TOURS_MIN_JS_VERSION = '1.324.0'

const startRecording = (): void => {
    toolbarPosthogJS.startSessionRecording(true)
    toolbarPosthogJS.capture(ProductTourEvent.RECORDING_STARTED)
}

export function hasMinProductToursVersion(version: string): boolean {
    const [major, minor] = version.split('.').map(Number)
    return major > 1 || (major === 1 && minor >= 324)
}

function newTour(): TourForm {
    return {
        name: '',
        steps: [],
    }
}

function tourToForm(tour: ProductTour): TourForm {
    const draft = tour.draft_content
    const content = draft?.content ?? tour.content
    return {
        id: tour.id,
        name: draft?.name ?? tour.name,
        steps: (content?.steps ?? []).map((step) => ({
            ...step,
            id: step.id || uuid(),
        })),
    }
}

function isToolbarElement(element: HTMLElement): boolean {
    const toolbar = document.getElementById(TOOLBAR_ID)
    return toolbar?.contains(element) ?? false
}

/** Get the DOM element for a step, checking cached ref is still valid */
export function getStepElement(step: TourStep): HTMLElement | null {
    if (step.element && document.body.contains(step.element)) {
        return step.element
    }

    if (step.elementTargeting === 'manual') {
        if (!step.selector) {
            return null
        }
        try {
            return document.querySelector(step.selector) as HTMLElement | null
        } catch {
            toolbarLogger.warn('product_tours', 'Failed to query element with manual selector', {
                selector: step.selector,
            })
            return null
        }
    }

    if (!step.inferenceData) {
        if (!step.selector) {
            return null
        }
        try {
            return document.querySelector(step.selector) as HTMLElement | null
        } catch {
            toolbarLogger.warn('product_tours', 'Failed to query element with selector', { selector: step.selector })
            return null
        }
    }

    return findElement(step.inferenceData)
}

// Step HTML generation drags tiptap/prosemirror/highlight.js (~500KB minified) — only needed
// when a tour is edited or previewed, so load it on demand. Repeat awaits resolve from the
// module cache in call order, so the draft-compare subscriptions below stay ordered.
const importStepHtml = (): Promise<typeof import('scenes/product-tours/editor/generateStepHtml')> =>
    retryImport(() => import('scenes/product-tours/editor/generateStepHtml'))

async function buildDraftPayload(form: TourForm, tours: ProductTour[]): Promise<Record<string, unknown>> {
    const { prepareStepForRender } = await importStepHtml()
    const stepsForApi = form.steps.map(({ element: _, ...step }) => prepareStepForRender(step))
    const existingTour = form.id ? tours.find((t) => t.id === form.id) : null
    const stepOrderHistory = getUpdatedStepOrderHistory(stepsForApi, existingTour?.content?.step_order_history)
    return {
        name: form.name,
        content: {
            appearance: DEFAULT_APPEARANCE,
            ...existingTour?.content,
            steps: stepsForApi,
            step_order_history: stepOrderHistory,
        },
    }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface productToursLogicValues {
    dataAttributes: string[] // toolbarConfigLogic
    posthog: PostHog | null // toolbarConfigLogic
    productTourId: string | null // toolbarConfigLogic
    uiHost: string // toolbarConfigLogic
    userIntent: ToolbarUserIntent | null // toolbarConfigLogic
    buttonProductToursVisible: boolean
    draftSaveStatus: 'saved' | 'saving' | 'unsaved' | null
    editorState: EditorState
    expandedStepIndex: number | null
    expandedStepRect: ElementRect | null
    hoverElement: HTMLElement | null
    hoverElementRect: ElementRect | null
    isPreviewing: boolean
    isSelecting: boolean
    isTourFormSubmitting: boolean
    isTourFormValid: boolean
    launchedFromMainApp: boolean
    rectUpdateCounter: number
    selectedElement: HTMLElement | null
    selectedElementRect: ElementRect | null
    selectedTour: TourForm | null
    selectedTourId: string | 'new' | null
    selectingStepIndex: number | null
    sessionRecordingConsent: boolean | null
    showTourFormErrors: boolean
    sidebarPosition: 'left' | 'right'
    sidebarTransitioning: boolean
    stepCount: number
    tourForm: TourForm
    tourFormAllErrors: Record<string, any>
    tourFormChanged: boolean
    tourFormErrors: DeepPartialMap<TourForm, ValidationErrorType>
    tourFormHasErrors: boolean
    tourFormManualErrors: Record<string, any>
    tourFormTouched: boolean
    tourFormTouches: Record<string, boolean>
    tourFormValidationErrors: DeepPartialMap<TourForm, ValidationErrorType>
    tours: ProductTour[]
    toursLoading: boolean
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface productToursLogicActions {
    addStep: (stepType: ProductTourStepType) => {
        stepType: ProductTourStepType
    }
    cancelEditing: () => {
        value: true
    }
    clearSelectedElement: () => {
        value: true
    }
    deleteTour: (id: string) => {
        id: string
    }
    draftAutoSave: () => {
        value: true
    }
    hideButtonProductTours: () => {
        value: true
    }
    loadTours: () => any
    loadToursFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadToursSuccess: (
        tours: ProductTour[],
        payload?: any
    ) => {
        tours: ProductTour[]
        payload?: any
    }
    newTour: () => {
        value: true
    }
    previewTour: () => {
        value: true
    }
    removeStep: (index: number) => {
        index: number
    }
    resetTourForm: (values?: TourForm) => {
        values?: TourForm
    }
    saveTour: () => {
        value: true
    }
    selectElement: (element: HTMLElement) => {
        element: HTMLElement
    }
    selectTour: (id: string | null) => {
        id: string | null
    }
    setEditorState: (state: EditorState) => {
        state: EditorState
    }
    setExpandedStepIndex: (index: number | null) => {
        index: number | null
    }
    setHoverElement: (element: HTMLElement | null) => {
        element: HTMLElement | null
    }
    setLaunchedFromMainApp: (value: boolean) => {
        value: boolean
    }
    setSessionRecordingConsent: (consent: boolean) => {
        consent: boolean
    }
    setSidebarTransitioning: (transitioning: boolean) => {
        transitioning: boolean
    }
    setTourFormManualErrors: (errors: Record<string, any>) => {
        errors: Record<string, any>
    }
    setTourFormValue: (
        key: FieldName,
        value: any
    ) => {
        name: FieldName
        value: any
    }
    setTourFormValues: (values: DeepPartial<TourForm>) => {
        values: DeepPartial<TourForm>
    }
    showButtonProductTours: () => {
        value: true
    }
    startPreviewMode: () => {
        value: true
    }
    stopPreview: () => {
        value: true
    }
    submitTourForm: () => {
        value: boolean
    }
    submitTourFormFailure: (
        error: Error,
        errors: Record<string, any>
    ) => {
        error: Error
        errors: Record<string, any>
    }
    submitTourFormRequest: (tourForm: TourForm) => {
        tourForm: TourForm
    }
    submitTourFormSuccess: (tourForm: TourForm) => {
        tourForm: TourForm
    }
    toggleSidebarPosition: () => {
        value: true
    }
    touchTourFormField: (key: string) => {
        key: string
    }
    updateRects: () => {
        value: true
    }
    updateStep: (
        index: number,
        patch: Partial<TourStep>
    ) => {
        index: number
        patch: Partial<TourStep>
    }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface productToursLogicMeta {
    __keaTypeGenInternalSelectorTypes: {
        selectedTour: (selectedTourId: string | null, tours: ProductTour[]) => TourForm | null
        isSelecting: (editorState: EditorState) => boolean
        selectingStepIndex: (editorState: EditorState) => number | null
        hoverElementRect: (hoverElement: HTMLElement | null, rectUpdateCounter: number) => ElementRect | null
        selectedElementRect: (selectedElement: HTMLElement | null, rectUpdateCounter: number) => ElementRect | null
        stepCount: (tourForm: TourForm) => number
        expandedStepRect: (
            expandedStepIndex: number | null,
            tourForm: TourForm,
            rectUpdateCounter: number,
            editorState: EditorState
        ) => ElementRect | null
    }
}

export type productToursLogicType = MakeLogicType<
    productToursLogicValues,
    productToursLogicActions,
    Record<string, any>,
    productToursLogicMeta
>

export const productToursLogic = kea<productToursLogicType>([
    path(['toolbar', 'product-tours', 'productToursLogic']),

    actions({
        showButtonProductTours: true,
        hideButtonProductTours: true,

        setEditorState: (state: EditorState) => ({ state }),

        setSessionRecordingConsent: (consent: boolean) => ({ consent }),

        // Step actions
        addStep: (stepType: ProductTourStepType) => ({ stepType }),
        selectElement: (element: HTMLElement) => ({ element }),
        setHoverElement: (element: HTMLElement | null) => ({ element }),
        clearSelectedElement: true,
        cancelEditing: true,
        removeStep: (index: number) => ({ index }),

        // Step configuration
        updateStep: (index: number, patch: Partial<TourStep>) => ({ index, patch }),

        // Tour CRUD
        selectTour: (id: string | null) => ({ id }),
        newTour: true,
        saveTour: true,
        deleteTour: (id: string) => ({ id }),

        // Preview
        previewTour: true,
        startPreviewMode: true,
        stopPreview: true,
        setLaunchedFromMainApp: (value: boolean) => ({ value }),

        updateRects: true,

        // Expanded step tracking
        setExpandedStepIndex: (index: number | null) => ({ index }),

        // Sidebar transition state (hide highlights during animation)
        setSidebarTransitioning: (transitioning: boolean) => ({ transitioning }),

        // Sidebar position toggle
        toggleSidebarPosition: true,

        draftAutoSave: true,
    }),

    loaders(() => ({
        tours: [
            [] as ProductTour[],
            {
                loadTours: async () => {
                    const result = await toolbarApi.productTours.list({ context: 'load_product_tours' })
                    if (!result.ok) {
                        return []
                    }
                    return Array.isArray(result.data) ? result.data : (result.data.results ?? [])
                },
            },
        ],
    })),

    reducers({
        buttonProductToursVisible: [
            false,
            {
                showButtonProductTours: () => true,
                hideButtonProductTours: () => false,
            },
        ],
        isPreviewing: [
            false,
            {
                startPreviewMode: () => true,
                stopPreview: () => false,
                selectTour: () => false,
            },
        ],
        selectedTourId: [
            null as string | 'new' | null,
            {
                selectTour: (_, { id }) => id,
                newTour: () => 'new',
                saveTourSuccess: (_, { tours }) => tours[0]?.id ?? null,
            },
        ],
        editorState: [
            { mode: 'idle' } as EditorState,
            {
                setEditorState: (_, { state }) => state,
                selectTour: () => ({ mode: 'idle' }),
                newTour: () => ({ mode: 'idle' }),
                hideButtonProductTours: () => ({ mode: 'idle' }),
                cancelEditing: () => ({ mode: 'idle' }),
            },
        ],
        // Element currently being hovered during selection mode
        hoverElement: [
            null as HTMLElement | null,
            {
                setHoverElement: (_, { element }) => element,
                setEditorState: () => null,
                hideButtonProductTours: () => null,
            },
        ],
        // Element selected for the current step being edited
        selectedElement: [
            null as HTMLElement | null,
            {
                selectElement: (_, { element }) => element,
                clearSelectedElement: () => null,
                setEditorState: () => null,
                cancelEditing: () => null,
                hideButtonProductTours: () => null,
            },
        ],
        rectUpdateCounter: [
            0,
            {
                updateRects: (state) => state + 1,
            },
        ],
        expandedStepIndex: [
            null as number | null,
            {
                setExpandedStepIndex: (_, { index }) => index,
                selectTour: () => null,
                newTour: () => null,
                removeStep: () => null,
                startPreviewMode: () => null,
            },
        ],
        sidebarTransitioning: [
            false,
            {
                setSidebarTransitioning: (_, { transitioning }) => transitioning,
                selectTour: () => true,
            },
        ],
        launchedFromMainApp: [
            false,
            {
                setLaunchedFromMainApp: (_, { value }) => value,
                selectTour: (state, { id }) => (id === null ? false : state),
            },
        ],
        sessionRecordingConsent: [
            null as boolean | null,
            { persist: true },
            {
                setSessionRecordingConsent: (_, { consent }) => consent,
            },
        ],
        sidebarPosition: [
            'right' as 'left' | 'right',
            { persist: true },
            {
                toggleSidebarPosition: (state) => (state === 'right' ? 'left' : 'right'),
            },
        ],
        draftSaveStatus: [
            null as 'unsaved' | 'saving' | 'saved' | null,
            {
                draftAutoSave: () => 'unsaved' as const,
                submitTourForm: () => 'saving' as const,
                submitTourFormSuccess: () => 'saved' as const,
                submitTourFormFailure: () => null,
                selectTour: () => null,
                newTour: () => null,
            },
        ],
    }),

    forms(({ values }) => ({
        tourForm: {
            defaults: { name: '', steps: [] } as TourForm,
            errors: ({ name, id, steps }) => {
                if (!name || !name.length) {
                    return { name: 'Must name this tour' }
                }
                // Check for duplicate names (excluding the current tour being edited)
                const isDuplicate = values.tours.some(
                    (tour: ProductTour) => tour.name.toLowerCase() === name.toLowerCase() && tour.id !== id
                )
                if (isDuplicate) {
                    return { name: 'A tour with this name already exists' }
                }

                const stepErrors = steps.map((s) => (hasIncompleteTargeting(s) ? { selector: 'Missing selector' } : {}))
                if (stepErrors.some((e) => Object.keys(e).length > 0)) {
                    return { steps: stepErrors }
                }

                return {}
            },
            submit: async (formValues) => {
                if (!formValues.id) {
                    return
                }
                // Tagged throw so kea-forms runs submitTourFormFailure (resets the
                // draft-save status) without reporting the failed request as an exception.
                const result = await toolbarApi.productTours.updateDraft(
                    formValues.id,
                    await buildDraftPayload(formValues, values.tours),
                    { context: 'save_product_tour_draft' }
                )
                if (!result.ok) {
                    throw new ToolbarRequestError('Failed to save draft', result.status)
                }
            },
        },
    })),

    connect(() => ({
        values: [toolbarConfigLogic, ['dataAttributes', 'uiHost', 'userIntent', 'productTourId', 'posthog']],
    })),

    selectors({
        selectedTour: [
            (s) => [s.selectedTourId, s.tours],
            (selectedTourId: string | 'new' | null, tours: ProductTour[]): TourForm | null => {
                if (selectedTourId === 'new') {
                    return newTour()
                }
                if (selectedTourId) {
                    const tour = tours.find((t: ProductTour) => t.id === selectedTourId)
                    if (tour) {
                        return tourToForm(tour)
                    }
                }
                return null
            },
        ],
        isSelecting: [(s) => [s.editorState], (editorState: EditorState) => editorState.mode === 'selecting'],
        selectingStepIndex: [
            (s) => [s.editorState],
            (editorState: EditorState): number | null =>
                editorState.mode === 'selecting' ? editorState.stepIndex : null,
        ],
        hoverElementRect: [
            (s) => [s.hoverElement, s.rectUpdateCounter],
            (hoverElement: HTMLElement | null): ElementRect | null => {
                if (!hoverElement) {
                    return null
                }
                return getRectForElement(hoverElement)
            },
        ],
        selectedElementRect: [
            (s) => [s.selectedElement, s.rectUpdateCounter],
            (selectedElement: HTMLElement | null): ElementRect | null => {
                if (!selectedElement) {
                    return null
                }
                return getRectForElement(selectedElement)
            },
        ],
        stepCount: [(s) => [s.tourForm], (tourForm: TourForm) => tourForm?.steps?.length ?? 0],
        expandedStepRect: [
            (s) => [s.expandedStepIndex, s.tourForm, s.rectUpdateCounter, s.editorState],
            (
                expandedStepIndex: number | null,
                tourForm: TourForm,
                _: number,
                editorState: EditorState
            ): ElementRect | null => {
                if (editorState.mode === 'selecting') {
                    return null
                }
                if (expandedStepIndex === null || !tourForm?.steps) {
                    return null
                }
                const step = tourForm.steps[expandedStepIndex]
                if (!step || !hasElementTarget(step)) {
                    return null
                }
                const element = getStepElement(step)
                return element ? getRectForElement(element) : null
            },
        ],
    }),

    subscriptions(({ actions, values, cache }) => ({
        selectedTour: async (selectedTour: TourForm | null) => {
            if (!selectedTour) {
                actions.resetTourForm()
                cache.lastDraftPayload = null
            } else {
                const incomingPayload = await buildDraftPayload(selectedTour, values.tours)
                if (!equal(incomingPayload, cache.lastDraftPayload)) {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    ;(actions.setTourFormValues as any)(selectedTour)
                    cache.lastDraftPayload = incomingPayload
                }
            }
        },
        tourForm: async (tourForm: TourForm) => {
            if (!values.selectedTourId || values.selectedTourId === 'new') {
                return
            }
            const payload = await buildDraftPayload(tourForm, values.tours)
            if (equal(cache.lastDraftPayload, payload)) {
                return
            }
            cache.lastDraftPayload = payload
            actions.draftAutoSave()
        },
    })),

    listeners(({ actions, values, cache }) => ({
        addStep: ({ stepType }) => {
            const nextIndex = values.tourForm?.steps?.length ?? 0
            toolbarPosthogJS.capture(ProductTourEvent.STEP_ADDED, {
                step_type: stepType,
                step_index: nextIndex,
                tour_id: values.tourForm?.id ?? null,
            })
            const steps = [...(values.tourForm?.steps || [])]
            const newStep = createDefaultStep(stepType) as TourStep
            steps.push(newStep)
            actions.setTourFormValue('steps', steps)
            actions.setExpandedStepIndex(nextIndex)
        },
        selectElement: async ({ element }) => {
            const { editorState, tourForm, dataAttributes } = values
            if (editorState.mode !== 'selecting') {
                return
            }

            const { stepIndex } = editorState
            const selector = elementToActionStep(element, dataAttributes).selector ?? ''
            const inferenceData = inferSelector(element)?.selector
            const screenshot = await captureAndUploadElementScreenshot(element).catch((e) => {
                toolbarLogger.warn('product_tours', 'Failed to capture element screenshot')
                // A failed upload request (ToolbarRequestError) is expected; only a bug in
                // the screenshot capture itself is worth an exception.
                if (!isToolbarRequestError(e)) {
                    captureToolbarException(e, 'product_tour_screenshot')
                }
                return null
            })

            const steps = [...(tourForm?.steps || [])]
            const existingStep = stepIndex < steps.length ? steps[stepIndex] : null

            const newStep: TourStep = {
                id: existingStep?.id ?? uuid(),
                type: 'modal',
                selector,
                content: existingStep?.content ?? getDefaultStepContent(),
                element,
                inferenceData,
                useManualSelector: false,
                elementTargeting: 'auto',
                progressionTrigger: existingStep?.progressionTrigger ?? 'button',
                ...(screenshot ? { screenshotMediaId: screenshot.mediaId } : {}),
            }

            if (stepIndex < steps.length) {
                steps[stepIndex] = newStep
            } else {
                steps.push(newStep)
            }

            actions.setTourFormValue('steps', steps)
            actions.setEditorState({ mode: 'idle' })
            actions.setExpandedStepIndex(stepIndex)
        },
        removeStep: ({ index }) => {
            if (values.tourForm) {
                const removedStep = values.tourForm.steps?.[index]
                toolbarPosthogJS.capture(ProductTourEvent.STEP_REMOVED, {
                    step_type: removedStep?.type ?? null,
                    step_index: index,
                    tour_id: values.tourForm.id ?? null,
                    remaining_steps: (values.tourForm.steps?.length ?? 1) - 1,
                })
                const steps = [...(values.tourForm.steps || [])]
                steps.splice(index, 1)
                actions.setTourFormValue('steps', steps)
                actions.setEditorState({ mode: 'idle' })
            }
        },
        updateStep: ({ index, patch }) => {
            if (!values.tourForm) {
                return
            }
            const steps = [...(values.tourForm.steps || [])]
            const step = steps[index]
            if (!step) {
                return
            }
            steps[index] = { ...step, ...patch }
            actions.setTourFormValue('steps', steps)
        },
        clearStepTargeting: ({ index }) => {
            if (!values.tourForm) {
                return
            }
            const steps = [...(values.tourForm.steps || [])]
            const step = steps[index]
            if (!step) {
                return
            }
            steps[index] = {
                ...step,
                type: 'modal',
                selector: undefined,
                inferenceData: undefined,
                screenshotMediaId: undefined,
                useManualSelector: undefined,
                elementTargeting: undefined,
                element: undefined,
            }
            actions.setTourFormValue('steps', steps)
        },
        newTour: () => {
            toolbarLogic.actions.setVisibleMenu('none')
            if (values.sessionRecordingConsent) {
                startRecording()
            }
        },
        setSessionRecordingConsent: ({ consent }) => {
            toolbarPosthogJS.capture(ProductTourEvent.CONSENT_SELECTED, { consent })
            if (consent && values.selectedTourId !== null) {
                startRecording()
            } else if (!consent) {
                toolbarPosthogJS.stopSessionRecording()
            }
        },
        selectTour: ({ id }) => {
            if (id !== null && id !== 'new') {
                toolbarLogic.actions.setVisibleMenu('none')
                if (values.sessionRecordingConsent) {
                    startRecording()
                }

                cache.disposables.add(() => {
                    const canFetch = (): boolean =>
                        values.draftSaveStatus !== 'unsaved' && values.draftSaveStatus !== 'saving'

                    if (canFetch()) {
                        actions.loadTours()
                    }
                    const intervalId = setInterval(() => {
                        if (canFetch()) {
                            actions.loadTours()
                        }
                    }, 3000)
                    return () => clearInterval(intervalId)
                }, 'draftPoll')

                return
            }
            cache.disposables.dispose('draftPoll')

            if (id === 'new') {
                toolbarLogic.actions.setVisibleMenu('none')
                if (values.sessionRecordingConsent) {
                    startRecording()
                }
                return
            }

            if (!values.isPreviewing && values.sessionRecordingConsent) {
                toolbarPosthogJS.stopSessionRecording()
            }
        },
        saveTour: async () => {
            const { tourForm, tours, uiHost, launchedFromMainApp } = values
            if (!tourForm?.name) {
                return
            }
            const isUpdate = !!tourForm.id
            const payload = { ...(await buildDraftPayload(tourForm, tours)), creation_context: 'toolbar' }
            const result = tourForm.id
                ? await toolbarApi.productTours.updateDraft(tourForm.id, payload, {
                      context: 'save_product_tour',
                      toastOnError: 'Failed to save tour',
                  })
                : await toolbarApi.productTours.create(payload, {
                      context: 'save_product_tour',
                      toastOnError: 'Failed to save tour',
                  })
            if (!result.ok) {
                return
            }
            const editUrl = joinWithUiHost(uiHost, urls.productTour(result.data.id, 'edit=true'))
            if (launchedFromMainApp) {
                window.close()
            } else {
                lemonToast.success(isUpdate ? 'Tour saved' : 'Tour created', {
                    button: {
                        label: 'Open in PostHog',
                        action: () => window.open(editUrl, '_blank'),
                    },
                })
                actions.loadTours()
                actions.selectTour(null)
            }
        },
        draftAutoSave: async (_, breakpoint) => {
            await breakpoint(1000)
            const { selectedTourId, tourForm } = values
            if (!selectedTourId || selectedTourId === 'new' || !tourForm?.name) {
                return
            }
            actions.submitTourForm()
        },
        previewTour: async () => {
            const { tourForm, posthog, selectedTourId, tours } = values
            if (posthog?.version && !hasMinProductToursVersion(posthog.version)) {
                lemonToast.error(`Requires posthog-js ${PRODUCT_TOURS_MIN_JS_VERSION}+`)
                return
            }

            if (!tourForm || !posthog?.productTours) {
                lemonToast.error('Unable to preview tour')
                return
            }

            // we can clean this up when posthog-js is updated in the main repo...
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const productTours = posthog.productTours as any
            if (typeof productTours.previewTour !== 'function') {
                lemonToast.error('Preview requires an updated version of posthog-js')
                return
            }

            // Check if the first element-targeted step's target exists on this page
            const firstElementStep = tourForm.steps.find((step) => hasElementTarget(step))
            if (firstElementStep && !getStepElement(firstElementStep)) {
                // eslint-disable-next-line no-alert
                lemonToast.error(
                    "Can't preview tour: the first step targets an element not found on this page.\n\nNavigate to a page where this element exists, or update the selector."
                )
                return
            }

            // Validation passed - now enter preview mode
            toolbarPosthogJS.capture(ProductTourEvent.PREVIEW_STARTED, {
                tour_id: tourForm.id ?? null,
                step_count: tourForm.steps.length,
            })
            actions.startPreviewMode()
            toolbarLogic.actions.toggleMinimized(true)

            // Get appearance from the saved tour if editing an existing one
            const existingTour =
                selectedTourId && selectedTourId !== 'new'
                    ? tours.find((t: ProductTour) => t.id === selectedTourId)
                    : null

            const tour = {
                id: `preview-${Date.now()}`,
                name: tourForm.name || 'Preview Tour',
                type: 'product_tour' as const,
                start_date: null,
                end_date: null,
                steps: (await importStepHtml()).prepareStepsForRender(tourForm.steps),
                appearance: existingTour?.content?.appearance,
            }

            // wait for sidebar animation - gross, sorry :(
            setTimeout(() => {
                productTours.previewTour(tour)
            }, PRODUCT_TOURS_SIDEBAR_TRANSITION_MS + 50)
        },
        stopPreview: () => {
            const { selectedTourId, tours, launchedFromMainApp } = values
            const selectedTour = tours.find((t: ProductTour) => t.id === selectedTourId)
            const isAnnouncement = selectedTour?.content?.type === 'announcement'

            if (isAnnouncement) {
                if (launchedFromMainApp) {
                    window.close() // go back to posthog app
                    return
                }
                actions.selectTour(null)
            }
            toolbarLogic.actions.toggleMinimized(false)
        },
        updateRects: () => {
            // If in selecting mode with a previously selected element that got
            // detached, try to re-find it via selector. We guard on
            // selectedElement being non-null so we don't auto-select when the
            // user hasn't clicked yet (selectedElement is cleared to null on
            // entering selecting mode).
            const { editorState, selectedElement, tourForm } = values
            if (editorState.mode === 'selecting' && selectedElement) {
                if (!selectedElement.isConnected) {
                    const step = tourForm?.steps?.[editorState.stepIndex]
                    if (step?.selector) {
                        const element = document.querySelector(step.selector) as HTMLElement | null
                        if (element) {
                            actions.selectElement(element)
                        } else {
                            actions.clearSelectedElement()
                        }
                    }
                }
            }
        },
        deleteTour: async ({ id }) => {
            const result = await toolbarApi.productTours.delete(id, {
                context: 'delete_product_tour',
                toastOnError: 'Failed to delete tour',
            })
            if (result.ok) {
                lemonToast.success('Tour deleted')
                actions.loadTours()
                actions.selectTour(null)
            }
        },
        showButtonProductTours: () => {
            toolbarPosthogJS.capture('toolbar mode triggered', { mode: 'product-tours', enabled: true })
            actions.loadTours()
        },
        hideButtonProductTours: () => {
            toolbarPosthogJS.capture('toolbar mode triggered', { mode: 'product-tours', enabled: false })
        },
        loadToursSuccess: () => {
            const { userIntent, productTourId } = values
            if (userIntent === 'edit-product-tour' && productTourId) {
                actions.setLaunchedFromMainApp(true)
                actions.selectTour(productTourId)
                toolbarConfigLogic.actions.clearUserIntent()
            } else if (userIntent === 'add-product-tour') {
                actions.setLaunchedFromMainApp(true)
                actions.newTour()
                toolbarConfigLogic.actions.clearUserIntent()
            } else if (userIntent === 'preview-product-tour' && productTourId) {
                actions.setLaunchedFromMainApp(true)
                actions.selectTour(productTourId)
                actions.previewTour()
                toolbarConfigLogic.actions.clearUserIntent()
            }
        },
    })),

    events(({ actions, values, cache }) => ({
        afterMount: () => {
            actions.loadTours()

            // Watch for DOM changes to update highlights when elements appear/disappear
            cache.mutationTimeout = null as ReturnType<typeof setTimeout> | null
            cache.mutationObserver = new MutationObserver(() => {
                // Debounce updates to avoid performance issues
                if (cache.mutationTimeout) {
                    clearTimeout(cache.mutationTimeout)
                }
                cache.mutationTimeout = setTimeout(() => {
                    actions.updateRects()
                }, 50)
            })
            cache.mutationObserver.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['style', 'class', 'hidden'],
            })

            cache.onMouseOver = (e: MouseEvent): void => {
                // During preview, don't track hover
                if (values.isPreviewing) {
                    return
                }
                // Only show hover highlight when in selecting mode
                if (values.editorState.mode !== 'selecting') {
                    return
                }
                const target = e.target as HTMLElement
                if (target && !isToolbarElement(target)) {
                    actions.setHoverElement(target)
                }
            }

            cache.onClick = (e: MouseEvent): void => {
                if (values.isPreviewing) {
                    return
                }

                const target = e.target as HTMLElement
                if (!target || isToolbarElement(target)) {
                    return
                }

                // In selecting mode: capture the element
                if (values.editorState.mode === 'selecting') {
                    e.preventDefault()
                    e.stopPropagation()
                    actions.selectElement(target)
                    return
                }
            }

            cache.onScroll = (): void => {
                if (values.hoverElement || values.selectedElement) {
                    actions.updateRects()
                }
            }

            cache.onResize = (): void => {
                if (values.hoverElement || values.selectedElement) {
                    actions.updateRects()
                }
            }

            cache.onKeyDown = (e: KeyboardEvent): void => {
                if (e.key === 'Escape' && values.editorState.mode !== 'idle') {
                    actions.setEditorState({ mode: 'idle' })
                }
            }

            document.addEventListener('mouseover', cache.onMouseOver, true)
            document.addEventListener('click', cache.onClick, true)
            document.addEventListener('scroll', cache.onScroll, { capture: true, passive: true })
            window.addEventListener('resize', cache.onResize)
            window.addEventListener('keydown', cache.onKeyDown)

            cache.onTourEnded = (): void => {
                if (values.isPreviewing) {
                    actions.stopPreview()
                }
            }
            window.addEventListener('PHProductTourCompleted', cache.onTourEnded)
            window.addEventListener('PHProductTourDismissed', cache.onTourEnded)
        },
        beforeUnmount: () => {
            if (cache.mutationTimeout) {
                clearTimeout(cache.mutationTimeout)
            }
            if (cache.mutationObserver) {
                cache.mutationObserver.disconnect()
            }
            if (cache.onMouseOver) {
                document.removeEventListener('mouseover', cache.onMouseOver, true)
            }
            if (cache.onClick) {
                document.removeEventListener('click', cache.onClick, true)
            }
            if (cache.onScroll) {
                document.removeEventListener('scroll', cache.onScroll, { capture: true })
            }
            if (cache.onResize) {
                window.removeEventListener('resize', cache.onResize)
            }
            if (cache.onKeyDown) {
                window.removeEventListener('keydown', cache.onKeyDown)
            }
            if (cache.onTourEnded) {
                window.removeEventListener('PHProductTourCompleted', cache.onTourEnded)
                window.removeEventListener('PHProductTourDismissed', cache.onTourEnded)
            }
            toolbarPosthogJS.stopSessionRecording()
        },
    })),
])
