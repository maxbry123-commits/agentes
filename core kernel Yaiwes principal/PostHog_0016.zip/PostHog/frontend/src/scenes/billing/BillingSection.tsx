import './Billing.scss'

import { useValues } from 'kea'
import { router } from 'kea-router'
import { Suspense, lazy, useEffect } from 'react'

import { LemonTabs, Spinner } from '@posthog/lemon-ui'

import { FEATURE_FLAGS } from 'lib/constants'
import { featureFlagLogic } from 'lib/logic/featureFlagLogic'
import { SceneExport } from 'scenes/sceneTypes'
import { urls } from 'scenes/urls'

import { Billing } from './Billing'
import { billingLogic } from './billingLogic'
import { BillingSpendView } from './BillingSpendView'
import { BillingUsage } from './BillingUsage'
import { BillingSectionId } from './types'

const BillingAlerts = lazy(() =>
    import('@posthog/products-billing-alerts/frontend/BillingAlerts').then((module) => ({
        default: module.BillingAlerts,
    }))
)

export const scene: SceneExport = {
    component: BillingSection,
    logic: billingLogic,
}

const allTabs: { key: BillingSectionId; label: string }[] = [
    { key: 'overview', label: 'Overview' },
    { key: 'usage', label: 'Usage' },
    { key: 'spend', label: 'Spend' },
    { key: 'alerts', label: 'Alerts' },
]

export function BillingSection(): JSX.Element {
    const { location, searchParams } = useValues(router)
    const { featureFlags, receivedFeatureFlags } = useValues(featureFlagLogic)
    const { canAccessBilling, canViewUsageAndSpend, canOnlyViewUsageAndSpend } = useValues(billingLogic)
    const billingAlertsEnabled = !!featureFlags[FEATURE_FLAGS.BILLING_ALERTS]
    const alertsRequested = location.pathname.includes('alerts')
    const billingAlertsPending = alertsRequested && !receivedFeatureFlags
    const tabs = billingAlertsEnabled || billingAlertsPending ? allTabs : allTabs.filter((tab) => tab.key !== 'alerts')

    const section = location.pathname.includes('spend')
        ? 'spend'
        : location.pathname.includes('usage')
          ? 'usage'
          : alertsRequested && (billingAlertsEnabled || billingAlertsPending)
            ? 'alerts'
            : 'overview'

    useEffect(() => {
        // Wait for feature flags before redirecting an alerts deep link away.
        if (alertsRequested && receivedFeatureFlags && !billingAlertsEnabled) {
            router.actions.replace(urls.organizationBillingSection('overview'))
        }
    }, [alertsRequested, billingAlertsEnabled, receivedFeatureFlags])

    // View-only members have no access to the Overview tab, so send them to Usage instead.
    // canOnlyViewUsageAndSpend is only true once org membership and flags are loaded, so admins never bounce.
    useEffect(() => {
        if (section === 'overview' && canOnlyViewUsageAndSpend) {
            router.actions.replace(urls.organizationBillingSection('usage'))
        }
    }, [section, canOnlyViewUsageAndSpend])

    // Usage and Spend are the read-only surfaces. Overview and Alerts stay admin-only, since both
    // can change what the organization is billed.
    const visibleTabs = tabs.filter((tab) =>
        tab.key === 'usage' || tab.key === 'spend' ? canViewUsageAndSpend : canAccessBilling
    )

    const handleTabChange = (key: BillingSectionId): void => {
        const newUrl = urls.organizationBillingSection(key)

        const currentHasParams = section === 'usage' || section === 'spend'
        const targetHasParams = key === 'usage' || key === 'spend'
        const shouldPreserveParams = currentHasParams && targetHasParams

        if (!shouldPreserveParams) {
            router.actions.push(newUrl)
            return
        }

        const paramsToPreserve = { ...searchParams }

        // When switching from spend to usage and breakdowns param is present,
        // ensure 'type' breakdown is included, since it's required for usage
        if (section === 'spend' && key === 'usage' && paramsToPreserve.breakdowns) {
            const currentBreakdowns = Array.isArray(paramsToPreserve.breakdowns) ? paramsToPreserve.breakdowns : []

            if (!currentBreakdowns.includes('type')) {
                paramsToPreserve.breakdowns = ['type', ...currentBreakdowns]
            }
        }

        router.actions.push(newUrl, paramsToPreserve)
    }

    return (
        <div className="flex flex-col">
            {visibleTabs.length > 0 && <LemonTabs activeKey={section} onChange={handleTabChange} tabs={visibleTabs} />}

            {section === 'overview' && <Billing />}
            {section === 'usage' && <BillingUsage />}
            {section === 'spend' && <BillingSpendView />}
            {section === 'alerts' && (
                <Suspense fallback={<Spinner className="text-3xl mx-auto my-8" />}>
                    {billingAlertsPending ? <Spinner className="text-3xl mx-auto my-8" /> : <BillingAlerts />}
                </Suspense>
            )}
        </div>
    )
}
