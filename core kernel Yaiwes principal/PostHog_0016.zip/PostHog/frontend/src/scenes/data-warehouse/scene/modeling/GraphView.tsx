import '@xyflow/react/dist/style.css'

import {
    Background,
    BackgroundVariant,
    Controls,
    NodeTypes,
    ReactFlow,
    ReactFlowProvider,
    useReactFlow,
} from '@xyflow/react'
import { useActions, useValues } from 'kea'
import { useEffect, useRef } from 'react'

import { IconArrowRight, IconCollapse, IconDatabase, IconExpand } from '@posthog/icons'
import { LemonButton, LemonSegmentedButton } from '@posthog/lemon-ui'

import { IconArrowDown } from 'lib/lemon-ui/icons'

import { themeLogic } from '~/layout/navigation-3000/themeLogic'
import { DataModelingNodeType } from '~/types'

import { NODE_TYPE_TAG_SETTINGS } from 'products/data_modeling/frontend/lineage/nodeStyles'

import { dataModelingLogic } from '../dataModelingLogic'
import { REACT_FLOW_NODE_TYPES } from './Node'
import { CreateModelNodeType, Edge, ElkDirection, Node } from './types'

const FIT_VIEW_OPTIONS = {
    padding: 0.2,
    maxZoom: 1,
}

const NODES_TO_SHOW: CreateModelNodeType[] = [
    {
        type: 'view',
        name: 'View',
        description: 'A virtual table based on a SQL query',
    },
    {
        type: 'matview',
        name: 'Materialized view',
        description: 'A persisted view with improved query performance',
    },
    {
        type: 'endpoint',
        name: 'Endpoint',
        description: 'A materialized endpoint for API access',
    },
]

function NodeTypeButton({
    node,
    isActive,
    onClick,
}: {
    node: CreateModelNodeType
    isActive: boolean
    onClick: () => void
}): JSX.Element {
    const color = NODE_TYPE_TAG_SETTINGS[node.type].color

    return (
        <div draggable>
            <LemonButton
                icon={
                    <span style={{ color }}>
                        <IconDatabase />
                    </span>
                }
                fullWidth
                active={isActive}
                onClick={onClick}
            >
                <div className="flex flex-col items-start flex-1">
                    <span>{node.name}</span>
                    {node.description && <span className="text-xs text-muted font-normal">{node.description}</span>}
                </div>
            </LemonButton>
        </div>
    )
}

export function NodeTypePanel(): JSX.Element {
    const { highlightedNodeType, layoutDirection, nodeTypePanelCollapsed } = useValues(dataModelingLogic)
    const { setHighlightedNodeType, setLayoutDirection, setSearchTerm, setNodeTypePanelCollapsed } =
        useActions(dataModelingLogic)

    const handleNodeTypeClick = (type: DataModelingNodeType): void => {
        if (highlightedNodeType === type) {
            setHighlightedNodeType(null)
        } else {
            setHighlightedNodeType(type)
            setSearchTerm('')
        }
    }

    if (nodeTypePanelCollapsed) {
        return (
            <div className="absolute right-1.5 bottom-1.5 z-10 bg-transparent p-2">
                <LemonButton
                    className="dark:bg-primary bg-white"
                    icon={<IconExpand />}
                    type="secondary"
                    size="small"
                    onClick={() => setNodeTypePanelCollapsed(false)}
                    tooltip="Expand panel"
                />
            </div>
        )
    }

    return (
        <div className="absolute right-4 top-4 bottom-4 w-64 bg-primary border rounded-lg shadow-xs overflow-hidden z-10">
            <div className="flex flex-col gap-1 p-4">
                <span className="flex gap-2 text-xs font-semibold items-center text-muted">Node types</span>
                {NODES_TO_SHOW.map((node, index) => (
                    <NodeTypeButton
                        key={`${node.type}-${index}`}
                        node={node}
                        isActive={highlightedNodeType === node.type}
                        onClick={() => handleNodeTypeClick(node.type)}
                    />
                ))}
            </div>
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <LemonSegmentedButton
                    value={layoutDirection}
                    onChange={(value) => setLayoutDirection(value as ElkDirection)}
                    options={[
                        {
                            value: 'RIGHT',
                            icon: <IconArrowRight />,
                            tooltip: 'Left to right',
                        },
                        {
                            value: 'DOWN',
                            icon: <IconArrowDown />,
                            tooltip: 'Top to bottom',
                        },
                    ]}
                    size="small"
                />
                <LemonButton
                    className="dark:bg-primary bg-white"
                    icon={<IconCollapse />}
                    type="secondary"
                    size="small"
                    onClick={() => setNodeTypePanelCollapsed(true)}
                    tooltip="Collapse panel"
                />
            </div>
        </div>
    )
}

function GraphViewContent(): JSX.Element {
    const { isDarkModeOn } = useValues(themeLogic)

    const { enrichedNodes, enrichedEdges, debouncedSearchTerm, savedViewport, searchLayoutNodes } =
        useValues(dataModelingLogic)
    const { onEdgesChange, onNodesChange, setReactFlowInstance, setReactFlowWrapper } = useActions(dataModelingLogic)

    const reactFlowWrapper = useRef<HTMLDivElement>(null)
    const reactFlowInstance = useReactFlow<Node, Edge>()

    useEffect(() => {
        setReactFlowInstance(reactFlowInstance)
    }, [reactFlowInstance, setReactFlowInstance])

    useEffect(() => {
        setReactFlowWrapper(reactFlowWrapper)
    }, [setReactFlowWrapper])

    useEffect(() => {
        if (debouncedSearchTerm.length > 0 && searchLayoutNodes && searchLayoutNodes.length > 0) {
            reactFlowInstance.fitView({
                nodes: searchLayoutNodes,
                duration: 400,
                maxZoom: 1,
            })
        }
    }, [debouncedSearchTerm, reactFlowInstance, searchLayoutNodes])

    return (
        <div ref={reactFlowWrapper} className="relative w-full border rounded-lg overflow-hidden h-[calc(100vh-17rem)]">
            <ReactFlow<Node, Edge>
                fitView={!savedViewport}
                defaultViewport={savedViewport ?? undefined}
                nodes={enrichedNodes}
                edges={enrichedEdges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                nodeTypes={REACT_FLOW_NODE_TYPES as NodeTypes}
                nodesDraggable={false}
                colorMode={isDarkModeOn ? 'dark' : 'light'}
                fitViewOptions={FIT_VIEW_OPTIONS}
                proOptions={{ hideAttribution: true }}
                elevateNodesOnSelect={false}
                minZoom={0.25}
                maxZoom={1.5}
                onlyRenderVisibleElements
            >
                <Background gap={36} variant={BackgroundVariant.Dots} bgColor="var(--color-bg-primary)" />
                <Controls showInteractive={false} fitViewOptions={FIT_VIEW_OPTIONS} />
                <NodeTypePanel />
            </ReactFlow>
        </div>
    )
}

// TODO: fold this onto the shared <LineageGraph> (products/data_modeling/frontend/lineage) once the
// DAG concept is removed from the UI and the backend resolves schedules per-node. A team then has a
// single implicit graph, so dataModelingLogic can drop its multi-DAG selection/viewport machinery and
// this canvas collapses to <LineageGraph variant="canvas"> with search/legend passed as `panels`.
export function GraphView(): JSX.Element {
    return (
        <ReactFlowProvider>
            <GraphViewContent />
        </ReactFlowProvider>
    )
}
