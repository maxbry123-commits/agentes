import { useActions, useValues } from 'kea'

import { LemonButton, LemonInput, LemonTable, LemonTag, Link, Spinner, Tooltip } from '@posthog/lemon-ui'

import { AccessControlAction } from 'lib/components/AccessControlAction'
import { TZLabel } from 'lib/components/TZLabel'
import { FEATURE_FLAGS } from 'lib/constants'
import { More } from 'lib/lemon-ui/LemonButton/More'
import { LemonTableLink } from 'lib/lemon-ui/LemonTable/LemonTableLink'
import { humanFriendlyDetailedTime } from 'lib/utils/datetime'
import { urls } from 'scenes/urls'

import { AccessControlObjectModal } from '~/layout/navigation-3000/sidepanel/panels/access_control/AccessControlObjectModal'
import { DataWarehouseSavedQueryOrigin } from '~/queries/schema/schema-general'
import {
    AccessControlLevel,
    AccessControlResourceType,
    DataWarehouseSavedQuery,
    DataWarehouseSavedQueryRunHistory,
} from '~/types'

import { STATUS_TAG_SETTINGS } from 'products/data_modeling/frontend/lineage/nodeStyles'

import { TableCertificationTag } from '../TableCertificationBadge'
import { PAGE_SIZE, viewsTabLogic } from './viewsTabLogic'

const getDisabledReason = (view: DataWarehouseSavedQuery): string | undefined => {
    if (view.managed_viewset_kind !== null) {
        return `Cannot delete a view that belongs to a managed viewset. You can turn the viewset off in the ${urls.dataWarehouseManagedViewsets()} page.`
    }
    if (view.origin === DataWarehouseSavedQueryOrigin.ENDPOINT) {
        return `Cannot delete a view that belongs to an endpoint. You can disable materialization on this endpoint's page.`
    }

    return undefined
}

function RunHistoryDisplay({
    runHistory,
    loading,
}: {
    runHistory?: DataWarehouseSavedQueryRunHistory[]
    loading?: boolean
}): JSX.Element {
    if (loading) {
        return <Spinner className="text-sm" />
    }

    if (!runHistory || runHistory.length === 0) {
        return <span className="text-muted">-</span>
    }

    // Show up to 5 most recent runs, reversed so the most recent is on the right
    const displayRuns = runHistory.slice(0, 5).reverse()

    return (
        <div className="flex gap-1">
            {displayRuns.map((run, index) => {
                const friendlyTime = run.timestamp ? humanFriendlyDetailedTime(run.timestamp) : ''
                return (
                    <Tooltip
                        key={index}
                        title={`${run.status}${friendlyTime ? ` - ${friendlyTime}` : ''}`}
                        placement="top"
                    >
                        <div
                            className={`w-4 h-4 rounded-sm ${run.status === 'Completed' ? 'bg-success' : 'bg-danger'}`}
                        />
                    </Tooltip>
                )
            })}
        </div>
    )
}

function DependencyCount({ count, loading }: { count?: number; loading?: boolean }): JSX.Element {
    if (loading || count === undefined) {
        return <Spinner className="text-sm" />
    }
    return <span>{count}</span>
}

interface ViewsTabProps {
    /** Optional function to build the URL when clicking on a view. Defaults to SQL editor. */
    getViewUrl?: (view: DataWarehouseSavedQuery) => string
}

export function ViewsTab({ getViewUrl }: ViewsTabProps = {}): JSX.Element {
    const {
        filteredViews,
        filteredMaterializedViews,
        visibleMaterializedViews,
        visibleViews,
        viewsLoading,
        searchTerm,
        materializedViewDependenciesMapLoading,
        viewDependenciesMapLoading,
        runHistoryMapLoading,
        materializedViewsCurrentPage,
        viewsCurrentPage,
        accessControlModalOpen,
        editingAccessControlView,
        featureFlags,
        viewsMapById,
    } = useValues(viewsTabLogic)
    const {
        setSearchTerm,
        deleteView,
        runMaterialization,
        setMaterializedViewsPage,
        setViewsPage,
        openAccessControlModal,
        closeAccessControlModal,
    } = useActions(viewsTabLogic)

    const warehouseAccessControlEnabled = !!featureFlags[FEATURE_FLAGS.HOGQL_WAREHOUSE_ACCESS_CONTROL]

    const nameWithCertification = (view: DataWarehouseSavedQuery, content: JSX.Element): JSX.Element => (
        <div className="flex items-center gap-2">
            <div>{content}</div>
            <TableCertificationTag certification={viewsMapById[view.id]?.certification} />
        </div>
    )

    const accessControlMenuButton = (view: DataWarehouseSavedQuery): JSX.Element | null => {
        if (!warehouseAccessControlEnabled || view.managed_viewset_kind !== null) {
            return null
        }
        return <LemonButton onClick={() => openAccessControlModal(view)}>Access control</LemonButton>
    }

    return (
        <div className="space-y-4">
            {editingAccessControlView ? (
                <AccessControlObjectModal
                    isOpen={accessControlModalOpen}
                    onClose={closeAccessControlModal}
                    resource={AccessControlResourceType.WarehouseView}
                    resource_id={editingAccessControlView.id}
                    title={editingAccessControlView.name}
                    description="Control who can query this view. Users without access won't see it and queries referencing it will fail for them."
                />
            ) : null}
            {(filteredViews.length > 0 || filteredMaterializedViews.length > 0 || searchTerm) && (
                <div className="flex gap-2 justify-between items-center">
                    <LemonInput
                        type="search"
                        placeholder="Search views..."
                        onChange={setSearchTerm}
                        value={searchTerm}
                    />
                </div>
            )}

            {/* Materialized Views Section */}
            {filteredMaterializedViews.length > 0 && (
                <div>
                    <h3 className="text-lg font-semibold mb-2">Materialized views</h3>
                    <p className="text-muted mb-2">
                        Materialized views are refreshed on a schedule and stored as tables for faster query
                        performance.
                    </p>
                    <LemonTable
                        dataSource={visibleMaterializedViews}
                        loading={viewsLoading}
                        columns={[
                            {
                                title: 'Name',
                                key: 'name',
                                render: (_, view: DataWarehouseSavedQuery) =>
                                    nameWithCertification(
                                        view,
                                        view.managed_viewset_kind !== null ? (
                                            <>
                                                <Tooltip
                                                    interactive
                                                    title={
                                                        <>
                                                            You cannot edit the definition for a view that belongs to a
                                                            managed viewset. You can enable/disable the viewset in the{' '}
                                                            <Link to={urls.dataWarehouseManagedViewsets()}>
                                                                Managed Viewsets
                                                            </Link>{' '}
                                                            page.
                                                        </>
                                                    }
                                                >
                                                    <span className="font-bold text-primary">{view.name}</span>
                                                </Tooltip>
                                                <br />
                                                <span className="text-muted text-xs">
                                                    Created by the{' '}
                                                    <Link
                                                        to={urls.dataWarehouseManagedViewsets()}
                                                        className="text-muted"
                                                    >
                                                        <code>{view.managed_viewset_kind}</code>
                                                    </Link>{' '}
                                                    managed viewset
                                                </span>
                                            </>
                                        ) : view.origin === DataWarehouseSavedQueryOrigin.ENDPOINT ? (
                                            <LemonTableLink
                                                to={urls.endpoint(view.name)}
                                                title={view.name}
                                                description={`Created by the ${view.name} endpoint.`}
                                            />
                                        ) : (
                                            <LemonTableLink
                                                to={getViewUrl?.(view) ?? urls.sqlEditor({ view_id: view.id })}
                                                title={view.name}
                                                description="Materialized view"
                                            />
                                        )
                                    ),
                            },
                            {
                                title: 'Last run',
                                key: 'last_run_at',
                                render: (_, view) => {
                                    return view.last_run_at ? (
                                        <TZLabel time={view.last_run_at} formatDate="MMM DD, YYYY" formatTime="HH:mm" />
                                    ) : (
                                        'Never'
                                    )
                                },
                            },
                            {
                                title: 'Status',
                                key: 'status',
                                render: (_, view) => {
                                    if (!view.status) {
                                        return null
                                    }
                                    if (view.latest_error && view.status === 'Failed') {
                                        return (
                                            <Tooltip title={view.latest_error} interactive>
                                                <LemonTag type="danger">Failed</LemonTag>
                                            </Tooltip>
                                        )
                                    }
                                    return (
                                        <LemonTag type={STATUS_TAG_SETTINGS[view.status] || 'default'}>
                                            {view.status}
                                        </LemonTag>
                                    )
                                },
                            },
                            {
                                title: 'Run history',
                                key: 'run_history',
                                tooltip: 'Recent run status (up to 5 most recent)',
                                render: (_, view) => (
                                    <RunHistoryDisplay runHistory={view.run_history} loading={runHistoryMapLoading} />
                                ),
                            },
                            {
                                title: 'Upstream',
                                key: 'upstream_count',
                                tooltip: 'Number of immediate upstream dependencies',
                                render: (_, view) => (
                                    <DependencyCount
                                        count={view.upstream_dependency_count}
                                        loading={materializedViewDependenciesMapLoading}
                                    />
                                ),
                            },
                            {
                                title: 'Downstream',
                                key: 'downstream_count',
                                tooltip: 'Number of immediate downstream dependencies',
                                render: (_, view) => (
                                    <DependencyCount
                                        count={view.downstream_dependency_count}
                                        loading={materializedViewDependenciesMapLoading}
                                    />
                                ),
                            },
                            {
                                key: 'actions',
                                width: 0,
                                render: (_, view) => (
                                    <More
                                        overlay={
                                            <>
                                                <AccessControlAction
                                                    resourceType={AccessControlResourceType.WarehouseObjects}
                                                    minAccessLevel={AccessControlLevel.Editor}
                                                >
                                                    <LemonButton
                                                        onClick={() => runMaterialization(view.id)}
                                                        disabledReason={
                                                            view.status === 'Running'
                                                                ? 'Materialization is already running'
                                                                : undefined
                                                        }
                                                    >
                                                        Sync now
                                                    </LemonButton>
                                                </AccessControlAction>
                                                {accessControlMenuButton(view)}
                                                <AccessControlAction
                                                    resourceType={AccessControlResourceType.WarehouseObjects}
                                                    minAccessLevel={AccessControlLevel.Editor}
                                                    userAccessLevel={view.user_access_level}
                                                >
                                                    <LemonButton
                                                        status="danger"
                                                        onClick={() => deleteView(view.id)}
                                                        disabledReason={getDisabledReason(view)}
                                                    >
                                                        Delete
                                                    </LemonButton>
                                                </AccessControlAction>
                                            </>
                                        }
                                    />
                                ),
                            },
                        ]}
                        pagination={{
                            controlled: true,
                            pageSize: PAGE_SIZE,
                            currentPage: materializedViewsCurrentPage,
                            entryCount: filteredMaterializedViews.length,
                            onForward: () => {
                                setMaterializedViewsPage(materializedViewsCurrentPage + 1)
                            },
                            onBackward: () => {
                                setMaterializedViewsPage(materializedViewsCurrentPage - 1)
                            },
                        }}
                    />
                </div>
            )}

            {/* Regular Views Section */}
            {filteredViews.length > 0 && (
                <div>
                    <h3 className="text-lg font-semibold mb-2">Views</h3>
                    <p className="text-muted mb-2">
                        Views are virtual tables created from SQL queries. They are computed on-the-fly when queried.
                    </p>
                    <LemonTable
                        dataSource={visibleViews}
                        loading={viewsLoading}
                        columns={[
                            {
                                title: 'Name',
                                key: 'name',
                                render: (_, view: DataWarehouseSavedQuery) =>
                                    nameWithCertification(
                                        view,
                                        view.managed_viewset_kind !== null ? (
                                            <>
                                                <Tooltip
                                                    interactive
                                                    title={
                                                        <>
                                                            You cannot edit the definition for a view that belongs to a
                                                            managed viewset. You can enable/disable the viewset in the{' '}
                                                            <Link to={urls.dataWarehouseManagedViewsets()}>
                                                                Managed Viewsets
                                                            </Link>{' '}
                                                            page.
                                                        </>
                                                    }
                                                >
                                                    <span className="font-bold text-primary">{view.name}</span>
                                                </Tooltip>
                                                <br />
                                                <span className="text-muted text-xs">
                                                    Created by the{' '}
                                                    <Link
                                                        to={urls.dataWarehouseManagedViewsets()}
                                                        className="text-muted"
                                                    >
                                                        <code>{view.managed_viewset_kind}</code>
                                                    </Link>{' '}
                                                    managed viewset
                                                </span>
                                            </>
                                        ) : (
                                            <LemonTableLink
                                                to={getViewUrl?.(view) ?? urls.sqlEditor({ view_id: view.id })}
                                                title={view.name}
                                            />
                                        )
                                    ),
                            },
                            {
                                title: 'Created',
                                key: 'created_at',
                                render: (_, view) =>
                                    view.created_at ? (
                                        <TZLabel time={view.created_at} formatDate="MMM DD, YYYY" formatTime="HH:mm" />
                                    ) : (
                                        '-'
                                    ),
                            },
                            {
                                title: 'Upstream',
                                key: 'upstream_count',
                                tooltip: 'Number of immediate upstream dependencies',
                                render: (_, view) => (
                                    <DependencyCount
                                        count={view.upstream_dependency_count}
                                        loading={viewDependenciesMapLoading}
                                    />
                                ),
                            },
                            {
                                title: 'Downstream',
                                key: 'downstream_count',
                                tooltip: 'Number of immediate downstream dependencies',
                                render: (_, view) => (
                                    <DependencyCount
                                        count={view.downstream_dependency_count}
                                        loading={viewDependenciesMapLoading}
                                    />
                                ),
                            },
                            {
                                key: 'actions',
                                width: 0,
                                render: (_, view) => (
                                    <More
                                        overlay={
                                            <>
                                                {accessControlMenuButton(view)}
                                                <AccessControlAction
                                                    resourceType={AccessControlResourceType.WarehouseObjects}
                                                    minAccessLevel={AccessControlLevel.Editor}
                                                    userAccessLevel={view.user_access_level}
                                                >
                                                    <LemonButton
                                                        status="danger"
                                                        onClick={() => deleteView(view.id)}
                                                        disabledReason={getDisabledReason(view)}
                                                    >
                                                        Delete
                                                    </LemonButton>
                                                </AccessControlAction>
                                            </>
                                        }
                                    />
                                ),
                            },
                        ]}
                        pagination={{
                            controlled: true,
                            pageSize: PAGE_SIZE,
                            currentPage: viewsCurrentPage,
                            entryCount: filteredViews.length,
                            onForward: () => {
                                setViewsPage(viewsCurrentPage + 1)
                            },
                            onBackward: () => {
                                setViewsPage(viewsCurrentPage - 1)
                            },
                        }}
                    />
                </div>
            )}

            {/* Empty State */}
            {!viewsLoading && filteredViews.length === 0 && filteredMaterializedViews.length === 0 && (
                <div className="text-center py-12">
                    <h3 className="text-xl font-semibold mb-2">No views found</h3>
                    {searchTerm ? (
                        <p className="text-muted">No views match your search. Try adjusting your search term.</p>
                    ) : (
                        <p className="text-muted">
                            Create your first view to transform and organize your data warehouse tables.
                        </p>
                    )}
                    <AccessControlAction
                        resourceType={AccessControlResourceType.WarehouseObjects}
                        minAccessLevel={AccessControlLevel.Editor}
                    >
                        <LemonButton type="primary" to={urls.sqlEditor({ source: 'view' })} className="inline-block">
                            Create view
                        </LemonButton>
                    </AccessControlAction>
                </div>
            )}
        </div>
    )
}
