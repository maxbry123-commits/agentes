import { useActions, useValues } from 'kea'

import { IconCheck, IconX } from '@posthog/icons'

import { AutoSizer } from 'lib/components/AutoSizer'
import { Resizer } from 'lib/components/Resizer/Resizer'
import { LemonButton } from 'lib/lemon-ui/LemonButton'
import { CodeEditor, CodeEditorProps } from 'lib/monaco/CodeEditor'
import { cn } from 'lib/utils/css-classes'

import { HogQLQuery } from '~/queries/schema/schema-general'

import { editorSizingLogic } from './editorSizingLogic'
import { sqlEditorLogic } from './sqlEditorLogic'

interface QueryPaneProps {
    queryInput: string
    promptError: string | null
    codeEditorProps: Partial<CodeEditorProps>
    sourceQuery: HogQLQuery
    originalValue?: string
    onRun?: () => void
    editorVimModeEnabled?: boolean
    constrainHeight?: boolean
}

export function QueryPane(props: QueryPaneProps): JSX.Element {
    const { queryPaneHeight, queryPaneDesiredSize, queryPaneResizerProps } = useValues(editorSizingLogic)
    const { onAcceptSuggestedQueryInput, onRejectSuggestedQueryInput } = useActions(sqlEditorLogic)
    const { acceptText, rejectText, diffShowRunButton } = useValues(sqlEditorLogic)
    // Without an output pane beneath it the editor owns its column, so it takes whatever height the
    // database tree gives the row rather than leaving dead space next to the schema list.
    const fillsColumn = props.constrainHeight === false

    return (
        <>
            <div
                // No min-h-0 here: Tailwind runs with `important`, so the utility would beat the
                // inline min-height that keeps the editor readable when the tree is closed.
                className={cn('relative flex flex-row w-full bg-primary', fillsColumn && 'flex-1')}
                // eslint-disable-next-line react/forbid-dom-props
                style={{
                    height: fillsColumn ? undefined : `${queryPaneHeight}px`,
                    minHeight: fillsColumn ? `${queryPaneHeight}px` : undefined,
                    maxHeight: !fillsColumn && queryPaneDesiredSize === null ? '35%' : undefined,
                }}
                ref={queryPaneResizerProps.containerRef}
            >
                <div className="relative flex flex-col w-full min-h-0">
                    <div className="flex-1 min-h-0" data-attr="hogql-query-editor">
                        <AutoSizer
                            renderProp={({ height, width }) =>
                                height && width ? (
                                    <CodeEditor
                                        language="hogQL"
                                        value={props.queryInput}
                                        sourceQuery={props.sourceQuery}
                                        height={height}
                                        width={width}
                                        originalValue={props.originalValue}
                                        enableVimMode={props.editorVimModeEnabled}
                                        autoFocus={true}
                                        {...props.codeEditorProps}
                                        options={{
                                            minimap: {
                                                enabled: false,
                                            },
                                            wordWrap: 'on',
                                            scrollBeyondLastLine: !!props.originalValue,
                                            automaticLayout: true,
                                            fixedOverflowWidgets: true,
                                            glyphMargin: true,
                                            suggest: {
                                                showInlineDetails: true,
                                            },
                                            quickSuggestionsDelay: 300,
                                        }}
                                    />
                                ) : null
                            }
                        />
                    </div>
                    {props.originalValue && (
                        <div
                            className="absolute flex gap-1 bg-bg-light rounded border py-1 px-1.5 z-10 left-1/2 -translate-x-1/2 bottom-4 whitespace-nowrap"
                            // eslint-disable-next-line react/forbid-dom-props
                            style={{ boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)' }}
                        >
                            {!!diffShowRunButton && (
                                <LemonButton
                                    type="primary"
                                    icon={<IconCheck color="var(--success)" />}
                                    onClick={() => {
                                        onAcceptSuggestedQueryInput(true)
                                    }}
                                    tooltipPlacement="top"
                                    size="small"
                                >
                                    {acceptText} & run
                                </LemonButton>
                            )}
                            <LemonButton
                                type="tertiary"
                                icon={<IconCheck color="var(--success)" />}
                                onClick={() => {
                                    onAcceptSuggestedQueryInput()
                                }}
                                tooltipPlacement="top"
                                size="small"
                            >
                                {acceptText}
                            </LemonButton>
                            <LemonButton
                                status="danger"
                                icon={<IconX />}
                                onClick={() => {
                                    onRejectSuggestedQueryInput()
                                }}
                                tooltipPlacement="top"
                                size="small"
                            >
                                {rejectText}
                            </LemonButton>
                        </div>
                    )}
                </div>
                <Resizer {...queryPaneResizerProps} />
            </div>
        </>
    )
}
