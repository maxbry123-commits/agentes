import { Monaco } from '@monaco-editor/react'
import { BindLogic, useActions, useValues } from 'kea'
import type { editor as importedEditor } from 'monaco-editor'
import { useEffect, useMemo, useRef, useState } from 'react'

import { IconBook, IconChevronDown, IconDownload, IconNotebook, IconX } from '@posthog/icons'
import { LemonModal, Spinner } from '@posthog/lemon-ui'

import { AccessControlAction } from 'lib/components/AccessControlAction'
import { useOnMountEffect } from 'lib/hooks/useOnMountEffect'
import { LemonButton } from 'lib/lemon-ui/LemonButton'
import { LemonMenuOverlay } from 'lib/lemon-ui/LemonMenu/LemonMenu'
import { TreeDataItem } from 'lib/lemon-ui/LemonTree/LemonTree'
import { useAttachedLogic } from 'lib/logic/scenes/useAttachedLogic'
import { getAccessControlDisabledReason } from 'lib/utils/accessControlUtils'

import { AccessControlObjectModal } from '~/layout/navigation-3000/sidepanel/panels/access_control/AccessControlObjectModal'
import { DatabaseTree } from '~/layout/panel-layout/DatabaseTree/DatabaseTree'
import { iconForType } from '~/layout/panel-layout/ProjectTree/defaultTree'
import { SceneTitleSection } from '~/layout/scenes/components/SceneTitleSection'
import { DataNodeLogicProps, dataNodeLogic } from '~/queries/nodes/DataNode/dataNodeLogic'
import { variableModalLogic } from '~/queries/nodes/DataVisualization/Components/Variables/variableModalLogic'
import {
    VariablesLogicProps,
    variablesLogic,
} from '~/queries/nodes/DataVisualization/Components/Variables/variablesLogic'
import {
    DataVisualizationLogicProps,
    dataVisualizationLogic,
} from '~/queries/nodes/DataVisualization/dataVisualizationLogic'
import { displayLogic } from '~/queries/nodes/DataVisualization/displayLogic'
import { applyDataVisualizationQueryUpdate } from '~/queries/nodes/DataVisualization/queryUpdateUtils'
import { AccessControlLevel, AccessControlResourceType } from '~/types'

import { useAttachedContext } from 'products/posthog_ai/frontend/api/logics'

import { ExpressionModal } from '../ExpressionModal'
import { dataWarehouseViewsLogic } from '../saved_queries/dataWarehouseViewsLogic'
import { ViewLinkModal } from '../ViewLinkModal'
import { connectionSelectorLogic } from './connectionSelectorLogic'
import { editorSceneLogic } from './editorSceneLogic'
import { editorSizingLogic } from './editorSizingLogic'
import { applyExecuteSqlToolOutput, getExecuteSqlToolContext } from './maxSqlTool'
import { QueryInfo } from './output-pane-tabs/QueryInfo'
import { OutputPane } from './OutputPane'
import { outputPaneLogic } from './outputPaneLogic'
import { QueryHistoryModal } from './QueryHistoryModal'
import { QueryWindow } from './QueryWindow'
import { sqlEditorLogic } from './sqlEditorLogic'
import { SQLEditorMode, isEmbeddedSQLEditorMode } from './sqlEditorModes'

export enum SQLEditorPanel {
    Full = 'full',
    Query = 'query',
    Output = 'output',
}

const VARIABLE_QUERY_SYNC_DEBOUNCE_MS = 150

interface SQLEditorProps {
    tabId?: string
    mode?: SQLEditorMode
    showDatabaseTree?: boolean
    defaultShowDatabaseTree?: boolean
    /** Extra top-level sections for the database tree, owned by the embedder — see QueryDatabase. */
    extraTreeSections?: TreeDataItem[]
    panel?: SQLEditorPanel
    showOutputToolbar?: boolean
    onRunQuery?: () => void
    runQueryLoading?: boolean
    runQueryDisabledReason?: string
    runQueryTooltip?: string
    /** With onRunQuery: flips the run button to Cancel while runQueryLoading. */
    onCancelQuery?: () => void
    cancelQueryLoading?: boolean
    /** Drop the toolbar's run button, for hosts that offer the run affordance themselves. */
    hideRunButton?: boolean
    onShareTab?: () => void
    queryPaneDefaultHeight?: number
    /** Whether the query pane's code editor may grab focus on mount. Defaults to true. */
    autoFocusQueryPane?: boolean
}

export function SQLEditor({
    tabId,
    mode = SQLEditorMode.FullScene,
    showDatabaseTree,
    defaultShowDatabaseTree = true,
    extraTreeSections,
    panel = SQLEditorPanel.Full,
    showOutputToolbar = true,
    onRunQuery,
    runQueryLoading,
    runQueryDisabledReason,
    runQueryTooltip,
    onCancelQuery,
    cancelQueryLoading,
    hideRunButton,
    onShareTab,
    queryPaneDefaultHeight,
    autoFocusQueryPane,
}: SQLEditorProps): JSX.Element {
    const ref = useRef(null)
    const navigatorRef = useRef(null)
    const queryPaneRef = useRef(null)
    const biEditorRef = useRef(null)
    const sidebarRef = useRef(null)
    const databaseTreeRef = useRef(null)
    const [hasShownDatabaseTree, setHasShownDatabaseTree] = useState(defaultShowDatabaseTree)

    const shouldShowDatabaseTree = showDatabaseTree ?? hasShownDatabaseTree
    const showQueryPanel = panel !== SQLEditorPanel.Output
    const showOutputPanel = panel !== SQLEditorPanel.Query
    const showSceneTitle = panel === SQLEditorPanel.Full && mode === SQLEditorMode.FullScene
    const showDatabaseTreePanel = showQueryPanel && shouldShowDatabaseTree
    const showFullSceneModals = mode === SQLEditorMode.FullScene

    const editorSizingLogicProps = useMemo(() => {
        // The scene keeps one shared set of pane sizes across its tabs. Notebook cells each get their
        // own, so resizing one cell's editor doesn't resize every other SQL cell in the notebook.
        const sizingKey = isEmbeddedSQLEditorMode(mode) ? `embedded:${tabId ?? 'new'}` : 'scene'
        const resizerKey = (name: string): string => (sizingKey === 'scene' ? name : `${name}:${sizingKey}`)

        return {
            logicKey: sizingKey,
            editorSceneRef: ref,
            navigatorRef,
            sidebarRef,
            databaseTreeRef,
            queryPaneDefaultHeight,
            biEditorResizerProps: {
                containerRef: biEditorRef,
                logicKey: 'bi-editor-pane',
                placement: 'bottom' as const,
                persistent: true,
                persistPrefix: 'v1',
            },
            sourceNavigatorResizerProps: {
                containerRef: navigatorRef,
                logicKey: resizerKey('source-navigator'),
                placement: 'right' as const,
            },
            sidebarResizerProps: {
                containerRef: sidebarRef,
                logicKey: resizerKey('sidebar-resizer'),
                placement: 'right' as const,
            },
            queryPaneResizerProps: {
                containerRef: queryPaneRef,
                logicKey: resizerKey('query-pane'),
                placement: 'bottom' as const,
            },
            databaseTreeResizerProps: {
                containerRef: databaseTreeRef,
                logicKey: resizerKey('database-tree'),
                placement: 'right' as const,
                persistent: true,
                marginTop: mode === SQLEditorMode.FullScene ? 8 : 0,
            },
        }
    }, [mode, tabId, queryPaneDefaultHeight])

    const [monacoAndEditor, setMonacoAndEditor] = useState(
        null as [Monaco, importedEditor.IStandaloneCodeEditor] | null
    )
    const [monaco, editor] = monacoAndEditor ?? []

    useOnMountEffect(() => {
        return () => {
            setMonacoAndEditor(null)
        }
    })

    const logic = sqlEditorLogic({
        tabId: tabId || '',
        mode,
        monaco,
        editor,
    })

    const { sourceQuery, dataLogicKey } = useValues(logic)
    const { setSourceQuery } = useActions(logic)
    const sourceQueryRef = useRef(sourceQuery)
    sourceQueryRef.current = sourceQuery

    const dataVisualizationLogicProps: DataVisualizationLogicProps = {
        key: dataLogicKey,
        query: sourceQuery,
        dashboardId: undefined,
        dataNodeCollectionId: dataLogicKey,
        editMode: true,
        loadPriority: undefined,
        cachedResults: undefined,
        variablesOverride: undefined,
        setQuery: (setter) => applyDataVisualizationQueryUpdate(sourceQueryRef, setter, setSourceQuery),
    }

    const dataNodeLogicProps: DataNodeLogicProps = {
        query: sourceQuery.source,
        key: dataLogicKey,
        cachedResults: undefined,
        loadPriority: undefined,
        dataNodeCollectionId: dataLogicKey,
        variablesOverride: undefined,
        autoLoad: false,
        onError: (error) => {
            const mountedLogic = sqlEditorLogic.findMounted({
                tabId: tabId || '',
                mode,
                monaco,
                editor,
            })

            if (mountedLogic) {
                mountedLogic.actions.setDataError(error)
            }
        },
    }

    const { loadData } = useActions(dataNodeLogic(dataNodeLogicProps))

    useAttachedLogic(dataNodeLogic(dataNodeLogicProps), logic)
    useAttachedLogic(connectionSelectorLogic(), logic)

    const variablesLogicProps: VariablesLogicProps = {
        key: dataVisualizationLogicProps.key,
        readOnly: false,
        sourceQuery,
        setQuery: setSourceQuery,
        onUpdate: (query) => {
            loadData('force_async', undefined, query.source)
        },
    }

    return (
        <BindLogic logic={dataNodeLogic} props={dataNodeLogicProps}>
            <BindLogic logic={dataVisualizationLogic} props={dataVisualizationLogicProps}>
                <BindLogic logic={displayLogic} props={{ key: dataVisualizationLogicProps.key }}>
                    <BindLogic logic={variablesLogic} props={variablesLogicProps}>
                        <BindLogic logic={variableModalLogic} props={{ key: dataVisualizationLogicProps.key }}>
                            <BindLogic logic={outputPaneLogic} props={{ tabId }}>
                                <BindLogic logic={sqlEditorLogic} props={{ tabId, mode, monaco, editor }}>
                                    {showQueryPanel ? <VariablesQuerySync /> : null}
                                    {panel === SQLEditorPanel.Output ? (
                                        <div className="flex h-full min-h-0 flex-col overflow-hidden">
                                            <OutputPane
                                                tabId={tabId || ''}
                                                showToolbar={showOutputToolbar}
                                                onShareTab={onShareTab}
                                            />
                                        </div>
                                    ) : (
                                        <BindLogic logic={editorSizingLogic} props={editorSizingLogicProps}>
                                            <div className="flex h-full min-h-0 flex-col overflow-hidden">
                                                {showSceneTitle ? <SQLEditorSceneTitle /> : null}
                                                <div className="flex min-h-0 flex-1">
                                                    {showDatabaseTreePanel && (
                                                        <DatabaseTree
                                                            databaseTreeRef={databaseTreeRef}
                                                            tabId={tabId || ''}
                                                            extraTreeSections={extraTreeSections}
                                                            embedded={isEmbeddedSQLEditorMode(mode)}
                                                        />
                                                    )}
                                                    <div
                                                        data-attr="editor-scene"
                                                        className="EditorScene relative flex min-h-0 grow flex-row overflow-hidden"
                                                        ref={ref}
                                                    >
                                                        <ViewLoadingOverlay />
                                                        <QueryWindow
                                                            mode={mode}
                                                            tabId={tabId || ''}
                                                            showDatabaseTree={showDatabaseTreePanel}
                                                            onShowDatabaseTree={() => setHasShownDatabaseTree(true)}
                                                            showQueryPanel={showQueryPanel}
                                                            showOutputPanel={showOutputPanel}
                                                            onSetMonacoAndEditor={(nextMonaco, nextEditor) =>
                                                                setMonacoAndEditor([nextMonaco, nextEditor])
                                                            }
                                                            onRunQuery={onRunQuery}
                                                            runQueryLoading={runQueryLoading}
                                                            runQueryDisabledReason={runQueryDisabledReason}
                                                            runQueryTooltip={runQueryTooltip}
                                                            onCancelQuery={onCancelQuery}
                                                            cancelQueryLoading={cancelQueryLoading}
                                                            hideRunButton={hideRunButton}
                                                            onShareTab={onShareTab}
                                                            autoFocusQueryPane={autoFocusQueryPane}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </BindLogic>
                                    )}
                                    {showFullSceneModals ? (
                                        <>
                                            <MaterializationModal tabId={tabId || ''} />
                                            <AccessControlModal />
                                            <ViewLinkModal />
                                            <ExpressionModal />
                                        </>
                                    ) : null}
                                </BindLogic>
                            </BindLogic>
                        </BindLogic>
                    </BindLogic>
                </BindLogic>
            </BindLogic>
        </BindLogic>
    )
}

function ViewLoadingOverlay(): JSX.Element | null {
    const { viewQueryLoading } = useValues(sqlEditorLogic)
    if (!viewQueryLoading) {
        return null
    }
    return (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-primary/70">
            <Spinner className="text-2xl" />
        </div>
    )
}

function MaterializationModal({ tabId }: { tabId: string }): JSX.Element {
    const { materializationModalOpen, materializationModalView, viewLoading } = useValues(sqlEditorLogic)
    const { closeMaterializationModal } = useActions(sqlEditorLogic)

    return (
        <LemonModal
            title={materializationModalView ? `Materialize ${materializationModalView.name}` : 'Materialize view'}
            isOpen={materializationModalOpen}
            onClose={closeMaterializationModal}
            width={960}
        >
            <div className="max-h-[75vh] overflow-auto">
                {viewLoading ? (
                    <div className="flex min-h-64 items-center justify-center">
                        <Spinner className="text-2xl" />
                    </div>
                ) : materializationModalView ? (
                    <QueryInfo tabId={tabId} view={materializationModalView} />
                ) : (
                    <div className="flex min-h-64 items-center justify-center">
                        <Spinner className="text-2xl" />
                    </div>
                )}
            </div>
        </LemonModal>
    )
}

function AccessControlModal(): JSX.Element | null {
    const { accessControlModalOpen, editingAccessControlObject } = useValues(sqlEditorLogic)
    const { closeAccessControlModal } = useActions(sqlEditorLogic)

    if (!editingAccessControlObject) {
        return null
    }

    return (
        <AccessControlObjectModal
            isOpen={accessControlModalOpen}
            onClose={closeAccessControlModal}
            resource={editingAccessControlObject.resource}
            resource_id={editingAccessControlObject.resourceId}
            title={editingAccessControlObject.name}
            description={
                editingAccessControlObject.resource === AccessControlResourceType.ExternalDataSource
                    ? 'Control who can manage this source. Access set here also applies to its tables, unless a table has access rules of its own.'
                    : `Control who can query this ${
                          editingAccessControlObject.resource === AccessControlResourceType.WarehouseTable
                              ? 'table'
                              : 'view'
                      }. Users without access won't see it and queries referencing it will fail for them.`
            }
        />
    )
}

function SQLEditorSceneTitle(): JSX.Element | null {
    const { titleSectionProps, updateInsightButtonEnabled, saveAsMenuItems, notebooksLoading } =
        useValues(editorSceneLogic)
    const {
        queryInput,
        editingView,
        editingInsight,
        insightLoading,
        sourceQuery,
        changesToSave,
        inProgressViewEdits,
        isSourceQueryLastRun,
        isMultiQuery,
        selectedConnectionId,
    } = useValues(sqlEditorLogic)
    const { convertToNotebook, openHistoryModal } = useActions(editorSceneLogic)
    const {
        reviewViewUpdate,
        updateInsight,
        closeEditingObject,
        saveAsInsight,
        saveAsView,
        saveAsEndpoint,
        saveAsMetric,
        updateEditingMetric,
        setEditingMetricName,
        setSourceQuery,
        setSuggestedQueryInput,
        reportAIQueryPromptOpen,
        setEditingInsightName,
        setEditingInsightDescription,
    } = useActions(sqlEditorLogic)
    const { editingMetricName, metricUpdating } = useValues(sqlEditorLogic)
    const { response, responseError, responseLoading } = useValues(dataNodeLogic)
    const { updatingDataWarehouseSavedQuery } = useValues(dataWarehouseViewsLogic)

    useAttachedContext([
        {
            type: 'sql_editor_state',
            value: JSON.stringify(getExecuteSqlToolContext(queryInput, sourceQuery)),
            label: 'Current query',
        },
    ])

    const saveAsViewAccessDisabledReason = getAccessControlDisabledReason(
        AccessControlResourceType.WarehouseObjects,
        AccessControlLevel.Editor
    )

    const saveAsEndpointAccessDisabledReason = getAccessControlDisabledReason(
        AccessControlResourceType.Endpoint,
        AccessControlLevel.Editor
    )

    // A direct connection's table names only resolve while it is selected, and an endpoint serves data from PostHog.
    const saveAsEndpointDisabledReason = selectedConnectionId
        ? "Endpoints can't query a direct connection. Switch the connection to PostHog (ClickHouse) and query a synced table instead."
        : saveAsEndpointAccessDisabledReason

    const continueInNotebookAccessDisabledReason = getAccessControlDisabledReason(
        AccessControlResourceType.Notebook,
        AccessControlLevel.Editor
    )

    const secondarySaveMenuItems = useMemo(
        () =>
            saveAsMenuItems.secondary.map((item) => ({
                ...item,
                onClick: () => {
                    if (item.action === 'insight') {
                        saveAsInsight()
                        return
                    }

                    if (item.action === 'endpoint') {
                        saveAsEndpoint()
                        return
                    }

                    if (item.action === 'metric') {
                        saveAsMetric()
                        return
                    }

                    saveAsView()
                },
                accessDisabledReason:
                    item.action === 'view'
                        ? saveAsViewAccessDisabledReason
                        : item.action === 'endpoint'
                          ? saveAsEndpointDisabledReason
                          : undefined,
            })),
        [
            saveAsEndpoint,
            saveAsInsight,
            saveAsMetric,
            saveAsMenuItems.secondary,
            saveAsView,
            saveAsViewAccessDisabledReason,
            saveAsEndpointDisabledReason,
        ]
    )

    const onPrimarySaveClick = (): void => {
        if (saveAsMenuItems.primary.action === 'endpoint') {
            saveAsEndpoint()
            return
        }

        if (saveAsMenuItems.primary.action === 'metric') {
            saveAsMetric()
            return
        }

        if (saveAsMenuItems.primary.action === 'view') {
            saveAsView()
            return
        }

        saveAsInsight()
    }

    const saveAsDisabledReason = useMemo(() => {
        if (insightLoading) {
            return 'Loading insight...'
        }

        if (!isSourceQueryLastRun) {
            return 'Run latest query changes before saving'
        }

        if (responseLoading) {
            return 'Running query...'
        }

        if (responseError || !response) {
            return 'Run query successfully before saving'
        }

        return undefined
    }, [insightLoading, isSourceQueryLastRun, responseLoading, responseError, response])

    const [editingViewDisabledReason, EditingViewButtonIcon] = useMemo(() => {
        if (updatingDataWarehouseSavedQuery) {
            return ['Saving...', Spinner]
        }

        if (isMultiQuery) {
            return ['Views must be a single query — remove extra statements to update', IconDownload]
        }

        if (!changesToSave) {
            return ['No changes to save', IconDownload]
        }

        // Require the current (edited) query to have been run successfully before updating — a stale
        // response from a previous run must not enable the button after further edits.
        if (!isSourceQueryLastRun) {
            return ['Run the latest query before updating the view', IconDownload]
        }

        if (responseLoading) {
            return ['Running query...', Spinner]
        }

        if (responseError || !response) {
            return ['Run the query successfully before updating the view', IconDownload]
        }

        return [undefined, IconDownload]
    }, [
        updatingDataWarehouseSavedQuery,
        changesToSave,
        isSourceQueryLastRun,
        responseLoading,
        responseError,
        response,
        isMultiQuery,
    ])

    const isMaterializedView = editingView?.is_materialized === true
    const closeObjectTooltip = editingInsight
        ? 'Close this insight and reset the SQL editor to an unsaved query without clearing your SQL or visualization settings.'
        : editingView
          ? 'Close this view and reset the SQL editor to an unsaved query without clearing your SQL or visualization settings.'
          : 'Reset the SQL editor to an unsaved query without clearing your SQL or visualization settings.'
    const continueInNotebookButton = (
        <LemonButton
            type="secondary"
            size="small"
            icon={<IconNotebook />}
            onClick={() => convertToNotebook()}
            loading={notebooksLoading}
            disabledReason={
                queryInput?.trim() ? continueInNotebookAccessDisabledReason : 'Write a SQL query before continuing'
            }
            data-attr="sql-editor-continue-in-notebook-button"
        >
            Continue in a notebook
        </LemonButton>
    )

    return (
        <>
            <SceneTitleSection
                className="p-1 pl-3 pr-2"
                noBorder
                noPadding
                {...titleSectionProps}
                {...(editingInsight && {
                    onNameChange: setEditingInsightName,
                    onDescriptionChange: setEditingInsightDescription,
                    canEdit: true,
                    forceEdit: true,
                    descriptionMaxLength: 400,
                })}
                maxToolProps={{
                    identifier: 'execute_sql',
                    context: getExecuteSqlToolContext(queryInput, sourceQuery),
                    contextDescription: {
                        text: 'Current query',
                        icon: iconForType('sql_editor'),
                    },
                    callback: (toolOutput: unknown) => {
                        applyExecuteSqlToolOutput({
                            toolOutput,
                            queryInput,
                            sourceQuery,
                            setSourceQuery,
                            setSuggestedQueryInput,
                        })
                    },
                    suggestions: [],
                    onMaxOpen: () => {
                        reportAIQueryPromptOpen()
                    },
                    introOverride: {
                        headline: 'What data do you want to analyze?',
                        description: 'Let me help you quickly write SQL, and tweak it.',
                    },
                }}
                actions={
                    <div className="flex items-center gap-2">
                        {editingView ? (
                            <>
                                <LemonButton
                                    onClick={() => openHistoryModal()}
                                    icon={<IconBook />}
                                    type="secondary"
                                    size="small"
                                >
                                    History
                                </LemonButton>
                                <AccessControlAction
                                    resourceType={AccessControlResourceType.WarehouseObjects}
                                    minAccessLevel={AccessControlLevel.Editor}
                                    userAccessLevel={editingView.user_access_level}
                                >
                                    <LemonButton
                                        onClick={() =>
                                            reviewViewUpdate({
                                                id: editingView.id,
                                                query: {
                                                    ...sourceQuery.source,
                                                    query: queryInput ?? '',
                                                },
                                                types: response && 'types' in response ? (response?.types ?? []) : [],
                                                shouldRematerialize: isMaterializedView,
                                                edited_history_id: inProgressViewEdits[editingView.id],
                                            })
                                        }
                                        disabledReason={editingViewDisabledReason}
                                        icon={<EditingViewButtonIcon />}
                                        type="primary"
                                        size="small"
                                        sideAction={{
                                            icon: <IconChevronDown />,
                                            dropdown: {
                                                placement: 'bottom-end',
                                                overlay: (
                                                    <LemonMenuOverlay
                                                        items={[
                                                            {
                                                                label: 'Save as new insight...',
                                                                disabledReason: saveAsDisabledReason,
                                                                onClick: () => saveAsInsight(),
                                                            },
                                                            {
                                                                label: 'Save as new view...',
                                                                disabledReason:
                                                                    saveAsDisabledReason ??
                                                                    saveAsViewAccessDisabledReason,
                                                                onClick: () => saveAsView(),
                                                            },
                                                            {
                                                                label: 'Save as endpoint...',
                                                                disabledReason:
                                                                    saveAsDisabledReason ??
                                                                    saveAsEndpointDisabledReason,
                                                                onClick: () => saveAsEndpoint(),
                                                            },
                                                        ]}
                                                    />
                                                ),
                                            },
                                        }}
                                    >
                                        {isMaterializedView ? 'Update and re-materialize view' : 'Update view'}
                                    </LemonButton>
                                </AccessControlAction>
                                <LemonButton
                                    onClick={() => closeEditingObject()}
                                    icon={<IconX />}
                                    type="tertiary"
                                    size="small"
                                    aria-label="close"
                                    tooltip={closeObjectTooltip}
                                />
                            </>
                        ) : editingInsight ? (
                            <>
                                <LemonButton
                                    onClick={() => openHistoryModal()}
                                    icon={<IconBook />}
                                    type="secondary"
                                    size="small"
                                    data-attr="sql-editor-insight-history-button"
                                >
                                    History
                                </LemonButton>
                                {continueInNotebookButton}
                                <LemonButton
                                    disabledReason={
                                        !isSourceQueryLastRun
                                            ? 'Run latest query changes before saving'
                                            : !updateInsightButtonEnabled
                                              ? 'No updates to save'
                                              : undefined
                                    }
                                    loading={insightLoading}
                                    type="primary"
                                    size="small"
                                    onClick={() => updateInsight()}
                                    sideAction={{
                                        icon: <IconChevronDown />,
                                        'data-attr': 'sql-editor-save-options-button',
                                        dropdown: {
                                            placement: 'bottom-end',
                                            overlay: (
                                                <LemonMenuOverlay
                                                    items={[
                                                        {
                                                            label: 'Save as new insight...',
                                                            disabledReason: saveAsDisabledReason,
                                                            onClick: () => saveAsInsight(),
                                                        },
                                                        {
                                                            label: 'Save as new view...',
                                                            disabledReason:
                                                                saveAsDisabledReason ?? saveAsViewAccessDisabledReason,
                                                            onClick: () => saveAsView(),
                                                        },
                                                        {
                                                            label: 'Save as endpoint...',
                                                            disabledReason:
                                                                saveAsDisabledReason ?? saveAsEndpointDisabledReason,
                                                            onClick: () => saveAsEndpoint(),
                                                        },
                                                    ]}
                                                />
                                            ),
                                        },
                                    }}
                                >
                                    Update insight
                                </LemonButton>
                                <LemonButton
                                    onClick={() => closeEditingObject()}
                                    icon={<IconX />}
                                    type="secondary"
                                    size="small"
                                    noPadding
                                    aria-label="close"
                                    tooltip={closeObjectTooltip}
                                />
                            </>
                        ) : editingMetricName ? (
                            <>
                                <LemonButton
                                    type="primary"
                                    size="small"
                                    onClick={() => updateEditingMetric()}
                                    loading={metricUpdating}
                                    disabledReason={saveAsDisabledReason}
                                    data-attr="sql-editor-update-metric"
                                    sideAction={{
                                        icon: <IconChevronDown />,
                                        dropdown: {
                                            placement: 'bottom-end',
                                            overlay: (
                                                <LemonMenuOverlay
                                                    items={secondarySaveMenuItems.map((item) => ({
                                                        ...item,
                                                        disabledReason:
                                                            saveAsDisabledReason ?? item.accessDisabledReason,
                                                    }))}
                                                />
                                            ),
                                        },
                                    }}
                                >
                                    Update metric
                                </LemonButton>
                                <LemonButton
                                    onClick={() => setEditingMetricName(null)}
                                    icon={<IconX />}
                                    type="tertiary"
                                    size="small"
                                    aria-label="Stop editing metric"
                                    tooltip="Stop editing this metric and start a new query"
                                />
                            </>
                        ) : (
                            <>
                                {saveAsMenuItems.primary.action === 'insight' && continueInNotebookButton}
                                <LemonButton
                                    type="primary"
                                    size="small"
                                    onClick={onPrimarySaveClick}
                                    disabledReason={
                                        saveAsDisabledReason ??
                                        (saveAsMenuItems.primary.action === 'endpoint'
                                            ? saveAsEndpointDisabledReason
                                            : saveAsMenuItems.primary.action === 'view'
                                              ? saveAsViewAccessDisabledReason
                                              : undefined)
                                    }
                                    sideAction={{
                                        icon: <IconChevronDown />,
                                        'data-attr': 'sql-editor-save-options-button',
                                        dropdown: {
                                            placement: 'bottom-end',
                                            overlay: (
                                                <LemonMenuOverlay
                                                    items={secondarySaveMenuItems.map((item) => ({
                                                        ...item,
                                                        disabledReason:
                                                            saveAsDisabledReason ?? item.accessDisabledReason,
                                                    }))}
                                                />
                                            ),
                                        },
                                    }}
                                >
                                    {saveAsMenuItems.primary.label}
                                </LemonButton>
                            </>
                        )}
                    </div>
                }
            />
            <QueryHistoryModal />
        </>
    )
}

function VariablesQuerySync(): null {
    const { queryInput } = useValues(sqlEditorLogic)
    const { setEditorQuery } = useActions(variablesLogic)

    useEffect(() => {
        const timeout = window.setTimeout(() => setEditorQuery(queryInput ?? ''), VARIABLE_QUERY_SYNC_DEBOUNCE_MS)

        return () => window.clearTimeout(timeout)
    }, [queryInput, setEditorQuery])

    return null
}
