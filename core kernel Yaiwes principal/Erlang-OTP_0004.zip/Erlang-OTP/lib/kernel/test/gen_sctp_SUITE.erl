%%
%% %CopyrightBegin%
%%
%% SPDX-License-Identifier: Apache-2.0
%%
%% Copyright Ericsson AB 2007-2026. All Rights Reserved.
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%     http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%
%% %CopyrightEnd%
%%
-module(gen_sctp_SUITE).

-include_lib("common_test/include/ct.hrl").
-include_lib("kernel/include/inet_sctp.hrl").
-include_lib("kernel/src/inet_int.hrl").
-include("kernel_test_lib.hrl").

%%-compile(export_all).

-export([all/0, suite/0, groups/0,
	 init_per_suite/1, end_per_suite/1,
	 init_per_group/2, end_per_group/2,
	 init_per_testcase/2, end_per_testcase/2]).
-export([
         skip_old_solaris/1,
         basic/1,

         api_open_close/1,
         api_listen/1,
         api_connect_init/1,
         api_connectx_init/1,
         api_opts/1,

         xfer_min/1,xfer_active/1,def_sndrcvinfo/1,implicit_inet6/1,
         open_multihoming_ipv4_socket/1,
         open_unihoming_ipv6_socket/1,
         open_multihoming_ipv6_socket/1,
         open_multihoming_ipv4_and_ipv6_socket/1,
         basic_stream/1, xfer_stream_min/1, active_n/1,
         peeloff_active_once_ipv4/1, peeloff_active_once_ipv6/1,
         peeloff_active_true/1, peeloff_active_n/1,
         buffers/1, send_block/1,
         names_unihoming_ipv4/1, names_unihoming_ipv6/1,
         names_multihoming_ipv4/1, names_multihoming_ipv6/1,
         recv_close/1,

         t_simple_local_sockaddr_in_send_recv/1,
         t_simple_link_local_sockaddr_in_send_recv/1,
         t_simple_local_sockaddr_in6_send_recv/1,
         t_simple_link_local_sockaddr_in6_send_recv/1,
         t_simple_local_sockaddr_in_connectx_init/1,

         non_block_send/1,

         default_options/1
        ]).

suite() ->
    [{ct_hooks,[ts_install_cth]},
     {timetrap,{minutes,1}}].

all() ->
    G = case is_old_solaris() of
	    true -> old_solaris;
	    false -> extensive
	end,
    [
     {group, smoke},
     {group, G},
     {group, sockaddr},
     {group, misc}
    ].

groups() -> 
    [
     {smoke,       [], smoke_cases()},
     {old_solaris, [], old_solaris_cases()},
     {extensive,   [], extensive_cases()},
     {peeloff,     [], peeloff_cases()},
     {names,       [], names_cases()},

     {sockaddr,    [], sockaddr_cases()},

     {misc,        [], misc_cases()}
    ].

smoke_cases() ->
    [
     basic,
     basic_stream
    ].

old_solaris_cases() ->
    [
     skip_old_solaris
    ].

extensive_cases() ->
    [
     api_open_close, api_listen, api_connect_init, api_connectx_init,
     api_opts, xfer_min, xfer_active, def_sndrcvinfo, implicit_inet6,
     open_multihoming_ipv4_socket,
     open_unihoming_ipv6_socket,
     open_multihoming_ipv6_socket,
     open_multihoming_ipv4_and_ipv6_socket, active_n,
     xfer_stream_min,
     {group, peeloff},
     buffers, send_block,
     {group, names},
     recv_close
    ].

peeloff_cases() ->
    [
     peeloff_active_once_ipv4,
     peeloff_active_once_ipv6,
     peeloff_active_true,
     peeloff_active_n
    ].

names_cases() ->
    [
     names_unihoming_ipv4,
     names_unihoming_ipv6,
     names_multihoming_ipv4,
     names_multihoming_ipv6
    ].

sockaddr_cases() ->
    [
     t_simple_local_sockaddr_in_send_recv,
     t_simple_link_local_sockaddr_in_send_recv,
     t_simple_local_sockaddr_in6_send_recv,
     t_simple_link_local_sockaddr_in6_send_recv,
     t_simple_local_sockaddr_in_connectx_init
    ].

misc_cases() ->
    [
     non_block_send,
     default_options
    ].



%% This (Config) was ignored before, why?
init_per_suite(Config0) ->

    ?P("init_per_suite -> entry with"
       "~n      Config: ~p"
       "~n      Nodes:  ~p", [Config0, erlang:nodes()]),

    case is_sctp_supported() of
        ok ->
            case ?LIB:init_per_suite(Config0) of
                {skip, _} = SKIP ->
                    SKIP;

                Config1 when is_list(Config1) ->

                    ?P("init_per_suite -> end when "
                       "~n      Config: ~p", [Config1]),

                    %% We need a monitor on this node also
                    kernel_test_sys_monitor:start(),

                    Config1
            end;

        {skip, _} = SKIP ->
            SKIP
    end.

end_per_suite(Config0) ->

    ?P("end_per_suite -> entry with"
       "~n      Config: ~p"
       "~n      Nodes:  ~p", [Config0, erlang:nodes()]),

    %% Stop the local monitor
    kernel_test_sys_monitor:stop(),

    Config1 = ?LIB:end_per_suite(Config0),

    ?P("end_per_suite -> "
       "~n      Nodes: ~p", [erlang:nodes()]),

    Config1.

init_per_group(sockaddr = _GroupName, Config) ->
    ?P("init_per_group(sockaddr) -> do we support 'socket'"),
    try socket:info() of
	#{load_nif_result := ok} ->
            ?P("init_per_group(sockaddr) -> we support 'socket'"),
            Config;
	#{load_nif_result := LoadRes} ->
	    ?P("init_per_group(sockaddr) -> 'socket' not supperted"
	       "~n   (socket) nif load result: ~p", [LoadRes]),
	    {skip, "esock not supported"};
	_ ->
            ?P("init_per_group(sockaddr) -> 'socket' not supperted"),
	    {skip, "esock not supported"}
    catch
        error : notsup ->
            ?P("init_per_group(sockaddr) -> we *do not* support 'socket'"),
            {skip, "esock not supported"};
        error : undef ->
            ?P("init_per_group(sockaddr) -> 'socket' not configured"),
            {skip, "esock not configured"}
    end;
init_per_group(_GroupName, Config) ->
    Config.

end_per_group(_GroupName, Config) ->
    Config.


init_per_testcase(api_connectx_init = Case, Config) ->
    check_sctp_connectx(Case, Config);
init_per_testcase(t_simple_local_sockaddr_in_connectx_init = Case, Config) ->
    check_sctp_connectx(Case, Config);
init_per_testcase(names_multihoming_ipv4 = Case, Config) ->
    case lists:keysearch(label, 1, Config) of
        {value, {label, docker}} ->
            {skip, "Unstable/broken on docker"};
        _ ->
            init_per_testcase_common(Case, Config)
    end;
init_per_testcase(Case, Config) ->
    init_per_testcase_common(Case, Config).
    
init_per_testcase_common(_Case, Config) ->

    ?P("init_per_testcase -> entry with"
       "~n   Config:   ~p"
       "~n   Nodes:    ~p"
       "~n   Links:    ~p"
       "~n   Monitors: ~p",
       [Config, erlang:nodes(), pi(links), pi(monitors)]),

    kernel_test_global_sys_monitor:reset_events(),

    ?P("init_per_testcase -> done when"
       "~n   Nodes:    ~p"
       "~n   Links:    ~p"
       "~n   Monitors: ~p", [erlang:nodes(), pi(links), pi(monitors)]),

    Config.

end_per_testcase(_Case, Config) ->
    ?P("end_per_testcase -> entry with"
       "~n   Config:   ~p"
       "~n   Nodes:    ~p"
       "~n   Links:    ~p"
       "~n   Monitors: ~p",
       [Config, erlang:nodes(), pi(links), pi(monitors)]),

    ?P("system events during test: "
       "~n   ~p", [kernel_test_global_sys_monitor:events()]),

    ?P("end_per_testcase -> done with"
       "~n   Nodes:    ~p"
       "~n   Links:    ~p"
       "~n   Monitors: ~p", [erlang:nodes(), pi(links), pi(monitors)]),
    ok.


-define(LOGVAR(Var), begin io:format(??Var" = ~p~n", [Var]), Var end).
-define(no_return(Expr), error({unexpected, Expr})).

check_sctp_connectx(Case, Config) ->
    {ok,S} = gen_sctp:open([]),
    try
        {ok,Pb} = inet:port(S),
        case gen_sctp:connectx_init(S, [{127,0,0,1}], Pb, []) of
            {error, enotsup} ->
                {skip, "sctp_connectx unsupported"};
            _ ->
                init_per_testcase_common(Case, Config)
        end
    after
        gen_sctp:close(S)
    end.

is_old_solaris() ->
    os:type() =:= {unix,sunos} andalso os:version() < {5,12,0}.

skip_old_solaris(_Config) ->
    {skip,"Unreliable test cases and/or implementation on old Solaris"}.

%% Hello world.
basic(Config) when is_list(Config) ->
    {ok,S} = gen_sctp:open(),
    ok = gen_sctp:close(S),
    ok.

%% Minimal data transfer.
xfer_min(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() -> case ?WHICH_LOCAL_ADDR(inet) of
                        {ok, Addr} ->
                            Addr;
                        {error, Reason} ->
                            throw({skip, Reason})
                    end
           end,
    TC   = fun(Addr) -> do_xfer_min(Config, Addr) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_xfer_min(Config, LAddr) when is_list(Config) ->
    Stream = 0,
    Data = <<"The quick brown fox jumps over a lazy dog 0123456789">>,
    Loopback = {127,0,0,1},
    StatOpts =
	[recv_avg,recv_cnt,recv_max,recv_oct,
	 send_avg,send_cnt,send_max,send_oct],

    ?P("~s -> [b] try create server socket", [?FUNCTION_NAME]),
    {ok,Sb} = gen_sctp:open([{type,seqpacket}]),
    {ok,SbStat1} = inet:getstat(Sb, StatOpts),
    {ok,Pb} = inet:port(Sb),
    ok = gen_sctp:listen(Sb, true),

    ?P("~s -> [a] try create client socket", [?FUNCTION_NAME]),
    {ok,Sa} = gen_sctp:open(),
    {ok,Pa} = inet:port(Sa),

    ?P("~s -> [a] try connect (to server)", [?FUNCTION_NAME]),
    {ok,#sctp_assoc_change{state=comm_up,
			   error=0,
			   outbound_streams=SaOutboundStreams,
			   inbound_streams=SaInboundStreams,
			   assoc_id=SaAssocId}=SaAssocChange} =
	gen_sctp:connect(Sa, Loopback, Pb, []),

    ?P("~s -> [b] try accept connection", [?FUNCTION_NAME]),
    {SbAssocId,SaOutboundStreams,SaInboundStreams} =
	case recv_event(log_ok(gen_sctp:recv(Sb, infinity))) of
	    {Loopback,Pa,
	     #sctp_assoc_change{state=comm_up,
				error=0,
				outbound_streams=SbOutboundStreams,
				inbound_streams=SbInboundStreams,
				assoc_id=AssocId}} ->
		{AssocId,SbInboundStreams,SbOutboundStreams};
	    {Loopback,Pa,
	     #sctp_paddr_change{state=addr_confirmed,
				addr={Loopback,Pa},
				error=0,
				assoc_id=AssocId}} ->
		{Loopback,Pa,
		 #sctp_assoc_change{state=comm_up,
				    error=0,
				    outbound_streams=SbOutboundStreams,
				    inbound_streams=SbInboundStreams,
				    assoc_id=AssocId}} =
		    recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
		{AssocId,SbInboundStreams,SbOutboundStreams}
	end,

    ?P("~s -> send data (client -> server)", [?FUNCTION_NAME]),
    ok = gen_sctp:send(Sa, SaAssocId, 0, Data),
    ?P("~s -> recv data (server)", [?FUNCTION_NAME]),
    ok = await_first_data(Loopback, LAddr,
                          Pa, SaAssocId,
                          Sb, Pb, SbAssocId,
                          Data),
    ?P("~s -> send data (server -> client)", [?FUNCTION_NAME]),
    ok = gen_sctp:send(Sb, SbAssocId, 0, Data),
    ?P("~s -> recv data (client)", [?FUNCTION_NAME]),
    case log_ok(gen_sctp:recv(Sa, infinity)) of
	{Loopback,Pb,
	 [#sctp_sndrcvinfo{stream=Stream,
			   assoc_id=SaAssocId}],
	 Data} ->
	    ok;
	Event2 ->
	    {Loopback,Pb,
	     #sctp_paddr_change{addr={_,Pb},
				state=addr_confirmed,
				error=0,
				assoc_id=SaAssocId}} =
		recv_event(Event2),
	    {Loopback,
	     Pb,
	     [#sctp_sndrcvinfo{stream=Stream,
			       assoc_id=SaAssocId}],
	     Data} =
		log_ok(gen_sctp:recv(Sa, infinity))
    end,
    %%
    ?P("~s -> (client) graceful shutdown (eof)", [?FUNCTION_NAME]),
    ok = gen_sctp:eof(Sa, SaAssocChange),
    ?P("~s -> (server) receive shutdown event", [?FUNCTION_NAME]),
    {Loopback,Pa,#sctp_shutdown_event{assoc_id=SbAssocId}} =
	recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
    ?P("~s -> (server) receive shutdown-complete event", [?FUNCTION_NAME]),
    {Loopback,Pb,
     #sctp_assoc_change{state=shutdown_comp,
			error=0,
			assoc_id=SaAssocId}} =
	recv_event(log_ok(gen_sctp:recv(Sa, infinity))),
    ?P("~s -> (client) receive shutdown-complete event", [?FUNCTION_NAME]),
    {Loopback,Pa,
     #sctp_assoc_change{state=shutdown_comp,
			error=0,
			assoc_id=SbAssocId}} =
	recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
    ?P("~s -> (client) close socket", [?FUNCTION_NAME]),
    ok = gen_sctp:close(Sa),
    {ok,SbStat2} = inet:getstat(Sb, StatOpts),
    [] = filter_stat_eq(SbStat1, SbStat2),
    ?P("~s -> (server) close socket", [?FUNCTION_NAME]),
    ok = gen_sctp:close(Sb),

    ?P("~s -> expect nothing", [?FUNCTION_NAME]),
    receive
	Msg -> ct:fail({received,Msg})
    after 17 -> ok
    end,
    ?P("~s -> done", [?FUNCTION_NAME]),
    ok.

await_first_data(Loopback, LAddr,
                 CPort, CAssocId,
                 SSock, SPort, SAssocId,
                 Data) ->
    await_first_data(Loopback, LAddr,
                     CPort, CAssocId,
                     SSock, SPort, SAssocId,
                     Data, 2).    

await_first_data(Loopback, LAddr,
                 CPort, CAssocId,
                 SSock, SPort, SAssocId,
                 Data,
                 N) when (N >= 0) ->
    case log_ok(gen_sctp:recv(SSock, infinity)) of
        {Loopback, CPort,
         [#sctp_sndrcvinfo{stream   = Stream,
			   assoc_id = SAssocId}],
         Data} ->
            ?P("~w -> received expected data (sndrcvinfo) event with"
               "~n   Stream: ~p",
               [?FUNCTION_NAME, Stream]),
            ok;
        %% Something else...
        %% We *can* also first receive one or more paddr-change events...
        Event ->
            ?P("~w -> received other event - check", [?FUNCTION_NAME]),
            case recv_event(Event) of
                {Loopback, CPort,
                 #sctp_paddr_change{addr     = {IPAddr, _} = Addr,
                                    state    = State,
                                    error    = 0 = Error,
                                    assoc_id = SAssocId}}
                  when ((IPAddr =:= Loopback) orelse
		        (IPAddr =:= LAddr)) andalso
		       ((State =:= addr_available) orelse
                        (State =:= addr_confirmed)) ->
                    ?P("~w -> was expected paddr-change event with expected:"
                       "~n   Addr:  ~p"
                       "~n   State: ~p"
                       "~n   Error: ~p",
                       [?FUNCTION_NAME, Addr, State, Error]),
                    await_first_data(Loopback, LAddr,
                                     CPort, CAssocId,
                                     SSock, SPort, SAssocId,
                                     Data,
                                     N-1);
                {Loopback, CPort,
                 #sctp_paddr_change{addr     = Addr,
                                    state    = State,
                                    error    = Error,
                                    assoc_id = AssocId}} ->
                    ?P("~w -> was expected paddr-change event with unexpected:"
                       "~n   Addr:    ~p"
                       "~n   State:   ~p"
                       "~n   Error:   ~p"
                       "~n   AssocId: ~p",
                       [?FUNCTION_NAME, Addr, State, Error, AssocId]),
                    ct:fail({unexpected_paddr_change,
                             {Addr, State, Error, AssocId}});
                OtherEvent ->
                    ?P("~w -> was unexpected event:"
                       "~n   ~p",
                       [?FUNCTION_NAME, OtherEvent]),
                    ct:fail({unexpected_event, OtherEvent})
            end
    end.


filter_stat_eq([], []) ->
    [];
filter_stat_eq([{Tag,Val1}=Stat|SbStat1], [{Tag,Val2}|SbStat2]) ->
    if
	Val1 == Val2 ->
	    [Stat|filter_stat_eq(SbStat1, SbStat2)];
	true ->
	    filter_stat_eq(SbStat1, SbStat2)
    end.



%% Minimal data transfer in active mode.
xfer_active(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() ->
                   Addr =
                       case ?WHICH_LOCAL_ADDR(inet) of
                           {ok, A} ->
                               A;
                           {error, Reason} ->
                               throw({skip, Reason})
                       end,
                   OS =
                       case os:type() of
                           {unix, Flavor} ->
                               Flavor;
                           {win32 = Win, _} ->
                               Win
                       end,
                   {Addr, OS}
           end,
    TC   = fun({Addr, OS}) -> do_xfer_active(#{addr => Addr,
                                               os   => OS}) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_xfer_active(#{addr := LAddr, os := OS}) ->
    Timeout = 2000,
    Stream = 0,
    Data = <<"The quick brown fox jumps over a lazy dog 0123456789">>,
    Loopback = {127,0,0,1},

    ?P("~w -> [b] try create server socket", [?FUNCTION_NAME]),
    {ok,Sb} = gen_sctp:open([{active,true}]),
    {ok,Pb} = inet:port(Sb),
    ok = gen_sctp:listen(Sb, true),

    ?P("~w -> [a] try create client socket", [?FUNCTION_NAME]),
    {ok,Sa} = gen_sctp:open([{active,true}]),
    {ok,Pa} = inet:port(Sa),

    ?P("~w -> [a] try initiaate connect (to server)", [?FUNCTION_NAME]),
    ok = gen_sctp:connect_init(Sa, Loopback, Pb, []),
    ?P("~w -> [a] await (assoc-change) comm-up event", [?FUNCTION_NAME]),
    #sctp_assoc_change{state            = comm_up,
		       error            = 0,
		       outbound_streams = SaOutboundStreams,
		       inbound_streams  = SaInboundStreams,
		       assoc_id         = SaAssocId} = SaAssocChange =
	recv_assoc_change(Sa, Loopback, Pb, Timeout),
    ?P("~w -> [a] received expected comm-up event with"
       "~n   Sa:          ~p"
       "~n   Pa:          ~p"
       "~n   SaAssocId:   ~p"
       "~n   Out Streams: ~p"
       "~n   In Streams:  ~p",
       [?FUNCTION_NAME,
        Sa, Pa, SaAssocId, SaOutboundStreams, SaInboundStreams]),

    ?P("~w -> [b] await (assoc-change) comm-up event", [?FUNCTION_NAME]),
    #sctp_assoc_change{state            = comm_up,
		       error            = 0,
		       outbound_streams = SbOutboundStreams,
		       inbound_streams  = SbInboundStreams,
		       assoc_id         = SbAssocId} =
	recv_assoc_change(Sb, Loopback, Pa, Timeout),
    ?P("~w -> [b] received expected comm-up event with"
       "~n   SbAssocId:   ~p"
       "~n   Out Streams: ~p"
       "~n   In Streams:  ~p",
       [?FUNCTION_NAME,
        SbAssocId, SbOutboundStreams, SbInboundStreams]),

    ?P("~w -> ensure in/out streams match", [?FUNCTION_NAME]),
    SbOutboundStreams = SaInboundStreams,
    SbInboundStreams = SaOutboundStreams,

    ?P("~w -> [a] await paddr-change", [?FUNCTION_NAME]),
    case recv_paddr_change(Sa, Loopback, Pb, 314) of
	#sctp_paddr_change{state=addr_confirmed,
			   addr={_,Pb},
			   error=0,
			   assoc_id=SaAssocId} -> ok;
	#sctp_paddr_change{state=addr_available,
			   addr={_,Pb},
			   error=0,
			   assoc_id=SaAssocId} -> ok;
	timeout -> ok
    end,

    ?P("~w -> [b] await paddr-change", [?FUNCTION_NAME]),
    case recv_paddr_change(Sb, Loopback, Pa, 314) of
	#sctp_paddr_change{state=addr_confirmed,
			   addr={Loopback,Pa},
			   error=0,
			   assoc_id=SbAssocId} -> ok;
	#sctp_paddr_change{state=addr_available,
			   addr={Loopback,P},
			   error=0,
			   assoc_id=SbAssocId} ->
	    match_unless_solaris(Pa, P);
	timeout -> ok
    end,
    
    ?P("~w -> ensure (nearly) empty message queue", [?FUNCTION_NAME]),
    case flush() of
        [] ->
            ?P("~w -> no events", [?FUNCTION_NAME]),
            ok;
        [{sctp,  Sb,  Loopback, Pa,
	 {[],
	  #sctp_paddr_change{addr     = {LAddr, Pa},
                             state    = addr_confirmed,
                             error    = 0,
                             assoc_id = SaAssocId}}}]
	  when (OS =:= freebsd) ->
            ?P("~w -> accepted (paddr-change) event", [?FUNCTION_NAME]),
            ok
    end,

    ?P("~w -> send from other process", [?FUNCTION_NAME]),
    ok =
	do_from_other_process(
	  fun () -> gen_sctp:send(Sa, SaAssocId, 0, Data) end),
    ?P("~w -> receive data", [?FUNCTION_NAME]),
    receive
	{sctp,Sb,Loopback,Pa,
	 {[#sctp_sndrcvinfo{stream=Stream,
			    assoc_id=SbAssocId}],
	  Data}} -> ok
    after Timeout ->
	    ct:fail({timeout,flush()})
    end,

    ?P("~w -> send", [?FUNCTION_NAME]),
    ok = gen_sctp:send(Sb, SbAssocId, 0, Data),
    ?P("~w -> receive data", [?FUNCTION_NAME]),
    receive
	{sctp,Sa,Loopback,Pb,
	 {[#sctp_sndrcvinfo{stream=Stream,
			    assoc_id=SaAssocId}],
	  Data}} -> ok
    after Timeout ->
	    ct:fail({timeout,flush()})
    end,

    %%
    ?P("~w -> [a] abort", [?FUNCTION_NAME]),
    ok = gen_sctp:abort(Sa, SaAssocChange),
    ?P("~w -> [b] await comm-lost event", [?FUNCTION_NAME]),
    case recv_assoc_change(Sb, Loopback, Pa, Timeout) of
	#sctp_assoc_change{state=comm_lost,
			   assoc_id=SbAssocId} -> ok;
	timeout ->
            ?P("~w -> timeout", [?FUNCTION_NAME]),
	    ct:fail({timeout,flush()})
    end,

    ?P("~w -> [b] close socket", [?FUNCTION_NAME]),
    ok = gen_sctp:close(Sb),
    ?P("~w -> [a] await comm-lost event", [?FUNCTION_NAME]),
    case recv_assoc_change(Sa, Loopback, Pb, Timeout) of
	#sctp_assoc_change{state=comm_lost,
			   assoc_id=SaAssocId} -> ok;
	timeout ->
            ?P("~w -> timeout waiting for comm-lost", [?FUNCTION_NAME]),
	    match_unless_solaris(ok, {timeout,flush()})
    end,
    receive
	{sctp_error,Sa,enotconn} -> ok % Solaris
    after 17 -> ok
    end,

    ?P("~w -> [a] close socket", [?FUNCTION_NAME]),
    ok = gen_sctp:close(Sa),
    %%
    receive
	Msg -> ct:fail({unexpected,[Msg]++flush()})
    after 17 -> ok
    end,

    ?P("~w -> done", [?FUNCTION_NAME]),
    ok.

recv_assoc_change(S, Addr, Port, Timeout) ->
    receive
	{sctp,S,Addr,Port,{[], #sctp_assoc_change{}=AssocChange}} ->
	    AssocChange;
	{sctp,S,Addr,Port,
	 {[#sctp_sndrcvinfo{assoc_id=AssocId}],
	  #sctp_assoc_change{assoc_id=AssocId}=AssocChange}} ->
	    AssocChange
    after Timeout ->
	    timeout
    end.

recv_paddr_change(S, Addr, Port, Timeout) ->
    receive
	{sctp,S,Addr,Port,{[], #sctp_paddr_change{}=PaddrChange}} ->
	    PaddrChange;
	{sctp,S,Addr,Port,
	 {[#sctp_sndrcvinfo{assoc_id=AssocId}],
	  #sctp_paddr_change{assoc_id=AssocId}=PaddrChange}} ->
	    PaddrChange
    after Timeout ->
	    timeout
    end.

%% Test that #sctp_sndrcvinfo{} parameters set on a socket
%% are used by gen_sctp:send/4.
def_sndrcvinfo(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() -> case ?WHICH_LOCAL_ADDR(inet) of
                        {ok, Addr} ->
                            Addr;
                        {error, Reason} ->
                            throw({skip, Reason})
                    end
           end,
    TC   = fun(Addr) -> do_def_sndrcvinfo(Addr) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_def_sndrcvinfo(LAddr) ->
    Loopback = {127,0,0,1},
    Data = <<"What goes up, must come down.">>,
    %%
    S1 =
	log_ok(gen_sctp:open(
		 0, [{sctp_default_send_param,#sctp_sndrcvinfo{ppid=17}}])),
    ?LOGVAR(S1),
    P1 =
	log_ok(inet:port(S1)),
    ?LOGVAR(P1),
    #sctp_sndrcvinfo{ppid=17, context=0, timetolive=0, assoc_id=0} =
	getopt(S1, sctp_default_send_param),
    ok =
	gen_sctp:listen(S1, true),
    %%
    S2 =
	log_ok(gen_sctp:open()),
    ?LOGVAR(S2),
    P2 =
	log_ok(inet:port(S2)),
    ?LOGVAR(P2),
    #sctp_sndrcvinfo{ppid=0, context=0, timetolive=0, assoc_id=0} =
	getopt(S2, sctp_default_send_param),
    %%
    #sctp_assoc_change{
       state=comm_up,
       error=0,
       assoc_id=S2AssocId} = S2AssocChange =
	log_ok(gen_sctp:connect(S2, Loopback, P1, [])),
    ?LOGVAR(S2AssocChange),
    S1AssocId =
	case recv_event(log_ok(gen_sctp:recv(S1))) of
	    {Loopback,P2,
	     #sctp_assoc_change{
		state=comm_up,
		error=0,
		assoc_id=AssocId}} ->
		AssocId;
	    {Loopback,P2,
	     #sctp_paddr_change{
		state=addr_confirmed,
		error=0,
		assoc_id=AssocId}} ->
		{Loopback,P2,
		 #sctp_assoc_change{
		    state=comm_up,
		    error=0,
		    assoc_id=AssocId}} =
		    recv_event(log_ok(gen_sctp:recv(S1))),
		AssocId
	end,
    ?LOGVAR(S1AssocId),

    #sctp_sndrcvinfo{
       ppid=17, context=0, timetolive=0} = %, assoc_id=S1AssocId} =
	getopt(
	  S1, sctp_default_send_param, #sctp_sndrcvinfo{assoc_id=S1AssocId}),
    #sctp_sndrcvinfo{
       ppid=0, context=0, timetolive=0} = %, assoc_id=S2AssocId} =
	getopt(
	  S2, sctp_default_send_param, #sctp_sndrcvinfo{assoc_id=S2AssocId}),
    %%
    ok =
	gen_sctp:send(S1, S1AssocId, 1, <<"1: ",Data/binary>>),
    case log_ok(gen_sctp:recv(S2)) of
	{Loopback,P1,
	 [#sctp_sndrcvinfo{
	     stream=1, ppid=17, context=0, assoc_id=S2AssocId}],
	 <<"1: ",Data/binary>>} -> ok;
	Event1 ->
	    {Loopback,P1,
	     #sctp_paddr_change{state=addr_confirmed,
				addr={_,P1},
				error=0,
				assoc_id=S2AssocId}} =
		recv_event(Event1),
	    {Loopback,P1,
	     [#sctp_sndrcvinfo{
		 stream=1, ppid=17, context=0, assoc_id=S2AssocId}],
	     <<"1: ",Data/binary>>} =
		log_ok(gen_sctp:recv(S2))
    end,
    %%
    ok =
	setopt(
	  S1, sctp_default_send_param, #sctp_sndrcvinfo{ppid=18}),
    ok =
	setopt(
	  S1, sctp_default_send_param,
	  #sctp_sndrcvinfo{ppid=19, assoc_id=S1AssocId}),
    #sctp_sndrcvinfo{
       ppid=18, context=0, timetolive=0, assoc_id=0} =
	getopt(S1, sctp_default_send_param),
    #sctp_sndrcvinfo{
       ppid=19, context=0, timetolive=0, assoc_id=S1AssocId} =
	getopt(
	  S1, sctp_default_send_param, #sctp_sndrcvinfo{assoc_id=S1AssocId}),
    %%
    ok =
	gen_sctp:send(S1, S1AssocId, 0, <<"2: ",Data/binary>>),
    case log_ok(gen_sctp:recv(S2)) of
	{Loopback,P1,
	 [#sctp_sndrcvinfo{
	     stream=0, ppid=19, context=0, assoc_id=S2AssocId}],
	 <<"2: ",Data/binary>>} -> ok
    end,
    ok =
	gen_sctp:send(S2, S2AssocChange, 1, <<"3: ",Data/binary>>),
    case log_ok(gen_sctp:recv(S1)) of
	{Loopback,P2,
	 [#sctp_sndrcvinfo{
	     stream=1, ppid=0, context=0, assoc_id=S1AssocId}],
	 <<"3: ",Data/binary>>} -> ok;
	Event2 ->
	    case recv_event(Event2) of
		{Loopback,P2,
		 #sctp_paddr_change{
		    addr={Loopback,_},
		    state=State,
		    error=0, assoc_id=S1AssocId}}
		  when State =:= addr_available;
		       State =:= addr_confirmed ->
                    %% We *may* get an paddr-event before the data event
                    %% (on FreeBSD)
		    case log_ok(gen_sctp:recv(S1)) of
			{Loopback,P2,
			 [#sctp_sndrcvinfo{
			     stream=1, ppid=0, context=0,
			     assoc_id=S1AssocId}],
			 <<"3: ",Data/binary>>} ->
                            ok;
                        {Loopback, P2, [],
                          #sctp_paddr_change{addr     = {LAddr, _},
                                             state    = addr_confirmed,
                                             error    = 0,
                                             assoc_id = S1AssocId}} ->
                            ?P("~w -> paddr-change (addr-confirmed) event "
                               "before data event - receive again",
                               [?FUNCTION_NAME]),
                            {Loopback,P2,
                             [#sctp_sndrcvinfo{
                                 stream   = 1,
                                 ppid     = 0,
                                 context  = 0,
                                 assoc_id = S1AssocId}],
                             <<"3: ",Data/binary>>} = log_ok(gen_sctp:recv(S1)),
                            ok
		    end
	    end
    end,
    ok =
	do_from_other_process(
	  fun () ->
		  gen_sctp:send(
		    S2,
		    #sctp_sndrcvinfo{stream=0, ppid=20, assoc_id=S2AssocId},
		    <<"4: ",Data/binary>>)
	  end),
    case log_ok(do_from_other_process(fun() -> gen_sctp:recv(S1) end)) of
	{Loopback,P2,
	 [#sctp_sndrcvinfo{
	     stream=0, ppid=20, context=0, assoc_id=S1AssocId}],
	 <<"4: ",Data/binary>>} -> ok
    end,
    %%
    ok =
	gen_sctp:close(S1),
    ok =
	gen_sctp:close(S2),
    receive
	Msg ->
	    ct:fail({received,Msg})
    after 17 -> ok
    end,
    ok.

getopt(S, Opt) ->
    {ok,[{Opt,Val}]} = inet:getopts(S, [Opt]),
    Val.

getopt(S, Opt, Param) ->
    {ok,[{Opt,Val}]} = inet:getopts(S, [{Opt,Param}]),
    Val.

setopt(S, Opt, Val) ->
    inet:setopts(S, [{Opt,Val}]).


flush() ->
    receive
	Msg ->
	    [Msg|flush()]
    after 17 ->
	    []
    end.

%% Test the API function open/1,2 and close/1.
api_open_close(Config) when is_list(Config) ->
    ?TC_TRY(?FUNCTION_NAME, fun() -> do_api_open_close() end).

do_api_open_close() ->
    {ok,S1} = gen_sctp:open(0),
    {ok,P}  = inet:port(S1),
    ok      = gen_sctp:close(S1),

    {ok,S2} = gen_sctp:open(P),
    {ok,P}  = inet:port(S2),
    ok      = gen_sctp:close(S2),

    {ok,S3} = gen_sctp:open([{port,P}]),
    {ok,P}  = inet:port(S3),
    ok      = gen_sctp:close(S3),

    {ok,S4} = gen_sctp:open(P, []),
    {ok,P}  = inet:port(S4),
    ok      = gen_sctp:close(S4),

    {ok,S5} = gen_sctp:open(P, [{debug, false}, {ifaddr,any}, {debug, true}]),
    {ok,P}  = inet:port(S5),
    ok      = gen_sctp:close(S5),

    ok      = gen_sctp:close(S5),

    try gen_sctp:close(0)
    catch error:badarg -> ok
    end,

    try gen_sctp:open({})
    catch error:badarg -> ok
    end,

    try gen_sctp:open(-1)
    catch error:badarg -> ok
    end,

    try gen_sctp:open(65536)
    catch error:badarg -> ok
    end,

    try gen_sctp:open(make_ref(), [])
    catch error:badarg -> ok
    end,

    try gen_sctp:open(0, {})
    catch error:badarg -> ok
    end,

    try gen_sctp:open(0, [make_ref()])
    catch error:badarg -> ok
    end,

    try gen_sctp:open([{invalid_option,0}])
    catch error:badarg -> ok
    end,

    try gen_sctp:open(0, [{mode,invalid_mode}])
    catch error:badarg -> ok
    end,
    ok.

%% Test the API function listen/2.
api_listen(Config) when is_list(Config) ->
    ?P("~s -> entry", [?FUNCTION_NAME]),

    Localhost = {127,0,0,1},

    try gen_sctp:listen(0, true)
    catch error:badarg -> ok
    end,

    {ok,S} = gen_sctp:open(),
    {ok,Pb} = inet:port(S),
    try gen_sctp:listen(S, not_allowed_for_listen)
    catch error:badarg -> ok
    end,
    ok = gen_sctp:close(S),
    {error,closed} = gen_sctp:listen(S, true),

    {ok,Sb} = gen_sctp:open(Pb),
    {ok,Sa} = gen_sctp:open(),

    element(1, os:type()) =:= unix andalso
        begin
            {error, nxdomain} = gen_sctp:connect(Sa, "", 65535, []),
            {error, nxdomain} = gen_sctp:connect(Sa, '', 65535, [])
        end,
    {error, nxdomain} = gen_sctp:connect(Sa, ".", 65535, []),
    {error, nxdomain} = gen_sctp:connect(Sa, '.', 65535, []),

    ?P("~s -> try connect to localhost:~w (before listen) - expect failure",
       [?FUNCTION_NAME, Pb]),
    case gen_sctp:connect(Sa, localhost, Pb, []) of
	{error,econnrefused = Reason} ->
            ?P("~s -> ~w => await assoc-change (with state = 'comm_lost')",
               [?FUNCTION_NAME, Reason]),
	    {ok,{Localhost,
		 Pb,[],
		 #sctp_assoc_change{
		    state=comm_lost}}} =
		gen_sctp:recv(Sa, infinity);
	{error,#sctp_assoc_change{state=cant_assoc = State}} ->
            ?P("~s -> expected assoc-change event (state = ~w)",
               [?FUNCTION_NAME, State]),
	    ok;
        {error, UnexpectedReason} ->
            ?P("~s -> unexpected error:"
               "~n   ~p", [?FUNCTION_NAME, UnexpectedReason]),
            exit(UnexpectedReason)
    end,
    ?P("~s -> try listen", [?FUNCTION_NAME]),
    ok = gen_sctp:listen(Sb, true),
    ?P("~s -> try connect to localhost:~w (before listen) - expect success",
       [?FUNCTION_NAME, Pb]),
    {ok,#sctp_assoc_change{state=comm_up,
			   error=0}} =
	gen_sctp:connect(Sa, localhost, Pb, []),
    ?P("~s -> close sockets", [?FUNCTION_NAME]),
    ok = gen_sctp:close(Sa),
    ok = gen_sctp:close(Sb),
    ?P("~s -> done", [?FUNCTION_NAME]),
    ok.

%% Test the API function connect_init/4.
api_connect_init(Config) when is_list(Config) ->
    Localhost = {127,0,0,1},

    {ok,S} = gen_sctp:open(),
    {ok,Pb} = inet:port(S),
    try gen_sctp:connect_init(S, Localhost, not_allowed_for_port, [])
    catch error:badarg -> ok
    end,
    try gen_sctp:connect_init(S, Localhost, 12345, not_allowed_for_opts)
    catch error:badarg -> ok
    end,
    ok = gen_sctp:close(S),
    {error,closed} = gen_sctp:connect_init(S, Localhost, 12345, []),

    {ok,Sb} = gen_sctp:open(Pb),
    {ok,Sa} = gen_sctp:open(),
    case gen_sctp:connect_init(Sa, localhost, Pb, []) of
	{error,econnrefused} ->
	    {Localhost,Pb,#sctp_assoc_change{state=comm_lost}} =
		recv_event(log_ok(gen_sctp:recv(Sa, infinity)));
	ok ->
	    {Localhost,Pb,#sctp_assoc_change{state=cant_assoc}} =
		recv_event(log_ok(gen_sctp:recv(Sa, infinity)))
    end,
    ok = gen_sctp:listen(Sb, true),
    case gen_sctp:connect_init(Sa, localhost, Pb, []) of
	ok ->
	    {Localhost,Pb,#sctp_assoc_change{state=comm_up}} =
		recv_event(log_ok(gen_sctp:recv(Sa, infinity)))
    end,
    ok = gen_sctp:close(Sa),
    ok = gen_sctp:close(Sb),
    ok.

%% Test the API function connectx_init/4.
api_connectx_init(Config) when is_list(Config) ->
    Localhost = {127,0,0,1},

    {ok,S} = gen_sctp:open(),
    {ok,Pb} = inet:port(S),
    try ?no_return(gen_sctp:connectx_init(S, Localhost, 12345, []))
    catch error:badarg -> ok
    end,
    {error, einval} = gen_sctp:connectx_init(S, [Localhost], not_allowed_for_port, []),
    %% try ?no_return(gen_sctp:connectx_init(S, [Localhost], not_allowed_for_port, []))
    %% catch error:badarg -> ok
    %% end,
    try ?no_return(gen_sctp:connectx_init(S, [Localhost], 12345, not_allowed_for_opts))
    catch error:badarg -> ok
    end,
    ok = gen_sctp:close(S),
    {error,closed} = gen_sctp:connectx_init(S, [Localhost], 12345, []),

    {ok,Sb} = gen_sctp:open(Pb),
    {ok,Sa} = gen_sctp:open(),
    {ok, A1} = gen_sctp:connectx_init(Sa, [localhost], Pb, []),
    true = (A1 =/= 0),
    {Localhost,Pb,#sctp_assoc_change{state=cant_assoc, assoc_id = A1}} =
	recv_event(log_ok(gen_sctp:recv(Sa, infinity))),
    ok = gen_sctp:listen(Sb, true),
    {ok, A2} = gen_sctp:connectx_init(Sa, [localhost], Pb, []),
    true = (A2 =/= 0),
    {Localhost,Pb,#sctp_assoc_change{state=comm_up, assoc_id = A2}} =
	recv_event(log_ok(gen_sctp:recv(Sa, infinity))),
    ok = gen_sctp:close(Sa),
    ok = gen_sctp:close(Sb),
    ok.

recv_event({Addr, Port, [], #sctp_assoc_change{} = AssocChange}) ->
    {Addr, Port, AssocChange};
recv_event({Addr,Port,
	    [#sctp_sndrcvinfo{assoc_id  = Assoc}],
	    #sctp_assoc_change{assoc_id = Assoc} = AssocChange}) ->
    {Addr, Port, AssocChange};
recv_event({Addr, Port, [], #sctp_paddr_change{} = PaddrChange}) ->
    {Addr, Port, PaddrChange};
recv_event({Addr, Port,
	    [#sctp_sndrcvinfo{assoc_id  = Assoc}],
	    #sctp_paddr_change{assoc_id = Assoc} = PaddrChange}) ->
    {Addr, Port, PaddrChange};
recv_event({Addr, Port, [], #sctp_shutdown_event{} = ShutdownEvent}) ->
    {Addr, Port, ShutdownEvent};
recv_event({Addr, Port,
	    [#sctp_sndrcvinfo{assoc_id    = Assoc}],
	    #sctp_shutdown_event{assoc_id = Assoc} = ShutdownEvent}) ->
    {Addr, Port, ShutdownEvent}.

%% Test socket options.
api_opts(Config) when is_list(Config) ->
    Sndbuf = 32768,
    Recbuf = 65536,
    {ok,S} = gen_sctp:open(0),
    OSType = os:type(),
    case {inet:setopts(S, [{linger,{true,2}}]),OSType} of
	{ok,_} ->
	    ok;
	{{error,einval},{unix,sunos}} ->
	    ok
    end,
    ok = inet:setopts(S, [{sndbuf,Sndbuf}]),
    ok = inet:setopts(S, [{recbuf,Recbuf}]),
    case inet:getopts(S, [sndbuf]) of
	{ok, [{sndbuf,SB}]} when SB >= Sndbuf -> ok
    end,
    case inet:getopts(S, [recbuf]) of
	{ok, [{recbuf, RB}]} when (RB >= Recbuf) -> ok
    end.

%% What is this *actually* supposed to test?
implicit_inet6(Config) when is_list(Config) ->
    ?TC_TRY(implicit_inet6, fun() -> do_implicit_inet6(Config) end).

do_implicit_inet6(_Config) ->
    ?P("begin"),
    %% First
    ?P("try create server socket (1)"),
    case gen_sctp:open(0, [inet6]) of
	{ok, S1} ->
            Loopback = {0,0,0,0,0,0,0,1},
            ?P("*** ~s: ~p ***", ["Loopback", Loopback]),
            implicit_inet6(S1, Loopback),
            ok = gen_sctp:close(S1),
            
            %% Second
            ?P("try create server socket (2)"),
            Localhost =
                case inet:getaddr("localhost", inet6) of
                    {ok, LH} ->
                        LH;
                    {error, nxdomain = Reason_getaddr} ->
                        ?SKIPT(Reason_getaddr);
                    {error, Reason_getaddr} ->
                        ct:fail({unexpected, Reason_getaddr})
                end,
            S2 = case gen_sctp:open(0, [{ip, Localhost}]) of
                     {ok, S} ->
                         S;
                     {error, nxdomain = Reason_open} ->
                         ?SKIPT(Reason_open);
                     {error, Reason_open} ->
                         ct:fail({unexpected, Reason_open})
                 end,

            ?P("*** ~s: ~p ***", ["localhost", Localhost]),
            implicit_inet6(S2, Localhost),
            ok = gen_sctp:close(S2),
            
            %% Third
            ?P("try create server socket (3)"),
            Hostname = log_ok(inet:gethostname()),
            Addr     = case inet:getaddr(Hostname, inet6) of
                           {ok, A} ->
                               A;
                           {error, eafnosupport} ->
                               ok = gen_sctp:close(S1),
                               ?SKIPT("Can not look up IPv6 address")
                       end,
            S3 = log_ok(gen_sctp:open(0, [{ifaddr, Addr}])),
            ?P("*** ~s: ~p ***", [Hostname, Addr]),
            implicit_inet6(S3, Addr),
            ok = gen_sctp:close(S1),
            ?P("done"),
            ok;
        {error, eaddrnotavail = Reason} ->
            ?SKIPT(open_failed_str(Reason));
        _ ->
            {skip, "IPv6 not supported"}
    end.


implicit_inet6(S1, Addr) ->
    ?P("make (server) listen socket"),
    ok = gen_sctp:listen(S1, true),
    ServerPortNo = log_ok(inet:port(S1)),
    ?P("try create (client) socket"),
    S2 = case gen_sctp:open(0, [inet6, {ifaddr, Addr}]) of
             {ok, Sock} ->
                 ?P("client socket created: ~p", [Sock]),
                 Sock;
             {error, eaddrnotavail = Reason} ->
                 ?P("could not create (client) socket with ifaddr: "
                    "~n   ~p", [Addr]),
                 ?SKIPT(open_failed_str(Reason))
    end,
    {ClientAddr, ClientPortNo} = log_ok(inet:sockname(S2)),
    ?P("try connect"
       "~n   from (connector): ~p, ~p (~p)"
       "~n   to:               ~p, ~p",
       [ClientAddr, ClientPortNo, S2, Addr, ServerPortNo]),
    #sctp_assoc_change{state = comm_up} =
	log_ok(gen_sctp:connect(S2, Addr, ServerPortNo, [])),
    ?P("connect success: await events"),
    implicit_inet6_await_ac_comm_up(S1, ClientAddr, ClientPortNo),
    ?P("verify server sockname"),
    case log_ok(inet:sockname(S1)) of
	{Addr,              ServerPortNo} -> ok;
	{{0,0,0,0,0,0,0,0}, ServerPortNo} -> ok
    end,
    ?P("verify client sockname"),
    case log_ok(inet:sockname(S2)) of
	{Addr,              ClientPortNo} -> ok;
	{{0,0,0,0,0,0,0,0}, ClientPortNo} -> ok
    end,
    ?P("client client socket"),
    ok = gen_sctp:close(S2),
    ?P("verification complete"),
    ok.


implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo) ->
    {_OsFam, OsName} = os:type(),
    implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo, OsName).

implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo, OsName) ->
    case recv_event(log_ok(gen_sctp:recv(Sock))) of
	{Addr, PortNo, #sctp_assoc_change{state = comm_up}} ->
            ?P("received assoc-change:comm-up event => done"),
	    ok;
	{Addr, PortNo, #sctp_paddr_change{state = addr_confirmed,
                                          addr  = {Addr, PortNo},
                                          error = 0}} ->
            ?P("received paddr-change:addr-confirmed event - "
               "try recv assoc-change:comm-up"),
            implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo, OsName);

	{Addr2, PortNo2, #sctp_assoc_change{state = comm_up}}
          when (OsName =:= freebsd) ->
            ?P("Expected (assoc-change:comm-up) event from unexpected address: "
               "~n   Unexpected Address: ~p, ~p"
               "~n   Expected Address:   ~p, ~p"
               "~n   => RETRY"
               "~n", [Addr2, PortNo2, Addr, PortNo]),
            implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo, OsName);
	{Addr2, PortNo2, #sctp_paddr_change{state = addr_confirmed}}
          when (OsName =:= freebsd) ->
            ?P("Expected paddr-change:addr-confirmed event from "
               "UNEXPECTED ADDRESS: "
               "~n   UNEXPECTED Address: ~p, ~p"
               "~n   Expected Address:   ~p, ~p"
               "~n   => RETRY"
               "~n", [Addr2, PortNo2, Addr, PortNo]),
            implicit_inet6_await_ac_comm_up(Sock, Addr, PortNo, OsName);

	{Addr2, PortNo2, #sctp_assoc_change{state = comm_up} = CX} = UNEX ->
            ?P("Expected (assoc-change:comm-up) event from UNEXPECTED ADDRESS: "
               "~n   UNEXPECTED Address: ~p, ~p"
               "~n   Expected Address:   ~p, ~p"
               "~n   Assoc Change:       ~p"
               "~n", [Addr2, PortNo2, Addr, PortNo, CX]),
            exit({unexpected_event, UNEX});

	{AX, PX, #sctp_paddr_change{state = addr_confirmed} = CX} = UNEX ->
            ?P("Expected paddr-change:addr-confirmed event from "
               "UNEXPECTED ADDRESS: "
               "~n   UNEXPECTED Address: ~p, ~p"
               "~n   Expected Address:   ~p, ~p"
               "~n   PAddr Change:       ~p"
               "~n", [AX, PX, Addr, PortNo, CX]),
            exit({unexpected_event, UNEX});

        {AX, PX, CX} = UNEX ->
            ?P("UNEXPECTED EVENT: "
               "~n   ~p"
               "~n   UNEXPECTED ADDRESS: ~p, ~p"
               "~n   Expected Address:   ~p, ~p"
               "~n", [CX, AX, PX, Addr, PortNo]),
            exit({unexpected_event, UNEX})
    end.


%% Verify {active, N} socket management.
%% This is difficult to do since we do not just receive data messages.
%% Also, how do we know that sctp behaves the same way on all platforms?
active_n(Config) when is_list(Config) ->
    ?TC_TRY(active_n, fun() -> do_active_n(Config) end).

do_active_n(_Config) ->
    N = 3,
    S1 = ok(gen_sctp:open([{active,N}])),
    [{active,N}] = ok(inet:getopts(S1, [active])),
    ok = inet:setopts(S1, [{active,-N}]),
    receive
        {sctp_passive, S1} -> ok
    after
        5000 ->
            exit({error,sctp_passive_failure})
    end,
    [{active,false}] = ok(inet:getopts(S1, [active])),
    ok = inet:setopts(S1, [{active,0}]),
    receive
        {sctp_passive, S1} -> ok
    after
        5000 ->
            exit({error,sctp_passive_failure})
    end,
    ok = inet:setopts(S1, [{active,32767}]),
    {error,einval} = inet:setopts(S1, [{active,1}]),
    {error,einval} = inet:setopts(S1, [{active,-32769}]),
    ok = inet:setopts(S1, [{active,-32768}]),
    receive
        {sctp_passive, S1} -> ok
    after
        5000 ->
            exit({error,sctp_passive_failure})
    end,
    [{active,false}] = ok(inet:getopts(S1, [active])),
    ok = inet:setopts(S1, [{active,N}]),
    ok = inet:setopts(S1, [{active,true}]),
    [{active,true}] = ok(inet:getopts(S1, [active])),
    receive
        _ -> exit({error,active_n})
    after
        0 ->
            ok
    end,
    ok = inet:setopts(S1, [{active,N}]),
    ok = inet:setopts(S1, [{active,once}]),
    [{active,once}] = ok(inet:getopts(S1, [active])),
    receive
        _ -> exit({error,active_n})
    after
        0 ->
            ok
    end,
    {error,einval} = inet:setopts(S1, [{active,32768}]),
    ok = inet:setopts(S1, [{active,false}]),
    [{active,false}] = ok(inet:getopts(S1, [active])),
    ok = gen_sctp:listen(S1, true),
    S1Port = ok(inet:port(S1)),
    S2 = ok(gen_sctp:open(0, [{active,false}])),
    Assoc = ok(gen_sctp:connect(S2, "localhost", S1Port, [])),
    ok = inet:setopts(S1, [{active,N}]),
    active_n_flush_connect_msgs(S1),
    active_n_send_loop(N, S2, Assoc, S1),
    S3 = ok(gen_sctp:open([{active,0}])),
    receive
        {sctp_passive,S3} ->
            [{active,false}] = ok(inet:getopts(S3, [active]))
    after
        5000 ->
            exit({error,udp_passive})
    end,
    ok = gen_sctp:close(S3),
    ok = gen_sctp:close(S2),
    ok = gen_sctp:close(S1),
    ok.


%% There is no way to know how many addresses this host has,
%% and if there is "too many" (more then N = 3), then the
%% socket may already be passive. In this case the send-
%% loop will fail.
%% So, if we get a passive-message here, we just give up (=skip).
active_n_flush_connect_msgs(Sock) ->
    %% This seems only to be needed on certain platforms
    active_n_flush_connect_msgs(os:type(), Sock).

active_n_flush_connect_msgs(_, Sock) ->
    do_active_n_flush_connect_msgs(Sock).
%% active_n_flush_connect_msgs({unix, freebsd}, Sock) ->
%%     do_active_n_flush_connect_msgs(Sock);
%% active_n_flush_connect_msgs(_, _) ->
%%     ok.

do_active_n_flush_connect_msgs(Sock) ->
    receive
        {sctp_passive, Sock} ->
            ?P("connect-flush-loop -> premature passive"),
            ?SKIPT("Too many addresses (premature passive)");

        {sctp, Sock,
         _FromIP, _FromPort,
         {[], #sctp_assoc_change{state = comm_up}}} ->
            ?P("connect-flush-loop -> "
               "connect message discard - assoc change : comm-up"),
            ok = inet:setopts(Sock, [{active, 1}]),
            do_active_n_flush_connect_msgs(Sock);

        {sctp, Sock,
         _FromIP, _FromPort,
         {[], #sctp_paddr_change{state    = addr_confirmed,
                                 addr     = Addr,
                                 error    = Error,
                                 assoc_id = AID}}} ->
            ?P("connect-flush-loop -> "
               "connect message discard - paddr change : addr-confirmed:"
               "~n   Addr:    ~p"
               "~n   Error:   ~p"
               "~n   AssocID: ~p", [Addr, Error, AID]),
            ok = inet:setopts(Sock, [{active, 1}]),
            do_active_n_flush_connect_msgs(Sock)

    after 5000 ->
            ok
    end.
            
active_n_send_loop(Count, SrcSock, SndAssoc, DstSock) ->
    active_n_send_loop(0, Count, SrcSock, SndAssoc, DstSock).

active_n_send_loop(Count, Count, _SndSock, _SndAssoc, RcvSock) ->
    ?P("send-loop -> we are done - wait for passive"),
    receive
        {sctp_passive, RcvSock} ->
            ?P("received passive"),
            ok
    after
        5000 ->
            ?P("UNEXPECTED TIMEOUT: "
               "~n   Message Queue:    ~p"
               "~n   Active:           ~p",
               [process_info(self(), messages),
                inet:getopts(RcvSock, [active])]),
            exit({error, timeout})
    end;

active_n_send_loop(Sent, Count, SndSock, SndAssoc, RcvSock) ->
    Msg = list_to_binary("message " ++ integer_to_list(Sent+1)),
    ?P("send-loop(~w,~w) -> send message (on ~p)", [Sent, Count, SndSock]),
    ok = gen_sctp:send(SndSock, SndAssoc, 0, Msg),
    receive
        {sctp, RcvSock, FromIP, FromPort, {[SR], Msg}}
        when is_record(SR, sctp_sndrcvinfo) ->
            ?P("send-loop(~w,~w) -> "
               "recv (expected) data message (on ~p):"
               "~n   Msg:  ~p"
               "~n   From: ~p, ~p",
               [Sent, Count,
                RcvSock, Msg, FromIP, FromPort]),
            active_n_send_loop(Sent+1, Count, SndSock, SndAssoc, RcvSock);
        
        {sctp, RcvSock, _FromIP, _FromPort, {_AncData, _Data}} ->
            %% ignore non-data messages
            %% we should not get any here because of the flush loop,
            %% but just in case...
            ?P("send-loop(~w,~w) -> "
               "ignore non-data messages (on ~p):"
               "~n   From:    ~p:~p"
               "~n   AncData: ~p"
               "~n   Data:    ~p",
               [Sent, Count,
                RcvSock, _FromIP, _FromPort, _AncData, _Data]),
            
            %% It may be too late to update here,
            %% the socket may already have gone passive 
            %% and generated a passive message!
            
            ok = inet:setopts(RcvSock, [{active, 1}]),

            active_n_send_loop(Sent, Count, SndSock, SndAssoc, RcvSock);
        
        Other ->
            ?P("send-loop(~w,~w) -> "
               "UNEXPECTED: "
               "~n   Other:     ~p"
               "~n   Send Sock: ~p"
               "~n   Recv Sock: ~p", [Sent, Count,
                                      Other, SndSock, RcvSock]),
            exit({unexpected, Other})
    after
        5000 ->
            exit({error,timeout})
    end.
    
%% Hello world stream socket.
basic_stream(Config) when is_list(Config) ->
    {ok,S} = gen_sctp:open([{type,stream}]),
    ok = gen_sctp:listen(S, true),
    ok =
	do_from_other_process(
	  fun () -> gen_sctp:listen(S, 10) end),
    ok = gen_sctp:close(S),
    ok.

%% Minimal data transfer.
xfer_stream_min(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() -> case ?WHICH_LOCAL_ADDR(inet) of
                        {ok, Addr} ->
                            Addr;
                        {error, Reason} ->
                            throw({skip, Reason})
                    end
           end,
    TC   = fun(Addr) -> do_xfer_stream_min(Addr) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_xfer_stream_min(LAddr) ->
    {_, OSName} = os:type(),
    Stream = 0,
    Data = <<"The quick brown fox jumps over a lazy dog 0123456789">>,
    Loopback = {127,0,0,1},
    {ok,Sb} = gen_sctp:open([{type,seqpacket}]),
    ?LOGVAR(Sb),
    {ok,Pb} = inet:port(Sb),
    ?LOGVAR(Pb),
    ok = gen_sctp:listen(Sb, true),

    {ok,Sa} = gen_sctp:open([{type,stream}]),
    ?LOGVAR(Sa),
    {ok,Pa} = inet:port(Sa),
    ?LOGVAR(Pa),
    #sctp_assoc_change{state=comm_up,
		       error=0,
		       outbound_streams=SaOutboundStreams,
		       inbound_streams=SaInboundStreams,
		       assoc_id=SaAssocId_X} =
	log_ok(gen_sctp:connect(Sa, Loopback, Pb, [])),
    ?LOGVAR(SaAssocId_X),
    [{_,#sctp_paddrinfo{assoc_id=SaAssocId,state=active}}] =
	log_ok(inet:getopts(Sa, [{sctp_get_peer_addr_info,
				  #sctp_paddrinfo{address={Loopback,Pb}}}])),
    ?LOGVAR(SaAssocId),
    match_unless_solaris(SaAssocId_X, SaAssocId),

    {SbOutboundStreams,SbInboundStreams,SbAssocId} =
	case recv_event(log_ok(gen_sctp:recv(Sb, infinity))) of
	    {Loopback,Pa,
	     #sctp_assoc_change{state=comm_up,
				error=0,
				outbound_streams=OS,
				inbound_streams=IS,
				assoc_id=AI}} ->
		{OS,IS,AI};
	    {Loopback,Pa,
	     #sctp_paddr_change{state=addr_confirmed,
				addr={Loopback,Pa},
				error=0,
				assoc_id=AI}} ->
		{Loopback,Pa,
		 #sctp_assoc_change{state=comm_up,
				    error=0,
				    outbound_streams=OS,
				    inbound_streams=IS,
				    assoc_id=AI}} =
		    recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
		{OS,IS,AI}
	end,
    ?LOGVAR(SbAssocId),
    SaOutboundStreams = SbInboundStreams,
    ?LOGVAR(SaOutboundStreams),
    SbOutboundStreams = SaInboundStreams,
    ?LOGVAR(SbOutboundStreams),
    ok = gen_sctp:send(Sa, SaAssocId, 0, Data),
    case log_ok(gen_sctp:recv(Sb, infinity)) of
	{Loopback,
	 Pa,
	 [#sctp_sndrcvinfo{stream   = Stream,
			   assoc_id = SbAssocId}],
	 Data} ->
            ?P("[1] received expected data with ancillary data => done"),
            ok;

	{Loopback,
	 Pa,
         [],
	 #sctp_paddr_change{addr     = {Loopback,_},
			    state    = addr_available,
			    error    = 0,
			    assoc_id = SbAssocId}} ->
            ?P("[2] received paddr change => recv again"),
            Res2 = log_ok(gen_sctp:recv(Sb, infinity)),
            ?P("[2] recv ok => "
               "~n   ~p", [Res2]),
	    {Loopback,
	     Pa,
	     [#sctp_sndrcvinfo{stream   = Stream,
			       assoc_id = SbAssocId}],
	     Data} = Res2,
            ?P("[2] received expected data with ancillary data => done"),
            Res2;

	{Loopback,
	 Pa,
	 [#sctp_sndrcvinfo{stream    = Stream,
			   assoc_id  = SbAssocId}],
	 #sctp_paddr_change{addr     = {Loopback,_},
			    state    = addr_confirmed,
			    error    = 0,
			    assoc_id = SbAssocId}} ->
            ?P("[3] received paddr change with ancillary data => recv again"),
            Res3 = log_ok(gen_sctp:recv(Sb, infinity)),
            ?P("[3] recv ok => "
               "~n   ~p", [Res3]),
	    {Loopback,
	     Pa,
	     [#sctp_sndrcvinfo{stream   = Stream,
			       assoc_id = SbAssocId}],
	     Data} = Res3,
            ?P("[3] received expected data with ancillary data => done"),
            Res3;

        %% It seems that on FreeBSD (for instance) we don't get any
        %% AncData with this.
	{Loopback,
	 Pa,
	 [],
	 #sctp_paddr_change{addr     = {Loopback,_},
			    state    = addr_confirmed,
			    error    = 0,
			    assoc_id = SbAssocId}} when (OSName =:= freebsd) ->
            ?P("[4] received paddr change without ancillary data => "
               "recv again"),
            Res4 = log_ok(gen_sctp:recv(Sb, infinity)),
            ?P("[4] recv ok => "
               "~n   ~p", [Res4]),
            case Res4 of
                {Loopback,
                 Pa,
                 [#sctp_sndrcvinfo{stream   = Stream,
                                   assoc_id = SbAssocId}],
                 Data} ->
                    ?P("[4] received expected data with ancillary data => "
                       "done"),
                    Res4;
                {Loopback, Pa, [],
                 #sctp_paddr_change{addr     = {LAddr, _},
                                    state    = addr_confirmed,
                                    error    = 0,
                                    assoc_id = SbAssocId}} ->
                    ?P("[4] received paddr-change event - receive again"),
                    {Loopback,
                     Pa,
                     [#sctp_sndrcvinfo{stream   = Stream,
                                       assoc_id = SbAssocId}],
                     Data} = log_ok(gen_sctp:recv(Sb, infinity)),
                    ?P("[4] *now* we received expected data "
                       "with ancillary data => done"),
                    Res4
            end;

        {FromIPX, FromPortX, AncDataX, DataX} = Other1 ->
            ?P("UNEXPECTED: "
               "~n   FromIP:   ~p"
               "~n   FromPort: ~p"
               "~n   AncData:  ~p"
               "~n   Data:     ~p"
               "~nwhen"
               "~n   Loopback: ~p"
               "~n   Pa:       ~p",
               [FromIPX, FromPortX, AncDataX, DataX, Loopback, Pa]),
            exit({unexpected, Other1});
        Other2 ->
            ?P("UNEXPECTED: "
               "~n   Other:    ~p"
               "~nwhen"
               "~n   Loopback: ~p"
               "~n   Pa:       ~p",
               [Other2, Loopback, Pa]),
            exit({unexpected, Other2})
    end,
    ok =
	do_from_other_process(
	  fun () -> gen_sctp:send(Sb, SbAssocId, 0, Data) end),
    case log_ok(gen_sctp:recv(Sa, infinity)) of
	{Loopback,Pb,
	 [#sctp_sndrcvinfo{stream=Stream,
			   assoc_id=SaAssocId}],
	 Data} -> ok;
	Event1 ->
	    {Loopback,Pb,
	     #sctp_paddr_change{state=addr_confirmed,
				addr={_,Pb},
				error=0,
				assoc_id=SaAssocId}} =
		recv_event(Event1),
	    {Loopback,Pb,
	     [#sctp_sndrcvinfo{stream=Stream,
			       assoc_id=SaAssocId}],
	     Data} =
		log_ok(gen_sctp:recv(Sa, infinity))
    end,
    ok = gen_sctp:close(Sa),
    {Loopback,Pa,
     #sctp_shutdown_event{assoc_id=SbAssocId}} =
	recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
    {Loopback,Pa,
     #sctp_assoc_change{state=shutdown_comp,
			error=0,
			assoc_id=SbAssocId}} =
	recv_event(log_ok(gen_sctp:recv(Sb, infinity))),
    ok = gen_sctp:close(Sb),

    receive
	Msg -> ct:fail({received,Msg})
    after 17 -> ok
    end,
    ok.



do_from_other_process(Fun) ->
    Parent = self(),
    Ref = make_ref(),
    Child =
	spawn(fun () ->
		      try Fun() of
			  Result ->
			      Parent ! {Ref,Result}
		      catch
			  Class:Reason:Stacktrace ->
			      Parent ! {Ref,Class,Reason,Stacktrace}
		      end
	      end),
    Mref = erlang:monitor(process, Child),
    receive
	{Ref,Result} ->
	    receive {'DOWN',Mref,_,_,_} -> Result end;
	{Ref,Class,Reason,Stacktrace} ->
	    receive {'DOWN',Mref,_,_,_} ->
		    erlang:raise(Class, Reason, Stacktrace)
	    end;
	{'DOWN',Mref,_,_,Reason} ->
	    erlang:exit(Reason)
    end.


%% Peel off an SCTP stream socket ({active,once}).

peeloff_active_once_ipv4(Config) ->
    Cond =
	fun() ->
		?P("~s:cond -> verify IPv4 (inet) support", [?FUNCTION_NAME]),
		?HAS_SUPPORT_IPV4()
	end,
    Pre =
	fun() ->
		?P("~s:pre -> try get \"proper\" local address",
		   [?FUNCTION_NAME]),
		case ?WHICH_LOCAL_ADDR(inet) of
		    {ok, Addr} ->
			?P("~s:pre -> \"proper\" local address: ~p",
			   [?FUNCTION_NAME, Addr]),
			Addr;
		    {error, _Reason} ->
			?P("~s:pre -> no \"proper\" local address",
			   [?FUNCTION_NAME]),
			undefined
		end
	end,
    TC =
	fun(Addr) ->
		?P("~s:tc -> run with loopback address", [?FUNCTION_NAME]),
		peeloff(Config, [{active,once}], {127,0,0,1}),
		?P("~s:tc -> maybe run with \"poper\" address",
		   [?FUNCTION_NAME]),
		peeloff(Config, [{active,once}], Addr)
	end,
    Post =
	fun(_) ->
		?P("~s:post -> nothing", [?FUNCTION_NAME]),
		ok
	end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

peeloff_active_once_ipv6(Config) ->
    Cond =
	fun() ->
		?P("~s:cond -> verify IPv6 (inet6) support", [?FUNCTION_NAME]),
		?HAS_SUPPORT_IPV6()
	end,
    Pre =
	fun() ->
		?P("~s:pre -> try get \"proper\" local address",
		   [?FUNCTION_NAME]),
		case ?WHICH_LOCAL_ADDR(inet6) of
		    {ok, Addr} ->
			?P("~s:pre -> \"proper\" local address: ~p",
			   [?FUNCTION_NAME, Addr]),
			Addr;
		    {error, _Reason} ->
			?P("~s:pre -> no \"proper\" local address",
			   [?FUNCTION_NAME]),
			undefined
		end
	end,
    TC =
	fun(Addr) ->
		?P("~s:tc -> run with loopback address", [?FUNCTION_NAME]),
		peeloff(Config, [{active,once}], {0,0,0,0,0,0,0,1}),
		?P("~s:tc -> maybe run with local address", [?FUNCTION_NAME]),
		peeloff(Config, [{active,once}], Addr)
	end,
    Post =
	fun(_) ->
		?P("~s:post -> nothing", [?FUNCTION_NAME]),
		ok
	end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).


%% Peel off an SCTP stream socket ({active,true}).

peeloff_active_true(Config) ->
    Cond =
	fun() ->
		?P("~s:cond ->  verify IPv4 (inet) support", [?FUNCTION_NAME]),
		?HAS_SUPPORT_IPV4()
	end,
    Pre =
	fun() ->
		?P("~s:pre -> nothing", [?FUNCTION_NAME]),
		undefined
	end,
    TC =
	fun(_) ->
		?P("~s:tc -> run", [?FUNCTION_NAME]),
		peeloff(Config, [{active,true}])
	end,
    Post =
	fun(_) ->
		?P("~s:post -> nothing", [?FUNCTION_NAME]),
		ok
	end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).
		    

%% Peel off an SCTP stream socket ({active,N}).

peeloff_active_n(Config) ->
    Cond =
	fun() ->
		?P("~s:cond -> verify (inet) support", [?FUNCTION_NAME]),
		?HAS_SUPPORT_IPV4()
	end,
    Pre =
	fun() ->
		?P("~s:pre -> nothing", [?FUNCTION_NAME]),
		undefined
	end,
    TC =
	fun(_) ->
		?P("~s:tc -> run", [?FUNCTION_NAME]),
		peeloff(Config, [{active,1}])
	end,
    Post =
	fun(_) ->
		?P("~s:post -> nothing", [?FUNCTION_NAME]),
		ok
	end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).


peeloff(Config, SockOpts) when is_list(Config) ->
    peeloff(Config, SockOpts, {127,0,0,1}).

peeloff(_Config, _SockOpts, undefined) ->
    ok;
peeloff(Config, SockOpts, Addr) when is_list(Config) ->
    ?P("~s -> entry with"
       "~n   Config:   ~p"
       "~n   SockOpts: ~p"
       "~n   Addr:     ~p", [?FUNCTION_NAME, Config, SockOpts, Addr]),
    Stream = 0,
    Timeout = 333,
    InheritOpts = [{priority, 3}, {sctp_nodelay, true}, {linger, {true, 7}}],
    %% Verify the last inherit option to make sure no earlier
    %% option does a silent bailout
    SurelyInheritedOpt = lists:last(InheritOpts),
    InheritOptnames = [Opt || {Opt,_} <- InheritOpts],
    StartTime = timestamp(),
    {{S1,P1,S1Ai}, {S2,P2,S2Ai}} =
        socket_pair_open(Addr, StartTime, Timeout),
    Socket1 = socket_call(S1, get_socket),
    ?LOGVAR(Socket1),
    Socket2 = socket_call(S2, get_socket),
    ?LOGVAR(Socket2),
    %%
    socket_call(S2, {send,S2Ai,Stream,<<"Number one">>}),
    receive
	{S1,{Addr,P2,S1Ai,Stream,<<"Number one">>}} -> ok
    after Timeout ->
	    socket_bailout([S1,S2], StartTime)
    end,
    socket_call(S2, {send,Socket1,S1Ai,Stream,<<"Number two">>}),
    receive
	{S2,{Addr,P1,S2Ai,Stream,<<"Number two">>}} -> ok
    after Timeout ->
	    socket_bailout([S1,S2], StartTime)
    end,
    socket_call(S1, {setopts, InheritOpts}),
    InheritedOpts = socket_call(S1, {getopts, InheritOptnames}),
    SurelyInheritedOpt = lists:last(InheritedOpts),
    %%
    S3 = socket_peeloff(Socket1, S1Ai, SockOpts, Timeout),
    ?LOGVAR(S3),
    P3_X = socket_call(S3, get_port),
    ?LOGVAR(P3_X),
    P3 = case P3_X of 0 -> P1; _ -> P3_X end,
    InheritedOpts = socket_call(S3, {getopts, InheritOptnames}),
    [{_,#sctp_paddrinfo{assoc_id=S3Ai,state=active}}] =
	socket_call(S3,
		    {getopts,[{sctp_get_peer_addr_info,
			       #sctp_paddrinfo{address={Addr,P2}}}]}),
    %%S3Ai = S1Ai,
    ?LOGVAR(S3Ai),
    %%
    socket_call(S3, {send,S3Ai,Stream,<<"Number three">>}),
    receive
	{S2,{Addr,P3,S2Ai,Stream,<<"Number three">>}} -> ok
    after Timeout ->
	    socket_bailout([S1,S2,S3], StartTime)
    end,
    socket_call(S3, {send,Socket2,S2Ai,Stream,<<"Number four">>}),
    receive
	{S3,{Addr,P2,S3Ai,Stream,<<"Number four">>}} -> ok
    after Timeout ->
	    socket_bailout([S1,S2,S3], StartTime)
    end,
    %%
    inet:i(sctp),
    ?P("~s -> try (verbose) close of S1 (~p)", [?FUNCTION_NAME, S1]),
    socket_close_verbose(S1, StartTime),
    ?P("~s -> await (normal) exit signal from ~p", [?FUNCTION_NAME, S1]),
    receive {'EXIT', S1, normal} -> ok end,
    ?P("~s -> try (verbose) close of S2 (~p)", [?FUNCTION_NAME, S2]),
    socket_close_verbose(S2, StartTime),
    ?P("~s -> await (normal) exit signal from ~p", [?FUNCTION_NAME, S2]),
    receive {'EXIT', S2, normal} -> ok end,
    ?P("~s -> await shutdown event from S3 (~p)", [?FUNCTION_NAME, S3]),
    receive
	{S3,{Addr,P2,#sctp_shutdown_event{assoc_id=S3Ai_X}}} ->
	    ?P("~s -> received expected shutdown event", [?FUNCTION_NAME]),
	    match_unless_solaris(S3Ai, S3Ai_X)
    after Timeout ->
	    ?P("~s -> (shutdown event) timeout", [?FUNCTION_NAME]),
	    socket_bailout([S3], StartTime)
    end,
    ?P("~s -> await assoc-change event from S3 (~p)", [?FUNCTION_NAME, S3]),
    receive
	{S3,{Addr,P2,#sctp_assoc_change{state=shutdown_comp,
					assoc_id=S3Ai}}} ->
	    ?P("~s -> received expected assoc-change event", [?FUNCTION_NAME]),
	    ok
    after Timeout ->
	    ?P("~s -> (assoc-change event) timeout", [?FUNCTION_NAME]),
	    socket_bailout([S3], StartTime)
    end,
    ?P("~s -> try (verbose) close of S3 (~p)", [?FUNCTION_NAME, S3]),
    socket_close_verbose(S3, StartTime),
    ?P("~s -> await (normal) exit signal from ~p", [?FUNCTION_NAME, S3]),
    receive {'EXIT', S3, normal} -> ok end,
    ?P("~s -> try flush events - expect none", [?FUNCTION_NAME]),
    case flush() of
	[] ->
	    ok;
	UnexpectedEvents ->
	    ?P("~s -> unexpected events when flushing:"
	       "~n   ~p", [?FUNCTION_NAME, UnexpectedEvents]),
	    exit({unexpected_evs, UnexpectedEvents})
    end,
    ?P("~s -> done", [?FUNCTION_NAME]),
    ok.

%% Check sndbuf and recbuf behaviour.
buffers(Config) when is_list(Config) ->
    Limit = 4096,
    Addr = {127,0,0,1},
    Stream = 1,
    Timeout = 3333,
    StartTime = timestamp(),
    {{S1,_P1,S1Ai}, {S2,P2,S2Ai}} = SocketPair =
        socket_pair_open(Addr, StartTime, Timeout),
    %%
    socket_call(S1, {setopts,[{recbuf,Limit}]}),
    Recbuf =
	case socket_call(S1, {getopts,[recbuf]}) of
	    [{recbuf,RB1}] when RB1 >= Limit -> RB1
	end,
    Data = mk_data(Recbuf+Limit),
    socket_call(S2, {setopts,[{sndbuf,Recbuf+Limit}]}),
    socket_call(S2, {send,S2Ai,Stream,Data}),
    receive
	{S1,{Addr,P2,S1Ai,Stream,Data}} -> ok
    after Timeout ->
	    socket_bailout([S1,S2], StartTime)
    end,
    %%
    socket_pair_close(Addr, StartTime, Timeout, SocketPair).

mk_data(Bytes) ->
    mk_data(0, Bytes, <<>>).
%%
mk_data(N, Bytes, Bin) when N < Bytes ->
    mk_data(N+4, Bytes, <<Bin/binary,N:32>>);
mk_data(_, _, Bin) ->
    Bin.


send_block(Config) when is_list(Config) ->
    Limit          = 4096,
    Addr           = {127,0,0,1},
    Stream         = 1,
    Timeout        = 1111,
    ReceiveTimeout = 3333,
    StartTime      = timestamp(),
    N              = 8,
    %%
    {{S1,P1,S1Ai}, {S2,_P2,S2Ai}} = SocketPair =
        socket_pair_open(Addr, StartTime, Timeout),
    %%
    socket_call(S1, {setopts,[{sndbuf,Limit}]}),
    Sndbuf =
	case socket_call(S1, {getopts,[sndbuf]}) of
	    [{sndbuf,SB1}] when SB1 >= Limit -> SB1
	end,
    ?LOGVAR(Sndbuf),
    Data = mk_data(Sndbuf div 2),
    Seq = lists:seq(1, N),
    ok = socket_call(S2, {setopts,[{recbuf,Sndbuf*2},{active,false}]}),
    Sender = self(),
    ReceiveFun =
        fun RF(J) when 0 < J ->
                receive
                    {Sender, send, J} ->
                        ct:log("send signalled {~w}: ~w~n", [self(), J]),
                        RF(J + 1)
                after Timeout ->
                        ct:log("send timed out {~w}: ~w~n", [self(), J]),
                        ok = socket_call(S2, {setopts, [{active, true}]}),
                        ct:log("set active true {~w}: ~w~n", [self(), J]),
                        RF(-1)
                end;
            RF(J) when -N =< J, J < 0 ->
                receive
                    {S2,{Addr,P1,S2Ai,Stream,<<I:32,Data/binary>>}} ->
                        ct:log("recv {~w}: ~w~n", [self(), I]),
                        I = -J,
                        RF(J - 1)
                after ReceiveTimeout ->
                        %% For some reason, hopefully not our fault,
                        %% we'll say OS reason for now, there is a 1..2 s
                        %% delay between the first and the second message
                        %% received after setting active=true,
                        %% even though there are 2 (at least) messages
                        %% buffered by the sending side.
                        %%
                        %% Therefore ReceiveTimeout is above 3 s
                        %% while Timeout can be shorter...
                        socket_bailout([S1,S2], StartTime)
                end;
            RF(J) when J < -N ->
                ok = socket_controlling_process(S2, Sender),
                Sender ! {self(), ok}
        end,
    Receiver = spawn_link(fun () -> ReceiveFun(1) end),
    ok = socket_controlling_process(S2, Receiver),
    [begin
         ok = socket_call(S1, {send,S1Ai,Stream,<<J:32,Data/binary>>}),
         ct:log("send {~w}: ~w~n", [self(), J]),
         Receiver ! {Sender, send, J}
     end || J <- Seq],
    receive {Receiver, ok} -> ok end,
    %%
    socket_pair_close(Addr, StartTime, Timeout, SocketPair).

%% Test opening a multihoming ipv4 socket.
open_multihoming_ipv4_socket(Config) when is_list(Config) ->
    ?P("~s -> get addrs by family (inet, 2)", [?FUNCTION_NAME]),
    case get_addrs_by_family(inet, 2) of
	{ok, [Addr1, Addr2]} ->
            ?P("got addrs: "
               "~n      Addr1: ~p"
               "~n      Addr2: ~p", [Addr1, Addr2]),
	    do_open_and_connect([Addr1, Addr2], Addr1);
	{error, Reason} ->
            ?P("failed get addrs: "
               "~n      ~p", [Reason]),
	    {skip, Reason}
    end.

%% This test is mostly aimed to indicate whether host has a
%% non-working ipv6 setup.  Test opening a unihoming (non-multihoming)
%% ipv6 socket.
open_unihoming_ipv6_socket(Config) when is_list(Config) ->
    Cond = fun() ->
                   case os:type() of
                       {unix, freebsd} ->
                           %% There is some issue on FreeBSD 14.4
                           %% (it did not use to a problem before 14.4).
                           case os:version() of
                               {14,4,_} = Version ->
                                   skip({bad_version, Version});
                               _ ->
                                   ok
                           end;
                       _ ->
                           ok
                   end
           end,
    Pre  = fun() ->
                   #{config => Config}
           end,
    TC   = fun(C) ->
                   do_open_unihoming_ipv6_socket(C)
           end,
    Post = fun(_) ->
                   ok
           end,
    ?TC_TRY(?FUNCTION_NAME,
            Cond, Pre, TC, Post).

do_open_unihoming_ipv6_socket(#{config := _}) ->
    ?P("~s -> get addrs by family (inet6, 1)", [?FUNCTION_NAME]),
    case get_addrs_by_family(inet6, 1) of
	{ok, [Addr]} ->
            ?P("got addr: "
               "~n      Addr: ~p", [Addr]),
	    do_open_and_connect([Addr], Addr);
	{error, Reason} ->
	    {skip, Reason}
    end.


%% Test opening a multihoming ipv6 socket.
open_multihoming_ipv6_socket(Config) when is_list(Config) ->
    Cond = fun() ->
                   case os:type() of
                       {unix, freebsd} ->
                           %% There is some issue on FreeBSD 14.4
                           %% (it did not use to a problem before 14.4).
                           case os:version() of
                               {14,4,_} = Version ->
                                   skip({bad_version, Version});
                               _ ->
                                   ok
                           end;
                       _ ->
                           ok
                   end
           end,
    Pre  = fun() ->
                   #{config => Config}
           end,
    TC   = fun(C) ->
                   do_open_multihoming_ipv6_socket(C)
           end,
    Post = fun(_) ->
                   ok
           end,
    ?TC_TRY(?FUNCTION_NAME,
            Cond, Pre, TC, Post).

do_open_multihoming_ipv6_socket(#{config := _}) ->
    ?P("~s -> get addrs by family (inet6, 1)", [?FUNCTION_NAME]),
    case get_addrs_by_family(inet6, 2) of
	{ok, [Addr1, Addr2]} ->
	    do_open_and_connect([Addr1, Addr2], Addr1);
	{error, Reason} ->
	    {skip, Reason}
    end.

%% Test opening a multihoming ipv6 socket with ipv4 and ipv6 addresses.
open_multihoming_ipv4_and_ipv6_socket(Config) when is_list(Config) ->
    Cond = fun() ->
                   case os:type() of
                       {unix, freebsd} ->
                           %% There is some issue on FreeBSD 14.4
                           %% (it did not use to a problem before 14.4).
                           case os:version() of
                               {14,4,_} = Version ->
                                   skip({bad_version, Version});
                               _ ->
                                   ok
                           end;
                       _ ->
                           ok
                   end
           end,
    Pre  = fun() ->
                   #{config => Config}
           end,
    TC   = fun(C) ->
                   do_open_multihoming_ipv4_and_ipv6_socket(C)
           end,
    Post = fun(_) ->
                   ok
           end,
    ?TC_TRY(?FUNCTION_NAME,
            Cond, Pre, TC, Post).

do_open_multihoming_ipv4_and_ipv6_socket(#{config := _}) ->
    case get_addrs_by_family(inet_and_inet6, 2) of
	{ok, [[InetAddr1, InetAddr2], [Inet6Addr1, Inet6Addr2]]} ->
	    %% Connect to the first address to test bind
	    do_open_and_connect([InetAddr1, Inet6Addr1, InetAddr2],
				InetAddr1),
	    do_open_and_connect([Inet6Addr1, InetAddr1],
				Inet6Addr1),

	    %% Connect an address, not the first,
	    %% to test sctp_bindx
	    do_open_and_connect([Inet6Addr1, Inet6Addr2, InetAddr1],
				Inet6Addr2),
	    do_open_and_connect([Inet6Addr1, Inet6Addr2, InetAddr1],
				InetAddr1);
	{error, Reason} ->
	    {skip, Reason}
    end.

%% Test inet:socknames/peernames on unihoming IPv4 sockets.
names_unihoming_ipv4(Config) when is_list(Config) ->
    do_names(#{config      => Config,
               family      => inet,
               addrs_count => 1}).

%% Test inet:socknames/peernames on unihoming IPv6 sockets.
names_unihoming_ipv6(Config) when is_list(Config) ->
    Cond = fun() ->
                   case os:type() of
                       {unix, freebsd} ->
                           %% There is some issue on FreeBSD 14.4
                           %% (it did not use to a problem before 14.4).
                           case os:version() of
                               {14,4,_} = Version ->
                                   skip({bad_version, Version});
                               _ ->
                                   ok
                           end;
                       _ ->
                           ok
                   end
           end,
    Pre  = fun() ->
                   #{config      => Config,
                     family      => inet6,
                     addrs_count => 1}
           end,
    TC   = fun(C) ->
                   do_names(C)
           end,
    Post = fun(_) ->
                   ok
           end,
    ?TC_TRY(?FUNCTION_NAME,
            Cond, Pre, TC, Post).


%% Test inet:socknames/peernames on multihoming IPv4 sockets.
names_multihoming_ipv4(Config) when is_list(Config) ->
    do_names(#{config      => Config,
               family      => inet,
               addrs_count => 2}).

%% Test inet:socknames/peernames on multihoming IPv6 sockets.
names_multihoming_ipv6(Config) when is_list(Config) ->
    Cond = fun() ->
                   case os:type() of
                       {unix, freebsd} ->
                           %% There is some issue on FreeBSD 14.4
                           %% (it did not use to a problem before 14.4).
                           case os:version() of
                               {14,4,_} = Version ->
                                   skip({bad_version, Version});
                               _ ->
                                   ok
                           end;
                       _ ->
                           ok
                   end
           end,
    Pre  = fun() ->
                   #{config      => Config,
                     family      => inet6,
                     addrs_count => 2}
           end,
    TC   = fun(C) ->
                   do_names(C)
           end,
    Post = fun(_) ->
                   ok
           end,
    ?TC_TRY(?FUNCTION_NAME,
            Cond, Pre, TC, Post).


do_names(#{family := FamilySpec, addrs_count := AddressCount}) ->
    Fun =
	fun (ServerSocket, _, ServerAssoc, ClientSocket, _, ClientAssoc) ->
		ServerSocknamesNoassoc =
		    lists:sort(ok(inet:socknames(ServerSocket))),
		?LOGVAR(ServerSocknamesNoassoc),
		ServerSocknames =
		    lists:sort(ok(inet:socknames(ServerSocket, ServerAssoc))),
		?LOGVAR(ServerSocknames),
		[_|_] =
		    ordsets:intersection
		      (ServerSocknamesNoassoc, ServerSocknames),
		ClientSocknamesNoassoc =
		    lists:sort(ok(inet:socknames(ClientSocket))),
		?LOGVAR(ClientSocknamesNoassoc),
		ClientSocknames =
		    lists:sort(ok(inet:socknames(ClientSocket, ClientAssoc))),
		?LOGVAR(ClientSocknames),
		[_|_] =
		    ordsets:intersection
		      (ClientSocknamesNoassoc, ClientSocknames),
		err([einval,enotconn], inet:peernames(ServerSocket)),
		ServerPeernames =
		    lists:sort(ok(inet:peernames(ServerSocket, ServerAssoc))),
		?LOGVAR(ServerPeernames),
		err([einval,enotconn], inet:peernames(ClientSocket)),
		ClientPeernames =
		    lists:sort(ok(inet:peernames(ClientSocket, ClientAssoc))),
		?LOGVAR(ClientPeernames),
		ServerSocknames = ClientPeernames,
		ClientSocknames = ServerPeernames,
		{ok,Socket} =
		    gen_sctp:peeloff(ServerSocket, ServerAssoc),
		SocknamesNoassoc =
		    lists:sort(ok(inet:socknames(Socket))),
		?LOGVAR(SocknamesNoassoc),
		Socknames =
		    lists:sort(ok(inet:socknames(Socket, ServerAssoc))),
		?LOGVAR(Socknames),
		true =
		    ordsets:is_subset(SocknamesNoassoc, Socknames),
		Peernames =
		    lists:sort(ok(inet:peernames(Socket, ServerAssoc))),
		?LOGVAR(Peernames),
		ok = gen_sctp:close(Socket),
		Socknames = ClientPeernames,
		ClientSocknames = Peernames,
		ok
	end,
    case get_addrs_by_family(FamilySpec, AddressCount) of
	{ok, Addresses} when length(Addresses) =:= AddressCount ->
	    do_open_and_connect(Addresses, hd(Addresses), Fun);
	{error, Reason} ->
	    {skip, Reason}
    end.



get_addrs_by_family(Family, NumAddrs) ->
    case os:type() of
	{unix,linux} ->
	    get_addrs_by_family_aux(Family, NumAddrs);
	{unix,freebsd} ->
	    get_addrs_by_family_aux(Family, NumAddrs);
	{unix,sunos} ->
	    case get_addrs_by_family_aux(Family, NumAddrs) of
		{ok, [InetAddrs, Inet6Addrs]} when Family =:= inet_and_inet6 ->
		    %% Man page for sctp_bindx on Solaris says: "If sock is an
		    %% Internet Protocol Version 6 (IPv6) socket, addrs should
		    %% be an array of sockaddr_in6 structures containing IPv6
		    %% or IPv4-mapped IPv6 addresses."
		    {ok, [ipv4_map_addrs(InetAddrs), Inet6Addrs]};
		{ok, Addrs} ->
		    {ok, Addrs};
		{error, Reason} ->
		    {error, Reason}
	    end;
	Os ->
	    Reason = if Family =:= inet_and_inet6 ->
			     ?F("Mixing ipv4 and ipv6 addresses for "
			       " multihoming has not been verified on ~p",
                                [Os]);
			true ->
			     ?F("Multihoming for ~p has not been verified "
                                "on ~p", [Family, Os])
		     end,
	    {error, Reason}
    end.

get_addrs_by_family_aux(Family, NumAddrs) when Family =:= inet;
					       Family =:= inet6 ->
    case inet:getaddr(localhost, Family) of
	{error, eafnosupport = Reason} ->
            ?P("failed get (~w) addrs for localhost: ~p", [Family, Reason]),
	    {error, ?F("No support for ~p (~p)", [Family, Reason])};
        {error, nxdomain = Reason} ->
            ?P("failed get (~w) addrs for localhost: ~p", [Family, Reason]),
	    {error, ?F("No support for ~p (~p)", [Family, Reason])};
	{ok, _} ->
            ?P("got addr for localhost (ignored)"),
	    IfAddrs = ok(inet:getifaddrs()),
            ?P("IfAddrs: ~p", [IfAddrs]),
	    case filter_addrs_by_family(IfAddrs, Family) of
		Addrs when length(Addrs) >= NumAddrs ->
		    Addrs2 = lists:sublist(Addrs, NumAddrs),
		    ?P("Addrs2: ~p", [Addrs2]),
		    {ok, Addrs2};
		[] ->
		    {error, ?F("Need ~p ~p address(es) found none~n",
                               [NumAddrs, Family])};
		Addrs ->
		    {error,
		     ?F("Need ~p ~p address(es) found only ~p: ~p~n",
                        [NumAddrs, Family, length(Addrs), Addrs])}
	    end
    end;
get_addrs_by_family_aux(inet_and_inet6, NumAddrs) ->
    try {ok, [case get_addrs_by_family_aux(Family, NumAddrs) of
                  {ok, Addrs}     ->
		      Addrs;
                  {error, Reason} ->
		      throw({error, Reason})
              end || Family <- [inet, inet6]]}
    catch
        throw:{error, _} = ERROR ->
            ERROR
    end.

filter_addrs_by_family(IfAddrs, Family) ->
    lists:flatten([[Addr || {addr, Addr} <- Info,
			    is_good_addr(Addr, Family)]
		   || {_IfName, Info} <- IfAddrs]).

is_good_addr(Addr, inet) when tuple_size(Addr) =:= 4 ->
    true;
is_good_addr({0,0,0,0,0,16#ffff,_,_}, inet6) ->
    false; %% ipv4 mapped
is_good_addr({16#fe80,_,_,_,_,_,_,_}, inet6) ->
    false; %% link-local
is_good_addr(Addr, inet6) when tuple_size(Addr) =:= 8 ->
    true;
is_good_addr(_Addr, _Family) ->
    false.

ipv4_map_addrs(InetAddrs) ->
    [begin
	 <<AB:16>> = <<A,B>>,
	 <<CD:16>> = <<C,D>>,
	 {0, 0, 0, 0, 0, 16#ffff, AB, CD}
     end || {A,B,C,D} <- InetAddrs].

do_open_and_connect(ServerAddresses, AddressToConnectTo) ->
    Fun = fun (_, _, _, _, _, _) -> ok end,
    do_open_and_connect(ServerAddresses, AddressToConnectTo, Fun).
%%
do_open_and_connect(ServerAddresses, AddressToConnectTo, Fun) ->
    ?P("~s -> entry with"
       "~n   ServerAddresses:    ~p"
       "~n   AddressToConnectTo: ~p",
       [?FUNCTION_NAME, ServerAddresses, AddressToConnectTo]),
    {ServerFamily, ServerOpts} = get_family_by_addrs(ServerAddresses),
    ?P("~s -> Serving ~p addresses: ~p~n",
       [?FUNCTION_NAME, ServerFamily, ServerAddresses]),
    S1 = ok(gen_sctp:open(0, [{ip,Addr} || Addr <- ServerAddresses] ++
			      [ServerFamily|ServerOpts])),
    ok = gen_sctp:listen(S1, true),
    P1 = ok(inet:port(S1)),
    ?P("~s -> "
       "~n   S1:          ~p"
       "~n   port of S1:  ~p"
       "~n   sockname S1: ~p", [?FUNCTION_NAME, S1, P1, inet:sockname(S1)]),
    ClientFamily = get_family_by_addr(AddressToConnectTo),
    ClientOpts =
	[ClientFamily |
	 case ClientFamily of
	     inet6 ->
		 [{ipv6_v6only,true}];
	     _ ->
		 []
	 end],
    S2 = ok(gen_sctp:open(0, ClientOpts)),
    ?P("~s -> "
       "~n   S2:          ~p"
       "~n   sockname S2: ~p", [?FUNCTION_NAME, S2, inet:sockname(S2)]),
    log(open),
    ?P("~s -> [~w] try connect to ~p",
       [?FUNCTION_NAME, ClientFamily, AddressToConnectTo]),
    %% Verify client can connect
    #sctp_assoc_change{state=comm_up} = S2Assoc =
	ok(gen_sctp:connect(S2, AddressToConnectTo, P1, [])),
    log(comm_up),
    %% verify server side also receives comm_up from client
    ?P("~s -> await (server side) comm-up (eventually)", [?FUNCTION_NAME]),
    S1Assoc = recv_comm_up_eventually(S1),
    ?P("~s -> verify", [?FUNCTION_NAME]),
    Result = Fun(S1, ServerFamily, S1Assoc, S2, ClientFamily, S2Assoc),
    ?P("~s -> cleanup", [?FUNCTION_NAME]),
    ok = gen_sctp:close(S2),
    ok = gen_sctp:close(S1),
    ?P("~s -> done when"
       "~n   Result: ~p", [?FUNCTION_NAME, Result]),
    Result.

%% If at least one of the addresses is an ipv6 address, return inet6, else inet.
get_family_by_addrs(Addresses) ->
    case lists:usort([get_family_by_addr(Addr) || Addr <- Addresses]) of
	[inet, inet6] -> {inet6, [{ipv6_v6only, false}]};
	[inet]        -> {inet,  []};
	[inet6]       -> {inet6, []}
    end.

get_family_by_addr(Addr) when tuple_size(Addr) =:= 4 -> inet;
get_family_by_addr(Addr) when tuple_size(Addr) =:= 8 -> inet6.

recv_comm_up_eventually(S) ->
    case ok(gen_sctp:recv(S)) of
	{_Addr, _Port, _Info,
	 #sctp_assoc_change{state=comm_up} = Assoc} ->
	    Assoc;
	{_Addr, _Port, _Info, _OtherSctpMsg} = Msg ->
	    log({unexpected,Msg}),
	    recv_comm_up_eventually(S)
    end.


%% 
recv_close(Config) when is_list(Config) ->
    ?P("create server socket (and listen)"),
    {ok, S} = gen_sctp:open(),
    gen_sctp:listen(S, true),
    {ok, SPort} = inet:port(S),

    ?P("create client socket (and connect)"),
    {ok, C} = gen_sctp:open(),
    {ok, _} = gen_sctp:connect(C, localhost, SPort, []),

    TC = self(),
    RECV = fun() ->
                   ?P("try setup recv(s)"),
                   ok = recv_close_setup_recv(S),
                   ?P("announce ready"),
                   TC ! {self(), ready},
                   ?P("try data recv"),
                   Res = gen_sctp:recv(S),
                   ?P("recv res: "
                      "~n   ~p", [Res]),
                   exit(Res)
           end,
    ?P("spawn reader - then await reader ready"),
    {Pid, MRef} = spawn_monitor(RECV),
    receive
        {'DOWN', MRef, process, Pid, PreReason} ->
            %% Make sure it does not die for some other reason...
            ?P("unexpected reader termination:"
               "~n   ~p", [PreReason]),
            ?CATCH_AND_IGNORE( gen_sctp:close(S) ),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            ct:fail("Unexpected pre close from reader (~p): ~p",
                          [Pid, PreReason]);
        {Pid, ready} ->
            ?P("reader ready"),
            ok
    after 30000 -> % Just in case...
            %% This is **extreme**, but there is no way to know
            %% how long it will take to iterate through all the
            %% addresses of a host...
            ?P("reader ready timeout"),
            ?CATCH_AND_IGNORE( gen_sctp:close(S) ),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            ct:fail("Unexpected pre close timeout (~p)", [Pid])
    end,

    ?P("\"ensure\" reader reading..."),
    receive
        Any ->
            ?P("Received unexpected message: "
               "~n   ~p", [Any]),
            ?CATCH_AND_IGNORE( gen_sctp:close(S) ),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            ct:fail("Unexpected message: ~p", [Any])
    after 5000 ->
            ok
    end,

    ?P("close server socket"),
    ok = gen_sctp:close(S),
    ?P("await reader termination"),
    receive
        {'DOWN', MRef, process, Pid, {error, closed}} ->
            ?P("expected reader termination result"),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            ok;
        {'DOWN', MRef, process, Pid, PostReason} ->
            ?P("unexpected reader termination: "
               "~n   ~p", [PostReason]),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            ct:fail("Unexpected post close from reader (~p): ~p",
                          [Pid, PostReason])
    after 5000 ->
            ?P("unexpected reader termination timeout"),
            demonitor(MRef, [flush]),
            ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
            exit(Pid, kill),
            ct:fail("Reader (~p) termination timeout", [Pid])
    end,
    ?P("close client socket"),
    ?CATCH_AND_IGNORE( gen_sctp:close(C) ),
    ?P("done"),
    ok.


recv_close_setup_recv(S) ->
    recv_close_setup_recv(S, 1).

recv_close_setup_recv(S, N) ->
    ?P("try setup recv ~w", [N]),
    case gen_sctp:recv(S, 5000) of
        {ok, {Addr,
              Port,
              _AncData, 
              Data}} when is_tuple(Addr) andalso is_integer(Port) ->
            ?P("setup recv ~w: "
               "~n   ~p", [N, Data]),
            recv_close_setup_recv(S, N+1);
        {error, timeout} ->
            ok
    end.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% This is the most basic of (sockaddr) tests.

t_simple_local_sockaddr_in_send_recv(Config) when is_list(Config) ->
    ct:timetrap(?MINS(1)),
    ?TC_TRY(?FUNCTION_NAME,
            fun() -> ok end,
            fun() ->
                    Domain = inet,
                    LocalAddr =
                        case ?LIB:which_local_addr(Domain) of
                            {ok, LA} ->
                                LA;
                            {error, _} ->
                                skip("No local address")
                        end,
                    SockAddr = #{family   => Domain,
                                 addr     => LocalAddr,
                                 port     => 0},
                    do_simple_sockaddr_send_recv(SockAddr, Config)
            end).

t_simple_link_local_sockaddr_in_send_recv(Config) when is_list(Config) ->
    ?TC_TRY(?FUNCTION_NAME,
            fun() -> ok end,
            fun() ->
                    Domain = inet,
                    LinkLocalAddr =
                        case ?LIB:which_link_local_addr(Domain) of
                            {ok, LLA} ->
                                LLA;
                            {error, _} ->
                                skip("No link local address")
                        end,
                    SockAddr = #{family => Domain,
                                 addr   => LinkLocalAddr,
                                 port   => 0},
                    do_simple_sockaddr_send_recv(SockAddr, Config)
            end).


t_simple_local_sockaddr_in6_send_recv(Config) when is_list(Config) ->
    ?TC_TRY(?FUNCTION_NAME,
            fun() -> ?LIB:has_support_ipv6() end,
            fun() ->
                    Domain = inet6,
                    LocalAddr =
                        case ?LIB:which_local_addr(Domain) of
                            {ok, LA} ->
                                LA;
                        {error, _} ->
                            skip("No local address")
                    end,
                    SockAddr = #{family   => Domain,
                                 addr     => LocalAddr,
                                 port     => 0},
                    do_simple_sockaddr_send_recv(SockAddr, Config)
            end).


t_simple_link_local_sockaddr_in6_send_recv(Config) when is_list(Config) ->
    ?TC_TRY(?FUNCTION_NAME,
            fun() ->
                    ?LIB:has_support_ipv6(),
                    is_net_supported(),
                    is_not_freebsd()
            end,
            fun() ->
                    Domain = inet6,
                    LinkLocalAddr =
                        case ?LIB:which_link_local_addr(Domain) of
                            {ok, LLA} ->
                                LLA;
                            {error, _} ->
                                skip("No link local address")
                        end,
                    Filter =
                        fun(#{addr := #{family := D,
                                        addr   := A}} = C) ->
                                if
                                    (D =:= Domain) andalso
                                    (A =:= LinkLocalAddr) ->
                                        ?P("found link-local candidate: "
                                           "~n   ~p", [C]),
                                        true;
                                    true ->
                                        false
                                end;                                        
                           (_) ->
                                false
                        end,
                    case net:getifaddrs(Filter) of
                        {ok, [#{addr := #{scope_id := ScopeID}} = H|T]} ->
                            ?P("found link-local candidate(s): "
                               "~n   Candidate:         ~p"
                               "~n   Rest Candidate(s): ~p", [H, T]),
                            SockAddr = #{family   => Domain,
                                         addr     => LinkLocalAddr,
                                         port     => 0,
                                         scope_id => ScopeID},
                            do_simple_sockaddr_send_recv(SockAddr, Config);
                        {ok, _} ->
                            skip("Scope ID not found");
                        {error, R} ->
                            skip({failed_getifaddrs, R})
                    end
            end).

do_simple_sockaddr_send_recv(#{family := _Fam} = SockAddr, _) ->
    %% Create the server
    Self   = self(),
    ?P("~n      SockAddr: ~p", [SockAddr]),
    ServerF = fun() ->
                      ?P("[server] try create (open) listen socket"),
                      Sock =
                          try gen_sctp:open([{ifaddr, SockAddr},
                                             {active, true},
                                             binary]) of
                              {ok, S} ->
                                  S;
                              {error, OReason} ->
                                  ?P("open error: "
                                     "~n      Reason: ~p", [OReason]),
                                  exit({open_error, OReason})
                          catch
                              OC:OE:OS ->
                                  ?P("open failure: "
                                     "~n      Error Class: ~p"
                                     "~n      Error:       ~p"
                                     "~n      Call Stack:  ~p", [OC, OE, OS]),
                                  exit({open_failure, {OC, OE, OS}})
                          end,

                      ?P("[server] try make 'listen' socket"),
                      ok = gen_sctp:listen(Sock, true),

                      ?P("[server] try get port number"),
                      {ok, Port}  = inet:port(Sock),
                      ?P("[server] port: ~w", [Port]),
                      Self ! {{port, Port}, self()},


                      ?P("try accept (await 'accept' message)"),
                      AssocID1 =
                          receive
                              {sctp,
                               Sock,
                               FromIP11, FromPort11,
                               {ANC1, #sctp_assoc_change{state            = comm_up,
                                                         error            = 0,
                                                         outbound_streams = OutStreams1,
                                                         inbound_streams  = InStreams1,
                                                         assoc_id         = AID1}}} ->
                                  ?P("[server] received assoc - accepted: "
                                     "~n      From IP:     ~p"
                                     "~n      From Port:   ~p"
                                     "~n      ANC:         ~p"
                                     "~n      Out Streams: ~p"
                                     "~n      In Streams:  ~p"
                                     "~n      Assoc ID:    ~p",
                                     [FromIP11, FromPort11, ANC1,
                                      OutStreams1, InStreams1, AID1]),
                                  AID1
                          end,

                      ?P("[server] await message 2"),
                      receive
                          {sctp, Sock, FromIP12, FromPort12, {_, <<"hej">>}} ->
                              ?P("[server] received expected message 1: "
                                 "~n      FromIP2:   ~p"
                                 "~n      FromPort2: ~p"
                                 "~n      => send reply", [FromIP12, FromPort12]),
                              ok = gen_sctp:send(Sock, AssocID1, 1, "hopp")
                      end,


                      ?P("try accept (await 'accept' message)"),
                      AssocID2 =
                          receive
                              {sctp,
                               Sock,
                               FromIP21, FromPort21,
                               {ANC2, #sctp_assoc_change{state            = comm_up,
                                                         error            = 0,
                                                         outbound_streams = OutStreams2,
                                                         inbound_streams  = InStreams2,
                                                         assoc_id         = AID2}}} ->
                                  ?P("[server] received assoc - accepted: "
                                     "~n      FromIP:      ~p"
                                     "~n      FromPort:    ~p"
                                     "~n      ANC:         ~p"
                                     "~n      Out Streams: ~p"
                                     "~n      In Streams:  ~p"
                                     "~n      Assoc ID:    ~p",
                                     [FromIP21, FromPort21, ANC2,
                                      OutStreams2, InStreams2, AID2]),
                                  AID2
                          end,

                      ?P("[server] await message 1"),
                      receive
                          {sctp, Sock, FromIP22, FromPort22, {_, <<"hej">>}} ->
                              ?P("[server] received expected message 1: "
                                 "~n      From IP:   ~p"
                                 "~n      From Port: ~p"
                                 "~n      => send reply", [FromIP22, FromPort22]),
                              ok = gen_sctp:send(Sock, AssocID2, 1, "hopp")
                      end,


                      ?P("[server] await termination command"),
                      receive
                          {die, Self} ->
                              ?P("[server] terminating"),
                              ?CATCH_AND_IGNORE( gen_tcp:close(Sock) ),
                              exit(normal)
                      end
              end,
    ?P("try start server"),
    Server = spawn_link(ServerF),
    ?P("server started - await port "),
    ServerPort = receive
                     {{port, Port}, Server} ->
                         Port;
                     {'EXIT', Server, Reason} ->
                         ?P("server died unexpectedly: "
                            "~n      ~p", [Reason]),
                         exit({unexpected_server_failure, Reason})
                 end,
    ?P("server port received: ~p", [ServerPort]),
    

    ?P("try create client socket 1"),
    {ok, CSock1} = gen_sctp:open([{ifaddr, SockAddr},
                                  {active, true},
                                  binary]),

    ?P("client socket 1: "
       "~n      CSock: ~p"
       "~n      CPort: ~p", [CSock1, inet:port(CSock1)]),

    ?P("try connect client socket 1"),
    ServerSockAddr = SockAddr#{port => ServerPort},
    {COutStreams1, CInStreams1, CAssocID1} =
        case gen_sctp:connect(CSock1, ServerSockAddr, [], ?SECS(1)) of
            {ok, #sctp_assoc_change{state            = comm_up,
                                    error            = 0,
                                    outbound_streams = COS1,
                                    inbound_streams  = CIS1,
                                    assoc_id         = CAID1}} ->
                {COS1, CIS1, CAID1};
            {ok, Unexpected1} ->
                ?P("<ERROR> unexpected connect (1) result: "
                   "~n      ~p", [Unexpected1]),
                ct:fail({unexpected_client_connect_result, 1, Unexpected1});
            {error, Reason1} ->
                ?P("<ERROR> failed client 1 connect: "
                   "~n      Reason: ~p", [Reason1]),
                ct:fail({client_connect_failed, 1, Reason1})
        end,

    ?P("client 1 connected: "
       "~n      Out Streams: ~p"
       "~n      In Streams:  ~p"
       "~n      Assoc ID:    ~p", [COutStreams1, CInStreams1, CAssocID1]),

    ?P("[client 1] try send message"),
    ok = gen_sctp:send(CSock1, CAssocID1, 1, "hej"),

    ?P("[client 1] await reply message"),
    receive
        {sctp, CSock1, _, _, {_, <<"hopp">>}} ->
            ?P("received expected reply message")
    end,


    ?P("[client 2] try create client socket"),
    {ok, CSock2} = gen_sctp:open([{ifaddr, SockAddr},
                                  {active, true},
                                  binary]),

    ?P("[client 2] client socket: "
       "~n      CSock: ~p"
       "~n      CPort: ~p", [CSock2, inet:port(CSock2)]),

    ?P("[client 2] try connect-init"),
    ServerSockAddr = SockAddr#{port => ServerPort},
    case gen_sctp:connect_init(CSock2, ServerSockAddr, []) of
        ok ->
            ok;
        {error, Reason2} ->
            ?P("<ERROR> failed client 2 connect: "
               "~n      Reason: ~p", [Reason2]),
            ct:fail({client_connect_failed, 2, Reason2})
    end,

    ?P("[client 2] await connect completion"),
    CAssocID2 =
        receive
            {sctp,
             CSock2,
             CFromIP2, CFromPort2,
             {CANC2, #sctp_assoc_change{state            = comm_up,
                                        error            = 0,
                                        outbound_streams = COutStreams2,
                                        inbound_streams  = CInStreams2,
                                        assoc_id         = CAID2}}} ->
                ?P("[client 2] connected: "
                   "~n      From IP:     ~p"
                   "~n      From Port:   ~p"
                   "~n      ANC:         ~p"
                   "~n      Out Streams: ~p"
                   "~n      In Streams:  ~p"
                   "~n      Assoc ID:    ~p",
                   [CFromIP2, CFromPort2, CANC2,
                    COutStreams2, CInStreams2, CAID2]),
                CAID2
        end,

    ?P("[client 2] try send message"),
    ok = gen_sctp:send(CSock2, CAssocID2, 1, "hej"),

    ?P("[client 2] await reply message"),
    receive
        {sctp, CSock2, _, _, {_, <<"hopp">>}} ->
            ?P("[client 2] received expected reply message")
    end,


    ?P("terminate server"),
    Server ! {die, self()},

    ?P("await server termination"),
    receive
        {'EXIT', Server, normal} ->
            ok
    end,
    
    ?P("cleanup"),
    ?CATCH_AND_IGNORE( gen_sctp:close(CSock1) ),
    ?CATCH_AND_IGNORE( gen_sctp:close(CSock2) ),

    ?P("done"),
    ok.

    
%% Test the sockaddr version of connectx_init/4.
t_simple_local_sockaddr_in_connectx_init(Config) when is_list(Config) ->
    Localhost = {127,0,0,1},
    {ok,Sb} = gen_sctp:open(),
    {ok,Pb} = inet:port(Sb),
    {ok,Sa} = gen_sctp:open(),
    SockAddr = #{family   => inet,
                 addr     => Localhost,
                 port     => Pb},
    case gen_sctp:connectx_init(Sa, [SockAddr], []) of
        {ok, A1} ->
	    true = (A1 =/= 0),
            {Localhost,Pb,#sctp_assoc_change{state=cant_assoc, assoc_id = A1}} =
                recv_event(log_ok(gen_sctp:recv(Sa, infinity))),
            ok = gen_sctp:listen(Sb, true),
            {ok, A2} = gen_sctp:connectx_init(Sa, [SockAddr], []),
	    true = (A2 =/= 0),
            {Localhost,Pb,#sctp_assoc_change{state=comm_up, assoc_id = A2}} =
                recv_event(log_ok(gen_sctp:recv(Sa, infinity))),
            ok = gen_sctp:close(Sa),
            ok = gen_sctp:close(Sb);
        {error, enotsup} ->
            ok
    end,
    ok.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

non_block_send(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() -> case ?WHICH_LOCAL_ADDR(inet) of
                        {ok, Addr} ->
                            Addr;
                        {error, Reason} ->
                            throw({skip, Reason})
                    end
           end,
    TC   = fun(Addr) -> do_non_block_send(Config, Addr) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_non_block_send(_Config, Addr) ->
    {Server, Port} = nbs_server_start(Addr),
    Client         = nbs_client_start(Addr, Port),
    ok = nbs_await_client_blocked(Client),
    nbs_command_continue("server", Server),
    ok = nbs_await_server_recv(Server),
    nbs_command_continue("client", Client),
    nbs_command_continue("server", Server),
    case nbs_await_client_done(Client) of
        ok ->
            nbs_server_stop(Server),
            ok;
        {error, Reason} ->
            nbs_server_stop(Server),
            exit(Reason)
    end.

nbs_command_continue(Who, Pid) ->
    ?P("[ctrl] command ~s continue", [Who]),
    Pid ! {?MODULE, self(), continue}.

nbs_await_server_recv(Server) ->
    ?P("[ctrl] await server recv"),
    receive
        {?MODULE, Server, recv} ->
            ?P("[ctrl] server recv"),
            ok
    end.

nbs_await_client_blocked(Client) ->
    ?P("[ctrl] await client blocked"),
    receive
        {?MODULE, Client, blocked} ->
            ?P("[ctrl] client blocked"),
            ok
    end.

nbs_await_client_done(Client) ->
    ?P("[ctrl] await client done"),
    receive
        {'EXIT', Client, normal} ->
            ?P("[ctrl] client done"),
            ok;
        {'EXIT', Client, Reason} ->
            ?P("[ctrl] client failed: "
               "~n   ~p", [Reason]),
            {error, Reason}
    end.


nbs_server_start(Addr) ->
    Self = self(),
    Pid  = spawn_link(fun() -> nbs_server_init(Self, Addr) end),
    receive
        {?MODULE, Pid, {ok, Port}} when is_integer(Port) ->
            {Pid, Port}
    end.

nbs_server_stop(Server) ->
    ?P("[ctrl] command server stop"),
    Server ! {?MODULE, self(), stop},
    ?P("[ctrl] await server stopped"),
    receive
        {'EXIT', Server, normal} ->
            ?P("[ctrl] server stopped"),
            ok;
        {'EXIT', Server, Reason} ->
            ?P("[ctrl] server failed: "
               "~n   ~p", [Reason]),
            {error, Reason}
    end.

nbs_server_init(Parent, Addr) ->
    ?P("[server] Try create socket"),
    case gen_sctp:open(0, [{recbuf, 16384}, {ip, Addr}, {debug, true}] ) of
        {ok, S} ->
            {ok, [false]} = inet:getopts(S, [non_block_send]),
            {ok, Port} = inet:port(S),
            ?P("[server] Try make listen"),
            ok = gen_sctp:listen(S, true),
            Parent ! {?MODULE, self(), {ok, Port}},
            nbs_server_main(Parent, S);
        {error, Reason} ->
            exit({server, Reason})
    end.

nbs_server_main(Parent, Sock) ->
    ?P("[server] await controller continue command"),
    receive
        {?MODULE, Parent, continue} ->
            ?P("[server] received controller continue command"),
            ok
    end,
    nbs_server_loop(Parent, Sock, true),
    ?P("[server] await controller stop command"),
    receive
        {?MODULE, Parent, stop} ->
            ?P("[server] received controller stop command"),
            gen_sctp:close(Sock)
    end.

nbs_server_loop(Parent, Sock, Retry) ->
    case gen_sctp:recv(Sock, 5000) of
        {ok, {FromIP, FromPort, AncData, Data}} when is_binary(Data) ->
            ?P("[server] received data: "
               "~n   From IP:   ~p"
               "~n   From Port: ~p"
               "~n   Anc Data:  ~p"
               "~n   sz(Data):  ~p",
               [FromIP, FromPort, AncData, byte_size(Data)]),
            nbs_server_loop(Parent, Sock, Retry);
        {ok, {FromIP, FromPort, AncData, Data}} ->
            ?P("[server] received data: "
               "~n   From IP:   ~p"
               "~n   From Port: ~p"
               "~n   Anc Data:  ~p"
               "~n   Data:      ~p",
               [FromIP, FromPort, AncData, Data]),
            nbs_server_loop(Parent, Sock, Retry);
        {error, timeout} when (Retry =:= true) ->
            ?P("[server] receive timeout"),
            Parent ! {?MODULE, self(), recv},
            ?P("[server] await controller contue command"),
            receive
                {?MODULE, Parent, continue} ->
                    ?P("[server] received continue command from controller"),
                    ok
            end,
            nbs_server_loop(Parent, Sock, false);
        {error, timeout} ->
            ?P("[server] receive timeout => done"),
            ok;
        {error, Reason} ->
            exit({server_recv, Reason})
    end.


nbs_client_start(Addr, Port) ->
    Self = self(),
    Pid  = spawn_link(fun() -> nbs_client_init(Self, Addr, Port) end),
    receive
        {?MODULE, Pid, ok} ->
            Pid
    end.

nbs_client_init(Parent, Addr, Port) ->
    OOpts = [{ip, Addr}, {non_block_send, true}],
    ?P("[client] Try create socket"),
    case gen_sctp:open(0, OOpts) of
        {ok, S} ->
            {ok, [true]} = inet:getopts(S, [non_block_send]),
            COpts = [{sctp_initmsg, #sctp_initmsg{num_ostreams = 5}}],
            ?P("[client] Try connect to server"),
            case gen_sctp:connect(S, Addr, Port, COpts) of
                {ok, Assoc} ->
                    ?P("[client] assoc created"),
                    inet:setopts(S, [{debug, true}]),
                    Parent ! {?MODULE, self(), ok},
                    Data =
                        list_to_binary(
                          lists:flatten(
                            lists:duplicate(1024, "HejHoppDuGlade"))),
                    nbs_client_loop(Parent, S, Assoc, 0, 0, Data);
                {error, CReason} ->
                    ?P("[client] failed connect: "
                       "~n   Reason: ~p", [CReason]),
                    gen_sctp:close(S),
                    exit({client_connect, CReason})
            end;
        {error, OReason} ->
            ?P("[client] failed create socket: "
               "~n   Reason: ~p", [OReason]),
            exit({client_open, OReason})
    end.

nbs_client_loop(Parent, S, Assoc, NumWrites, NumBytes, Data) ->
    nbs_client_loop(Parent, S, Assoc, NumWrites, NumBytes, Data, true).

nbs_client_loop(Parent, S, Assoc, NumWrites, NumBytes, Data, true) ->
    ?P("[client,true] try send when"
       "~n   Num Writes: ~p"
       "~n   Num Bytes:  ~p", [NumWrites, NumBytes]),
    %% Should we use all the streams?
    case gen_sctp:send(S, Assoc, 0, Data) of
        ok ->
            nbs_client_loop(Parent, S, Assoc,
                            NumWrites+1,
                            NumBytes + byte_size(Data),
                            Data, true);
        {error, eagain} ->
            ?P("[client] send blocked when"
               "~n   Num Writes: ~p"
               "~n   Num Bytes:  ~p", [NumWrites, NumBytes]),
            Parent ! {?MODULE, self(), blocked},
            ?P("[client] await continue command from controller"),
            receive
                {?MODULE, Parent, continue} ->
                    ?P("[client] received continue command from controller"),
                    ok
            end,
            nbs_client_loop(Parent, S, Assoc,
                            NumWrites,
                            NumBytes,
                            Data, false);
        {error, Reason} ->
            ?P("[client] failed sending message: "
               "~n   Reason: ~p", [Reason]),
            gen_sctp:close(S),
            exit({send_failed, Reason})
    end;
nbs_client_loop(_Parent, S, Assoc, NumWrites, NumBytes, Data, false) ->
    ?P("[client,false] try send when"
       "~n   Num Writes: ~p"
       "~n   Num Bytes:  ~p", [NumWrites, NumBytes]),
    case gen_sctp:send(S, Assoc, 0, Data) of
        ok ->
            ?P("[client] sent final message - final option verification"),
            {ok, [true]} = inet:getopts(S, [non_block_send]),
            ok = inet:setopts(S, [{non_block_send, false}]),
            {ok, [false]} = inet:getopts(S, [non_block_send]),            
            ?P("[client] close socket"),
            gen_sctp:close(S),
            ?P("[client] done"),
            exit(normal);
        {error, Reason} ->
            ?P("[client] failed sending last message: "
               "~n   Reason: ~p", [Reason]),
            gen_sctp:close(S),
            exit({send_failed, Reason})
    end.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

default_options(Config) when is_list(Config) ->
    Cond = fun() -> ok end,
    Pre  = fun() -> case ?WHICH_LOCAL_ADDR(inet) of
                        {ok, Addr} ->
                            Addr;
                        {error, Reason} ->
                            throw({skip, Reason})
                    end
           end,
    TC   = fun(Addr) -> do_default_options(Config, Addr) end,
    Post = fun(_) -> ok end,
    ?TC_TRY(?FUNCTION_NAME, Cond, Pre, TC, Post).

do_default_options(_Config, _Addr) ->
    ?P("*** standard open without any options ***"),
    ok = dos_open([]),
    ?P("*** standard open with updated recbuf option ***"),
    ok = dos_open([{recbuf, 8*1024}]),

    ?P("*** update kernel application env "
       "(inet_default_sctp_options with active and recbuf) ***"),
    application:set_env(kernel, inet_default_sctp_options,
                        [{active, once}, {recbuf, 12*1024}]),

    ?P("*** open without any options ***"),
    ok = dos_open([]),
    ?P("*** open with updated recbuf option ***"),
    ok = dos_open([{recbuf, 8*1024}]),

    ?P("*** update kernel application env "
       "(inet_default_sctp_options with active) ***"),
    application:set_env(kernel, inet_default_sctp_options,
                        [{active, true}]),

    ?P("*** open without any options ***"),
    ok = dos_open([]),
    ?P("*** open with updated recbuf option ***"),
    ok = dos_open([{recbuf, 8*1024}]),

    ?P("done"),
    ok.

%% Allways check the following options:
%%    active, mode, buffer, sndbuf, recbuf
dos_open(OpenOpts) ->    
    ?P("~w -> try open", [?FUNCTION_NAME]),
    case gen_sctp:open(OpenOpts) of
        {ok, Sock} ->
            CheckOpts = [mode, buffer, sndbuf, recbuf],
            ?P("~w -> try get options ~p", [?FUNCTION_NAME, CheckOpts]),
            case inet:getopts(Sock, CheckOpts) of
                {ok, Opts} ->
                    ?P("~w -> try verify when"
                       "~n   (Current) Opts:"
                       "~n      ~p", [?FUNCTION_NAME, Opts]),
                    dos_open_verify_opts(OpenOpts, Opts);
                {error, GReason} ->
                    ?P("~w -> failed get options"
                       "~n   Reason:"
                       "~n      ~p", [?FUNCTION_NAME, GReason]),
                    error
            end;
        {error, OReason} ->
            ?P("~w -> failed open socket"
               "~n   Reason:"
               "~n      ~p", [?FUNCTION_NAME, OReason]),
            error
    end.
                    
dos_open_verify_opts(OpenOpts, Opts) ->
    Defaults = #sctp_opts{},
    dos_open_verify_opts(OpenOpts, Opts,
                         Defaults#sctp_opts.ifaddr,
                         Defaults#sctp_opts.opts).

dos_open_verify_opts(OpenOpts, Opts, DefaultIfAddr, DefaultOpts) ->
    ?P("~w ->"
       "~n   OpenOpts:"
       "~n      ~p"
       "~n   Opts:"
       "~n      ~p"
       "~n   DefaultIfAddr:"
       "~n      ~p"
       "~n   DefaultOpts:"
       "~n      ~p",
       [?FUNCTION_NAME,
        OpenOpts, Opts, DefaultIfAddr, DefaultOpts]),
    dos_open_verify_opts2(OpenOpts, Opts, DefaultIfAddr, DefaultOpts).

dos_open_verify_opts2([], Opts, _DefaultIfAddr, DefaultOpts) ->
    dos_open_verify_rest_opts(Opts, DefaultOpts);
dos_open_verify_opts2([{Key, OpenValue}|OpenOpts], Opts,
                      DefaultIfAddr, DefaultOpts) ->
    case dos_open_verify_opt(Key, OpenValue, Opts) of
        ok ->
            Opts2 = lists:keydelete(Key, 1, Opts),
            dos_open_verify_opts2(OpenOpts, Opts2,
                                  DefaultIfAddr, DefaultOpts);
        {error, _} = ERROR ->
            ERROR
    end.

dos_open_verify_opt(Key, OpenValue, Opts)
  when (Key =:= buffer) orelse
       (Key =:= sndbuf) orelse
       (Key =:= recbuf) ->
    case lists:keysearch(Key, 1, Opts) of
        {value, {Key, Value}} when (Value >= OpenValue) ->
            ?P("~w -> ~w verified (~w >= ~w)",
               [?FUNCTION_NAME, Key, Value, OpenValue]),
            ok;
        {value, {Key, Value}} ->
            ?P("~w -> ~w *not* verified: ~w not >= ~w",
               [?FUNCTION_NAME, Key, Value, OpenValue]),
            {error, {invalid_value, {Key, Value, OpenValue}}};
        false ->
            ?P("~w -> ~w not found", [?FUNCTION_NAME, Key]),
            {error, {not_found, Key}}
    end;
dos_open_verify_opt(Key, OpenValue, Opts) ->
    case lists:keysearch(Key, 1, Opts) of
        {value, {Key, Value}} when (Value =:= OpenValue) ->
            ?P("~w -> ~w verified (~w =:= ~w)",
               [?FUNCTION_NAME, Key, Value, OpenValue]),
            ok;
        {value, {Key, Value}} ->
            ?P("~w -> ~w *not* verified: ~w =/= ~w",
               [?FUNCTION_NAME, Key, Value, OpenValue]),
            {error, {invalid_value, {Key, Value, OpenValue}}};
        false ->
            ?P("~w -> ~w not found", [?FUNCTION_NAME, Key]),
            {error, {not_found, Key}}
    end.

dos_open_verify_rest_opts(Opts, DefaultOpts) ->
    ?P("~w ->"
       "~n   Opts:"
       "~n      ~p"
       "~n   DefaultOpts:"
       "~n      ~p",
       [?FUNCTION_NAME,
        Opts, DefaultOpts]),
    dos_open_verify_rest_opts2(Opts, DefaultOpts).

dos_open_verify_rest_opts2([], _DefaultOpts) ->
    ok;
dos_open_verify_rest_opts2([{Key, Value}|Opts], DefaultOpts) ->
    case dos_open_verify_rest_opt(Key, Value, DefaultOpts) of
        ok ->
            dos_open_verify_rest_opts2(Opts, DefaultOpts);
        {error, _} = ERROR ->
            ERROR
    end.

dos_open_verify_rest_opt(Key, Value, DefaultOpts)
  when (Key =:= buffer) orelse
       (Key =:= sndbuf) orelse
       (Key =:= recbuf) ->
    case lists:keysearch(Key, 1, DefaultOpts) of
        {value, {Key, DefaultValue}} when (Value >= DefaultValue) ->
            ?P("~w -> ~w verified (~w >= (default) ~w)",
               [?FUNCTION_NAME, Key, Value, DefaultValue]),
            ok;
        {value, {Key, DefaultValue}} ->
            ?P("~w -> ~w *not* verified: ~w not >= (default) ~w",
               [?FUNCTION_NAME, Key, Value, DefaultValue]),
            {error, {invalid_value, {Key, Value, DefaultValue}}};
        false ->
            ?P("~w -> no default value for ~w - ignore", [?FUNCTION_NAME, Key]),
            ok
    end;
dos_open_verify_rest_opt(Key, Value, DefaultOpts) ->
    case lists:keysearch(Key, 1, DefaultOpts) of
        {value, {Key, DefaultValue}} when (Value =:= DefaultValue) ->
            ?P("~w -> ~w verified (~w =:= (default) ~w)",
               [?FUNCTION_NAME, Key, Value, DefaultValue]),
            ok;
        {value, {Key, DefaultValue}} ->
            ?P("~w -> ~w *not* verified: ~w =/= (default) ~w",
               [?FUNCTION_NAME, Key, Value, DefaultValue]),
            {error, {invalid_value, {Key, Value, DefaultValue}}};
        false -> % No default value for this is ok
            ?P("~w -> no default value for ~w - ignore", [?FUNCTION_NAME, Key]),
            ok
    end.

            



%% dos_opt_value(Key, Opts) ->
%%     proplists:get_value(Key, Opts, undefined).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

socket_pair_open(Addr, StartTime, Timeout) ->
    S1 = socket_open([{ip,Addr}], Timeout),
    ?LOGVAR(S1),
    P1 = socket_call(S1, get_port),
    ?LOGVAR(P1),
    ok = socket_call(S1, {listen,true}),
    S2 = socket_open([{ip,Addr}], Timeout),
    ?LOGVAR(S2),
    P2 = socket_call(S2, get_port),
    ?LOGVAR(P2),
    %%
    socket_call(S2, {connect_init,Addr,P1,[]}),
    S2Ai =
	receive
	    {S2,{Addr,P1,
		 #sctp_assoc_change{
		    state=comm_up,
		    assoc_id=S2AssocId}}} -> S2AssocId
	after Timeout ->
		socket_bailout([S1,S2], StartTime)
	end,
    S1Ai =
	receive
	    {S1,{Addr,P2,
		 #sctp_assoc_change{
		    state=comm_up,
		    assoc_id=S1AssocId}}} -> S1AssocId
	after Timeout ->
		socket_bailout([S1,S2], StartTime)
	end,
    {{S1,P1,S1Ai}, {S2,P2,S2Ai}}.

socket_pair_close(Addr, StartTime, Timeout, {{S1,P1,_S1Ai}, {S2,_P2,S2Ai}}) ->
    socket_close_verbose(S1, StartTime),
    receive
	{S2,{Addr,P1,#sctp_shutdown_event{assoc_id=S2Ai}}} -> ok
    after Timeout ->
	    socket_bailout([S2], StartTime)
    end,
    receive
	{S2,{Addr,P1,#sctp_assoc_change{state=shutdown_comp,
					assoc_id=S2Ai}}} -> ok
    after Timeout ->
	    socket_bailout([S2], StartTime)
    end,
    socket_close_verbose(S2, StartTime),
    [] = flush(),
    ok.

%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% socket gen_server ultra light

socket_open(SockOpts0, Timeout) ->
    SockOpts =
	case lists:keyfind(active,1,SockOpts0) of
	    false ->
		[{active,once}|SockOpts0];
	    _ ->
		SockOpts0
	end,
    Opts = [{type,seqpacket},binary|SockOpts],
    Starter =
	fun () ->
		{ok,Socket} =
		    gen_sctp:open(Opts),
		Socket
	end,
    s_start(Starter, Timeout).

socket_peeloff(Socket, AssocId, SocketOpts, Timeout) ->
    Opts = [binary|SocketOpts],
    Starter =
	fun () ->
		{ok,NewSocket} =
		    gen_sctp:peeloff(Socket, AssocId),
		ok = inet:setopts(NewSocket, Opts),
		NewSocket
	end,
    s_start(Starter, Timeout).

socket_close_verbose(S, StartTime) ->
    History = socket_history(socket_close(S), StartTime),
    io:format("socket_close ~p:~n    ~p.~n", [S,History]),
    History.

socket_close(S) ->
    s_req(S, close).

socket_controlling_process(S, Pid) when is_pid(Pid) ->
    s_req(S, {controlling_process, Pid}).

socket_call(S, Request) ->
    s_req(S, {Request}).

%% socket_get(S, Key) ->
%%     s_req(S, {get,Key}).

socket_bailout([S|Ss], StartTime) ->
    History = socket_history(socket_close(S), StartTime),
    io:format("bailout ~p:~n    ~p.~n", [S,History]),
    socket_bailout(Ss, StartTime);
socket_bailout([], _) ->
    io:format("flush: ~p.~n", [flush()]),
    try throw(socket_bailout)
    catch throw : Reason : Stacktrace ->
            io:format("Stacktrace:~n    ~p.~n", [Stacktrace]),
            ct:fail(Reason)
    end, ok.

socket_history({State,Flush}, StartTime) ->
    {lists:keysort(
       2,
       lists:flatten(
	 [[{Key,{TS-StartTime,Val}} || {TS,Val} <- Vals]
	  || {Key,Vals} <- gb_trees:to_list(State)])),
     Flush}.

s_req(S, Req) ->
    AMref = erlang:monitor(process, S, [{alias, reply_demonitor}]),
    S ! {?MODULE, AMref, Req},
    receive
        {'DOWN', AMref, _, _, Error} ->
            exit(Error);
        {?MODULE, AMref, Reply} ->
            Reply
    end.

s_handle_req(Socket, Req) ->
    case Req of
        {listen,Listen} ->
	    ok = gen_sctp:listen(Socket, Listen);
	get_port ->
	    ok(inet:port(Socket));
	get_socket ->
	    Socket;
	{connect_init,ConAddr,ConPort,ConOpts} ->
	    ok = gen_sctp:connect_init(Socket, ConAddr, ConPort, ConOpts);
	{send,AssocId,Stream,Data} ->
	    ok = gen_sctp:send(Socket, AssocId, Stream, Data);
	{send,OtherSocket,AssocId,Stream,Data} ->
	    ok = gen_sctp:send(OtherSocket, AssocId, Stream, Data);
	{setopts,Opts} ->
	    ok = inet:setopts(Socket, Opts);
	{getopts,Optnames} ->
	    ok(inet:getopts(Socket, Optnames))
    end.

s_start(Starter, Timeout) ->
    Parent = self(),
    spawn_link(
      fun () ->
              try
                  Socket = Starter(),
                  s_loop(Socket, Timeout, Parent, gb_trees:empty())
              catch
                  Class:Reason:Stacktrace ->
                      io:format(?MODULE_STRING":socket exception ~w:~w at~n"
                                "~p.~n", [Class,Reason,Stacktrace]),
                      erlang:raise(Class, Reason, Stacktrace)
              end
      end).

s_loop(Socket, Timeout, Parent, State) ->
    receive
	{?MODULE,AMref,{controlling_process, NewParent}} ->
            ?P("received (new) controlling process: "
               "~n   ~p", [NewParent]),
	    AMref ! {?MODULE,AMref,ok},
	    s_loop(Socket, Timeout, NewParent, State);
	{?MODULE,AMref,close} -> % socket_close()
            ?P("received close"),
	    erlang:send_after(Timeout, self(), {?MODULE,AMref,exit}),
	    s_loop(Socket, Timeout, Parent, State);
	{?MODULE,AMref,exit} ->
            ?P("received exit"),
	    ok = gen_sctp:close(Socket),
	    NewState = gb_push(exit, Socket, State),
	    AMref ! {?MODULE,AMref,{NewState,flush()}};
	{?MODULE,AMref,{Req}} ->
            ?P("received request: "
               "~n   ~p", [Req]),
            Result = s_handle_req(Socket, Req),
	    NewState = gb_push(req, {Req,Result}, State),
	    AMref ! {?MODULE, AMref,Result},
	    s_loop(Socket, Timeout, Parent, NewState);
	%% {Parent,AMref,{get,Key}} ->
	%%     AMref ! {?MODULE,AMref,gb_get(Key, State)},
	%%     s_loop(Socket, Timeout, Parent, State);
	{sctp,Socket,Addr,Port,
	 {[#sctp_sndrcvinfo{stream=Stream,assoc_id=AssocId}=SRI],Data}}
	  when not is_tuple(Data) ->
            ?P("received [sctp] snd/rcv info: "
               "~n   Stream:  ~p"
               "~n   AssocId: ~p", [Stream, AssocId]),
	    case gb_get({assoc_change,AssocId}, State) of
		[{Addr,Port,
		  #sctp_assoc_change{
		     state=comm_up,
		     inbound_streams=Is}}|_]
		  when 0 =< Stream, Stream < Is-> ok;
		[] -> ok
	    end,
	    Key = {msg,AssocId,Stream},
	    NewState = gb_push(Key, {Addr,Port,SRI,Data}, State),
	    Parent ! {self(),{Addr,Port,AssocId,Stream,Data}},
	    again(Socket),
	    s_loop(Socket, Timeout, Parent, NewState);
	{sctp,Socket,Addr,Port,
	 {SRI,#sctp_assoc_change{assoc_id=AssocId,state=St}=SAC}} ->
            ?P("received [sctp] assoc change: "
               "~n   AssocId: ~p"
               "~n   St:      ~p"
               "~n   SRI:     ~p", [AssocId, St, SRI]),
	    case SRI of
		[#sctp_sndrcvinfo{assoc_id=AssocId,stream=0}] -> ok;
		[] -> ok
	    end,
	    Key = {assoc_change,AssocId},
	    case {gb_get(Key, State),St} of
		{[],_} -> ok;
		{[{Addr,Port,#sctp_assoc_change{state=comm_up}}|_],_}
		  when St =:= comm_lost; St =:= shutdown_comp -> ok
	    end,
	    NewState = gb_push(Key, {Addr,Port,SAC}, State),
	    Parent ! {self(),{Addr,Port,SAC}},
	    again(Socket),
	    s_loop(Socket, Timeout, Parent, NewState);
	{sctp,Socket,Addr,Port,
	 {SRI,#sctp_paddr_change{assoc_id=AssocId,
				 addr={_,P},
				 state=St}=SPC}} ->
            ?P("received [sctp] paddr change: "
               "~n   AssocId: ~p"
               "~n   P:       ~p"
               "~n   St:      ~p", [AssocId, P, St]),
	    match_unless_solaris(Port, P),
	    case SRI of
		[#sctp_sndrcvinfo{assoc_id=AssocId,stream=0}] -> ok;
		[] -> ok
	    end,
	    case {gb_get({assoc_change,AssocId}, State),St} of
		{[{Addr,Port,#sctp_assoc_change{state=comm_up}}|_],_}
		  when St =:= addr_available;
		       St =:= addr_confirmed -> ok;
		{[],addr_confirmed} -> ok
	    end,
	    Key = {paddr_change,AssocId},
	    NewState = gb_push(Key, {Addr,Port,SPC}, State),
	    again(Socket),
	    s_loop(Socket, Timeout, Parent, NewState);
	{sctp,Socket,Addr,Port,
	 {SRI,#sctp_shutdown_event{assoc_id=AssocId}=SSE}} ->
            ?P("received [sctp] shutdown event: "
               "~n   AssocId: ~p"
               "~n   SRI:     ~p", [AssocId, SRI]),
	    case SRI of
		[#sctp_sndrcvinfo{assoc_id=AssocId,stream=0}] -> ok;
		[] -> ok
	    end,
	    case gb_get({assoc_change,AssocId}, State) of
		[{Addr,Port,#sctp_assoc_change{state=comm_up}}|_] -> ok;
		[] -> ok
	    end,
	    Key = {shutdown_event,AssocId},
	    NewState = gb_push(Key, {Addr,Port}, State),
	    Parent ! {self(), {Addr,Port,SSE}},
	    again(Socket),
	    s_loop(Socket, Timeout, Parent, NewState);
	Unexpected ->
            ?P("received unexpected message: "
               "~n                ~p"
               "~nwhen"
               "~n   Socket Info: ~p",
               [Unexpected, inet:info(Socket)]),
	    erlang:error({unexpected,Unexpected})
    end.

again(Socket) ->
    receive
	{sctp_passive,Socket} ->
	    [{active, false}] = ok(inet:getopts(Socket, [active])),
	    ok = inet:setopts(Socket,[{active,1}])
    after 0 ->
	    ok = inet:setopts(Socket, [{active,once}])
    end.

gb_push(Key, Val, GBT) ->
    TS = timestamp(),
    case gb_trees:lookup(Key, GBT) of
	none ->
	    gb_trees:insert(Key, [{TS,Val}], GBT);
	{value,V} ->
	    gb_trees:update(Key, [{TS,Val}|V], GBT)
    end.

gb_get(Key, GBT) ->
    case gb_trees:lookup(Key, GBT) of
	none ->
	    [];
	{value,V} ->
	    [Val || {_TS,Val} <- V]
    end.

match_unless_solaris(A, B) ->
    case os:type() of
	{unix,sunos} -> B;
	_ -> A = B
    end.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


is_net_supported() ->
    try net:info() of
        #{} ->
            ok
    catch
        error : notsup ->
            not_supported(net)
    end.


is_not_freebsd() ->
    is_not_platform(freebsd, "FreeBSD").

is_not_platform(Platform, PlatformStr)
  when is_atom(Platform) andalso is_list(PlatformStr) ->
      case os:type() of
        {unix, Platform} ->
            skip("This does not work on " ++ PlatformStr);
        _ ->
            ok
    end.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

timestamp() ->
    erlang:monotonic_time().


pi(Item) ->
    {Item, Val} = process_info(self(), Item),
    Val.
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

not_supported(What) ->
    skip({not_supported, What}).

skip(Reason) ->
    throw({skip, Reason}).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

log_ok(X) ->
    log(ok(X)).

ok({ok, X}) ->
    X;
ok({error, X}) ->
    ?P("ERROR: ~p", [X]),
    ct:fail({unexpected_error, X});
ok(X) ->
    ?P("UNEXPECTED: ~p", [X]),
    ct:fail({unexpected, X}).
    

log(X) ->
    ?P("LOG: ~p", [X]),
    X.

err([], Result) ->
    erlang:error(Result);
err([Reason|_], {error,Reason}) ->
    ok;
err([_|Reasons], Result) ->
    err(Reasons, Result).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

open_failed_str(Reason) ->
    ?F("Open failed: ~w", [Reason]).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

is_sctp_supported() ->
    case os:type() of
        {unix, netbsd} ->
            %% SCTP is "fishy" on (our) NetBSD, so skip just to
            %% avoid fatal crashes...
            {skip, "SCTP \"fishy\" on NetBSD"};
        _ ->
            case gen_sctp:open() of
                {ok, Socket} ->
                    gen_sctp:close(Socket),
                    ok;
                {error, Reason}
                  when (Reason =:= eprotonosupport) orelse
                       (Reason =:= esocktnosupport) ->
                    {skip, "SCTP not supported on this machine"}
            end
    end.
