import unittest
from test import audiotests
from test import support
from test.support.os_helper import FakePath, unlink
import io
import os
import struct
import tempfile
import sys
import wave


class WaveTest(audiotests.AudioWriteTests,
               audiotests.AudioTestsWithSourceFile):
    module = wave


class WavePCM8Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm8.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 1
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_PCM
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      827F CB80 B184 0088 4B86 C883 3F81 837E 387A 3473 A96B 9A66 \
      6D64 4662 8E60 6F60 D762 7B68 936F 5877 177B 757C 887B 5F7B \
      917A BE7B 3C7C E67F 4F84 C389 418E D192 6E97 0296 FF94 0092 \
      C98E D28D 6F8F 4E8F 648C E38A 888A AB8B D18E 0B91 368E C48A \
      """)


class WavePCM16Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm16.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 2
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_PCM
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022EFFEA 4B5C00F9 311404EF 80DC0843 CBDF06B2 48AA03F3 BFE701B2 036BFE7C \
      B857FA3E B4B2F34F 2999EBCA 1A5FE6D7 EDFCE491 C626E279 0E05E0B8 EF27E02D \
      5754E275 FB31E843 1373EF89 D827F72C 978BFB7A F5F7FC11 0866FB9C DF30FB42 \
      117FFA36 3EE4FB5D BC75FCB6 66D5FF5F CF16040E 43220978 C1BC0EC8 511F12A4 \
      EEDF1755 82061666 7FFF1446 80001296 499C0EB2 52BA0DB9 EFB70F5C CE400FBC \
      E4B50CEB 63440A5A 08CA0A1F 2BBA0B0B 51460E47 8BCB113C B6F50EEA 44150A59 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 2)


class WavePCM24Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm24.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 3
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_PCM
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65FFEB9D 4B5A0F00FA54 3113C304EE2B 80DCD6084303 \
      CBDEC006B261 48A99803F2F8 BFE82401B07D 036BFBFE7B5D \
      B85756FA3EC9 B4B055F3502B 299830EBCB62 1A5CA7E6D99A \
      EDFA3EE491BD C625EBE27884 0E05A9E0B6CF EF2929E02922 \
      5758D8E27067 FB3557E83E16 1377BFEF8402 D82C5BF7272A \
      978F16FB7745 F5F865FC1013 086635FB9C4E DF30FCFB40EE \
      117FE0FA3438 3EE6B8FB5AC3 BC77A3FCB2F4 66D6DAFF5F32 \
      CF13B9041275 431D69097A8C C1BB600EC74E 5120B912A2BA \
      EEDF641754C0 8207001664B7 7FFFFF14453F 8000001294E6 \
      499C1B0EB3B2 52B73E0DBCA0 EFB2B20F5FD8 CE3CDB0FBE12 \
      E4B49C0CEA2D 6344A80A5A7C 08C8FE0A1FFE 2BB9860B0A0E \
      51486F0E44E1 8BCC64113B05 B6F4EC0EEB36 4413170A5B48 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 3)


class WavePCM24ExtTest(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm24-ext.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 3
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_EXTENSIBLE
    readonly = True  # Writing EXTENSIBLE wave format is not supported.
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65FFEB9D 4B5A0F00FA54 3113C304EE2B 80DCD6084303 \
      CBDEC006B261 48A99803F2F8 BFE82401B07D 036BFBFE7B5D \
      B85756FA3EC9 B4B055F3502B 299830EBCB62 1A5CA7E6D99A \
      EDFA3EE491BD C625EBE27884 0E05A9E0B6CF EF2929E02922 \
      5758D8E27067 FB3557E83E16 1377BFEF8402 D82C5BF7272A \
      978F16FB7745 F5F865FC1013 086635FB9C4E DF30FCFB40EE \
      117FE0FA3438 3EE6B8FB5AC3 BC77A3FCB2F4 66D6DAFF5F32 \
      CF13B9041275 431D69097A8C C1BB600EC74E 5120B912A2BA \
      EEDF641754C0 8207001664B7 7FFFFF14453F 8000001294E6 \
      499C1B0EB3B2 52B73E0DBCA0 EFB2B20F5FD8 CE3CDB0FBE12 \
      E4B49C0CEA2D 6344A80A5A7C 08C8FE0A1FFE 2BB9860B0A0E \
      51486F0E44E1 8BCC64113B05 B6F4EC0EEB36 4413170A5B48 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 3)


class WavePCM32Test(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-pcm32.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 4
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_PCM
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      022D65BCFFEB9D92 4B5A0F8000FA549C 3113C34004EE2BC0 80DCD680084303E0 \
      CBDEC0C006B26140 48A9980003F2F8FC BFE8248001B07D92 036BFB60FE7B5D34 \
      B8575600FA3EC920 B4B05500F3502BC0 29983000EBCB6240 1A5CA7A0E6D99A60 \
      EDFA3E80E491BD40 C625EB80E27884A0 0E05A9A0E0B6CFE0 EF292940E0292280 \
      5758D800E2706700 FB3557D8E83E1640 1377BF00EF840280 D82C5B80F7272A80 \
      978F1600FB774560 F5F86510FC101364 086635A0FB9C4E20 DF30FC40FB40EE28 \
      117FE0A0FA3438B0 3EE6B840FB5AC3F0 BC77A380FCB2F454 66D6DA80FF5F32B4 \
      CF13B980041275B0 431D6980097A8C00 C1BB60000EC74E00 5120B98012A2BAA0 \
      EEDF64C01754C060 820700001664B780 7FFFFFFF14453F40 800000001294E6E0 \
      499C1B000EB3B270 52B73E000DBCA020 EFB2B2E00F5FD880 CE3CDB400FBE1270 \
      E4B49CC00CEA2D90 6344A8800A5A7CA0 08C8FE800A1FFEE0 2BB986C00B0A0E00 \
      51486F800E44E190 8BCC6480113B0580 B6F4EC000EEB3630 441317800A5B48A0 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 4)


class WaveIeeeFloatingPointTest(WaveTest, unittest.TestCase):
    sndfilename = 'pluck-float32.wav'
    sndfilenframes = 3307
    nchannels = 2
    sampwidth = 4
    framerate = 11025
    nframes = 48
    format = wave.WAVE_FORMAT_IEEE_FLOAT
    comptype = 'NONE'
    compname = 'not compressed'
    frames = bytes.fromhex("""\
      3C8B5960BA231400 3F16B41F3BFA5480 3EC44F0E3D1DC580 BF7E46533D843040 \
      BED084FC3D564C30 3F1153303CFCBE40 BF002FB73C583EC0 3CDAFEE0BC425180 \
      BF0F5154BD3826E0 BF169F56BDCAFD40 3EA660C0BE21A4EC 3E52E53CBE49332C \
      BE102E0CBE5B7214 BEE76852BE6C3BDC 3DE05A98BE7A4980 BE06B6B4BE7EB6EC \
      3F2EB1B0BE6C7CC8 BD195500BE3E0F4C 3E1BBDF8BE03DFEC BE9F4E92BD8D8D58 \
      BF50E1D4BD111750 BDA079B0BCFBFB20 3D866358BD0C7640 BE833C0EBD17E240 \
      3E0BFF04BD3978F0 3EFB9AE2BD14A780 BF0710B9BCD342E0 3F4DADB5BBA0CD80 \
      BEC3B11A3D024EB0 3F063AD33D97A8C0 BEF912803DEC74E0 3F2241733E1515D4 \
      BE0904D83E3AA604 BF7BF2003E3325BC 3F8000003E2229FC BF8000003E14A738 \
      3F1338363DEB3B28 3F256E7C3DDBCA00 BE026A683DF5FD88 BEC70C923DFBE128 \
      BE5A5B183DCEA2D8 3F4689513DA5A7C8 3D8C8FE83DA1FFF0 3EAEE61C3DB0A0E0 \
      3F2290DF3DE44E18 BF6867373E09D82C BF1216283DEEB360 3F08262F3DA5B488 \
      """)
    if sys.byteorder != 'big':
        frames = wave._byteswap(frames, 4)

class MiscTestCase(unittest.TestCase):
    def test__all__(self):
        not_exported = {'KSDATAFORMAT_SUBTYPE_PCM'}
        support.check__all__(self, wave, not_exported=not_exported)

    def test_getfp(self):
        fp = io.BytesIO()
        with wave.open(fp, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(1)
            w.setframerate(11025)
        fp.seek(0)
        with wave.open(fp) as r:
            chunk = r.getfp()
            self.assertIsNotNone(chunk)
            self.assertIs(chunk.file, fp)
            self.assertEqual(chunk.chunkname, b'RIFF')


class WaveLowLevelTest(unittest.TestCase):

    def test_setparams_6_tuple_defaults_to_pcm(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)
            w.setparams((1, 2, 22050, 0, 'NONE', 'not compressed'))
            self.assertEqual(w.getformat(), wave.WAVE_FORMAT_PCM)

    def test_setparams_7_tuple_uses_format(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setparams((1, 4, 22050, 0, 'NONE', 'not compressed',
                         wave.WAVE_FORMAT_IEEE_FLOAT))
            self.assertEqual(w.getformat(), wave.WAVE_FORMAT_IEEE_FLOAT)

    def test_setparams_7_tuple_ieee_64bit_sampwidth(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setparams((1, 8, 22050, 0, 'NONE', 'not compressed',
                         wave.WAVE_FORMAT_IEEE_FLOAT))
            self.assertEqual(w.getformat(), wave.WAVE_FORMAT_IEEE_FLOAT)
            self.assertEqual(w.getsampwidth(), 8)

    def test_getparams_backward_compatible_shape(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setparams((1, 4, 22050, 0, 'NONE', 'not compressed',
                         wave.WAVE_FORMAT_IEEE_FLOAT))
            params = w.getparams()
            self.assertEqual(params, (1, 4, 22050, 0, 'NONE', 'not compressed'))

    def test_getformat_setformat(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(4)
            w.setframerate(22050)
            self.assertEqual(w.getformat(), wave.WAVE_FORMAT_PCM)
            w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)
            self.assertEqual(w.getformat(), wave.WAVE_FORMAT_IEEE_FLOAT)

    def test_setformat_ieee_requires_32_or_64_bit_sampwidth(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(22050)
            with self.assertRaisesRegex(wave.Error,
                                        'unsupported sample width for IEEE float format'):
                w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)

    def test_setsampwidth_ieee_requires_32_or_64_bit(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setframerate(22050)
            w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)
            with self.assertRaisesRegex(wave.Error,
                                        'unsupported sample width for IEEE float format'):
                w.setsampwidth(2)
            w.setsampwidth(4)

    def test_setsampwidth_ieee_accepts_64_bit(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setframerate(22050)
            w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)
            w.setsampwidth(8)
            self.assertEqual(w.getsampwidth(), 8)

    def test_read_getformat(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 1, 11025, 11025, 1, 8)
        b += b'data' + struct.pack('<L', 0)
        with wave.open(io.BytesIO(b), 'rb') as r:
            self.assertEqual(r.getformat(), wave.WAVE_FORMAT_PCM)

    def test_read_no_chunks(self):
        b = b'SPAM'
        with self.assertRaises(EOFError):
            wave.open(io.BytesIO(b))

    def test_read_no_riff_chunk(self):
        b = b'SPAM' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error,
                                    'file does not start with RIFF id'):
            wave.open(io.BytesIO(b))

    def test_read_not_wave(self):
        b = b'RIFF' + struct.pack('<L', 4) + b'SPAM'
        with self.assertRaisesRegex(wave.Error,
                                    'not a WAVE file'):
            wave.open(io.BytesIO(b))

    def test_read_no_fmt_no_data_chunk(self):
        b = b'RIFF' + struct.pack('<L', 4) + b'WAVE'
        with self.assertRaisesRegex(wave.Error,
                                    'fmt chunk and/or data chunk missing'):
            wave.open(io.BytesIO(b))

    def test_read_no_data_chunk(self):
        b = b'RIFF' + struct.pack('<L', 28) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 1, 11025, 11025, 1, 8)
        with self.assertRaisesRegex(wave.Error,
                                    'fmt chunk and/or data chunk missing'):
            wave.open(io.BytesIO(b))

    def test_read_no_fmt_chunk(self):
        b = b'RIFF' + struct.pack('<L', 12) + b'WAVE'
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'data chunk before fmt chunk'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_form(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 2, 1, 11025, 11025, 1, 1)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'unknown format: 2'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_number_of_channels(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 0, 11025, 11025, 1, 8)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'bad # of channels'):
            wave.open(io.BytesIO(b))

    def test_read_wrong_sample_width(self):
        b = b'RIFF' + struct.pack('<L', 36) + b'WAVE'
        b += b'fmt ' + struct.pack('<LHHLLHH', 16, 1, 1, 11025, 11025, 1, 0)
        b += b'data' + struct.pack('<L', 0)
        with self.assertRaisesRegex(wave.Error, 'bad sample width'):
            wave.open(io.BytesIO(b))

    def test_open_in_write_raises(self):
        # gh-136523: Wave_write.__del__ should not throw
        with support.catch_unraisable_exception() as cm:
            with self.assertRaises(OSError):
                wave.open(os.curdir, "wb")
            support.gc_collect()
            self.assertIsNone(cm.unraisable)

    def test_ieee_float_has_fact_chunk(self):
        nframes = 100
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(4)
            w.setframerate(22050)
            w.setformat(wave.WAVE_FORMAT_IEEE_FLOAT)
            w.writeframes(b'\x00\x00\x00\x00' * nframes)

        with open(filename, 'rb') as f:
            f.read(12)
            fact_found = False
            fact_samples = None
            while True:
                chunk_id = f.read(4)
                if len(chunk_id) < 4:
                    break
                chunk_size = struct.unpack('<L', f.read(4))[0]
                if chunk_id == b'fact':
                    fact_found = True
                    fact_samples = struct.unpack('<L', f.read(4))[0]
                    break
                f.seek(chunk_size + (chunk_size & 1), 1)

        self.assertTrue(fact_found)
        self.assertEqual(fact_samples, nframes)

    def test_pcm_has_no_fact_chunk(self):
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            filename = fp.name
        self.addCleanup(unlink, filename)

        with wave.open(filename, 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(22050)
            w.writeframes(b'\x00\x00' * 100)

        with open(filename, 'rb') as f:
            f.read(12)
            while True:
                chunk_id = f.read(4)
                if len(chunk_id) < 4:
                    break
                chunk_size = struct.unpack('<L', f.read(4))[0]
                self.assertNotEqual(chunk_id, b'fact')
                f.seek(chunk_size + (chunk_size & 1), 1)

    @support.subTests('arg', (
        # rounds to 0, should raise:
        0.5,
        0.4,
        # Negative values should still raise:
        -1,
        -0.5,
        -0.4,
        # 0 should raise:
        0,
    ))
    def test_setframerate_validates_rounded_values(self, arg):
        """Test that setframerate that round to 0 or negative are rejected"""
        with wave.open(io.BytesIO(), 'wb') as f:
            f.setnchannels(1)
            f.setsampwidth(2)
            with self.assertRaises(wave.Error):
                f.setframerate(arg)
            with self.assertRaises(wave.Error):
                f.close()

    @support.subTests(('arg', 'expected'), (
        (1.4, 1),
        (1.5, 2),
        (1.6, 2),
        (44100.4, 44100),
        (44100.5, 44100),
        (44100.6, 44101),
    ))
    def test_setframerate_rounds(self, arg, expected):
        """Test that setframerate is rounded"""
        with wave.open(io.BytesIO(), 'wb') as f:
            f.setnchannels(1)
            f.setsampwidth(2)
            f.setframerate(arg)
            self.assertEqual(f.getframerate(), expected)

    def test_write_odd_data_chunk_pads_and_updates_riff_size(self):
        # gh-117716: odd-sized data chunks must be padded with one zero byte.
        with io.BytesIO() as output:
            with wave.open(output, mode='wb') as w:
                w.setnchannels(1)
                w.setsampwidth(1)
                w.setframerate(48000)
                w.writeframes(b'\x80')

            value = output.getvalue()

        self.assertEqual(value[-1], 0)
        self.assertEqual(
            int.from_bytes(value[4:8], byteorder='little'),
            38,
        )

        with wave.open(io.BytesIO(value), mode='rb') as r:
            self.assertEqual(r.getnchannels(), 1)
            self.assertEqual(r.getsampwidth(), 1)
            self.assertEqual(r.getframerate(), 48000)
            self.assertEqual(r.getnframes(), 1)
            self.assertEqual(r.readframes(-1), b'\x80')


class WaveOpen(unittest.TestCase):
    def test_open_pathlike(self):
        """It is possible to use `wave.read` and `wave.write` with a path-like object"""
        with tempfile.NamedTemporaryFile(delete_on_close=False) as fp:
            cases = (
                FakePath(fp.name),
                FakePath(os.fsencode(fp.name)),
                os.fsencode(fp.name),
                )
            for fake_path in cases:
                with self.subTest(fake_path):
                    with wave.open(fake_path, 'wb') as f:
                        f.setnchannels(1)
                        f.setsampwidth(2)
                        f.setframerate(44100)

                    with wave.open(fake_path, 'rb') as f:
                        pass

    def test_open_invalid_mode(self):
        with self.assertRaisesRegex(wave.Error, "mode must be"):
            wave.open(io.BytesIO(), 'xb')


class WaveReadErrorTest(unittest.TestCase):
    """Cover error and edge paths of Wave_read, and wave.open()."""

    FMT_PCM = struct.pack('<HHLLHH', wave.WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8)

    @staticmethod
    def _wave_file(*chunks):
        """Build in-memory WAVE bytes from (name, payload) chunks.

        Each chunk stores its real payload length and is padded to an even
        number of bytes, and the RIFF size is computed to match.
        """
        body = b'WAVE'
        for name, payload in chunks:
            body += name + struct.pack('<L', len(payload)) + payload
            if len(payload) & 1:
                body += b'\x00'
        return b'RIFF' + struct.pack('<L', len(body)) + body

    def test_read_unknown_extensible_subformat(self):
        # A WAVE_FORMAT_EXTENSIBLE fmt chunk whose SubFormat GUID is not
        # KSDATAFORMAT_SUBTYPE_PCM must be rejected.
        fmt = struct.pack('<HHLLH', wave.WAVE_FORMAT_EXTENSIBLE, 2, 11025,
                          11025 * 2 * 3, 6)
        fmt += struct.pack('<H', 24)            # bits per sample
        fmt += struct.pack('<HHL', 22, 24, 3)   # cbSize, valid bits, channel mask
        fmt += b'\xff' * 16                      # bogus SubFormat GUID
        b = self._wave_file((b'fmt ', fmt), (b'data', b''))
        with self.assertRaisesRegex(wave.Error, 'unknown extended format'):
            wave.open(io.BytesIO(b))

    def test_read_truncated_fmt_chunk_header(self):
        # fmt chunk too short for the fixed 14-byte header.
        fmt = struct.pack('<H', wave.WAVE_FORMAT_PCM) + b'\x00' * 8
        b = self._wave_file((b'fmt ', fmt))
        with self.assertRaises(EOFError):
            wave.open(io.BytesIO(b))

    def test_read_truncated_fmt_chunk_sampwidth(self):
        # fmt chunk holds the 14-byte header but is missing the sample width.
        fmt = struct.pack('<HHLLH', wave.WAVE_FORMAT_PCM, 1, 11025, 11025, 1)
        b = self._wave_file((b'fmt ', fmt))
        with self.assertRaises(EOFError):
            wave.open(io.BytesIO(b))

    def test_read_skips_unknown_chunk(self):
        # An unknown, odd-sized chunk between fmt and data must be skipped
        # (including its pad byte) so the data chunk is still found.
        data = b'\x01\x02\x03\x04'
        b = self._wave_file((b'fmt ', self.FMT_PCM),
                            (b'LIST', b'abc'),   # odd size, forces alignment
                            (b'data', data))
        with wave.open(io.BytesIO(b)) as r:
            self.assertEqual(r.getnframes(), 4)
            self.assertEqual(r.readframes(4), data)


class WaveWriteValidationTest(unittest.TestCase):
    """Cover parameter-validation paths of Wave_write."""

    @staticmethod
    def _close(w):
        try:
            # Make sure that all parameters are set
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(44100)
        except wave.Error:
            # Ignore "cannot change parameters after starting to write" error
            pass

        w.close()

    def open_writer(self):
        w = wave.open(io.BytesIO(), 'wb')
        self.addCleanup(self._close, w)
        return w

    def test_get(self):
        w = self.open_writer()
        self.assertEqual(w.getformat(), wave.WAVE_FORMAT_PCM)
        self.assertEqual(w.getnframes(), 0)
        # getcomptype() and getcompname() raise AttributeError
        # until setcomptype() is called

        with self.assertRaisesRegex(wave.Error, 'number of channels not set'):
            w.getnchannels()
        with self.assertRaisesRegex(wave.Error, 'sample width not set'):
            w.getsampwidth()
        with self.assertRaisesRegex(wave.Error, 'frame rate not set'):
            w.getframerate()
        with self.assertRaisesRegex(wave.Error, 'not all parameters set'):
            w.getparams()

    def test_set(self):
        w = self.open_writer()

        w.setnchannels(1)
        self.assertEqual(w.getnchannels(), 1)
        with self.assertRaisesRegex(wave.Error, 'bad # of channels'):
            w.setnchannels(0)

        w.setsampwidth(2)
        self.assertEqual(w.getsampwidth(), 2)
        for width in (0, 5):
            with self.subTest(width=width):
                with self.assertRaisesRegex(wave.Error, 'bad sample width'):
                    w.setsampwidth(width)

        w.setframerate(44100)
        self.assertEqual(w.getframerate(), 44100)
        with self.assertRaisesRegex(wave.Error, 'bad frame rate'):
            w.setframerate(0)

        w.setnframes(10)
        self.assertEqual(w.getnframes(), 0)

        w.setcomptype('NONE', 'not compressed')
        self.assertEqual(w.getcomptype(), 'NONE')
        self.assertEqual(w.getcompname(), 'not compressed')
        with self.assertRaisesRegex(wave.Error, 'unsupported compression type'):
            w.setcomptype('ADPCM', 'unsupported')

        w.setformat(wave.WAVE_FORMAT_PCM)
        self.assertEqual(w.getformat(), wave.WAVE_FORMAT_PCM)
        with self.assertRaisesRegex(wave.Error, 'unsupported wave format'):
            w.setformat(0x1234)

        w.setparams((1, 2, 44100, 0, 'NONE', 'not compressed'))
        self.assertEqual(w.getparams(),
                         (1, 2, 44100, 0, 'NONE', 'not compressed'))
        with self.assertRaisesRegex(wave.Error, 'bad # of channels'):
            w.setparams((0, 2, 44100, 0, 'NONE', 'not compressed'))

    def test_tell(self):
        def check_nframes(nframes):
            self.assertEqual(w.tell(), nframes)
            self.assertEqual(w.getnframes(), nframes)

        w = self.open_writer()
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(44100)
        check_nframes(0)

        frame = b'\x00\x00'
        w.writeframes(frame * 5)
        check_nframes(5)

        w.writeframes(frame * 3)
        check_nframes(8)

    def test_cannot_change_params_after_write(self):
        w = self.open_writer()
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(44100)
        w.writeframes(b'\x00\x00')

        setters = (
            ('setnchannels', (1,)),
            ('setsampwidth', (2,)),
            ('setframerate', (44100,)),
            ('setnframes', (10,)),
            ('setcomptype', ('NONE', 'not compressed')),
            ('setformat', (wave.WAVE_FORMAT_PCM,)),
            ('setparams', ((1, 2, 44100, 0, 'NONE', 'not compressed'),)),
        )
        for name, args in setters:
            with self.subTest(setter=name):
                with self.assertRaisesRegex(wave.Error,
                                            'cannot change parameters'):
                    getattr(w, name)(*args)

if __name__ == '__main__':
    unittest.main()
