/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package scheduler

import (
	"context"
	"maps"
	"reflect"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"

	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	v1 "k8s.io/api/core/v1"
	resourceapi "k8s.io/api/resource/v1"
	schedulingv1alpha3 "k8s.io/api/scheduling/v1alpha3"
	schedulingapi "k8s.io/api/scheduling/v1beta1"
	storagev1 "k8s.io/api/storage/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	utilruntime "k8s.io/apimachinery/pkg/util/runtime"
	"k8s.io/apimachinery/pkg/util/sets"
	"k8s.io/apimachinery/pkg/util/version"
	"k8s.io/apimachinery/pkg/util/wait"
	utilfeature "k8s.io/apiserver/pkg/util/feature"
	"k8s.io/client-go/dynamic/dynamicinformer"
	dyfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/informers"
	"k8s.io/client-go/kubernetes/fake"
	"k8s.io/client-go/tools/cache"
	featuregatetesting "k8s.io/component-base/featuregate/testing"
	resourceslicetracker "k8s.io/dynamic-resource-allocation/resourceslice/tracker"
	"k8s.io/klog/v2"
	"k8s.io/klog/v2/ktesting"
	fwk "k8s.io/kube-scheduler/framework"
	"k8s.io/kubernetes/pkg/features"
	apidispatcher "k8s.io/kubernetes/pkg/scheduler/backend/api_dispatcher"
	internalcache "k8s.io/kubernetes/pkg/scheduler/backend/cache"
	internalqueue "k8s.io/kubernetes/pkg/scheduler/backend/queue"
	"k8s.io/kubernetes/pkg/scheduler/framework"
	apicalls "k8s.io/kubernetes/pkg/scheduler/framework/api_calls"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/defaultbinder"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/dynamicresources"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/nodeaffinity"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/nodename"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/nodeports"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/noderesources"
	"k8s.io/kubernetes/pkg/scheduler/framework/plugins/queuesort"
	frameworkruntime "k8s.io/kubernetes/pkg/scheduler/framework/runtime"
	"k8s.io/kubernetes/pkg/scheduler/metrics"
	"k8s.io/kubernetes/pkg/scheduler/profile"
	st "k8s.io/kubernetes/pkg/scheduler/testing"
	tf "k8s.io/kubernetes/pkg/scheduler/testing/framework"
	"k8s.io/kubernetes/pkg/scheduler/util"
	"k8s.io/kubernetes/pkg/scheduler/util/assumecache"
)

func TestEventHandlers_MoveToActiveOnNominatedNodeUpdate(t *testing.T) {
	highPriorityPod :=
		st.MakePod().Name("hpp").Namespace("ns1").UID("hppns1").Priority(highPriority).SchedulerName(testSchedulerName).Obj()

	medNominatedPriorityPod :=
		st.MakePod().Name("mpp").Namespace("ns2").UID("mppns1").Priority(midPriority).SchedulerName(testSchedulerName).NominatedNodeName("node1").Obj()
	medPriorityPod :=
		st.MakePod().Name("smpp").Namespace("ns3").UID("mppns2").Priority(midPriority).SchedulerName(testSchedulerName).Obj()

	lowPriorityPod :=
		st.MakePod().Name("lpp").Namespace("ns4").UID("lppns1").Priority(lowPriority).SchedulerName(testSchedulerName).Obj()

	unschedulablePods := []*v1.Pod{highPriorityPod, medNominatedPriorityPod, medPriorityPod, lowPriorityPod}

	// Make pods schedulable on Delete event, but not when nominated node appears.
	queueHintForPodDelete := func(logger klog.Logger, pod *v1.Pod, oldObj, newObj interface{}) (fwk.QueueingHint, error) {
		oldPod, _, err := util.As[*v1.Pod](oldObj, newObj)
		if err != nil {
			t.Errorf("Failed to convert objects to pods: %v", err)
		}
		if oldPod.Status.NominatedNodeName == "" {
			return fwk.QueueSkip, nil
		}
		return fwk.Queue, nil
	}
	queueingHintMap := internalqueue.QueueingHintMapPerProfile{
		testSchedulerName: {
			framework.EventAssignedPodDelete: {
				{
					PluginName:     "fooPlugin1",
					QueueingHintFn: queueHintForPodDelete,
				},
			},
		},
	}

	tests := []struct {
		name                  string
		updateFunc            func(s *Scheduler)
		wantInActiveOrBackoff sets.Set[string]
	}{
		{
			name: "Update of a nominated node name to a different value should trigger rescheduling of lower priority pods",
			updateFunc: func(s *Scheduler) {
				updatedPod := medNominatedPriorityPod.DeepCopy()
				updatedPod.Status.NominatedNodeName = "node2"
				updatedPod.ResourceVersion = "1"
				s.updatePodInSchedulingQueue(medNominatedPriorityPod, updatedPod)
			},
			wantInActiveOrBackoff: sets.New(lowPriorityPod.Name, medPriorityPod.Name, medNominatedPriorityPod.Name),
		},
		{
			name: "Removal of a nominated node name should trigger rescheduling of lower priority pods",
			updateFunc: func(s *Scheduler) {
				updatedPod := medNominatedPriorityPod.DeepCopy()
				updatedPod.Status.NominatedNodeName = ""
				updatedPod.ResourceVersion = "1"
				s.updatePodInSchedulingQueue(medNominatedPriorityPod, updatedPod)
			},
			wantInActiveOrBackoff: sets.New(lowPriorityPod.Name, medPriorityPod.Name, medNominatedPriorityPod.Name),
		},
		{
			name: "Removal of a pod that had nominated node name should trigger rescheduling of lower priority pods",
			updateFunc: func(s *Scheduler) {
				s.deletePodFromSchedulingQueue(medNominatedPriorityPod, false)
			},
			wantInActiveOrBackoff: sets.New(lowPriorityPod.Name, medPriorityPod.Name),
		},
		{
			name: "Addition of a nominated node name to the high priority pod that did not have it before shouldn't trigger rescheduling",
			updateFunc: func(s *Scheduler) {
				updatedPod := highPriorityPod.DeepCopy()
				updatedPod.Status.NominatedNodeName = "node2"
				updatedPod.ResourceVersion = "1"
				s.updatePodInSchedulingQueue(highPriorityPod, updatedPod)
			},
			wantInActiveOrBackoff: sets.New[string](),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			var objs []runtime.Object
			for _, pod := range unschedulablePods {
				objs = append(objs, pod)
			}
			client := fake.NewClientset(objs...)
			informerFactory := informers.NewSharedInformerFactory(client, 0)

			// apiDispatcher is unused in the test, but intializing it anyway.
			apiDispatcher := apidispatcher.New(client, 16, apicalls.Relevances)
			apiDispatcher.Run(logger)
			defer apiDispatcher.Close()

			recorder := metrics.NewMetricsAsyncRecorder(3, 20*time.Microsecond, ctx.Done())
			queue := internalqueue.NewPriorityQueue(
				newDefaultQueueSort(),
				informerFactory,
				internalqueue.WithMetricsRecorder(recorder),
				internalqueue.WithQueueingHintMapPerProfile(queueingHintMap),
				internalqueue.WithAPIDispatcher(apiDispatcher),
				// disable backoff queue
				internalqueue.WithPodInitialBackoffDuration(0),
				internalqueue.WithPodMaxBackoffDuration(0))
			schedulerCache := internalcache.New(ctx, nil, false, false /* CompositePodGroup */)

			// Put test pods into unschedulable queue
			for _, pod := range unschedulablePods {
				queue.Add(ctx, pod)
				entity, err := queue.Pop(logger)
				if err != nil {
					t.Fatalf("Pop failed: %v", err)
				}
				poppedPod := entity.(*framework.QueuedPodInfo)
				poppedPod.UnschedulablePlugins = sets.New("fooPlugin1")
				if err := queue.AddUnschedulablePodIfNotPresent(logger, poppedPod, queue.SchedulingCycle()); err != nil {
					t.Errorf("Unexpected error from AddUnschedulablePodIfNotPresent: %v", err)
				}
			}

			s, _, err := initScheduler(ctx, schedulerCache, queue, apiDispatcher, client, informerFactory)
			if err != nil {
				t.Fatalf("Failed to initialize test scheduler: %v", err)
			}

			if len(s.SchedulingQueue.PodsInActiveQ()) > 0 {
				t.Errorf("No pods were expected to be in the activeQ before the update, but there were %v", s.SchedulingQueue.PodsInActiveQ())
			}
			tt.updateFunc(s)

			podsInActiveOrBackoff := s.SchedulingQueue.PodsInActiveQ()
			podsInActiveOrBackoff = append(podsInActiveOrBackoff, s.SchedulingQueue.PodsInBackoffQ()...)
			if len(podsInActiveOrBackoff) != len(tt.wantInActiveOrBackoff) {
				t.Errorf("Different number of pods were expected to be in the activeQ or backoffQ, but found actual %v vs. expected %v", podsInActiveOrBackoff, tt.wantInActiveOrBackoff)
			}
			for _, pod := range podsInActiveOrBackoff {
				if !tt.wantInActiveOrBackoff.Has(pod.Name) {
					t.Errorf("Found unexpected pod in activeQ or backoffQ: %s", pod.Name)
				}
			}
		})
	}
}

func newDefaultQueueSort() fwk.LessFunc {
	sort := &queuesort.PrioritySort{}
	return sort.Less
}

func TestUpdateAssignedPodInCache(t *testing.T) {
	nodeName := "node"

	tests := []struct {
		name   string
		oldPod *v1.Pod
		newPod *v1.Pod
	}{
		{
			name:   "pod updated with the same UID",
			oldPod: withPodName(podWithPort("oldUID", nodeName, 80), "pod"),
			newPod: withPodName(podWithPort("oldUID", nodeName, 8080), "pod"),
		},
		{
			name:   "pod updated with different UIDs",
			oldPod: withPodName(podWithPort("oldUID", nodeName, 80), "pod"),
			newPod: withPodName(podWithPort("newUID", nodeName, 8080), "pod"),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()
			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, false, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
			}
			sched.addAssignedPodToCache(tt.oldPod)
			sched.updateAssignedPodInCache(tt.oldPod, tt.newPod)

			if tt.oldPod.UID != tt.newPod.UID {
				if pod, err := sched.Cache.GetPod(tt.oldPod); err == nil {
					t.Errorf("Get pod UID %v from cache but it should not happen", pod.UID)
				}
			}
			pod, err := sched.Cache.GetPod(tt.newPod)
			if err != nil {
				t.Errorf("Failed to get pod from scheduler: %v", err)
			}
			if pod.UID != tt.newPod.UID {
				t.Errorf("Want pod UID %v, got %v", tt.newPod.UID, pod.UID)
			}
		})
	}
}

func withPodName(pod *v1.Pod, name string) *v1.Pod {
	pod.Name = name
	return pod
}

// test for informers of resources we care about is registered
func TestAddAllEventHandlers(t *testing.T) {
	tests := []struct {
		name                   string
		gvkMap                 map[fwk.EventResource]fwk.ActionType
		emulatedVersion        string
		overrides              featuregatetesting.FeatureOverrides
		expectStaticInformers  map[reflect.Type]bool
		expectDynamicInformers map[schema.GroupVersionResource]bool
	}{
		{
			name:   "default handlers in framework",
			gvkMap: map[fwk.EventResource]fwk.ActionType{},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name:            "DRA events disabled",
			emulatedVersion: "1.34",
			overrides: featuregatetesting.FeatureOverrides{
				features.DynamicResourceAllocation: false,
			},
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.ResourceClaim: fwk.Add,
				fwk.ResourceSlice: fwk.Add,
				fwk.DeviceClass:   fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():       true,
				reflect.TypeFor[*v1.Node]():      true,
				reflect.TypeFor[*v1.Namespace](): true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name:            "core DRA events enabled",
			emulatedVersion: "1.35",
			overrides: featuregatetesting.FeatureOverrides{
				features.DRADeviceTaints:     false,
				features.DRADeviceTaintRules: false,
				features.DRAExtendedResource: false,
			},
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.ResourceClaim: fwk.Add,
				fwk.ResourceSlice: fwk.Add,
				fwk.DeviceClass:   fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                    true,
				reflect.TypeFor[*v1.Node]():                   true,
				reflect.TypeFor[*v1.Namespace]():              true,
				reflect.TypeFor[*resourceapi.ResourceClaim](): true,
				reflect.TypeFor[*resourceapi.ResourceSlice](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():   true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name:            "DRA device taints partially enabled",
			emulatedVersion: "1.35",
			overrides: featuregatetesting.FeatureOverrides{
				features.DRADeviceTaintRules: false,
			},
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.ResourceClaim: fwk.Add,
				fwk.ResourceSlice: fwk.Add,
				fwk.DeviceClass:   fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                    true,
				reflect.TypeFor[*v1.Node]():                   true,
				reflect.TypeFor[*v1.Namespace]():              true,
				reflect.TypeFor[*resourceapi.ResourceClaim](): true,
				reflect.TypeFor[*resourceapi.ResourceSlice](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():   true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name: "all DRA events enabled",
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.ResourceClaim: fwk.Add,
				fwk.ResourceSlice: fwk.Add,
				fwk.DeviceClass:   fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name: "PodGroup events disabled",
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.PodGroup: fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name: "PodGroup events enabled",
			overrides: featuregatetesting.FeatureOverrides{
				features.GenericWorkload: true,
			},
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				fwk.PodGroup: fwk.Add,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
				reflect.TypeFor[*schedulingapi.PodGroup]():      true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name: "add GVKs handlers defined in framework dynamically",
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				"Pod":                               fwk.Add | fwk.Delete,
				"PersistentVolume":                  fwk.Delete,
				"storage.k8s.io/CSIStorageCapacity": fwk.Update,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                       true,
				reflect.TypeFor[*v1.Node]():                      true,
				reflect.TypeFor[*v1.Namespace]():                 true,
				reflect.TypeFor[*v1.PersistentVolume]():          true,
				reflect.TypeFor[*storagev1.CSIStorageCapacity](): true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():    true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():    true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule]():  true,
				reflect.TypeFor[*resourceapi.DeviceClass]():      true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{},
		},
		{
			name: "add GVKs handlers defined in plugins dynamically",
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				"daemonsets.v1.apps": fwk.Add | fwk.Delete,
				"cronjobs.v1.batch":  fwk.Delete,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{
				{Group: "apps", Version: "v1", Resource: "daemonsets"}: true,
				{Group: "batch", Version: "v1", Resource: "cronjobs"}:  true,
			},
		},
		{
			name: "add GVKs handlers defined in plugins dynamically, with one illegal GVK form",
			gvkMap: map[fwk.EventResource]fwk.ActionType{
				"daemonsets.v1.apps":    fwk.Add | fwk.Delete,
				"custommetrics.v1beta1": fwk.Update,
			},
			expectStaticInformers: map[reflect.Type]bool{
				reflect.TypeFor[*v1.Pod]():                      true,
				reflect.TypeFor[*v1.Node]():                     true,
				reflect.TypeFor[*v1.Namespace]():                true,
				reflect.TypeFor[*resourceapi.ResourceClaim]():   true,
				reflect.TypeFor[*resourceapi.ResourceSlice]():   true,
				reflect.TypeFor[*resourceapi.DeviceTaintRule](): true,
				reflect.TypeFor[*resourceapi.DeviceClass]():     true,
			},
			expectDynamicInformers: map[schema.GroupVersionResource]bool{
				{Group: "apps", Version: "v1", Resource: "daemonsets"}: true,
			},
		},
	}

	scheme := runtime.NewScheme()
	var localSchemeBuilder = runtime.SchemeBuilder{
		appsv1.AddToScheme,
		batchv1.AddToScheme,
	}
	localSchemeBuilder.AddToScheme(scheme)

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.emulatedVersion != "" {
				featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, utilfeature.DefaultFeatureGate, version.MustParse(tt.emulatedVersion))
			}
			featuregatetesting.SetFeatureGatesDuringTest(t, utilfeature.DefaultFeatureGate, tt.overrides)

			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			informerFactory := informers.NewSharedInformerFactory(fake.NewClientset(), 0)
			schedulingQueue := internalqueue.NewTestQueueWithInformerFactory(ctx, nil, informerFactory)
			testSched := Scheduler{
				StopEverything:  ctx.Done(),
				SchedulingQueue: schedulingQueue,
				logger:          logger,
			}

			dynclient := dyfake.NewSimpleDynamicClient(scheme)
			dynInformerFactory := dynamicinformer.NewDynamicSharedInformerFactory(dynclient, 0)
			var resourceClaimCache *assumecache.AssumeCache
			var resourceSliceTracker *resourceslicetracker.Tracker
			var draManager fwk.SharedDRAManager
			if utilfeature.DefaultFeatureGate.Enabled(features.DynamicResourceAllocation) {
				resourceClaimInformer := informerFactory.Resource().V1().ResourceClaims().Informer()
				resourceClaimCache = assumecache.NewAssumeCache(logger, resourceClaimInformer, "ResourceClaim", "", nil)
				var err error
				opts := resourceslicetracker.Options{
					EnableDeviceTaintRules: utilfeature.DefaultFeatureGate.Enabled(features.DRADeviceTaintRules),
					SliceInformer:          informerFactory.Resource().V1().ResourceSlices(),
				}
				if opts.EnableDeviceTaintRules {
					opts.TaintInformer = informerFactory.Resource().V1().DeviceTaintRules()
				}
				resourceSliceTracker, err = resourceslicetracker.StartTracker(ctx, opts)
				if err != nil {
					t.Fatalf("couldn't start resource slice tracker: %v", err)
				}

				if utilfeature.DefaultFeatureGate.Enabled(features.DRAExtendedResource) {
					draManager = dynamicresources.NewDRAManager(ctx, resourceClaimCache, resourceSliceTracker, informerFactory)
				}
			}

			if err := addAllEventHandlers(&testSched, informerFactory, dynInformerFactory, resourceClaimCache, resourceSliceTracker, draManager, tt.gvkMap); err != nil {
				t.Fatalf("Add event handlers failed, error = %v", err)
			}

			informerFactory.Start(testSched.StopEverything)
			dynInformerFactory.Start(testSched.StopEverything)
			staticInformers := informerFactory.WaitForCacheSync(testSched.StopEverything)
			dynamicInformers := dynInformerFactory.WaitForCacheSync(testSched.StopEverything)

			expectedStaticInformers := make(map[reflect.Type]bool)
			maps.Copy(expectedStaticInformers, tt.expectStaticInformers)
			if utilfeature.DefaultFeatureGate.Enabled(features.GenericWorkload) {
				expectedStaticInformers[reflect.TypeFor[*schedulingapi.PodGroup]()] = true
				if utilfeature.DefaultFeatureGate.Enabled(features.CompositePodGroup) {
					expectedStaticInformers[reflect.TypeFor[*schedulingv1alpha3.CompositePodGroup]()] = true
				}
			}

			if diff := cmp.Diff(expectedStaticInformers, staticInformers); diff != "" {
				t.Errorf("Unexpected diff (-want, +got):\n%s", diff)
			}
			if diff := cmp.Diff(tt.expectDynamicInformers, dynamicInformers); diff != "" {
				t.Errorf("Unexpected diff (-want, +got):\n%s", diff)
			}
		})
	}
}

func TestAddAllEventHandlersPodEventResources(t *testing.T) {
	logger, ctx := ktesting.NewTestContext(t)
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	informerFactory := informers.NewSharedInformerFactory(fake.NewClientset(), 0)
	schedulingQueue := internalqueue.NewTestQueueWithInformerFactory(ctx, nil, informerFactory)
	testSched := Scheduler{
		StopEverything:  ctx.Done(),
		SchedulingQueue: schedulingQueue,
		logger:          logger,
	}

	dynclient := dyfake.NewSimpleDynamicClient(runtime.NewScheme())
	dynInformerFactory := dynamicinformer.NewDynamicSharedInformerFactory(dynclient, 0)
	gvkMap := map[fwk.EventResource]fwk.ActionType{
		fwk.AssignedPod:    fwk.Add | fwk.Update | fwk.Delete,
		fwk.UnscheduledPod: fwk.Add | fwk.Update | fwk.Delete,
		fwk.TargetPod:      fwk.Update,
	}

	handledErrorMessages := []string{}
	oldErrorHandlers := utilruntime.ErrorHandlers
	t.Cleanup(func() {
		utilruntime.ErrorHandlers = oldErrorHandlers
	})
	utilruntime.ErrorHandlers = []utilruntime.ErrorHandler{
		func(_ context.Context, _ error, msg string, _ ...interface{}) {
			handledErrorMessages = append(handledErrorMessages, msg)
		},
	}

	err := addAllEventHandlers(&testSched, informerFactory, dynInformerFactory, nil, nil, nil, gvkMap)
	utilruntime.ErrorHandlers = oldErrorHandlers
	if err != nil {
		t.Fatalf("Add event handlers failed, error = %v", err)
	}
	for _, msg := range handledErrorMessages {
		if msg == "Incorrect event registration" {
			t.Fatalf("expected no incorrect event registration, got handled errors: %v", handledErrorMessages)
		}
	}

	informerFactory.Start(testSched.StopEverything)
	dynInformerFactory.Start(testSched.StopEverything)
	staticInformers := informerFactory.WaitForCacheSync(testSched.StopEverything)
	dynamicInformers := dynInformerFactory.WaitForCacheSync(testSched.StopEverything)

	expectStaticInformers := map[reflect.Type]bool{
		reflect.TypeFor[*v1.Pod]():       true,
		reflect.TypeFor[*v1.Node]():      true,
		reflect.TypeFor[*v1.Namespace](): true,
	}
	if diff := cmp.Diff(expectStaticInformers, staticInformers); diff != "" {
		t.Errorf("Unexpected diff (-want, +got):\n%s", diff)
	}
	if len(dynamicInformers) != 0 {
		t.Errorf("expected no dynamic informers, got %v", dynamicInformers)
	}
}

func TestAdmissionCheck(t *testing.T) {
	nodeaffinityError := AdmissionResult{Name: nodeaffinity.Name, Reason: nodeaffinity.ErrReasonPod}
	nodenameError := AdmissionResult{Name: nodename.Name, Reason: nodename.ErrReason}
	nodeportsError := AdmissionResult{Name: nodeports.Name, Reason: nodeports.ErrReason}
	podOverheadError := AdmissionResult{InsufficientResource: &noderesources.InsufficientResource{ResourceName: v1.ResourceCPU, Reason: "Insufficient cpu", Requested: 2000, Used: 7000, Capacity: 8000}}
	extendedResourceError := AdmissionResult{InsufficientResource: &noderesources.InsufficientResource{ResourceName: "foo.com/bar", Reason: "Insufficient foo.com/bar", Requested: 1, Unresolvable: true}}
	nodeCPUCapacity := map[v1.ResourceName]string{v1.ResourceCPU: "8"}
	extendedResource := map[v1.ResourceName]string{"foo.com/bar": "1"}
	nodeAllocatableResourceError := AdmissionResult{InsufficientResource: &noderesources.InsufficientResource{ResourceName: v1.ResourceCPU, Reason: "Insufficient cpu", Requested: 9000, Used: 0, Capacity: 8000, Unresolvable: true}}
	tests := []struct {
		name                              string
		node                              *v1.Node
		existingPods                      []*v1.Pod
		pod                               *v1.Pod
		wantAdmissionResults              [][]AdmissionResult
		enableDRAExtendedResource         bool
		enableDRANodeAllocatableResources bool
	}{
		{
			name: "check nodeAffinity and nodeports, nodeAffinity need fail quickly if includeAllFailures is false",
			node: st.MakeNode().Name("fake-node").Label("foo", "bar").Obj(),
			pod:  st.MakePod().Name("pod2").HostPort(80).NodeSelector(map[string]string{"foo": "bar1"}).Obj(),
			existingPods: []*v1.Pod{
				st.MakePod().Name("pod1").HostPort(80).Obj(),
			},
			wantAdmissionResults: [][]AdmissionResult{{nodeaffinityError, nodeportsError}, {nodeaffinityError}},
		},
		{
			name: "check PodOverhead and nodeAffinity, PodOverhead need fail quickly if includeAllFailures is false",
			node: st.MakeNode().Name("fake-node").Label("foo", "bar").Capacity(nodeCPUCapacity).Obj(),
			pod:  st.MakePod().Name("pod2").Container("c").Overhead(v1.ResourceList{v1.ResourceCPU: resource.MustParse("1")}).Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).NodeSelector(map[string]string{"foo": "bar1"}).Obj(),
			existingPods: []*v1.Pod{
				st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "7"}).Node("fake-node").Obj(),
			},
			wantAdmissionResults: [][]AdmissionResult{{podOverheadError, nodeaffinityError}, {podOverheadError}},
		},
		{
			name: "check nodename and nodeports, nodename need fail quickly if includeAllFailures is false",
			node: st.MakeNode().Name("fake-node").Obj(),
			pod:  st.MakePod().Name("pod2").HostPort(80).Node("fake-node1").Obj(),
			existingPods: []*v1.Pod{
				st.MakePod().Name("pod1").HostPort(80).Node("fake-node").Obj(),
			},
			wantAdmissionResults: [][]AdmissionResult{{nodenameError, nodeportsError}, {nodenameError}},
		},
		{
			name:                 "check extended resource handling when node Allocatable doesn't have the resource",
			node:                 st.MakeNode().Name("fake-node").Obj(),
			pod:                  st.MakePod().Name("pod1").Req(extendedResource).Obj(),
			wantAdmissionResults: [][]AdmissionResult{{extendedResourceError}, {extendedResourceError}},
		},
		{
			name:                      "check extended resource handling when node Allocatable doesn't have the resource and DRAExtendedResource is enabled",
			node:                      st.MakeNode().Name("fake-node").Obj(),
			pod:                       st.MakePod().Name("pod1").Req(extendedResource).Obj(),
			wantAdmissionResults:      [][]AdmissionResult{{extendedResourceError}, {extendedResourceError}},
			enableDRAExtendedResource: true,
		},
		{
			name: "pod not rejected when DRANodeAllocatableResources flag is disabled",
			node: st.MakeNode().Name("fake-node").Capacity(nodeCPUCapacity).Obj(),
			pod: func() *v1.Pod {
				p := st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).Obj()
				p.Status.NodeAllocatableResourceClaimStatuses = []v1.NodeAllocatableResourceClaimStatus{
					{
						ResourceClaimName: "node-allocatable-claim",
						Mapping: []v1.NodeAllocatableMappedResources{{
							Name:     v1.ResourceCPU,
							Quantity: new(resource.MustParse("8")),
						}},
					},
				}
				return p
			}(),
			wantAdmissionResults:              [][]AdmissionResult{nil, nil},
			enableDRANodeAllocatableResources: false,
		},
		{
			name: "pod rejected when DRANodeAllocatableResources flag is enabled and pod's resource request exceeds node capacity",
			node: st.MakeNode().Name("fake-node").Capacity(nodeCPUCapacity).Obj(),
			pod: func() *v1.Pod {
				p := st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).Obj()
				p.Status.NodeAllocatableResourceClaimStatuses = []v1.NodeAllocatableResourceClaimStatus{
					{
						ResourceClaimName: "node-allocatable-claim",
						Mapping: []v1.NodeAllocatableMappedResources{{
							Name:     v1.ResourceCPU,
							Quantity: new(resource.MustParse(nodeCPUCapacity[v1.ResourceCPU])), // We should exceed node capacity since we also request 1 CPU in standard request.
						}},
					},
				}
				return p
			}(),
			wantAdmissionResults:              [][]AdmissionResult{{nodeAllocatableResourceError}, {nodeAllocatableResourceError}},
			enableDRANodeAllocatableResources: true,
		},
		{
			name: "pod not rejected when DRANodeAllocatableResources flag is enabled and pod's resource request fits within node capacity",
			node: st.MakeNode().Name("fake-node").Capacity(nodeCPUCapacity).Obj(),
			pod: func() *v1.Pod {
				p := st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).Obj()
				cpuQty := resource.MustParse(nodeCPUCapacity[v1.ResourceCPU])
				cpuQty.Sub(resource.MustParse("1"))
				p.Status.NodeAllocatableResourceClaimStatuses = []v1.NodeAllocatableResourceClaimStatus{
					{
						ResourceClaimName: "node-allocatable-claim",
						Mapping: []v1.NodeAllocatableMappedResources{{
							Name:     v1.ResourceCPU,
							Quantity: new(cpuQty),
						}},
					},
				}
				return p
			}(),
			wantAdmissionResults:              [][]AdmissionResult{nil, nil},
			enableDRANodeAllocatableResources: true,
		},
		{
			name: "pod rejected when DRANodeAllocatableResources flag is enabled and pod's resource request + DRA Overhead exceeds node capacity",
			node: st.MakeNode().Name("fake-node").Capacity(nodeCPUCapacity).Obj(),
			pod: func() *v1.Pod {
				p := st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).Obj()
				p.Status.NodeAllocatableResourceClaimStatuses = []v1.NodeAllocatableResourceClaimStatus{
					{
						ResourceClaimName: "node-allocatable-claim",
						Containers:        []string{"bar"}, // Default container name created by st.MakePod() is usually "bar" (let's use that or empty containers since it's just PerPod)
						Overhead: []v1.NodeAllocatableOverheadResources{{
							Name:   v1.ResourceCPU,
							PerPod: new(resource.MustParse(nodeCPUCapacity[v1.ResourceCPU])), // 1 CPU + nodeCPUCapacity CPU > nodeCPUCapacity
						}},
					},
				}
				return p
			}(),
			wantAdmissionResults:              [][]AdmissionResult{{nodeAllocatableResourceError}, {nodeAllocatableResourceError}},
			enableDRANodeAllocatableResources: true,
		},
		{
			name: "pod not rejected when DRANodeAllocatableResources flag is enabled and pod's resource request + DRA Overhead fits within node capacity",
			node: st.MakeNode().Name("fake-node").Capacity(nodeCPUCapacity).Obj(),
			pod: func() *v1.Pod {
				p := st.MakePod().Name("pod1").Req(map[v1.ResourceName]string{v1.ResourceCPU: "1"}).Obj()
				cpuQty := resource.MustParse(nodeCPUCapacity[v1.ResourceCPU])
				cpuQty.Sub(resource.MustParse("1")) // Now cpuQty + 1 CPU (request) = nodeCPUCapacity CPU
				p.Status.NodeAllocatableResourceClaimStatuses = []v1.NodeAllocatableResourceClaimStatus{
					{
						ResourceClaimName: "node-allocatable-claim",
						Containers:        []string{"bar"},
						Overhead: []v1.NodeAllocatableOverheadResources{{
							Name:   v1.ResourceCPU,
							PerPod: &cpuQty,
						}},
					},
				}
				return p
			}(),
			wantAdmissionResults:              [][]AdmissionResult{nil, nil},
			enableDRANodeAllocatableResources: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if !tt.enableDRAExtendedResource {
				featuregatetesting.SetFeatureGateEmulationVersionDuringTest(t, utilfeature.DefaultFeatureGate, version.MustParse("1.36"))
			}
			featuregatetesting.SetFeatureGatesDuringTest(t, utilfeature.DefaultFeatureGate, featuregatetesting.FeatureOverrides{
				features.DRAExtendedResource:         tt.enableDRAExtendedResource,
				features.DRANodeAllocatableResources: tt.enableDRANodeAllocatableResources,
			})
			nodeInfo := framework.NewNodeInfo(tt.existingPods...)
			nodeInfo.SetNode(tt.node)

			flags := []bool{true, false}
			for i := range flags {
				admissionResults := AdmissionCheck(tt.pod, nodeInfo, flags[i])

				if diff := cmp.Diff(tt.wantAdmissionResults[i], admissionResults); diff != "" {
					t.Errorf("Unexpected admissionResults (-want, +got):\n%s", diff)
				}
			}
		})
	}
}

func TestAddPod(t *testing.T) {
	basePod := func() *st.PodWrapper {
		return st.MakePod().Name("pod1").SchedulerName("supported-scheduler").Namespace("ns1").UID("pod1")
	}

	tests := []struct {
		name                             string
		pod                              *v1.Pod
		genericWorkloadEnabled           bool
		expectInQueue                    bool
		expectInCache                    bool
		expectInPodGroupStateUnscheduled bool
		expectInPodGroupStateAssigned    bool
	}{
		{
			name:          "add unscheduled pod",
			pod:           basePod().Obj(),
			expectInQueue: true,
		},
		{
			name: "add unscheduled pod with other scheduler name",
			pod:  basePod().SchedulerName("other-scheduler").Obj(),
		},
		{
			name:          "add scheduled pod",
			pod:           basePod().Node("node1").Obj(),
			expectInCache: true,
		},
		{
			name:          "add a pod group member with GenericWorkload disabled",
			pod:           basePod().PodGroupName("pg1").Obj(),
			expectInQueue: true,
		},
		{
			name:                             "add an unscheduled pod group member",
			pod:                              basePod().PodGroupName("pg1").Obj(),
			genericWorkloadEnabled:           true,
			expectInQueue:                    true,
			expectInPodGroupStateUnscheduled: true,
		},
		{
			name:                          "add a scheduled pod group member",
			pod:                           basePod().Node("node1").PodGroupName("pg1").Obj(),
			genericWorkloadEnabled:        true,
			expectInCache:                 true,
			expectInPodGroupStateAssigned: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, tt.genericWorkloadEnabled, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
				Profiles: profile.Map{
					"supported-scheduler": nil,
				},
			}

			sched.addPod(tt.pod)

			_, ok := sched.SchedulingQueue.GetPod(tt.pod.Name, tt.pod.Namespace, tt.pod.Spec.SchedulingGroup)
			if tt.expectInQueue && !ok {
				t.Errorf("Expected pod to be in scheduling queue")
			} else if !tt.expectInQueue && ok {
				t.Errorf("Expected pod not to be in scheduling queue")
			}
			_, err := sched.Cache.GetPod(tt.pod)
			if tt.expectInCache && err != nil {
				t.Errorf("Expected pod to be in cache: %v", err)
			} else if !tt.expectInCache && err == nil {
				t.Errorf("Expected pod not to be in cache")
			}

			if tt.pod.Spec.SchedulingGroup == nil {
				// Pod has no pod group, so there is no pod group state to check, the test can complete.
				return
			}

			pgs, err := sched.Cache.PodGroupStates().Get(tt.pod.Namespace, *tt.pod.Spec.SchedulingGroup.PodGroupName)

			if !tt.genericWorkloadEnabled {
				if err == nil {
					t.Errorf("Expected no pod group state to exist when GenericWorkload is disabled, but found one")
				}
				return
			}

			if err != nil {
				t.Fatalf("Expected pod group state to exist, got error: %v", err)
			}

			if inUnscheduled := pgs.UnscheduledPods()[tt.pod.Name] != nil; inUnscheduled != tt.expectInPodGroupStateUnscheduled {
				t.Errorf("Expected pod in UnscheduledPods of PodGroupState: got %v, want %v", inUnscheduled, tt.expectInPodGroupStateUnscheduled)
			}
			if inAssigned := pgs.AssignedPods().Has(tt.pod.UID); inAssigned != tt.expectInPodGroupStateAssigned {
				t.Errorf("Expected pod in AssignedPods of PodGroupState: got %v, want %v", inAssigned, tt.expectInPodGroupStateAssigned)
			}
		})
	}
}

func TestAddPod_MoveUnschedulablePodsWithGenericWorkload(t *testing.T) {
	pod := st.MakePod().Name("pod1").SchedulerName("supported-scheduler").Namespace("ns1").UID("pod1").Obj()
	unschedulablePodInfos := []*framework.QueuedPodInfo{
		{
			PodInfo: &framework.PodInfo{
				Pod: st.MakePod().Name("unsched-pod-1").SchedulerName("supported-scheduler").Namespace("ns1").UID("unsched-pod-1").Obj(),
			},
			QueueingParams: framework.QueueingParams{
				UnschedulablePlugins: sets.New("fooPlugin1"),
			},
		},
		{
			PodInfo: &framework.PodInfo{
				Pod: st.MakePod().Name("unsched-pod-2").SchedulerName("supported-scheduler").Namespace("ns1").UID("unsched-pod-2").Obj(),
			},
			QueueingParams: framework.QueueingParams{
				UnschedulablePlugins: sets.New("otherPlugin"),
			},
		},
	}

	tests := []struct {
		name                   string
		genericWorkloadEnabled bool
		expectInActiveQ        sets.Set[string]
	}{
		{
			name:                   "do not move unschedulable pods when GenericWorkload is disabled",
			genericWorkloadEnabled: false,
			expectInActiveQ:        sets.New("pod1"),
		},
		{
			name:                   "only move unschedulable pods waiting on the triggered plugin when GenericWorkload is enabled",
			genericWorkloadEnabled: true,
			expectInActiveQ:        sets.New("pod1", "unsched-pod-1"),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.GenericWorkload, tt.genericWorkloadEnabled)
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			queueingHintMap := internalqueue.QueueingHintMapPerProfile{
				"supported-scheduler": {
					framework.EventUnscheduledPodAdd: {
						{
							PluginName: "fooPlugin1",
							QueueingHintFn: func(logger klog.Logger, pod *v1.Pod, oldObj, newObj interface{}) (fwk.QueueingHint, error) {
								return fwk.Queue, nil
							},
						},
					},
				},
			}

			sched := &Scheduler{
				Cache: internalcache.New(ctx, nil, tt.genericWorkloadEnabled, false),
				SchedulingQueue: internalqueue.NewTestQueue(
					ctx,
					newDefaultQueueSort(),
					internalqueue.WithQueueingHintMapPerProfile(queueingHintMap),
					internalqueue.WithPodInitialBackoffDuration(0),
					internalqueue.WithPodMaxBackoffDuration(0),
				),
				logger: logger,
				Profiles: profile.Map{
					"supported-scheduler": nil,
				},
			}

			// Put test pod(s) into unschedulable queue.
			for _, pInfo := range unschedulablePodInfos {
				sched.SchedulingQueue.Add(ctx, pInfo.Pod)
				if _, err := sched.SchedulingQueue.Pop(logger); err != nil {
					t.Fatalf("Pop failed: %v", err)
				}
				if err := sched.SchedulingQueue.AddUnschedulablePodIfNotPresent(logger, pInfo, sched.SchedulingQueue.SchedulingCycle()); err != nil {
					t.Fatalf("Unexpected error from AddUnschedulablePodIfNotPresent: %v", err)
				}
			}

			// Add a new pod to trigger the event handler.
			sched.addPod(pod)

			// Check if unschedulable pods were moved.
			// Since backoff time is set to 0, all moved pods should land in active queue.
			gotInActiveQ := sets.New[string]()
			for _, p := range sched.SchedulingQueue.PodsInActiveQ() {
				gotInActiveQ.Insert(p.Name)
			}

			if diff := cmp.Diff(tt.expectInActiveQ, gotInActiveQ); diff != "" {
				t.Errorf("Unexpected pods in active queue (-want, +got):\n%s", diff)
			}
		})
	}
}

func TestUpdatePod(t *testing.T) {
	pod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").SchedulerName("supported-scheduler").Obj()
	updatedPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").SchedulerName("supported-scheduler").Obj()

	podWithDeletionTimestamp := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Terminating().ResourceVersion("2").SchedulerName("supported-scheduler").Obj()

	otherPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").SchedulerName("other-scheduler").Obj()
	updatedOtherPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").SchedulerName("other-scheduler").Obj()

	scheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName("supported-scheduler").Obj()
	updatedScheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").Node("node1").SchedulerName("supported-scheduler").Obj()

	otherScheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName("other-scheduler").Obj()
	updatedOtherScheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").Node("node1").SchedulerName("other-scheduler").Obj()

	scheduledPodOtherNode := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node2").SchedulerName("supported-scheduler").Obj()

	unscheduledPodGroupMember := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	unscheduledPodGroupMemberWithLabels := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	scheduledPodGroupMember := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Node("node1").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	scheduledPodGroupMemberWithLabels := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Labels(map[string]string{"foo": "bar"}).ResourceVersion("2").Node("node1").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	scheduledPodGroupMemberWithOtherNode := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Node("node2").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	podGroupMemberWithDeletionTimestamp := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Terminating().ResourceVersion("2").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()

	tests := []struct {
		name                             string
		oldPod                           *v1.Pod
		assumedPod                       *v1.Pod
		newPod                           *v1.Pod
		genericWorkloadEnabled           bool
		waitingOnPermit                  bool
		expectInQueue                    *v1.Pod
		expectInCache                    *v1.Pod
		expectInPodGroupStateUnscheduled bool
		expectInPodGroupStateAssumed     bool
		expectInPodGroupStateAssigned    bool
		expectPodGroupStateDeleted       bool
	}{
		{
			name:          "update unscheduled pod",
			oldPod:        pod,
			newPod:        updatedPod,
			expectInQueue: updatedPod,
		},
		{
			name:   "update unscheduled pod with other scheduler name",
			oldPod: otherPod,
			newPod: updatedOtherPod,
		},
		{
			name:          "update assumed pod",
			oldPod:        pod,
			assumedPod:    scheduledPod,
			newPod:        updatedPod,
			expectInCache: scheduledPod,
		},
		{
			name:          "update scheduled pod",
			oldPod:        scheduledPod,
			newPod:        updatedScheduledPod,
			expectInCache: updatedScheduledPod,
		},
		{
			name:          "update scheduled pod with other scheduler name",
			oldPod:        otherScheduledPod,
			newPod:        updatedOtherScheduledPod,
			expectInCache: updatedOtherScheduledPod,
		},
		{
			name:          "bind unscheduled pod",
			oldPod:        pod,
			newPod:        scheduledPod,
			expectInCache: scheduledPod,
		},
		{
			name:          "bind unscheduled pod with other scheduler name",
			oldPod:        otherPod,
			newPod:        otherScheduledPod,
			expectInCache: otherScheduledPod,
		},
		{
			name:          "bind assumed pod",
			oldPod:        pod,
			assumedPod:    scheduledPod,
			newPod:        scheduledPod,
			expectInCache: scheduledPod,
		},
		{
			name:          "bind assumed pod to a different node",
			oldPod:        pod,
			assumedPod:    scheduledPod,
			newPod:        scheduledPodOtherNode,
			expectInCache: scheduledPodOtherNode,
		},
		{
			name:       "update assumed pod with deletion timestamp",
			oldPod:     pod,
			assumedPod: scheduledPod,
			newPod:     podWithDeletionTimestamp,
		},
		{
			name:            "update assumed pod waiting on permit with deletion timestamp",
			oldPod:          pod,
			assumedPod:      scheduledPod,
			newPod:          podWithDeletionTimestamp,
			waitingOnPermit: true,
			expectInCache:   scheduledPod,
		},
		{
			name:          "update pod group member with GenericWorkload disabled",
			oldPod:        unscheduledPodGroupMember,
			newPod:        unscheduledPodGroupMemberWithLabels,
			expectInQueue: unscheduledPodGroupMemberWithLabels,
		},
		{
			name:                             "update unscheduled pod group member, add label",
			oldPod:                           unscheduledPodGroupMember,
			newPod:                           unscheduledPodGroupMemberWithLabels,
			expectInQueue:                    unscheduledPodGroupMemberWithLabels,
			genericWorkloadEnabled:           true,
			expectInPodGroupStateUnscheduled: true,
		},
		{
			name:                         "update assumed pod group member, add label",
			oldPod:                       unscheduledPodGroupMember,
			assumedPod:                   scheduledPodGroupMember,
			newPod:                       unscheduledPodGroupMemberWithLabels,
			expectInCache:                scheduledPodGroupMember,
			genericWorkloadEnabled:       true,
			expectInPodGroupStateAssumed: true,
		},
		{
			name:                          "update scheduled pod group member, add label",
			oldPod:                        scheduledPodGroupMember,
			newPod:                        scheduledPodGroupMemberWithLabels,
			expectInCache:                 scheduledPodGroupMemberWithLabels,
			genericWorkloadEnabled:        true,
			expectInPodGroupStateAssigned: true,
		},
		{
			name:                          "bind unscheduled pod group member",
			oldPod:                        unscheduledPodGroupMember,
			newPod:                        scheduledPodGroupMember,
			expectInCache:                 scheduledPodGroupMember,
			genericWorkloadEnabled:        true,
			expectInPodGroupStateAssigned: true,
		},
		{
			name:                          "bind assumed pod group member",
			oldPod:                        unscheduledPodGroupMember,
			assumedPod:                    scheduledPodGroupMember,
			newPod:                        scheduledPodGroupMember,
			expectInCache:                 scheduledPodGroupMember,
			genericWorkloadEnabled:        true,
			expectInPodGroupStateAssigned: true,
		},
		{
			name:                          "bind assumed pod group member to a different node",
			oldPod:                        unscheduledPodGroupMember,
			assumedPod:                    scheduledPodGroupMember,
			newPod:                        scheduledPodGroupMemberWithOtherNode,
			expectInCache:                 scheduledPodGroupMemberWithOtherNode,
			genericWorkloadEnabled:        true,
			expectInPodGroupStateAssigned: true,
		},
		{
			name:                       "update assumed pod group member with deletion timestamp",
			oldPod:                     unscheduledPodGroupMember,
			assumedPod:                 scheduledPodGroupMember,
			newPod:                     podGroupMemberWithDeletionTimestamp,
			genericWorkloadEnabled:     true,
			expectPodGroupStateDeleted: true,
		},
		{
			name:                         "update assumed pod group member waiting on permit with deletion timestamp",
			oldPod:                       unscheduledPodGroupMember,
			assumedPod:                   scheduledPodGroupMember,
			newPod:                       podGroupMemberWithDeletionTimestamp,
			genericWorkloadEnabled:       true,
			waitingOnPermit:              true,
			expectInCache:                scheduledPodGroupMember,
			expectInPodGroupStateAssumed: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			registerPluginFuncs := []tf.RegisterPluginFunc{
				tf.RegisterQueueSortPlugin(queuesort.Name, queuesort.New),
				tf.RegisterBindPlugin(defaultbinder.Name, defaultbinder.New),
			}
			waitingPods := frameworkruntime.NewWaitingPodsMap()
			schedFramework, err := tf.NewFramework(
				ctx,
				registerPluginFuncs,
				"supported-scheduler",
				frameworkruntime.WithWaitingPods(waitingPods),
			)
			if err != nil {
				t.Fatalf("Failed to create framework: %v", err)
			}
			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, tt.genericWorkloadEnabled, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
				Profiles: profile.Map{
					"supported-scheduler": schedFramework,
				},
			}

			var waitOnPermitDone chan struct{}
			if tt.assumedPod != nil {
				if tt.oldPod.Spec.SchedulingGroup != nil {
					sched.Cache.AddPodGroupMember(tt.oldPod)
				}
				err := sched.Cache.AssumePod(logger, tt.assumedPod)
				if err != nil {
					t.Fatalf("Failed to assume pod: %v", err)
				}
				if tt.waitingOnPermit {
					waitOnPermitDone = make(chan struct{})
					schedFramework.AddWaitingPod(tt.assumedPod, nil)
					go func() {
						defer close(waitOnPermitDone)
						schedFramework.WaitOnPermit(ctx, tt.assumedPod)
					}()
				}
			} else {
				sched.addPod(tt.oldPod)
			}

			sched.updatePod(tt.oldPod, tt.newPod)

			if tt.waitingOnPermit {
				err := wait.PollUntilContextTimeout(ctx, 10*time.Millisecond, 1*time.Second, true, func(ctx context.Context) (bool, error) {
					return schedFramework.GetWaitingPod(tt.assumedPod.UID) == nil, nil
				})
				if err != nil {
					t.Errorf("Expected pod %v to be removed from waiting pods", tt.assumedPod.UID)
				}
				select {
				case <-waitOnPermitDone:
				case <-time.After(wait.ForeverTestTimeout):
					t.Fatalf("timeout on WaitOnPermit %v", tt.assumedPod.UID)
				}
			}

			qPod, ok := sched.SchedulingQueue.GetPod(tt.newPod.Name, tt.newPod.Namespace, tt.newPod.Spec.SchedulingGroup)
			if tt.expectInQueue != nil {
				if !ok {
					t.Errorf("Expected pod to be in scheduling queue")
				} else if diff := cmp.Diff(tt.expectInQueue, qPod.GetPod()); diff != "" {
					t.Errorf("Unexpected pod after update (-want,+got):\n%s", diff)
				}
			} else if ok {
				t.Errorf("Expected pod not to be in scheduling queue")
			}
			pod, err := sched.Cache.GetPod(tt.newPod)
			if tt.expectInCache != nil {
				if err != nil {
					t.Errorf("Expected pod to be in cache: %v", err)
				} else if diff := cmp.Diff(tt.expectInCache, pod); diff != "" {
					t.Errorf("Unexpected pod after update (-want,+got):\n%s", diff)
				}
			} else if err == nil {
				t.Errorf("Expected pod not to be in cache")
			}

			if tt.newPod.Spec.SchedulingGroup == nil {
				// Pod has no pod group, so there is no pod group state to check, the test can complete.
				return
			}
			pgs, err := sched.Cache.PodGroupStates().Get(tt.oldPod.Namespace, *tt.oldPod.Spec.SchedulingGroup.PodGroupName)

			if !tt.genericWorkloadEnabled || tt.expectPodGroupStateDeleted {
				if err == nil {
					t.Errorf("Expected pod group state to not exist, but it still exists")
				}
				return
			}

			if err != nil {
				t.Fatalf("Expected pod group state to exist, got error: %v", err)
			}

			if inUnscheduled := pgs.UnscheduledPods()[tt.newPod.Name] != nil; inUnscheduled != tt.expectInPodGroupStateUnscheduled {
				t.Errorf("pod in UnscheduledPods of PodGroupState: got %v, want %v", inUnscheduled, tt.expectInPodGroupStateUnscheduled)
			}
			if inAssumed := pgs.AssumedPods().Has(tt.newPod.UID); inAssumed != tt.expectInPodGroupStateAssumed {
				t.Errorf("pod in AssumedPods of PodGroupState: got %v, want %v", inAssumed, tt.expectInPodGroupStateAssumed)
			}
			if inAssigned := pgs.AssignedPods().Has(tt.newPod.UID); inAssigned != tt.expectInPodGroupStateAssigned {
				t.Errorf("pod in AssignedPods of PodGroupState: got %v, want %v", inAssigned, tt.expectInPodGroupStateAssigned)
			}
		})
	}
}

func TestDeletePod(t *testing.T) {
	pod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").SchedulerName("supported-scheduler").Obj()
	otherPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").SchedulerName("other-scheduler").Obj()
	scheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName("supported-scheduler").Obj()
	otherScheduledPod := st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName("other-scheduler").Obj()
	podGroupMember := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()
	scheduledPodGroupMember := st.MakePod().Name("pod1").Namespace("ns1").UID("pgpod1").Node("node1").SchedulerName("supported-scheduler").PodGroupName("pg1").Obj()

	tests := []struct {
		name                         string
		initialPod                   *v1.Pod
		assumedPod                   *v1.Pod
		waitingOnPermit              bool
		podToDelete                  any
		genericWorkloadEnabled       bool
		expectInCache                bool
		expectInPodGroupStateAssumed bool
	}{
		{
			name:        "delete unscheduled pod",
			initialPod:  pod,
			podToDelete: pod,
		},
		{
			name:        "delete unscheduled pod with other scheduler name",
			initialPod:  otherPod,
			podToDelete: otherPod,
		},
		{
			name:        "delete unscheduled pod with unknown state",
			initialPod:  pod,
			podToDelete: cache.DeletedFinalStateUnknown{Obj: pod},
		},
		{
			name:        "delete assumed pod",
			initialPod:  pod,
			assumedPod:  scheduledPod,
			podToDelete: pod,
		},
		{
			name:        "delete scheduled pod",
			initialPod:  scheduledPod,
			podToDelete: scheduledPod,
		},
		{
			name:        "delete scheduled pod with other scheduler name",
			initialPod:  otherScheduledPod,
			podToDelete: otherScheduledPod,
		},
		{
			name:        "delete scheduled pod with unknown state",
			initialPod:  scheduledPod,
			podToDelete: cache.DeletedFinalStateUnknown{Obj: scheduledPod},
		},
		{
			name:        "delete scheduled pod with unknown older state",
			initialPod:  scheduledPod,
			podToDelete: cache.DeletedFinalStateUnknown{Obj: pod},
		},
		{
			name:        "delete a pod group member, GenericWorkload disabled",
			initialPod:  podGroupMember,
			podToDelete: podGroupMember,
		},
		{
			name:                   "delete an unscheduled pod group member",
			initialPod:             podGroupMember,
			podToDelete:            podGroupMember,
			genericWorkloadEnabled: true,
		},
		{
			name:                   "delete a scheduled pod group member",
			initialPod:             scheduledPodGroupMember,
			podToDelete:            scheduledPodGroupMember,
			genericWorkloadEnabled: true,
		},
		{
			name:                   "delete an assumed pod group member",
			initialPod:             podGroupMember,
			assumedPod:             scheduledPodGroupMember,
			podToDelete:            scheduledPodGroupMember,
			genericWorkloadEnabled: true,
		},
		{
			name:                         "delete an assumed pod group member waiting on permit",
			initialPod:                   podGroupMember,
			assumedPod:                   scheduledPodGroupMember,
			podToDelete:                  podGroupMember,
			genericWorkloadEnabled:       true,
			waitingOnPermit:              true,
			expectInCache:                true,
			expectInPodGroupStateAssumed: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			registerPluginFuncs := []tf.RegisterPluginFunc{
				tf.RegisterQueueSortPlugin(queuesort.Name, queuesort.New),
				tf.RegisterBindPlugin(defaultbinder.Name, defaultbinder.New),
			}
			waitingPods := frameworkruntime.NewWaitingPodsMap()
			schedFramework, err := tf.NewFramework(
				ctx,
				registerPluginFuncs,
				"supported-scheduler",
				frameworkruntime.WithWaitingPods(waitingPods),
			)
			if err != nil {
				t.Fatalf("Failed to create framework: %v", err)
			}
			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, tt.genericWorkloadEnabled, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
				Profiles: profile.Map{
					"supported-scheduler": schedFramework,
				},
			}

			var waitOnPermitDone chan struct{}
			if tt.assumedPod != nil {
				if tt.initialPod.Spec.SchedulingGroup != nil {
					sched.Cache.AddPodGroupMember(tt.initialPod)
				}
				err := sched.Cache.AssumePod(logger, tt.assumedPod)
				if err != nil {
					t.Fatalf("Failed to assume pod: %v", err)
				}
				if tt.waitingOnPermit {
					waitOnPermitDone = make(chan struct{})
					schedFramework.AddWaitingPod(tt.assumedPod, nil)
					go func() {
						defer close(waitOnPermitDone)
						schedFramework.WaitOnPermit(ctx, tt.assumedPod)
					}()
				}
			} else {
				sched.addPod(tt.initialPod)
			}

			sched.deletePod(tt.podToDelete)

			if tt.waitingOnPermit {
				err := wait.PollUntilContextTimeout(ctx, 10*time.Millisecond, 1*time.Second, true, func(ctx context.Context) (bool, error) {
					return schedFramework.GetWaitingPod(tt.assumedPod.UID) == nil, nil
				})
				if err != nil {
					t.Errorf("Expected pod %v to be removed from waiting pods", tt.assumedPod.UID)
				}

				select {
				case <-waitOnPermitDone:
				case <-time.After(wait.ForeverTestTimeout):
					t.Fatalf("timeout on WaitOnPermit %v", tt.assumedPod.UID)
				}
			}

			_, err = sched.Cache.GetPod(tt.initialPod)
			if tt.expectInCache {
				if err != nil {
					t.Errorf("Expected pod to still be in cache: %v", err)
				}
			} else if err == nil {
				t.Errorf("Unexpected pod in cache after removal")
			}
			_, ok := sched.SchedulingQueue.GetPod(tt.initialPod.Name, tt.initialPod.Namespace, tt.initialPod.Spec.SchedulingGroup)
			if ok {
				t.Errorf("Unexpected pod in scheduling queue after removal")
			}

			if tt.initialPod.Spec.SchedulingGroup == nil {
				// Pod has no pod group, so there is no pod group state to check, the test can complete.
				return
			}
			pgs, err := sched.Cache.PodGroupStates().Get(tt.initialPod.Namespace, *tt.initialPod.Spec.SchedulingGroup.PodGroupName)
			if tt.expectInPodGroupStateAssumed {
				if err != nil {
					t.Fatalf("Unexpected error getting pod group state: %v", err)
				}
				if inAssumed := pgs.AssumedPods().Has(tt.assumedPod.UID); !inAssumed {
					t.Errorf("Expected pod to be in AssumedPods of PodGroupState")
				}
			} else if err == nil {
				t.Errorf("Unexpected pod group state in cache after pod removal")
			}
		})
	}
}

func TestAddPodGroup(t *testing.T) {
	podGroup := st.MakePodGroup().Namespace("ns1").Name("pg1").Obj()

	tests := []struct {
		name     string
		podGroup *schedulingapi.PodGroup
	}{
		{
			name:     "add valid pod group",
			podGroup: podGroup,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
			}

			sched.addPodGroup(tt.podGroup)

			gotPodGroup, err := sched.Cache.PodGroups().Get(podGroup.Namespace, podGroup.Name)
			if err != nil {
				t.Errorf("Expected pod group to be in cache, got error: %v", err)
			}
			if diff := cmp.Diff(podGroup, gotPodGroup); diff != "" {
				t.Errorf("Unexpected pod group in cache (-want, +got):\n%s", diff)
			}
		})
	}
}

func TestUpdatePodGroup(t *testing.T) {
	oldPodGroup := st.MakePodGroup().Namespace("ns1").Name("pg1").MinCount(1).Obj()
	oldPodGroup.ResourceVersion = "1"
	newPodGroup := st.MakePodGroup().Namespace("ns1").Name("pg1").MinCount(2).Obj()
	newPodGroup.ResourceVersion = "2"

	tests := []struct {
		name           string
		oldPodGroup    *schedulingapi.PodGroup
		newPodGroup    *schedulingapi.PodGroup
		expectPodGroup *schedulingapi.PodGroup
	}{
		{
			name:           "update valid pod group",
			oldPodGroup:    oldPodGroup,
			newPodGroup:    newPodGroup,
			expectPodGroup: newPodGroup,
		},
		{
			name:           "update pod group with same resource version should be no-op",
			oldPodGroup:    oldPodGroup,
			newPodGroup:    oldPodGroup,
			expectPodGroup: oldPodGroup,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
			}

			sched.Cache.AddGenericPodGroup(framework.NewGenericPodGroup(tt.oldPodGroup))

			sched.updatePodGroup(tt.oldPodGroup, tt.newPodGroup)

			gotPodGroup, err := sched.Cache.PodGroups().Get(tt.expectPodGroup.Namespace, tt.expectPodGroup.Name)
			if err != nil {
				t.Errorf("Expected pod group to be in cache, got error: %v", err)
			}
			if diff := cmp.Diff(tt.expectPodGroup, gotPodGroup); diff != "" {
				t.Errorf("Unexpected pod group in cache (-want, +got):\n%s", diff)
			}
		})
	}
}

func TestDeletePodGroup(t *testing.T) {
	podGroup := st.MakePodGroup().Namespace("ns1").Name("pg1").Obj()

	tests := []struct {
		name             string
		initPodGroup     *schedulingapi.PodGroup
		podGroupToDelete any
	}{
		{
			name:             "delete pod group",
			initPodGroup:     podGroup,
			podGroupToDelete: podGroup,
		},
		{
			name:             "delete DeletedFinalStateUnknown tombstone with pod group",
			initPodGroup:     podGroup,
			podGroupToDelete: cache.DeletedFinalStateUnknown{Obj: podGroup},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
			}

			if tt.initPodGroup != nil {
				sched.Cache.AddGenericPodGroup(framework.NewGenericPodGroup(tt.initPodGroup))
			}

			sched.deletePodGroup(tt.podGroupToDelete)

			_, err := sched.Cache.PodGroups().Get(tt.initPodGroup.Namespace, tt.initPodGroup.Name)
			if err == nil {
				t.Errorf("Expected pod group to be deleted from cache, but it still exists")
			}
		})
	}
}

func TestAddCompositePodGroup(t *testing.T) {
	cpg := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").Obj()

	tests := []struct {
		name                string
		cpg                 any
		cpgEnabled          bool
		expectInCache       bool
		triggerQueueingHint bool
	}{
		{
			name:          "add valid composite pod group with feature enabled",
			cpg:           cpg,
			cpgEnabled:    true,
			expectInCache: true,
		},
		{
			name:          "add valid composite pod group with feature disabled",
			cpg:           cpg,
			cpgEnabled:    false,
			expectInCache: false,
		},
		{
			name:          "add invalid composite pod group type with feature enabled",
			cpg:           "invalid-type",
			cpgEnabled:    true,
			expectInCache: false,
		},
		{
			name:                "add valid composite pod group triggers queueing hint with correct arguments",
			cpg:                 cpg,
			cpgEnabled:          true,
			expectInCache:       true,
			triggerQueueingHint: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGatesDuringTest(t, utilfeature.DefaultFeatureGate, featuregatetesting.FeatureOverrides{
				features.GenericWorkload:                 true,
				features.TopologyAwareWorkloadScheduling: tt.cpgEnabled,
				features.CompositePodGroup:               tt.cpgEnabled,
			})

			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			var actualOldObj, actualNewObj any
			var queueingHintCalled bool
			activeHint := func(logger klog.Logger, pod *v1.Pod, oldObj, newObj any) (fwk.QueueingHint, error) {
				queueingHintCalled = true
				actualOldObj = oldObj
				actualNewObj = newObj
				return fwk.QueueSkip, nil
			}

			queueingHintMap := internalqueue.QueueingHintMapPerProfile{
				testSchedulerName: {
					fwk.ClusterEvent{Resource: fwk.CompositePodGroup, ActionType: fwk.Add}: {
						{PluginName: "fake-plugin", QueueingHintFn: activeHint},
					},
				},
			}

			pod := st.MakePod().Name("p").Namespace("ns1").UID("pns").SchedulerName(testSchedulerName).Obj()
			client := fake.NewClientset(pod)
			apiDispatcher := apidispatcher.New(client, 16, apicalls.Relevances)
			apiDispatcher.Run(logger)
			defer apiDispatcher.Close()

			queue := internalqueue.NewTestQueue(ctx, nil,
				internalqueue.WithQueueingHintMapPerProfile(queueingHintMap),
				internalqueue.WithAPIDispatcher(apiDispatcher),
			)

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, tt.cpgEnabled),
				SchedulingQueue: queue,
				logger:          logger,
			}

			if tt.triggerQueueingHint {
				cpgObj := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericCompositePodGroup(cpgObj))
				pg := st.MakePodGroup().Name("pg1").Namespace("ns1").ParentCompositePodGroup("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericPodGroup(pg))

				queue.Add(ctx, pod)
				poppedEntity, _ := queue.Pop(logger)
				poppedPod := poppedEntity.(*framework.QueuedPodInfo)
				poppedPod.QueueingParams.Timestamp = time.Now().Add(-10 * time.Minute)
				poppedPod.QueueingParams.UnschedulablePlugins = sets.New("fake-plugin")
				if err := queue.AddUnschedulablePodIfNotPresent(logger, poppedPod, queue.SchedulingCycle()); err != nil {
					t.Fatalf("Failed to add unschedulable pod: %v", err)
				}
			}

			sched.addCompositePodGroup(tt.cpg)

			gotCPG, err := sched.Cache.CompositePodGroups().Get(cpg.Namespace, cpg.Name)
			if tt.expectInCache {
				if err != nil {
					t.Errorf("Expected composite pod group to be in cache, got error: %v", err)
				}
				if diff := cmp.Diff(cpg, gotCPG); diff != "" {
					t.Errorf("Unexpected composite pod group in cache (-want, +got):\n%s", diff)
				}
			} else if err == nil {
				t.Errorf("Expected composite pod group NOT to be in cache, but got: %v", gotCPG)
			}

			if tt.triggerQueueingHint {
				if !queueingHintCalled {
					t.Errorf("expected QueueingHint to be called")
				}
				if actualOldObj != nil {
					t.Errorf("expected oldObj to be nil, got %v", actualOldObj)
				}
				if actualNewObj != tt.cpg {
					t.Errorf("expected newObj to be %v, got %v", tt.cpg, actualNewObj)
				}
			}
		})
	}
}

func TestUpdateCompositePodGroup(t *testing.T) {
	oldCPG := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").MinGroupCount(1).Obj()
	oldCPG.ResourceVersion = "1"
	newCPG := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").MinGroupCount(2).Obj()
	newCPG.ResourceVersion = "2"

	tests := []struct {
		name                string
		oldCPG              any
		newCPG              any
		expectCPG           *schedulingv1alpha3.CompositePodGroup
		cpgEnabled          bool
		expectInCache       bool
		triggerQueueingHint bool
	}{
		{
			name:          "update valid composite pod group with feature enabled",
			oldCPG:        oldCPG,
			newCPG:        newCPG,
			expectCPG:     newCPG,
			cpgEnabled:    true,
			expectInCache: true,
		},
		{
			name:          "update composite pod group with same resource version should be no-op",
			oldCPG:        oldCPG,
			newCPG:        oldCPG,
			expectCPG:     oldCPG,
			cpgEnabled:    true,
			expectInCache: true,
		},
		{
			name:          "update composite pod group with feature disabled",
			oldCPG:        oldCPG,
			newCPG:        newCPG,
			expectCPG:     nil,
			cpgEnabled:    false,
			expectInCache: false,
		},
		{
			name:          "update invalid old composite pod group type with feature enabled",
			oldCPG:        "invalid-type",
			newCPG:        newCPG,
			expectCPG:     oldCPG,
			cpgEnabled:    true,
			expectInCache: true,
		},
		{
			name:          "update invalid new composite pod group type with feature enabled",
			oldCPG:        oldCPG,
			newCPG:        "invalid-type",
			expectCPG:     oldCPG,
			cpgEnabled:    true,
			expectInCache: true,
		},
		{
			name:                "update valid composite pod group triggers queueing hint with correct arguments",
			oldCPG:              oldCPG,
			newCPG:              newCPG,
			expectCPG:           newCPG,
			cpgEnabled:          true,
			expectInCache:       true,
			triggerQueueingHint: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGatesDuringTest(t, utilfeature.DefaultFeatureGate, featuregatetesting.FeatureOverrides{
				features.GenericWorkload:                 true,
				features.TopologyAwareWorkloadScheduling: tt.cpgEnabled,
				features.CompositePodGroup:               tt.cpgEnabled,
			})

			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			var actualOldObj, actualNewObj any
			var queueingHintCalled bool
			activeHint := func(logger klog.Logger, pod *v1.Pod, oldObj, newObj any) (fwk.QueueingHint, error) {
				queueingHintCalled = true
				actualOldObj = oldObj
				actualNewObj = newObj
				return fwk.QueueSkip, nil
			}

			queueingHintMap := internalqueue.QueueingHintMapPerProfile{
				testSchedulerName: {
					fwk.ClusterEvent{Resource: fwk.CompositePodGroup, ActionType: fwk.Update}: {
						{PluginName: "fake-plugin", QueueingHintFn: activeHint},
					},
				},
			}

			pod := st.MakePod().Name("p").Namespace("ns1").UID("pns").SchedulerName(testSchedulerName).Obj()
			client := fake.NewClientset(pod)
			apiDispatcher := apidispatcher.New(client, 16, apicalls.Relevances)
			apiDispatcher.Run(logger)
			defer apiDispatcher.Close()

			queue := internalqueue.NewTestQueue(ctx, nil,
				internalqueue.WithQueueingHintMapPerProfile(queueingHintMap),
				internalqueue.WithAPIDispatcher(apiDispatcher),
			)

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, tt.cpgEnabled),
				SchedulingQueue: queue,
				logger:          logger,
			}

			if tt.cpgEnabled {
				sched.Cache.AddGenericPodGroup(framework.NewGenericCompositePodGroup(oldCPG))
			}

			if tt.triggerQueueingHint {
				cpgObj := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericCompositePodGroup(cpgObj))
				pg := st.MakePodGroup().Name("pg1").Namespace("ns1").ParentCompositePodGroup("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericPodGroup(pg))

				queue.Add(ctx, pod)
				poppedEntity, _ := queue.Pop(logger)
				poppedPod := poppedEntity.(*framework.QueuedPodInfo)
				poppedPod.QueueingParams.Timestamp = time.Now().Add(-10 * time.Minute)
				poppedPod.QueueingParams.UnschedulablePlugins = sets.New("fake-plugin")
				if err := queue.AddUnschedulablePodIfNotPresent(logger, poppedPod, queue.SchedulingCycle()); err != nil {
					t.Fatalf("Failed to add unschedulable pod: %v", err)
				}
			}

			sched.updateCompositePodGroup(tt.oldCPG, tt.newCPG)

			gotCPG, err := sched.Cache.CompositePodGroups().Get(oldCPG.Namespace, oldCPG.Name)
			if tt.expectInCache {
				if err != nil {
					t.Errorf("Expected composite pod group to be in cache, got error: %v", err)
				}
				if diff := cmp.Diff(tt.expectCPG, gotCPG); diff != "" {
					t.Errorf("Unexpected composite pod group in cache (-want, +got):\n%s", diff)
				}
			} else if err == nil {
				t.Errorf("Expected composite pod group NOT to be in cache, but got: %v", gotCPG)
			}

			if tt.triggerQueueingHint {
				if !queueingHintCalled {
					t.Errorf("expected QueueingHint to be called")
				}
				if actualOldObj != tt.oldCPG {
					t.Errorf("expected oldObj to be %v, got %v", tt.oldCPG, actualOldObj)
				}
				if actualNewObj != tt.newCPG {
					t.Errorf("expected newObj to be %v, got %v", tt.newCPG, actualNewObj)
				}
			}
		})
	}
}

func TestDeleteCompositePodGroup(t *testing.T) {
	cpg := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").Obj()

	tests := []struct {
		name                string
		initCPG             *schedulingv1alpha3.CompositePodGroup
		cpgToDelete         any
		cpgEnabled          bool
		expectStillExists   bool
		triggerQueueingHint bool
	}{
		{
			name:                "delete composite pod group",
			initCPG:             cpg,
			cpgToDelete:         cpg,
			cpgEnabled:          true,
			expectStillExists:   false,
			triggerQueueingHint: true,
		},
		{
			name:                "delete DeletedFinalStateUnknown tombstone with composite pod group",
			initCPG:             cpg,
			cpgToDelete:         cache.DeletedFinalStateUnknown{Obj: cpg},
			cpgEnabled:          true,
			expectStillExists:   false,
			triggerQueueingHint: true,
		},
		{
			name:              "delete composite pod group with feature disabled",
			initCPG:           cpg,
			cpgToDelete:       cpg,
			cpgEnabled:        false,
			expectStillExists: false,
		},
		{
			name:              "delete composite pod group with invalid type",
			initCPG:           cpg,
			cpgToDelete:       "invalid-type",
			cpgEnabled:        true,
			expectStillExists: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGatesDuringTest(t, utilfeature.DefaultFeatureGate, featuregatetesting.FeatureOverrides{
				features.GenericWorkload:                 true,
				features.TopologyAwareWorkloadScheduling: tt.cpgEnabled,
				features.CompositePodGroup:               tt.cpgEnabled,
			})

			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			var actualOldObj, actualNewObj any
			var queueingHintCalled bool
			activeHint := func(logger klog.Logger, pod *v1.Pod, oldObj, newObj any) (fwk.QueueingHint, error) {
				queueingHintCalled = true
				actualOldObj = oldObj
				actualNewObj = newObj
				return fwk.QueueSkip, nil
			}

			queueingHintMap := internalqueue.QueueingHintMapPerProfile{
				testSchedulerName: {
					fwk.ClusterEvent{Resource: fwk.CompositePodGroup, ActionType: fwk.Delete}: {
						{PluginName: "fake-plugin", QueueingHintFn: activeHint},
					},
				},
			}

			pod := st.MakePod().Name("p").Namespace("ns1").UID("pns").SchedulerName(testSchedulerName).Obj()
			client := fake.NewClientset(pod)
			apiDispatcher := apidispatcher.New(client, 16, apicalls.Relevances)
			apiDispatcher.Run(logger)
			defer apiDispatcher.Close()

			queue := internalqueue.NewTestQueue(ctx, nil,
				internalqueue.WithQueueingHintMapPerProfile(queueingHintMap),
				internalqueue.WithAPIDispatcher(apiDispatcher),
			)

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, true, tt.cpgEnabled),
				SchedulingQueue: queue,
				logger:          logger,
			}

			if tt.triggerQueueingHint {
				cpgObj := st.MakeCompositePodGroup().Namespace("ns1").Name("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericCompositePodGroup(cpgObj))
				pg := st.MakePodGroup().Name("pg1").Namespace("ns1").ParentCompositePodGroup("cpg1").Obj()
				queue.AddGenericPodGroup(logger, framework.NewGenericPodGroup(pg))

				queue.Add(ctx, pod)
				poppedEntity, _ := queue.Pop(logger)
				poppedPod := poppedEntity.(*framework.QueuedPodInfo)
				poppedPod.QueueingParams.Timestamp = time.Now().Add(-10 * time.Minute)
				poppedPod.QueueingParams.UnschedulablePlugins = sets.New("fake-plugin")
				if err := queue.AddUnschedulablePodIfNotPresent(logger, poppedPod, queue.SchedulingCycle()); err != nil {
					t.Fatalf("Failed to add unschedulable pod: %v", err)
				}
			}

			if tt.initCPG != nil && tt.cpgEnabled {
				sched.Cache.AddGenericPodGroup(framework.NewGenericCompositePodGroup(tt.initCPG))
			}

			sched.deleteCompositePodGroup(tt.cpgToDelete)

			if tt.triggerQueueingHint {
				if !queueingHintCalled {
					t.Errorf("expected QueueingHint to be called")
				}
				expectedOldObj := tt.cpgToDelete
				if tombstone, ok := tt.cpgToDelete.(cache.DeletedFinalStateUnknown); ok {
					expectedOldObj = tombstone.Obj
				}
				if actualOldObj != expectedOldObj {
					t.Errorf("expected oldObj to be %v, got %v", expectedOldObj, actualOldObj)
				}
				if actualNewObj != nil {
					t.Errorf("expected newObj to be nil, got %v", actualNewObj)
				}
			}

			gotCPG, err := sched.Cache.CompositePodGroups().Get(cpg.Namespace, cpg.Name)
			if tt.expectStillExists {
				if err != nil {
					t.Errorf("Expected composite pod group to still exist in cache, but got error: %v", err)
				}
				if diff := cmp.Diff(cpg, gotCPG); diff != "" {
					t.Errorf("Unexpected composite pod group in cache (-want, +got):\n%s", diff)
				}
			} else if err == nil {
				t.Errorf("Expected composite pod group NOT to be in cache, but got: %v", gotCPG)
			}
		})
	}
}

func TestEventHandlers_DeferredResize(t *testing.T) {
	tests := []struct {
		name                 string
		enablePreemptionGate bool
		isAdd                bool
		initialPod           *v1.Pod
		updatedPod           *v1.Pod
		expectInQueue        bool
		expectInCache        bool
	}{
		{
			name:                 "add: feature gate enabled, assigned pod with deferred resize",
			enablePreemptionGate: true,
			isAdd:                true,
			initialPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			expectInQueue: true,
			expectInCache: true,
		},
		{
			name:                 "add: feature gate disabled, assigned pod with deferred resize",
			enablePreemptionGate: false,
			isAdd:                true,
			initialPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			expectInQueue: false,
			expectInCache: true,
		},
		{
			name:                 "update: feature gate enabled, assigned pod transitions to deferred resize",
			enablePreemptionGate: true,
			isAdd:                false,
			initialPod:           st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).Obj(),
			updatedPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			expectInQueue: true,
			expectInCache: true,
		},
		{
			name:                 "update: feature gate enabled, assigned pod transitions out of deferred resize",
			enablePreemptionGate: true,
			isAdd:                false,
			initialPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			updatedPod:    st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).Obj(),
			expectInQueue: false,
			expectInCache: true,
		},
		{
			name:                 "update: feature gate enabled, assigned pod requests change while remaining deferred",
			enablePreemptionGate: true,
			isAdd:                false,
			initialPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			updatedPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).
				Req(map[v1.ResourceName]string{v1.ResourceCPU: "2"}).Obj(),
			expectInQueue: true,
			expectInCache: true,
		},
		{
			name:                 "update: feature gate disabled, assigned pod transitions to deferred resize",
			enablePreemptionGate: false,
			isAdd:                false,
			initialPod:           st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).Obj(),
			updatedPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			expectInQueue: false,
			expectInCache: true,
		},
		{
			name:                 "update: feature gate disabled, assigned pod requests change while remaining deferred",
			enablePreemptionGate: false,
			isAdd:                false,
			initialPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).Obj(),
			updatedPod: st.MakePod().Name("pod1").Namespace("ns1").UID("pod1").Node("node1").SchedulerName(testSchedulerName).
				Condition(v1.PodResizePending, v1.ConditionTrue, v1.PodReasonDeferred).
				Req(map[v1.ResourceName]string{v1.ResourceCPU: "2"}).Obj(),
			expectInQueue: false,
			expectInCache: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			featuregatetesting.SetFeatureGateDuringTest(t, utilfeature.DefaultFeatureGate, features.InPlacePodVerticalScalingSchedulerPreemption, tt.enablePreemptionGate)

			logger, ctx := ktesting.NewTestContext(t)
			ctx, cancel := context.WithCancel(ctx)
			defer cancel()

			sched := &Scheduler{
				Cache:           internalcache.New(ctx, nil, false, false /* CompositePodGroup */),
				SchedulingQueue: internalqueue.NewTestQueue(ctx, nil),
				logger:          logger,
				Profiles: profile.Map{
					testSchedulerName: nil,
				},
			}

			if tt.isAdd {
				sched.addPod(tt.initialPod)
			} else {
				// For update test, first simulate addPod for the initial pod
				sched.addPod(tt.initialPod)
				sched.updatePod(tt.initialPod, tt.updatedPod)
			}

			targetPod := tt.initialPod
			if !tt.isAdd {
				targetPod = tt.updatedPod
			}

			_, ok := sched.SchedulingQueue.GetPod(targetPod.Name, targetPod.Namespace, targetPod.Spec.SchedulingGroup)
			if ok != tt.expectInQueue {
				t.Errorf("Unexpected queue state: got inQueue=%v, want inQueue=%v", ok, tt.expectInQueue)
			}

			_, err := sched.Cache.GetPod(targetPod)
			inCache := err == nil
			if inCache != tt.expectInCache {
				t.Errorf("Unexpected cache state: got inCache=%v, want inCache=%v", inCache, tt.expectInCache)
			}
		})
	}
}
