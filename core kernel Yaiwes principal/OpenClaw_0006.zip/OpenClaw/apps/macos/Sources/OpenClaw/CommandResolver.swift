import Foundation

enum CommandResolver {
    private static let projectRootDefaultsKey = "openclaw.gatewayProjectRootPath"
    private static let helperName = "openclaw"
    /// Version probes may queue under machine load; keep command resolution tolerant but bounded.
    static let versionProbeTimeout: TimeInterval = 10

    static func gatewayEntrypoint(in root: URL) -> String? {
        let distEntry = root.appendingPathComponent("dist/index.js").path
        if FileManager().isReadableFile(atPath: distEntry) { return distEntry }
        let openclawEntry = root.appendingPathComponent("openclaw.mjs").path
        if FileManager().isReadableFile(atPath: openclawEntry) { return openclawEntry }
        let binEntry = root.appendingPathComponent("bin/openclaw.js").path
        if FileManager().isReadableFile(atPath: binEntry) { return binEntry }
        return nil
    }

    static func runtimeResolution(searchPaths: [String]?) async -> Result<RuntimeResolution, RuntimeResolutionError> {
        await RuntimeLocator.resolve(searchPaths: searchPaths ?? self.preferredPaths())
    }

    static func makeRuntimeCommand(
        runtime: RuntimeResolution,
        entrypoint: String,
        subcommand: String,
        extraArgs: [String],
        profile: AppProfile = .current) -> [String]
    {
        profile.localCLICommand(
            prefix: [runtime.path, entrypoint],
            arguments: [subcommand] + extraArgs)
    }

    static func runtimeErrorCommand(_ error: RuntimeResolutionError) -> [String] {
        let message = RuntimeLocator.describeFailure(error)
        return self.errorCommand(with: message)
    }

    static func errorCommand(with message: String) -> [String] {
        let script = """
        cat <<'__OPENCLAW_ERR__' >&2
        \(message)
        __OPENCLAW_ERR__
        exit 1
        """
        return ["/bin/sh", "-c", script]
    }

    static func projectRoot(
        defaults: UserDefaults = AppDefaults.standard,
        profile: AppProfile = .current,
        homeDirectory: URL = FileManager.default.homeDirectoryForCurrentUser) -> URL
    {
        if let stored = defaults.string(forKey: projectRootDefaultsKey),
           let url = expandPath(stored),
           FileManager().fileExists(atPath: url.path)
        {
            return url
        }
        if profile.isActive {
            return profile.stateDirectoryURL(homeDirectory: homeDirectory)
        }
        let fallback = homeDirectory.appendingPathComponent("Projects/openclaw")
        if FileManager().fileExists(atPath: fallback.path) {
            return fallback
        }
        return homeDirectory
    }

    static func setProjectRoot(_ path: String) {
        AppDefaults.standard.set(path, forKey: self.projectRootDefaultsKey)
    }

    static func projectRootPath() -> String {
        self.projectRoot().path
    }

    static func preferredPaths() -> [String] {
        let current = ProcessInfo.processInfo.environment["PATH"]?
            .split(separator: ":").map(String.init) ?? []
        let home = FileManager().homeDirectoryForCurrentUser
        let projectRoot = self.projectRoot()
        let validatedExecutable = self.validatedOpenClawExecutable(
            defaults: AppDefaults.standard,
            fileManager: .default,
            requiredVersion: GatewayEnvironment.expectedGatewayVersionString())
        return self.preferredPaths(
            home: home,
            current: current,
            projectRoot: projectRoot,
            validatedExecutable: validatedExecutable)
    }

    /// Version-manager trees can make discovery arbitrarily slow. Async callers
    /// must leave their actor before touching the filesystem or the UI can stall.
    @concurrent
    static func preferredPathsAsync() async -> [String] {
        self.preferredPaths()
    }

    static func preferredPaths(
        home: URL,
        current: [String],
        projectRoot: URL,
        validatedExecutable: String? = nil,
        profile: AppProfile = .current) -> [String]
    {
        var preferredPaths: [String] = []
        let managedPaths = self.openclawManagedPaths(home: home, profile: profile)
        // Other profiles' managed trees must not leak in via stale validation or the
        // inherited shell PATH (the CLI installer adds ~/.openclaw/bin to shell profiles).
        let activeManagedBase = profile.stateDirectoryURL(homeDirectory: home).path
        func isForeignManaged(_ path: String) -> Bool {
            guard path.hasPrefix(home.path + "/") else { return false }
            let name = path.dropFirst(home.path.count + 1)
                .split(separator: "/").first.map(String.init) ?? ""
            return self.isManagedDirectoryName(name)
                && home.appendingPathComponent(name).path != activeManagedBase
        }
        if let validatedExecutable {
            let validatedBin = URL(fileURLWithPath: validatedExecutable).deletingLastPathComponent().path
            if managedPaths.contains(validatedBin) {
                preferredPaths.append(contentsOf: managedPaths)
            } else if !isForeignManaged(validatedBin) {
                preferredPaths.append(validatedBin)
            }
        }
        let externalPaths = [
            home.appendingPathComponent("Library/pnpm").path,
            "/opt/homebrew/bin",
            "/usr/local/bin",
            "/usr/bin",
            "/bin",
            home.appendingPathComponent(".local/bin").path,
        ]
        #if DEBUG
        // Dev-only convenience. Avoid project-local PATH hijacking in release builds.
        preferredPaths.insert(projectRoot.appendingPathComponent("node_modules/.bin").path, at: 0)
        #endif
        var seen = Set<String>()
        let fallbackPaths = self.nodeManagerBinPaths(home: home) + externalPaths + managedPaths
        // Preserve order while stripping duplicates so PATH lookups remain deterministic.
        return (preferredPaths + fallbackPaths + current)
            .filter { !isForeignManaged($0) && seen.insert($0).inserted }
    }

    static func validatedOpenClawExecutable(
        defaults: UserDefaults,
        fileManager: FileManager,
        requiredVersion: String?) -> String?
    {
        guard let executable = defaults.string(forKey: cliValidatedExecutableKey),
              fileManager.isExecutableFile(atPath: executable),
              let validatedVersion = defaults.string(forKey: cliValidatedVersionKey),
              Semver.parse(validatedVersion) != nil
        else {
            return nil
        }
        return Semver.satisfiesExpectedGatewayVersion(
            installed: validatedVersion,
            expected: requiredVersion) ? executable : nil
    }

    /// Exactly the AppProfile.stateDirectoryURL namespace; ~/.openclaw2 is not managed.
    private static func isManagedDirectoryName(_ name: String) -> Bool {
        name == ".openclaw" || name.hasPrefix(".openclaw-")
    }

    private static func openclawManagedPaths(home: URL, profile: AppProfile) -> [String] {
        let bases = [profile.stateDirectoryURL(homeDirectory: home)]
        var paths: [String] = []
        for base in bases {
            let bin = base.appendingPathComponent("bin")
            let nodeBin = base.appendingPathComponent("tools/node/bin")
            if FileManager().fileExists(atPath: bin.path) {
                paths.append(bin.path)
            }
            if FileManager().fileExists(atPath: nodeBin.path) {
                paths.append(nodeBin.path)
            }
        }
        return paths
    }

    private static func nodeManagerBinPaths(home: URL) -> [String] {
        var bins: [String] = []

        // Volta
        let volta = home.appendingPathComponent(".volta/bin")
        if FileManager().fileExists(atPath: volta.path) {
            bins.append(volta.path)
        }

        // asdf
        let asdf = home.appendingPathComponent(".asdf/shims")
        if FileManager().fileExists(atPath: asdf.path) {
            bins.append(asdf.path)
        }

        // fnm
        bins.append(contentsOf: self.versionedNodeBinPaths(
            base: home.appendingPathComponent(".local/share/fnm/node-versions"),
            suffix: "installation/bin"))

        // nvm
        bins.append(contentsOf: self.versionedNodeBinPaths(
            base: home.appendingPathComponent(".nvm/versions/node"),
            suffix: "bin"))

        return bins
    }

    private static func versionedNodeBinPaths(base: URL, suffix: String) -> [String] {
        guard FileManager().fileExists(atPath: base.path) else { return [] }
        let entries: [String]
        do {
            entries = try FileManager().contentsOfDirectory(atPath: base.path)
        } catch {
            return []
        }

        let sorted = entries.compactMap { entry -> (name: String, version: RuntimeVersion)? in
            guard let version = RuntimeVersion.from(string: entry),
                  RuntimeLocator.isSupportedNodeVersion(version)
            else { return nil }
            return (entry, version)
        }.sorted { first, second in
            first.version == second.version ? first.name > second.name : first.version > second.version
        }

        var paths: [String] = []
        for (entry, _) in sorted {
            let binDir = base.appendingPathComponent(entry).appendingPathComponent(suffix)
            let node = binDir.appendingPathComponent("node")
            if FileManager().isExecutableFile(atPath: node.path) {
                paths.append(binDir.path)
            }
        }
        return paths
    }

    static func findExecutable(named name: String, searchPaths: [String]? = nil) -> String? {
        for dir in searchPaths ?? self.preferredPaths() {
            let candidate = (dir as NSString).appendingPathComponent(name)
            if FileManager().isExecutableFile(atPath: candidate) {
                return candidate
            }
        }
        return nil
    }

    static func openclawExecutable(searchPaths: [String]? = nil) -> String? {
        self.findExecutable(named: self.helperName, searchPaths: searchPaths)
    }

    static func projectOpenClawExecutable(projectRoot: URL? = nil) -> String? {
        #if DEBUG
        let root = projectRoot ?? self.projectRoot()
        let candidate = root.appendingPathComponent("node_modules/.bin").appendingPathComponent(self.helperName).path
        if FileManager().isExecutableFile(atPath: candidate) {
            return candidate
        }
        // pnpm does not create a self-referential node_modules/.bin link for
        // this package. Source builds still need the checkout CLI, not a stale
        // globally installed binary with a different private command surface.
        let sourceEntrypoint = root.appendingPathComponent("openclaw.mjs").path
        return FileManager().isExecutableFile(atPath: sourceEntrypoint) ? sourceEntrypoint : nil
        #else
        return nil
        #endif
    }

    static func nodeHostWorkerLaunch(
        bundle: Bundle = .main,
        projectRoot: URL? = nil,
        searchPaths: [String]? = nil) async throws -> MacNodeHostWorkerLaunch
    {
        // Packaging and optimization are independent: even DEBUG apps must use
        // their signed payload, including after relocation or checkout removal.
        if bundle.bundleURL.pathExtension == "app" {
            return try BundledNodeWorker.launch(bundle: bundle)
        }
        #if DEBUG
        let root = projectRoot ?? self.projectRoot()
        let sourceRunner = root.appendingPathComponent("scripts/run-node.mjs")
        guard FileManager().isReadableFile(atPath: sourceRunner.path) else {
            throw MacNodeHostWorker.WorkerError.unavailable(reason: "Development worker source runner is missing")
        }
        switch await self.runtimeResolution(searchPaths: searchPaths) {
        case let .success(runtime):
            return MacNodeHostWorkerLaunch(
                command: self.nodeHostWorkerCommand(
                    prefix: [runtime.path, sourceRunner.path]),
                currentDirectoryURL: root)
        case let .failure(error):
            throw error
        }
        #else
        throw MacNodeHostWorker.WorkerError.unavailable(reason: "The node worker requires a packaged OpenClaw.app")
        #endif
    }

    static func nodeHostWorkerCommand(
        prefix: [String],
        profile: AppProfile = .current) -> [String]
    {
        profile.localCLICommand(prefix: prefix, arguments: ["node", "worker"])
    }

    static func openclawNodeCommand(
        subcommand: String,
        extraArgs: [String] = [],
        defaults: UserDefaults = AppDefaults.standard,
        configRoot: [String: Any]? = nil,
        searchPaths: [String]? = nil,
        projectRoot: URL? = nil,
        profile: AppProfile = .current) async -> [String]
    {
        let settings = self.connectionSettings(defaults: defaults, configRoot: configRoot)
        if settings.mode == .remote, settings.transport == .ssh {
            guard let ssh = sshNodeCommand(
                subcommand: subcommand,
                extraArgs: extraArgs,
                settings: settings)
            else {
                return self.errorCommand(with: "Remote SSH gateway target is missing or invalid.")
            }
            return ssh
        }

        let root = projectRoot ?? self.projectRoot()
        if let openclawPath = projectOpenClawExecutable(projectRoot: root) {
            return profile.localCLICommand(prefix: [openclawPath], arguments: [subcommand] + extraArgs)
        }
        if let openclawPath = openclawExecutable(searchPaths: searchPaths) {
            return profile.localCLICommand(prefix: [openclawPath], arguments: [subcommand] + extraArgs)
        }

        let runtimeResult = await self.runtimeResolution(searchPaths: searchPaths)
        switch runtimeResult {
        case let .success(runtime):
            if let entry = gatewayEntrypoint(in: root) {
                return self.makeRuntimeCommand(
                    runtime: runtime,
                    entrypoint: entry,
                    subcommand: subcommand,
                    extraArgs: extraArgs,
                    profile: profile)
            }
        case .failure:
            break
        }

        if let pnpm = findExecutable(named: "pnpm", searchPaths: searchPaths) {
            // Use --silent to avoid pnpm lifecycle banners that would corrupt JSON outputs.
            return profile.localCLICommand(
                prefix: [pnpm, "--silent", "openclaw"],
                arguments: [subcommand] + extraArgs)
        }

        switch runtimeResult {
        case .success:
            let missingEntry = """
            openclaw CLI not found. Install the CLI, or run pnpm build in an OpenClaw source checkout.
            """
            return self.errorCommand(with: missingEntry)
        case let .failure(error):
            return self.runtimeErrorCommand(error)
        }
    }

    static func openclawCommand(
        subcommand: String,
        extraArgs: [String] = [],
        defaults: UserDefaults = AppDefaults.standard,
        configRoot: [String: Any]? = nil,
        searchPaths: [String]? = nil,
        projectRoot: URL? = nil,
        profile: AppProfile = .current) async -> [String]
    {
        await self.openclawNodeCommand(
            subcommand: subcommand,
            extraArgs: extraArgs,
            defaults: defaults,
            configRoot: configRoot,
            searchPaths: searchPaths,
            projectRoot: projectRoot,
            profile: profile)
    }

    // MARK: - SSH helpers

    static func sshEnvironment(
        base: [String: String] = ProcessInfo.processInfo.environment,
        searchPaths: [String]? = nil) -> [String: String]
    {
        var environment = base
        environment["PATH"] = (searchPaths ?? self.preferredPaths()).joined(separator: ":")
        return environment
    }

    private static func sshNodeCommand(subcommand: String, extraArgs: [String], settings: RemoteSettings) -> [String]? {
        guard !settings.target.isEmpty else { return nil }
        guard let parsed = parseSSHTarget(settings.target) else { return nil }

        // Run the real openclaw CLI on the remote host.
        let exportedPath = [
            "/opt/homebrew/bin",
            "/usr/local/bin",
            "/usr/bin",
            "/bin",
            "/usr/sbin",
            "/sbin",
            "$HOME/Library/pnpm",
            "$PATH",
        ].joined(separator: ":")
        let quotedArgs = ([subcommand] + extraArgs).map(self.shellQuote).joined(separator: " ")
        let userPRJ = settings.projectRoot.trimmingCharacters(in: .whitespacesAndNewlines)
        let userCLI = settings.cliPath.trimmingCharacters(in: .whitespacesAndNewlines)

        let projectSection = if userPRJ.isEmpty {
            """
            DEFAULT_PRJ="$HOME/Projects/openclaw"
            if [ -d "$DEFAULT_PRJ" ]; then
              PRJ="$DEFAULT_PRJ"
              cd "$PRJ" || { echo "Project root not found: $PRJ"; exit 127; }
            fi
            """
        } else {
            """
            PRJ=\(self.shellQuote(userPRJ))
            cd "$PRJ" || { echo "Project root not found: $PRJ"; exit 127; }
            """
        }

        let cliSection = if userCLI.isEmpty {
            ""
        } else {
            """
            CLI_HINT=\(self.shellQuote(userCLI))
            if [ -n "$CLI_HINT" ]; then
              if [ -x "$CLI_HINT" ]; then
                CLI="$CLI_HINT"
                "$CLI_HINT" \(quotedArgs);
                exit $?;
              elif [ -f "$CLI_HINT" ]; then
                if command -v node >/dev/null 2>&1; then
                  CLI="node $CLI_HINT"
                  node "$CLI_HINT" \(quotedArgs);
                  exit $?;
                fi
              fi
            fi
            """
        }

        let scriptBody = """
        PATH=\(exportedPath);
        CLI="";
        \(cliSection)
        \(projectSection)
        if command -v openclaw >/dev/null 2>&1; then
          CLI="$(command -v openclaw)"
          openclaw \(quotedArgs);
        elif [ -n "${PRJ:-}" ] && [ -f "$PRJ/dist/index.js" ]; then
          if command -v node >/dev/null 2>&1; then
            CLI="node $PRJ/dist/index.js"
            node "$PRJ/dist/index.js" \(quotedArgs);
          else
            echo "Node >=22 required on remote host"; exit 127;
          fi
        elif [ -n "${PRJ:-}" ] && [ -f "$PRJ/openclaw.mjs" ]; then
          if command -v node >/dev/null 2>&1; then
            CLI="node $PRJ/openclaw.mjs"
            node "$PRJ/openclaw.mjs" \(quotedArgs);
          else
            echo "Node >=22 required on remote host"; exit 127;
          fi
        elif [ -n "${PRJ:-}" ] && [ -f "$PRJ/bin/openclaw.js" ]; then
          if command -v node >/dev/null 2>&1; then
            CLI="node $PRJ/bin/openclaw.js"
            node "$PRJ/bin/openclaw.js" \(quotedArgs);
          else
            echo "Node >=22 required on remote host"; exit 127;
          fi
        elif command -v pnpm >/dev/null 2>&1; then
          CLI="pnpm --silent openclaw"
          pnpm --silent openclaw \(quotedArgs);
        else
          echo "openclaw CLI missing on remote host"; exit 127;
        fi
        """
        // Remote credentials require strict host verification unless config explicitly opts into OpenSSH policy.
        let options: [String] = [
            "-o", "BatchMode=yes",
        ] + settings.sshHostKeyPolicy.commandOptions
        let args = self.sshArguments(
            target: parsed,
            identity: settings.identity,
            options: options,
            remoteCommand: ["/bin/sh", "-c", scriptBody])
        return ["/usr/bin/ssh"] + args
    }

    enum SSHHostKeyPolicy: String, Sendable {
        case strict
        case openssh

        var hostKeyOptions: [String] {
            switch self {
            case .strict:
                [
                    "-o", "StrictHostKeyChecking=yes",
                    "-o", "UpdateHostKeys=yes",
                ]
            case .openssh:
                []
            }
        }

        var commandOptions: [String] {
            [
                "-o", "ControlMaster=no",
                "-o", "ControlPath=none",
                "-o", "ControlPersist=no",
                "-o", "ForkAfterAuthentication=no",
            ] + self.hostKeyOptions
        }
    }

    struct RemoteSettings {
        let mode: AppState.ConnectionMode
        let transport: AppState.RemoteTransport
        let target: String
        let identity: String
        let projectRoot: String
        let cliPath: String
        let sshHostKeyPolicy: SSHHostKeyPolicy
    }

    static func connectionSettings(
        defaults: UserDefaults = AppDefaults.standard,
        configRoot: [String: Any]? = nil) -> RemoteSettings
    {
        let root = configRoot ?? OpenClawConfigFile.loadDict()
        let mode = ConnectionModeResolver.resolve(root: root, defaults: defaults).mode
        let transport = GatewayRemoteConfig.resolveTransport(root: root)
        let remote = (root["gateway"] as? [String: Any])?["remote"] as? [String: Any]
        let hasConfiguredTarget = remote?.keys.contains("sshTarget") == true
        let configuredTarget = self.sanitizedTarget(remote?["sshTarget"] as? String ?? "")
        // Canonical config wins after an offline edit. UserDefaults remains the
        // compatibility fallback for older configs that never stored SSH fields.
        let target = hasConfiguredTarget
            ? configuredTarget
            : self.sanitizedTarget(defaults.string(forKey: remoteTargetKey) ?? "")
        let hasConfiguredIdentity = remote?.keys.contains("sshIdentity") == true
        let configuredIdentity = (remote?["sshIdentity"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let identity = hasConfiguredIdentity
            ? configuredIdentity
            : defaults.string(forKey: remoteIdentityKey)?.nonEmpty ?? ""
        let projectRoot = defaults.string(forKey: remoteProjectRootKey)?.nonEmpty ?? ""
        let cliPath = defaults.string(forKey: remoteCliPathKey)?.nonEmpty ?? ""
        let rawHostKeyPolicy = remote?["sshHostKeyPolicy"] as? String
        let configuredHostKeyPolicy = rawHostKeyPolicy.flatMap(SSHHostKeyPolicy.init(rawValue:)) ?? .strict
        let sshHostKeyPolicy: SSHHostKeyPolicy = if configuredHostKeyPolicy == .openssh,
                                                    !target.isEmpty,
                                                    target == configuredTarget
        {
            .openssh
        } else {
            .strict
        }
        return RemoteSettings(
            mode: mode,
            transport: transport,
            target: target,
            identity: identity,
            projectRoot: projectRoot,
            cliPath: cliPath,
            sshHostKeyPolicy: sshHostKeyPolicy)
    }

    static func connectionModeIsRemote(defaults: UserDefaults = AppDefaults.standard) -> Bool {
        self.connectionSettings(defaults: defaults).mode == .remote
    }

    private static func sanitizedTarget(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("ssh ") {
            return trimmed.replacingOccurrences(of: "ssh ", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return trimmed
    }

    struct SSHParsedTarget: Equatable, Sendable {
        let user: String?
        let host: String
        let port: Int
    }

    static func parseSSHTarget(_ target: String) -> SSHParsedTarget? {
        let trimmed = self.normalizeSSHTargetInput(target)
        guard !trimmed.isEmpty else { return nil }
        if trimmed.rangeOfCharacter(from: CharacterSet.whitespacesAndNewlines.union(.controlCharacters)) != nil {
            return nil
        }
        let userHostPort: String
        let user: String?
        if let atRange = trimmed.range(of: "@") {
            user = String(trimmed[..<atRange.lowerBound])
            userHostPort = String(trimmed[atRange.upperBound...])
        } else {
            user = nil
            userHostPort = trimmed
        }

        let host: String
        let port: Int
        if let colon = userHostPort.lastIndex(of: ":"), colon != userHostPort.startIndex {
            host = String(userHostPort[..<colon])
            let portStr = String(userHostPort[userHostPort.index(after: colon)...])
            guard let parsedPort = Int(portStr), parsedPort > 0, parsedPort <= 65535 else {
                return nil
            }
            port = parsedPort
        } else {
            host = userHostPort
            port = 22
        }

        return self.makeSSHTarget(user: user, host: host, port: port)
    }

    static func sshTargetValidationMessage(_ target: String) -> String? {
        let trimmed = self.normalizeSSHTargetInput(target)
        guard !trimmed.isEmpty else { return nil }
        if trimmed.hasPrefix("-") {
            return "SSH target cannot start with '-'"
        }
        if trimmed.rangeOfCharacter(from: CharacterSet.whitespacesAndNewlines.union(.controlCharacters)) != nil {
            return "SSH target cannot contain spaces"
        }
        if self.parseSSHTarget(trimmed) == nil {
            return "SSH target must look like user@host[:port]"
        }
        return nil
    }

    private static func shellQuote(_ text: String) -> String {
        if text.isEmpty { return "''" }
        let escaped = text.replacingOccurrences(of: "'", with: "'\\''")
        return "'\(escaped)'"
    }

    private static func expandPath(_ path: String) -> URL? {
        var expanded = path
        if expanded.hasPrefix("~") {
            let home = FileManager().homeDirectoryForCurrentUser.path
            expanded.replaceSubrange(expanded.startIndex...expanded.startIndex, with: home)
        }
        return URL(fileURLWithPath: expanded)
    }

    private static func normalizeSSHTargetInput(_ target: String) -> String {
        var trimmed = target.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("ssh ") {
            trimmed = trimmed.replacingOccurrences(of: "ssh ", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return trimmed
    }

    private static func isValidSSHComponent(_ value: String, allowLeadingDash: Bool = false) -> Bool {
        if value.isEmpty { return false }
        if !allowLeadingDash, value.hasPrefix("-") { return false }
        let invalid = CharacterSet.whitespacesAndNewlines.union(.controlCharacters)
        return value.rangeOfCharacter(from: invalid) == nil
    }

    static func makeSSHTarget(user: String?, host: String, port: Int) -> SSHParsedTarget? {
        let trimmedHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard self.isValidSSHComponent(trimmedHost) else { return nil }
        let trimmedUser = user?.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedUser: String?
        if let trimmedUser {
            guard self.isValidSSHComponent(trimmedUser) else { return nil }
            normalizedUser = trimmedUser.isEmpty ? nil : trimmedUser
        } else {
            normalizedUser = nil
        }
        guard port > 0, port <= 65535 else { return nil }
        return SSHParsedTarget(user: normalizedUser, host: trimmedHost, port: port)
    }

    private static func sshTargetString(_ target: SSHParsedTarget) -> String {
        target.user.map { "\($0)@\(target.host)" } ?? target.host
    }

    static func sshArguments(
        target: SSHParsedTarget,
        identity: String,
        options: [String],
        remoteCommand: [String] = []) -> [String]
    {
        var args = options
        if target.port > 0 {
            args.append(contentsOf: ["-p", String(target.port)])
        }
        let trimmedIdentity = identity.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedIdentity.isEmpty {
            // Only use IdentitiesOnly when an explicit identity file is provided.
            // This allows 1Password SSH agent and other SSH agents to provide keys.
            args.append(contentsOf: ["-o", "IdentitiesOnly=yes"])
            args.append(contentsOf: ["-i", trimmedIdentity])
        }
        args.append("--")
        args.append(self.sshTargetString(target))
        args.append(contentsOf: remoteCommand)
        return args
    }
}
