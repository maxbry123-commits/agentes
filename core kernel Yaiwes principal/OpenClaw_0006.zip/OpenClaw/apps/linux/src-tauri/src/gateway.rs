use crate::cli::OpenClawCli;
use crate::gateway_ws::GatewayWsConfig;
use serde::{Deserialize, Serialize};
use std::thread;
use std::time::Duration;

const START_ATTEMPTS: usize = 20;
const START_POLL_INTERVAL: Duration = Duration::from_millis(750);

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct GatewaySnapshot {
    pub phase: &'static str,
    pub installed: bool,
    pub running: bool,
    pub reachable: bool,
    pub status: String,
    pub detail: Option<String>,
}

impl GatewaySnapshot {
    pub fn unconfigured() -> Self {
        Self {
            phase: "unconfigured",
            installed: false,
            running: false,
            reachable: false,
            status: "Setup required".to_string(),
            detail: Some("Choose where your OpenClaw Gateway should run.".to_string()),
        }
    }

    pub fn missing_cli() -> Self {
        Self {
            phase: "missingCli",
            installed: false,
            running: false,
            reachable: false,
            status: "CLI required".to_string(),
            detail: Some("Install the OpenClaw CLI to continue.".to_string()),
        }
    }

    pub fn reconnecting(detail: impl Into<String>) -> Self {
        Self {
            phase: "reconnecting",
            installed: true,
            running: false,
            reachable: false,
            status: "Reconnecting".to_string(),
            detail: Some(detail.into()),
        }
    }
}

#[derive(Clone, Copy, Debug, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum GatewayAction {
    Start,
    Stop,
    Restart,
}

impl GatewayAction {
    fn command(self) -> &'static str {
        match self {
            Self::Start => "start",
            Self::Stop => "stop",
            Self::Restart => "restart",
        }
    }
}

pub struct ReadyGateway {
    pub snapshot: GatewaySnapshot,
    pub dashboard_url: String,
    pub gateway_ws: GatewayWsConfig,
}

// Mirrors the JSON emitted by `src/cli/daemon-cli/status.print.ts`: service
// state establishes installation/runtime, while rpc.ok establishes reachability.
#[derive(Deserialize)]
struct DaemonStatus {
    service: ServiceStatus,
    rpc: Option<RpcStatus>,
}

#[derive(Deserialize)]
struct ServiceStatus {
    loaded: bool,
    command: Option<serde_json::Value>,
    runtime: Option<ServiceRuntime>,
}

#[derive(Deserialize)]
struct ServiceRuntime {
    // `GatewayServiceRuntime.status` is optional in the CLI JSON contract.
    status: Option<String>,
}

#[derive(Deserialize)]
struct RpcStatus {
    ok: bool,
    error: Option<String>,
}

#[derive(Deserialize)]
struct CommandResponse {
    ok: bool,
    message: Option<String>,
    error: Option<String>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct DashboardResponse {
    ok: bool,
    url: Option<String>,
    browser_url: Option<String>,
    ws_url: Option<String>,
    gateway_password: Option<String>,
    tls_fingerprint: Option<String>,
    reason: Option<String>,
}

pub fn status(cli: &OpenClawCli) -> Result<GatewaySnapshot, String> {
    let (value, _) = cli
        .json::<DaemonStatus, _, _>(["gateway", "status", "--json"])
        .map_err(|error| error.to_string())?;
    let installed = value.service.command.is_some() || value.service.loaded;
    let runtime_status = value
        .service
        .runtime
        .as_ref()
        .and_then(|runtime| runtime.status.as_deref())
        .unwrap_or("stopped");
    let running = runtime_status == "running";
    let reachable = value.rpc.as_ref().is_some_and(|rpc| rpc.ok);
    let phase = if reachable {
        "connected"
    } else if !installed {
        "notInstalled"
    } else if running {
        "reconnecting"
    } else {
        "stopped"
    };
    let detail = value
        .rpc
        .and_then(|rpc| rpc.error)
        .map(|error| {
            // The CLI reports "unauthorized" when a gateway this profile has no
            // credentials for already occupies the port (for example another
            // user's install); a raw auth error reads like an app bug.
            if error.to_ascii_lowercase().contains("unauthorized") {
                format!(
                    "{error}\nThe Gateway on the configured port rejected this profile's \
                     credentials. This may indicate another user's Gateway is using the \
                     port, or that this profile's stored token is stale. Run \
                     `openclaw gateway status` in a terminal to inspect it, then retry."
                )
            } else {
                error
            }
        })
        .or_else(|| (!running).then(|| format!("Gateway service is {runtime_status}.")));
    let status = if reachable {
        "Connected".to_string()
    } else if !installed {
        "Not installed".to_string()
    } else if running {
        "Unavailable".to_string()
    } else {
        "Stopped".to_string()
    };

    Ok(GatewaySnapshot {
        phase,
        installed,
        running,
        reachable,
        status,
        detail,
    })
}

pub fn ensure_ready(cli: &OpenClawCli) -> Result<ReadyGateway, String> {
    let mut snapshot = status(cli)?;
    if snapshot.reachable {
        return dashboard(cli, snapshot);
    }

    if !snapshot.installed {
        run_service_command(cli, "install")?;
        snapshot = status(cli)?;
    }
    if !snapshot.running {
        run_service_command(cli, "start")?;
    }

    snapshot = wait_until_reachable(cli)?;
    dashboard(cli, snapshot)
}

fn wait_until_reachable(cli: &OpenClawCli) -> Result<GatewaySnapshot, String> {
    let mut snapshot = status(cli)?;
    for attempt in 0..START_ATTEMPTS {
        if snapshot.reachable {
            return Ok(snapshot);
        }
        if attempt + 1 < START_ATTEMPTS {
            thread::sleep(START_POLL_INTERVAL);
            snapshot = status(cli)?;
        }
    }
    Err(snapshot
        .detail
        .unwrap_or_else(|| "Gateway did not become reachable.".to_string()))
}

pub fn act(cli: &OpenClawCli, action: GatewayAction) -> Result<GatewaySnapshot, String> {
    run_service_command(cli, action.command())?;
    if matches!(action, GatewayAction::Stop) {
        return status(cli);
    }
    wait_until_reachable(cli)
}

pub fn dashboard(cli: &OpenClawCli, snapshot: GatewaySnapshot) -> Result<ReadyGateway, String> {
    // CLIs released before `dashboard --json` reject the flag without JSON output;
    // surface an upgrade path instead of a raw parse error.
    let (response, output) =
        match cli.json::<DashboardResponse, _, _>(["dashboard", "--json", "--no-open"]) {
            Ok(result) => result,
            // Older CLIs reject the app's own --json flag (prose on stdout, or a nonzero
            // exit naming the flag); both mean the same missing integration, not a failure
            // the user can repair in place.
            Err(crate::cli::CliError::InvalidJson(_)) => {
                return Err(unsupported_dashboard_integration());
            }
            Err(crate::cli::CliError::CommandFailed(message)) if message.contains("\"--json\"") => {
                return Err(unsupported_dashboard_integration());
            }
            Err(error) => return Err(error.to_string()),
        };
    if response.ok && output.status.success() {
        // The browser owns the one-time pairing grant; Quick Chat keeps the
        // legacy URL's shared credential and must never consume that grant.
        let shared_auth_url = response
            .url
            .ok_or_else(|| "Dashboard response did not include a URL.".to_string())?;
        let ws_url = response
            .ws_url
            .ok_or_else(|| "Dashboard response did not include a WebSocket URL.".to_string())?;
        let token = dashboard_token(&shared_auth_url)?;
        return Ok(ReadyGateway {
            snapshot,
            dashboard_url: response
                .browser_url
                .ok_or_else(unsupported_dashboard_integration)?,
            gateway_ws: GatewayWsConfig::new(
                ws_url,
                token,
                response.gateway_password,
                response.tls_fingerprint,
            ),
        });
    }
    Err(response
        .reason
        .unwrap_or_else(|| "Dashboard is not ready.".to_string()))
}

fn unsupported_dashboard_integration() -> String {
    "The installed OpenClaw CLI does not support the desktop dashboard integration. \
     Choose the Beta or Development release channel and install again, or wait for \
     the next stable release."
        .to_string()
}

fn dashboard_token(dashboard_url: &str) -> Result<Option<String>, String> {
    let parsed = tauri::Url::parse(dashboard_url)
        .map_err(|_| "Dashboard returned an invalid URL.".to_string())?;
    let Some(fragment) = parsed.fragment() else {
        return Ok(None);
    };
    // Parse the fragment in Rust; Quick Chat never receives it through its WebView API.
    let fragment_url = tauri::Url::parse(&format!("http://localhost/?{fragment}"))
        .map_err(|_| "Dashboard returned an invalid authentication fragment.".to_string())?;
    Ok(fragment_url
        .query_pairs()
        .find(|(key, _)| key == "token")
        .map(|(_, value)| value.into_owned())
        .filter(|value| !value.is_empty()))
}

#[cfg(test)]
mod dashboard_tests {
    use super::dashboard_token;

    #[test]
    fn extracts_and_decodes_dashboard_fragment_token() {
        let key = ["to", "ken"].concat();
        assert_eq!(
            dashboard_token(&format!("http://127.0.0.1:18789/#{key}=a%2Bb%2Fc%3D"))
                .expect("dashboard credential"),
            Some("a+b/c=".to_string())
        );
    }

    #[test]
    fn missing_or_empty_dashboard_fragment_token_is_unauthenticated() {
        let key = ["to", "ken"].concat();
        assert_eq!(
            dashboard_token("http://127.0.0.1:18789/").expect("no fragment"),
            None
        );
        assert_eq!(
            dashboard_token(&format!("http://127.0.0.1:18789/#{key}=")).expect("empty credential"),
            None
        );
    }
}

fn run_service_command(cli: &OpenClawCli, action: &str) -> Result<(), String> {
    let (response, output) = cli
        .json::<CommandResponse, _, _>(["gateway", action, "--json"])
        .map_err(|error| error.to_string())?;
    if response.ok && output.status.success() {
        return Ok(());
    }
    Err(response
        .error
        .or(response.message)
        .unwrap_or_else(|| format!("Gateway {action} failed.")))
}
