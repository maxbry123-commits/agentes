// Copyright IBM Corp. 2015, 2026
// SPDX-License-Identifier: BUSL-1.1

package command

import (
	"fmt"
	"strings"

	"github.com/hashicorp/nomad/api"
	"github.com/posener/complete"
)

type JobAllocsCommand struct {
	Meta
}

func (c *JobAllocsCommand) Help() string {
	helpText := `
Usage: nomad job allocs [options] <job>

  Display allocations for a particular job.

  When ACLs are enabled, this command requires a token with the 'read-job'
  capability for the job's namespace. The 'list-jobs' capability is required to
  run the command with a job prefix instead of the exact job ID.

General Options:

  ` + generalOptionsUsage(usageOptsDefault) + `

Allocs Options:

  -all
    Display all allocations matching the job ID, even those from an older
    instance of the job.

  -json
    Output the allocations in a JSON format.

  -t
    Format and display allocations using a Go template.

  -verbose
    Display full information.
`
	return strings.TrimSpace(helpText)
}

func (c *JobAllocsCommand) Synopsis() string {
	return "List allocations for a job"
}

func (c *JobAllocsCommand) AutocompleteFlags() complete.Flags {
	return mergeAutocompleteFlags(c.Meta.AutocompleteFlags(FlagSetClient),
		complete.Flags{
			"-json":    complete.PredictNothing,
			"-t":       complete.PredictAnything,
			"-verbose": complete.PredictNothing,
			"-all":     complete.PredictNothing,
		})
}

func (c *JobAllocsCommand) AutocompleteArgs() complete.Predictor {
	return JobPredictor(c.Meta.Client)
}

func (c *JobAllocsCommand) Name() string { return "job allocs" }

func (c *JobAllocsCommand) Run(args []string) int {
	var json, verbose, all bool
	var tmpl string

	flags := c.Meta.FlagSet(c.Name(), FlagSetClient)
	flags.Usage = func() { c.Ui.Output(c.Help()) }
	flags.BoolVar(&verbose, "verbose", false, "")
	flags.BoolVar(&all, "all", false, "")
	flags.BoolVar(&json, "json", false, "")
	flags.StringVar(&tmpl, "t", "", "")

	if err := flags.Parse(args); err != nil {
		return 1
	}

	// Check that we got exactly one job
	args = flags.Args()
	if len(args) != 1 {
		c.Ui.Error("This command takes one argument: <job>")
		c.Ui.Error(commandErrorText(c))
		return 1
	}

	// Get the HTTP client
	client, err := c.Meta.Client()
	if err != nil {
		c.Ui.Error(fmt.Sprintf("Error initializing client: %s", err))
		return 1
	}

	// Check if the job exists
	jobIDPrefix := strings.TrimSpace(args[0])
	jobID, namespace, err := c.JobIDByPrefix(client, jobIDPrefix)
	if err != nil {
		c.Ui.Error(err.Error())
		return 1
	}

	q := &api.QueryOptions{Namespace: namespace}

	// Fetch job info to enrich allocations output (e.g. Max Run Deadline
	// column). This is best-effort: when the jobID was returned as a raw
	// prefix by JobIDByPrefix (e.g. because the token lacks list-jobs), the
	// Info call may fail. In that case we continue with a nil job so that
	// formatJobAllocListStubs still works — it omits the deadline column.
	job, _, err := client.Jobs().Info(jobID, q)
	if err != nil && strings.Contains(err.Error(), api.PermissionDeniedErrorContent) {
		c.Ui.Error(fmt.Sprintf("Error querying job: %s", err))
		return 1
	}

	allocs, _, err := client.Jobs().Allocations(jobID, all, q)
	if err != nil {
		c.Ui.Error(fmt.Sprintf("Error retrieving allocations: %s", err))
		return 1
	}

	if json || len(tmpl) > 0 {
		out, err := Format(json, tmpl, allocs)
		if err != nil {
			c.Ui.Error(err.Error())
			return 1
		}

		c.Ui.Output(out)
		return 0
	}

	// Truncate the id unless full length is requested
	length := shortId
	if verbose {
		length = fullId
	}

	c.Ui.Output(formatJobAllocListStubs(allocs, job, verbose, length))
	return 0
}
