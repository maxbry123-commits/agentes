/**
 * Copyright IBM Corp. 2015, 2026
 * SPDX-License-Identifier: BUSL-1.1
 */

import { Model, belongsTo } from 'miragejs';

export default Model.extend({
  job: belongsTo(),
  node: belongsTo(),
});
