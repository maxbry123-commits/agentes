/**
 * Copyright IBM Corp. 2015, 2026
 * SPDX-License-Identifier: BUSL-1.1
 */

import { Model, hasMany } from 'miragejs';

export default Model.extend({
  policies: hasMany(),
  roles: hasMany(),
});
