#!/bin/bash
set -exo pipefail

# Contains OS specific sed function
. utils.sh

usage() {
  cat <<'EOF'
Usage: newCloudLoadTest.sh <namespace>

Arguments:
  namespace          Base namespace name. Will be prefixed with "c8-" if missing.

Options:
  -h, --help         Show this help message.

Examples:
  ./newCloudLoadTest.sh demo
  ./newCloudLoadTest.sh c8-demo
EOF
}

if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
  usage
  exit 0
fi

if [ -z "$1" ]; then
  echo "Error: Missing namespace name."
  usage
  exit 1
fi

### Cloud load test helper script
### First parameter is used as namespace name
### For a new namespace a new folder will be created


namespace=$1

# Add c8- prefix if not present
if [[ ! "$namespace" =~ ^c8- ]]; then
  namespace="c8-$namespace"
  echo "Namespace prefix added: $namespace"
fi

kubectl create namespace $namespace

# Label namespace with registry (required to inject image pull secrets)
kubectl label namespace "$namespace" registry=harbor --overwrite

# Label namespace with author and purpose
git_author=$(compute_git_author)
kubectl label namespace "$namespace" camunda.io/purpose=load-test --overwrite
kubectl label namespace "$namespace" camunda.io/created-by="$git_author" --overwrite

cp -rv saas-default/ $namespace
# Derive the SaaS realistic-benchmark values from the single shared source.
# The SaaS setup installs the camunda-load-tests chart standalone, so it needs
# the values at the top level; strip the `load-tester` wrapper that the
# self-managed umbrella (load-test-setup) chart requires around the subchart.
yq '.load-tester' scenarios/load-tester-values-realistic-benchmark.yaml > "$namespace/load-test-values-realistic-benchmark.yaml"
cd $namespace


# Update Makefile to use the namespace
sed_inplace "s/__NAMESPACE__/$namespace/" Makefile

# Inject the author as a real Helm value. The Makefile passes this via -f alongside
# load-test-values.yaml, so it deep-merges into global.commonLabels rather than
# being baked into a committed file.
cat <<EOF > load-test-values-generated.yaml
global:
  commonLabels:
    camunda.io/created-by: "$git_author"
EOF
