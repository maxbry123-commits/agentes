// Session model override tests cover model override parsing and validation.
import { describe, expect, it } from "vitest";
import type { SessionEntry } from "../config/sessions.js";
import {
  applyModelOverrideToSessionEntry,
  MODEL_SELECTION_LOCKED_MESSAGE,
  ModelSelectionLockedError,
  repairProviderWrappedModelOverride,
} from "./model-overrides.js";

function applyOpenAiSelection(entry: SessionEntry) {
  return applyModelOverrideToSessionEntry({
    entry,
    selection: {
      provider: "openai",
      model: "gpt-5.4",
    },
  });
}

function expectRuntimeModelFieldsCleared(entry: SessionEntry, before: number) {
  expect(entry.providerOverride).toBe("openai");
  expect(entry.modelOverride).toBe("gpt-5.4");
  expect(entry.modelProvider).toBeUndefined();
  expect(entry.model).toBeUndefined();
  expect((entry.updatedAt ?? 0) > before).toBe(true);
}

function contextBudgetStatus(params: {
  updatedAt: number;
  provider: string;
  model: string;
  contextTokenBudget: number;
}): NonNullable<SessionEntry["contextBudgetStatus"]> {
  return {
    schemaVersion: 1,
    source: "pre-prompt-estimate",
    updatedAt: params.updatedAt,
    provider: params.provider,
    model: params.model,
    route: "fits",
    shouldCompact: false,
    estimatedPromptTokens: Math.floor(params.contextTokenBudget * 0.6),
    contextTokenBudget: params.contextTokenBudget,
    promptBudgetBeforeReserve: params.contextTokenBudget - 10_000,
    reserveTokens: 10_000,
    effectiveReserveTokens: 10_000,
    remainingPromptBudgetTokens: Math.floor(params.contextTokenBudget * 0.4),
    overflowTokens: 0,
    toolResultReducibleChars: 0,
    messageCount: 2,
    unwindowedMessageCount: 2,
  };
}

describe("applyModelOverrideToSessionEntry", () => {
  it("rejects locked session model mutations before changing any fields", () => {
    const entry: SessionEntry = {
      sessionId: "sess-locked",
      updatedAt: 10,
      providerOverride: "openai",
      modelOverride: "gpt-5.4",
      modelSelectionLocked: true,
    };
    const before = { ...entry };

    expect(() =>
      applyModelOverrideToSessionEntry({
        entry,
        selection: {
          provider: "anthropic",
          model: "claude-sonnet-4-6",
        },
      }),
    ).toThrow(ModelSelectionLockedError);
    expect(() =>
      applyModelOverrideToSessionEntry({
        entry,
        selection: {
          provider: "openai",
          model: "gpt-5.4",
          isDefault: true,
        },
      }),
    ).toThrow(MODEL_SELECTION_LOCKED_MESSAGE);
    expect(entry).toEqual(before);
  });

  it("clears stale runtime model fields when switching overrides", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-1",
      updatedAt: before,
      modelProvider: "anthropic",
      model: "claude-sonnet-4-6",
      providerOverride: "anthropic",
      modelOverride: "claude-sonnet-4-6",
      contextTokens: 160_000,
      contextTokensSource: "runtime",
      contextBudgetStatus: contextBudgetStatus({
        updatedAt: before,
        provider: "anthropic",
        model: "claude-sonnet-4-6",
        contextTokenBudget: 200_000,
      }),
      fallbackNotice: {
        kind: "active",
        selectedModel: "anthropic/claude-sonnet-4-6",
        activeModel: "anthropic/claude-sonnet-4-6",
        reason: "provider temporary failure",
      },
    };

    const result = applyOpenAiSelection(entry);

    expect(result.updated).toBe(true);
    expectRuntimeModelFieldsCleared(entry, before);
    expect(entry.contextTokens).toBeUndefined();
    expect(entry.contextTokensSource).toBeUndefined();
    expect(entry.contextBudgetStatus).toBeUndefined();
    expect(entry.fallbackNotice).toBeUndefined();
    expect(entry.modelOverrideSource).toBe("user");
    expect(entry.modelOverrideRouteResolution).toBe("resolved");
  });

  it("clears stale runtime model fields even when override selection is unchanged", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-2",
      updatedAt: before,
      modelProvider: "anthropic",
      model: "claude-sonnet-4-6",
      providerOverride: "openai",
      modelOverride: "gpt-5.4",
      contextTokens: 160_000,
      contextBudgetStatus: contextBudgetStatus({
        updatedAt: before,
        provider: "anthropic",
        model: "claude-sonnet-4-6",
        contextTokenBudget: 200_000,
      }),
    };

    const result = applyOpenAiSelection(entry);

    expect(result.updated).toBe(true);
    expectRuntimeModelFieldsCleared(entry, before);
    expect(entry.contextTokens).toBeUndefined();
    expect(entry.contextBudgetStatus).toBeUndefined();
  });

  it("retains aligned runtime model fields when selection and runtime already match", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-3",
      updatedAt: before,
      modelProvider: "openai",
      model: "gpt-5.4",
      providerOverride: "openai",
      modelOverride: "gpt-5.4",
      contextTokens: 200_000,
      contextTokensSource: "runtime",
      contextBudgetStatus: contextBudgetStatus({
        updatedAt: before,
        provider: "openai",
        model: "gpt-5.4",
        contextTokenBudget: 200_000,
      }),
    };

    const result = applyModelOverrideToSessionEntry({
      entry,
      selection: {
        provider: "openai",
        model: "gpt-5.4",
      },
    });

    expect(result.updated).toBe(true);
    expect(entry.modelProvider).toBe("openai");
    expect(entry.model).toBe("gpt-5.4");
    expect(entry.modelOverrideSource).toBe("user");
    expect(entry.contextTokens).toBe(200_000);
    expect(entry.contextTokensSource).toBe("runtime");
    expect(entry.contextBudgetStatus?.contextTokenBudget).toBe(200_000);
    expect((entry.updatedAt ?? 0) >= before).toBe(true);
  });

  it("clears stale contextTokens when switching back to the default model", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-4",
      updatedAt: before,
      providerOverride: "local",
      modelOverride: "sunapi386/llama-3-lexi-uncensored:8b",
      modelOverrideRouteResolution: "resolved",
      contextTokens: 4_096,
      contextBudgetStatus: contextBudgetStatus({
        updatedAt: before,
        provider: "local",
        model: "sunapi386/llama-3-lexi-uncensored:8b",
        contextTokenBudget: 4_096,
      }),
    };

    const result = applyModelOverrideToSessionEntry({
      entry,
      selection: {
        provider: "local",
        model: "llama3.1:8b",
        isDefault: true,
      },
    });

    expect(result.updated).toBe(true);
    expect(entry.providerOverride).toBeUndefined();
    expect(entry.modelOverride).toBeUndefined();
    expect(entry.modelOverrideSource).toBeUndefined();
    expect(entry.modelOverrideRouteResolution).toBeUndefined();
    expect(entry.contextTokens).toBeUndefined();
    expect(entry.contextBudgetStatus).toBeUndefined();
    expect((entry.updatedAt ?? 0) > before).toBe(true);
  });

  it("sets liveModelSwitchPending when switching to default with runtime-only fields", () => {
    const entry: SessionEntry = {
      sessionId: "sess-96269",
      updatedAt: Date.now() - 5_000,
      modelProvider: "anthropic",
      model: "claude-sonnet-4-6",
      contextTokens: 200_000,
      contextBudgetStatus: contextBudgetStatus({
        updatedAt: Date.now() - 5_000,
        provider: "anthropic",
        model: "claude-sonnet-4-6",
        contextTokenBudget: 200_000,
      }),
    };

    const result = applyModelOverrideToSessionEntry({
      entry,
      selection: {
        provider: "openai",
        model: "gpt-5.4",
        isDefault: true,
      },
      markLiveSwitchPending: true,
    });

    expect(result.updated).toBe(true);
    expect(entry.modelProvider).toBeUndefined();
    expect(entry.model).toBeUndefined();
    expect(entry.contextTokens).toBeUndefined();
    expect(entry.contextBudgetStatus).toBeUndefined();
    expect(entry.liveModelSwitchPending).toBe(true);
  });

  it("marks non-default overrides with the provided source", () => {
    const entry: SessionEntry = {
      sessionId: "sess-5a",
      updatedAt: Date.now() - 5_000,
    };

    const result = applyModelOverrideToSessionEntry({
      entry,
      selection: {
        provider: "anthropic",
        model: "claude-sonnet-4-6",
      },
      selectionSource: "auto",
    });

    expect(result.updated).toBe(true);
    expect(entry.providerOverride).toBe("anthropic");
    expect(entry.modelOverride).toBe("claude-sonnet-4-6");
    expect(entry.modelOverrideSource).toBe("auto");
    expect(entry.modelOverrideRouteResolution).toBe("resolved");
  });

  it("sets liveModelSwitchPending only when explicitly requested", () => {
    const entry: SessionEntry = {
      sessionId: "sess-5",
      updatedAt: Date.now() - 5_000,
      providerOverride: "anthropic",
      modelOverride: "claude-sonnet-4-6",
    };

    const withoutFlag = applyModelOverrideToSessionEntry({
      entry: { ...entry },
      selection: {
        provider: "openai",
        model: "gpt-5.4",
      },
    });
    expect(withoutFlag.updated).toBe(true);
    expect(entry.liveModelSwitchPending).toBeUndefined();

    const withFlagEntry: SessionEntry = { ...entry };
    const withFlag = applyModelOverrideToSessionEntry({
      entry: withFlagEntry,
      selection: {
        provider: "openai",
        model: "gpt-5.4",
      },
      markLiveSwitchPending: true,
    });
    expect(withFlag.updated).toBe(true);
    expect(withFlagEntry.liveModelSwitchPending).toBe(true);
  });

  it("marks profile-only switches as pending when requested", () => {
    const entry: SessionEntry = {
      sessionId: "sess-profile-switch",
      updatedAt: Date.now() - 5_000,
      providerOverride: "openai",
      modelOverride: "gpt-5.4",
      authProfileOverride: "oldprofile",
      authProfileOverrideSource: "user",
    };

    const result = applyModelOverrideToSessionEntry({
      entry,
      selection: {
        provider: "openai",
        model: "gpt-5.4",
      },
      profileOverride: "newprofile",
      markLiveSwitchPending: true,
    });

    expect(result.updated).toBe(true);
    expect(entry.authProfileOverride).toBe("newprofile");
    expect(entry.liveModelSwitchPending).toBe(true);
  });

  it.each([
    { preserveAuthProfileOverride: undefined, expectedProfile: undefined },
    { preserveAuthProfileOverride: false, expectedProfile: undefined },
    { preserveAuthProfileOverride: true, expectedProfile: "openai:work" },
  ])(
    "keeps auth profile metadata only when preservation is $preserveAuthProfileOverride",
    ({ preserveAuthProfileOverride, expectedProfile }) => {
      const entry: SessionEntry = {
        sessionId: "sess-profile-preservation-contract",
        updatedAt: Date.now() - 5_000,
        providerOverride: "openai",
        modelOverride: "gpt-5.4",
        authProfileOverride: "openai:work",
        authProfileOverrideSource: "user",
        authProfileOverrideCompactionCount: 2,
      };

      applyModelOverrideToSessionEntry({
        entry,
        selection: {
          provider: "openai",
          model: "gpt-4.1",
        },
        preserveAuthProfileOverride,
      });

      expect(entry.authProfileOverride).toBe(expectedProfile);
      expect(entry.authProfileOverrideSource).toBe(expectedProfile ? "user" : undefined);
      expect(entry.authProfileOverrideCompactionCount).toBe(expectedProfile ? 2 : undefined);
    },
  );
});

describe("repairProviderWrappedModelOverride", () => {
  it("rejects provider-wrapped repair for locked sessions without mutating them", () => {
    const entry: SessionEntry = {
      sessionId: "sess-locked-openrouter-repair",
      updatedAt: Date.now() - 5_000,
      providerOverride: "anthropic",
      modelOverride: "claude-haiku-4.5",
      modelOverrideSource: "user",
      modelProvider: "openrouter",
      model: "anthropic/claude-haiku-4.5",
      contextTokens: 200_000,
      modelSelectionLocked: true,
    };
    const before = { ...entry };

    expect(() =>
      repairProviderWrappedModelOverride({
        entry,
        defaultProvider: "openai",
        defaultModel: "gpt-5.4",
      }),
    ).toThrow(ModelSelectionLockedError);
    expect(entry).toEqual(before);
  });

  it("restores a provider-wrapped override from aligned runtime model fields", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-openrouter-repair-runtime",
      updatedAt: before,
      providerOverride: "anthropic",
      modelOverride: "claude-haiku-4.5",
      modelOverrideSource: "user",
      modelProvider: "openrouter",
      model: "anthropic/claude-haiku-4.5",
      contextTokens: 200_000,
    };

    const result = repairProviderWrappedModelOverride({
      entry,
      defaultProvider: "openai",
      defaultModel: "gpt-5.4",
    });

    expect(result.updated).toBe(true);
    expect(entry.providerOverride).toBe("openrouter");
    expect(entry.modelOverride).toBe("anthropic/claude-haiku-4.5");
    expect(entry.modelOverrideSource).toBe("user");
    expect(entry.modelProvider).toBeUndefined();
    expect(entry.model).toBeUndefined();
    expect(entry.contextTokens).toBeUndefined();
    expect((entry.updatedAt ?? 0) > before).toBe(true);
  });

  it("clears a provider-wrapped override that matches the configured default", () => {
    const before = Date.now() - 5_000;
    const entry: SessionEntry = {
      sessionId: "sess-openrouter-repair-default",
      updatedAt: before,
      providerOverride: "anthropic",
      modelOverride: "claude-haiku-4.5",
      modelOverrideSource: "user",
    };

    const result = repairProviderWrappedModelOverride({
      entry,
      defaultProvider: "openrouter",
      defaultModel: "anthropic/claude-haiku-4.5",
    });

    expect(result.updated).toBe(true);
    expect(entry.providerOverride).toBeUndefined();
    expect(entry.modelOverride).toBeUndefined();
    expect(entry.modelOverrideSource).toBeUndefined();
    expect((entry.updatedAt ?? 0) > before).toBe(true);
  });
});
