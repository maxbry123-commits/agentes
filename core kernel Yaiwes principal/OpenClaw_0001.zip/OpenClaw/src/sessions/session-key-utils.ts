// Session key utilities normalize and classify persisted session keys.
import {
  normalizeLowercaseStringOrEmpty,
  normalizeOptionalLowercaseString,
  normalizeOptionalString,
} from "@openclaw/normalization-core/string-coerce";
import { pruneMapToMaxSize } from "../infra/map-size.js";
import { escapeRegExp } from "../shared/regexp.js";

export type ParsedAgentSessionKey = {
  agentId: string;
  rest: string;
};

export type ParsedThreadSessionSuffix = {
  baseSessionKey: string | undefined;
  threadId: string | undefined;
};

type ParsedSessionDeliveryRoute = {
  accountId?: string;
  channel: string;
  peerId: string;
  peerKind: "channel" | "direct" | "dm" | "group";
  threadId?: string;
};

type ParsedCronRunScopeSuffix = {
  baseSessionKey: string | undefined;
  runId: string | undefined;
};

export type RawSessionConversationRef = {
  channel: string;
  kind: "group" | "channel";
  rawId: string;
  prefix: string;
};

/**
 * Generic, opt-in case-preservation policy for session-key peer IDs.
 *
 * Session keys are canonicalized to lowercase for stable comparison/routing, but
 * some channels own opaque, case-SENSITIVE peer IDs that must survive verbatim.
 * Channels enroll here individually; un-enrolled channels keep the default
 * lowercase behavior. See openclaw/openclaw#75670 (Matrix) and #82853 (Signal).
 *
 *   span "segment" — preserve a single colon-free id segment, matched anywhere
 *                    (incl. unscoped keys without an `agent:<id>:` head).
 *   span "tail"    — preserve the entire opaque tail after the agent-scoped
 *                    `agent:<id>:<channel>:<peerKind>:` head (opaque id with
 *                    embedded colons plus any `:thread:<event>` suffix).
 */
type CasePreservingPeerDescriptor = {
  channel: string;
  peerKinds: ReadonlySet<string>;
  span: "segment" | "tail";
  /** Preserve even without the `agent:<id>:` structural head (legacy Signal). */
  unscoped: boolean;
};

const CASE_PRESERVING_PEERS: readonly CasePreservingPeerDescriptor[] = [
  // #82853 — Signal group IDs (opaque). Encoded to match prior behavior exactly.
  { channel: "signal", peerKinds: new Set(["group"]), span: "segment", unscoped: true },
  // #75670 — Matrix room IDs (opaque, embedded `:server`) plus thread event suffix.
  { channel: "matrix", peerKinds: new Set(["channel", "group"]), span: "tail", unscoped: true },
];

const CASE_PRESERVING_PEER_PATTERNS = CASE_PRESERVING_PEERS.flatMap((descriptor) =>
  [...descriptor.peerKinds].map((peerKind) => {
    const prefix = `${escapeRegExp(descriptor.channel)}:${escapeRegExp(peerKind)}:`;
    return {
      span: descriptor.span,
      pattern: new RegExp(
        descriptor.span === "segment" ? `(^|:)${prefix}([^:]+)` : `^(?:agent:[^:]*:)+:*${prefix}`,
        descriptor.span === "segment" ? "gi" : "i",
      ),
      unscopedPattern:
        descriptor.span === "tail" && descriptor.unscoped
          ? new RegExp(`^${prefix}`, "i")
          : undefined,
    };
  }),
);

function findCasePreservingPeerDescriptor(
  channel: string | undefined | null,
  peerKind: string | undefined | null,
): CasePreservingPeerDescriptor | undefined {
  const c = normalizeLowercaseStringOrEmpty(channel);
  const k = normalizeLowercaseStringOrEmpty(peerKind);
  return CASE_PRESERVING_PEERS.find((d) => d.channel === c && d.peerKinds.has(k));
}

export function requiresFoldedSessionKeyAliasProof(sessionKey: string | undefined | null): boolean {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return false;
  }
  const parts = raw.split(":");
  let bodyStartIndex = 0;
  let hasAgentWrapper = false;
  while (
    parts.length - bodyStartIndex >= 3 &&
    normalizeOptionalLowercaseString(parts[bodyStartIndex]) === "agent"
  ) {
    hasAgentWrapper = true;
    bodyStartIndex += 2;
  }
  if (hasAgentWrapper) {
    while (bodyStartIndex < parts.length && !normalizeOptionalString(parts[bodyStartIndex])) {
      bodyStartIndex += 1;
    }
  }
  const descriptor = findCasePreservingPeerDescriptor(
    parts[bodyStartIndex],
    parts[bodyStartIndex + 1],
  );
  return descriptor?.span === "tail";
}

export function normalizeSessionPeerId(params: {
  channel: string | undefined | null;
  peerKind?: string | null;
  peerId?: string | null;
}): string {
  const peerId = (params.peerId ?? "").trim();
  if (!peerId) {
    return "";
  }
  return findCasePreservingPeerDescriptor(params.channel, params.peerKind) !== undefined
    ? peerId
    : normalizeLowercaseStringOrEmpty(peerId);
}

type PreservedSpan = { start: number; end: number; trim: boolean };

const NORMALIZED_SESSION_KEY_CACHE_MAX_ENTRIES = 2048;
const NORMALIZED_SESSION_KEY_CACHE_MAX_LENGTH = 4096;
const normalizedSessionKeyCache = new Map<string, string>();

function readNormalizedSessionKeyCache(raw: string): string | undefined {
  return raw.length <= NORMALIZED_SESSION_KEY_CACHE_MAX_LENGTH
    ? normalizedSessionKeyCache.get(raw)
    : undefined;
}

function writeNormalizedSessionKeyCache(raw: string, normalized: string): void {
  if (raw.length > NORMALIZED_SESSION_KEY_CACHE_MAX_LENGTH) {
    return;
  }
  normalizedSessionKeyCache.set(raw, normalized);
  pruneMapToMaxSize(normalizedSessionKeyCache, NORMALIZED_SESSION_KEY_CACHE_MAX_ENTRIES);
}

function mayContainCasePreservingPeer(raw: string): boolean {
  const folded = raw.toLowerCase();
  return CASE_PRESERVING_PEERS.some((descriptor) => folded.includes(`${descriptor.channel}:`));
}

/**
 * Collect [start,end) index ranges in `raw` whose case must be preserved, per the
 * CASE_PRESERVING_PEERS registry. Spans may come from multiple descriptors; the
 * caller lowercases everything OUTSIDE their union — collect-then-emit, never
 * sequential transforms that could re-lowercase an already-preserved span.
 */
function collectCasePreservedSpans(raw: string): PreservedSpan[] {
  const spans: PreservedSpan[] = [];
  for (const descriptor of CASE_PRESERVING_PEER_PATTERNS) {
    if (descriptor.span === "segment") {
      // matchAll clones the global matcher, so separate keys never share a cursor.
      for (const match of raw.matchAll(descriptor.pattern)) {
        const matched = match[0] ?? "";
        const segment = match[2] ?? "";
        const segStart = (match.index ?? 0) + matched.length - segment.length;
        // Segment spans match the legacy peerId.trim() behavior exactly.
        spans.push({ start: segStart, end: segStart + segment.length, trim: true });
      }
      continue;
    }
    // Nested/malformed ownership wrappers remain opaque; only the matcher owns their shape.
    const match = descriptor.pattern.exec(raw) ?? descriptor.unscopedPattern?.exec(raw);
    if (!match || match[0].length >= raw.length) {
      continue;
    }
    const tailStart = match[0].length;
    const tail = raw.slice(tailStart);
    const threadMarker = ":thread:";
    const markerIndex = normalizeLowercaseStringOrEmpty(tail).lastIndexOf(threadMarker);
    if (markerIndex === -1) {
      spans.push({ start: tailStart, end: raw.length, trim: false });
      continue;
    }
    // Room/event bytes stay opaque; only the structural thread marker is folded.
    spans.push({ start: tailStart, end: tailStart + markerIndex, trim: false });
    const threadIdStart = tailStart + markerIndex + threadMarker.length;
    if (threadIdStart < raw.length) {
      spans.push({ start: threadIdStart, end: raw.length, trim: false });
    }
  }
  return spans;
}

export function normalizeSessionKeyPreservingOpaquePeerIds(
  sessionKey: string | undefined | null,
): string {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return "";
  }
  const cached = readNormalizedSessionKeyCache(raw);
  if (cached !== undefined) {
    return cached;
  }
  if (!mayContainCasePreservingPeer(raw)) {
    const normalized = raw.toLowerCase();
    writeNormalizedSessionKeyCache(raw, normalized);
    return normalized;
  }
  const spans = collectCasePreservedSpans(raw)
    .filter((span) => span.end > span.start)
    .toSorted((a, b) => a.start - b.start);

  let normalized = "";
  let cursor = 0;
  for (const span of spans) {
    if (span.start < cursor) {
      // Overlapping/contained in an already-emitted preserved range; skip.
      continue;
    }
    normalized += normalizeLowercaseStringOrEmpty(raw.slice(cursor, span.start));
    const preserved = raw.slice(span.start, span.end);
    normalized += span.trim ? preserved.trim() : preserved;
    cursor = span.end;
  }
  normalized += normalizeLowercaseStringOrEmpty(raw.slice(cursor));
  writeNormalizedSessionKeyCache(raw, normalized);
  return normalized;
}

/**
 * Parse agent-scoped session keys in a canonical, case-insensitive way.
 * Returned values are canonicalized for stable comparisons/routing while
 * preserving provider-owned opaque peer IDs.
 */
export function parseAgentSessionKey(
  sessionKey: string | undefined | null,
): ParsedAgentSessionKey | null {
  const raw = normalizeSessionKeyPreservingOpaquePeerIds(sessionKey);
  if (!raw) {
    return null;
  }
  if (!raw.startsWith("agent:")) {
    return null;
  }
  const agentIdEnd = raw.indexOf(":", "agent:".length);
  if (agentIdEnd === -1) {
    return null;
  }
  const agentId = normalizeOptionalString(raw.slice("agent:".length, agentIdEnd));
  const rest = raw.slice(agentIdEnd + 1);
  if (!agentId || !rest || rest.startsWith(":")) {
    return null;
  }
  return { agentId, rest };
}

export function isCronRunSessionKey(sessionKey: string | undefined | null): boolean {
  const parsed = parseAgentSessionKey(sessionKey);
  if (!parsed) {
    return false;
  }
  return /^cron:[^:]+:run:[^:]+(?::|$)/.test(parsed.rest);
}

/**
 * Splits the terminal per-run `:run:<id>` scope off an isolated cron session key
 * (`agent:<id>:cron:<job>:run:<runId>`), yielding the cache-stable base key.
 * The run scope is only ever appended to cron keys, so this is gated to that exact
 * shape: any other key (including channel ids that embed a `:run:` segment) is returned
 * unchanged with `runId` undefined, never truncating an unrelated session identity.
 */
export function parseCronRunScopeSuffix(
  sessionKey: string | undefined | null,
): ParsedCronRunScopeSuffix {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return { baseSessionKey: undefined, runId: undefined };
  }
  const parsed = parseAgentSessionKey(raw);
  if (!parsed || !/^cron:[^:]+:run:[^:]+$/.test(parsed.rest)) {
    return { baseSessionKey: raw, runId: undefined };
  }
  const runMarker = ":run:";
  const markerIndex = raw.toLowerCase().lastIndexOf(runMarker);
  return {
    baseSessionKey: raw.slice(0, markerIndex),
    runId: raw.slice(markerIndex + runMarker.length),
  };
}

export function isCronSessionKey(sessionKey: string | undefined | null): boolean {
  const parsed = parseAgentSessionKey(sessionKey);
  if (!parsed) {
    return false;
  }
  return normalizeOptionalLowercaseString(parsed.rest)?.startsWith("cron:") === true;
}

export function isSubagentSessionKey(sessionKey: string | undefined | null): boolean {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return false;
  }
  if (normalizeOptionalLowercaseString(raw)?.startsWith("subagent:")) {
    return true;
  }
  const parsed = parseAgentSessionKey(raw);
  return normalizeOptionalLowercaseString(parsed?.rest)?.startsWith("subagent:") === true;
}

export function getSubagentDepth(sessionKey: string | undefined | null): number {
  const raw = normalizeOptionalLowercaseString(sessionKey);
  if (!raw) {
    return 0;
  }

  const scoped = parseAgentSessionKey(raw)?.rest ?? raw;
  const normalized = scoped.toLowerCase();
  const matches = normalized.match(/(^|:)subagent:/g);
  return matches?.length ?? 0;
}

export function isAcpSessionKey(sessionKey: string | undefined | null): boolean {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return false;
  }
  const normalized = normalizeLowercaseStringOrEmpty(raw);
  if (normalized.startsWith("acp:")) {
    return true;
  }
  const parsed = parseAgentSessionKey(raw);
  return normalizeOptionalLowercaseString(parsed?.rest)?.startsWith("acp:") === true;
}

/** Stored ACP bindings and stale ACP keys both belong to ACP dispatch, never local fallback. */
export function resolveSessionDispatchKind(
  sessionKey: string | undefined | null,
  entry?: { acp?: unknown },
): "agent" | "acp" {
  return entry?.acp || isAcpSessionKey(sessionKey) ? "acp" : "agent";
}

export function parseThreadSessionSuffix(
  sessionKey: string | undefined | null,
): ParsedThreadSessionSuffix {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return { baseSessionKey: undefined, threadId: undefined };
  }

  const lowerRaw = normalizeLowercaseStringOrEmpty(raw);
  const threadMarker = ":thread:";
  const threadIndex = lowerRaw.lastIndexOf(threadMarker);
  const markerIndex = threadIndex;
  const marker = threadMarker;

  const baseSessionKey = markerIndex === -1 ? raw : raw.slice(0, markerIndex);
  const threadIdRaw = markerIndex === -1 ? undefined : raw.slice(markerIndex + marker.length);
  const threadId = normalizeOptionalString(threadIdRaw);

  return { baseSessionKey, threadId };
}

const SESSION_DELIVERY_PEER_KINDS = new Set<ParsedSessionDeliveryRoute["peerKind"]>([
  "channel",
  "direct",
  "dm",
  "group",
]);

/** Parse only complete external delivery shapes; nested ownership stays opaque. */
export function parseSessionDeliveryRoute(
  sessionKey: string | undefined | null,
): ParsedSessionDeliveryRoute | null {
  const parsedThread = parseThreadSessionSuffix(sessionKey);
  const parsed = parseAgentSessionKey(parsedThread.baseSessionKey ?? sessionKey);
  if (!parsed) {
    return null;
  }
  const parts = parsed.rest.split(":");
  if (parts[0] === "agent" || parts.length < 3) {
    return null;
  }
  const channel = normalizeOptionalLowercaseString(parts[0]);
  if (!channel) {
    return null;
  }

  if (parts.length >= 4 && (parts[2] === "direct" || parts[2] === "dm")) {
    const accountId = normalizeOptionalString(parts[1]);
    const firstPeerIdSegment = normalizeOptionalString(parts[3]);
    const peerId = normalizeOptionalString(parts.slice(3).join(":"));
    if (!accountId || !firstPeerIdSegment || !peerId) {
      return null;
    }
    return {
      accountId,
      channel,
      peerId,
      peerKind: parts[2],
      threadId: parsedThread.threadId,
    };
  }

  const peerKind = parts[1] as ParsedSessionDeliveryRoute["peerKind"] | undefined;
  const firstPeerIdSegment = normalizeOptionalString(parts[2]);
  const peerId = normalizeOptionalString(parts.slice(2).join(":"));
  if (!peerKind || !SESSION_DELIVERY_PEER_KINDS.has(peerKind) || !firstPeerIdSegment || !peerId) {
    return null;
  }
  return { channel, peerId, peerKind, threadId: parsedThread.threadId };
}

export function parseRawSessionConversationRef(
  sessionKey: string | undefined | null,
): RawSessionConversationRef | null {
  const raw = normalizeOptionalString(sessionKey);
  if (!raw) {
    return null;
  }

  const rawParts = raw.split(":");
  // Only the outer ownership wrapper is authoritative for routing. Any inner
  // agent-shaped identity is opaque plugin input and must not inherit policy.
  const hasAgentWrapper = normalizeOptionalLowercaseString(rawParts[0]) === "agent";
  if (hasAgentWrapper && (!normalizeOptionalString(rawParts[1]) || rawParts.length < 3)) {
    return null;
  }
  const bodyStartIndex = hasAgentWrapper ? 2 : 0;
  const parts = rawParts.slice(bodyStartIndex);
  if (normalizeOptionalLowercaseString(parts[0]) === "agent") {
    return null;
  }
  // Empty opaque tail segments are valid (for example compressed IPv6), but
  // structural owner/channel/kind/first-id segments must be present.
  if (parts.length < 3 || !normalizeOptionalString(parts[2])) {
    return null;
  }

  const channel = normalizeOptionalLowercaseString(parts[0]);
  const kind = normalizeOptionalLowercaseString(parts[1]);
  if (!channel || (kind !== "group" && kind !== "channel")) {
    return null;
  }

  const rawId = normalizeOptionalString(parts.slice(2).join(":"));
  const prefix = normalizeOptionalString(rawParts.slice(0, bodyStartIndex + 2).join(":"));
  if (!rawId || !prefix) {
    return null;
  }

  return { channel, kind, rawId, prefix };
}
