import { expectDefined } from "@openclaw/normalization-core";
// Isolated agent test setup centralizes common mocks for cron agent tests.
import { vi } from "vitest";
import { runEmbeddedAgent } from "../agents/embedded-agent.js";
import { loadPreparedModelCatalog } from "../agents/prepared-model-catalog.js";
import { runSubagentAnnounceFlow } from "../agents/subagents/announce/subagent-announce.js";
import type {
  ChannelOutboundAdapter,
  ChannelOutboundContext,
} from "../channels/plugins/types.adapters.js";
import { callGateway } from "../gateway/call.js";
import { resolveOutboundSendDep } from "../infra/outbound/send-deps.js";
import { buildChannelOutboundSessionRoute } from "../plugin-sdk/core.js";
import { setActivePluginRegistry } from "../plugins/runtime.js";
import { createOutboundTestPlugin, createTestRegistry } from "../test-utils/channel-plugins.js";

// Test-only outbound registry for isolated cron turns.
type TestSendFn = (
  to: string,
  text: string,
  options?: Record<string, unknown>,
) => Promise<{ messageId?: string } & Record<string, unknown>>;

function withRequiredMessageId(
  channel: "signal" | "telegram",
  result: Awaited<ReturnType<TestSendFn>>,
) {
  return {
    channel,
    ...result,
    messageId:
      typeof result.messageId === "string" && result.messageId.trim()
        ? result.messageId
        : `${channel}-test-message`,
  };
}

function parseTelegramTargetForTest(raw: string): {
  chatId: string;
  messageThreadId?: number;
  chatType: "direct" | "group" | "unknown";
} {
  const trimmed = raw
    .trim()
    .replace(/^telegram:/i, "")
    .replace(/^tg:/i, "");
  const match = /^group:([^:]+):topic:(\d+)$/i.exec(trimmed);
  if (match) {
    return {
      chatId: expectDefined(match[1], "isolated agent.test setup regex capture 1"),
      messageThreadId: Number.parseInt(
        expectDefined(match[2], "isolated agent.test setup regex capture 2"),
        10,
      ),
      chatType: "group",
    };
  }
  const topicMatch = /^([^:]+):topic:(\d+)$/i.exec(trimmed);
  if (topicMatch) {
    return {
      chatId: expectDefined(topicMatch[1], "topic match capture group 1"),
      messageThreadId: Number.parseInt(
        expectDefined(topicMatch[2], "topic match capture group 2"),
        10,
      ),
      chatType: expectDefined(topicMatch[1], "topic match capture group 1").startsWith("-")
        ? "group"
        : "direct",
    };
  }
  const colonPair = /^([^:]+):(\d+)$/i.exec(trimmed);
  if (colonPair && expectDefined(colonPair[1], "colon pair capture group 1").startsWith("-")) {
    return {
      chatId: expectDefined(colonPair[1], "colon pair capture group 1"),
      messageThreadId: Number.parseInt(
        expectDefined(colonPair[2], "colon pair capture group 2"),
        10,
      ),
      chatType: "group",
    };
  }
  return {
    chatId: trimmed,
    chatType: trimmed.startsWith("-") ? "group" : "unknown",
  };
}

function resolveRequiredTarget(label: string, raw: string | undefined) {
  const trimmed = raw?.trim();
  if (!trimmed) {
    return { ok: false as const, error: new Error(`${label} target is required`) };
  }
  return { ok: true as const, to: trimmed };
}

function resolveTestSender(
  channel: "signal" | "telegram",
  deps: ChannelOutboundContext["deps"],
): TestSendFn {
  const sender = resolveOutboundSendDep<TestSendFn>(deps, channel);
  if (!sender) {
    throw new Error(`missing ${channel} sender`);
  }
  return sender;
}

const telegramOutboundForTest: ChannelOutboundAdapter = {
  deliveryMode: "direct",
  preferFinalAssistantVisibleText: true,
  sendText: async () => ({ channel: "telegram", messageId: "telegram-msg" }),
  resolveTarget: ({ to }) => {
    const resolved = resolveRequiredTarget("Telegram", to);
    if (!resolved.ok) {
      return resolved;
    }
    return { ok: true, to: parseTelegramTargetForTest(resolved.to).chatId };
  },
};

const signalOutboundForTest: ChannelOutboundAdapter = {
  deliveryMode: "direct",
  sendText: async ({ cfg, to, text, accountId, deps }) =>
    withRequiredMessageId(
      "signal",
      await resolveTestSender("signal", deps)(to, text, {
        cfg,
        accountId: accountId ?? undefined,
      }),
    ),
  resolveTarget: ({ to }) => resolveRequiredTarget("Signal", to),
};

telegramOutboundForTest.sendText = async ({ cfg, to, text, accountId, deps, threadId }) =>
  withRequiredMessageId(
    "telegram",
    await resolveTestSender("telegram", deps)(to, text, {
      cfg,
      accountId: accountId ?? undefined,
      messageThreadId: threadId ?? undefined,
    }),
  );

telegramOutboundForTest.sendMedia = async ({
  cfg,
  to,
  text,
  mediaUrl,
  mediaLocalRoots,
  mediaReadFile,
  accountId,
  deps,
  threadId,
}) =>
  withRequiredMessageId(
    "telegram",
    await resolveTestSender("telegram", deps)(to, text, {
      cfg,
      mediaUrl,
      mediaLocalRoots,
      mediaReadFile,
      accountId: accountId ?? undefined,
      messageThreadId: threadId ?? undefined,
    }),
  );

export function setupIsolatedAgentTurnMocks(params?: { fast?: boolean }): void {
  if (params?.fast) {
    vi.stubEnv("OPENCLAW_TEST_FAST", "1");
  }
  vi.mocked(runEmbeddedAgent).mockReset();
  vi.mocked(loadPreparedModelCatalog).mockResolvedValue([]);
  vi.mocked(runSubagentAnnounceFlow).mockReset().mockResolvedValue("delivered");
  vi.mocked(callGateway).mockReset().mockResolvedValue({ ok: true, deleted: true });
  setActivePluginRegistry(
    createTestRegistry([
      {
        pluginId: "telegram",
        plugin: createOutboundTestPlugin({
          id: "telegram",
          outbound: telegramOutboundForTest,
          messaging: {
            inferTargetChatType: ({ to }) => {
              const target = parseTelegramTargetForTest(to);
              return target.chatType === "unknown" ? undefined : target.chatType;
            },
            targetResolver: {
              resolveTarget: async ({ input }) => {
                const parsed = parseTelegramTargetForTest(input);
                if (!parsed.chatId) {
                  return null;
                }
                return {
                  to:
                    parsed.messageThreadId == null
                      ? parsed.chatId
                      : `${parsed.chatId}:topic:${parsed.messageThreadId}`,
                  kind: parsed.chatType === "direct" ? "user" : "group",
                  source: "normalized",
                };
              },
            },
            resolveOutboundSessionRoute: ({ cfg, agentId, accountId, target, threadId }) => {
              const parsed = parseTelegramTargetForTest(target);
              const resolvedThreadId = parsed.messageThreadId ?? threadId ?? undefined;
              const chatType = parsed.chatType === "direct" ? "direct" : "group";
              return buildChannelOutboundSessionRoute({
                cfg,
                agentId,
                channel: "telegram",
                accountId,
                peer: {
                  kind: chatType,
                  id:
                    chatType === "group" && resolvedThreadId !== undefined
                      ? `${parsed.chatId}:topic:${resolvedThreadId}`
                      : parsed.chatId,
                },
                chatType,
                from: `telegram:${parsed.chatId}`,
                to: parsed.chatId,
                ...(resolvedThreadId !== undefined ? { threadId: resolvedThreadId } : {}),
              });
            },
          },
        }),
        source: "test",
      },
      {
        pluginId: "signal",
        plugin: createOutboundTestPlugin({ id: "signal", outbound: signalOutboundForTest }),
        source: "test",
      },
    ]),
  );
}
