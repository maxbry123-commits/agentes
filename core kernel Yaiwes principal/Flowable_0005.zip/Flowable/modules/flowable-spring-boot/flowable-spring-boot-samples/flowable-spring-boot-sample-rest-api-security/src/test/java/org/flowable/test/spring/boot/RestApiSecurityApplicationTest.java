/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.flowable.test.spring.boot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import java.util.Base64;

import org.flowable.cmmn.rest.service.api.repository.CaseDefinitionResponse;
import org.flowable.common.rest.api.DataResponse;
import org.flowable.dmn.rest.service.api.repository.DmnDeploymentResponse;
import org.flowable.rest.service.api.identity.GroupResponse;
import org.flowable.rest.service.api.repository.ProcessDefinitionResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.resttestclient.TestRestTemplate;
import org.springframework.boot.resttestclient.autoconfigure.AutoConfigureTestRestTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;

import flowable.Application;

/**
 * @author Filip Hrisafov
 */
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestRestTemplate
public class RestApiSecurityApplicationTest {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int serverPort;

    @Test
    public void userDetailsService() {
        assertThat(userDetailsService.loadUserByUsername("jlong").getAuthorities())
                .as("jlong user's authorities")
                .extracting(GrantedAuthority::getAuthority)
                .containsExactly("user-privilege");

        assertThat(userDetailsService.loadUserByUsername("jbarrez").getAuthorities())
                .as("jbarrez user's authorities")
                .extracting(GrantedAuthority::getAuthority)
                .containsExactlyInAnyOrder("user-privilege", "admin-privilege");
    }

    @Test
    public void testRestApiIntegration() {
        String authenticationChallenge = "http://localhost:" + serverPort + "/repository/process-definitions";

        ResponseEntity<String> response = restTemplate.getForEntity(authenticationChallenge, String.class);
        assertThat(response.getStatusCode()).as(response.toString()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    public void testRestApiIntegrationWithAuthentication() {
        String processDefinitionsUrl = "http://localhost:" + serverPort + "/process-api/repository/process-definitions";

        HttpEntity<?> request = new HttpEntity<>(createHeaders("jbarrez", "password"));
        ResponseEntity<DataResponse<ProcessDefinitionResponse>> response = restTemplate
            .exchange(processDefinitionsUrl, HttpMethod.GET, request, new ParameterizedTypeReference<DataResponse<ProcessDefinitionResponse>>() {

            });

        assertThat(response.getStatusCode())
            .as("Status code")
            .isEqualTo(HttpStatus.OK);
        DataResponse<ProcessDefinitionResponse> processDefinitions = response.getBody();
        assertThat(processDefinitions).isNotNull();
        assertThat(processDefinitions.getTotal()).isEqualTo(1);
        ProcessDefinitionResponse defResponse = processDefinitions.getData().get(0);
        assertThat(defResponse.getKey()).isEqualTo("dogeProcess");
        assertThat(defResponse.getUrl()).startsWith("http://localhost:" + serverPort + "/process-api/repository/process-definitions/dogeProcess:1:");

    }

    @Test
    public void testCmmnRestApiIntegrationWithAuthentication() {
        String processDefinitionsUrl = "http://localhost:" + serverPort + "/cmmn-api/cmmn-repository/case-definitions";

        HttpEntity<?> request = new HttpEntity<>(createHeaders("filiphr", "password"));
        ResponseEntity<DataResponse<CaseDefinitionResponse>> response = restTemplate
            .exchange(processDefinitionsUrl, HttpMethod.GET, request, new ParameterizedTypeReference<DataResponse<CaseDefinitionResponse>>() {
            });

        assertThat(response.getStatusCode())
            .as("Status code")
            .isEqualTo(HttpStatus.OK);
        DataResponse<CaseDefinitionResponse> caseDefinitions = response.getBody();
        assertThat(caseDefinitions).isNotNull();
        CaseDefinitionResponse defResponse = caseDefinitions.getData().get(0);
        assertThat(defResponse.getKey()).isEqualTo("case1");
        assertThat(defResponse.getUrl()).startsWith("http://localhost:" + serverPort + "/cmmn-api/cmmn-repository/case-definitions/");
    }

    @Test
    public void testDmnRestApiIntegrationWithAuthentication() {
        String processDefinitionsUrl = "http://localhost:" + serverPort + "/dmn-api/dmn-repository/deployments";

        HttpEntity<?> request = new HttpEntity<>(createHeaders("filiphr", "password"));
        ResponseEntity<DataResponse<DmnDeploymentResponse>> response = restTemplate
            .exchange(processDefinitionsUrl, HttpMethod.GET, request, new ParameterizedTypeReference<DataResponse<DmnDeploymentResponse>>() {
            });

        assertThat(response.getStatusCode())
            .as("Status code")
            .isEqualTo(HttpStatus.OK);
        DataResponse<DmnDeploymentResponse> deployments = response.getBody();
        assertThat(deployments).isNotNull();
        assertThat(deployments.getData())
            .isEmpty();
        assertThat(deployments.getTotal()).isZero();
    }
    @Test
    public void testIdmRestApiIntegrationWithAuthentication() {
        String processDefinitionsUrl = "http://localhost:" + serverPort + "/idm-api/groups";

        HttpEntity<?> request = new HttpEntity<>(createHeaders("filiphr", "password"));
        ResponseEntity<DataResponse<GroupResponse>> response = restTemplate
            .exchange(processDefinitionsUrl, HttpMethod.GET, request, new ParameterizedTypeReference<DataResponse<GroupResponse>>() {
            });

        assertThat(response.getStatusCode())
            .as("Status code")
            .isEqualTo(HttpStatus.OK);
        DataResponse<GroupResponse> groups = response.getBody();
        assertThat(groups).isNotNull();
        assertThat(groups.getData())
            .extracting(GroupResponse::getId, GroupResponse::getType, GroupResponse::getName, GroupResponse::getUrl)
            .containsExactlyInAnyOrder(
                tuple("user", "security-role", "users", null),
                tuple("admin", "security-role", "admin", null)
            );
        assertThat(groups.getTotal()).isEqualTo(2);
    }

    protected static HttpHeaders createHeaders(String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.AUTHORIZATION, base64Authentication(username, password));
        return headers;
    }

    protected static String base64Authentication(String username, String password) {
        String auth = username + ":" + password;
        return "Basic " + Base64.getEncoder().encodeToString(auth.getBytes());
    }
}
