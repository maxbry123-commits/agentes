/**
 * Creating a sidebar enables you to:
 - create an ordered group of docs
 - render a sidebar for each doc of that group
 - provide next/previous navigation

 The sidebars can be generated from the filesystem, or explicitly defined here.

 Create as many sidebars as you want.
 */

const redTeamSidebar = [
  {
    type: 'doc',
    id: 'red-team/quickstart',
    label: 'Getting started',
  },
  {
    type: 'doc',
    id: 'red-team/index',
  },
  {
    type: 'doc',
    id: 'red-team/configuration',
  },
  {
    type: 'doc',
    id: 'red-team/discovery',
  },
  {
    type: 'category',
    label: 'Concepts',
    collapsed: true,
    items: [
      { type: 'doc', id: 'red-team/architecture' },
      { type: 'doc', id: 'red-team/llm-vulnerability-types' },
      { type: 'doc', id: 'red-team/risk-scoring' },
    ],
  },
  {
    type: 'category',
    label: 'Plugins',
    collapsed: true,
    link: {
      type: 'doc',
      id: 'red-team/plugins/index',
    },
    items: [
      {
        type: 'category',
        label: 'Privacy & Access Control',
        collapsed: true,
        items: [
          'red-team/plugins/ascii-smuggling',
          'red-team/plugins/bfla',
          'red-team/plugins/bola',
          'red-team/plugins/cross-session-leak',
          'red-team/plugins/debug-access',
          'red-team/plugins/model-identification',
          'red-team/plugins/context-compliance-attack',
          'red-team/plugins/divergent-repetition',
          'red-team/plugins/hijacking',
          'red-team/plugins/indirect-prompt-injection',
          'red-team/plugins/mcp',
          'red-team/plugins/memory-poisoning',
          'red-team/plugins/pii',
          'red-team/plugins/prompt-extraction',
          'red-team/plugins/rag-document-exfiltration',
          'red-team/plugins/rag-poisoning',
          'red-team/plugins/rbac',
          'red-team/plugins/reasoning-dos',
          'red-team/plugins/shell-injection',
          'red-team/plugins/special-token-injection',
          'red-team/plugins/sql-injection',
          'red-team/plugins/ssrf',
          'red-team/plugins/system-prompt-override',
          'red-team/plugins/tool-discovery',
        ],
      },
      {
        type: 'category',
        label: 'Trust, Safety, & Compliance',
        collapsed: true,
        items: [
          {
            type: 'category',
            label: 'Bias Detection',
            collapsed: true,
            items: [
              'red-team/plugins/bias',
              'red-team/plugins/age-bias',
              'red-team/plugins/disability-bias',
              'red-team/plugins/gender-bias',
              'red-team/plugins/race-bias',
            ],
          },
          'red-team/plugins/beavertails',
          'red-team/plugins/contracts',
          'red-team/plugins/coppa',
          'red-team/plugins/cyberseceval',
          'red-team/plugins/donotanswer',
          'red-team/plugins/ferpa',
          'red-team/plugins/harmbench',
          'red-team/plugins/aegis',
          'red-team/plugins/harmful',
          'red-team/plugins/malicious-code',
          'red-team/plugins/pliny',
          'red-team/plugins/politics',
          'red-team/plugins/religion',
          'red-team/plugins/toxic-chat',
          'red-team/plugins/unsafebench',
          'red-team/plugins/vlguard',
          'red-team/plugins/wordplay',
          'red-team/plugins/xstest',
        ],
      },
      {
        type: 'category',
        label: 'Brand & Reputation',
        collapsed: true,
        items: [
          'red-team/plugins/competitors',
          'red-team/plugins/excessive-agency',
          'red-team/plugins/goal-misalignment',
          'red-team/plugins/hallucination',
          'red-team/plugins/imitation',
          'red-team/plugins/off-topic',
          'red-team/plugins/overreliance',
          'red-team/plugins/unverifiable-claims',
        ],
      },
      {
        type: 'category',
        label: 'Domain-Specific',
        collapsed: true,
        items: [
          'red-team/plugins/ecommerce',
          'red-team/plugins/financial',
          'red-team/plugins/insurance',
          'red-team/plugins/medical',
          'red-team/plugins/pharmacy',
          'red-team/plugins/realestate',
          'red-team/plugins/telecom',
        ],
      },
      {
        type: 'category',
        label: 'Custom',
        collapsed: true,
        items: ['red-team/plugins/policy', 'red-team/plugins/intent', 'red-team/plugins/custom'],
      },
    ],
  },
  {
    type: 'category',
    label: 'Strategies',
    collapsed: true,
    link: {
      type: 'doc',
      id: 'red-team/strategies/index',
    },
    items: [
      {
        type: 'category',
        label: 'Single-Turn',
        collapsed: true,
        items: [
          'red-team/strategies/base64',
          'red-team/strategies/basic',
          'red-team/strategies/best-of-n',
          'red-team/strategies/citation',
          'red-team/strategies/gcg',
          'red-team/strategies/hex',
          'red-team/strategies/homoglyph',
          'red-team/strategies/jailbreak-templates',
          'red-team/strategies/leetspeak',
          'red-team/strategies/likert',
          'red-team/strategies/math-prompt',
          'red-team/strategies/other-encodings',
          'red-team/strategies/rot13',
        ],
      },
      {
        type: 'category',
        label: 'Conversational',
        collapsed: true,
        items: [
          'red-team/strategies/multi-turn',
          'red-team/strategies/goat',
          'red-team/strategies/mischievous-user',
        ],
      },
      {
        type: 'category',
        label: 'Agentic',
        collapsed: true,
        items: [
          'red-team/strategies/iterative',
          'red-team/strategies/meta',
          'red-team/strategies/hydra',
          'red-team/strategies/goblin',
          'red-team/strategies/tree',
          'red-team/strategies/composite-jailbreaks',
        ],
      },
      {
        type: 'category',
        label: 'Multimodal',
        collapsed: true,
        items: [
          'red-team/strategies/image',
          'red-team/strategies/audio',
          'red-team/strategies/video',
        ],
      },
      {
        type: 'category',
        label: 'Indirect Prompt Injection',
        collapsed: true,
        items: ['red-team/strategies/indirect-web-pwn'],
      },
      {
        type: 'category',
        label: 'Custom',
        collapsed: true,
        items: [
          'red-team/strategies/layer',
          'red-team/strategies/custom-strategy',
          'red-team/strategies/custom',
        ],
      },
      {
        type: 'category',
        label: 'Regression',
        collapsed: true,
        items: ['red-team/strategies/retry'],
      },
    ],
  },
  {
    type: 'category',
    label: 'Frameworks',
    collapsed: true,
    items: [
      'red-team/nist-ai-rmf',
      'red-team/dod-ai-ethics',
      'red-team/owasp-llm-top-10',
      'red-team/owasp-agentic-ai',
      'red-team/owasp-api-top-10',
      'red-team/mitre-atlas',
      'red-team/iso-42001',
      'red-team/gdpr',
      'red-team/eu-ai-act',
    ],
  },
  {
    type: 'category',
    label: 'Troubleshooting',
    collapsed: true,
    items: [{ type: 'autogenerated', dirName: 'red-team/troubleshooting' }],
  },
  {
    type: 'category',
    label: 'Guides',
    link: {
      type: 'doc',
      id: 'red-team/guides/index',
    },
    collapsed: true,
    items: [
      {
        type: 'doc',
        label: 'Application Red Teaming',
        id: 'guides/llm-redteaming',
      },
      {
        type: 'doc',
        label: 'Testing Guardrails',
        id: 'guides/testing-guardrails',
      },
      {
        type: 'doc',
        label: 'RAG Red Teaming',
        id: 'red-team/rag',
      },
      {
        type: 'doc',
        label: 'Agent Red Teaming',
        id: 'red-team/llm-agents',
      },
      {
        type: 'doc',
        label: 'MCP Security',
        id: 'red-team/mcp-security-testing',
      },
      {
        type: 'doc',
        label: 'Red Teaming a Chatbase Chatbot',
        id: 'guides/chatbase-redteam',
      },
      {
        type: 'doc',
        label: 'Multi-Input Testing',
        id: 'red-team/multi-input',
      },
      {
        type: 'doc',
        label: 'Multi-Modal Red Teaming',
        id: 'guides/multimodal-red-team',
      },
      {
        type: 'doc',
        label: 'Foundation Model Red Teaming',
        id: 'red-team/foundation-models',
      },
      {
        type: 'doc',
        label: 'Evaluating Safety with HarmBench',
        id: 'guides/evaling-with-harmbench',
      },
      {
        type: 'doc',
        label: 'Testing Google Cloud Model Armor',
        id: 'guides/google-cloud-model-armor',
      },
      {
        type: 'doc',
        label: 'LLM Supply Chain Security',
        id: 'red-team/llm-supply-chain',
      },
      {
        type: 'doc',
        label: 'Detecting Model Drift',
        id: 'red-team/model-drift',
      },
    ],
  },
];

/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  // By default, Docusaurus generates a sidebar from the docs folder structure
  promptfoo: [
    {
      type: 'doc',
      id: 'intro',
    },
    {
      type: 'doc',
      id: 'installation',
    },
    {
      type: 'category',
      label: 'Evals',
      collapsible: true,
      collapsed: false,
      items: [
        { type: 'doc', id: 'getting-started' },
        {
          type: 'category',
          label: 'Configuration',
          collapsed: true,
          link: {
            type: 'generated-index',
          },
          items: [
            { type: 'doc', id: 'configuration/guide' },
            { type: 'doc', id: 'configuration/reference' },
            { type: 'doc', id: 'configuration/tools' },
            // Page still exists for backwards compatibility, but we don't put it in the sidebar
            // { type: 'doc', id: 'configuration/parameters' },
            { type: 'doc', id: 'configuration/prompts' },
            { type: 'doc', id: 'configuration/test-cases' },
            { type: 'doc', id: 'configuration/outputs' },
            { type: 'doc', id: 'configuration/chat' },
            { type: 'doc', id: 'configuration/datasets' },
            { type: 'doc', id: 'configuration/scenarios' },
          ],
        },
        {
          type: 'category',
          label: 'Assertions & metrics',
          collapsed: true,
          link: {
            type: 'doc',
            id: 'configuration/expected-outputs/index',
          },
          items: [{ type: 'autogenerated', dirName: 'configuration/expected-outputs' }],
        },
        {
          type: 'category',
          label: 'Runtime',
          collapsed: true,
          items: [
            { type: 'doc', id: 'configuration/caching' },
            { type: 'doc', id: 'configuration/rate-limits' },
            { type: 'doc', id: 'configuration/telemetry' },
            { type: 'doc', id: 'tracing' },
          ],
        },
        {
          type: 'category',
          label: 'Guides',
          link: {
            type: 'doc',
            id: 'guides/index',
          },
          collapsed: true,
          items: [
            {
              type: 'category',
              label: 'Evaluation Techniques',
              collapsed: true,
              items: [
                'guides/evaluate-rag',
                'guides/prevent-llm-hallucinations',
                'guides/evaluate-json',
                'guides/evaluate-coding-agents',
                'guides/evaluate-osworld-with-inspect',
                'guides/test-agent-skills',
                'guides/factuality-eval',
                'guides/llm-as-a-judge',
                'guides/testing-llm-chains',
                'guides/evaluate-llm-temperature',
                'guides/text-to-sql-evaluation',
                'guides/sandboxed-code-evals',
                'guides/hle-benchmark',
              ],
            },
            {
              type: 'category',
              label: 'Model Comparisons',
              collapsed: true,
              items: [
                'guides/gpt-vs-claude-vs-gemini',
                'guides/deepseek-benchmark',
                'guides/choosing-best-gpt-model',
                'guides/gpt-5.2-vs-o3',
                'guides/compare-open-source-models',
                'guides/gpt-mmlu-comparison',
                'guides/qwen-benchmark',
                'guides/azure-vs-openai',
                'guides/mixtral-vs-gpt',
                'guides/llama2-uncensored-benchmark-ollama',
              ],
            },
            {
              type: 'category',
              label: 'Integrations',
              collapsed: true,
              items: [
                'guides/langchain-prompttemplate',
                'guides/evaluate-openai-assistants',
                'guides/evaluate-crewai',
                'guides/evaluate-langgraph',
                'guides/evaluate-google-adk',
                'guides/evaluate-elevenlabs',
              ],
            },
          ],
        },
        {
          type: 'category',
          label: 'Usage',
          collapsed: true,
          link: {
            type: 'generated-index',
          },
          items: [
            'usage/command-line',
            'usage/prompt-optimization',
            'usage/node-package',
            'usage/node-api-reference',
            'usage/node-api-examples',
            'usage/node-api-quick-reference',
            'usage/web-ui',
            'usage/sharing',
            'usage/self-hosting',
            'usage/troubleshooting',
          ],
        },
      ],
    },
    {
      type: 'category',
      label: 'Red teaming',
      items: redTeamSidebar,
    },
    {
      type: 'category',
      label: 'Providers',
      link: {
        type: 'doc',
        id: 'providers/index',
      },
      collapsed: true,
      items: [{ type: 'autogenerated', dirName: 'providers' }],
    },
    {
      type: 'category',
      label: 'Integrations',
      link: {
        type: 'generated-index',
      },
      collapsed: true,
      items: [{ type: 'autogenerated', dirName: 'integrations' }],
    },
    {
      type: 'category',
      label: 'Code scanning',
      link: {
        type: 'doc',
        id: 'code-scanning/index',
      },
      collapsed: true,
      items: [
        { type: 'doc', id: 'code-scanning/github-action' },
        { type: 'doc', id: 'code-scanning/cli' },
        { type: 'doc', id: 'code-scanning/vscode-extension' },
      ],
    },
    {
      type: 'category',
      label: 'Model Audit',
      link: {
        type: 'doc',
        id: 'model-audit/index',
      },
      collapsed: true,
      items: [
        { type: 'doc', id: 'model-audit/usage' },
        { type: 'doc', id: 'model-audit/scanners' },
      ],
    },
    {
      type: 'category',
      label: 'Enterprise',
      collapsed: true,
      items: [
        { type: 'doc', id: 'enterprise/index' },
        { type: 'doc', id: 'enterprise/authentication' },
        { type: 'doc', id: 'enterprise/service-accounts' },
        { type: 'doc', id: 'enterprise/teams' },
        { type: 'doc', id: 'enterprise/red-teams' },
        { type: 'doc', id: 'enterprise/findings' },
        { type: 'doc', id: 'enterprise/guardrails' },
        { type: 'doc', id: 'enterprise/remediation-reports' },
        { type: 'doc', id: 'enterprise/webhooks' },
        { type: 'doc', id: 'enterprise/audit-logging' },
        {
          type: 'link',
          label: 'API Reference',
          href: '/docs/api-reference',
        },
      ],
    },
    {
      type: 'doc',
      id: 'contributing',
    },
    {
      type: 'doc',
      id: 'write-for-promptfoo',
    },
    {
      type: 'doc',
      id: 'faq',
    },
    {
      type: 'doc',
      id: 'releases',
    },
  ],
};

module.exports = sidebars;
