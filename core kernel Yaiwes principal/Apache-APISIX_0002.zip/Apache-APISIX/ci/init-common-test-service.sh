#!/usr/bin/env bash
#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# wait for vault to be ready
for i in $(seq 1 30); do
    if curl -sf http://127.0.0.1:8200/v1/sys/health >/dev/null 2>&1; then
        break
    fi
    if [ "$i" -eq 30 ]; then
        echo "ERROR: vault failed to become ready"
        docker logs vault 2>&1 || true
        exit 1
    fi
    sleep 2
done

# prepare vault kv engine
docker exec -i vault sh -c "VAULT_TOKEN='root' VAULT_ADDR='http://0.0.0.0:8200' vault secrets enable -path=kv -version=1 kv"

# wait for localstack to be ready
for i in $(seq 1 30); do
    if curl -sf http://127.0.0.1:4566/_localstack/health >/dev/null 2>&1; then
        break
    fi
    if [ "$i" -eq 30 ]; then
        echo "ERROR: localstack failed to become ready"
        docker logs localstack 2>&1 || true
        exit 1
    fi
    sleep 2
done

# prepare localstack
docker exec -i localstack sh -c "awslocal secretsmanager create-secret --name apisix-key --description 'APISIX Secret' --secret-string '{\"jack\":\"value\"}'"
docker exec -i localstack sh -c "awslocal secretsmanager create-secret --name apisix-mysql --description 'APISIX Secret' --secret-string 'secret'"
docker exec -i localstack sh -c "awslocal secretsmanager create-secret --name 'john/secret' --description 'APISIX Secret' --secret-string '{\"john-key-auth\":\"value\"}'"
docker exec -i localstack sh -c "awslocal secretsmanager create-secret --name 'apisix/full/path' --description 'APISIX Secret' --secret-string 'full-value'"

# prepare filesystem mcp server
sleep 3s
./ci/prepare_filesystem_mcp.sh
