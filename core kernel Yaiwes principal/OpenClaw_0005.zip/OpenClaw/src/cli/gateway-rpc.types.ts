// Shared RPC option shape for gateway CLI commands.
/** Common gateway RPC flags accepted by direct gateway command helpers. */
export type GatewayRpcOpts = {
  url?: string;
  port?: string;
  token?: string;
  password?: string;
  timeout?: string;
  expectFinal?: boolean;
  json?: boolean;
};
