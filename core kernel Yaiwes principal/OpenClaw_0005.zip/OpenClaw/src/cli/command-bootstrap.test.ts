// Command bootstrap tests cover CLI command bootstrap sequencing and side effects.
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

const ensureConfigReadyMock = vi.hoisted(() => vi.fn(async () => {}));
const ensureCliPluginRegistryLoadedMock = vi.hoisted(() => vi.fn(async () => {}));

vi.mock("./program/config-guard.js", () => ({
  ensureConfigReady: ensureConfigReadyMock,
}));

vi.mock("./plugin-registry-loader.js", () => ({
  ensureCliPluginRegistryLoaded: ensureCliPluginRegistryLoadedMock,
}));

describe("ensureCliCommandBootstrap", () => {
  let ensureCliCommandBootstrap: typeof import("./command-bootstrap.js").ensureCliCommandBootstrap;

  beforeAll(async () => {
    vi.resetModules();
    ({ ensureCliCommandBootstrap } = await import("./command-bootstrap.js"));
  });

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("runs config guard and plugin loading with shared options", async () => {
    const runtime = {} as never;

    await ensureCliCommandBootstrap({
      runtime,
      commandPath: ["agents", "list"],
      suppressDoctorStdout: true,
      allowInvalid: true,
      loadPlugins: true,
    });

    expect(ensureConfigReadyMock).toHaveBeenCalledWith({
      runtime,
      commandPath: ["agents", "list"],
      measure: expect.any(Function),
      allowInvalid: true,
      suppressDoctorStdout: true,
    });
    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "all",
      routeLogsToStderr: true,
    });
  });

  it("forwards prepared pristine migration facts to the config guard", async () => {
    const runtime = {} as never;

    await ensureCliCommandBootstrap({
      runtime,
      commandPath: ["gateway"],
      loadPlugins: false,
      skipPristineCoreStateMigrations: true,
      skipPristineStartupStateMigrations: true,
    });

    expect(ensureConfigReadyMock).toHaveBeenCalledWith({
      runtime,
      commandPath: ["gateway"],
      measure: expect.any(Function),
      skipPristineCoreStateMigrations: true,
      skipPristineStartupStateMigrations: true,
    });
  });

  it("skips config guard without skipping plugin loading", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["memory", "search"],
      suppressDoctorStdout: true,
      skipConfigGuard: true,
      loadPlugins: true,
      pluginRegistry: { scope: "memory" },
    });

    expect(ensureConfigReadyMock).not.toHaveBeenCalled();
    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "memory",
      routeLogsToStderr: true,
    });
  });

  it("forwards validation-only config guards without state migration", async () => {
    const runtime = {} as never;

    await ensureCliCommandBootstrap({
      runtime,
      commandPath: ["nodes", "approve"],
      validateConfigOnly: true,
      loadPlugins: false,
    });

    expect(ensureConfigReadyMock).toHaveBeenCalledWith({
      runtime,
      commandPath: ["nodes", "approve"],
      measure: expect.any(Function),
      validateConfigOnly: true,
    });
  });

  it("loads configured channel plugins with repair enabled for operational channel commands", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["channels", "send"],
      loadPlugins: true,
    });

    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "configured-channels",
      routeLogsToStderr: undefined,
    });
  });

  it("loads configured channel plugins without package-manager repair for read-only channel commands", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["channels", "resolve"],
      loadPlugins: true,
    });

    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "configured-channels",
      routeLogsToStderr: undefined,
    });
  });

  it("loads agent command plugins without package-manager repair", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["agent"],
      loadPlugins: true,
    });

    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "all",
      routeLogsToStderr: undefined,
    });
  });

  it("loads configured and persisted backend owners for sandbox management", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["sandbox", "list"],
      loadPlugins: true,
    });

    expect(ensureCliPluginRegistryLoadedMock).toHaveBeenCalledWith({
      scope: "sandbox-management",
      routeLogsToStderr: undefined,
    });
  });

  it("skips config and plugin activation for a gateway-backed agent turn", async () => {
    await ensureCliCommandBootstrap({
      runtime: {} as never,
      commandPath: ["agent"],
      skipConfigGuard: true,
      loadPlugins: false,
    });

    expect(ensureConfigReadyMock).not.toHaveBeenCalled();
    expect(ensureCliPluginRegistryLoadedMock).not.toHaveBeenCalled();
  });
});
