export const PRODUCTION = 'production';
