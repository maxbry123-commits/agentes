import {
    Alert,
    type AlertProps,
    Button,
    Collapse,
    styled,
    Typography,
} from '@mui/material';
import { useLocalStorageState } from 'hooks/useLocalStorageState';
import { Link } from 'react-router';
import EnterpriseEdgeCloud from 'assets/img/enterpriseEdgeCloud.svg?react';

const StyledAlert = styled(Alert)(({ theme }) => ({
    fontSize: theme.typography.body1.fontSize,
    '& > .MuiAlert-icon': {
        paddingBlock: '7px',
    },
    '& > .MuiAlert-message': {
        padding: theme.spacing(1),
        display: 'flex',
        flexFlow: 'row wrap',
        justifyContent: 'space-between',
        width: '100%',
        gap: theme.spacing(1),
    },
    '&.MuiAlert-standard.MuiAlert-colorInfo': {
        backgroundColor: theme.palette.secondary.light,
        color: theme.palette.text.primary,
        border: `1px solid ${theme.palette.secondary.border}`,
    },
}));

const StyledAlertBody = styled('div')(({ theme }) => ({
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: theme.spacing(2),
}));

const StyledAlertBodyCol = styled('div')(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'start',
    gap: theme.spacing(1),
    flex: '1 1 auto',
}));

const StyledButton = styled(Button)(({ theme }) => ({
    '&&': {
        marginTop: theme.spacing(1),
        color: 'white',
    },
})) as typeof Button;

const StyledEnterpriseEdgeCloud = styled(EnterpriseEdgeCloud)(({ theme }) => ({
    flex: 0,
    width: 'auto',
    display: 'block',
    [theme.breakpoints.down('md')]: {
        display: 'none',
    },
}));

interface IEnterpriseEdgeDismissibleAlertProps extends AlertProps {}

export const EnterpriseEdgeDismissibleAlert = ({
    ...props
}: IEnterpriseEdgeDismissibleAlertProps) => {
    const [alertState, setAlertState] = useLocalStorageState<'open' | 'closed'>(
        'enterpriseEdgeUIDismissibleAlert',
        'open',
    );

    return (
        <Collapse in={alertState === 'open'}>
            <StyledAlert
                severity='info'
                onClose={() => setAlertState('closed')}
                icon={false}
                {...props}
            >
                <StyledAlertBody>
                    <StyledAlertBodyCol>
                        <Typography variant='h3'>
                            Instant flag updates worldwide
                        </Typography>
                        <Typography
                            variant='body2'
                            sx={{
                                color: 'text.secondary',
                            }}
                        >
                            Enterprise Edge is a high-performance proxy between
                            your SDKs and Unleash, giving you global reach,
                            minimal latency, and making flag changes instantly
                            available to your users.
                        </Typography>
                        <StyledButton
                            component={Link}
                            nativeButton={false}
                            to='/admin/enterprise-edge'
                            variant='contained'
                        >
                            Check out Enterprise Edge
                        </StyledButton>
                    </StyledAlertBodyCol>
                    <StyledAlertBodyCol sx={{ alignItems: 'end' }}>
                        <StyledEnterpriseEdgeCloud />
                    </StyledAlertBodyCol>
                </StyledAlertBody>
            </StyledAlert>
        </Collapse>
    );
};
