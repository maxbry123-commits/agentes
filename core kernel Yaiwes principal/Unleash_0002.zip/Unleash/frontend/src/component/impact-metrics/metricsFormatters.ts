import { prettifyLargeNumber } from '../common/PrettifyLargeNumber/formatLargeNumber.js';
import type { AggregationMode } from './types.ts';

export const getTimeUnit = (timeRange: string) => {
    switch (timeRange) {
        case 'hour':
            return 'minute';
        case 'day':
            return 'hour';
        case 'week':
            return 'day';
        case 'month':
        case 'threeMonths':
            return 'week';
        case 'sixMonths':
            return 'month';
        default:
            return 'day';
    }
};

export const getDisplayFormat = (timeRange: string) => {
    switch (timeRange) {
        case 'hour':
            return 'HH:mm';
        case 'day':
            return 'HH:mm';
        case 'week':
            return 'MMM dd';
        case 'month':
        case 'threeMonths':
            return 'MMM dd';
        case 'sixMonths':
            return 'MMM';
        default:
            return 'MMM dd';
    }
};

export const getSeriesLabel = (metric: Record<string, string>): string => {
    const { __name__, ...labels } = metric;

    const labelParts = Object.entries(labels)
        .filter(([key, value]) => key !== '__name__' && value)
        .map(([key, value]) => `${key}=${value}`)
        .join(', ');

    if (!__name__ && !labelParts) {
        return 'Value';
    }

    if (!__name__) {
        return labelParts;
    }

    if (!labelParts) {
        return __name__;
    }

    return `${__name__} (${labelParts})`;
};

export const formatLargeNumbers = prettifyLargeNumber(1000, 1);

export type MetricType = 'counter' | 'gauge' | 'histogram' | 'unknown';

const KNOWN_METRIC_TYPES: MetricType[] = ['counter', 'gauge', 'histogram'];

export const getMetricType = (
    seriesName: string,
    metricTypeLabel?: string[],
): MetricType => {
    if (
        metricTypeLabel?.length === 1 &&
        KNOWN_METRIC_TYPES.includes(metricTypeLabel[0] as MetricType)
    ) {
        return metricTypeLabel[0] as MetricType;
    }
    if (seriesName.startsWith('unleash_counter_')) return 'counter';
    if (seriesName.startsWith('unleash_gauge_')) return 'gauge';
    if (seriesName.startsWith('unleash_histogram_')) return 'histogram';
    if (seriesName.endsWith('_bucket')) return 'histogram';
    if (seriesName.endsWith('_count')) return 'counter';
    return 'unknown';
};

export const getDefaultAggregation = (
    metricType: MetricType,
): AggregationMode => {
    if (metricType === 'counter') return 'count';
    if (metricType === 'histogram') return 'p50';
    return 'avg';
};
