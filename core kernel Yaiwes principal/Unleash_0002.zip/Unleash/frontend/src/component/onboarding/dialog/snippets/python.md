1\. Install the SDK
```sh
pip install UnleashClient
```

2\. Run Unleash
```python
from UnleashClient import UnleashClient
import time

client = UnleashClient(
    url="<YOUR_API_URL>",
    app_name="unleash-onboarding-python",
    custom_headers={'Authorization': '<YOUR_API_TOKEN>'}) # in production use environment variable

client.initialize_client()

while True:
    if client.is_enabled("<YOUR_FLAG>"):
        print("<YOUR_FLAG> is enabled")
    else:
        print("<YOUR_FLAG> is disabled")
    time.sleep(2)
```
---
```python
from UnleashClient import UnleashClient
import os

client = UnleashClient(
    url="<YOUR_API_URL>",
    app_name="unleash-onboarding-python",
    custom_headers={'Authorization': os.getenv('UNLEASH_API_TOKEN')})

client.initialize_client()

```

---
- [SDK repository with documentation](https://github.com/Unleash/unleash-client-python)
- [Python SDK example with CodeSandbox](https://github.com/Unleash/unleash-sdk-examples/tree/main/Python)
- [How to Implement Feature Flags in Python](https://docs.getunleash.io/guides/implement-feature-flags-in-python)

---

```python
if client.is_enabled("<YOUR_FLAG>"):
    print("<YOUR_FLAG> is enabled")
else:
    print("<YOUR_FLAG> is disabled")
```
