///<reference path="../../global.d.ts" />

describe('segments', () => {
    const randomId = String(Math.random()).split('.')[1];
    const segmentName = `unleash-e2e-${randomId}`;

    before(() => {
        cy.runBefore();
    });

    beforeEach(() => {
        cy.loginUI();
        cy.visit('/segments');
    });

    it('can create a segment', () => {
        cy.createSegmentUI(segmentName);
        cy.contains(segmentName);
    });

    it('gives an error if a segment exists with the same name', () => {
        cy.get("[data-testid='NAVIGATE_TO_CREATE_SEGMENT']").click();
        cy.get("[data-testid='SEGMENT_NAME_ID']")
            .should('be.visible')
            .type(segmentName);
        cy.get("[data-testid='SEGMENT_NEXT_BTN_ID']").should('be.disabled');
        cy.get("[data-testid='INPUT_ERROR_TEXT']").contains(
            'Segment name already exists',
        );
    });

    it('can delete a segment', () => {
        cy.contains(segmentName).should('exist');

        cy.deleteSegmentUI(segmentName);

        cy.contains(segmentName).should('not.exist');
    });
});
