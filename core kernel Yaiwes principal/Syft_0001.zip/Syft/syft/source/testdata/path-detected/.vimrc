" A .vimrc file
