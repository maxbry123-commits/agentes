import { Message } from 'node-rdkafka'

import { DlqOutput, IngestionWarningsOutput } from '~/common/outputs'
import { IngestionOutputs } from '~/common/outputs/ingestion-outputs'
import { PromiseScheduler } from '~/common/utils/promise-scheduler'
import { TeamManager } from '~/common/utils/team-manager'
import { ChunkProcessingStep } from '~/ingestion/framework/base-chunk-pipeline'
import {
    AfterBatchInput,
    AfterBatchOutput,
    BatchingContext,
    BatchingPipeline,
    BeforeBatchInput,
    BeforeBatchOutput,
} from '~/ingestion/framework/batching-pipeline'
import { newBatchingPipeline } from '~/ingestion/framework/builders'
import { ChunkPipelineBuilder, GroupProcessingBuilder } from '~/ingestion/framework/builders/chunk-pipeline-builders'
import { PipelineBuilder, StartPipelineBuilder } from '~/ingestion/framework/builders/pipeline-builders'
import { GroupingFunction } from '~/ingestion/framework/concurrently-grouping-chunk-pipeline'
import { TopHogMetricFactory, TopHogRegistry, createTopHogWrapper } from '~/ingestion/framework/extensions/tophog'
import { FanInFunction, FanOutFunction, FanOutSubContext } from '~/ingestion/framework/fan-out-fan-in-chunk-pipeline'
import { KafkaDebugContext, aggregateKafkaDebugContexts } from '~/ingestion/framework/helpers'
import { PipelineConfig } from '~/ingestion/framework/result-handling-pipeline'
import { ok } from '~/ingestion/framework/results'
import { RetryOptions } from '~/ingestion/framework/retry'
import { ProcessingStep } from '~/ingestion/framework/steps'
import { PluginEvent } from '~/plugin-scaffold'
import { EventHeaders, IncomingEvent, Team } from '~/types'

import {
    createParseHeadersStep,
    createParseKafkaMessageStep,
    createResolveTeamStep,
    parseMessageTopHogMetrics,
} from './steps/event-preprocessing'
import { addTeamToContext } from './subpipelines/helpers'

/**
 * Common ingestion pipeline builder.
 *
 * Every Kafka-fed ingestion pipeline (analytics, AI, error tracking, heatmaps,
 * client warnings, session replay) shares the same skeleton; only the steps in
 * the middle vary. This builder owns the skeleton and reads as a flat recipe —
 * the phase markers carry the structure:
 *
 * ```text
 * beforeBatch hooks                            .beforeBatch(cb)   (optional)
 *   messageAware
 *     parse headers                            .parseHeaders()
 *     header-only steps                        .pipe / .pipeChunk
 *     parse body                               .parseMessage()
 *     body steps                               .pipe
 *     resolve team, lift team into context     .resolveTeam()
 *     team-aware processing                    .pipe / .pipeChunk / .gather /
 *                                              .concurrentlyPerGroup /
 *                                              .fanOut(…).via(…).fanIn(…) /
 *                                              .compose
 *     handleIngestionWarnings                  (automatic)
 *   handleResults                              (automatic)
 *   handleSideEffects                          (automatic)
 * afterBatch hooks                             .afterBatch(cb)    (optional)
 * ```
 *
 * Consecutive `.pipe()` calls coalesce into one sequential per-element block;
 * any chunk-level call (`.pipeChunk`, `.gather`, `.concurrentlyPerGroup`, `.fanOut`,
 * `.compose`, a phase marker that is chunk-level) closes the block. Block
 * boundaries therefore fall out of where the chunk operations sit, which is
 * how the hand-written pipelines were already shaped.
 *
 * `.resolveTeam()` resolves the team, lifts it into the element context, and
 * opens the team-aware scope: every step after it runs inside
 * `handleIngestionWarnings`, so warnings (and warnings on dropped elements)
 * route to the resolved team. The warning handler only covers that scope:
 * warnings attached to non-OK results before `.resolveTeam()` are silently
 * dropped (there is no team to route them to), so pre-team steps must attach
 * warnings to OK results only. The stages are enforced by the type system —
 * body steps don't typecheck before `.parseMessage()`, team-dependent steps
 * not before `.resolveTeam()`. Redirect kinds are fixed up front via the
 * `ROut` type parameter — the configured outputs must cover every redirect any
 * step can produce.
 */
export interface CommonIngestionPipelineConfig<ROut extends string = never> {
    teamManager: TeamManager
    outputs: IngestionOutputs<IngestionWarningsOutput | DlqOutput | ROut>
    promiseScheduler: PromiseScheduler
    /**
     * TopHog registry for per-tenant metrics. The skeleton itself records
     * parse timing and message sizes (see `parseMessageTopHogMetrics`);
     * pipelines can layer their own metrics via the `parseMessage` /
     * `resolveTeam` factory lists.
     */
    topHog: TopHogRegistry
    /** Maximum number of batches accepted concurrently. Defaults to the framework default. */
    concurrentBatches?: number
    /**
     * Await side effects inline instead of scheduling them on the promise
     * scheduler. Applies to element results and to the beforeBatch/afterBatch
     * hooks alike — the built pipeline always handles its own side effects, so
     * drivers never see them on `BatchResult.sideEffects`. Defaults to false.
     */
    awaitSideEffects?: boolean
}

/** Element type entering the per-batch sub-pipeline: input enriched by the beforeBatch hooks. */
type BatchElement<TInput, CBatch> = TInput & CBatch

/** Element context inside the per-batch sub-pipeline. */
type BatchContext<TContext> = TContext & BatchingContext

/** Element context after `.resolveTeam()`, once the team is lifted into it. */
type TeamAwareContext<TContext> = BatchContext<TContext> & { team: Team }

/** Output of `.resolveTeam()`: the parsed event with the resolved team attached. */
type TeamResolved<T> = Omit<T & { event: IncomingEvent }, 'event'> & { event: PluginEvent; team: Team }

export type BeforeBatchCallback<TInput, TContext, CBatch> = (
    builder: StartPipelineBuilder<BeforeBatchInput<TInput, TContext>, Record<string, never>>
) => PipelineBuilder<
    BeforeBatchInput<TInput, TContext>,
    BeforeBatchOutput<TInput, TContext, CBatch>,
    Record<string, never>
>

export type AfterBatchCallback<TOutput, TContext, CBatch, ROut extends string> = (
    builder: StartPipelineBuilder<AfterBatchInput<TOutput, BatchContext<TContext>, CBatch, ROut>, Record<string, never>>
) => PipelineBuilder<
    AfterBatchInput<TOutput, BatchContext<TContext>, CBatch, ROut>,
    AfterBatchOutput<TOutput, BatchContext<TContext>, CBatch, ROut>,
    Record<string, never>
>

/**
 * A phase's accumulated content: a transform over the phase's chunk builder,
 * from the phase's start element type `TStart` to the current element type,
 * under the element context `C`. Each call extends the previous transform,
 * so the skeleton is composed exactly once, at `.build()`.
 */
type ChainTransform<TStart, TCurrent, C, ROut extends string> = (
    builder: ChunkPipelineBuilder<TStart, TStart, C, C, never, KafkaDebugContext>
) => ChunkPipelineBuilder<TStart, TCurrent, C, C, ROut, KafkaDebugContext>

/** The messageAware block before `.resolveTeam()`: runs under the batch context. */
type SubpipelineTransform<TInput, TContext, CBatch, TOut, ROut extends string> = ChainTransform<
    BatchElement<TInput, CBatch>,
    TOut,
    BatchContext<TContext>,
    ROut
>

/**
 * Coalesces consecutive per-element steps into one sequential block. `extend`
 * appends a step to the open block (or opens one); `build` closes it into the
 * committed chunk-level transform. The block's start type stays existential —
 * it lives only in the closures — so stages don't carry it as a type parameter.
 *
 * Both builder phases share this mechanism and differ only in instantiation:
 * the pre-team phase runs under the batch context, the team-aware phase under
 * the team-lifted context (see the aliases below).
 */
interface Chain<TStart, C, ROut extends string, TCurrent> {
    build(): ChainTransform<TStart, TCurrent, C, ROut>
    extend<U, R2 extends ROut>(
        step: ProcessingStep<TCurrent, U, R2>,
        options?: { retry?: RetryOptions }
    ): Chain<TStart, C, ROut, U>
}

function pendingChain<TStart, C, ROut extends string, TBlock, TCurrent>(
    committed: ChainTransform<TStart, TBlock, C, ROut>,
    pending: (start: StartPipelineBuilder<TBlock, C>) => PipelineBuilder<TBlock, TCurrent, C, ROut>
): Chain<TStart, C, ROut, TCurrent> {
    return {
        build: () => (builder) => committed(builder).sequentially(pending),
        extend: (step, options) => pendingChain(committed, (start) => pending(start).pipe(step, options)),
    }
}

function committedChain<TStart, C, ROut extends string, TCurrent>(
    committed: ChainTransform<TStart, TCurrent, C, ROut>
): Chain<TStart, C, ROut, TCurrent> {
    return {
        build: () => committed,
        extend: (step, options) => pendingChain(committed, (start) => start.pipe(step, options)),
    }
}

/** Chain over the pre-team phase. */
type PreTeamChain<TInput, TContext, ROut extends string, CBatch, TCurrent> = Chain<
    BatchElement<TInput, CBatch>,
    BatchContext<TContext>,
    ROut,
    TCurrent
>

/** Chain over the team-aware phase. */
type TeamChain<TPost, TContext, ROut extends string, TCurrent> = Chain<
    TPost,
    TeamAwareContext<TContext>,
    ROut,
    TCurrent
>

export function newCommonIngestionPipeline<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string = never,
>(config: CommonIngestionPipelineConfig<ROut>): CommonIngestionPipelineBuilder<TInput, TContext, ROut> {
    return new CommonIngestionPipelineBuilder(config)
}

export class CommonIngestionPipelineBuilder<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
> {
    constructor(private readonly config: CommonIngestionPipelineConfig<ROut>) {}

    /** Attach batch context (e.g. batch-scoped stores) before each batch is processed. */
    beforeBatch<CBatch>(
        callback: BeforeBatchCallback<TInput, TContext, CBatch>
    ): CommonBatchHooksStage<TInput, TContext, ROut, CBatch> {
        return new CommonBatchHooksStage(this.config, callback)
    }

    /** Skip batch context and go straight to header parsing. */
    parseHeaders(): CommonPreTeamStage<
        TInput,
        TContext,
        ROut,
        Record<never, object>,
        BatchElement<TInput, Record<never, object>> & { headers: EventHeaders }
    > {
        return this.beforeBatch<Record<never, object>>((builder) =>
            builder.pipe(function passThroughBeforeBatch(input) {
                return Promise.resolve(ok(input))
            })
        ).parseHeaders()
    }
}

export class CommonBatchHooksStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
> {
    constructor(
        private readonly config: CommonIngestionPipelineConfig<ROut>,
        private readonly beforeBatchCallback: BeforeBatchCallback<TInput, TContext, CBatch>
    ) {}

    /** Parse Kafka headers; after this, header-shaped steps can be piped. */
    parseHeaders(): CommonPreTeamStage<
        TInput,
        TContext,
        ROut,
        CBatch,
        BatchElement<TInput, CBatch> & { headers: EventHeaders }
    > {
        return new CommonPreTeamStage(
            this.config,
            this.beforeBatchCallback,
            pendingChain<
                BatchElement<TInput, CBatch>,
                BatchContext<TContext>,
                ROut,
                BatchElement<TInput, CBatch>,
                BatchElement<TInput, CBatch> & { headers: EventHeaders }
            >(
                (builder) => builder,
                (start) => start.pipe(createParseHeadersStep())
            )
        )
    }
}

export class CommonPreTeamStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
    TCurrent extends { message: Message; headers: EventHeaders },
> {
    constructor(
        private readonly config: CommonIngestionPipelineConfig<ROut>,
        private readonly beforeBatchCallback: BeforeBatchCallback<TInput, TContext, CBatch>,
        private readonly chain: PreTeamChain<TInput, TContext, ROut, CBatch, TCurrent>
    ) {}

    /** Per-element step; consecutive pipes run in one sequential block.
     * `options.topHog` records metric factories around the step. */
    pipe<U extends { message: Message; headers: EventHeaders }, R2 extends ROut>(
        step: ProcessingStep<TCurrent, U, R2>,
        options?: { retry?: RetryOptions; topHog?: TopHogMetricFactory<TCurrent, U>[] }
    ): CommonPreTeamStage<TInput, TContext, ROut, CBatch, U> {
        const wrapped = options?.topHog?.length ? createTopHogWrapper(this.config.topHog)(step, options.topHog) : step
        return new CommonPreTeamStage(this.config, this.beforeBatchCallback, this.chain.extend(wrapped, options))
    }

    /** Chunk-level step (e.g. rate-limit-to-overflow); closes the open sequential block. */
    pipeChunk<U extends { message: Message; headers: EventHeaders }, R2 extends ROut>(
        step: ChunkProcessingStep<TCurrent, U, R2>,
        options?: { retry?: RetryOptions }
    ): CommonPreTeamStage<TInput, TContext, ROut, CBatch, U> {
        const committed = this.chain.build()
        return new CommonPreTeamStage(
            this.config,
            this.beforeBatchCallback,
            committedChain((builder) => committed(builder).pipeChunk(step, options))
        )
    }

    /**
     * Parse the message body; after this, body-dependent steps can be piped.
     *
     * Parse timing and raw message sizes are always recorded to topHog
     * (`parseMessageTopHogMetrics`); `options.topHog` appends
     * pipeline-specific metric factories on top.
     */
    parseMessage(options?: {
        topHog?: TopHogMetricFactory<TCurrent, TCurrent & { event: IncomingEvent }>[]
    }): CommonPreTeamStage<TInput, TContext, ROut, CBatch, TCurrent & { event: IncomingEvent }> {
        const topHog = createTopHogWrapper(this.config.topHog)
        return this.pipe(
            topHog(createParseKafkaMessageStep<TCurrent>(), [
                ...parseMessageTopHogMetrics<TCurrent, TCurrent & { event: IncomingEvent }>(),
                ...(options?.topHog ?? []),
            ])
        )
    }

    /**
     * Resolve the team from the token, lift it into the element context, and
     * open the team-aware scope: every step piped after this runs inside
     * `handleIngestionWarnings`, with warnings routed to the resolved team.
     *
     * `options.topHog` records metric factories around the team-resolution
     * step (e.g. a per-team resolved counter).
     */
    resolveTeam(
        this: CommonPreTeamStage<TInput, TContext, ROut, CBatch, TCurrent & { event: IncomingEvent }>,
        options?: {
            topHog?: TopHogMetricFactory<TCurrent & { event: IncomingEvent }, TeamResolved<TCurrent>>[]
        }
    ): CommonTeamStage<TInput, TContext, ROut, CBatch, TeamResolved<TCurrent>, TeamResolved<TCurrent>> {
        const step = createResolveTeamStep<TCurrent & { event: IncomingEvent }>(this.config.teamManager)
        const topHog = createTopHogWrapper(this.config.topHog)
        const metrics = options?.topHog
        const resolved = this.chain.extend(metrics?.length ? topHog(step, metrics) : step)
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            resolved.build(),
            committedChain((builder) => builder)
        )
    }
}

/**
 * Subpipeline callback of a fan-out stage. Sub-pipelines are context-agnostic
 * (typed over the minimal base context, not the team-aware context): context
 * gated surface like `teamAware` or `handleIngestionWarnings` is uncallable
 * inside — sub warnings/side effects merge into the parent and are handled
 * once by the skeleton. Fan-out functions put any team/message data sub-steps
 * need into the sub-element value.
 */
type FanOutViaCallback<TSub, TSubOut, ROut extends string> = (
    builder: ChunkPipelineBuilder<TSub, TSub, FanOutSubContext, FanOutSubContext, never, KafkaDebugContext>
) => ChunkPipelineBuilder<TSub, TSubOut, FanOutSubContext, FanOutSubContext, ROut, KafkaDebugContext>

export class CommonTeamStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
    TPost extends { team: Team },
    TCurrent,
> {
    constructor(
        private readonly config: CommonIngestionPipelineConfig<ROut>,
        private readonly beforeBatchCallback: BeforeBatchCallback<TInput, TContext, CBatch>,
        private readonly preTeamTransform: SubpipelineTransform<TInput, TContext, CBatch, TPost, ROut>,
        private readonly chain: TeamChain<TPost, TContext, ROut, TCurrent>
    ) {}

    /** Per-element step; consecutive pipes run in one sequential block.
     * `options.topHog` records metric factories around the step. */
    pipe<U, R2 extends ROut>(
        step: ProcessingStep<TCurrent, U, R2>,
        options?: { retry?: RetryOptions; topHog?: TopHogMetricFactory<TCurrent, U>[] }
    ): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U> {
        const wrapped = options?.topHog?.length ? createTopHogWrapper(this.config.topHog)(step, options.topHog) : step
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            this.preTeamTransform,
            this.chain.extend(wrapped, options)
        )
    }

    /** Chunk-level step; closes the open sequential block. */
    pipeChunk<U, R2 extends ROut>(
        step: ChunkProcessingStep<TCurrent, U, R2>,
        options?: { retry?: RetryOptions }
    ): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U> {
        const committed = this.chain.build()
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            this.preTeamTransform,
            committedChain((builder) => committed(builder).pipeChunk(step, options))
        )
    }

    /** Re-collect concurrent groups or streamed elements into one chunk. */
    gather(): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, TCurrent> {
        const committed = this.chain.build()
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            this.preTeamTransform,
            committedChain((builder) => committed(builder).gather())
        )
    }

    /**
     * Group elements by key and process the groups concurrently; the callback
     * configures how items within a group are processed (mirrors the framework
     * method — within-group ordering stays visible at the call site).
     */
    concurrentlyPerGroup<TKey, U>(
        groupingFn: GroupingFunction<TCurrent, TKey>,
        callback: (
            group: GroupProcessingBuilder<
                TPost,
                TCurrent,
                TeamAwareContext<TContext>,
                TeamAwareContext<TContext>,
                ROut,
                KafkaDebugContext
            >
        ) => GroupProcessingBuilder<
            TPost,
            U,
            TeamAwareContext<TContext>,
            TeamAwareContext<TContext>,
            ROut,
            KafkaDebugContext
        >,
        options?: { maxConcurrency?: number }
    ): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U> {
        const committed = this.chain.build()
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            this.preTeamTransform,
            committedChain((builder) => committed(builder).concurrentlyPerGroup(groupingFn, callback, options))
        )
    }

    /**
     * Open a fan-out/fan-in stage: `.fanOut(fn).via(cb).fanIn(fn)` (mirrors
     * the framework method — the staged sequencing holds on the skeleton
     * surface too, so an unclosed stage can't reach `afterBatch`/`build`).
     */
    fanOut<TSub>(
        fanOutFn: FanOutFunction<TCurrent, TSub>
    ): CommonFanOutStage<TInput, TContext, ROut, CBatch, TPost, TCurrent, TSub> {
        const committed = this.chain.build()
        return new CommonFanOutStage(
            <TSubOut, U>(
                subpipelineCallback: FanOutViaCallback<TSub, TSubOut, ROut>,
                fanInFn: FanInFunction<TCurrent, TSubOut, U>
            ) =>
                new CommonTeamStage(
                    this.config,
                    this.beforeBatchCallback,
                    this.preTeamTransform,
                    committedChain((builder) =>
                        committed(builder).fanOut(fanOutFn).via(subpipelineCallback).fanIn(fanInFn)
                    )
                )
        )
    }

    /** Escape hatch: apply a subpipeline function (a transform over the chunk builder). */
    compose<U>(
        fn: (
            builder: ChunkPipelineBuilder<
                TPost,
                TCurrent,
                TeamAwareContext<TContext>,
                TeamAwareContext<TContext>,
                ROut,
                KafkaDebugContext
            >
        ) => ChunkPipelineBuilder<
            TPost,
            U,
            TeamAwareContext<TContext>,
            TeamAwareContext<TContext>,
            ROut,
            KafkaDebugContext
        >
    ): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U> {
        const committed = this.chain.build()
        return new CommonTeamStage(
            this.config,
            this.beforeBatchCallback,
            this.preTeamTransform,
            committedChain((builder) => fn(committed(builder)))
        )
    }

    /** Flush steps that run once per batch after every element has a result. */
    afterBatch(
        callback: AfterBatchCallback<TCurrent, TContext, CBatch, ROut>
    ): CommonBuildStage<TInput, TContext, ROut, CBatch, TCurrent> {
        return new CommonBuildStage(this.config, this.beforeBatchCallback, this.completeTransform(), callback)
    }

    build<CFeed extends object = Record<never, never>>(): BatchingPipeline<
        TInput,
        TCurrent,
        TContext,
        CBatch,
        BatchContext<TContext>,
        ROut,
        CFeed
    > {
        return new CommonBuildStage(this.config, this.beforeBatchCallback, this.completeTransform()).build<CFeed>()
    }

    private completeTransform(): SubpipelineTransform<TInput, TContext, CBatch, TCurrent, ROut> {
        const { outputs } = this.config
        const preTeam = this.preTeamTransform
        const inner = this.chain.build()
        return (builder) =>
            preTeam(builder).filterMap(addTeamToContext, (b) =>
                b.teamAware((teamAware) => inner(teamAware)).handleIngestionWarnings(outputs)
            )
    }
}

/**
 * Middle stage of the skeleton's `.fanOut(fn).via(cb).fanIn(fn)`. Its only
 * method is `via`, so an unclosed fan-out stage cannot reach `afterBatch` or
 * `build`.
 */
export class CommonFanOutStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
    TPost extends { team: Team },
    TCurrent,
    TSub,
> {
    // Completion-closure shape, like the framework's FanOutBuilder: TCurrent
    // only appears in variance-neutral positions.
    constructor(
        private readonly completeStage: <TSubOut, U>(
            subpipelineCallback: FanOutViaCallback<TSub, TSubOut, ROut>,
            fanInFn: FanInFunction<TCurrent, TSubOut, U>
        ) => CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U>
    ) {}

    /**
     * Route the sub-elements through a subpipeline built on the full chunk
     * builder surface, under the team-aware context (exactly what `compose`
     * would provide).
     */
    via<TSubOut>(
        subpipelineCallback: FanOutViaCallback<TSub, TSubOut, ROut>
    ): CommonFanInStage<TInput, TContext, ROut, CBatch, TPost, TCurrent, TSubOut> {
        return new CommonFanInStage(<U>(fanInFn: FanInFunction<TCurrent, TSubOut, U>) =>
            this.completeStage(subpipelineCallback, fanInFn)
        )
    }
}

/**
 * Final stage of the skeleton's `.fanOut(fn).via(cb).fanIn(fn)`. Its only
 * method is `fanIn`, which closes the stage and returns the regular
 * {@link CommonTeamStage} surface.
 */
export class CommonFanInStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
    TPost extends { team: Team },
    TCurrent,
    TSubOut,
> {
    // Completion-closure shape for the same variance reason as CommonFanOutStage.
    constructor(
        private readonly completeStage: <U>(
            fanInFn: FanInFunction<TCurrent, TSubOut, U>
        ) => CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U>
    ) {}

    /** Close the stage: fold each parent's collected sub-results back into the original element. */
    fanIn<U>(fanInFn: FanInFunction<TCurrent, TSubOut, U>): CommonTeamStage<TInput, TContext, ROut, CBatch, TPost, U> {
        return this.completeStage(fanInFn)
    }
}

export class CommonBuildStage<
    TInput extends { message: Message },
    TContext extends { message: Message; debugContext?: KafkaDebugContext },
    ROut extends string,
    CBatch,
    TFinal,
> {
    constructor(
        private readonly config: CommonIngestionPipelineConfig<ROut>,
        private readonly beforeBatchCallback: BeforeBatchCallback<TInput, TContext, CBatch>,
        private readonly transform: SubpipelineTransform<TInput, TContext, CBatch, TFinal, ROut>,
        private readonly afterBatchCallback?: AfterBatchCallback<TFinal, TContext, CBatch, ROut>
    ) {}

    build<CFeed extends object = Record<never, never>>(): BatchingPipeline<
        TInput,
        TFinal,
        TContext,
        CBatch,
        BatchContext<TContext>,
        ROut,
        CFeed
    > {
        const { outputs, promiseScheduler, concurrentBatches, awaitSideEffects } = this.config
        const pipelineConfig: PipelineConfig<ROut> = { outputs, promiseScheduler }
        const sideEffectOptions = { await: awaitSideEffects ?? false }
        const afterBatchCallback: AfterBatchCallback<TFinal, TContext, CBatch, ROut> =
            this.afterBatchCallback ??
            ((builder) =>
                builder.pipe(function passThroughAfterBatch(input) {
                    return Promise.resolve(ok(input))
                }))

        // The hooks handle their own side effects, so nothing rides out on
        // `BatchResult.sideEffects` and drivers only ever drain results.
        return newBatchingPipeline<TInput, TFinal, TContext, CBatch, TContext, ROut, KafkaDebugContext, CFeed>(
            (builder) => this.beforeBatchCallback(builder).handleSideEffects(promiseScheduler, sideEffectOptions),
            (batch) =>
                batch
                    .messageAware((b) => this.transform(b))
                    .handleResults(pipelineConfig)
                    .handleSideEffects(promiseScheduler, sideEffectOptions),
            (builder) => afterBatchCallback(builder).handleSideEffects(promiseScheduler, sideEffectOptions),
            concurrentBatches === undefined ? undefined : { concurrentBatches },
            { aggregateDebugContexts: aggregateKafkaDebugContexts }
        )
    }
}
