import { OVERFLOW_OUTPUT } from '~/common/outputs'
import { EventIngestionRestrictionManager, Restriction } from '~/common/utils/event-ingestion-restrictions'
import { dlq, drop, ok, redirect } from '~/ingestion/framework/results'
import { createTestEventHeaders } from '~/tests/helpers/event-headers'
import { EventHeaders } from '~/types'

import {
    RoutingConfig,
    createApplyBasicEventRestrictionsStep,
    createApplyEventRestrictionsStep,
} from './apply-event-restrictions'

describe('createApplyEventRestrictionsStep', () => {
    let eventIngestionRestrictionManager: EventIngestionRestrictionManager
    let routingConfig: RoutingConfig
    let step: ReturnType<typeof createApplyEventRestrictionsStep>

    beforeEach(() => {
        eventIngestionRestrictionManager = {
            getAppliedRestrictions: jest.fn().mockReturnValue(new Set()),
        } as unknown as EventIngestionRestrictionManager

        // The shared config mirrors a person-writing pipeline like analytics.
        // The locality table overrides both fields per case.
        routingConfig = {
            preservePartitionLocality: true,
            overflowMode: 'redirect',
            pipelineWritesPersons: true,
        }

        step = createApplyEventRestrictionsStep(eventIngestionRestrictionManager, routingConfig)
    })

    describe('header passing', () => {
        it('passes token and distinct_id correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({ distinct_id: 'test-user' })
            )
        })

        it('passes session_id correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                    session_id: 'session-123',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({ distinct_id: 'test-user', session_id: 'session-123' })
            )
        })

        it('passes event correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                    event: '$pageview',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({ distinct_id: 'test-user', event: '$pageview' })
            )
        })

        it('passes uuid correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                    uuid: 'event-uuid-123',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({ distinct_id: 'test-user', uuid: 'event-uuid-123' })
            )
        })

        it('passes all headers correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                    session_id: 'session-123',
                    event: '$pageview',
                    uuid: 'event-uuid-123',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({
                    distinct_id: 'test-user',
                    session_id: 'session-123',
                    event: '$pageview',
                    uuid: 'event-uuid-123',
                })
            )
        })
    })

    describe('drop events', () => {
        it('returns drop when DROP_EVENT restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'blocked-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.DROP_EVENT])
            )

            const result = await step(input)

            expect(result).toEqual(drop('blocked_token'))
        })
    })

    describe('DLQ redirect', () => {
        it('returns dlq when REDIRECT_TO_DLQ restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'dlq-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.REDIRECT_TO_DLQ])
            )

            const result = await step(input)

            expect(result).toEqual(dlq('restricted_to_dlq'))
        })
    })

    describe('overflow redirect', () => {
        it('returns redirect when FORCE_OVERFLOW restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'overflow-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.FORCE_OVERFLOW])
            )

            const result = await step(input)

            expect(result).toEqual(
                redirect(
                    'Event redirected to overflow due to force overflow restrictions',
                    OVERFLOW_OUTPUT,
                    true,
                    false
                )
            )
        })

        // The force-overflow redirect keeps the partition key only when person
        // processing is on AND the pipeline writes persons, because that is the
        // only case where a spread key could put two writers on one person row.
        // Every other case follows preservePartitionLocality.
        it.each([
            { config: true, skipPerson: false, writesPersons: true, expected: true },
            { config: false, skipPerson: false, writesPersons: true, expected: true },
            { config: true, skipPerson: true, writesPersons: true, expected: true },
            { config: false, skipPerson: true, writesPersons: true, expected: false },
            { config: true, skipPerson: false, writesPersons: false, expected: true },
            { config: false, skipPerson: false, writesPersons: false, expected: false },
        ])(
            'partition locality: config=$config, skipPerson=$skipPerson, writesPersons=$writesPersons -> preserveKey=$expected',
            async ({ config, skipPerson, writesPersons, expected }) => {
                const localityStep = createApplyEventRestrictionsStep(eventIngestionRestrictionManager, {
                    ...routingConfig,
                    preservePartitionLocality: config,
                    pipelineWritesPersons: writesPersons,
                })

                jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                    skipPerson
                        ? new Set([Restriction.FORCE_OVERFLOW, Restriction.SKIP_PERSON_PROCESSING])
                        : new Set([Restriction.FORCE_OVERFLOW])
                )

                const input = {
                    message: {} as any,
                    headers: createTestEventHeaders({ token: 'test-token', distinct_id: 'test-user' }),
                }

                const result = await localityStep(input)

                expect(result).toEqual(
                    redirect(
                        'Event redirected to overflow due to force overflow restrictions',
                        OVERFLOW_OUTPUT,
                        expected,
                        false
                    )
                )
            }
        )

        it('returns success when overflow is disabled', async () => {
            const disabledConfig: RoutingConfig = {
                ...routingConfig,
                overflowMode: 'disabled',
            }
            const disabledStep = createApplyEventRestrictionsStep(eventIngestionRestrictionManager, disabledConfig)

            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                }),
            }

            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.FORCE_OVERFLOW])
            )

            const result = await disabledStep(input)

            expect(result).toEqual(ok(input))
        })
    })

    describe('priority ordering', () => {
        it('drop takes priority over DLQ', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.DROP_EVENT, Restriction.REDIRECT_TO_DLQ])
            )

            const result = await step(input)

            expect(result).toEqual(drop('blocked_token'))
        })

        it('drop takes priority over overflow', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.DROP_EVENT, Restriction.FORCE_OVERFLOW])
            )

            const result = await step(input)

            expect(result).toEqual(drop('blocked_token'))
        })

        it('DLQ takes priority over overflow', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.REDIRECT_TO_DLQ, Restriction.FORCE_OVERFLOW])
            )

            const result = await step(input)

            expect(result).toEqual(dlq('restricted_to_dlq'))
        })

        it('returns ok when nothing matches', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
        })
    })

    describe('edge cases', () => {
        it('handles undefined headers', async () => {
            const input = {
                message: {} as any,
                headers: {} as EventHeaders,
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(undefined, {})
        })

        it('handles empty headers', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders(),
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
        })
    })
})

describe('createApplyBasicEventRestrictionsStep', () => {
    let eventIngestionRestrictionManager: EventIngestionRestrictionManager
    let step: ReturnType<typeof createApplyBasicEventRestrictionsStep>

    beforeEach(() => {
        eventIngestionRestrictionManager = {
            getAppliedRestrictions: jest.fn().mockReturnValue(new Set()),
        } as unknown as EventIngestionRestrictionManager

        step = createApplyBasicEventRestrictionsStep(eventIngestionRestrictionManager)
    })

    describe('header passing', () => {
        it('passes token and distinct_id correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({ distinct_id: 'test-user' })
            )
        })

        it('passes all headers correctly', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'test-token',
                    distinct_id: 'test-user',
                    session_id: 'session-123',
                    event: '$pageview',
                    uuid: 'event-uuid-123',
                }),
            }

            await step(input)

            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(
                'test-token',
                expect.objectContaining({
                    distinct_id: 'test-user',
                    session_id: 'session-123',
                    event: '$pageview',
                    uuid: 'event-uuid-123',
                })
            )
        })
    })

    describe('drop events', () => {
        it('returns drop when DROP_EVENT restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'blocked-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.DROP_EVENT])
            )

            const result = await step(input)

            expect(result).toEqual(drop('blocked_token'))
        })
    })

    describe('DLQ redirect', () => {
        it('returns dlq when REDIRECT_TO_DLQ restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'dlq-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.REDIRECT_TO_DLQ])
            )

            const result = await step(input)

            expect(result).toEqual(dlq('restricted_to_dlq'))
        })
    })

    describe('overflow is not handled', () => {
        it('returns ok when only FORCE_OVERFLOW restriction is applied', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'overflow-token',
                    distinct_id: 'user-123',
                }),
            }
            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.FORCE_OVERFLOW])
            )

            const result = await step(input)

            expect(result).toEqual(ok(input))
        })
    })

    describe('priority ordering', () => {
        it('drop takes priority over DLQ', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            jest.mocked(eventIngestionRestrictionManager.getAppliedRestrictions).mockReturnValue(
                new Set([Restriction.DROP_EVENT, Restriction.REDIRECT_TO_DLQ])
            )

            const result = await step(input)

            expect(result).toEqual(drop('blocked_token'))
        })

        it('returns ok when nothing matches', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders({
                    token: 'token',
                    distinct_id: 'user',
                }),
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
        })
    })

    describe('edge cases', () => {
        it('handles undefined headers', async () => {
            const input = {
                message: {} as any,
                headers: {} as EventHeaders,
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
            expect(eventIngestionRestrictionManager.getAppliedRestrictions).toHaveBeenCalledWith(undefined, {})
        })

        it('handles empty headers', async () => {
            const input = {
                message: {} as any,
                headers: createTestEventHeaders(),
            }

            const result = await step(input)

            expect(result).toEqual(ok(input))
        })
    })
})
