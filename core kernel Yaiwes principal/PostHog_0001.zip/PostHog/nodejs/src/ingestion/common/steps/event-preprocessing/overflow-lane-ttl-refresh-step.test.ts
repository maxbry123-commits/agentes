import { OverflowRedirectService } from '~/ingestion/common/overflow-redirect/overflow-redirect-service'
import { PipelineResultType } from '~/ingestion/framework/results'
import { createTestEventHeaders } from '~/tests/helpers/event-headers'
import { createTestPipelineEvent } from '~/tests/helpers/pipeline-event'

import { createOverflowLaneTTLRefreshStep } from './overflow-lane-ttl-refresh-step'
import { RateLimitToOverflowStepInput } from './rate-limit-to-overflow-step'

const createMockEvent = (token: string, distinctId: string, now?: Date): RateLimitToOverflowStepInput => ({
    headers: createTestEventHeaders({ token, distinct_id: distinctId, now: now ?? new Date() }),
    event: createTestPipelineEvent({ distinct_id: distinctId }),
})

const createMockService = (): jest.Mocked<OverflowRedirectService> => ({
    handleEventBatch: jest.fn().mockResolvedValue(new Set()),
    healthCheck: jest.fn(),
    shutdown: jest.fn(),
})

describe('createOverflowLaneTTLRefreshStep', () => {
    it('returns all events as ok with TTL refresh as side effect', async () => {
        const service = createMockService()
        const step = createOverflowLaneTTLRefreshStep(service)

        const events = [createMockEvent('token1', 'user1'), createMockEvent('token1', 'user2')]

        const results = await step(events)

        expect(results).toHaveLength(2)
        results.forEach((result) => {
            expect(result.type).toBe(PipelineResultType.OK)
            expect(result.sideEffects.length).toBe(1)
        })
    })

    it('calls service with deduplicated keys', async () => {
        const service = createMockService()
        const step = createOverflowLaneTTLRefreshStep(service)

        const baseTime = new Date()
        const events = [
            createMockEvent('token1', 'user1', baseTime),
            createMockEvent('token1', 'user1', baseTime), // Duplicate key
            createMockEvent('token1', 'user2', baseTime),
        ]

        await step(events)

        expect(service.handleEventBatch).toHaveBeenCalledWith([
            {
                key: { token: 'token1', distinctId: 'user1' },
                headersPerEvent: [events[0].headers, events[1].headers],
                firstTimestamp: baseTime.getTime(),
            },
            {
                key: { token: 'token1', distinctId: 'user2' },
                headersPerEvent: [events[2].headers],
                firstTimestamp: baseTime.getTime(),
            },
        ])
    })

    it('handles empty batch', async () => {
        const service = createMockService()
        const step = createOverflowLaneTTLRefreshStep(service)

        const results = await step([])

        expect(results).toHaveLength(0)
        expect(service.handleEventBatch).not.toHaveBeenCalled()
    })
})
