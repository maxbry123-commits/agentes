import { DateTime } from 'luxon'
import { Counter, Histogram } from 'prom-client'

import { personMergeFailureCounter } from '~/common/persons/metrics'
import { PersonMessage } from '~/common/persons/person-message'
import { isDistinctIdIllegal } from '~/common/persons/person-utils'
import {
    PersonClaimedByLifecycleOpError,
    PersonTombstoneBlockedError,
} from '~/common/persons/repositories/person-repository'
import { timeoutGuard } from '~/common/utils/db/utils'
import { logger } from '~/common/utils/logger'
import { captureException } from '~/common/utils/posthog'
import { promiseRetry } from '~/common/utils/retries'
import { emitIngestionWarning } from '~/ingestion/common/ingestion-warnings'
import { Properties } from '~/plugin-scaffold'
import { InternalPerson } from '~/types'

import { PersonContext } from './person-context'
import { PersonCreateService } from './person-create-service'
import type { MergeFoldPair, MergeFoldPlan } from './person-merge-fold'
import {
    PersonMergeLimitExceededError,
    PersonMergeRaceConditionError,
    PersonMergeResult,
    SourcePersonHasDistinctIdsError,
    SourcePersonNotFoundError,
    TargetPersonNotFoundError,
    mergeError,
    mergeSuccess,
} from './person-merge-types'
import { applyEventPropertyUpdates, extractEventOps, refineEventOps } from './person-update'
import { lifecycleOpIdFromEvent } from './person-uuid'
import { PersonsStoreTransactionForBatch } from './persons-store-for-batch'

export const mergeFinalFailuresCounter = new Counter({
    name: 'person_merge_final_failure_total',
    help: 'Number of person merge final failures.',
})

export const mergeTxnAttemptCounter = new Counter({
    name: 'person_merge_txn_attempt_total',
    help: 'Number of person merge attempts.',
    labelNames: ['call', 'oldPersonIdentified', 'newPersonIdentified'],
})

export const mergeTxnSuccessCounter = new Counter({
    name: 'person_merge_txn_success_total',
    help: 'Number of person merges that succeeded.',
    labelNames: ['call', 'oldPersonIdentified', 'newPersonIdentified'],
})

export const mergeFoldExecutedCounter = new Counter({
    name: 'person_merge_fold_executed_total',
    help: 'Number of folded merge transactions executed.',
})

export const mergeFoldFallbackCounter = new Counter({
    name: 'person_merge_fold_fallback_total',
    help: 'Number of merge folds abandoned in favor of the sequential path.',
    labelNames: ['reason'],
})

export const mergeFoldSizeHistogram = new Histogram({
    name: 'person_merge_fold_size',
    help: 'Number of merge pairs folded into one transaction.',
    buckets: [2, 5, 10, 25, 50, 100, 250, 500],
})

export const mergeClaimDroppedCounter = new Counter({
    name: 'person_merge_claim_dropped_total',
    help: 'Merges dropped because another lifecycle operation held a person through every retry.',
    labelNames: ['call'],
})

export const mergeDistinctIdOverrideCounter = new Counter({
    name: 'person_merge_distinct_id_override_total',
    help: 'Distinct id mapping rows written during merges, each writing a ClickHouse override row.',
    labelNames: ['call'],
})

/** Thrown inside the fold transaction to roll it back when merge-mode move bounds would be exceeded. */
class MergeFoldLimitError extends Error {}

/** Thrown inside the fold transaction to roll it back when a concurrent merge invalidated the fetched sources. */
class MergeFoldConflictError extends Error {}

/** Maps a fold failure to the fallback counter's reason label. */
function foldFallbackReason(error: unknown): 'limit' | 'conflict' | 'deadlock' | 'error' {
    if (error instanceof MergeFoldLimitError) {
        return 'limit'
    }
    if (
        error instanceof MergeFoldConflictError ||
        error instanceof PersonTombstoneBlockedError ||
        error instanceof PersonClaimedByLifecycleOpError
    ) {
        return 'conflict'
    }
    if ((error as { code?: string })?.code === '40P01') {
        return 'deadlock'
    }
    return 'error'
}

/**
 * Service responsible for handling person merging operations (identify, alias, merge).
 * Extracted from PersonState to focus on merge-specific logic.
 */
export class PersonMergeService {
    private personCreateService: PersonCreateService
    constructor(private context: PersonContext) {
        this.personCreateService = new PersonCreateService(context)
    }

    async handleIdentifyOrAlias(): Promise<PersonMergeResult> {
        /**
         * strategy:
         *   - if the two distinct ids passed don't match and aren't illegal, then mark `is_identified` to be true for the `distinct_id` person
         *   - if a person doesn't exist for either distinct id passed we create the person with both ids
         *   - if only one person exists we add the other distinct id
         *   - if the distinct ids belong to different already existing persons we try to merge them:
         *     - the merge is blocked if the other distinct id (`anon_distinct_id` or `alias` event property) person has `is_identified` true.
         *     - we merge into `distinct_id` person:
         *       - both distinct ids used in the future will map to the person id that was associated with `distinct_id` before
         *       - if person property was defined for both we'll use `distinct_id` person's property going forward
         */
        const timeout = timeoutGuard('Still running "handleIdentifyOrAlias". Timeout warning after 30 sec!')
        try {
            if (
                ['$create_alias', '$merge_dangerously'].includes(this.context.event.event) &&
                this.context.eventProperties['alias']
            ) {
                return await this.merge(
                    String(this.context.eventProperties['alias']),
                    this.context.distinctId,
                    this.context.team.id,
                    this.context.timestamp
                )
            } else if (
                this.context.event.event === '$identify' &&
                '$anon_distinct_id' in this.context.eventProperties
            ) {
                const anonDistinctId = String(this.context.eventProperties['$anon_distinct_id'])
                // Only await the fold path when a plan exists: an extra microtask
                // here measurably shifts event interleaving for plain merges.
                const foldResult = this.context.mergeFoldPlan ? await this.tryFoldedMerge(anonDistinctId) : null
                if (foldResult !== null) {
                    return foldResult
                }
                return await this.merge(
                    anonDistinctId,
                    this.context.distinctId,
                    this.context.team.id,
                    this.context.timestamp
                )
            }
        } catch (e) {
            if (e instanceof PersonClaimedByLifecycleOpError) {
                // Expected contention, not a failure: another lifecycle operation held one of
                // the persons through every retry. Drop the merge with a warning; the event's
                // property updates still apply to whatever the distinct ids resolve to next.
                // The counter is the rollout's drop-rate signal; the warning is debounced by
                // the standard limiter so a long-held claim cannot flood the warnings topic.
                mergeClaimDroppedCounter.labels({ call: this.context.event.event }).inc()
                const warningAck = emitIngestionWarning(this.context.outputs, this.context.team.id, {
                    type: 'merge_race_condition',
                    details: {
                        distinctId: this.context.distinctId,
                        eventUuid: this.context.event.uuid,
                        sourcePersonDistinctId: String(
                            this.context.eventProperties['$anon_distinct_id'] ?? this.context.eventProperties['alias']
                        ),
                        targetPersonDistinctId: this.context.distinctId,
                    },
                    pipelineStep: 'person-merge',
                }).then(() => undefined)
                logger.warn('🤔', 'merge dropped: person claimed by a concurrent lifecycle operation', {
                    team_id: this.context.team.id,
                    distinctId: this.context.distinctId,
                })
                return mergeSuccess(undefined, warningAck, true)
            }
            captureException(e, {
                tags: { team_id: this.context.team.id, pipeline_step: 'processPersonsStep' },
                extra: {
                    location: 'handleIdentifyOrAlias',
                    distinctId: this.context.distinctId,
                    anonId: String(this.context.eventProperties['$anon_distinct_id']),
                    alias: String(this.context.eventProperties['alias']),
                },
            })
            mergeFinalFailuresCounter.inc()
            logger.error('handleIdentifyOrAlias failed', {
                error: e,
                team_id: this.context.team.id,
                distinctId: this.context.distinctId,
                event_name: this.context.event.event,
                anon_distinct_id: String(this.context.eventProperties['$anon_distinct_id']),
                alias: String(this.context.eventProperties['alias']),
            })
        } finally {
            clearTimeout(timeout)
        }
        // For non-merge events or when no merge conditions are met, return success with no person
        return mergeSuccess(undefined, Promise.resolve(), true)
    }

    public async merge(
        otherPersonDistinctId: string,
        mergeIntoDistinctId: string,
        teamId: number,
        timestamp: DateTime
    ): Promise<PersonMergeResult> {
        // No reason to alias person against itself. Done by posthog-node when updating user properties
        if (mergeIntoDistinctId === otherPersonDistinctId) {
            // Create a success result with undefined person to indicate no merge was needed
            return mergeSuccess(undefined, Promise.resolve(), true)
        }
        if (isDistinctIdIllegal(mergeIntoDistinctId)) {
            const warningAck = emitIngestionWarning(this.context.outputs, teamId, {
                type: 'cannot_merge_with_illegal_distinct_id',
                details: {
                    illegalDistinctId: mergeIntoDistinctId,
                    otherDistinctId: otherPersonDistinctId,
                    distinctId: mergeIntoDistinctId,
                    eventUuid: this.context.event.uuid,
                },
                pipelineStep: 'person-merge',
                alwaysSend: true,
            }).then(() => undefined)
            return mergeSuccess(undefined, warningAck, true)
        }
        if (isDistinctIdIllegal(otherPersonDistinctId)) {
            const warningAck = emitIngestionWarning(this.context.outputs, teamId, {
                type: 'cannot_merge_with_illegal_distinct_id',
                details: {
                    illegalDistinctId: otherPersonDistinctId,
                    otherDistinctId: mergeIntoDistinctId,
                    distinctId: mergeIntoDistinctId,
                    eventUuid: this.context.event.uuid,
                },
                pipelineStep: 'person-merge',
                alwaysSend: true,
            }).then(() => undefined)
            return mergeSuccess(undefined, warningAck, true)
        }

        const result = await promiseRetry(
            () => this.mergeDistinctIds(otherPersonDistinctId, mergeIntoDistinctId, teamId, timestamp),
            'merge_distinct_ids'
        )
        return result
    }

    private async mergeDistinctIds(
        otherPersonDistinctId: string,
        mergeIntoDistinctId: string,
        teamId: number,
        timestamp: DateTime
    ): Promise<PersonMergeResult> {
        this.context.updateIsIdentified = true

        const otherPerson = await this.context.personStore.fetchForUpdate(teamId, otherPersonDistinctId)
        const mergeIntoPerson = await this.context.personStore.fetchForUpdate(teamId, mergeIntoDistinctId)

        // A note about the `distinctIdVersion` logic you'll find below:
        //
        // Overrides are only created for `posthog_persondistinctid` rows with version > 0, see:
        //   https://github.com/PostHog/posthog/blob/92e17ce307a577c4233d4ab252eebc6c2207a5ee/posthog/models/person/sql.py#L269-L287
        //
        // With $process_person_profile=false, events can exist in ClickHouse stamped with the
        // deterministic implied person uuid even though no `posthog_persondistinctid` or
        // `posthog_person` rows exist. So every merge-added mapping for a distinct id without a
        // person gets version 1: the override either re-points real personless events or is a
        // harmless transient row the squash job deletes within days. The exception is the distinct
        // id whose uuid a newly created person is born on — its events already point at the right
        // person, so it keeps version 0 and stays out of the overrides join.

        if ((otherPerson && !mergeIntoPerson) || (!otherPerson && mergeIntoPerson)) {
            // Only one of the two Distinct IDs points at an existing Person

            const [existingPerson, distinctIdToAdd] = (() => {
                if (otherPerson) {
                    return [otherPerson!, mergeIntoDistinctId]
                } else {
                    return [mergeIntoPerson!, otherPersonDistinctId]
                }
            })()

            this.discardOverrideCounts()
            const lifecycleOpId = lifecycleOpIdFromEvent(this.context.team.id, this.context.event.uuid)
            const result = await this.context.personStore.inTransaction('mergeDistinctIds-OneExists', async (tx) => {
                // New-world merges claim the person's lifecycle mark, which keeps a concurrent
                // tombstone from landing between this check and the distinct id insert (an
                // orphaned mapping); old-world merges rely on the delete's FK violation instead.
                if (this.context.mergeTombstoneEnabled) {
                    await tx.claimLifecycleMarks(
                        lifecycleOpId,
                        existingPerson.team_id,
                        [{ personId: existingPerson.id, personUuid: existingPerson.uuid, role: 'target' }],
                        this.context.distinctId
                    )
                    if (!(await tx.isPersonLive(existingPerson, this.context.distinctId))) {
                        // Purge the stale cache entries so the promiseRetry attempt
                        // re-fetches from Postgres instead of replaying the cached,
                        // now-tombstoned person into the same failure.
                        this.context.personStore.removeDistinctIdFromCache(teamId, otherPersonDistinctId)
                        this.context.personStore.removeDistinctIdFromCache(teamId, mergeIntoDistinctId)
                        throw new TargetPersonNotFoundError(
                            'Person was deleted before the merge could add a distinct id'
                        )
                    }
                }
                // See comment above about `distinctIdVersion`
                const distinctIdVersion = 1
                this.recordOverrideCount('oneExists')

                const kafkaMessages = await tx.addDistinctId(existingPerson, distinctIdToAdd, distinctIdVersion)
                await this.context.produceMessages(kafkaMessages)
                if (this.context.mergeTombstoneEnabled) {
                    await tx.releaseLifecycleMarks(lifecycleOpId, this.context.team.id, this.context.distinctId)
                }
                return mergeSuccess(existingPerson, Promise.resolve(), true)
            })
            this.flushOverrideCounts()
            return result
        } else if (otherPerson && mergeIntoPerson) {
            // Both Distinct IDs point at an existing Person

            if (otherPerson.id == mergeIntoPerson.id) {
                // Nothing to do, they are the same Person
                return mergeSuccess(mergeIntoPerson, Promise.resolve(), true)
            }

            const result = await this.mergePeople({
                mergeInto: mergeIntoPerson,
                mergeIntoDistinctId: mergeIntoDistinctId,
                otherPerson: otherPerson,
                otherPersonDistinctId: otherPersonDistinctId,
            })

            return result
        } else {
            // Neither Distinct ID points at an existing Person

            const distinctId1 = mergeIntoDistinctId
            const distinctId2 = otherPersonDistinctId

            this.discardOverrideCounts()
            const result = await this.context.personStore.inTransaction('mergeDistinctIds-NeitherExist', async (tx) => {
                // See comment above about `distinctIdVersion`: the first Distinct ID derives the
                // new Person's UUID so it never needs an override; the second always gets one.
                const distinctId1Version = 0
                const distinctId2Version = 1
                this.recordOverrideCount('neitherExist')

                const [person, wasCreated] = await this.personCreateService.createPerson(
                    timestamp,
                    this.context.eventProperties['$set'] || {},
                    this.context.eventProperties['$set_once'] || {},
                    teamId,
                    null,
                    true,
                    this.context.event.uuid,
                    { distinctId: distinctId1, version: distinctId1Version },
                    [{ distinctId: distinctId2, version: distinctId2Version }],
                    tx
                )
                // If person was not created (creation conflict) and is not identified,
                // we need to update it later
                const needsPersonUpdate = !wasCreated && !person.is_identified
                return mergeSuccess(person, Promise.resolve(), needsPersonUpdate)
            })
            this.flushOverrideCounts()
            return result
        }
    }

    /**
     * Folded-merge entry for $identify events that are part of a MergeFoldPlan.
     * Returns null when the event should fall through to the sequential merge
     * path (no plan, pair not planned, plan abandoned, or fold not applicable).
     */
    private async tryFoldedMerge(anonDistinctId: string): Promise<PersonMergeResult | null> {
        const plan = this.context.mergeFoldPlan
        if (
            !plan ||
            plan.targetDistinctId !== this.context.distinctId ||
            !plan.pairs.some((pair) => pair.anonDistinctId === anonDistinctId)
        ) {
            return null
        }

        if (plan.status === 'abandoned') {
            return null
        }

        if (plan.status === 'executed') {
            this.context.updateIsIdentified = true
            return mergeSuccess(plan.mergedPerson, Promise.resolve(), true)
        }

        if (isDistinctIdIllegal(plan.targetDistinctId)) {
            // The sequential path emits the per-event warning.
            plan.status = 'abandoned'
            mergeFoldFallbackCounter.labels({ reason: 'illegal_target' }).inc()
            return null
        }

        try {
            return await this.executeFoldedMerge(plan, anonDistinctId)
        } catch (error) {
            // Any failure falls back to the sequential path: the current event
            // re-runs its own merge (a no-op if the fold partially landed), and
            // later events in the run process individually with full retries.
            plan.status = 'abandoned'
            const reason = foldFallbackReason(error)
            mergeFoldFallbackCounter.labels({ reason }).inc()
            // The batch store's caches were updated optimistically inside the
            // rolled-back transaction (distinct id → target mappings); purge
            // them so the sequential fallback re-reads committed state.
            this.context.personStore.removeDistinctIdFromCache(this.context.team.id, plan.targetDistinctId)
            for (const pair of plan.pairs) {
                this.context.personStore.removeDistinctIdFromCache(this.context.team.id, pair.anonDistinctId)
            }
            logger.warn('🤔', 'folded merge failed, falling back to sequential merges', {
                team_id: this.context.team.id,
                distinct_id: plan.targetDistinctId,
                pairs: plan.pairs.length,
                reason,
                error,
            })
            return null
        }
    }

    /**
     * Counts each folded source's distinct ids inside the transaction and
     * aborts the fold (rolling it back) when:
     * - a source is missing entirely — it was merged away between the locked
     *   fetch (whose locks were released at statement end) and the transaction,
     *   so its already-computed property contribution would be stale;
     * - a source's count exceeds the LIMIT/ASYNC move limit — those events
     *   need their own per-event DLQ/redirect decision;
     * - the total exceeds batched SYNC's per-statement batch size.
     * Returns the expected total so the caller can verify the move touched
     * exactly that many rows. One cheap indexed GROUP BY that rarely trips.
     */
    private async assertFoldSourcesWithinMoveBounds(
        tx: PersonsStoreTransactionForBatch,
        mergeSources: InternalPerson[]
    ): Promise<number> {
        if (mergeSources.length === 0) {
            return 0
        }
        const mergeMode = this.context.mergeMode
        const limit = mergeMode.type === 'SYNC' ? undefined : mergeMode.limit
        const batchSize = mergeMode.type === 'SYNC' ? mergeMode.batchSize : undefined

        const counts = await tx.countDistinctIdsForPersons(
            this.context.team.id,
            mergeSources.map((source) => source.id),
            this.context.distinctId
        )
        let total = 0
        for (const source of mergeSources) {
            const count = counts.get(source.id)
            if (count === undefined) {
                throw new MergeFoldConflictError('folded merge source lost its distinct ids concurrently')
            }
            if (limit !== undefined && count > limit) {
                throw new MergeFoldLimitError('folded merge source exceeds distinct id move limit')
            }
            total += count
        }
        if (batchSize !== undefined && total > batchSize) {
            throw new MergeFoldLimitError('folded merge move exceeds sync batch size')
        }
        return total
    }

    private async executeFoldedMerge(plan: MergeFoldPlan, currentAnonDistinctId: string): Promise<PersonMergeResult> {
        const teamId = this.context.team.id
        this.context.updateIsIdentified = true

        let target = await this.context.personStore.fetchForUpdate(teamId, plan.targetDistinctId)
        let pairsToFold = plan.pairs

        if (!target) {
            // Cold start: no target person yet. Bootstrap it through the
            // sequential path for the current event's pair (which creates the
            // person or attaches the distinct_id), then fold the remaining pairs.
            const bootstrap = await promiseRetry(
                () =>
                    this.mergeDistinctIds(currentAnonDistinctId, plan.targetDistinctId, teamId, this.context.timestamp),
                'merge_distinct_ids'
            )
            if (!bootstrap.success || !bootstrap.person) {
                throw new Error('merge fold bootstrap did not produce a target person')
            }
            target = bootstrap.person
            pairsToFold = plan.pairs.filter((pair) => pair.anonDistinctId !== currentAnonDistinctId)
        }

        const sources = await this.context.personStore.fetchPersonsForUpdateByDistinctIds(
            teamId,
            pairsToFold.map((pair) => pair.anonDistinctId)
        )
        const sourceByDistinctId = new Map(sources.map((source) => [source.distinct_id, source]))

        // Partition pairs, preserving pair order for property-merge precedence.
        const mergeSources: InternalPerson[] = []
        const seenSourceIds = new Set<string>([target.id])
        const missingPairs: MergeFoldPair[] = []
        // Warning produces are awaited at batch end through the result's kafkaAck,
        // not here, so a plan full of refused pairs does not serialize round-trips.
        const warningAcks: Promise<boolean>[] = []
        for (const pair of pairsToFold) {
            if (isDistinctIdIllegal(pair.anonDistinctId)) {
                warningAcks.push(
                    emitIngestionWarning(this.context.outputs, teamId, {
                        type: 'cannot_merge_with_illegal_distinct_id',
                        details: {
                            illegalDistinctId: pair.anonDistinctId,
                            otherDistinctId: plan.targetDistinctId,
                            distinctId: plan.targetDistinctId,
                            eventUuid: pair.eventUuid,
                        },
                        pipelineStep: 'person-merge',
                        alwaysSend: true,
                    })
                )
                continue
            }
            const source = sourceByDistinctId.get(pair.anonDistinctId)
            if (!source) {
                missingPairs.push(pair)
                continue
            }
            if (seenSourceIds.has(source.id)) {
                continue
            }
            if (source.is_identified) {
                // $identify never merges an already-identified source. One
                // warning per folded pair (pairs are deduped), not per event.
                warningAcks.push(
                    emitIngestionWarning(this.context.outputs, teamId, {
                        type: 'cannot_merge_already_identified',
                        details: {
                            sourcePersonDistinctId: pair.anonDistinctId,
                            targetPersonDistinctId: plan.targetDistinctId,
                            distinctId: plan.targetDistinctId,
                            eventUuid: pair.eventUuid,
                            personId: target.uuid,
                            otherPersonId: source.uuid,
                        },
                        pipelineStep: 'person-merge',
                        alwaysSend: true,
                    })
                )
                continue
            }
            seenSourceIds.add(source.id)
            mergeSources.push(source)
        }
        const warningsAck = Promise.all(warningAcks).then(() => undefined)

        if (mergeSources.length === 0 && missingPairs.length === 0) {
            plan.status = 'executed'
            plan.mergedPerson = target
            return mergeSuccess(target, warningsAck, true)
        }

        // Sequential property precedence: each pair merges source properties
        // under the accumulated target's (target wins, earlier sources win
        // over later ones). Event $set/$set_once apply on top, as in mergePeople.
        let mergedProperties: Properties = target.properties
        for (const source of mergeSources) {
            mergedProperties = { ...source.properties, ...mergedProperties }
        }
        const propertyUpdates = refineEventOps(
            extractEventOps(this.context.event, this.context.updateAllProperties),
            mergedProperties,
            this.context.updateAllProperties
        )
        const [updatedTempPerson] = applyEventPropertyUpdates(propertyUpdates, {
            ...target,
            properties: mergedProperties,
        })

        const createdAt = DateTime.min(target.created_at, ...mergeSources.map((source) => source.created_at))
        const version = Math.max(target.version, ...mergeSources.map((source) => source.version)) + 1

        const currentTarget = target
        this.discardOverrideCounts()
        const lifecycleOpId = lifecycleOpIdFromEvent(this.context.team.id, this.context.event.uuid)
        const [mergedPerson, kafkaMessages] = await this.context.personStore.inTransaction(
            'mergePeopleFold',
            async (tx) => {
                // New-world folds claim every person, keeping concurrent lifecycle operations
                // (other merges, the delete saga) off the targets and sources until commit.
                if (this.context.mergeTombstoneEnabled) {
                    await tx.claimLifecycleMarks(
                        lifecycleOpId,
                        currentTarget.team_id,
                        [
                            { personId: currentTarget.id, personUuid: currentTarget.uuid, role: 'target' },
                            ...mergeSources.map((source, index) => ({
                                personId: source.id,
                                personUuid: source.uuid,
                                role: 'source' as const,
                                ordinal: index,
                            })),
                        ],
                        this.context.distinctId
                    )
                    if (!(await tx.isPersonLive(currentTarget, this.context.distinctId))) {
                        throw new MergeFoldConflictError('Fold target was deleted concurrently')
                    }
                }
                const expectedMoveCount = await this.assertFoldSourcesWithinMoveBounds(tx, mergeSources)

                let person = currentTarget
                let updateMessages: PersonMessage[] = []
                if (mergeSources.length > 0) {
                    ;[person, updateMessages] = await tx.updatePersonForMerge(
                        currentTarget,
                        {
                            created_at: createdAt,
                            properties: updatedTempPerson.properties,
                            is_identified: true,
                            version,
                        },
                        this.context.distinctId
                    )
                }

                const moveResult = await tx.moveDistinctIdsFromPersons(
                    mergeSources,
                    currentTarget,
                    this.context.distinctId
                )
                if (!moveResult.success) {
                    throw new TargetPersonNotFoundError('Target person no longer exists')
                }
                // A mismatch means a concurrent merge touched the sources
                // between the count and the move; abort so the sequential path
                // (whose zero-moved handling retries with fresh persons) takes
                // over rather than merging stale source properties.
                if (moveResult.distinctIdsMoved.length !== expectedMoveCount) {
                    throw new MergeFoldConflictError('folded merge moved an unexpected number of distinct ids')
                }
                this.recordOverrideCount('bothExistMove', moveResult.distinctIdsMoved.length)

                const addMessages: PersonMessage[] = []
                for (const pair of missingPairs) {
                    // See mergeDistinctIds for the distinctIdVersion logic.
                    const distinctIdVersion = 1
                    this.recordOverrideCount('fold')
                    addMessages.push(...(await tx.addDistinctId(person, pair.anonDistinctId, distinctIdVersion)))
                }

                let deleteMessages: PersonMessage[] = []
                if (mergeSources.length > 0) {
                    await tx.updateCohortsAndFeatureFlagsForMergeBatch(
                        teamId,
                        mergeSources.map((source) => source.id),
                        currentTarget.id,
                        this.context.distinctId
                    )
                    deleteMessages = await tx.deletePersons(mergeSources, this.context.distinctId)
                }

                if (this.context.mergeTombstoneEnabled) {
                    await tx.releaseLifecycleMarks(lifecycleOpId, this.context.team.id, this.context.distinctId)
                }
                return [person, [...updateMessages, ...moveResult.messages, ...addMessages, ...deleteMessages]]
            }
        )

        this.flushOverrideCounts()
        plan.status = 'executed'
        plan.mergedPerson = mergedPerson
        mergeFoldExecutedCounter.inc()
        mergeFoldSizeHistogram.observe(plan.pairs.length)

        const kafkaAck = Promise.all([this.context.produceMessages(kafkaMessages), warningsAck]).then(() => undefined)
        for (const source of mergeSources) {
            // Same fire-and-forget contract as executeTransaction.
            void this.context.producePersonMergeEvent(source, mergedPerson).catch(() => {})
        }
        return mergeSuccess(mergedPerson, kafkaAck, true)
    }

    public async mergePeople({
        mergeInto,
        mergeIntoDistinctId,
        otherPerson,
        otherPersonDistinctId,
    }: {
        mergeInto: InternalPerson
        mergeIntoDistinctId: string
        otherPerson: InternalPerson
        otherPersonDistinctId: string
    }): Promise<PersonMergeResult> {
        const olderCreatedAt = DateTime.min(mergeInto.created_at, otherPerson.created_at)
        const mergeAllowed = this.isMergeAllowed(otherPerson)

        // If merge isn't allowed, we will ignore it, log an ingestion warning and return success with original person
        if (!mergeAllowed) {
            const warningAck = emitIngestionWarning(this.context.outputs, this.context.team.id, {
                type: 'cannot_merge_already_identified',
                details: {
                    sourcePersonDistinctId: otherPersonDistinctId,
                    targetPersonDistinctId: mergeIntoDistinctId,
                    distinctId: mergeIntoDistinctId,
                    eventUuid: this.context.event.uuid,
                    personId: mergeInto.uuid,
                    otherPersonId: otherPerson.uuid,
                },
                pipelineStep: 'person-merge',
                alwaysSend: true,
            }).then(() => undefined)
            logger.warn('🤔', 'refused to merge an already identified user via an $identify or $create_alias call', {
                team_id: this.context.team.id,
            })
            return mergeSuccess(mergeInto, warningAck, true)
        }

        // How the merge works:
        // Merging properties:
        //   on key conflict we use the properties from the person provided as the first argument in identify or alias calls (mergeInto person),
        //   Note it's important for us to compute this before potentially swapping the persons for personID merging purposes in PoEEmbraceJoin mode
        // In case of PoE Embrace the join mode:
        //   we want to keep using the older person to reduce the number of partitions that need to be updated during squash
        //   to do that we'll swap otherPerson and mergeInto person (after properties merge computation!)
        //   additionally update person overrides table in postgres and clickhouse
        //   TODO: ^
        // If the merge fails:
        //   we'll roll back the transaction and then try from scratch in the origial order of persons provided for property merges
        //   that guarantees consistency of how properties are processed regardless of persons created_at timestamps and rollout state
        //   we're calling aliasDeprecated as we need to refresh the persons info completely first

        const mergedProperties: Properties = { ...otherPerson.properties, ...mergeInto.properties }
        const propertyUpdates = refineEventOps(
            extractEventOps(this.context.event, this.context.updateAllProperties),
            mergedProperties,
            this.context.updateAllProperties
        )

        // Create a temporary person object to apply property updates to
        const tempPerson: InternalPerson = { ...mergeInto, properties: mergedProperties }
        const [updatedTempPerson, _] = applyEventPropertyUpdates(propertyUpdates, tempPerson)
        const properties = updatedTempPerson.properties

        const result = await this.handleMergeTransaction(
            mergeInto,
            mergeIntoDistinctId,
            otherPerson,
            otherPersonDistinctId,
            olderCreatedAt, // Keep the oldest created_at (i.e. the first time we've seen either person)
            properties
        )

        if (result.success) {
            return result
        }

        // Handle specific error types
        if (result.error instanceof PersonMergeRaceConditionError) {
            const warningAck = emitIngestionWarning(this.context.outputs, this.context.team.id, {
                type: 'merge_race_condition',
                details: {
                    sourcePersonDistinctId: otherPersonDistinctId,
                    targetPersonDistinctId: mergeIntoDistinctId,
                    distinctId: mergeIntoDistinctId,
                    eventUuid: this.context.event.uuid,
                    personId: mergeInto.uuid,
                    otherPersonId: otherPerson.uuid,
                },
                pipelineStep: 'person-merge',
                alwaysSend: true,
            }).then(() => undefined)
            logger.warn('🤔', 'merge race condition detected, too many concurrent merges', {
                team_id: this.context.team.id,
            })
            return mergeSuccess(mergeInto, warningAck, true)
        }

        // For other errors (PersonMergeLimitExceededError, etc.), return the error result
        return result
    }

    private isMergeAllowed(mergeFrom: InternalPerson): boolean {
        // $merge_dangerously has no restrictions
        // $create_alias and $identify will not merge a user who's already identified into anyone else
        return this.context.event.event === '$merge_dangerously' || !mergeFrom.is_identified
    }

    private async executeTransaction(
        currentTargetPerson: InternalPerson,
        currentSourcePerson: InternalPerson,
        createdAt: DateTime,
        properties: Properties
    ): Promise<PersonMergeResult> {
        try {
            mergeTxnAttemptCounter
                .labels({
                    call: this.context.event.event, // $identify, $create_alias or $merge_dangerously
                    oldPersonIdentified: String(currentSourcePerson.is_identified),
                    newPersonIdentified: String(currentTargetPerson.is_identified),
                })
                .inc()

            this.discardOverrideCounts()
            const lifecycleOpId = lifecycleOpIdFromEvent(this.context.team.id, this.context.event.uuid)
            const [mergedPerson, kafkaMessages] = await this.context.personStore.inTransaction(
                'mergePeople',
                async (tx) => {
                    // New-world merges claim both persons in the lifecycle mark table: at
                    // most one live operation (merge or delete saga) may hold a person, so
                    // neither can be tombstoned under this transaction. The marks say
                    // nothing about tombstones committed before the claim, so assert both
                    // persons are still live while holding them. Liveness checks are
                    // separate statements because a claim that waited on the mark index
                    // resumes with a stale snapshot.
                    if (this.context.mergeTombstoneEnabled) {
                        await tx.claimLifecycleMarks(
                            lifecycleOpId,
                            currentTargetPerson.team_id,
                            [
                                {
                                    personId: currentTargetPerson.id,
                                    personUuid: currentTargetPerson.uuid,
                                    role: 'target',
                                },
                                {
                                    personId: currentSourcePerson.id,
                                    personUuid: currentSourcePerson.uuid,
                                    role: 'source',
                                    ordinal: 0,
                                },
                            ],
                            this.context.distinctId
                        )
                        if (!(await tx.isPersonLive(currentTargetPerson, this.context.distinctId))) {
                            throw new TargetPersonNotFoundError('Target person was deleted concurrently')
                        }
                        if (!(await tx.isPersonLive(currentSourcePerson, this.context.distinctId))) {
                            throw new SourcePersonNotFoundError('Source person was deleted concurrently')
                        }
                    }
                    const [person, updatePersonMessages] = await tx.updatePersonForMerge(
                        currentTargetPerson,
                        {
                            created_at: createdAt,
                            properties: properties,
                            is_identified: true,

                            // By using the max version between the two Persons, we ensure that if
                            // this Person is later split, we can use `this_person.version + 1` for
                            // any split-off Persons and know that *that* version will be higher than
                            // any previously deleted Person, and so the new Person row will "win" and
                            // "undelete" the Person.
                            //
                            // For example:
                            //  - Merge Person_1(version:7) into Person_2(version:2)
                            //      - Person_1 is deleted
                            //      - Person_2 attains version 8 via this code below
                            //  - Person_2 is later split, which attempts to re-create Person_1 by using
                            //    its `distinct_id` to generate the deterministic Person UUID.
                            //    That new Person_1 will have a version _at least_ as high as 8, and
                            //    so any previously existing rows in CH or otherwise from
                            //    Person_1(version:7) will "lose" to this new Person_1.
                            version: Math.max(currentTargetPerson.version, currentSourcePerson.version) + 1,
                        },
                        this.context.distinctId
                    )

                    // Move distinct IDs first to establish ownership of the source person quickly.
                    // This reduces contention when multiple concurrent merges target the same source,
                    // as subsequent lookups via distinct ID will fail faster.
                    const allDistinctIdMessages = await this.moveDistinctIdsBasedOnMode(
                        tx,
                        currentSourcePerson,
                        currentTargetPerson
                    )

                    // Update cohorts and feature flags after distinct IDs are moved.
                    // The source person row still exists (deleted below), so FK constraints are satisfied.
                    // TODO: Doesn't this table need to add updates to CH too?
                    await tx.updateCohortsAndFeatureFlagsForMerge(
                        currentSourcePerson.team_id,
                        currentSourcePerson.id,
                        currentTargetPerson.id,
                        this.context.distinctId
                    )

                    const deletePersonMessages = await tx.deletePerson(currentSourcePerson, this.context.distinctId)
                    if (this.context.mergeTombstoneEnabled) {
                        await tx.releaseLifecycleMarks(lifecycleOpId, this.context.team.id, this.context.distinctId)
                    }
                    return [person, [...updatePersonMessages, ...allDistinctIdMessages, ...deletePersonMessages]]
                }
            )

            this.flushOverrideCounts()
            mergeTxnSuccessCounter
                .labels({
                    call: this.context.event.event, // $identify, $create_alias or $merge_dangerously
                    oldPersonIdentified: String(currentSourcePerson.is_identified),
                    newPersonIdentified: String(currentTargetPerson.is_identified),
                })
                .inc()

            // Fire-and-forget after commit: the person_merge_events emission is detached from the ack
            // chain, so a produce failure can never block, replay, or crash ingestion.
            // producePersonMergeEvent is best-effort and never throws; the call-site catch is a safety
            // net that swallows an escaped rejection so a broken never-throws contract can't reach the
            // unhandledRejection handler and stop the service.
            const kafkaAck = this.context.produceMessages(kafkaMessages)
            void this.context.producePersonMergeEvent(currentSourcePerson, mergedPerson).catch(() => {})
            return mergeSuccess(mergedPerson, kafkaAck, true)
        } catch (error) {
            // Map exceptions to result types - these will cause transaction rollback
            if (error instanceof SourcePersonNotFoundError) {
                return mergeError(error)
            } else if (error instanceof TargetPersonNotFoundError) {
                return mergeError(error)
            } else if (error instanceof PersonMergeLimitExceededError) {
                return mergeError(error)
            } else if (error.code === '23503' || error instanceof PersonTombstoneBlockedError) {
                // A concurrent merge added a distinct ID to the source person after we've already
                // moved the distinct IDs we knew about, but before the delete executed — surfaced
                // as a foreign key violation by the hard delete, or as PersonTombstoneBlockedError
                // by the tombstone's live-mapping guard. The retry mechanism will:
                // 1. Refresh the source person data to see all distinct IDs (including newly added ones)
                // 2. Move ALL distinct IDs to the target person
                // 3. Successfully delete the now-empty source person
                return mergeError(
                    new SourcePersonHasDistinctIdsError(
                        'Cannot delete source person due to concurrent distinct ID additions'
                    )
                )
            } else {
                // Re-throw unexpected errors
                throw error
            }
        }
    }

    // Override-counter increments are buffered and flushed only after the enclosing
    // transaction commits: merges retry and roll back, and rolled-back rows must not
    // inflate a metric used for override-inflow capacity planning.
    private pendingOverrideCounts: { call: string; count: number }[] = []

    private recordOverrideCount(call: string, count: number = 1): void {
        if (count > 0) {
            this.pendingOverrideCounts.push({ call, count })
        }
    }

    private discardOverrideCounts(): void {
        this.pendingOverrideCounts = []
    }

    private flushOverrideCounts(): void {
        for (const { call, count } of this.pendingOverrideCounts) {
            mergeDistinctIdOverrideCounter.labels({ call }).inc(count)
        }
        this.pendingOverrideCounts = []
    }

    private async moveDistinctIdsBasedOnMode(
        tx: PersonsStoreTransactionForBatch,
        currentSourcePerson: InternalPerson,
        currentTargetPerson: InternalPerson
    ): Promise<PersonMessage[]> {
        if (this.context.mergeMode.type === 'SYNC') {
            if (!this.context.mergeMode.batchSize) {
                return await this.moveDistinctIdsWithLimit(tx, currentSourcePerson, currentTargetPerson, undefined)
            }
            return await this.moveDistinctIdsInBatches(
                tx,
                currentSourcePerson,
                currentTargetPerson,
                this.context.mergeMode.batchSize
            )
        } else {
            const limit = this.context.mergeMode.limit
            return await this.moveDistinctIdsWithLimit(tx, currentSourcePerson, currentTargetPerson, limit)
        }
    }

    private async moveDistinctIdsInBatches(
        tx: PersonsStoreTransactionForBatch,
        currentSourcePerson: InternalPerson,
        currentTargetPerson: InternalPerson,
        batchSize: number
    ): Promise<PersonMessage[]> {
        const allDistinctIdMessages: PersonMessage[] = []
        let hasMore = true
        let hasProcessedAnyDistinctIds = false

        while (hasMore) {
            const distinctIdResult = await tx.moveDistinctIds(
                currentSourcePerson,
                currentTargetPerson,
                this.context.distinctId,
                batchSize
            )

            if (!distinctIdResult.success) {
                if (distinctIdResult.error === 'SourceNotFound') {
                    if (hasProcessedAnyDistinctIds) {
                        // Source person not found after we've already moved some distinct IDs
                        // This means we've moved all distinct IDs
                        hasMore = false
                        break
                    } else {
                        // Source person not found on first attempt - this is a real error
                        throw new SourcePersonNotFoundError('Source person no longer exists')
                    }
                } else if (distinctIdResult.error === 'TargetNotFound') {
                    throw new TargetPersonNotFoundError('Target person no longer exists')
                }
            } else {
                allDistinctIdMessages.push(...distinctIdResult.messages)
                hasProcessedAnyDistinctIds = true
                this.recordOverrideCount('bothExistMove', distinctIdResult.distinctIdsMoved.length)

                // Check if we moved fewer than the batch size, indicating we're done
                hasMore = distinctIdResult.distinctIdsMoved.length >= batchSize
            }
        }

        return allDistinctIdMessages
    }

    private async moveDistinctIdsWithLimit(
        tx: PersonsStoreTransactionForBatch,
        currentSourcePerson: InternalPerson,
        currentTargetPerson: InternalPerson,
        limit: number | undefined
    ): Promise<PersonMessage[]> {
        // Original behavior for LIMIT mode or SYNC without batchSize
        const distinctIdResult = await tx.moveDistinctIds(
            currentSourcePerson,
            currentTargetPerson,
            this.context.distinctId,
            limit
        )

        if (!distinctIdResult.success) {
            if (distinctIdResult.error === 'SourceNotFound') {
                throw new SourcePersonNotFoundError('Source person no longer exists')
            } else if (distinctIdResult.error === 'TargetNotFound') {
                throw new TargetPersonNotFoundError('Target person no longer exists')
            }
        }

        const allDistinctIdMessages = distinctIdResult.success ? distinctIdResult.messages : []

        // If moved count equals the per-call limit, verify if it's a partial move by checking remaining IDs
        const movedCount = distinctIdResult.success ? distinctIdResult.distinctIdsMoved.length : 0
        const hitLimit = limit ? movedCount >= limit : false

        if (hitLimit) {
            const remaining = await tx.fetchPersonDistinctIds(currentSourcePerson, this.context.distinctId, 1)
            if (remaining.length > 0) {
                personMergeFailureCounter.labels({ call: this.context.event.event }).inc()
                // Drop the event by throwing an error that the pipeline will map to DLQ/no-retry
                logger.error('🤔', 'person merge move limit hit', {
                    team_id: this.context.team.id,
                    distinct_id: this.context.distinctId,
                })
                throw new PersonMergeLimitExceededError('person_merge_move_limit_hit')
            }
        }
        this.recordOverrideCount('bothExistMove', movedCount)

        return allDistinctIdMessages
    }

    private async handleMergeTransaction(
        targetPerson: InternalPerson,
        targetDistinctId: string,
        sourcePerson: InternalPerson,
        sourceDistinctId: string,
        createdAt: DateTime,
        properties: Properties,
        maxRetries: number = 5
    ): Promise<PersonMergeResult> {
        let currentTargetPerson = targetPerson
        let currentSourcePerson = sourcePerson

        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            const result = await this.executeTransaction(
                currentTargetPerson,
                currentSourcePerson,
                createdAt,
                properties
            )

            if (result.success) {
                return result
            }

            // Handle retryable errors
            if (attempt < maxRetries) {
                if (
                    result.error instanceof SourcePersonNotFoundError ||
                    result.error instanceof SourcePersonHasDistinctIdsError
                ) {
                    const refreshedPerson = await this.refreshPersonData(
                        sourceDistinctId,
                        currentSourcePerson.id,
                        attempt,
                        'source'
                    )

                    if (!refreshedPerson) {
                        return mergeSuccess(currentTargetPerson, Promise.resolve(), true)
                    }

                    currentSourcePerson = refreshedPerson
                    continue
                } else if (result.error instanceof TargetPersonNotFoundError) {
                    const refreshedPerson = await this.refreshPersonData(
                        targetDistinctId,
                        currentTargetPerson.id,
                        attempt,
                        'target'
                    )

                    if (!refreshedPerson) {
                        return mergeSuccess(currentTargetPerson, Promise.resolve(), true)
                    }

                    currentTargetPerson = refreshedPerson
                    continue
                } else {
                    // Non-retryable error, return the failure result
                    return result
                }
            } else {
                // Max retries reached, return the failure result
                return result
            }
        }

        // This should never be reached, but add fallback for race condition
        return mergeError(
            new PersonMergeRaceConditionError(
                `Failed to merge persons due to concurrent merges, ` +
                    `source person: ${sourcePerson.id}, target person: ${targetPerson.id}, team: ${this.context.team.id} ` +
                    `source distinct id: ${sourceDistinctId}, target distinct id: ${targetDistinctId}`
            )
        )
    }

    public async addDistinctId(
        person: InternalPerson,
        distinctId: string,
        version: number,
        tx?: PersonsStoreTransactionForBatch
    ): Promise<void> {
        const kafkaMessages = await (tx || this.context.personStore).addDistinctId(person, distinctId, version)
        await this.context.produceMessages(kafkaMessages)
    }

    private async refreshPersonData(
        distinctId: string,
        currentPersonId: string,
        attempt: number,
        personType: 'source' | 'target'
    ): Promise<InternalPerson | null> {
        logger.info(`${personType} person not found, retrying with fresh data`, {
            [`${personType}PersonId`]: currentPersonId,
            teamId: this.context.team.id,
            attempt,
            distinctId,
        })

        // Remove the distinct ID from the cache so that we don't try to use it again, if the store is the batch writing store
        // TODO: this should be removed once we clean up the person store code
        this.context.personStore.removeDistinctIdFromCache(this.context.team.id, distinctId)

        // Fetch the refreshed person data using the new distinct ID
        const refreshedPerson = await this.context.personStore.fetchForUpdate(this.context.team.id, distinctId)

        if (!refreshedPerson) {
            logger.info(`${personType} person no longer exists after refresh, skipping merge`, {
                [`${personType}PersonId`]: currentPersonId,
                teamId: this.context.team.id,
                attempt,
            })
            return null
        }

        return refreshedPerson
    }

    public getUpdateIsIdentified(): boolean {
        return this.context.updateIsIdentified
    }

    getContext(): PersonContext {
        return this.context
    }
}
