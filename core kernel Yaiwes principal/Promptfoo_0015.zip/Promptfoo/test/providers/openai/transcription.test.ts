import fs from 'fs';

import { afterAll, beforeEach, describe, expect, it, vi } from 'vitest';
import { fetchWithCache } from '../../../src/cache';
import { OpenAiTranscriptionProvider } from '../../../src/providers/openai/transcription';
import { mockGlobal, mockProcessEnv } from '../../util/utils';
import { getOpenAiMissingApiKeyMessage } from './shared';

vi.mock('../../../src/cache', async (importOriginal) => {
  return {
    ...(await importOriginal()),
    fetchWithCache: vi.fn(),
  };
});
vi.mock('../../../src/logger', () => ({
  default: {
    debug: vi.fn(),
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));
const fsMocks = vi.hoisted(() => ({
  existsSync: vi.fn(),
  readFileSync: vi.fn(),
}));

vi.mock('fs', async (importOriginal) => {
  const actual = await importOriginal<typeof import('fs')>();
  return {
    ...actual,
    default: {
      ...actual,
      ...fsMocks,
    },
    ...fsMocks,
  };
});
vi.mock('fs/promises', () => {
  // Async wrapper around the sync mock so the returned value is a real Promise,
  // matching the actual fs/promises.readFile API.
  const readFile = vi.fn(async (filePath: any, encoding?: any) =>
    encoding === undefined
      ? fsMocks.readFileSync(filePath)
      : fsMocks.readFileSync(filePath, encoding),
  );
  return {
    default: {
      readFile,
    },
    readFile,
  };
});

class MockFile {
  constructor(
    public parts: any[],
    public name: string,
    public options?: FilePropertyBag,
  ) {}
}

class MockFormData {
  private data: Map<string, any[]> = new Map();

  append(key: string, value: any) {
    this.data.set(key, [...(this.data.get(key) || []), value]);
  }

  get(key: string) {
    return this.data.get(key)?.[0];
  }

  getAll(key: string) {
    return this.data.get(key) || [];
  }

  has(key: string) {
    return this.data.has(key);
  }
}

const restoreFile = mockGlobal('File', MockFile as unknown as typeof File);
const restoreFormData = mockGlobal('FormData', MockFormData as unknown as typeof FormData);

afterAll(() => {
  restoreFormData();
  restoreFile();
});

describe('OpenAiTranscriptionProvider', () => {
  const mockTranscriptionResponse = {
    data: {
      task: 'transcribe',
      text: 'This is a test transcription.',
      duration: 120, // 2 minutes
      language: 'en',
      segments: [
        {
          id: 0,
          start: 0,
          end: 60,
          text: 'This is a test',
          avg_logprob: -0.3,
          compression_ratio: 1.2,
          no_speech_prob: 0.01,
        },
        {
          id: 1,
          start: 60,
          end: 120,
          text: 'transcription.',
          avg_logprob: -0.4,
          compression_ratio: 1.1,
          no_speech_prob: 0.02,
        },
      ],
    },
    cached: false,
    status: 200,
    statusText: 'OK',
  };

  const mockDiarizedResponse = {
    data: {
      task: 'transcribe',
      duration: 180, // 3 minutes
      language: 'en',
      segments: [
        {
          speaker: 'Speaker 1',
          text: 'Hello, how are you?',
          start: 0.0,
          end: 2.5,
          avg_logprob: -0.25,
          compression_ratio: 1.3,
          no_speech_prob: 0.005,
        },
        {
          speaker: 'Speaker 2',
          text: "I'm doing great, thanks!",
          start: 2.5,
          end: 5.0,
          avg_logprob: -0.35,
          compression_ratio: 1.25,
          no_speech_prob: 0.01,
        },
      ],
      speakers: ['Speaker 1', 'Speaker 2'],
    },
    cached: false,
    status: 200,
    statusText: 'OK',
  };

  beforeEach(() => {
    vi.resetAllMocks();
    vi.mocked(fs.existsSync).mockImplementation(function () {
      return true;
    });
    vi.mocked(fs.readFileSync).mockImplementation(function () {
      return Buffer.from('mock audio data');
    });
    vi.mocked(fetchWithCache).mockResolvedValue(mockTranscriptionResponse);
  });

  describe('Basic functionality', () => {
    it('should pass the configured retry limit to the shared fetch helper', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key', maxRetries: 0 },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.stringContaining('/audio/transcriptions'),
        expect.any(Object),
        expect.any(Number),
        'json',
        undefined,
        0,
      );
    });

    it('should transcribe audio successfully', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(fs.readFileSync).toHaveBeenCalledWith('/path/to/audio.mp3');
      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.stringContaining('/audio/transcriptions'),
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            Authorization: 'Bearer test-key',
            'X-OpenAI-Originator': 'promptfoo',
          }),
        }),
        expect.any(Number),
        'json',
        undefined,
        undefined,
      );

      expect(result).toEqual({
        output: 'This is a test transcription.',
        cached: false,
        cost: 0.012, // 2 minutes * $0.006/min
        metadata: {
          task: 'transcribe',
          duration: 120,
          language: 'en',
          segments: 2,
          avgLogprob: -0.35, // Average of -0.3 and -0.4
          avgCompressionRatio: 1.15, // Average of 1.2 and 1.1
          avgNoSpeechProb: 0.015, // Average of 0.01 and 0.02
        },
      });
    });

    it('should strip case-insensitive Content-Type overrides from transcription uploads', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          headers: { 'content-type': 'application/json', 'X-Gateway-Token': 'gateway-token' },
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      const headers = vi.mocked(fetchWithCache).mock.calls[0]![1]!.headers as Record<
        string,
        string
      >;
      expect(Object.keys(headers).some((key) => key.toLowerCase() === 'content-type')).toBe(false);
      expect(headers['X-Gateway-Token']).toBe('gateway-token');
    });

    it('should let lowercase Authorization replace the default transcription credential', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'default-key', headers: { authorization: 'Bearer gateway-key' } },
      });

      await provider.callApi('/path/to/audio.mp3');

      const headers = new Headers(vi.mocked(fetchWithCache).mock.calls[0]![1]!.headers as any);
      expect(headers.get('authorization')).toBe('Bearer gateway-key');
    });

    it('should use cached response', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        ...mockTranscriptionResponse,
        cached: true,
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toEqual({
        output: 'This is a test transcription.',
        cached: true,
        cost: 0, // Cost is 0 for cached responses
        metadata: {
          task: 'transcribe',
          duration: 120,
          language: 'en',
          segments: 2,
          avgLogprob: -0.35,
          avgCompressionRatio: 1.15,
          avgNoSpeechProb: 0.015,
        },
      });
    });

    it('should calculate cost correctly for gpt-4o-mini-transcribe', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe', {
        config: { apiKey: 'test-key' },
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0.006); // 2 minutes * $0.003/min
    });

    it('should calculate cost correctly for gpt-4o-mini-transcribe-2025-12-15', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe-2025-12-15', {
        config: { apiKey: 'test-key' },
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0.006); // 2 minutes * $0.003/min
    });

    it('should calculate cost correctly for gpt-4o-mini-transcribe-2025-03-20', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe-2025-03-20', {
        config: { apiKey: 'test-key' },
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0.006);
    });

    it('should calculate mini transcription cost from the real token-usage ledger', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe-2025-03-20', {
        config: { apiKey: 'test-key' },
      });
      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'This is a test transcription.',
          usage: {
            type: 'tokens',
            input_tokens: 1_000,
            input_token_details: { text_tokens: 0, audio_tokens: 1_000 },
            output_tokens: 100,
            total_tokens: 1_100,
          },
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      // Audio tokens bill at the $3/M audio rate, not the $1.25/M text rate.
      expect(result.cost).toBeCloseTo((1_000 * 3 + 100 * 5) / 1e6, 10);
      expect(result.tokenUsage).toEqual({
        total: 1_100,
        prompt: 1_000,
        completion: 100,
        numRequests: 1,
      });
    });

    it('should bill mixed text and audio input tokens at their separate rates', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });
      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'This is a test transcription.',
          usage: {
            type: 'tokens',
            input_tokens: 1_000,
            input_token_details: { text_tokens: 200, audio_tokens: 800 },
            output_tokens: 100,
            total_tokens: 1_100,
          },
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      // $2.50/M text input + $6/M audio input + $10/M output
      expect(result.cost).toBeCloseTo((200 * 2.5 + 800 * 6 + 100 * 10) / 1e6, 10);
    });

    it('should fall back to duration billing when token usage lacks the audio/text split', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });
      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'This is a test transcription.',
          duration: 120,
          usage: {
            type: 'tokens',
            input_tokens: 1_000,
            output_tokens: 100,
            total_tokens: 1_100,
          },
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      // 2 minutes * $0.006/min, not input tokens priced at the text rate
      expect(result.cost).toBeCloseTo(0.012, 10);
      expect(result.tokenUsage).toEqual({
        total: 1_100,
        prompt: 1_000,
        completion: 100,
        numRequests: 1,
      });
    });

    it('should calculate transcription cost from a duration usage ledger', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });
      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'This is a test transcription.',
          usage: { type: 'duration', seconds: 120 },
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0.012);
      expect(result.metadata?.duration).toBe(120);
    });

    it('should prefer billed duration usage over the decoded audio duration', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });
      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'This is a test transcription.',
          duration: 8.47,
          usage: { type: 'duration', seconds: 9 },
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBeCloseTo((9 / 60) * 0.006, 10);
      expect(result.metadata?.duration).toBe(9);
    });

    it('should calculate cost correctly for whisper-1', async () => {
      const provider = new OpenAiTranscriptionProvider('whisper-1', {
        config: { apiKey: 'test-key' },
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0.012); // 2 minutes * $0.006/min
    });

    it('should correctly use ID passed during construction', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
        id: 'custom-provider-id',
      });

      expect(provider.id()).toBe('custom-provider-id');
    });

    it('should generate correct default ID', () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      expect(provider.id()).toBe('openai:transcription:gpt-4o-transcribe');
    });

    it('should generate correct default ID for dated diarization snapshots', () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize-2025-10-15', {
        config: { apiKey: 'test-key' },
      });

      expect(provider.id()).toBe('openai:transcription:gpt-4o-transcribe-diarize-2025-10-15');
    });

    it('should throw an error if API key is not set', async () => {
      const restoreEnv = mockProcessEnv({ OPENAI_API_KEY: undefined });

      try {
        const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe');

        await expect(provider.callApi('/path/to/audio.mp3')).rejects.toThrow(
          getOpenAiMissingApiKeyMessage(),
        );
      } finally {
        restoreEnv();
      }
    });

    it('should use custom apiKeyEnvar in missing API key errors', async () => {
      const restoreEnv = mockProcessEnv({
        OPENAI_API_KEY: undefined,
        CUSTOM_TRANSCRIPTION_API_KEY: undefined,
      });

      try {
        const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
          config: {
            apiKeyEnvar: 'CUSTOM_TRANSCRIPTION_API_KEY',
          },
          env: {
            OPENAI_API_KEY: undefined,
            CUSTOM_TRANSCRIPTION_API_KEY: undefined,
          },
        });

        await expect(provider.callApi('/path/to/audio.mp3')).rejects.toThrow(
          getOpenAiMissingApiKeyMessage('CUSTOM_TRANSCRIPTION_API_KEY'),
        );
      } finally {
        restoreEnv();
      }
    });

    it('should allow an unauthenticated transcription endpoint with custom headers', async () => {
      const restoreEnv = mockProcessEnv({ OPENAI_API_KEY: undefined });

      try {
        const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
          config: {
            apiBaseUrl: 'https://gateway.example/v1',
            apiKeyRequired: false,
            headers: { 'X-Gateway-Token': 'gateway-token' },
          },
          env: { OPENAI_API_KEY: undefined },
        });

        await provider.callApi('/path/to/audio.mp3');

        expect(fetchWithCache).toHaveBeenCalledWith(
          'https://gateway.example/v1/audio/transcriptions',
          expect.objectContaining({
            headers: expect.objectContaining({ 'X-Gateway-Token': 'gateway-token' }),
          }),
          expect.any(Number),
          'json',
          undefined,
          undefined,
        );
        const headers = vi.mocked(fetchWithCache).mock.calls[0]![1]!.headers as Record<
          string,
          string
        >;
        expect(headers).not.toHaveProperty('Authorization');
      } finally {
        restoreEnv();
      }
    });
  });

  describe('Abort handling', () => {
    it('forwards the eval abort signal to transcription requests', async () => {
      const controller = new AbortController();
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      await provider.callApi('/path/to/audio.mp3', undefined, {
        abortSignal: controller.signal,
      });

      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.stringContaining('/audio/transcriptions'),
        expect.objectContaining({ signal: controller.signal }),
        expect.any(Number),
        'json',
        undefined,
        undefined,
      );
    });

    it('does not transcribe for an already-aborted eval', async () => {
      const controller = new AbortController();
      controller.abort();
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      await expect(
        provider.callApi('/path/to/audio.mp3', undefined, { abortSignal: controller.signal }),
      ).rejects.toMatchObject({ name: 'AbortError' });
      expect(fetchWithCache).not.toHaveBeenCalled();
    });

    it('normalizes a pre-aborted custom reason to AbortError', async () => {
      const controller = new AbortController();
      controller.abort(new Error('caller cancelled before dispatch'));
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      await expect(
        provider.callApi('/path/to/audio.mp3', undefined, { abortSignal: controller.signal }),
      ).rejects.toMatchObject({ name: 'AbortError', message: 'caller cancelled before dispatch' });
      expect(fetchWithCache).not.toHaveBeenCalled();
    });
  });

  describe('Diarization support', () => {
    it('should forward a custom chunking strategy for standard transcription models', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe', {
        config: {
          apiKey: 'test-key',
          chunking_strategy: {
            type: 'server_vad',
            threshold: 0.6,
            prefix_padding_ms: 300,
            silence_duration_ms: 500,
          },
        },
      });
      vi.mocked(fetchWithCache).mockResolvedValue(mockTranscriptionResponse);

      await provider.callApi('/path/to/audio.mp3');

      const formData = vi.mocked(fetchWithCache).mock.calls[0]![1]!.body as unknown as MockFormData;
      expect(formData.get('response_format')).toBe('json');
      expect(formData.get('chunking_strategy[type]')).toBe('server_vad');
      expect(formData.get('chunking_strategy[threshold]')).toBe('0.6');
      expect(formData.get('chunking_strategy[prefix_padding_ms]')).toBe('300');
      expect(formData.get('chunking_strategy[silence_duration_ms]')).toBe('500');
    });

    it('should handle diarized transcription', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue(mockDiarizedResponse);

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.output).toBe(
        "[0.00s - 2.50s] Speaker 1: Hello, how are you?\n[2.50s - 5.00s] Speaker 2: I'm doing great, thanks!",
      );
      expect(result.cached).toBe(false);
      expect(result.cost).toBeCloseTo(0.018, 5); // 3 minutes * $0.006/min
      expect(result.metadata).toEqual({
        task: 'transcribe',
        duration: 180,
        language: 'en',
        segments: 2,
        avgLogprob: -0.3, // Average of -0.25 and -0.35
        avgCompressionRatio: 1.275, // Average of 1.3 and 1.25
        avgNoSpeechProb: 0.0075, // Average of 0.005 and 0.01
        speakers: ['Speaker 1', 'Speaker 2'],
      });
    });

    it('should enable automatic chunking for diarization', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue(mockDiarizedResponse);

      await provider.callApi('/path/to/audio.mp3');

      const formData = vi.mocked(fetchWithCache).mock.calls[0]![1]!.body as unknown as MockFormData;
      expect(formData.get('response_format')).toBe('diarized_json');
      expect(formData.get('chunking_strategy')).toBe('auto');
    });

    it('should include known speaker references for diarization', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize', {
        config: {
          apiKey: 'test-key',
          chunking_strategy: 'auto',
          prompt: 'This field is unsupported for diarization.',
          timestamp_granularities: ['word'],
          known_speaker_names: ['agent', 'customer'],
          known_speaker_references: [
            'data:audio/wav;base64,YWdlbnQ=',
            'data:audio/wav;base64,Y3VzdG9tZXI=',
          ],
        },
      });

      vi.mocked(fetchWithCache).mockResolvedValue(mockDiarizedResponse);

      await provider.callApi('/path/to/audio.mp3');

      const formData = vi.mocked(fetchWithCache).mock.calls[0]![1]!.body as unknown as MockFormData;
      expect(formData.get('chunking_strategy')).toBe('auto');
      expect(formData.has('prompt')).toBe(false);
      expect(formData.has('timestamp_granularities[]')).toBe(false);
      expect(formData.getAll('known_speaker_names[]')).toEqual(['agent', 'customer']);
      expect(formData.getAll('known_speaker_references[]')).toEqual([
        'data:audio/wav;base64,YWdlbnQ=',
        'data:audio/wav;base64,Y3VzdG9tZXI=',
      ]);
    });

    it('should encode a custom server VAD chunking strategy', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize', {
        config: {
          apiKey: 'test-key',
          chunking_strategy: {
            type: 'server_vad',
            threshold: 0.6,
            prefix_padding_ms: 300,
            silence_duration_ms: 500,
          },
        },
      });

      vi.mocked(fetchWithCache).mockResolvedValue(mockDiarizedResponse);

      await provider.callApi('/path/to/audio.mp3');

      const formData = vi.mocked(fetchWithCache).mock.calls[0]![1]!.body as unknown as MockFormData;
      expect(formData.has('chunking_strategy')).toBe(false);
      expect(formData.get('chunking_strategy[type]')).toBe('server_vad');
      expect(formData.get('chunking_strategy[threshold]')).toBe('0.6');
      expect(formData.get('chunking_strategy[prefix_padding_ms]')).toBe('300');
      expect(formData.get('chunking_strategy[silence_duration_ms]')).toBe('500');
    });
  });

  describe('Error handling', () => {
    it('should handle missing audio file', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fs.readFileSync).mockImplementation(function () {
        throw Object.assign(new Error('ENOENT: no such file or directory'), { code: 'ENOENT' });
      });

      const result = await provider.callApi('/path/to/missing.mp3');

      expect(result).toEqual({
        error: 'Audio file not found: /path/to/missing.mp3',
      });
    });

    it('should handle API errors', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      const errorResponse = {
        data: { error: 'Invalid audio format' },
        cached: false,
        status: 400,
        statusText: 'Bad Request',
      };

      vi.mocked(fetchWithCache).mockResolvedValue(errorResponse);

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toHaveProperty('error');
      expect(result.error).toContain('Invalid audio format');
    });

    it('should handle HTTP errors', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: 'Error message',
        cached: false,
        status: 500,
        statusText: 'Internal Server Error',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toHaveProperty('error');
      expect(result.error).toContain('API error: 500 Internal Server Error');
    });

    it('should handle fetch errors', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockRejectedValue(new Error('Network error'));

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toHaveProperty('error');
      expect(result.error).toContain('API call error: Error: Network error');
    });

    it('should handle missing transcription in response', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: { duration: 120 },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toHaveProperty('error');
      expect(result.error).toContain('No transcription returned from API');
    });

    it('should accept an empty transcription returned for silent audio', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-mini-transcribe-2025-12-15', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: { text: '', duration: 1 },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/silent.wav');

      expect(result.error).toBeUndefined();
      expect(result.output).toBe('');
    });

    it('should handle transcription error in catch block', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockImplementation(function () {
        throw new Error('Unexpected error');
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result).toHaveProperty('error');
      expect(result.error).toContain('API call error: Error: Unexpected error');
    });
  });

  describe('Configuration options', () => {
    it('should include language option', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          language: 'es',
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalled();
    });

    it('should include prompt option', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          prompt: 'This is a technical discussion about AI.',
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalled();
    });

    it('should include temperature option', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          temperature: 0.5,
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalled();
    });

    it('should include timestamp_granularities option', async () => {
      const provider = new OpenAiTranscriptionProvider('whisper-1', {
        config: {
          apiKey: 'test-key',
          timestamp_granularities: ['word', 'segment'],
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      const formData = vi.mocked(fetchWithCache).mock.calls[0]![1]!.body as unknown as MockFormData;
      expect(formData.get('response_format')).toBe('verbose_json');
      expect(formData.getAll('timestamp_granularities[]')).toEqual(['word', 'segment']);
      expect(formData.has('timestamp_granularities')).toBe(false);
    });

    it('should include organization ID in headers when provided', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          organization: 'test-org',
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            'OpenAI-Organization': 'test-org',
          }),
        }),
        expect.any(Number),
        'json',
        undefined,
        undefined,
      );
    });

    it('should merge prompt config with provider config', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key', temperature: 0.5 },
      });

      const context = {
        prompt: {
          raw: '/path/to/audio.mp3',
          config: { temperature: 0.8 },
          label: 'test',
        },
        vars: {},
      };

      await provider.callApi('/path/to/audio.mp3', context);

      // Config should be merged with prompt config taking precedence
      expect(fetchWithCache).toHaveBeenCalled();
    });

    it('should use custom API URL when provided', async () => {
      const customApiUrl = 'https://custom-openai.example.com/v1';
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: {
          apiKey: 'test-key',
          apiBaseUrl: customApiUrl,
        },
      });

      await provider.callApi('/path/to/audio.mp3');

      expect(fetchWithCache).toHaveBeenCalledWith(
        `${customApiUrl}/audio/transcriptions`,
        expect.any(Object),
        expect.any(Number),
        'json',
        undefined,
        undefined,
      );
    });

    it('should handle bustCache from context', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      const context = {
        bustCache: true,
        prompt: { raw: '/path/to/audio.mp3', label: 'test' },
        vars: {},
      };

      await provider.callApi('/path/to/audio.mp3', context);

      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.any(String),
        expect.any(Object),
        expect.any(Number),
        'json',
        true,
        undefined,
      );
    });

    it('should handle debug mode from context', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      const context = {
        debug: true,
        prompt: { raw: '/path/to/audio.mp3', label: 'test' },
        vars: {},
      };

      await provider.callApi('/path/to/audio.mp3', context);

      expect(fetchWithCache).toHaveBeenCalledWith(
        expect.any(String),
        expect.any(Object),
        expect.any(Number),
        'json',
        true,
        undefined,
      );
    });
  });

  describe('Model validation', () => {
    it('should accept known transcription models', () => {
      const models = [
        'gpt-4o-transcribe',
        'gpt-4o-mini-transcribe',
        'gpt-4o-mini-transcribe-2025-03-20',
        'gpt-4o-mini-transcribe-2025-12-15',
        'gpt-4o-transcribe-diarize',
        'gpt-4o-transcribe-diarize-2025-10-15',
        'whisper-1',
      ];

      models.forEach((model) => {
        const provider = new OpenAiTranscriptionProvider(model, {
          config: { apiKey: 'test-key' },
        });
        expect(provider.id()).toBe(`openai:transcription:${model}`);
      });
    });

    it('should allow unknown transcription models with debug log', () => {
      const provider = new OpenAiTranscriptionProvider('unknown-model', {
        config: { apiKey: 'test-key' },
      });

      expect(provider.id()).toBe('openai:transcription:unknown-model');
    });
  });

  describe('Edge cases', () => {
    it('should handle zero duration audio', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'Test',
          duration: 0,
          language: 'en',
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBe(0);
    });

    it('should leave cost undefined when the API omits duration', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          text: 'Test',
          language: 'en',
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.cost).toBeUndefined();
      expect(result.metadata?.duration).toBeUndefined();
    });

    it('should handle diarized segments with missing fields', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe-diarize', {
        config: { apiKey: 'test-key' },
      });

      vi.mocked(fetchWithCache).mockResolvedValue({
        data: {
          duration: 60,
          language: 'en',
          segments: [
            {
              // Missing speaker, start, end fields
              text: 'Test text',
            },
          ],
        },
        cached: false,
        status: 200,
        statusText: 'OK',
      });

      const result = await provider.callApi('/path/to/audio.mp3');

      expect(result.output).toBe('[0.00s - 0.00s] Unknown: Test text');
    });

    it('should trim whitespace from audio file path', async () => {
      const provider = new OpenAiTranscriptionProvider('gpt-4o-transcribe', {
        config: { apiKey: 'test-key' },
      });

      await provider.callApi('  /path/to/audio.mp3  ');

      expect(fs.readFileSync).toHaveBeenCalledWith('/path/to/audio.mp3');
    });
  });
});
