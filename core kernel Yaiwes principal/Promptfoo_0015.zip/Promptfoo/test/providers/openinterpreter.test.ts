import { EventEmitter } from 'events';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { PassThrough } from 'stream';

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import cliState from '../../src/cliState';
import { loadApiProvider } from '../../src/providers/index';
import { OpenInterpreterProvider } from '../../src/providers/openinterpreter';
import { providerRegistry } from '../../src/providers/providerRegistry';
import { mockProcessEnv } from '../util/utils';

const mocks = vi.hoisted(() => ({
  spawn: vi.fn(),
}));

vi.mock('child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('child_process')>();
  return { ...actual, spawn: mocks.spawn };
});

interface MockAppServer {
  proc: any;
  stderr: PassThrough;
  stdout: PassThrough;
  messages: () => any[];
  send: (message: unknown) => void;
}

function createMockAppServer(): MockAppServer {
  const proc = new EventEmitter() as any;
  const stdout = new PassThrough();
  const stderr = new PassThrough();
  const stdin = new PassThrough();
  const writes: string[] = [];

  proc.stdout = stdout;
  proc.stderr = stderr;
  proc.stdin = stdin;
  proc.killed = false;
  proc.exitCode = null;
  proc.kill = vi.fn((signal?: NodeJS.Signals) => {
    proc.killed = true;
    proc.exitCode = 0;
    proc.emit('exit', 0, signal ?? null);
    return true;
  });
  stdin.write = vi.fn((chunk: unknown) => {
    writes.push(String(chunk));
    const message = JSON.parse(String(chunk));
    if (message.method === 'thread/unsubscribe' || message.method === 'turn/interrupt') {
      queueMicrotask(() => stdout.write(`${JSON.stringify({ id: message.id, result: {} })}\n`));
    }
    return true;
  }) as any;
  stdin.end = vi.fn(() => stdin) as any;

  return {
    proc,
    stderr,
    stdout,
    messages: () =>
      writes
        .join('')
        .split('\n')
        .filter(Boolean)
        .map((line) => JSON.parse(line)),
    send: (message) => stdout.write(`${JSON.stringify(message)}\n`),
  };
}

async function waitForMessage(
  server: MockAppServer,
  predicate: (message: any) => boolean,
): Promise<any> {
  let found: any;
  await vi.waitFor(() => {
    found = server.messages().find(predicate);
    expect(found).toBeTruthy();
  });
  return found;
}

async function startTurn(
  server: MockAppServer,
  options: { apiKey?: string; threadId?: string; turnId?: string } = {},
): Promise<{ threadStart: any; turnStart: any }> {
  const initialize = await waitForMessage(server, (message) => message.method === 'initialize');
  server.send({ id: initialize.id, result: {} });

  if (options.apiKey) {
    const login = await waitForMessage(
      server,
      (message) => message.method === 'account/login/start',
    );
    expect(login.params).toEqual({ type: 'apiKey', apiKey: options.apiKey });
    server.send({ id: login.id, result: { type: 'apiKey' } });
  }

  const threadStart = await waitForMessage(
    server,
    (message) => message.method === 'thread/start' || message.method === 'thread/resume',
  );
  server.send({
    id: threadStart.id,
    result: { thread: { id: options.threadId ?? 'thr_interpreter' } },
  });

  const turnStart = await waitForMessage(server, (message) => message.method === 'turn/start');
  server.send({
    id: turnStart.id,
    result: { turn: { id: options.turnId ?? 'turn_interpreter', status: 'inProgress' } },
  });
  return { threadStart, turnStart };
}

function completeTurn(
  server: MockAppServer,
  output: string,
  options: { threadId?: string; turnId?: string } = {},
): void {
  const threadId = options.threadId ?? 'thr_interpreter';
  const turnId = options.turnId ?? 'turn_interpreter';
  server.send({
    method: 'item/completed',
    params: {
      threadId,
      turnId,
      item: { type: 'agentMessage', id: `message_${turnId}`, text: output },
    },
  });
  server.send({
    method: 'turn/completed',
    params: { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } },
  });
}

describe('OpenInterpreterProvider', () => {
  const temporaryRoots: string[] = [];

  beforeEach(() => {
    mocks.spawn.mockReset();
  });

  afterEach(async () => {
    await providerRegistry.shutdownAll();
    for (const root of temporaryRoots.splice(0)) {
      fs.rmSync(root, { recursive: true, force: true });
    }
    vi.restoreAllMocks();
  });

  it.each([
    ['openinterpreter', undefined],
    ['openinterpreter:gpt-5.4', 'gpt-5.4'],
    ['openinterpreter:provider:model-with:colon', 'provider:model-with:colon'],
  ])('loads %s through the provider registry', async (id, model) => {
    const provider = await loadApiProvider(id, {
      options: { config: { skip_git_repo_check: true } },
    });

    expect(provider).toBeInstanceOf(OpenInterpreterProvider);
    expect(provider.id()).toBe(id);
    expect((provider as OpenInterpreterProvider).config.model).toBe(model);
  });

  it('uses an isolated home, an empty workspace, and safe app-server defaults', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined, UNRELATED_SECRET_TOKEN: 'do-not-forward' });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);

    const provider = new OpenInterpreterProvider();
    expect(provider.getApiKey()).toBeUndefined();
    expect(provider.requiresApiKey()).toBe(false);
    expect(provider.toString()).toBe('[Open Interpreter Provider]');
    const resultPromise = provider.callApi('Say hello');
    const { threadStart, turnStart } = await startTurn(server);

    const [command, args, options] = mocks.spawn.mock.calls[0];
    expect(command).toBe('interpreter');
    expect(args).toEqual([
      'app-server',
      '--listen',
      'stdio://',
      '-c',
      'analytics.enabled=false',
      '-c',
      'feedback.enabled=false',
      '-c',
      'features.memories=false',
    ]);
    expect(options.shell).toBeUndefined();
    expect(options.env.UNRELATED_SECRET_TOKEN).toBeUndefined();
    expect(options.env.INTERPRETER_HOME).toContain('promptfoo-openinterpreter-home-');
    expect(fs.statSync(options.env.INTERPRETER_HOME).isDirectory()).toBe(true);
    expect(threadStart.params).toMatchObject({
      sandbox: 'read-only',
      approvalPolicy: 'untrusted',
      ephemeral: true,
    });
    expect(threadStart.params.cwd).toContain('promptfoo-openinterpreter-workspace-');
    expect(fs.readdirSync(threadStart.params.cwd)).toEqual([]);
    expect(turnStart.params.input).toEqual([
      { type: 'text', text: 'Say hello', text_elements: [] },
    ]);

    completeTurn(server, 'hello');
    const result = await resultPromise;
    expect(result.output).toBe('hello');
    expect(result.tokenUsage).toBeUndefined();
    expect(result.cost).toBeUndefined();
    expect(result.metadata?.openInterpreter).toMatchObject({
      sandboxMode: 'read-only',
      approvalPolicy: 'untrusted',
    });

    await provider.cleanup();
    expect(server.proc.kill).toHaveBeenCalledWith('SIGTERM');
    expect(fs.existsSync(options.env.INTERPRETER_HOME)).toBe(false);
    expect(fs.existsSync(threadStart.params.cwd)).toBe(false);
  });

  it('maps backend, harness, workspace, environment, schema, and timeout options without a shell', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter options '));
    temporaryRoots.push(root);
    const workspace = path.join(root, "workspace $() 'quoted' Ω");
    const home = path.join(root, 'home with spaces');
    const extra = path.join(root, 'extra workspace Ω');
    const interpreterPath = path.join(root, 'Open Interpreter', 'interpreter $(no-shell)');
    fs.mkdirSync(workspace);
    fs.mkdirSync(home);
    fs.mkdirSync(extra);
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);

    const provider = new OpenInterpreterProvider({
      id: 'openinterpreter:custom-model',
      config: {
        apiKey: 'explicit-test-key',
        interpreter_path: interpreterPath,
        interpreter_home: home,
        working_dir: workspace,
        additional_directories: [extra],
        skip_git_repo_check: true,
        model: 'custom-model',
        model_provider: 'openrouter',
        harness: 'claude-code-bare',
        harness_guidance: false,
        sandbox_mode: 'workspace-write',
        approval_policy: 'on-request',
        network_access_enabled: true,
        output_schema: { type: 'object', properties: { ok: { type: 'boolean' } } },
        request_timeout_ms: 5000,
        startup_timeout_ms: 5000,
        turn_timeout_ms: 10000,
        cli_config: { features: { hooks: false }, custom: { value: '$(echo nope)\nΩ' } },
        cli_env: { ROUTER_TOKEN: 'quoted "value"; $(nope)', NUMERIC_VALUE: 7 },
      },
    });

    const prompt = 'Use quotes " and apostrophes \' and $() safely\nUnicode: Ω';
    const resultPromise = provider.callApi(prompt);
    const { threadStart, turnStart } = await startTurn(server, { apiKey: 'explicit-test-key' });

    const [command, args, options] = mocks.spawn.mock.calls[0];
    expect(command).toBe(interpreterPath);
    expect(args).toEqual([
      'app-server',
      '--listen',
      'stdio://',
      '-c',
      'features.memories=false',
      '-c',
      'features.hooks=false',
      '-c',
      'custom.value="$(echo nope)\\nΩ"',
      '-c',
      'analytics.enabled=false',
      '-c',
      'feedback.enabled=false',
      '-c',
      'harness="claude-code-bare"',
      '-c',
      'harness_guidance=false',
    ]);
    expect(options.shell).toBeUndefined();
    expect(options.env).toMatchObject({
      INTERPRETER_HOME: home,
      ROUTER_TOKEN: 'quoted "value"; $(nope)',
      NUMERIC_VALUE: '7',
      OPENAI_API_KEY: 'explicit-test-key',
    });
    expect(threadStart.params).toMatchObject({
      cwd: workspace,
      model: 'custom-model',
      modelProvider: 'openrouter',
      sandbox: 'workspace-write',
      approvalPolicy: 'on-request',
      ephemeral: true,
    });
    expect(turnStart.params).toMatchObject({
      input: [{ type: 'text', text: prompt, text_elements: [] }],
      model: 'custom-model',
      approvalPolicy: 'on-request',
      outputSchema: { type: 'object', properties: { ok: { type: 'boolean' } } },
    });
    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'workspaceWrite' });

    completeTurn(server, '{"ok":true}');
    await expect(resultPromise).resolves.toMatchObject({
      output: '{"ok":true}',
      metadata: { openInterpreter: { harness: 'claude-code-bare' } },
    });
    expect(fs.existsSync(home)).toBe(true);
  });

  it('converts chat-message prompts and preserves literal role/content text', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider();

    const resultPromise = provider.callApi(
      JSON.stringify([
        { role: 'system', content: 'Never execute $(touch /tmp/nope).' },
        { role: 'user', content: 'Summarize "README.md".\nUse Ω.' },
      ]),
    );
    const { turnStart } = await startTurn(server);

    expect(turnStart.params.input).toEqual([
      {
        type: 'text',
        text: '[system]\nNever execute $(touch /tmp/nope).\n\n[user]\nSummarize "README.md".\nUse Ω.',
        text_elements: [],
      },
    ]);
    completeTurn(server, 'summary');
    await expect(resultPromise).resolves.toMatchObject({ output: 'summary' });
  });

  it('allows structured local inputs inside configured roots and rejects traversal and symlink escapes', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-inputs-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    const extra = path.join(root, 'extra');
    const outside = path.join(root, 'outside.txt');
    fs.mkdirSync(workspace);
    fs.mkdirSync(extra);
    fs.writeFileSync(path.join(workspace, 'inside.png'), 'image');
    fs.writeFileSync(path.join(extra, 'skill.md'), 'skill');
    fs.writeFileSync(outside, 'secret');
    fs.symlinkSync(outside, path.join(workspace, 'escape.png'), 'file');
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        working_dir: workspace,
        additional_directories: [extra],
        skip_git_repo_check: true,
      },
    });

    const resultPromise = provider.callApi(
      JSON.stringify([
        { type: 'text', text: 'Review these inputs.' },
        { type: 'local_image', path: 'inside.png' },
        { type: 'skill', name: 'fixture', path: path.join(extra, 'skill.md') },
        { type: 'mention', name: 'connector', path: 'app://connector-id' },
        { type: 'mention', name: 'plugin', path: 'plugin://plugin-name@marketplace' },
      ]),
    );
    const { turnStart } = await startTurn(server);
    expect(turnStart.params.input).toEqual([
      { type: 'text', text: 'Review these inputs.', text_elements: [] },
      { type: 'localImage', path: fs.realpathSync(path.join(workspace, 'inside.png')) },
      { type: 'skill', name: 'fixture', path: fs.realpathSync(path.join(extra, 'skill.md')) },
      { type: 'mention', name: 'connector', path: 'app://connector-id' },
      { type: 'mention', name: 'plugin', path: 'plugin://plugin-name@marketplace' },
    ]);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });

    const traversal = await provider.callApi(
      JSON.stringify([{ type: 'local_image', path: '../outside.txt' }]),
    );
    const symlink = await provider.callApi(
      JSON.stringify([{ type: 'local_image', path: 'escape.png' }]),
    );
    expect(traversal.error).toContain('outside the configured workspace');
    expect(symlink.error).toContain('outside the configured workspace');
    expect(mocks.spawn).toHaveBeenCalledTimes(1);
  });

  it('resolves relative structured-input workspaces from the provider config base path', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-base-path-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace);
    fs.writeFileSync(path.join(workspace, 'inside.png'), 'image');
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: { basePath: root, working_dir: 'workspace', skip_git_repo_check: true },
    });

    const resultPromise = provider.callApi(
      JSON.stringify([{ type: 'local_image', path: 'inside.png' }]),
    );
    const { threadStart, turnStart } = await startTurn(server);

    expect(threadStart.params.cwd).toBe(workspace);
    expect(turnStart.params.input).toEqual([
      { type: 'localImage', path: fs.realpathSync(path.join(workspace, 'inside.png')) },
    ]);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it.each([
    ['interpreter_home', { interpreter_home: '{% if useA %}home-a{% else %}home-b{% endif %}' }],
    [
      'cli_env.INTERPRETER_HOME',
      { cli_env: { INTERPRETER_HOME: '{% if useA %}home-a{% else %}home-b{% endif %}' } },
    ],
  ])(
    'renders a statement-templated %s before validating the home directory',
    async (_name, config) => {
      mockProcessEnv({ OPENAI_API_KEY: undefined });
      const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-home-statement-'));
      temporaryRoots.push(root);
      const home = path.join(root, 'home-a');
      const workspace = path.join(root, 'workspace');
      fs.mkdirSync(home);
      fs.mkdirSync(workspace);
      const server = createMockAppServer();
      mocks.spawn.mockReturnValue(server.proc);
      const provider = new OpenInterpreterProvider({
        config: { ...config, basePath: root, working_dir: workspace, skip_git_repo_check: true },
      } as any);

      const resultPromise = provider.callApi('templated home', {
        vars: { useA: true },
        prompt: { raw: 'templated home', label: 'home statement template' },
      } as any);
      await startTurn(server);

      expect(mocks.spawn.mock.calls[0][2].env.INTERPRETER_HOME).toBe(home);
      completeTurn(server, 'reviewed');
      await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
    },
  );

  it('renders row workspace variables before validating structured input paths', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-row-workspace-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace);
    fs.writeFileSync(path.join(workspace, 'inside.png'), 'image');
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({ config: { basePath: root } });

    const resultPromise = provider.callApi(
      JSON.stringify([{ type: 'local_image', path: 'inside.png' }]),
      {
        vars: {
          workspace: 'workspace',
          sandbox: 'read-only',
          timeout: 1000,
          skipGitCheck: true,
          instruction: 'keep the literal {{secret}} placeholder',
          secret: 'must-not-expand',
        },
        prompt: {
          config: {
            working_dir: '{{workspace}}',
            sandbox_mode: '{{sandbox}}',
            turn_timeout_ms: '{{timeout}}',
            skip_git_repo_check: '{{skipGitCheck}}',
            base_instructions: '{{instruction}}',
          },
        },
      } as any,
    );
    const { threadStart, turnStart } = await startTurn(server);

    expect(threadStart.params.cwd).toBe(workspace);
    expect(threadStart.params.baseInstructions).toBe('keep the literal {{secret}} placeholder');
    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'readOnly' });
    expect(turnStart.params.input).toEqual([
      { type: 'localImage', path: fs.realpathSync(path.join(workspace, 'inside.png')) },
    ]);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('renders and validates typed base-provider templates for each row', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-base-template-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace);
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        basePath: root,
        working_dir: '{{workspace}}',
        sandbox_mode: '{{sandbox}}',
        turn_timeout_ms: '{{timeout}}',
        network_access_enabled: '{{network}}',
        skip_git_repo_check: true,
      } as any,
    });

    const resultPromise = provider.callApi('templated base config', {
      vars: { workspace: 'workspace', sandbox: 'read-only', timeout: 1000, network: false },
      prompt: { raw: 'templated base config', label: 'base template' },
    } as any);
    const { threadStart, turnStart } = await startTurn(server);

    expect(threadStart.params.cwd).toBe(workspace);
    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'readOnly' });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('renders Nunjucks statement templates in typed base-provider options', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        skip_git_repo_check: '{% if skipGitCheck %}\ntrue\n{% else %}\nfalse\n{% endif %}',
        sandbox_mode: '{% if writable %}\nworkspace-write\n{% else %}\nread-only\n{% endif %}',
        network_access_enabled: '{% if network %}\ntrue\n{% else %}\nfalse\n{% endif %}',
        turn_timeout_ms: '{% if timeout %}\n1000\n{% else %}\n500\n{% endif %}',
      } as any,
    });

    const resultPromise = provider.callApi('conditional config', {
      vars: { writable: false, network: false, skipGitCheck: true, timeout: true },
      prompt: { raw: 'conditional config', label: 'conditional template' },
    } as any);
    const { turnStart } = await startTurn(server);

    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'readOnly' });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('renders block-style Nunjucks statement templates in typed row options', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider();

    const resultPromise = provider.callApi('conditional row config', {
      vars: { writable: false, network: false, skipGitCheck: true, timeout: true },
      prompt: {
        raw: 'conditional row config',
        label: 'conditional row template',
        config: {
          skip_git_repo_check: '{% if skipGitCheck %}\ntrue\n{% else %}\nfalse\n{% endif %}',
          sandbox_mode: '{% if writable %}\nworkspace-write\n{% else %}\nread-only\n{% endif %}',
          network_access_enabled: '{% if network %}\ntrue\n{% else %}\nfalse\n{% endif %}',
          turn_timeout_ms: '{% if timeout %}\n1000\n{% else %}\n500\n{% endif %}',
        },
      },
    } as any);
    const { turnStart } = await startTurn(server);

    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'readOnly' });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('renders Nunjucks comment templates in typed base-provider options', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        skip_git_repo_check: true,
        sandbox_mode: '{# choose readonly #}read-only',
      } as any,
    });

    const resultPromise = provider.callApi('comment config', {
      vars: {},
      prompt: { raw: 'comment config', label: 'comment template' },
    } as any);
    const { turnStart } = await startTurn(server);

    expect(turnStart.params.sandboxPolicy).toMatchObject({ type: 'readOnly' });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('renders a nested base-provider approval template for each row', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        skip_git_repo_check: true,
        server_request_policy: { command_execution: '{{decision}}' },
      } as any,
    });

    const resultPromise = provider.callApi('templated approval', {
      vars: { decision: 'accept' },
      prompt: { raw: 'templated approval', label: 'approval template' },
    } as any);
    await startTurn(server);
    server.send({
      id: 81,
      method: 'item/commandExecution/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'cmd_1' },
    });

    await expect(
      waitForMessage(server, (message) => message.id === 81 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'accept' } });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('coerces a nested prompt-level boolean template before approval validation', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({ config: { skip_git_repo_check: true } });

    const resultPromise = provider.callApi('templated permissions', {
      vars: { strict: false },
      prompt: {
        raw: 'templated permissions',
        label: 'permissions template',
        config: {
          server_request_policy: {
            permissions: {
              strict_auto_review: '{% if strict %}\ntrue\n{% else %}\nfalse\n{% endif %}',
            },
          },
        },
      },
    } as any);
    await startTurn(server);
    server.send({
      id: 82,
      method: 'item/permissions/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'permission_1' },
    });

    await expect(
      waitForMessage(server, (message) => message.id === 82 && message.result),
    ).resolves.toMatchObject({
      result: { permissions: {}, scope: 'turn', strictAutoReview: false },
    });
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('merges templated base request policies with partial row overrides', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        skip_git_repo_check: true,
        server_request_policy: {
          command_execution: 'accept',
          permissions: { permissions: { read: true }, scope: 'session' },
          user_input: { q1: '{{answer}}' },
          dynamic_tools: { baseTool: { success: true, text: 'base result' } },
          mcp_elicitation: { action: 'accept', content: { answer: 'base' } },
        },
      } as any,
    });

    const resultPromise = provider.callApi('merged request policy', {
      vars: { answer: 'approved' },
      prompt: {
        raw: 'merged request policy',
        label: 'merged policy',
        config: {
          server_request_policy: {
            file_change: 'decline',
            permissions: { strict_auto_review: false },
            dynamic_tools: {
              baseTool: { success: false },
              rowTool: { success: true, text: 'row result' },
            },
            mcp_elicitation: { action: 'decline' },
          },
        },
      },
    } as any);
    await startTurn(server);

    server.send({
      id: 83,
      method: 'item/commandExecution/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'command_1' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 83 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'accept' } });

    server.send({
      id: 84,
      method: 'item/fileChange/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'file_1' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 84 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'decline' } });

    server.send({
      id: 85,
      method: 'item/permissions/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'permission_1' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 85 && message.result),
    ).resolves.toMatchObject({
      result: { permissions: { read: true }, scope: 'session', strictAutoReview: false },
    });

    server.send({
      id: 86,
      method: 'item/tool/requestUserInput',
      params: {
        threadId: 'thr_1',
        turnId: 'turn_1',
        itemId: 'input_1',
        questions: [{ id: 'q1', header: 'Question', question: 'Approve?', options: [] }],
      },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 86 && message.result),
    ).resolves.toMatchObject({ result: { answers: { q1: { answers: ['approved'] } } } });

    server.send({
      id: 87,
      method: 'item/tool/call',
      params: {
        threadId: 'thr_1',
        turnId: 'turn_1',
        callId: 'tool_1',
        tool: 'baseTool',
        arguments: {},
      },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 87 && message.result),
    ).resolves.toMatchObject({
      result: { contentItems: [{ type: 'inputText', text: '' }], success: false },
    });

    server.send({
      id: 88,
      method: 'mcpServer/elicitation/request',
      params: { threadId: 'thr_1', turnId: 'turn_1', serverName: 'forms', mode: 'form' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 88 && message.result),
    ).resolves.toMatchObject({
      result: { action: 'decline', content: null, _meta: null },
    });

    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it.each([
    ['interpreter_home', { interpreter_home: '{{home}}' }],
    ['cli_env.INTERPRETER_HOME', { cli_env: { INTERPRETER_HOME: '{{home}}' } }],
  ])('renders a row-templated %s before validating the home directory', async (_name, config) => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-home-template-'));
    temporaryRoots.push(root);
    const home = path.join(root, 'home');
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(home);
    fs.mkdirSync(workspace);
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: { ...config, basePath: root, working_dir: workspace, skip_git_repo_check: true },
    } as any);

    const resultPromise = provider.callApi('templated home', {
      vars: { home: 'home' },
      prompt: { raw: 'templated home', label: 'home template' },
    } as any);
    await startTurn(server);

    expect(mocks.spawn.mock.calls[0][2].env.INTERPRETER_HOME).toBe(home);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('allows framework test options in prompt config while rejecting provider-option typos', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const attachedProvider = {
      id: vi.fn(() => 'attached-target'),
      callApi: vi.fn(),
    };
    const provider = new OpenInterpreterProvider({
      config: { provider: attachedProvider },
    } as any);

    const resultPromise = provider.callApi('framework options', {
      vars: {},
      prompt: {
        config: {
          transform: 'output',
          storeOutputAs: 'saved',
          runSerially: true,
          provider: attachedProvider,
          redteamGraderExamples: [
            { output: 'example', pass: true, score: 1, reason: 'global grader example' },
          ],
        },
      },
    } as any);
    await startTurn(server);
    completeTurn(server, 'ok');

    await expect(resultPromise).resolves.toMatchObject({ output: 'ok' });
    expect(attachedProvider.id).not.toHaveBeenCalled();
    expect(attachedProvider.callApi).not.toHaveBeenCalled();
    await expect(
      provider.callApi('bad config', {
        vars: {},
        prompt: { config: { approval_policiy: 'never' } },
      } as any),
    ).resolves.toMatchObject({ error: expect.stringContaining('approval_policiy') });
  });

  it('coerces env-rendered typed options when loading Open Interpreter', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined, OI_TIMEOUT: '1000', OI_SKIP_GIT: 'true' });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);

    const provider = await loadApiProvider('openinterpreter', {
      options: {
        config: {
          turn_timeout_ms: '{{ env.OI_TIMEOUT }}',
          skip_git_repo_check: '{{ env.OI_SKIP_GIT }}',
        },
      },
    } as any);

    const resultPromise = provider.callApi('env-rendered config');
    await startTurn(server);
    completeTurn(server, 'reviewed');

    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
    expect(mocks.spawn.mock.calls[0][1]).toEqual(expect.arrayContaining(['app-server']));
  });

  it('preserves free-form boolean-like strings while coercing schema-defined request-policy booleans', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        skip_git_repo_check: true,
        server_request_policy: {
          permissions: {
            permissions: {
              success: '{{yes}}',
              rules: '{{no}}',
              turn_timeout_ms: '{{timeout}}',
              skip_git_repo_check: '{{skip}}',
            },
            strict_auto_review: '{{no}}',
          },
          user_input: {
            success: '{{yes}}',
            rules: '{{no}}',
            turn_timeout_ms: '{{timeout}}',
            skip_git_repo_check: '{{skip}}',
          },
          dynamic_tools: {
            boolTool: { success: '{{yes}}', text: '{{no}}' },
          },
        },
      } as any,
    });

    const resultPromise = provider.callApi('boolean-like strings', {
      vars: { yes: 'true', no: 'false', timeout: '1000', skip: 'true' },
      prompt: { raw: 'boolean-like strings', label: 'typed paths' },
    } as any);
    await startTurn(server);

    server.send({
      id: 88,
      method: 'item/permissions/requestApproval',
      params: { threadId: 'thr_1', turnId: 'turn_1', itemId: 'permission_1' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 88 && message.result),
    ).resolves.toMatchObject({
      result: {
        permissions: {
          success: 'true',
          rules: 'false',
          turn_timeout_ms: '1000',
          skip_git_repo_check: 'true',
        },
        strictAutoReview: false,
      },
    });

    server.send({
      id: 89,
      method: 'item/tool/requestUserInput',
      params: {
        threadId: 'thr_1',
        turnId: 'turn_1',
        itemId: 'input_1',
        questions: [
          { id: 'success', header: 'Success', question: 'Success?', options: [] },
          { id: 'rules', header: 'Rules', question: 'Rules?', options: [] },
          { id: 'turn_timeout_ms', header: 'Timeout', question: 'Timeout?', options: [] },
          { id: 'skip_git_repo_check', header: 'Skip Git', question: 'Skip Git?', options: [] },
        ],
      },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 89 && message.result),
    ).resolves.toMatchObject({
      result: {
        answers: {
          success: { answers: ['true'] },
          rules: { answers: ['false'] },
          turn_timeout_ms: { answers: ['1000'] },
          skip_git_repo_check: { answers: ['true'] },
        },
      },
    });

    server.send({
      id: 90,
      method: 'item/tool/call',
      params: {
        threadId: 'thr_1',
        turnId: 'turn_1',
        callId: 'tool_1',
        tool: 'boolTool',
        arguments: {},
      },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 90 && message.result),
    ).resolves.toMatchObject({
      result: { contentItems: [{ type: 'inputText', text: 'false' }], success: true },
    });

    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('forwards only the validated absolute local path when the launch directory contains a different file', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-path-leak-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace);
    fs.writeFileSync(path.join(root, '.env'), 'launch-directory-secret');
    fs.writeFileSync(path.join(workspace, '.env'), 'workspace-image');
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: { working_dir: workspace, skip_git_repo_check: true },
    });

    const resultPromise = provider.callApi(JSON.stringify([{ type: 'local_image', path: '.env' }]));
    const { turnStart } = await startTurn(server);
    expect(turnStart.params.input).toEqual([
      { type: 'localImage', path: fs.realpathSync(path.join(workspace, '.env')) },
    ]);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });

    fs.rmSync(path.join(workspace, '.env'));
    await expect(
      provider.callApi(JSON.stringify([{ type: 'local_image', path: '.env' }])),
    ).resolves.toMatchObject({
      error: expect.stringContaining('does not exist or is not accessible'),
    });
    expect(mocks.spawn).toHaveBeenCalledTimes(1);
  });

  it('rejects an absolute cross-drive relative result using portable Windows path semantics', async () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-win32-path-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace);
    fs.writeFileSync(path.join(workspace, 'inside.png'), 'image');
    const provider = new OpenInterpreterProvider({
      config: { working_dir: workspace, skip_git_repo_check: true },
    });
    const win32IsAbsolute = path.win32.isAbsolute;
    vi.spyOn(path, 'relative').mockReturnValue('D:\\outside\\secret.png');
    vi.spyOn(path, 'isAbsolute').mockImplementation(win32IsAbsolute);

    await expect(
      provider.callApi(JSON.stringify([{ type: 'local_image', path: 'inside.png' }])),
    ).resolves.toMatchObject({
      error: expect.stringContaining('outside the configured workspace'),
    });
    expect(mocks.spawn).not.toHaveBeenCalled();
  });

  it('resolves interpreter_path and interpreter_home from the config directory while preserving PATH lookup', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-config-paths-'));
    temporaryRoots.push(root);
    const home = path.join(root, 'oi-home');
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(home);
    fs.mkdirSync(workspace);
    const relativeServer = createMockAppServer();
    const pathServer = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(relativeServer.proc).mockReturnValueOnce(pathServer.proc);

    const relative = new OpenInterpreterProvider({
      config: {
        basePath: root,
        interpreter_path: './bin/oi',
        interpreter_home: './oi-home',
        working_dir: './workspace',
        skip_git_repo_check: true,
      },
    });
    const relativePromise = relative.callApi('relative paths');
    await startTurn(relativeServer);
    expect(mocks.spawn.mock.calls[0][0]).toBe(path.join(root, 'bin', 'oi'));
    expect(mocks.spawn.mock.calls[0][2].env.INTERPRETER_HOME).toBe(home);
    completeTurn(relativeServer, 'relative');
    await expect(relativePromise).resolves.toMatchObject({ output: 'relative' });

    const fromPath = new OpenInterpreterProvider({ config: { interpreter_path: 'oi' } });
    const pathPromise = fromPath.callApi('PATH lookup');
    await startTurn(pathServer);
    expect(mocks.spawn.mock.calls[1][0]).toBe('oi');
    completeTurn(pathServer, 'path');
    await expect(pathPromise).resolves.toMatchObject({ output: 'path' });
  });

  it('falls back to cliState.basePath for relative interpreter paths, like the delegate', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-clistate-'));
    temporaryRoots.push(root);
    const home = path.join(root, 'oi-home');
    fs.mkdirSync(home);
    const server = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(server.proc);

    const previousBasePath = cliState.basePath;
    cliState.basePath = root;
    try {
      const provider = new OpenInterpreterProvider({
        config: {
          interpreter_path: './bin/oi',
          interpreter_home: './oi-home',
        },
      });
      const promise = provider.callApi('cliState fallback');
      await startTurn(server);
      expect(mocks.spawn.mock.calls[0][0]).toBe(path.join(root, 'bin', 'oi'));
      expect(mocks.spawn.mock.calls[0][2].env.INTERPRETER_HOME).toBe(home);
      completeTurn(server, 'ok');
      await expect(promise).resolves.toMatchObject({ output: 'ok' });
    } finally {
      cliState.basePath = previousBasePath;
    }
  });

  it('uses a config-relative INTERPRETER_HOME from cli_env and ignores a missing optional root', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-env-home-'));
    temporaryRoots.push(root);
    const home = path.join(root, 'home');
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(home);
    fs.mkdirSync(workspace);
    fs.writeFileSync(path.join(workspace, 'inside.png'), 'image');
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        basePath: root,
        working_dir: './workspace',
        additional_directories: ['./optional-missing-root'],
        skip_git_repo_check: true,
        cli_env: { INTERPRETER_HOME: './home' },
      },
    });

    const resultPromise = provider.callApi(
      JSON.stringify([{ type: 'local_image', path: 'inside.png' }]),
    );
    const { turnStart } = await startTurn(server);
    expect(mocks.spawn.mock.calls[0][2].env.INTERPRETER_HOME).toBe(home);
    expect(turnStart.params.input).toEqual([
      { type: 'localImage', path: fs.realpathSync(path.join(workspace, 'inside.png')) },
    ]);
    completeTurn(server, 'reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'reviewed' });
  });

  it('passes non-array JSON and malformed structured arrays through as literal text', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const first = createMockAppServer();
    const second = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(first.proc).mockReturnValueOnce(second.proc);
    const provider = new OpenInterpreterProvider();

    for (const [server, prompt] of [
      [first, '{"task":"literal JSON"}'],
      [second, '[{"unexpected":true}]'],
    ] as const) {
      const resultPromise = provider.callApi(prompt);
      const { turnStart } = await startTurn(server);
      expect(turnStart.params.input).toEqual([{ type: 'text', text: prompt, text_elements: [] }]);
      completeTurn(server, 'literal');
      await expect(resultPromise).resolves.toMatchObject({ output: 'literal' });
    }
  });

  it('does not leak the generated-workspace Git bypass into a prompt-level real workspace', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-git-check-'));
    temporaryRoots.push(root);
    const workspace = path.join(root, 'not-a-repo');
    fs.mkdirSync(workspace);
    const existsSync = fs.existsSync;
    vi.spyOn(fs, 'existsSync').mockImplementation((candidate) =>
      String(candidate).endsWith(`${path.sep}.git`) ? false : existsSync(candidate),
    );
    const provider = new OpenInterpreterProvider();

    await expect(
      provider.callApi('real workspace', {
        prompt: { config: { working_dir: workspace } },
        vars: {},
      } as any),
    ).resolves.toMatchObject({ error: expect.stringContaining('not inside a Git repository') });
    expect(mocks.spawn).not.toHaveBeenCalled();

    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const defaultPromise = provider.callApi('temporary workspace');
    const { threadStart } = await startTurn(server);
    expect(threadStart.params.cwd).toContain('promptfoo-openinterpreter-workspace-');
    completeTurn(server, 'temporary');
    await expect(defaultPromise).resolves.toMatchObject({ output: 'temporary' });
  });

  it.each([
    ['native', 'harness=""'],
    ['claude-code', 'harness="claude-code"'],
    ['claude-code-bare', 'harness="claude-code-bare"'],
    ['deepseek-tui', 'harness="deepseek-tui"'],
    ['kimi-code', 'harness="kimi-code"'],
    ['kimi-cli', 'harness="kimi-cli"'],
    ['zcode', 'harness="zcode"'],
    ['little-coder', 'harness="little-coder"'],
    ['mini-swe-agent', 'harness="mini-swe-agent"'],
    ['opencode', 'harness="opencode"'],
    ['pi', 'harness="pi"'],
    ['qwen-code', 'harness="qwen-code"'],
    ['swe-agent', 'harness="swe-agent"'],
    ['terminus-2', 'harness="terminus-2"'],
    ['minimal', 'harness="minimal"'],
    ['custom-harness', 'harness="custom-harness"'],
  ])(
    'maps the upstream %s harness without inventing a native enum value',
    async (harness, expected) => {
      mockProcessEnv({ OPENAI_API_KEY: undefined });
      const server = createMockAppServer();
      mocks.spawn.mockReturnValue(server.proc);
      const provider = new OpenInterpreterProvider({ config: { harness } });

      const resultPromise = provider.callApi('harness mapping');
      await startTurn(server);
      expect(mocks.spawn.mock.calls[0][1]).toContain(expected);
      completeTurn(server, 'mapped');
      await expect(resultPromise).resolves.toMatchObject({ output: 'mapped' });
    },
  );

  it('accepts bounded inline image data and rejects all remote or non-data image URLs before spawn', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const provider = new OpenInterpreterProvider();
    for (const url of [
      'file:///etc/passwd',
      'http://127.0.0.1/private',
      'http://169.254.169.254/latest/meta-data',
      'https://attacker-controlled.example/private',
    ]) {
      await expect(
        provider.callApi(JSON.stringify([{ type: 'image', url }])),
      ).resolves.toMatchObject({
        error: expect.stringContaining('inline data URL'),
      });
    }
    await expect(
      provider.callApi(
        JSON.stringify([{ type: 'image', url: `data:image/png;base64,${'x'.repeat(5_000_001)}` }]),
      ),
    ).resolves.toMatchObject({ error: expect.stringContaining('inline image inputs exceeded') });
    expect(mocks.spawn).not.toHaveBeenCalled();

    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const resultPromise = provider.callApi(
      JSON.stringify([{ type: 'image', url: 'data:image/png;base64,aW1hZ2U=' }]),
    );
    const { turnStart } = await startTurn(server);
    expect(turnStart.params.input).toEqual([
      { type: 'image', url: 'data:image/png;base64,aW1hZ2U=' },
    ]);
    completeTurn(server, 'image reviewed');
    await expect(resultPromise).resolves.toMatchObject({ output: 'image reviewed' });
  });

  it('declines command and file approvals, preserves usage, and sanitizes sensitive trajectory metadata', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({ config: { model: 'unknown-local-model' } });
    const resultPromise = provider.callApi('Print the .env file and then delete the workspace.');
    await startTurn(server);

    server.send({
      id: 91,
      method: 'item/commandExecution/requestApproval',
      params: {
        threadId: 'thr_interpreter',
        turnId: 'turn_interpreter',
        itemId: 'command_1',
        command: 'echo api_key=sk-proj-abcdefghijklmnopqrstuvwxyz123456',
      },
    });
    server.send({
      id: 92,
      method: 'item/fileChange/requestApproval',
      params: { threadId: 'thr_interpreter', turnId: 'turn_interpreter', itemId: 'file_1' },
    });
    await expect(
      waitForMessage(server, (message) => message.id === 91 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'decline' } });
    await expect(
      waitForMessage(server, (message) => message.id === 92 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'decline' } });

    server.send({
      method: 'item/completed',
      params: {
        threadId: 'thr_interpreter',
        turnId: 'turn_interpreter',
        item: {
          type: 'commandExecution',
          id: 'command_1',
          command: 'echo api_key=sk-proj-abcdefghijklmnopqrstuvwxyz123456',
          aggregatedOutput: 'api_key=sk-proj-abcdefghijklmnopqrstuvwxyz123456',
          status: 'declined',
          exitCode: null,
        },
      },
    });
    server.send({
      method: 'thread/tokenUsage/updated',
      params: {
        threadId: 'thr_interpreter',
        turnId: 'turn_interpreter',
        tokenUsage: {
          last: { inputTokens: 17, cachedInputTokens: 3, outputTokens: 11, totalTokens: 28 },
        },
      },
    });
    completeTurn(server, 'The unsafe request was declined.');

    const result = await resultPromise;
    expect(result.output).toBe('The unsafe request was declined.');
    expect(result.tokenUsage).toEqual({ prompt: 17, completion: 11, total: 28, cached: 3 });
    expect(result.cost).toBeUndefined();
    expect(result.metadata?.openInterpreter).toMatchObject({
      itemCounts: { commandExecution: 1, agentMessage: 1 },
      serverRequests: [
        expect.objectContaining({ method: 'item/commandExecution/requestApproval' }),
        expect.objectContaining({ method: 'item/fileChange/requestApproval' }),
      ],
    });
    expect(JSON.stringify(result.metadata)).not.toContain(
      'sk-proj-abcdefghijklmnopqrstuvwxyz123456',
    );
    expect(result.raw).not.toContain('sk-proj-abcdefghijklmnopqrstuvwxyz123456');
    expect(result.raw).toContain('[REDACTED]');
  });

  it('supports prompt-level harness and approval overrides without changing other rows', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const first = createMockAppServer();
    const second = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(first.proc).mockReturnValueOnce(second.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        cli_config: {
          analytics: { enabled: true, sink: 'base' },
          feedback: { enabled: true },
          features: { hooks: false, nested: { base: true } },
        },
      },
    });

    const firstPromise = provider.callApi('First row', {
      prompt: {
        config: {
          harness: 'minimal',
          cli_config: { features: { memories: true, nested: { row: true } } },
          server_request_policy: { command_execution: 'accept' },
        },
      },
      vars: {},
    } as any);
    await startTurn(first, { threadId: 'thr_first', turnId: 'turn_first' });
    first.send({
      id: 51,
      method: 'item/commandExecution/requestApproval',
      params: { threadId: 'thr_first', turnId: 'turn_first', itemId: 'cmd_first' },
    });
    await expect(
      waitForMessage(first, (message) => message.id === 51 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'accept' } });
    completeTurn(first, 'first', { threadId: 'thr_first', turnId: 'turn_first' });
    await expect(firstPromise).resolves.toMatchObject({
      metadata: { openInterpreter: { harness: 'minimal' } },
    });

    const secondPromise = provider.callApi('Second row');
    await startTurn(second, { threadId: 'thr_second', turnId: 'turn_second' });
    second.send({
      id: 52,
      method: 'item/commandExecution/requestApproval',
      params: { threadId: 'thr_second', turnId: 'turn_second', itemId: 'cmd_second' },
    });
    await expect(
      waitForMessage(second, (message) => message.id === 52 && message.result),
    ).resolves.toMatchObject({ result: { decision: 'decline' } });
    completeTurn(second, 'second', { threadId: 'thr_second', turnId: 'turn_second' });
    await expect(secondPromise).resolves.toMatchObject({ output: 'second' });

    expect(mocks.spawn.mock.calls[0][1]).toContain('harness="minimal"');
    expect(mocks.spawn.mock.calls[0][1]).toEqual(
      expect.arrayContaining([
        'analytics.enabled=true',
        'analytics.sink="base"',
        'feedback.enabled=true',
        'features.hooks=false',
        'features.memories=true',
        'features.nested.base=true',
        'features.nested.row=true',
      ]),
    );
    expect(mocks.spawn.mock.calls[1][1]).not.toContain('harness="minimal"');
  });

  it('runs concurrent rows in separate ephemeral processes and keeps their state isolated', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const first = createMockAppServer();
    const second = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(first.proc).mockReturnValueOnce(second.proc);
    const provider = new OpenInterpreterProvider();

    const firstPromise = provider.callApi('row one');
    const secondPromise = provider.callApi('row two');
    const firstTurn = await startTurn(first, { threadId: 'thr_one', turnId: 'turn_one' });
    const secondTurn = await startTurn(second, { threadId: 'thr_two', turnId: 'turn_two' });
    const firstWorkspace = firstTurn.threadStart.params.cwd;
    const secondWorkspace = secondTurn.threadStart.params.cwd;
    expect(firstWorkspace).not.toBe(secondWorkspace);
    fs.writeFileSync(path.join(firstWorkspace, 'row-one.txt'), 'row one state');
    expect(fs.existsSync(path.join(secondWorkspace, 'row-one.txt'))).toBe(false);
    expect(firstTurn.turnStart.params.input[0].text).toBe('row one');
    expect(secondTurn.turnStart.params.input[0].text).toBe('row two');

    completeTurn(second, 'second result', { threadId: 'thr_two', turnId: 'turn_two' });
    completeTurn(first, 'first result', { threadId: 'thr_one', turnId: 'turn_one' });
    await expect(Promise.all([firstPromise, secondPromise])).resolves.toMatchObject([
      { output: 'first result', sessionId: 'thr_one' },
      { output: 'second result', sessionId: 'thr_two' },
    ]);
    expect(mocks.spawn).toHaveBeenCalledTimes(2);
    expect(first.proc.kill).toHaveBeenCalledWith('SIGTERM');
    expect(second.proc.kill).toHaveBeenCalledWith('SIGTERM');
    expect(fs.existsSync(firstWorkspace)).toBe(false);
    expect(fs.existsSync(secondWorkspace)).toBe(false);
  });

  it('reuses the process and thread when persist_threads is explicitly requested', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-persistent-thread-'));
    temporaryRoots.push(root);
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider({
      config: { working_dir: root, skip_git_repo_check: true, persist_threads: true },
    });

    const firstPromise = provider.callApi('same prompt');
    const firstTurn = await startTurn(server, { threadId: 'thr_persisted', turnId: 'turn_first' });
    completeTurn(server, 'first', { threadId: 'thr_persisted', turnId: 'turn_first' });
    await expect(firstPromise).resolves.toMatchObject({
      output: 'first',
      sessionId: 'thr_persisted',
    });

    const secondPromise = provider.callApi('same prompt');
    const secondTurn = await waitForMessage(
      server,
      (message) =>
        message.method === 'turn/start' &&
        message.params?.threadId === 'thr_persisted' &&
        message.id !== firstTurn.turnStart.id,
    );
    server.send({
      id: secondTurn.id,
      result: { turn: { id: 'turn_second', status: 'inProgress' } },
    });
    completeTurn(server, 'second', { threadId: 'thr_persisted', turnId: 'turn_second' });
    await expect(secondPromise).resolves.toMatchObject({
      output: 'second',
      sessionId: 'thr_persisted',
    });
    expect(mocks.spawn).toHaveBeenCalledTimes(1);
    expect(server.messages().filter((message) => message.method === 'thread/start')).toHaveLength(
      1,
    );
  });

  it('allocates and removes a fresh writable temporary workspace for sequential rows', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const first = createMockAppServer();
    const second = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(first.proc).mockReturnValueOnce(second.proc);
    const provider = new OpenInterpreterProvider({
      config: {
        sandbox_mode: 'workspace-write',
        server_request_policy: { command_execution: 'accept', file_change: 'accept' },
      },
    });

    const firstPromise = provider.callApi('first row');
    const firstTurn = await startTurn(first, { threadId: 'thr_first', turnId: 'turn_first' });
    const firstWorkspace = firstTurn.threadStart.params.cwd;
    fs.writeFileSync(path.join(firstWorkspace, 'row-state.txt'), 'must not leak');
    completeTurn(first, 'first', { threadId: 'thr_first', turnId: 'turn_first' });
    await expect(firstPromise).resolves.toMatchObject({ output: 'first' });
    expect(fs.existsSync(firstWorkspace)).toBe(false);

    const secondPromise = provider.callApi('second row');
    const secondTurn = await startTurn(second, { threadId: 'thr_second', turnId: 'turn_second' });
    const secondWorkspace = secondTurn.threadStart.params.cwd;
    expect(secondWorkspace).not.toBe(firstWorkspace);
    expect(fs.existsSync(path.join(secondWorkspace, 'row-state.txt'))).toBe(false);
    completeTurn(second, 'second', { threadId: 'thr_second', turnId: 'turn_second' });
    await expect(secondPromise).resolves.toMatchObject({ output: 'second' });
    expect(fs.existsSync(secondWorkspace)).toBe(false);
  });

  it('returns actionable runtime errors for a missing executable and stderr-only process failure', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const missing = createMockAppServer();
    const missingPath = path.resolve('/missing/oi');
    mocks.spawn.mockReturnValueOnce(missing.proc);
    const missingProvider = new OpenInterpreterProvider({
      config: { interpreter_path: missingPath },
    });
    const missingPromise = missingProvider.callApi('hello');
    await waitForMessage(missing, (message) => message.method === 'initialize');
    missing.proc.emit('error', new Error(`spawn ${missingPath} ENOENT`));
    await expect(missingPromise).resolves.toMatchObject({
      error: expect.stringContaining(`Open Interpreter CLI was not found at ${missingPath}`),
    });

    const failed = createMockAppServer();
    mocks.spawn.mockReturnValueOnce(failed.proc);
    const provider = new OpenInterpreterProvider();
    const resultPromise = provider.callApi('hello');
    await waitForMessage(failed, (message) => message.method === 'initialize');
    failed.stderr.write(
      'backend credential unavailable api_key=sk-proj-abcdefghijklmnopqrstuvwxyz123456',
    );
    failed.proc.emit('exit', 2, null);
    const failedResult = await resultPromise;
    expect(failedResult.error).toContain('backend credential unavailable');
    expect(failedResult.error).toContain('[REDACTED]');
    expect(failedResult.error).not.toContain('sk-proj-abcdefghijklmnopqrstuvwxyz123456');
  });

  it('returns an abort error and cleans up the app-server process', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider();
    const abort = new AbortController();
    const resultPromise = provider.callApi('wait', undefined, { abortSignal: abort.signal } as any);
    await startTurn(server);
    abort.abort();

    await expect(resultPromise).resolves.toMatchObject({
      error: 'Open Interpreter app-server call aborted',
    });
    expect(server.proc.kill).toHaveBeenCalledWith('SIGTERM');
  });

  it('fails closed and cleans up when an upstream JSON-RPC message is oversized', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider();
    const resultPromise = provider.callApi('return a large result');
    await startTurn(server);

    server.send({
      method: 'item/completed',
      params: {
        threadId: 'thr_interpreter',
        turnId: 'turn_interpreter',
        item: { type: 'agentMessage', id: 'huge', text: 'x'.repeat(5_000_001) },
      },
    });

    await expect(resultPromise).resolves.toMatchObject({
      error: expect.stringContaining('Open Interpreter app-server JSON-RPC message exceeded'),
    });
    expect(server.proc.kill).toHaveBeenCalledWith('SIGTERM');
  });

  it('bounds accumulated streamed events and cleans up a flooding upstream process', async () => {
    mockProcessEnv({ OPENAI_API_KEY: undefined });
    const server = createMockAppServer();
    mocks.spawn.mockReturnValue(server.proc);
    const provider = new OpenInterpreterProvider();
    const resultPromise = provider.callApi('stream a large result');
    await startTurn(server);

    for (let index = 0; index < 3; index++) {
      server.send({
        method: 'item/agentMessage/delta',
        params: {
          threadId: 'thr_interpreter',
          turnId: 'turn_interpreter',
          itemId: 'stream',
          delta: 'x'.repeat(4_000_000),
        },
      });
    }

    expect(server.proc.kill).toHaveBeenCalledWith('SIGTERM');

    await expect(resultPromise).resolves.toMatchObject({
      error: expect.stringContaining('Open Interpreter app-server turn events exceeded'),
    });
    expect(server.proc.kill).toHaveBeenCalledWith('SIGTERM');
  });

  it('rejects incompatible config and missing homes before spawning a runtime', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'openinterpreter-invalid-home-'));
    temporaryRoots.push(root);
    const homeFile = path.join(root, 'not-a-directory');
    fs.writeFileSync(homeFile, 'file');

    expect(
      () => new OpenInterpreterProvider({ config: { sandbox_mode: 'readonly' } as any }),
    ).toThrow(/Invalid Open Interpreter config: sandbox_mode/);
    expect(
      () => new OpenInterpreterProvider({ config: { unsupported_option: true } as any }),
    ).toThrow(/Invalid Open Interpreter config: \(root\)/);
    expect(
      () => new OpenInterpreterProvider({ config: { allow_remote_images: true } as any }),
    ).toThrow(/Invalid Open Interpreter config: \(root\)/);
    expect(() => new OpenInterpreterProvider({ config: { persist_threads: true } })).toThrow(
      /persist_threads requires an explicit working_dir/,
    );
    expect(
      () =>
        new OpenInterpreterProvider({
          config: { working_dir: os.tmpdir(), persist_threads: true, reuse_server: false },
        }),
    ).toThrow(/persist_threads cannot be combined with reuse_server: false/);
    expect(
      () =>
        new OpenInterpreterProvider({
          config: { interpreter_home: path.join(os.tmpdir(), 'openinterpreter-missing-home') },
        }),
    ).toThrow(/Open Interpreter home .* does not exist or is not accessible/);
    expect(() => new OpenInterpreterProvider({ config: { interpreter_home: homeFile } })).toThrow(
      /Open Interpreter home .* not a directory/,
    );
    expect(mocks.spawn).not.toHaveBeenCalled();
  });

  it('removes an allocated temporary home if delegate construction fails', () => {
    const prefix = 'promptfoo-openinterpreter-home-';
    const mkdtemp = vi.spyOn(fs, 'mkdtempSync');
    vi.spyOn(providerRegistry, 'register').mockImplementationOnce(() => {
      throw new Error('registration failed');
    });

    expect(() => new OpenInterpreterProvider()).toThrow('registration failed');
    expect(mkdtemp).toHaveBeenCalledTimes(1);
    const allocatedHome = mkdtemp.mock.results[0]?.value as string;
    expect(allocatedHome.startsWith(path.join(os.tmpdir(), prefix))).toBe(true);
    expect(fs.existsSync(allocatedHome)).toBe(false);
    expect(mocks.spawn).not.toHaveBeenCalled();
  });

  it('returns invalid prompt-level config as a row error without starting a process', async () => {
    const provider = new OpenInterpreterProvider();

    await expect(
      provider.callApi('hello', {
        prompt: { config: { harness: '' } },
        vars: {},
      } as any),
    ).resolves.toMatchObject({
      error: expect.stringContaining('Invalid Open Interpreter config: harness'),
    });
    for (const config of [{ approval_policiy: 'never' }, { sandbox: 'workspace-write' }]) {
      await expect(
        provider.callApi('hello', { prompt: { config }, vars: {} } as any),
      ).resolves.toMatchObject({
        error: expect.stringContaining('Invalid Open Interpreter config'),
      });
    }
    expect(mocks.spawn).not.toHaveBeenCalled();
  });
});
