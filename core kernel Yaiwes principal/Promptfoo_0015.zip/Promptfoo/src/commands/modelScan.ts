import { spawn } from 'child_process';
import crypto from 'crypto';
import { mkdtempSync, rmSync, unlinkSync } from 'fs';
import fs from 'fs/promises';
import os from 'os';
import path from 'path';

import chalk from 'chalk';
import ora from 'ora';
import semver from 'semver';
import { z } from 'zod';
import { getEnvBool, isCI } from '../envars';
import { getAuthor } from '../globalConfig/accounts';
import { cloudConfig } from '../globalConfig/cloud';
import logger from '../logger';
import ModelAudit from '../models/modelAudit';
import { createShareableModelAuditUrl, isModelAuditSharingEnabled } from '../share';
import { checkModelAuditUpdates } from '../updates';
import {
  getHuggingFaceMetadata,
  isHuggingFaceModel,
  parseHuggingFaceModel,
} from '../util/huggingfaceMetadata';
import { DEPRECATED_OPTIONS_MAP, parseModelAuditArgs } from '../util/modelAuditCliParser';
import { checkModelAuditInstalled } from '../util/modelAuditInstall';
import { getModelAuditVerdict, parseCompleteModelAuditResults } from '../util/modelAuditResults';
import type { Command } from 'commander';

import type { ModelAuditIssue, ModelAuditScanResults } from '../types/modelAudit';

// Preserve the existing deep-import surface while the implementation lives in the node layer.
export { checkModelAuditInstalled };

// ============================================================================
// Types
// ============================================================================

interface SpawnResult {
  code: number | null;
  signal: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
}

interface RevisionInfo {
  modelId?: string;
  revisionSha?: string;
  contentHash?: string;
  modelSource?: string;
  sourceLastModified?: number;
}

interface HuggingFaceRevisionSnapshot {
  modelId: string;
  sha: string;
  lastModified: string;
}

interface ScanOptions {
  blacklist?: string[];
  timeout?: string;
  maxSize?: string;
  verbose?: boolean;
  sbom?: string;
  strict?: boolean;
  dryRun?: boolean;
  cache?: boolean;
  quiet?: boolean;
  progress?: boolean;
  stream?: boolean;
  output?: string;
  format?: string;
  write?: boolean;
  name?: string;
  force?: boolean;
  share?: boolean;
  noShare?: boolean;
  scanners?: string[];
  excludeScanner?: string[];
  listScanners?: boolean;
}

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Create a unique temp file path for JSON output.
 * Uses crypto.randomUUID() for better security against TOCTOU attacks.
 * @internal Exported for testing
 */
export function createTempOutputPath(): string {
  const tempDir = mkdtempSync(
    path.join(os.tmpdir(), `promptfoo-modelscan-${crypto.randomUUID()}-`),
  );
  return path.join(tempDir, 'results.json');
}

/**
 * Check if modelaudit version supports CLI UI with --output flag.
 * This feature was added in v0.2.20.
 * @internal Exported for testing
 */
export function supportsCliUiWithOutput(version: string | null): boolean {
  if (!version) {
    return false;
  }
  const parsed = semver.valid(semver.coerce(version));
  if (!parsed) {
    return false;
  }
  return semver.gte(parsed, '0.2.20');
}

/**
 * Determine if scan results contain any non-clean findings.
 */
function hasFindingsInResults(results: ModelAuditScanResults): boolean {
  return getModelAuditVerdict(results).hasFindings;
}

/**
 * Resolve abnormal subprocess termination into a non-zero wrapper exit code.
 *
 * modelaudit exit codes:
 * - 0: Scan completed successfully, no security issues found
 * - 1: Scan completed successfully, security issues were found (NOT an error)
 * - 2+: Fatal errors (e.g., invalid arguments)
 *
 * Child processes that terminate by signal report `code === null`, so they must be
 * handled separately instead of collapsing to a successful wrapper exit.
 */
function getProcessErrorExitCode(result: Pick<SpawnResult, 'code' | 'signal'>): number | null {
  if (result.signal !== null) {
    return 1;
  }

  if (result.code === null) {
    return 1;
  }

  return result.code > 1 ? result.code : null;
}

function logProcessError(result: Pick<SpawnResult, 'code' | 'signal'>): number | null {
  const exitCode = getProcessErrorExitCode(result);
  if (exitCode === null) {
    return null;
  }

  if (result.signal !== null) {
    logger.error(`Model scan process terminated by signal ${result.signal}`);
  } else if (result.code === null) {
    logger.error('Model scan process exited without an exit code');
  } else {
    logger.error(`Model scan process exited with code ${result.code}`);
  }

  return exitCode;
}

/**
 * Determine if a model should be re-scanned based on version changes.
 */
function shouldRescan(
  existingVersion: string | null | undefined,
  currentVersion: string | null,
): boolean {
  if (!currentVersion) {
    return false;
  }
  if (!existingVersion) {
    return true;
  }
  return existingVersion !== currentVersion;
}

/**
 * Warn about deprecated CLI options.
 */
function warnDeprecatedOptions(options: Record<string, unknown>): void {
  const deprecatedOptionsUsed = Object.keys(options).filter((opt) => {
    const fullOption = `--${opt.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
    return DEPRECATED_OPTIONS_MAP[fullOption] !== undefined;
  });

  for (const opt of deprecatedOptionsUsed) {
    const fullOption = `--${opt.replace(/([A-Z])/g, '-$1').toLowerCase()}`;
    const replacement = DEPRECATED_OPTIONS_MAP[fullOption];

    if (replacement) {
      logger.warn(`⚠️  Warning: '${fullOption}' is deprecated. Use '${replacement}' instead.`);
    } else if (fullOption === '--jfrog-api-token') {
      logger.warn(`⚠️  Warning: '${fullOption}' is deprecated. Set JFROG_API_TOKEN env var.`);
    } else if (fullOption === '--jfrog-access-token') {
      logger.warn(`⚠️  Warning: '${fullOption}' is deprecated. Set JFROG_ACCESS_TOKEN env var.`);
    } else if (fullOption === '--registry-uri') {
      logger.warn(
        `⚠️  Warning: '${fullOption}' is deprecated. Set JFROG_URL or MLFLOW_TRACKING_URI env var.`,
      );
    } else {
      logger.warn(`⚠️  Warning: '${fullOption}' is deprecated and has been removed.`);
    }
  }
}

/**
 * Spawn modelaudit with proper signal handling and Promise wrapper.
 * Returns stdout/stderr content when capturing output, or empty strings for inherited stdio.
 *
 * Signal handling note: Node.js does NOT automatically forward signals to child
 * processes, even with inherited stdio. When the parent receives SIGINT (Ctrl+C)
 * or SIGTERM, the child keeps running unless we explicitly kill it. This affects
 * ALL code paths that use this function (--no-write, saveToDatabase, etc.).
 */
function spawnModelAudit(
  args: string[],
  options: {
    captureOutput: boolean;
    env: NodeJS.ProcessEnv;
    onStdout?: (data: string) => void;
    onStderr?: (data: string) => void;
  },
): Promise<SpawnResult> {
  return new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    let settled = false;

    const spawnOptions = options.captureOutput
      ? { env: options.env }
      : { stdio: 'inherit' as const, env: options.env };

    const childProcess = spawn('modelaudit', args, spawnOptions);

    // Graceful shutdown - forward SIGINT/SIGTERM to child process
    const forwardSignal = (signal: NodeJS.Signals) => () => {
      if (!childProcess.killed) {
        childProcess.kill(signal);
      }
    };
    const forwardSigint = forwardSignal('SIGINT');
    const forwardSigterm = forwardSignal('SIGTERM');
    process.once('SIGINT', forwardSigint);
    process.once('SIGTERM', forwardSigterm);

    const removeListeners = () => {
      process.removeListener('SIGINT', forwardSigint);
      process.removeListener('SIGTERM', forwardSigterm);
    };

    if (options.captureOutput) {
      childProcess.stdout?.on('data', (data: Buffer) => {
        const str = data.toString();
        stdout += str;
        options.onStdout?.(str);
      });

      childProcess.stderr?.on('data', (data: Buffer) => {
        const str = data.toString();
        stderr += str;
        options.onStderr?.(str);
      });
    }

    childProcess.on('error', (error: Error) => {
      removeListeners();
      if (settled) {
        return;
      }
      settled = true;
      reject(error);
    });

    childProcess.on('close', (code: number | null, signal: NodeJS.Signals | null) => {
      removeListeners();
      if (settled) {
        return;
      }
      settled = true;
      resolve({ code, signal: signal ?? null, stdout, stderr });
    });
  });
}

function collectRepeatableOption(value: string, previous: string[] = []): string[] {
  return [...previous, value];
}

function hasScannerSelectionOptions(options: ScanOptions): boolean {
  return Boolean(options.scanners?.length || options.excludeScanner?.length);
}

function hasScannerSelectionValue(value: unknown): boolean {
  if (Array.isArray(value)) {
    return value.length > 0;
  }
  return typeof value === 'string' && value.trim().length > 0;
}

function hasPersistedScannerSelection(metadata: ModelAudit['metadata']): boolean {
  const options = metadata?.options;
  if (!options || typeof options !== 'object' || Array.isArray(options)) {
    return false;
  }

  return (
    hasScannerSelectionValue(options.scanners) || hasScannerSelectionValue(options.excludeScanner)
  );
}

/**
 * Parse CLI options through Zod, logging validation errors to the CLI.
 * Returns null when validation fails (and sets process.exitCode to 1).
 */
function buildCliArgs(
  paths: string[],
  cliOptions: Record<string, unknown>,
): { args: string[]; unsupportedOptions: string[] } | null {
  try {
    return parseModelAuditArgs(paths, cliOptions);
  } catch (error) {
    if (error instanceof z.ZodError) {
      logger.error(`Invalid model audit options provided:\n${z.prettifyError(error)}`);
      process.exitCode = 1;
      return null;
    }
    throw error;
  }
}

/**
 * Run modelaudit with inherited stdio and propagate its exit code.
 *
 * `treatExitOneAsIssues=true` suppresses the error log for exit code 1, which
 * modelaudit uses to mean "scan completed, issues found" — callers that expect
 * findings (like the main scan flow) should set this, while list/help flows
 * (where a non-zero exit is always unexpected) should leave it false.
 */
async function runPassthroughModelAudit(
  args: string[],
  env: NodeJS.ProcessEnv,
  treatExitOneAsIssues = false,
): Promise<void> {
  try {
    const spawnResult = await spawnModelAudit(args, { captureOutput: false, env });
    const processErrorExitCode = logProcessError(spawnResult);
    if (processErrorExitCode !== null) {
      process.exitCode = processErrorExitCode;
      return;
    }

    const isIssuesExit = treatExitOneAsIssues && spawnResult.code === 1;
    if (spawnResult.code !== null && spawnResult.code !== 0 && !isIssuesExit) {
      logger.error(`Model scan process exited with code ${spawnResult.code}`);
    }
    process.exitCode = spawnResult.code ?? 0;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.error(`Failed to start modelaudit: ${message}`);
    logger.info('Make sure modelaudit is installed and available in your PATH.');
    logger.info('Install it using: pip install modelaudit');
    process.exitCode = 1;
  }
}

/**
 * Check for existing scan and determine if re-scan is needed.
 * Returns the existing audit if found and re-scan should happen.
 */
async function checkExistingScan(
  paths: string[],
  options: ScanOptions,
  currentScannerVersion: string | null,
): Promise<{
  shouldSkip: boolean;
  existingAudit: ModelAudit | null;
  huggingFaceRevision?: HuggingFaceRevisionSnapshot;
}> {
  if (paths.length !== 1 || !isHuggingFaceModel(paths[0])) {
    return { shouldSkip: false, existingAudit: null };
  }

  try {
    const metadata = await getHuggingFaceMetadata(paths[0]);
    if (!metadata) {
      return { shouldSkip: false, existingAudit: null };
    }

    const parsed = parseHuggingFaceModel(paths[0]);
    const modelId = parsed ? `${parsed.owner}/${parsed.repo}` : paths[0];
    const existing = await ModelAudit.findByRevision(modelId, metadata.sha);
    const huggingFaceRevision = {
      modelId: metadata.modelId,
      sha: metadata.sha,
      lastModified: metadata.lastModified,
    };

    if (!existing) {
      return { shouldSkip: false, existingAudit: null, huggingFaceRevision };
    }

    if (hasScannerSelectionOptions(options)) {
      logger.debug('Re-scanning with scanner selection options');
      return { shouldSkip: false, existingAudit: existing, huggingFaceRevision };
    }

    if (hasPersistedScannerSelection(existing.metadata)) {
      logger.debug('Re-scanning because cached revision used scanner selection options');
      return { shouldSkip: false, existingAudit: existing, huggingFaceRevision };
    }

    // Force flag - re-scan but update existing record
    if (options.force) {
      logger.debug(`Re-scanning (--force): ${modelId}`);
      return { shouldSkip: false, existingAudit: existing, huggingFaceRevision };
    }

    // Version changed - re-scan
    if (shouldRescan(existing.scannerVersion, currentScannerVersion)) {
      const reason = existing.scannerVersion
        ? `modelaudit upgraded from ${existing.scannerVersion} to ${currentScannerVersion}`
        : `previous scan missing version info (now using ${currentScannerVersion})`;
      logger.debug(`Re-scanning: ${reason}`);
      return { shouldSkip: false, existingAudit: existing, huggingFaceRevision };
    }

    // HuggingFace aliases are mutable. Without a pinned revision handed to the scanner,
    // a cached alias match is not strong enough evidence to skip a fresh scan safely.
    logger.debug(`Re-scanning mutable HuggingFace alias: ${modelId}`);
    return { shouldSkip: false, existingAudit: existing, huggingFaceRevision };
  } catch (error) {
    logger.debug(`Failed to check for existing scan: ${error}`);
    return { shouldSkip: false, existingAudit: null };
  }
}

/**
 * Fetch revision info for HuggingFace models.
 */
async function fetchRevisionInfo(
  paths: string[],
  results: ModelAuditScanResults,
  preScanRevision?: HuggingFaceRevisionSnapshot,
): Promise<RevisionInfo> {
  const revisionInfo: RevisionInfo = {};

  if (paths.length !== 1) {
    return revisionInfo;
  }

  const modelPath = paths[0];
  if (isHuggingFaceModel(modelPath)) {
    try {
      const postScanMetadata = await getHuggingFaceMetadata(modelPath);
      const metadata = preScanRevision ?? postScanMetadata;
      if (metadata) {
        revisionInfo.modelId = metadata.modelId;
        revisionInfo.modelSource = 'huggingface';
        revisionInfo.sourceLastModified = new Date(metadata.lastModified).getTime();
        if (preScanRevision && postScanMetadata && preScanRevision.sha !== postScanMetadata.sha) {
          logger.warn(
            `HuggingFace revision changed during scan for ${metadata.modelId}; omitting cached revision SHA`,
          );
        } else {
          revisionInfo.revisionSha = metadata.sha;
        }
      }
    } catch (error) {
      logger.debug(`Failed to fetch revision info: ${error}`);
    }
  }

  // Extract content_hash from modelaudit output if available
  if (results.content_hash) {
    logger.debug(`Using content_hash from modelaudit output: ${results.content_hash}`);
    revisionInfo.contentHash = results.content_hash;
  }

  return revisionInfo;
}

/**
 * Display scan summary to user.
 */
function displayScanSummary(
  results: ModelAuditScanResults,
  auditId: string,
  currentScannerVersion: string | null,
  wasUpdated: boolean,
): void {
  logger.info('\n' + chalk.bold('Model Audit Summary'));
  logger.info('=' + '='.repeat(50));

  const verdict = getModelAuditVerdict(results);
  if (verdict.hasFindings) {
    const issueCount = Math.max(results.failed_checks ?? 0, results.issues?.length ?? 0);
    logger.info(chalk.yellow(`⚠  Found ${issueCount} issues`));
    displayIssuesBySeverity(results.issues);
  } else {
    logger.info(chalk.green(`✓ No issues found. ${results.passed_checks || 0} checks passed.`));
  }

  const mbScanned = ((results.bytes_scanned ?? 0) / 1024 / 1024).toFixed(2);
  const duration = ((results.duration ?? 0) / 1000).toFixed(2);

  logger.info(`\nScanned ${results.files_scanned ?? 0} files (${mbScanned} MB)`);
  logger.info(`Duration: ${duration} seconds`);

  if (currentScannerVersion) {
    logger.debug(`Scanner version: ${currentScannerVersion}`);
  }
  if (wasUpdated) {
    logger.debug(`Updated existing audit record: ${auditId}`);
  }

  logger.info(chalk.green(`\n✓ Results saved to database with ID: ${auditId}`));
}

/**
 * Display issues grouped by severity.
 */
function displayIssuesBySeverity(issues: ModelAuditIssue[] | undefined): void {
  if (!issues || issues.length === 0) {
    return;
  }

  const issuesBySeverity = issues.reduce<Record<string, ModelAuditIssue[]>>((acc, issue) => {
    const severity = issue.severity || 'info';
    if (!acc[severity]) {
      acc[severity] = [];
    }
    acc[severity].push(issue);
    return acc;
  }, {});

  const severityOrder = ['critical', 'error', 'warning', 'info'];
  const severityColors: Record<string, typeof chalk.red> = {
    critical: chalk.red,
    error: chalk.red,
    warning: chalk.yellow,
    info: chalk.blue,
  };

  for (const severity of severityOrder) {
    const severityIssues = issuesBySeverity[severity];
    if (!severityIssues || severityIssues.length === 0) {
      continue;
    }

    const color = severityColors[severity] || chalk.white;
    logger.info(`\n${color.bold(severity.toUpperCase())} (${severityIssues.length}):`);

    const displayCount = Math.min(severityIssues.length, 5);
    for (let i = 0; i < displayCount; i++) {
      const issue = severityIssues[i];
      logger.info(`  • ${issue.message}`);
      if (issue.location) {
        logger.info(`    ${chalk.gray(issue.location)}`);
      }
    }

    if (severityIssues.length > 5) {
      logger.info(`  ${chalk.gray(`... and ${severityIssues.length - 5} more`)}`);
    }
  }
}

/**
 * Save or update audit record in database.
 */
async function saveAuditRecord(
  paths: string[],
  results: ModelAuditScanResults,
  options: ScanOptions,
  currentScannerVersion: string | null,
  existingAudit: ModelAudit | null,
  revisionInfo: RevisionInfo,
): Promise<ModelAudit> {
  const auditMetadata = {
    paths,
    options: {
      blacklist: options.blacklist,
      timeout: options.timeout ? parseInt(options.timeout, 10) : undefined,
      maxSize: options.maxSize,
      verbose: options.verbose,
      sbom: options.sbom,
      strict: options.strict,
      dryRun: options.dryRun,
      cache: options.cache,
      quiet: options.quiet,
      progress: options.progress,
      stream: options.stream,
      scanners: options.scanners,
      excludeScanner: options.excludeScanner,
    },
  };

  const matchedAudit =
    existingAudit ??
    (revisionInfo.modelId
      ? await ModelAudit.findByRevision(
          revisionInfo.modelId,
          revisionInfo.revisionSha,
          revisionInfo.contentHash,
        )
      : null);

  const shouldCreateNewAudit =
    matchedAudit?.contentHash &&
    revisionInfo.contentHash &&
    matchedAudit.contentHash !== revisionInfo.contentHash;

  if (matchedAudit && !shouldCreateNewAudit) {
    // Update existing record with new scan results
    matchedAudit.results = results;
    matchedAudit.checks = results.checks ?? null;
    matchedAudit.issues = results.issues ?? null;
    matchedAudit.hasErrors = hasFindingsInResults(results);
    matchedAudit.totalChecks = results.total_checks ?? null;
    matchedAudit.passedChecks = results.passed_checks ?? null;
    matchedAudit.failedChecks = results.failed_checks ?? null;
    matchedAudit.scannerVersion = currentScannerVersion ?? null;
    matchedAudit.metadata = auditMetadata;
    matchedAudit.updatedAt = Date.now();
    if (revisionInfo.modelId) {
      matchedAudit.modelId = revisionInfo.modelId;
    }
    if (revisionInfo.revisionSha) {
      matchedAudit.revisionSha = revisionInfo.revisionSha;
    }
    if (revisionInfo.contentHash) {
      matchedAudit.contentHash = revisionInfo.contentHash;
    }
    if (revisionInfo.modelSource) {
      matchedAudit.modelSource = revisionInfo.modelSource;
    }
    if (revisionInfo.sourceLastModified) {
      matchedAudit.sourceLastModified = revisionInfo.sourceLastModified;
    }
    await matchedAudit.save();
    return matchedAudit;
  }

  if (shouldCreateNewAudit) {
    logger.debug('Creating new audit because model content changed since the previous scan');
  }

  return ModelAudit.create({
    name: options.name || `Model scan ${new Date().toISOString()}`,
    author: getAuthor() || undefined,
    modelPath: paths.join(', '),
    results,
    metadata: auditMetadata,
    scannerVersion: currentScannerVersion || undefined,
    ...revisionInfo,
  });
}

/**
 * Common logic for processing scan results after JSON is obtained.
 * Parses JSON, saves to database, and displays summary.
 */
async function processJsonResults(
  jsonOutput: string,
  exitCode: number,
  paths: string[],
  options: ScanOptions,
  currentScannerVersion: string | null,
  existingAudit: ModelAudit | null,
  preScanRevision?: HuggingFaceRevisionSnapshot,
): Promise<number> {
  if (!jsonOutput) {
    logger.error('No output received from model scan');
    return 1;
  }

  let results: ModelAuditScanResults;
  try {
    results = parseCompleteModelAuditResults(JSON.parse(jsonOutput));
  } catch (error) {
    logger.error(`Failed to parse scan results: ${error}`);
    if (options.verbose) {
      logger.error(`Raw output: ${jsonOutput}`);
    }
    return 1;
  }

  // Fetch revision info and save to database
  const revisionInfo = await fetchRevisionInfo(paths, results, preScanRevision);
  const audit = await saveAuditRecord(
    paths,
    results,
    options,
    currentScannerVersion,
    existingAudit,
    revisionInfo,
  );

  // Determine if we should share (matches eval command behavior)
  const hasExplicitDisable =
    options.share === false || options.noShare === true || getEnvBool('PROMPTFOO_DISABLE_SHARING');

  let wantsToShare: boolean;
  if (hasExplicitDisable) {
    wantsToShare = false;
  } else if (options.share === true) {
    wantsToShare = true;
  } else {
    // Default: auto-share when cloud is enabled
    wantsToShare = cloudConfig.isEnabled();
  }

  // Check if sharing is actually possible (cloud enabled or custom share URL configured)
  const canShare = isModelAuditSharingEnabled();

  logger.debug(`Model audit sharing decision: wantsToShare=${wantsToShare}, canShare=${canShare}`);

  // Start sharing in background (don't await yet - non-blocking like evals!)
  let sharePromise: Promise<string | null> | null = null;
  if (wantsToShare && canShare) {
    sharePromise = createShareableModelAuditUrl(audit);
  }

  // Display summary immediately (don't wait for upload)
  if (options.format !== 'json') {
    displayScanSummary(results, audit.id, currentScannerVersion, existingAudit !== null);
  }

  // Save to user-specified output file if requested. Persisted scans always emit
  // Promptfoo's normalized JSON payload; use --no-write for raw ModelAudit output.
  if (options.output) {
    try {
      await fs.writeFile(options.output, JSON.stringify(results, null, 2));
      logger.info(`Results also saved to ${options.output}`);
    } catch (error) {
      logger.error(`Failed to save results to ${options.output}: ${error}`);
      return 1;
    }
  }

  // Now wait for share to complete and show spinner (like evals)
  if (sharePromise != null) {
    if (process.stdout.isTTY && !isCI()) {
      const spinner = ora({
        text: 'Sharing model audit...',
        prefixText: chalk.dim('»'),
        spinner: 'dots',
      }).start();

      try {
        const shareableUrl = await sharePromise;
        if (shareableUrl) {
          spinner.succeed(shareableUrl);
        } else {
          spinner.fail(chalk.red('Share failed'));
        }
      } catch (error) {
        spinner.fail(chalk.red('Share failed'));
        logger.debug(`Share error: ${error}`);
      }
    } else {
      // CI mode - direct log
      try {
        const shareableUrl = await sharePromise;
        if (shareableUrl) {
          logger.info(`${chalk.dim('»')} ${chalk.green('✓')} ${shareableUrl}`);
        }
      } catch (error) {
        logger.debug(`Share error: ${error}`);
      }
    }
  }

  return exitCode === 0 && getModelAuditVerdict(results).hasFindings ? 1 : exitCode;
}

/**
 * Process scan results from a JSON file (used when CLI UI is displayed).
 * Reads JSON from temp file, processes results, and cleans up the temp file.
 */
async function processScanResultsFromFile(
  spawnResult: SpawnResult,
  jsonFilePath: string,
  paths: string[],
  options: ScanOptions,
  currentScannerVersion: string | null,
  existingAudit: ModelAudit | null,
  preScanRevision?: HuggingFaceRevisionSnapshot,
): Promise<number> {
  // Helper to clean up temp file
  const cleanupTempFile = async () => {
    try {
      await fs.rm(path.dirname(jsonFilePath), { recursive: true, force: true });
    } catch (error) {
      logger.debug(`Failed to cleanup temp file ${jsonFilePath}: ${error}`);
    }
  };

  // Handle process errors (stderr already displayed via inherited stdio)
  const processErrorExitCode = logProcessError(spawnResult);
  if (processErrorExitCode !== null) {
    await cleanupTempFile();
    return processErrorExitCode;
  }

  // Read JSON from temp file
  let jsonOutput: string;
  try {
    jsonOutput = (await fs.readFile(jsonFilePath, 'utf-8')).trim();
  } catch (error) {
    logger.error(`Failed to read scan results from file: ${error}`);
    await cleanupTempFile();
    return 1;
  }

  // Clean up temp file after successful read
  await cleanupTempFile();

  return processJsonResults(
    jsonOutput,
    spawnResult.code ?? 0,
    paths,
    options,
    currentScannerVersion,
    existingAudit,
    preScanRevision,
  );
}

/**
 * Process scan results from stdout (used for older modelaudit versions).
 * Parses JSON from captured stdout and saves to database.
 */
async function processScanResultsFromStdout(
  spawnResult: SpawnResult,
  paths: string[],
  options: ScanOptions,
  currentScannerVersion: string | null,
  existingAudit: ModelAudit | null,
  preScanRevision?: HuggingFaceRevisionSnapshot,
): Promise<number> {
  // Handle process errors
  const processErrorExitCode = logProcessError(spawnResult);
  if (processErrorExitCode !== null) {
    if (spawnResult.stderr) {
      logger.error(spawnResult.stderr);
    }
    return processErrorExitCode;
  }

  const jsonOutput = spawnResult.stdout.trim();
  if (!jsonOutput && spawnResult.stderr) {
    logger.error('No output received from model scan');
    logger.error(spawnResult.stderr);
    return 1;
  }

  return processJsonResults(
    jsonOutput,
    spawnResult.code ?? 0,
    paths,
    options,
    currentScannerVersion,
    existingAudit,
    preScanRevision,
  );
}

// ============================================================================
// Main Command
// ============================================================================

export function modelScanCommand(program: Command): void {
  program
    .command('scan-model')
    .description('Scan model files for security and quality issues')
    .argument('[paths...]', 'Model files or directories to scan')

    // Core configuration
    .option(
      '-b, --blacklist <patterns...>',
      'Additional blacklist patterns to check against model names',
    )

    // Output configuration
    .option('-o, --output <path>', 'Output file path (prints to stdout if not specified)')
    .option('-f, --format <format>', 'Output format (text, json, sarif)', 'text')
    .option('--sbom <path>', 'Write CycloneDX SBOM to the specified file')
    .option('--no-write', 'Do not write results to database')
    .option('--name <name>', 'Name for the audit (when saving to database)')

    // Execution control
    .option('-t, --timeout <seconds>', 'Scan timeout in seconds', '300')
    .option('--max-size <size>', 'Override auto-detected size limits (e.g., 10GB, 500MB)')

    // Scanning behavior
    .option(
      '--strict',
      'Strict mode: fail on warnings, scan all file types, strict license validation',
    )
    .option('--dry-run', 'Preview what would be scanned/downloaded without actually doing it')
    .option('--no-cache', 'Force disable caching (overrides smart detection)')
    .option('--quiet', 'Silence detection messages')
    .option('--progress', 'Force enable progress reporting (auto-detected by default)')
    .option('--stream', 'Scan and delete downloaded files immediately after scan')
    .option(
      '--scanners <scanner>',
      'Only run selected ModelAudit scanners (IDs/classes; comma-separated or repeated)',
      collectRepeatableOption,
    )
    .option(
      '--exclude-scanner <scanner>',
      'Exclude a ModelAudit scanner from the active set (comma-separated or repeated)',
      collectRepeatableOption,
    )
    .option('--list-scanners', 'List registered ModelAudit scanners and exit')

    // Miscellaneous
    .option('-v, --verbose', 'Enable verbose output')
    .option('--force', 'Force scan even if model was already scanned')

    // Sharing options
    .option('--share', 'Share the model audit results')
    .option('--no-share', 'Do not share the model audit results')

    .action(async (paths: string[], options: ScanOptions) => {
      // Validate input
      if (!options.listScanners && (!paths || paths.length === 0)) {
        logger.error('No paths specified. Provide at least one model file or directory to scan.');
        process.exitCode = 1;
        return;
      }

      // Warn about deprecated options
      warnDeprecatedOptions(options as Record<string, unknown>);

      // Check modelaudit installation
      const { installed, version: currentScannerVersion } = await checkModelAuditInstalled();
      if (!installed) {
        logger.error('ModelAudit is not installed.');
        logger.info(`Please install it using: ${chalk.green('pip install modelaudit')}`);
        logger.info('For more information, visit: https://www.promptfoo.dev/docs/model-audit/');
        process.exitCode = 1;
        return;
      }

      // Check for updates
      await checkModelAuditUpdates();
      if (currentScannerVersion) {
        logger.debug(`Using modelaudit version: ${currentScannerVersion}`);
      }

      const delegationEnv = {
        ...process.env,
        PROMPTFOO_DELEGATED: 'true',
      };

      if (options.listScanners) {
        const parsed = buildCliArgs(paths || [], {
          ...options,
          format: options.format || 'text',
          output: options.output,
          timeout: undefined,
        });
        if (!parsed) {
          return;
        }
        await runPassthroughModelAudit(parsed.args, delegationEnv);
        return;
      }

      // Determine if we should save to database
      const saveToDatabase = options.write === undefined || options.write === true;

      // Check for existing scan (skip or get audit to update)
      let existingAuditToUpdate: ModelAudit | null = null;
      let huggingFaceRevision: HuggingFaceRevisionSnapshot | undefined;
      if (saveToDatabase) {
        const {
          shouldSkip,
          existingAudit,
          huggingFaceRevision: scannedRevision,
        } = await checkExistingScan(paths, options, currentScannerVersion);
        if (shouldSkip) {
          process.exitCode = 0;
          return;
        }
        existingAuditToUpdate = existingAudit;
        huggingFaceRevision = scannedRevision;
      }

      // Parse CLI arguments
      const outputFormat = saveToDatabase ? 'json' : options.format || 'text';
      const parsed = buildCliArgs(paths, {
        ...options,
        format: outputFormat,
        output: options.output && !saveToDatabase ? options.output : undefined,
        timeout: options.timeout ? parseInt(options.timeout, 10) : undefined,
      });
      if (!parsed) {
        return;
      }
      const args = parsed.args;
      if (parsed.unsupportedOptions.length > 0) {
        logger.warn(`Unsupported options detected: ${parsed.unsupportedOptions.join(', ')}`);
      }

      if (saveToDatabase || outputFormat === 'text') {
        logger.info(`Running model scan on: ${paths.join(', ')}`);
      }

      if (!saveToDatabase) {
        await runPassthroughModelAudit(args, delegationEnv, true);
        return;
      }

      try {
        // Check if modelaudit version supports CLI UI with --output flag (v0.2.20+)
        const useCliUiFlow = supportsCliUiWithOutput(currentScannerVersion);

        if (useCliUiFlow) {
          // Use temp file for JSON output so CLI UI can display
          // (modelaudit 0.2.20+ shows CLI UI when --output is used)
          const tempOutputPath = createTempOutputPath();
          args.push('--output', tempOutputPath);

          // Cleanup handler for temp file on abnormal termination.
          // Note: Child process termination is handled by spawnModelAudit's signal
          // handlers - this only handles temp file cleanup.
          //
          // IMPORTANT: We use unlinkSync (synchronous) instead of fs.promises.unlink
          // because signal handlers must complete synchronously. Async operations
          // in signal handlers are unsafe - the process may exit before they complete.
          let cleanedUp = false;
          const cleanupTempFileOnExit = () => {
            if (cleanedUp) {
              return;
            }
            cleanedUp = true;
            try {
              unlinkSync(tempOutputPath);
            } catch {
              // Ignore - file may already be cleaned up or doesn't exist
            }
            try {
              rmSync(path.dirname(tempOutputPath), { recursive: true, force: true });
            } catch {
              // Ignore - directory may already be removed
            }
          };

          // Register cleanup handlers for abnormal termination.
          // We use once() so handlers auto-remove after firing, but we also manually
          // remove them in finally{} for the normal exit path. The cleanedUp flag
          // prevents double-cleanup if a signal fires between our manual cleanup call
          // and removeListener calls. This belt-and-suspenders approach ensures:
          // 1. Normal exit: finally{} cleans up and removes handlers
          // 2. Signal during await: once() handler cleans up, auto-removes itself
          // 3. Signal during finally{}: cleanedUp flag prevents double-cleanup
          process.once('exit', cleanupTempFileOnExit);
          process.once('SIGINT', cleanupTempFileOnExit);
          process.once('SIGTERM', cleanupTempFileOnExit);

          try {
            // Use inherited stdio so CLI UI displays (spinners, progress, colors)
            const spawnResult = await spawnModelAudit(args, {
              captureOutput: false,
              env: delegationEnv,
            });

            // Read JSON from temp file and process results
            process.exitCode = await processScanResultsFromFile(
              spawnResult,
              tempOutputPath,
              paths,
              options,
              currentScannerVersion,
              existingAuditToUpdate,
              huggingFaceRevision,
            );
          } finally {
            // Cleanup first, then remove handlers. Order matters: if we removed
            // handlers first, a signal arriving before cleanup would be missed.
            cleanupTempFileOnExit();
            process.removeListener('exit', cleanupTempFileOnExit);
            process.removeListener('SIGINT', cleanupTempFileOnExit);
            process.removeListener('SIGTERM', cleanupTempFileOnExit);
          }
        } else {
          // Fallback for older modelaudit versions: capture stdout for JSON
          logger.debug('Using stdout capture (modelaudit < 0.2.20)');
          const spawnResult = await spawnModelAudit(args, {
            captureOutput: true,
            env: delegationEnv,
          });

          process.exitCode = await processScanResultsFromStdout(
            spawnResult,
            paths,
            options,
            currentScannerVersion,
            existingAuditToUpdate,
            huggingFaceRevision,
          );
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error(`Failed to start modelaudit: ${message}`);
        logger.info('Make sure modelaudit is installed and available in your PATH.');
        logger.info('Install it using: pip install modelaudit');
        process.exitCode = 1;
      }
    });
}
