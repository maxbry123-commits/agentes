import { randomUUID } from 'crypto';
import path from 'path';

import chalk from 'chalk';
import cliProgress from 'cli-progress';
import { type Command } from 'commander';
import dedent from 'dedent';
import { z } from 'zod';
import { VERSION } from '../../constants';
import { renderPrompt } from '../../evaluatorHelpers';
import { getUserEmail } from '../../globalConfig/accounts';
import logger from '../../logger';
import { HttpProvider } from '../../providers/http';
import { loadApiProvider, loadApiProviders, resolveProviderConfigs } from '../../providers/index';
import telemetry from '../../telemetry';
import { getProviderFromCloud } from '../../util/cloud';
import { readConfig } from '../../util/config/load';
import { fetchWithProxy } from '../../util/fetch/index';
import { pathExists } from '../../util/file';
import invariant from '../../util/invariant';
import {
  getRemoteGenerationHeaders,
  getRemoteGenerationUrl,
  neverGenerateRemote,
} from '../remoteGeneration';
import { remoteGenerationContextPayload } from '../remoteGenerationContext';
import { getCloudTargetIdFromProviders } from '../remoteGenerationContextFromProviders';

import type { ApiProvider, Prompt, UnifiedConfig } from '../../types/index';

// ========================================================
// Schemas
// ========================================================

const TargetPurposeDiscoveryStateSchema = z.object({
  currentQuestionIndex: z.number(),
  answers: z.array(z.any()),
});

export const TargetPurposeDiscoveryRequestSchema = z.object({
  state: TargetPurposeDiscoveryStateSchema,
  task: z.literal('target-purpose-discovery'),
  targetId: z.string().optional(),
  version: z.string(),
  email: z.string().optional().nullable(),
});

const TargetPurposeDiscoveryResultSchema = z.object({
  purpose: z.string().nullable(),
  limitations: z.string().nullable(),
  user: z.string().nullable(),
  tools: z.array(
    z
      .object({
        name: z.string(),
        description: z.string(),
        arguments: z.array(
          z.object({
            name: z.string(),
            description: z.string(),
            type: z.string(),
          }),
        ),
      })
      .nullable(),
  ),
});

export const TargetPurposeDiscoveryTaskResponseSchema = z.object({
  done: z.boolean(),
  question: z.string().optional(),
  purpose: TargetPurposeDiscoveryResultSchema.optional(),
  state: TargetPurposeDiscoveryStateSchema,
  error: z.string().optional(),
});

export const ArgsSchema = z
  .object({
    config: z.string().optional(),
    target: z.string().optional(),
  })
  // Config and target are mutually exclusive:
  .refine((data) => !(data.config && data.target), {
    path: ['config', 'target'],
    message: 'Cannot specify both config and target!',
  });

// ========================================================
// Types
// ========================================================

export type TargetPurposeDiscoveryResult = z.infer<typeof TargetPurposeDiscoveryResultSchema>;

type Args = z.infer<typeof ArgsSchema>;

type DiscoveryProviderConfig = NonNullable<UnifiedConfig['providers']>;

// ========================================================
// Constants
// ========================================================

const DEFAULT_TURN_COUNT = 5;
const MAX_TURN_COUNT = 10;
const LOG_PREFIX = '[Target Discovery Agent]';
const COMMAND = 'discover';

// ========================================================
// Utils
// ========================================================

/**
 * Expands provider file references and derives context from the first provider that discovery uses.
 */
export function resolveDiscoveryProviderContext(
  providers: DiscoveryProviderConfig,
  basePath?: string,
): {
  providers: DiscoveryProviderConfig;
  cloudTargetId?: string;
} {
  const resolvedProviders = resolveProviderConfigs(providers, { basePath });
  const selectedProvider = Array.isArray(resolvedProviders)
    ? resolvedProviders[0]
    : resolvedProviders;

  return {
    providers: resolvedProviders,
    cloudTargetId: getCloudTargetIdFromProviders(selectedProvider),
  };
}

// Helper function to check if a string value should be considered null
const isNullLike = (value: string | null | undefined): boolean => {
  return !value || value === 'null' || value.trim() === '';
};

// Helper function to clean tools array
const cleanTools = (tools: Array<any> | null | undefined): Array<any> => {
  if (!tools || !Array.isArray(tools)) {
    return [];
  }
  return tools.filter((tool) => tool !== null && typeof tool === 'object');
};

/**
 * Normalizes a TargetPurposeDiscoveryResult by converting null-like values to actual null
 * and cleaning up empty or meaningless content.
 */
export function normalizeTargetPurposeDiscoveryResult(
  result: TargetPurposeDiscoveryResult,
): TargetPurposeDiscoveryResult {
  return {
    purpose: isNullLike(result.purpose) ? null : result.purpose,
    limitations: isNullLike(result.limitations) ? null : result.limitations,
    user: isNullLike(result.user) ? null : result.user,
    tools: cleanTools(result.tools),
  };
}

function extractStringField(value: unknown): string | undefined {
  if (typeof value !== 'string') {
    return undefined;
  }
  const trimmed = value.trim();
  return trimmed || undefined;
}

async function getRemoteResponseErrorDetail(response: Response): Promise<string> {
  const rawText = (await response.text()).trim();
  const fallback = rawText || response.statusText || 'Unknown error';
  if (!rawText) {
    return fallback;
  }
  try {
    const parsed = JSON.parse(rawText) as { message?: unknown; error?: unknown } | null;
    const detail = extractStringField(parsed?.message) ?? extractStringField(parsed?.error);
    return detail ?? fallback;
  } catch {
    // Not JSON — fall through to raw text.
    return fallback;
  }
}

const REMOTE_ERROR_HINTS: Record<number, string> = {
  400: 'This usually means your promptfoo client is out of date. Try `npm install -g promptfoo@latest` and rerun.',
  401: 'Check that you are logged in (`promptfoo auth login`) and that your account has access to target discovery.',
  403: 'Check that you are logged in (`promptfoo auth login`) and that your account has access to target discovery.',
  404: 'This usually means your promptfoo client is out of date. Try `npm install -g promptfoo@latest` and rerun.',
  429: 'You are being rate limited. Wait a moment and try again.',
};

function getRemoteErrorHint(status: number): string | undefined {
  if (REMOTE_ERROR_HINTS[status]) {
    return REMOTE_ERROR_HINTS[status];
  }
  if (status >= 500) {
    return 'The remote generation service may be temporarily unavailable. Retry in a few minutes or contact support if the issue persists.';
  }
  return undefined;
}

async function buildRemoteErrorFromResponse(response: Response): Promise<Error> {
  const detail = await getRemoteResponseErrorDetail(response);
  const hint = getRemoteErrorHint(response.status);
  const base = `Remote server returned HTTP ${response.status}: ${detail}`;
  return new Error(hint ? `${base}\n${hint}` : base);
}

/**
 * Queries Cloud for the purpose-discovery logic, sends each logic to the target,
 * and summarizes the results.
 *
 * @param target - The target API provider.
 * @param prompt - The prompt to use for the discovery.
 * @param showProgress - Whether to show the progress bar.
 * @param targetId - Cloud target database ID used to resolve target-owned task context.
 * @returns The discovery result.
 */
export async function doTargetPurposeDiscovery(
  target: ApiProvider,
  prompt?: Prompt,
  showProgress: boolean = true,
  targetId?: string,
): Promise<TargetPurposeDiscoveryResult | undefined> {
  // Generate a unique session id to pass to the target across all turns.
  const sessionId = randomUUID();

  let pbar: cliProgress.SingleBar | undefined;
  if (showProgress) {
    pbar = new cliProgress.SingleBar({
      format: 'Mapping the target {bar} {percentage}% | {value}/{total} turns',
      barCompleteChar: '\u2588',
      barIncompleteChar: '\u2591',
      hideCursor: true,
      gracefulExit: true,
    });

    pbar.start(DEFAULT_TURN_COUNT, 0);
  }

  let done = false;
  let question: string | undefined;
  let discoveryResult: TargetPurposeDiscoveryResult | undefined;
  let state = TargetPurposeDiscoveryStateSchema.parse({
    currentQuestionIndex: 0,
    answers: [],
  });
  let turn = 0;

  try {
    while (!done && turn < MAX_TURN_COUNT) {
      try {
        turn++;

        logger.debug(`${LOG_PREFIX} Discovery loop turn: ${turn}`);

        const response = await fetchWithProxy(getRemoteGenerationUrl(), {
          method: 'POST',
          // Auth is injected centrally at the fetch layer for the configured cloud
          // origin only, so the saved token is never sent to a custom
          // PROMPTFOO_REMOTE_GENERATION_URL.
          headers: getRemoteGenerationHeaders(),
          body: JSON.stringify(
            TargetPurposeDiscoveryRequestSchema.parse({
              state: {
                currentQuestionIndex: state.currentQuestionIndex,
                answers: state.answers,
              },
              task: 'target-purpose-discovery',
              ...remoteGenerationContextPayload(targetId),
              version: VERSION,
              email: getUserEmail(),
            }),
          ),
        });

        if (!response.ok) {
          throw await buildRemoteErrorFromResponse(response);
        }

        const responseData = await response.json();
        const data = TargetPurposeDiscoveryTaskResponseSchema.parse(responseData);

        logger.debug(
          `${LOG_PREFIX} Received response from remote server: ${JSON.stringify(data, null, 2)}`,
        );

        done = data.done;
        question = data.question;
        discoveryResult = data.purpose;
        state = data.state;

        if (data.error) {
          const errorMessage = `Error from remote server: ${data.error}`;
          logger.error(`${LOG_PREFIX} ${errorMessage}`);
          throw new Error(errorMessage);
        }
        // Should another question be asked?
        else if (!done) {
          invariant(question, 'Question should always be defined if `done` is falsy.');

          if (turn >= MAX_TURN_COUNT) {
            const errorMessage = `Too many retries, giving up.`;
            logger.error(`${LOG_PREFIX} ${errorMessage}`);
            throw new Error(errorMessage);
          }

          const renderedPrompt = prompt
            ? await renderPrompt(prompt, { prompt: question }, {}, target)
            : question;

          const targetResponse = await target.callApi(renderedPrompt, {
            prompt: { raw: question, label: 'Target Discovery Question' },
            vars: { sessionId },
            bustCache: true,
          });

          if (targetResponse.error) {
            const errorMessage = `Error from target: ${targetResponse.error}`;
            logger.error(`${LOG_PREFIX} ${errorMessage}`);
            throw new Error(errorMessage);
          }

          logger.debug(
            `${LOG_PREFIX} Received response from target: ${JSON.stringify(targetResponse, null, 2)}`,
          );

          // If the target is an HTTP provider and has no transformResponse defined, and the response is an object,
          // prompt the user to define a transformResponse.
          if (
            target instanceof HttpProvider &&
            target.config.transformResponse === undefined &&
            typeof targetResponse.output === 'object' &&
            targetResponse.output !== null
          ) {
            logger.warn(
              `${LOG_PREFIX} Target response is an object; should a \`transformResponse\` function be defined?`,
            );
          }

          state.answers.push(targetResponse.output);
        }
      } finally {
        pbar?.increment(1);
      }
    }

    return discoveryResult ? normalizeTargetPurposeDiscoveryResult(discoveryResult) : undefined;
  } finally {
    pbar?.stop();
  }
}

// ========================================================
// Command
// ========================================================

/**
 * Registers the `discover` command with the CLI.
 */
export function discoverCommand(
  program: Command,
  defaultConfig: Partial<UnifiedConfig>,
  defaultConfigPath: string | undefined,
) {
  program
    .command(COMMAND)
    .description(
      dedent`
        Run the Target Discovery Agent to automatically discover and report a target application's purpose,
        limitations, and tools, enhancing attack probe efficacy.

        If neither a config file nor a target ID is provided, the current working directory will be checked for a promptfooconfig.yaml file,
        and the first provider in that config will be used.
      `,
    )
    .option('-c, --config <path>', 'Path to `promptfooconfig.yaml` configuration file.')
    .option('-t, --target <id>', 'UUID of a target defined in Promptfoo Cloud to scan.')
    .action(async (rawArgs: Args) => {
      // Check that remote generation is enabled:
      if (neverGenerateRemote()) {
        logger.error(dedent`
          Target discovery relies on remote generation which is disabled.

          To enable remote generation, unset the PROMPTFOO_DISABLE_REDTEAM_REMOTE_GENERATION environment variable.
        `);
        process.exitCode = 1;
        return;
      }

      // Validate the arguments:
      const { success, data: args, error } = ArgsSchema.safeParse(rawArgs);
      if (!success) {
        logger.error('Invalid options:');
        error.issues.forEach((issue) => {
          logger.error(`  ${issue.path.join('.')}: ${issue.message}`);
        });
        process.exitCode = 1;
        return;
      }

      // Record telemetry:
      telemetry.record('redteam discover', {});

      let config: UnifiedConfig | null = null;
      // Although the providers/targets property supports multiple values, Redteaming only supports
      // a single target at a time.
      let target: ApiProvider | undefined = undefined;
      let cloudTargetId: string | undefined;
      // Fallback to the default config path:

      // If user provides a config, read the target from it:
      if (args.config) {
        // Validate that the config is a valid path:
        let configExists: boolean;
        try {
          configExists = await pathExists(args.config);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          throw new Error(`Unable to access config at ${args.config}: ${message}`);
        }
        if (!configExists) {
          throw new Error(`Config not found at ${args.config}`);
        }

        config = await readConfig(args.config);

        if (!config) {
          throw new Error(`Config is invalid at ${args.config}`);
        }

        if (!config.providers) {
          throw new Error('Config must contain a target');
        }

        const basePath = path.dirname(path.resolve(args.config));
        const resolved = resolveDiscoveryProviderContext(config.providers, basePath);
        const providers = await loadApiProviders(resolved.providers, { basePath });

        target = providers[0];
        cloudTargetId = resolved.cloudTargetId;
      }
      // If the target flag is provided, load it from Cloud:
      else if (args.target) {
        // Let the internal error handling bubble up:
        const providerOptions = await getProviderFromCloud(args.target);
        target = await loadApiProvider(providerOptions.id, { options: providerOptions });
        cloudTargetId = args.target;
      }
      // Check the current working directory for a promptfooconfig.yaml file:
      else if (defaultConfig) {
        if (!defaultConfig.providers) {
          throw new Error('Config must contain a target or provider');
        }

        const basePath = defaultConfigPath
          ? path.dirname(path.resolve(defaultConfigPath))
          : undefined;
        const resolved = resolveDiscoveryProviderContext(defaultConfig.providers, basePath);
        const providers = await loadApiProviders(resolved.providers, { basePath });
        target = providers[0];
        cloudTargetId = resolved.cloudTargetId;

        // Alert the user that we're using a config from the current working directory:
        logger.info(`Using config from ${chalk.italic(defaultConfigPath)}`);
      } else {
        logger.error(
          'No config found, please specify a config file with the --config flag, a target with the --target flag, or run this command from a directory with a promptfooconfig.yaml file.',
        );
        process.exitCode = 1;
        return;
      }

      try {
        const discoveryResult = await doTargetPurposeDiscovery(
          target,
          undefined,
          true,
          cloudTargetId,
        );

        if (discoveryResult) {
          if (discoveryResult.purpose) {
            logger.info(chalk.bold(chalk.green('\n1. The target believes its purpose is:\n')));
            logger.info(discoveryResult.purpose);
          }
          if (discoveryResult.limitations) {
            logger.info(
              chalk.bold(chalk.green('\n2. The target believes its limitations to be:\n')),
            );
            logger.info(discoveryResult.limitations);
          }
          if (discoveryResult.tools && discoveryResult.tools.length > 0) {
            logger.info(
              chalk.bold(chalk.green('\n3. The target divulged access to these tools:\n')),
            );
            logger.info(JSON.stringify(discoveryResult.tools, null, 2));
          }
          if (discoveryResult.user) {
            logger.info(
              chalk.bold(chalk.green('\n4. The target believes the user of the application is:\n')),
            );
            logger.info(discoveryResult.user);
          }

          // If no meaningful information was discovered, inform the user
          if (
            !discoveryResult.purpose &&
            !discoveryResult.limitations &&
            (!discoveryResult.tools || discoveryResult.tools.length === 0) &&
            !discoveryResult.user
          ) {
            logger.info(
              chalk.yellow('\nNo meaningful information was discovered about the target.'),
            );
          }
        }
      } catch (error) {
        logger.error(
          `An unexpected error occurred during target scan: ${error instanceof Error ? error.message : String(error)}\n${
            error instanceof Error ? error.stack : ''
          }`,
        );
        process.exitCode = 1;
        return;
      }
    });
}
