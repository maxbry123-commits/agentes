import { type ChildProcessWithoutNullStreams, spawn } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import readline from 'readline';

import { type Attributes, type Span, SpanKind, SpanStatusCode, trace } from '@opentelemetry/api';
import dedent from 'dedent';
import { z } from 'zod';
import cliState from '../../cliState';
import { getEnvString } from '../../envars';
import logger from '../../logger';
import {
  addActiveSpanRoleAttribute,
  closeTurnSpan,
  GenAIAttributes,
  type GenAISpanContext,
  type GenAISpanResult,
  getTraceparent,
  openTurnSpan,
  withGenAISpan,
} from '../../tracing/genaiTracer';
import { renderVarsInObject } from '../../util/render';
import { normalizeFieldName, REDACTED, sanitizeObject } from '../../util/sanitizer';
import { VERSION } from '../../version';
import { resolveAgenticWorkingDir } from '../agentic-utils';
import { providerRegistry } from '../providerRegistry';
import { calculateOpenAIUsageCostFromTokenUsage } from './billing';
import {
  getCodexTraceEndpoint,
  getCodexTraceProtocol,
  getCodexTraceShutdownGraceMs,
  withCodexTraceExporter,
} from './codex-tracing';
import { applyApiKeyToCliEnv, shouldInjectApiKey } from './codexApiKeyGating';
import {
  buildCodexSkillMetadata,
  getCodexSkillMetadataFields,
  getCodexSkillRootPrefixes,
} from './codexSkillMetadata';
import type { Usage as CodexSdkUsage } from '@openai/codex-sdk';

import type { EnvOverrides } from '../../types/env';
import type {
  ApiProvider,
  CallApiContextParams,
  CallApiOptionsParams,
  ProviderResponse,
} from '../../types/index';

export type CodexAppServerSandboxMode = 'read-only' | 'workspace-write' | 'danger-full-access';
export interface CodexAppServerGranularApprovalPolicy {
  granular: {
    sandbox_approval: boolean;
    rules: boolean;
    skill_approval: boolean;
    request_permissions: boolean;
    mcp_elicitations: boolean;
  };
}
export type CodexAppServerApprovalPolicy =
  | 'never'
  | 'on-request'
  | 'on-failure'
  | 'untrusted'
  | CodexAppServerGranularApprovalPolicy;
export type CodexAppServerReasoningEffort =
  | 'none'
  | 'minimal'
  | 'low'
  | 'medium'
  | 'high'
  | 'xhigh'
  | 'max'
  | 'ultra';
export type CodexAppServerReasoningSummary = 'auto' | 'concise' | 'detailed' | 'none';
export type CodexAppServerServiceTier = 'fast' | 'flex';
export type CodexAppServerPersonality = 'none' | 'friendly' | 'pragmatic';

function redactAppServerText(value: string): string {
  return value
    .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, REDACTED)
    .replace(
      /\b(?:sk-(?:proj-)?[A-Za-z0-9_-]{20,}|sk-ant-[A-Za-z0-9_-]{20,}|AKIA[A-Z0-9]{16}|AIza[A-Za-z0-9_-]{35}|Bearer\s+[A-Za-z0-9._~+/-]{20,}|Basic\s+[A-Za-z0-9+/=]{20,})\b/g,
      REDACTED,
    )
    .replace(
      /(\\["'](?:authorization|auth)\\["']\s*[:=]\s*\\["'])(?:bearer|basic)\s+[^\\\s"'`]+(\\["'])/gi,
      (_match, prefix, suffix) => `${prefix}${REDACTED}${suffix}`,
    )
    .replace(
      /\b(authorization|auth)(["']?)\s*([=:])(\s*)(["']?)(?:bearer|basic)\s+[^\s"'`]+(\5)/gi,
      (_match, key, keyQuote, separator, spacing, quote) =>
        `${key}${keyQuote}${separator}${spacing}${quote}${REDACTED}${quote}`,
    )
    .replace(
      /\b(api[_-]?key|token|password|secret|authorization|auth)(["']?)\s*([=:])(\s*)(["']?)[^\s"'`]+(\5)/gi,
      (_match, key, keyQuote, separator, spacing, quote) =>
        `${key}${keyQuote}${separator}${spacing}${quote}${REDACTED}${quote}`,
    );
}

export interface CodexAppServerCollaborationMode {
  mode: 'plan' | 'default';
  settings: {
    model: string;
    reasoning_effort: CodexAppServerReasoningEffort | null;
    developer_instructions: string | null;
  };
}

type CodexAppServerCommandExecutionApprovalDecision =
  | 'accept'
  | 'acceptForSession'
  | 'decline'
  | 'cancel'
  | {
      acceptWithExecpolicyAmendment: {
        execpolicy_amendment: string[];
      };
    }
  | {
      applyNetworkPolicyAmendment: {
        network_policy_amendment: {
          host: string;
          action: 'allow' | 'deny';
        };
      };
    };
type CodexAppServerFileChangeApprovalDecision =
  | 'accept'
  | 'acceptForSession'
  | 'decline'
  | 'cancel';
type CodexAppServerMcpElicitationPolicy =
  | 'accept'
  | 'decline'
  | 'cancel'
  | {
      action: 'accept' | 'decline' | 'cancel';
      content?: unknown;
      _meta?: unknown;
    };

type JsonRpcId = string | number;

const MAX_BUFFERED_JSON_RPC_CHARS = 5_000_000;
const MAX_BUFFERED_TURN_EVENT_CHARS = 10_000_000;

type CodexAppServerPromptInputItem =
  | {
      type: 'text';
      text: string;
    }
  | {
      type: 'image';
      url: string;
    }
  | {
      type: 'local_image' | 'localImage';
      path: string;
    }
  | {
      type: 'skill';
      name: string;
      path: string;
    }
  | {
      type: 'mention';
      name: string;
      path: string;
    };

type CodexAppServerUserInput =
  | {
      type: 'text';
      text: string;
      text_elements: [];
    }
  | {
      type: 'image';
      url: string;
    }
  | {
      type: 'localImage';
      path: string;
    }
  | {
      type: 'skill';
      name: string;
      path: string;
    }
  | {
      type: 'mention';
      name: string;
      path: string;
    };

type CodexAppServerThreadCleanup = 'unsubscribe' | 'archive' | 'none';
type CodexAppServerUserInputPolicy = 'empty' | 'first-option' | Record<string, string | string[]>;

export interface CodexAppServerDynamicToolResponse {
  success?: boolean;
  text?: string;
  contentItems?: Array<
    { type: 'inputText'; text: string } | { type: 'inputImage'; imageUrl: string }
  >;
}

export interface CodexAppServerRequestPolicy {
  command_execution?: CodexAppServerCommandExecutionApprovalDecision;
  file_change?: CodexAppServerFileChangeApprovalDecision;
  permissions?: {
    permissions?: Record<string, unknown>;
    scope?: 'turn' | 'session';
    strict_auto_review?: boolean | null;
  };
  user_input?: CodexAppServerUserInputPolicy;
  mcp_elicitation?: CodexAppServerMcpElicitationPolicy;
  dynamic_tools?: Record<string, CodexAppServerDynamicToolResponse>;
}

export interface CodexAppServerConfig {
  basePath?: string;
  prefix?: string;
  suffix?: string;
  provider?: unknown;
  linkedTargetId?: string;

  apiKey?: string;
  base_url?: string;
  working_dir?: string;
  additional_directories?: string[];
  skip_git_repo_check?: boolean;
  codex_path_override?: string;

  model?: string;
  model_provider?: string;
  service_tier?: CodexAppServerServiceTier;
  sandbox_mode?: CodexAppServerSandboxMode;
  sandbox_policy?: Record<string, unknown>;
  network_access_enabled?: boolean;
  approval_policy?: CodexAppServerApprovalPolicy;
  approvals_reviewer?: 'user' | 'auto_review' | 'guardian_subagent';
  model_reasoning_effort?: CodexAppServerReasoningEffort;
  reasoning_summary?: CodexAppServerReasoningSummary;
  personality?: CodexAppServerPersonality;
  base_instructions?: string;
  developer_instructions?: string;
  collaboration_mode?: CodexAppServerCollaborationMode;
  output_schema?: Record<string, unknown>;

  thread_id?: string;
  persist_threads?: boolean;
  thread_pool_size?: number;
  thread_cleanup?: CodexAppServerThreadCleanup;
  ephemeral?: boolean;
  persist_extended_history?: boolean;
  experimental_raw_events?: boolean;
  experimental_api?: boolean;
  include_raw_events?: boolean;

  cli_config?: Record<string, unknown>;
  cli_env?: Record<string, string | number | boolean>;
  inherit_process_env?: boolean;
  reuse_server?: boolean;
  deep_tracing?: boolean;
  request_timeout_ms?: number;
  startup_timeout_ms?: number;
  turn_timeout_ms?: number;
  server_request_policy?: CodexAppServerRequestPolicy;
}

interface JsonRpcMessage {
  id?: JsonRpcId;
  method?: string;
  params?: any;
  result?: any;
  error?: {
    code?: number;
    message?: string;
    data?: unknown;
  };
}

interface PendingRequest {
  method: string;
  resolve: (value: unknown) => void;
  reject: (error: Error) => void;
  timeout?: NodeJS.Timeout;
  abortListener?: () => void;
  abortSignal?: AbortSignal;
  onResponse?: (result: unknown) => void;
}

interface AppServerConnectionOptions {
  connectionInstanceId: string;
  command: string;
  args: string[];
  env: Record<string, string>;
  requestTimeoutMs: number;
  startupTimeoutMs: number;
  onNotification: (message: JsonRpcMessage) => void;
  onServerRequest: (message: JsonRpcMessage) => Promise<unknown>;
  onClose: (error: Error) => void;
}

interface CodexTraceExporterSettings {
  endpoint: string;
  protocol?: string;
  endpointConfigKey: string;
  protocolConfigKey: string;
}

interface Deferred<T> {
  promise: Promise<T>;
  resolve: (value: T | PromiseLike<T>) => void;
  reject: (reason?: unknown) => void;
}

interface ServerRequestRecord {
  id: JsonRpcId;
  method: string;
  params: unknown;
  response?: unknown;
  error?: string;
}

interface CodexAppServerTurnState {
  connection: CodexAppServerConnection;
  connectionKey: string;
  connectionInstanceId: string;
  threadId: string;
  turnId?: string;
  config: CodexAppServerConfig;
  appServerEnv: Record<string, string>;
  promptInput: CodexAppServerUserInput[];
  items: any[];
  itemStarts: any[];
  notifications: JsonRpcMessage[];
  notificationCount: number;
  bufferedEventChars: number;
  serverRequests: ServerRequestRecord[];
  agentMessageDeltas: string[];
  agentMessageDeltasByItemId: Map<string, string>;
  commandExecutionOutputDeltasByItemId: Map<string, string>;
  tokenUsage?: ProviderResponse['tokenUsage'];
  rawTokenUsage?: unknown;
  turn?: any;
  error?: string;
  completed: Deferred<void>;
  activeSpans: Map<string, Span>;
  itemStartTimes: Map<string, number>;
  lastEventTime: number;
  /**
   * Count of `turn/started` notifications received. Each represents an
   * app-server protocol turn; it does not expose model-internal rounds hidden
   * inside that turn. We emit a `gen_ai.turn N` marker span between
   * `turn/started` and `turn/completed` for correlation and usage visibility.
   */
  turnCount: number;
  /** Active `gen_ai.turn` span, opened on `turn/started`. */
  activeTurnSpan?: Span;
  /** 1-based index of the currently open turn, stamped on item spans. */
  activeTurnIndex: number;
}

interface ThreadHandle {
  connectionKey: string;
  threadId: string;
  response: any;
  cacheKey?: string;
  persistent: boolean;
}

const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;
const DEFAULT_STARTUP_TIMEOUT_MS = 30_000;

const MINIMAL_CLI_ENV_KEYS = [
  'PATH',
  'Path',
  'HOME',
  'USER',
  'USERNAME',
  'USERPROFILE',
  'TMPDIR',
  'TMP',
  'TEMP',
  'SHELL',
  'COMSPEC',
  'SystemRoot',
  'PATHEXT',
  'LANG',
  'LC_ALL',
  'TERM',
] as const;

const COMMON_OPTIONAL_PROCESS_ENV_KEYS = [
  'CODEX_HOME',
  'HTTP_PROXY',
  'HTTPS_PROXY',
  'ALL_PROXY',
  'NO_PROXY',
  'SSL_CERT_FILE',
  'SSL_CERT_DIR',
  'REQUESTS_CA_BUNDLE',
  'NODE_EXTRA_CA_CERTS',
  'SSH_AUTH_SOCK',
  'GIT_SSH_COMMAND',
] as const;

const CodexCliEnvValueSchema = z.union([z.string(), z.number(), z.boolean()]).transform(String);

const CodexAppServerReasoningEffortSchema = z.enum([
  'none',
  'minimal',
  'low',
  'medium',
  'high',
  'xhigh',
  'max',
  'ultra',
]);

const CodexAppServerGranularApprovalPolicySchema = z
  .object({
    granular: z
      .object({
        sandbox_approval: z.boolean(),
        rules: z.boolean(),
        skill_approval: z.boolean(),
        request_permissions: z.boolean(),
        mcp_elicitations: z.boolean(),
      })
      .strict(),
  })
  .strict();

const CodexAppServerApprovalPolicySchema = z.union([
  z.enum(['never', 'on-request', 'on-failure', 'untrusted']),
  CodexAppServerGranularApprovalPolicySchema,
]);

const CommandExecutionApprovalDecisionSchema = z.union([
  z.enum(['accept', 'acceptForSession', 'decline', 'cancel']),
  z
    .object({
      acceptWithExecpolicyAmendment: z
        .object({
          execpolicy_amendment: z.array(z.string()),
        })
        .strict(),
    })
    .strict(),
  z
    .object({
      applyNetworkPolicyAmendment: z
        .object({
          network_policy_amendment: z
            .object({
              host: z.string().min(1),
              action: z.enum(['allow', 'deny']),
            })
            .strict(),
        })
        .strict(),
    })
    .strict(),
]);

const McpElicitationPolicySchema = z.union([
  z.enum(['accept', 'decline', 'cancel']),
  z
    .object({
      action: z.enum(['accept', 'decline', 'cancel']),
      content: z.unknown().optional(),
      _meta: z.unknown().optional(),
    })
    .strict(),
]);

const CollaborationModeSchema = z
  .object({
    mode: z.enum(['plan', 'default']),
    settings: z
      .object({
        model: z.string().min(1),
        reasoning_effort: CodexAppServerReasoningEffortSchema.nullable(),
        developer_instructions: z.string().nullable(),
      })
      .strict(),
  })
  .strict();

const ServerRequestPolicySchema = z
  .object({
    command_execution: CommandExecutionApprovalDecisionSchema.optional(),
    file_change: z.enum(['accept', 'acceptForSession', 'decline', 'cancel']).optional(),
    permissions: z
      .object({
        permissions: z.record(z.string(), z.unknown()).optional(),
        scope: z.enum(['turn', 'session']).optional(),
        strict_auto_review: z.boolean().nullable().optional(),
      })
      .optional(),
    user_input: z
      .union([
        z.enum(['empty', 'first-option']),
        z.record(z.string(), z.union([z.string(), z.array(z.string())])),
      ])
      .optional(),
    mcp_elicitation: McpElicitationPolicySchema.optional(),
    dynamic_tools: z
      .record(
        z.string(),
        z.object({
          success: z.boolean().optional(),
          text: z.string().optional(),
          contentItems: z
            .array(
              z.union([
                z.object({ type: z.literal('inputText'), text: z.string() }),
                z.object({ type: z.literal('inputImage'), imageUrl: z.string() }),
              ]),
            )
            .optional(),
        }),
      )
      .optional(),
  })
  .strict();

const CodexAppServerConfigShape = {
  basePath: z.string().optional(),
  prefix: z.string().optional(),
  suffix: z.string().optional(),
  provider: z.unknown().optional(),
  linkedTargetId: z.string().optional(),
  apiKey: z.string().min(1).optional(),
  base_url: z.string().min(1).optional(),
  working_dir: z.string().min(1).optional(),
  additional_directories: z.array(z.string().min(1)).optional(),
  skip_git_repo_check: z.boolean().optional(),
  codex_path_override: z.string().min(1).optional(),
  model: z.string().min(1).optional(),
  model_provider: z.string().min(1).optional(),
  service_tier: z.enum(['fast', 'flex']).optional(),
  sandbox_mode: z.enum(['read-only', 'workspace-write', 'danger-full-access']).optional(),
  sandbox_policy: z.record(z.string(), z.unknown()).optional(),
  network_access_enabled: z.boolean().optional(),
  approval_policy: CodexAppServerApprovalPolicySchema.optional(),
  approvals_reviewer: z.enum(['user', 'auto_review', 'guardian_subagent']).optional(),
  model_reasoning_effort: CodexAppServerReasoningEffortSchema.optional(),
  reasoning_summary: z.enum(['auto', 'concise', 'detailed', 'none']).optional(),
  personality: z.enum(['none', 'friendly', 'pragmatic']).optional(),
  base_instructions: z.string().min(1).optional(),
  developer_instructions: z.string().min(1).optional(),
  collaboration_mode: CollaborationModeSchema.optional(),
  output_schema: z.record(z.string(), z.unknown()).optional(),
  thread_id: z.string().min(1).optional(),
  persist_threads: z.boolean().optional(),
  thread_pool_size: z.number().int().positive().optional(),
  thread_cleanup: z.enum(['unsubscribe', 'archive', 'none']).optional(),
  ephemeral: z.boolean().optional(),
  persist_extended_history: z.boolean().optional(),
  experimental_raw_events: z.boolean().optional(),
  experimental_api: z.boolean().optional(),
  include_raw_events: z.boolean().optional(),
  cli_config: z.record(z.string(), z.unknown()).optional(),
  cli_env: z.record(z.string(), CodexCliEnvValueSchema).optional(),
  inherit_process_env: z.boolean().optional(),
  reuse_server: z.boolean().optional(),
  deep_tracing: z.boolean().optional(),
  request_timeout_ms: z.number().int().positive().optional(),
  startup_timeout_ms: z.number().int().positive().optional(),
  turn_timeout_ms: z.number().int().positive().optional(),
  server_request_policy: ServerRequestPolicySchema.optional(),
} as const;

export const CodexAppServerConfigSchema = z.object(CodexAppServerConfigShape).strict();
const CodexAppServerMergedPromptConfigSchema = z.object(CodexAppServerConfigShape).strip();

function createDeferred<T>(): Deferred<T> {
  let resolve!: (value: T | PromiseLike<T>) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((promiseResolve, promiseReject) => {
    resolve = promiseResolve;
    reject = promiseReject;
  });
  return { promise, resolve, reject };
}

function parseCodexAppServerConfig(
  config: CodexAppServerConfig | undefined,
  options: { stripUnknownKeys?: boolean } = {},
): CodexAppServerConfig {
  const schema = options.stripUnknownKeys
    ? CodexAppServerMergedPromptConfigSchema
    : CodexAppServerConfigSchema;

  try {
    return schema.parse(config ?? {});
  } catch (error) {
    if (error instanceof z.ZodError) {
      const issues = error.issues
        .map((issue) => {
          const pathLabel = issue.path.length > 0 ? issue.path.join('.') : '(root)';
          return `${pathLabel}: ${issue.message}`;
        })
        .join('; ');
      throw new Error(`Invalid OpenAI Codex app-server config: ${issues}`);
    }

    throw error;
  }
}

function mergeOptionalRecord<T extends Record<string, unknown>>(
  base: T | undefined,
  override: T | undefined,
): T | undefined {
  if (!base && !override) {
    return undefined;
  }
  return {
    ...(base ?? {}),
    ...(override ?? {}),
  } as T;
}

function mergeServerRequestPolicy(
  base: CodexAppServerRequestPolicy | undefined,
  override: CodexAppServerRequestPolicy | undefined,
): CodexAppServerRequestPolicy | undefined {
  if (!base && !override) {
    return undefined;
  }

  const merged: CodexAppServerRequestPolicy = {
    ...(base ?? {}),
    ...(override ?? {}),
  };
  const permissions = mergeOptionalRecord(base?.permissions, override?.permissions);
  const dynamicTools = mergeOptionalRecord(base?.dynamic_tools, override?.dynamic_tools);

  if (permissions) {
    merged.permissions = permissions;
  } else {
    delete merged.permissions;
  }
  if (dynamicTools) {
    merged.dynamic_tools = dynamicTools;
  } else {
    delete merged.dynamic_tools;
  }

  return merged;
}

function mergeCodexAppServerConfig(
  base: CodexAppServerConfig,
  override: CodexAppServerConfig | undefined,
): CodexAppServerConfig {
  if (!override) {
    return { ...base };
  }

  return {
    ...base,
    ...override,
    cli_config: mergeOptionalRecord(base.cli_config, override.cli_config),
    cli_env: mergeOptionalRecord(base.cli_env, override.cli_env),
    server_request_policy: mergeServerRequestPolicy(
      base.server_request_policy,
      override.server_request_policy,
    ),
  };
}

function getMinimalProcessEnv(): Record<string, string> {
  const env: Record<string, string> = {};
  for (const key of MINIMAL_CLI_ENV_KEYS) {
    const value = process.env[key];
    if (typeof value === 'string' && value.length > 0) {
      env[key] = value;
    }
  }
  return env;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function flattenConfig(
  value: Record<string, unknown>,
  prefix = '',
): Array<{ key: string; value: unknown }> {
  const entries: Array<{ key: string; value: unknown }> = [];

  for (const [key, entryValue] of Object.entries(value)) {
    const nextKey = prefix ? `${prefix}.${key}` : key;
    if (isPlainObject(entryValue)) {
      entries.push(...flattenConfig(entryValue, nextKey));
    } else if (entryValue !== undefined) {
      entries.push({ key: nextKey, value: entryValue });
    }
  }

  return entries;
}

function getCodexTraceExporterSettings(config: unknown): CodexTraceExporterSettings | undefined {
  if (!isPlainObject(config)) {
    return undefined;
  }

  const entries = new Map(flattenConfig(config).map(({ key, value }) => [key, value]));
  for (const exporter of ['otlp-http', 'otlp-grpc']) {
    const prefix = `otel.trace_exporter.${exporter}`;
    const endpoint = entries.get(`${prefix}.endpoint`);
    if (typeof endpoint !== 'string' || endpoint.length === 0) {
      continue;
    }

    const protocol = entries.get(`${prefix}.protocol`);
    return {
      endpoint,
      ...(typeof protocol === 'string' && { protocol }),
      endpointConfigKey: `${prefix}.endpoint`,
      protocolConfigKey: `${prefix}.protocol`,
    };
  }

  return undefined;
}

function getCodexTraceExporterValue(config: unknown): unknown {
  if (!isPlainObject(config)) {
    return undefined;
  }
  if ('otel.trace_exporter' in config) {
    return config['otel.trace_exporter'];
  }

  const otel = config.otel;
  return isPlainObject(otel) ? otel.trace_exporter : undefined;
}

function getCodexConfigOriginType(origins: unknown, key: string): string | undefined {
  if (!isPlainObject(origins)) {
    return undefined;
  }

  const origin = origins[key];
  if (!isPlainObject(origin)) {
    return undefined;
  }

  const name = origin.name;
  if (typeof name === 'string') {
    return name;
  }
  if (isPlainObject(name) && typeof name.type === 'string') {
    return name.type;
  }

  return typeof origin.source === 'string' ? origin.source : undefined;
}

function getSafeTraceExporterOrigin(endpoint: string): string {
  try {
    return new URL(endpoint).origin;
  } catch {
    return '[invalid exporter endpoint]';
  }
}

function toTomlLiteral(value: unknown): string {
  if (typeof value === 'string') {
    return JSON.stringify(value);
  }
  if (typeof value === 'number' || typeof value === 'boolean') {
    return String(value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => toTomlLiteral(item)).join(', ')}]`;
  }
  if (value === null) {
    return '""';
  }
  return JSON.stringify(value);
}

function getJsonRpcErrorMessage(message: JsonRpcMessage): string {
  if (typeof message.error?.message === 'string' && message.error.message) {
    return message.error.message;
  }
  return 'Unknown app-server error';
}

class JsonRpcError extends Error {
  readonly code?: number;

  constructor(message: string, code?: number) {
    super(message);
    this.name = 'JsonRpcError';
    this.code = code;
  }
}

class StaleExplicitThreadConnectionClosedError extends Error {
  constructor() {
    super('stale explicit-thread cleanup closed the current app-server connection');
    this.name = 'StaleExplicitThreadConnectionClosedError';
  }
}

function isMethodNotFoundError(error: unknown): boolean {
  return error instanceof JsonRpcError && error.code === -32601;
}

function createAbortError(message: string): Error {
  const error = new Error(message);
  error.name = 'AbortError';
  return error;
}

class CodexAppServerConnection {
  readonly instanceId: string;

  private process: ChildProcessWithoutNullStreams;
  private lineInterface: readline.Interface;
  private nextRequestId = 1;
  private pending = new Map<JsonRpcId, PendingRequest>();
  private closed = false;
  private stderrChunks: string[] = [];
  private stderrTotalLength = 0;
  private bufferedJsonRpcLines: string[] = [];
  private closePromise: Promise<void> | null = null;

  constructor(private readonly options: AppServerConnectionOptions) {
    this.instanceId = options.connectionInstanceId;
    this.process = spawn(options.command, options.args, {
      env: options.env,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    this.lineInterface = readline.createInterface({ input: this.process.stdout });
    this.lineInterface.on('line', (line) => this.handleLine(line));
    this.process.stderr.on('data', (chunk: Buffer) => this.recordStderr(chunk));
    this.process.stdin.on('error', (error) => {
      logger.debug('[CodexAppServer] stdin error', { error: error.message });
    });
    this.process.on('error', (error) => this.handleProcessFailure(error));
    this.process.on('exit', (code, signal) => {
      if (this.closed) {
        this.rejectPending(new Error('codex app-server process closed'));
      } else {
        this.handleProcessFailure(
          new Error(
            `codex app-server exited with code ${code ?? 'null'} signal ${signal ?? 'null'}`,
          ),
        );
      }
    });
  }

  isClosed(): boolean {
    return this.closed;
  }

  async initialize(config: CodexAppServerConfig): Promise<void> {
    await this.request(
      'initialize',
      {
        clientInfo: {
          name: 'promptfoo_codex_app_server',
          title: 'Promptfoo Codex App Server Provider',
          version: VERSION,
        },
        capabilities: {
          experimentalApi: config.experimental_api ?? true,
        },
      },
      { timeoutMs: this.options.startupTimeoutMs },
    );
    this.notify('initialized', {});
  }

  request(
    method: string,
    params?: unknown,
    options: {
      timeoutMs?: number;
      abortSignal?: AbortSignal;
      onResponse?: (result: unknown) => void;
    } = {},
  ): Promise<any> {
    if (this.closed) {
      return Promise.reject(new Error('codex app-server connection is closed'));
    }
    if (options.abortSignal?.aborted) {
      return Promise.reject(createAbortError(`codex app-server request aborted: ${method}`));
    }

    const id = this.nextRequestId++;
    const message: JsonRpcMessage = { method, id };
    if (params !== undefined) {
      message.params = params;
    }

    const timeoutMs = options.timeoutMs ?? this.options.requestTimeoutMs;
    return new Promise((resolve, reject) => {
      const pendingRequest: PendingRequest = {
        method,
        resolve,
        reject,
        abortSignal: options.abortSignal,
        onResponse: options.onResponse,
      };

      pendingRequest.timeout = setTimeout(() => {
        const error = new Error(`codex app-server request timed out: ${method}`);
        this.pending.delete(id);
        if (options.abortSignal && pendingRequest.abortListener) {
          options.abortSignal.removeEventListener('abort', pendingRequest.abortListener);
        }
        reject(error);
        this.closeAfterRequestTimeout(method, error);
      }, timeoutMs);

      if (options.abortSignal) {
        pendingRequest.abortListener = () => {
          const error = createAbortError(`codex app-server request aborted: ${method}`);
          this.pending.delete(id);
          if (pendingRequest.timeout) {
            clearTimeout(pendingRequest.timeout);
          }
          reject(error);
          logger.debug('[CodexAppServer] JSON-RPC request aborted', {
            error: error.message,
            method,
          });
        };
        options.abortSignal.addEventListener('abort', pendingRequest.abortListener, { once: true });
      }

      this.pending.set(id, pendingRequest);
      this.send(message);
    });
  }

  notify(method: string, params?: unknown): void {
    const message: JsonRpcMessage = { method };
    if (params !== undefined) {
      message.params = params;
    }
    this.send(message);
  }

  getStderr(): string {
    return this.stderrChunks.join('').slice(-10_000);
  }

  async close(options: { graceful?: boolean } = {}): Promise<void> {
    if (this.closePromise !== null) {
      return this.closePromise;
    }

    this.closePromise = new Promise<void>((resolve) => {
      this.closed = true;
      this.rejectPending(new Error('codex app-server connection closed'));

      let terminateTimer: ReturnType<typeof setTimeout> | undefined;
      let killTimer: ReturnType<typeof setTimeout> | undefined;
      const finish = () => {
        if (terminateTimer) {
          clearTimeout(terminateTimer);
        }
        if (killTimer) {
          clearTimeout(killTimer);
        }
        this.lineInterface.close();
        resolve();
      };
      const terminate = () => {
        killTimer = setTimeout(() => {
          try {
            if (this.process.exitCode === null) {
              this.process.kill('SIGKILL');
            }
          } catch {
            // Process may have already exited (ESRCH).
          }
          finish();
        }, 1_000);
        try {
          this.process.kill('SIGTERM');
        } catch {
          // Process may have already exited (ESRCH).
          finish();
        }
      };

      this.process.once('exit', finish);

      if (this.process.killed || this.process.exitCode !== null) {
        finish();
        return;
      }

      try {
        this.process.stdin.end();
        if (options.graceful) {
          // Stdio EOF makes Codex shut down normally and force-flush its batch span processor.
          terminateTimer = setTimeout(terminate, getCodexTraceShutdownGraceMs(this.options.env));
        } else {
          terminate();
        }
      } catch {
        // Process may have already exited (ESRCH)
        finish();
      }
    });

    return this.closePromise;
  }

  private handleLine(line: string): void {
    const trimmed = line.trim();
    if (!trimmed && this.bufferedJsonRpcLines.length === 0) {
      return;
    }

    const candidateLines =
      this.bufferedJsonRpcLines.length > 0 ? [...this.bufferedJsonRpcLines, line] : [trimmed];
    const candidate = candidateLines.join('\\n');
    if (candidate.length > MAX_BUFFERED_JSON_RPC_CHARS) {
      this.bufferedJsonRpcLines = [];
      this.handleProcessFailure(
        new Error(
          `codex app-server JSON-RPC message exceeded ${MAX_BUFFERED_JSON_RPC_CHARS} characters`,
        ),
      );
      void this.close();
      return;
    }
    let message: JsonRpcMessage;
    try {
      message = JSON.parse(candidate) as JsonRpcMessage;
    } catch (error) {
      if (this.shouldBufferJsonRpcLine(error, trimmed)) {
        this.bufferedJsonRpcLines = candidateLines;
        return;
      }

      logger.warn('[CodexAppServer] Failed to parse JSON-RPC line', { error, line: candidate });
      this.bufferedJsonRpcLines = [];
      return;
    }

    this.bufferedJsonRpcLines = [];
    this.handleMessage(message);
  }

  private shouldBufferJsonRpcLine(error: unknown, trimmedLine: string): boolean {
    if (this.bufferedJsonRpcLines.length > 0) {
      return true;
    }
    if (!trimmedLine.startsWith('{')) {
      return false;
    }

    const message = error instanceof Error ? error.message : String(error);
    return /Unterminated string|Unexpected end of JSON input|Bad control character/i.test(message);
  }

  private handleMessage(message: JsonRpcMessage): void {
    if (message.id !== undefined && (message.result !== undefined || message.error !== undefined)) {
      this.handleResponse(message);
      return;
    }

    if (message.id !== undefined && message.method) {
      void this.handleServerRequest(message);
      return;
    }

    if (message.method) {
      this.options.onNotification(message);
      return;
    }

    logger.debug('[CodexAppServer] Ignoring unknown JSON-RPC message shape', { message });
  }

  private handleResponse(message: JsonRpcMessage): void {
    const pendingRequest = this.pending.get(message.id as JsonRpcId);
    if (!pendingRequest) {
      logger.debug('[CodexAppServer] Received response for unknown request', { id: message.id });
      return;
    }

    this.pending.delete(message.id as JsonRpcId);
    if (pendingRequest.timeout) {
      clearTimeout(pendingRequest.timeout);
    }
    if (pendingRequest.abortSignal && pendingRequest.abortListener) {
      pendingRequest.abortSignal.removeEventListener('abort', pendingRequest.abortListener);
    }

    if (message.error) {
      pendingRequest.reject(new JsonRpcError(getJsonRpcErrorMessage(message), message.error.code));
      return;
    }
    try {
      pendingRequest.onResponse?.(message.result);
    } catch (error) {
      pendingRequest.reject(error instanceof Error ? error : new Error(String(error)));
      return;
    }
    pendingRequest.resolve(message.result);
  }

  private async handleServerRequest(message: JsonRpcMessage): Promise<void> {
    try {
      const result = await this.options.onServerRequest(message);
      this.send({ id: message.id, result });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      try {
        this.send({
          id: message.id,
          error: {
            code: -32_000,
            message: errorMessage,
          },
        });
      } catch (sendError) {
        logger.debug('[CodexAppServer] Failed to send error response for server request', {
          error: sendError,
          originalError: errorMessage,
          method: message.method,
        });
      }
    }
  }

  private recordStderr(chunk: Buffer): void {
    const text = chunk.toString('utf8');
    this.stderrChunks.push(text);
    this.stderrTotalLength += text.length;
    if (this.stderrTotalLength > 20_000) {
      const truncated = this.getStderr();
      this.stderrChunks = [truncated];
      this.stderrTotalLength = truncated.length;
    }
    logger.debug('[CodexAppServer] stderr', {
      text: redactAppServerText(sanitizeObject(text, { context: 'Codex app-server stderr' })),
    });
  }

  private handleProcessFailure(error: Error): void {
    if (this.closed) {
      return;
    }
    this.closed = true;
    const stderr = this.getStderr().trim();
    const sanitizedStderr = stderr
      ? redactAppServerText(sanitizeObject(stderr, { context: 'Codex app-server stderr' }))
      : undefined;
    const failure =
      typeof sanitizedStderr === 'string' && sanitizedStderr
        ? new Error(`${error.message}: ${sanitizedStderr}`)
        : error;
    this.rejectPending(failure);
    logger.error('[CodexAppServer] Process failure', {
      error: failure.message,
      stderr: sanitizedStderr,
    });
    this.options.onClose(failure);
  }

  private closeAfterRequestTimeout(method: string, error: Error): void {
    if (this.closed) {
      return;
    }

    logger.warn('[CodexAppServer] Closing app-server after JSON-RPC request timeout', {
      error: error.message,
      method,
    });
    this.options.onClose(error);
    void this.close().catch((closeError) => {
      logger.debug('[CodexAppServer] Error closing app-server after request timeout', {
        error: closeError,
      });
    });
  }

  private rejectPending(error: Error): void {
    for (const [id, pendingRequest] of this.pending) {
      if (pendingRequest.timeout) {
        clearTimeout(pendingRequest.timeout);
      }
      if (pendingRequest.abortSignal && pendingRequest.abortListener) {
        pendingRequest.abortSignal.removeEventListener('abort', pendingRequest.abortListener);
      }
      pendingRequest.reject(error);
      this.pending.delete(id);
    }
  }

  private send(message: JsonRpcMessage): void {
    if (this.closed) {
      throw new Error('codex app-server connection is closed');
    }
    this.process.stdin.write(`${JSON.stringify(message)}\n`);
  }
}

export class OpenAICodexAppServerProvider implements ApiProvider {
  config: CodexAppServerConfig;
  env?: EnvOverrides;
  apiKey?: string;

  private providerId = 'openai:codex-app-server';
  private connections = new Map<string, CodexAppServerConnection>();
  private connectionPromises = new Map<string, Promise<CodexAppServerConnection>>();
  private initializingConnections = new Set<CodexAppServerConnection>();
  private threads = new Map<string, ThreadHandle>();
  private threadPromises = new Map<string, Promise<ThreadHandle>>();
  private threadPromiseConnectionInstances = new Map<string, string>();
  private explicitThreadAbortCleanups = new Map<string, Promise<void>>();
  private protectedThreadCounts = new Map<string, number>();
  private threadRunQueues = new Map<string, Promise<void>>();
  private activeTurnsByThread = new Map<string, CodexAppServerTurnState>();
  private activeTurnsByTurn = new Map<string, CodexAppServerTurnState>();
  private validatedWorkingDirs = new Set<string>();
  private ignoredProviderEnvWarningShown = false;
  private omittedProcessEnvWarningShown = false;
  private deepTracingWarningShown = false;
  private traceExporterOverrideWarningShown = false;

  constructor(
    options: {
      id?: string;
      config?: CodexAppServerConfig;
      env?: EnvOverrides;
    } = {},
  ) {
    this.config = parseCodexAppServerConfig(options.config);
    this.env = options.env;
    this.apiKey = this.getApiKey();
    this.providerId = options.id ?? this.providerId;
    providerRegistry.register(this);
  }

  id(): string {
    return this.providerId;
  }

  getApiKey(config: CodexAppServerConfig = this.config): string | undefined {
    return (
      config.apiKey ||
      this.env?.OPENAI_API_KEY ||
      this.env?.CODEX_API_KEY ||
      getEnvString('OPENAI_API_KEY') ||
      getEnvString('CODEX_API_KEY')
    );
  }

  requiresApiKey(): boolean {
    return false;
  }

  toString(): string {
    return '[OpenAI Codex App Server Provider]';
  }

  async cleanup(): Promise<void> {
    this.resolveActiveTurns(new Error('codex app-server provider cleanup interrupted active turn'));
    this.threads.clear();
    this.threadPromises.clear();
    this.threadPromiseConnectionInstances.clear();
    this.explicitThreadAbortCleanups.clear();
    this.threadRunQueues.clear();
    this.activeTurnsByThread.clear();
    this.activeTurnsByTurn.clear();
    this.protectedThreadCounts.clear();
    this.validatedWorkingDirs.clear();

    const connections = Array.from(
      new Set([...this.connections.values(), ...this.initializingConnections]),
    );
    this.connections.clear();
    this.connectionPromises.clear();
    this.initializingConnections.clear();

    await Promise.all(
      connections.map((connection) =>
        connection.close().catch((error) => {
          logger.warn('[CodexAppServer] Error during cleanup', { error });
        }),
      ),
    );
  }

  async shutdown(): Promise<void> {
    try {
      await this.cleanup();
    } finally {
      providerRegistry.unregister(this);
    }
  }

  async callApi(
    prompt: string,
    context?: CallApiContextParams,
    callOptions?: CallApiOptionsParams,
  ): Promise<ProviderResponse> {
    const mergedConfig = mergeCodexAppServerConfig(
      this.config,
      context?.prompt?.config as CodexAppServerConfig | undefined,
    );
    // Promptfoo may attach the live target provider object to prompt config for
    // generic provider workflows. Codex accepts this key for loader compatibility,
    // but runtime variable rendering must not recurse into provider methods.
    delete mergedConfig.provider;
    const config = renderVarsInObject(mergedConfig, context?.vars) as CodexAppServerConfig;
    const requestedModel =
      typeof config.model === 'string' && config.model ? config.model : undefined;

    return withGenAISpan(
      this.buildSpanContext(prompt, context, requestedModel),
      () => this.callApiInternal(prompt, context, callOptions, config),
      (response) => this.extractSpanResult(response, requestedModel),
    );
  }

  private buildSpanContext(
    prompt: string,
    context: CallApiContextParams | undefined,
    requestedModel: string | undefined,
  ): GenAISpanContext {
    return {
      system: 'openai',
      operationName: 'invoke_agent',
      model: requestedModel ?? 'Codex App Server',
      agentName: 'Codex App Server',
      providerId: this.id(),
      evalId: context?.evaluationId || context?.test?.metadata?.evaluationId,
      testIndex:
        typeof context?.test?.vars?.__testIdx === 'number'
          ? context.test.vars.__testIdx
          : undefined,
      promptLabel: context?.prompt?.label,
      traceparent: context?.traceparent,
      requestBody: prompt,
    };
  }

  private extractSpanResult(
    response: ProviderResponse,
    requestedModel: string | undefined,
  ): GenAISpanResult {
    const result: GenAISpanResult = {};
    if (response.tokenUsage) {
      result.tokenUsage = response.tokenUsage;
    }
    if (response.sessionId) {
      result.responseId = response.sessionId;
    }
    if (requestedModel) {
      result.responseModel = requestedModel;
    }
    if (response.cached !== undefined) {
      result.cacheHit = response.cached;
    }
    if (response.output !== undefined) {
      result.responseBody =
        typeof response.output === 'string' ? response.output : JSON.stringify(response.output);
    }
    if (response.metadata?.codexAppServer?.itemCounts) {
      result.additionalAttributes = {
        ...result.additionalAttributes,
        'codex.app_server.items.breakdown': JSON.stringify(
          response.metadata.codexAppServer.itemCounts,
        ),
      };
    }
    return result;
  }

  private async callApiInternal(
    prompt: string,
    context: CallApiContextParams | undefined,
    callOptions: CallApiOptionsParams | undefined,
    rawConfig: CodexAppServerConfig,
  ): Promise<ProviderResponse> {
    let config: CodexAppServerConfig;
    try {
      config = parseCodexAppServerConfig(rawConfig, { stripUnknownKeys: true });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error('Error calling OpenAI Codex app-server', { error: errorMessage });
      return { error: `Error calling OpenAI Codex app-server: ${errorMessage}` };
    }

    if (callOptions?.abortSignal?.aborted) {
      return { error: 'OpenAI Codex app-server call aborted before it started' };
    }

    const workingDirectory = this.resolveWorkingDirectory(config);
    const resolvedConfig: CodexAppServerConfig = {
      approval_policy: 'never',
      sandbox_mode: 'read-only',
      network_access_enabled: false,
      ephemeral: true,
      thread_cleanup: 'unsubscribe',
      reuse_server: true,
      ...config,
      working_dir: workingDirectory,
      additional_directories: this.resolveAdditionalDirectories(config),
    };

    const currentTraceparent = getTraceparent();
    const apiKey = this.getApiKey(resolvedConfig);
    const env = this.prepareEnvironment(resolvedConfig, currentTraceparent, apiKey);
    const promptInput = this.parsePromptInput(prompt);
    const connectionKey = this.generateConnectionKey(env, resolvedConfig);
    const useReusableConnection =
      resolvedConfig.reuse_server !== false && !resolvedConfig.deep_tracing;
    let localConnection: CodexAppServerConnection | undefined;

    try {
      this.validateWorkingDirectory(
        resolvedConfig.working_dir as string,
        resolvedConfig.skip_git_repo_check,
      );
      this.warnOnceForDeepTracingThreadOptions(resolvedConfig);

      let connection = useReusableConnection
        ? await this.getOrCreateConnection(connectionKey, env, resolvedConfig)
        : await this.createConnection(connectionKey, env, resolvedConfig);
      if (!useReusableConnection) {
        localConnection = connection;
      }

      const promptCacheBasis = context?.prompt?.raw ?? prompt;
      const explicitThreadQueueKey = resolvedConfig.thread_id
        ? `thread_id:${resolvedConfig.thread_id}`
        : undefined;
      const runThreadTurn = async (): Promise<ProviderResponse> => {
        if (useReusableConnection && connection.isClosed()) {
          connection = await this.getOrCreateConnection(connectionKey, env, resolvedConfig);
        }
        let threadHandle: ThreadHandle;
        try {
          threadHandle = await this.getOrCreateThread(
            connection,
            connectionKey,
            promptCacheBasis,
            resolvedConfig,
            useReusableConnection,
            callOptions,
          );
        } catch (error) {
          if (!(error instanceof StaleExplicitThreadConnectionClosedError)) {
            throw error;
          }
          connection = await this.getOrCreateConnection(connectionKey, env, resolvedConfig);
          threadHandle = await this.getOrCreateThread(
            connection,
            connectionKey,
            promptCacheBasis,
            resolvedConfig,
            useReusableConnection,
            callOptions,
          );
        }
        this.protectThread(threadHandle.threadId);
        let turnStarted = false;
        try {
          const queueKey = explicitThreadQueueKey
            ? undefined
            : this.getThreadRunQueueKey(resolvedConfig, threadHandle);

          return await this.runSerializedThreadTurn(
            queueKey,
            callOptions?.abortSignal,
            async () => {
              turnStarted = true;
              const state = this.createTurnState(
                connection,
                connectionKey,
                connection.instanceId,
                threadHandle.threadId,
                promptInput,
                resolvedConfig,
                env,
              );
              this.registerTurnState(state);
              try {
                const turnResponse = await connection.request(
                  'turn/start',
                  this.buildTurnStartParams(threadHandle.threadId, promptInput, resolvedConfig),
                  {
                    abortSignal: callOptions?.abortSignal,
                    timeoutMs: this.getRequestTimeoutMs(resolvedConfig),
                    onResponse: (response) => {
                      const turnId = (response as any)?.turn?.id;
                      if (typeof turnId === 'string') {
                        this.updateTurnStateId(state, turnId);
                      }
                    },
                  },
                );

                if (typeof turnResponse?.turn?.id === 'string') {
                  this.updateTurnStateId(state, turnResponse.turn.id);
                }

                await this.waitForTurnCompletion(connection, state, resolvedConfig, callOptions);
                return this.buildProviderResponse(state, threadHandle, resolvedConfig);
              } finally {
                this.unregisterTurnState(state);
                await this.cleanupThreadAfterTurn(connection, threadHandle, resolvedConfig);
              }
            },
          );
        } finally {
          this.unprotectThread(threadHandle.threadId);
          if (!turnStarted) {
            await this.cleanupThreadAfterTurn(connection, threadHandle, resolvedConfig, {
              skipIfActiveTurn: true,
            });
          }
          this.scheduleThreadPoolEnforcement(connection, connectionKey, resolvedConfig);
        }
      };

      return explicitThreadQueueKey
        ? await this.runSerializedThreadTurn(
            explicitThreadQueueKey,
            callOptions?.abortSignal,
            runThreadTurn,
          )
        : await runThreadTurn();
    } catch (error: unknown) {
      const isAbort =
        (error instanceof Error && error.name === 'AbortError') ||
        callOptions?.abortSignal?.aborted;

      if (isAbort) {
        logger.warn('OpenAI Codex app-server call aborted');
        return { error: 'OpenAI Codex app-server call aborted' };
      }

      const errorMessage = error instanceof Error ? error.message : String(error);
      logger.error('Error calling OpenAI Codex app-server', { error: errorMessage });
      return { error: `Error calling OpenAI Codex app-server: ${errorMessage}` };
    } finally {
      if (localConnection) {
        await localConnection
          .close({ graceful: resolvedConfig.deep_tracing === true })
          .catch((error) => {
            logger.debug('[CodexAppServer] Error closing local connection', { error });
          });
      }
    }
  }

  private resolveWorkingDirectory(config: CodexAppServerConfig): string {
    const basePath = config.basePath || cliState.basePath || process.cwd();
    if (!config.working_dir) {
      return process.cwd();
    }
    return resolveAgenticWorkingDir(config.working_dir, basePath) ?? process.cwd();
  }

  private resolveAdditionalDirectories(config: CodexAppServerConfig): string[] | undefined {
    if (!config.additional_directories?.length) {
      return undefined;
    }
    const basePath = config.basePath || cliState.basePath || process.cwd();
    return config.additional_directories.map((directory) => path.resolve(basePath, directory));
  }

  private prepareEnvironment(
    config: CodexAppServerConfig,
    traceparent?: string,
    apiKey: string | undefined = this.getApiKey(config),
  ): Record<string, string> {
    const inheritProcessEnv = config.inherit_process_env === true;
    const cliEnv = Object.fromEntries(
      Object.entries(config.cli_env ?? {}).map(([key, value]) => [key, String(value)]),
    );
    const env: Record<string, string> = {
      ...(inheritProcessEnv ? (process.env as Record<string, string>) : getMinimalProcessEnv()),
      ...cliEnv,
    };

    const ignoredProviderEnvKeys = Object.keys(this.env ?? {})
      .filter(
        (key) =>
          key !== 'OPENAI_API_KEY' && key !== 'CODEX_API_KEY' && !(key in (config.cli_env ?? {})),
      )
      .sort();

    if (ignoredProviderEnvKeys.length > 0 && !this.ignoredProviderEnvWarningShown) {
      logger.warn(
        '[CodexAppServer] Ignoring promptfoo-level env overrides for the Codex app-server process. ' +
          'Move these keys into config.cli_env if Codex shell commands need them.',
        { envKeys: ignoredProviderEnvKeys },
      );
      this.ignoredProviderEnvWarningShown = true;
    }

    if (!inheritProcessEnv && !this.omittedProcessEnvWarningShown) {
      const omittedProcessEnvKeys = this.getOmittedOptionalProcessEnvKeys(config, env);
      if (omittedProcessEnvKeys.length > 0) {
        logger.warn(
          '[CodexAppServer] Optional Codex app-server process env vars are not inherited by default. ' +
            'Move these keys into config.cli_env or set inherit_process_env: true if Codex commands need them.',
          { envKeys: omittedProcessEnvKeys },
        );
        this.omittedProcessEnvWarningShown = true;
      }
    }

    const sortedEnv: Record<string, string> = {};
    for (const key of Object.keys(env).sort()) {
      if (env[key] !== undefined) {
        sortedEnv[key] = env[key];
      }
    }

    applyApiKeyToCliEnv(sortedEnv, config, apiKey);

    if (config.base_url) {
      sortedEnv.OPENAI_BASE_URL = config.base_url;
      sortedEnv.OPENAI_API_BASE_URL = config.base_url;
    }

    if (config.deep_tracing) {
      if (!sortedEnv.OTEL_EXPORTER_OTLP_ENDPOINT) {
        sortedEnv.OTEL_EXPORTER_OTLP_ENDPOINT = getCodexTraceEndpoint();
      }
      if (!sortedEnv.OTEL_EXPORTER_OTLP_PROTOCOL) {
        sortedEnv.OTEL_EXPORTER_OTLP_PROTOCOL = getCodexTraceProtocol();
      }
      if (!sortedEnv.OTEL_SERVICE_NAME) {
        sortedEnv.OTEL_SERVICE_NAME = 'codex-app-server';
      }
      if (!sortedEnv.OTEL_TRACES_EXPORTER) {
        sortedEnv.OTEL_TRACES_EXPORTER = 'otlp';
      }
      if (traceparent) {
        sortedEnv.TRACEPARENT = traceparent;
      }
    } else {
      delete sortedEnv.TRACEPARENT;
    }

    return sortedEnv;
  }

  private getOmittedOptionalProcessEnvKeys(
    config: CodexAppServerConfig,
    env: Record<string, string>,
  ): string[] {
    const shouldWarnForSshEnv = config.network_access_enabled === true;
    return COMMON_OPTIONAL_PROCESS_ENV_KEYS.filter(
      (key) =>
        typeof process.env[key] === 'string' &&
        !(key in env) &&
        (shouldWarnForSshEnv || (key !== 'SSH_AUTH_SOCK' && key !== 'GIT_SSH_COMMAND')),
    );
  }

  private buildAppServerArgs(config: CodexAppServerConfig, env: Record<string, string>): string[] {
    const args = ['app-server', '--listen', 'stdio://'];
    const cliConfig = this.getResolvedCliConfig(config, env);
    for (const { key, value } of flattenConfig(cliConfig)) {
      args.push('-c', `${key}=${toTomlLiteral(value)}`);
    }
    return args;
  }

  private getResolvedCliConfig(
    config: CodexAppServerConfig,
    env: Record<string, string> = {},
  ): Record<string, unknown> {
    return withCodexTraceExporter(
      { ...(config.cli_config ?? {}) },
      env,
      config.deep_tracing === true,
    );
  }

  private getRequestTimeoutMs(config: CodexAppServerConfig): number {
    return config.request_timeout_ms ?? DEFAULT_REQUEST_TIMEOUT_MS;
  }

  private async getOrCreateConnection(
    connectionKey: string,
    env: Record<string, string>,
    config: CodexAppServerConfig,
  ): Promise<CodexAppServerConnection> {
    const existing = this.connections.get(connectionKey);
    if (existing) {
      return existing;
    }

    const pending = this.connectionPromises.get(connectionKey);
    if (pending) {
      return pending;
    }

    let connectionPromise: Promise<CodexAppServerConnection>;
    connectionPromise = this.createConnection(connectionKey, env, config)
      .then((connection) => {
        if (this.connectionPromises.get(connectionKey) !== connectionPromise) {
          void connection.close().catch((error) => {
            logger.debug('[CodexAppServer] Error closing stale initialized connection', { error });
          });
          throw new Error('codex app-server connection was closed during cleanup');
        }
        this.connections.set(connectionKey, connection);
        return connection;
      })
      .finally(() => {
        this.connectionPromises.delete(connectionKey);
      });
    this.connectionPromises.set(connectionKey, connectionPromise);
    return connectionPromise;
  }

  private async createConnection(
    connectionKey: string,
    env: Record<string, string>,
    config: CodexAppServerConfig,
  ): Promise<CodexAppServerConnection> {
    const connectionInstanceId = `${connectionKey}:${crypto.randomUUID()}`;
    const connection = new CodexAppServerConnection({
      connectionInstanceId,
      command: config.codex_path_override ?? 'codex',
      args: this.buildAppServerArgs(config, env),
      env,
      requestTimeoutMs: this.getRequestTimeoutMs(config),
      startupTimeoutMs: config.startup_timeout_ms ?? DEFAULT_STARTUP_TIMEOUT_MS,
      onNotification: (message) => this.handleNotification(message),
      onServerRequest: (message) => this.handleServerRequest(message, config),
      onClose: (error) => this.handleConnectionClose(connectionKey, connectionInstanceId, error),
    });

    this.initializingConnections.add(connection);
    try {
      await connection.initialize(config);
      const apiKey = this.getApiKey(config);
      // Don't log in with an ambient OpenAI/Codex key when routing to a custom model_provider
      // (e.g. amazon-bedrock) — it's unrelated to the backend. Gate it like the env injection.
      if (shouldInjectApiKey(config, apiKey)) {
        try {
          await connection.request(
            'account/login/start',
            {
              type: 'apiKey',
              apiKey,
            },
            { timeoutMs: this.getRequestTimeoutMs(config) },
          );
        } catch (error) {
          if (!isMethodNotFoundError(error)) {
            throw error;
          }
          logger.debug(
            '[CodexAppServer] account/login/start is unavailable; continuing with API key env auth',
          );
        }
      }
      await this.warnForTraceExporterOverride(connection, config, env);
      return connection;
    } catch (error) {
      await connection.close().catch((closeError) => {
        logger.debug('[CodexAppServer] Error closing app-server after failed initialization', {
          error: closeError,
        });
      });
      throw error;
    } finally {
      this.initializingConnections.delete(connection);
    }
  }

  private async warnForTraceExporterOverride(
    connection: CodexAppServerConnection,
    config: CodexAppServerConfig,
    env: Record<string, string>,
  ): Promise<void> {
    if (!config.deep_tracing || this.traceExporterOverrideWarningShown) {
      return;
    }

    const requestedExporter = getCodexTraceExporterSettings(this.getResolvedCliConfig(config, env));
    if (!requestedExporter) {
      return;
    }

    let effectiveConfig: unknown;
    try {
      effectiveConfig = await connection.request(
        'config/read',
        { includeLayers: false },
        { timeoutMs: this.getRequestTimeoutMs(config) },
      );
    } catch (error) {
      logger.debug('[CodexAppServer] Unable to inspect the effective Codex trace exporter', {
        error: error instanceof Error ? error.message : String(error),
      });
      return;
    }

    if (!isPlainObject(effectiveConfig)) {
      return;
    }

    const effectiveExporter = getCodexTraceExporterSettings(effectiveConfig.config);
    const effectiveExporterValue = getCodexTraceExporterValue(effectiveConfig.config);
    if (
      (!effectiveExporter && effectiveExporterValue === undefined) ||
      (effectiveExporter &&
        effectiveExporter.endpoint === requestedExporter.endpoint &&
        (!effectiveExporter.protocol ||
          !requestedExporter.protocol ||
          effectiveExporter.protocol === requestedExporter.protocol))
    ) {
      return;
    }

    const configOrigin =
      (effectiveExporter &&
        (getCodexConfigOriginType(effectiveConfig.origins, effectiveExporter.endpointConfigKey) ??
          getCodexConfigOriginType(
            effectiveConfig.origins,
            effectiveExporter.protocolConfigKey,
          ))) ??
      getCodexConfigOriginType(effectiveConfig.origins, 'otel.trace_exporter');
    const managedOverride = configOrigin !== undefined && /managed|mdm/i.test(configOrigin);
    const exporterState =
      typeof effectiveExporterValue === 'string' ? effectiveExporterValue : 'unsupported';
    this.traceExporterOverrideWarningShown = true;
    logger.warn(
      `[CodexAppServer] ${managedOverride ? 'Enterprise-managed' : 'Effective'} Codex configuration overrides the requested trace exporter. Native spans will not reach the configured trace receiver.`,
      {
        requestedOrigin: getSafeTraceExporterOrigin(requestedExporter.endpoint),
        ...(effectiveExporter
          ? { effectiveOrigin: getSafeTraceExporterOrigin(effectiveExporter.endpoint) }
          : { effectiveExporter: exporterState }),
        requestedProtocol: requestedExporter.protocol,
        effectiveProtocol: effectiveExporter?.protocol,
        ...(configOrigin && { configOrigin }),
      },
    );
  }

  private handleConnectionClose(
    connectionKey: string,
    connectionInstanceId: string,
    error: Error,
  ): void {
    logger.warn('[CodexAppServer] Connection closed', { connectionKey, error: error.message });
    const cachedConnection = this.connections.get(connectionKey);
    if (cachedConnection?.instanceId === connectionInstanceId) {
      this.connections.delete(connectionKey);
      this.connectionPromises.delete(connectionKey);
      for (const [threadCacheKey, handle] of this.threads) {
        if (handle.connectionKey === connectionKey) {
          this.threads.delete(threadCacheKey);
        }
      }
      for (const [threadCacheKey] of this.threadPromises) {
        if (this.threadPromiseConnectionInstances.get(threadCacheKey) === connectionInstanceId) {
          this.threadPromises.delete(threadCacheKey);
          this.threadPromiseConnectionInstances.delete(threadCacheKey);
        }
      }
    }

    this.resolveActiveTurns(error, (state) => state.connectionInstanceId === connectionInstanceId);
  }

  private resolveActiveTurns(
    error: Error,
    predicate: (state: CodexAppServerTurnState) => boolean = () => true,
  ): void {
    for (const state of new Set(this.activeTurnsByThread.values())) {
      if (!predicate(state)) {
        continue;
      }
      state.error = error.message;
      state.completed.resolve();
    }
  }

  private generateConnectionKey(env: Record<string, string>, config: CodexAppServerConfig): string {
    const stableEnv = { ...env };
    delete stableEnv.TRACEPARENT;
    const keyData = {
      env: stableEnv,
      codex_path_override: config.codex_path_override,
      cli_config: this.getResolvedCliConfig(config, env),
      experimental_api: config.experimental_api,
    };
    const hash = crypto.createHash('sha256').update(JSON.stringify(keyData)).digest('hex');
    return `openai:codex-app-server:connection:${hash}`;
  }

  private generateThreadCacheKey(
    connectionKey: string,
    promptCacheBasis: string,
    config: CodexAppServerConfig,
  ): string {
    const keyData = {
      connectionKey,
      prompt: promptCacheBasis,
      working_dir: config.working_dir,
      additional_directories: config.additional_directories,
      model: config.model,
      model_provider: config.model_provider,
      service_tier: config.service_tier,
      sandbox_mode: config.sandbox_mode,
      sandbox_policy: config.sandbox_policy,
      network_access_enabled: config.network_access_enabled,
      approval_policy: config.approval_policy,
      approvals_reviewer: config.approvals_reviewer,
      model_reasoning_effort: config.model_reasoning_effort,
      reasoning_summary: config.reasoning_summary,
      personality: config.personality,
      base_instructions: config.base_instructions,
      developer_instructions: config.developer_instructions,
      collaboration_mode: config.collaboration_mode,
      output_schema: config.output_schema,
      base_url: config.base_url,
      ephemeral: config.ephemeral,
      experimental_raw_events: config.experimental_raw_events,
      persist_extended_history: config.persist_extended_history,
    };
    const hash = crypto.createHash('sha256').update(JSON.stringify(keyData)).digest('hex');
    return `openai:codex-app-server:thread:${hash}`;
  }

  private generateExplicitThreadCachePrefix(threadId: string): string {
    const threadHash = crypto.createHash('sha256').update(threadId).digest('hex');
    return `openai:codex-app-server:thread_id:${threadHash}:`;
  }

  private generateExplicitThreadCacheKey(
    connectionKey: string,
    threadId: string,
    config: CodexAppServerConfig,
  ): string {
    const resumeHash = crypto
      .createHash('sha256')
      .update(
        JSON.stringify({
          connectionKey,
          resume: this.buildThreadResumeParams(threadId, config),
        }),
      )
      .digest('hex');
    return `${this.generateExplicitThreadCachePrefix(threadId)}${resumeHash}`;
  }

  private async discardOtherExplicitThreadVariants(
    prefix: string,
    keepKey: string,
    connection: CodexAppServerConnection,
    connectionKey: string,
    timeoutMs: number,
  ): Promise<void> {
    const staleKeys = Array.from(this.threads.keys()).filter(
      (key) => key.startsWith(prefix) && key !== keepKey,
    );
    for (const key of staleKeys) {
      const stale = this.threads.get(key);
      this.threads.delete(key);
      if (!stale) {
        continue;
      }
      const staleConnection =
        this.connections.get(stale.connectionKey) ??
        (stale.connectionKey === connectionKey ? connection : undefined);
      if (staleConnection) {
        try {
          await staleConnection.request(
            'thread/unsubscribe',
            { threadId: stale.threadId },
            { timeoutMs },
          );
        } catch (error) {
          logger.warn('[CodexAppServer] Failed to unsubscribe stale explicit thread variant', {
            error,
            threadId: stale.threadId,
          });
          if (staleConnection === connection && connection.isClosed()) {
            throw new StaleExplicitThreadConnectionClosedError();
          }
        }
      }
    }
  }

  private async settleOtherExplicitThreadVariants(
    prefix: string,
    keepKey: string,
    abortSignal?: AbortSignal,
  ): Promise<void> {
    const pending: Promise<unknown>[] = Array.from(this.threadPromises.entries())
      .filter(([key]) => key.startsWith(prefix) && key !== keepKey)
      .map(([, promise]) => promise);
    const abortCleanups = Array.from(this.explicitThreadAbortCleanups.entries())
      .filter(([key]) => key.startsWith(prefix))
      .map(([, promise]) => promise);
    pending.push(...abortCleanups);
    if (pending.length > 0) {
      await this.waitForPreviousThreadRun(
        Promise.allSettled(pending).then(() => undefined),
        abortSignal,
      );
    }
  }

  private async getOrCreateThread(
    connection: CodexAppServerConnection,
    connectionKey: string,
    promptCacheBasis: string,
    config: CodexAppServerConfig,
    allowThreadPersistence: boolean,
    callOptions?: CallApiOptionsParams,
  ): Promise<ThreadHandle> {
    const canPersistThread = allowThreadPersistence && config.persist_threads === true;

    if (config.thread_id) {
      const variantKey = this.generateExplicitThreadCacheKey(
        connectionKey,
        config.thread_id,
        config,
      );
      const cacheKey = canPersistThread ? variantKey : undefined;
      await this.settleOtherExplicitThreadVariants(
        this.generateExplicitThreadCachePrefix(config.thread_id),
        variantKey,
        callOptions?.abortSignal,
      );
      if (cacheKey) {
        await this.discardOtherExplicitThreadVariants(
          this.generateExplicitThreadCachePrefix(config.thread_id),
          cacheKey,
          connection,
          connectionKey,
          this.getRequestTimeoutMs(config),
        );
      }
      const cachedOrPending =
        (cacheKey ? this.threads.get(cacheKey) : undefined) ?? this.threadPromises.get(variantKey);
      if (cachedOrPending !== undefined) {
        return this.waitForThreadHandle(cachedOrPending, callOptions?.abortSignal);
      }

      this.throwIfThreadWaitAborted(callOptions?.abortSignal);
      const threadPromise = this.cacheThreadPromise(variantKey, connection.instanceId, async () => {
        const response = await connection.request(
          'thread/resume',
          this.buildThreadResumeParams(config.thread_id as string, config),
          { timeoutMs: this.getRequestTimeoutMs(config) },
        );
        const handle = {
          connectionKey,
          threadId: response?.thread?.id ?? config.thread_id,
          response,
          cacheKey,
          persistent: canPersistThread,
        };
        if (cacheKey) {
          this.threads.set(cacheKey, handle);
        }
        return handle;
      });
      return cacheKey
        ? this.waitForThreadHandle(threadPromise, callOptions?.abortSignal)
        : this.waitForThreadHandle(threadPromise, callOptions?.abortSignal, {
            onAbortResolvedThread: (threadHandle) =>
              this.cleanupThreadAfterTurn(connection, threadHandle, config, {
                skipIfProtected: true,
              }),
            onAbortCleanupScheduled: (cleanup) =>
              this.trackExplicitThreadAbortCleanup(variantKey, cleanup),
          });
    }

    const cacheKey = canPersistThread
      ? this.generateThreadCacheKey(connectionKey, promptCacheBasis, config)
      : undefined;
    const cachedOrPending = this.getCachedOrPendingThread(cacheKey);
    if (cachedOrPending !== undefined) {
      return this.waitForThreadHandle(cachedOrPending, callOptions?.abortSignal);
    }

    this.throwIfThreadWaitAborted(callOptions?.abortSignal);
    const threadPromise = this.cacheThreadPromise(cacheKey, connection.instanceId, async () => {
      const poolSize = config.thread_pool_size ?? 1;
      if (cacheKey && this.threads.size >= poolSize) {
        await this.evictOldestInactiveCachedThread(
          connection,
          connectionKey,
          this.getRequestTimeoutMs(config),
        );
      }

      const response = await connection.request(
        'thread/start',
        this.buildThreadStartParams(config),
        {
          timeoutMs: this.getRequestTimeoutMs(config),
        },
      );
      const threadId = response?.thread?.id;
      if (typeof threadId !== 'string' || !threadId) {
        throw new Error('codex app-server did not return a thread id');
      }

      const handle = {
        connectionKey,
        threadId,
        response,
        cacheKey,
        persistent: canPersistThread,
      };
      if (cacheKey) {
        this.threads.set(cacheKey, handle);
      }
      return handle;
    });
    return cacheKey
      ? this.waitForThreadHandle(threadPromise, callOptions?.abortSignal)
      : this.waitForThreadHandle(threadPromise, callOptions?.abortSignal, {
          onAbortResolvedThread: (threadHandle) =>
            this.cleanupThreadAfterTurn(connection, threadHandle, config, {
              skipIfProtected: true,
            }),
        });
  }

  private getCachedOrPendingThread(
    cacheKey: string | undefined,
  ): ThreadHandle | Promise<ThreadHandle> | undefined {
    if (!cacheKey) {
      return undefined;
    }
    return this.threads.get(cacheKey) ?? this.threadPromises.get(cacheKey);
  }

  private cacheThreadPromise(
    cacheKey: string | undefined,
    connectionInstanceId: string,
    createThread: () => Promise<ThreadHandle>,
  ): Promise<ThreadHandle> {
    if (!cacheKey) {
      return createThread();
    }

    let threadPromise: Promise<ThreadHandle>;
    threadPromise = createThread().finally(() => {
      if (this.threadPromises.get(cacheKey) === threadPromise) {
        this.threadPromises.delete(cacheKey);
        this.threadPromiseConnectionInstances.delete(cacheKey);
      }
    });
    this.threadPromises.set(cacheKey, threadPromise);
    this.threadPromiseConnectionInstances.set(cacheKey, connectionInstanceId);
    return threadPromise;
  }

  private throwIfThreadWaitAborted(abortSignal: AbortSignal | undefined): void {
    if (abortSignal?.aborted) {
      throw createAbortError('Codex app-server thread wait aborted');
    }
  }

  private async waitForThreadHandle(
    thread: ThreadHandle | Promise<ThreadHandle>,
    abortSignal: AbortSignal | undefined,
    options: {
      abortMessage?: string;
      onAbortResolvedThread?: (threadHandle: ThreadHandle) => Promise<void>;
      onAbortCleanupScheduled?: (cleanup: Promise<void>) => void;
    } = {},
  ): Promise<ThreadHandle> {
    const threadPromise = Promise.resolve(thread);
    if (!abortSignal) {
      return threadPromise;
    }

    let abortCleanupScheduled = false;
    const scheduleAbortCleanup = () => {
      if (abortCleanupScheduled) {
        return;
      }
      abortCleanupScheduled = true;
      const cleanup = threadPromise
        .then(async (threadHandle) => {
          if (options.onAbortResolvedThread) {
            await options.onAbortResolvedThread(threadHandle);
          }
        })
        .catch((error) => {
          logger.debug('[CodexAppServer] Thread request finished with error after abort', {
            error,
          });
        });
      options.onAbortCleanupScheduled?.(cleanup);
      void cleanup;
    };

    const createThreadAbortError = () =>
      createAbortError(options.abortMessage ?? 'Codex app-server thread wait aborted');

    if (abortSignal.aborted) {
      scheduleAbortCleanup();
      throw createThreadAbortError();
    }

    let abortListener: (() => void) | undefined;
    const abortPromise = new Promise<ThreadHandle>((_, reject) => {
      abortListener = () => {
        scheduleAbortCleanup();
        reject(createThreadAbortError());
      };
      abortSignal.addEventListener('abort', abortListener, { once: true });
    });

    try {
      return await Promise.race([threadPromise, abortPromise]);
    } finally {
      if (abortListener) {
        abortSignal.removeEventListener('abort', abortListener);
      }
    }
  }

  private trackExplicitThreadAbortCleanup(cacheKey: string, cleanup: Promise<void>): void {
    this.explicitThreadAbortCleanups.set(cacheKey, cleanup);
    void cleanup.finally(() => {
      if (this.explicitThreadAbortCleanups.get(cacheKey) === cleanup) {
        this.explicitThreadAbortCleanups.delete(cacheKey);
      }
    });
  }

  private scheduleThreadPoolEnforcement(
    fallbackConnection: CodexAppServerConnection,
    fallbackConnectionKey: string,
    config: CodexAppServerConfig,
  ): void {
    if (!config.persist_threads || config.thread_id) {
      return;
    }

    void this.enforceThreadPoolLimit(fallbackConnection, fallbackConnectionKey, config).catch(
      (error) => {
        logger.debug('[CodexAppServer] Error enforcing thread pool limit', { error });
      },
    );
  }

  private async enforceThreadPoolLimit(
    fallbackConnection: CodexAppServerConnection,
    fallbackConnectionKey: string,
    config: CodexAppServerConfig,
  ): Promise<void> {
    const poolSize = config.thread_pool_size ?? 1;
    while (this.threads.size > poolSize) {
      const evicted = await this.evictOldestInactiveCachedThread(
        fallbackConnection,
        fallbackConnectionKey,
        this.getRequestTimeoutMs(config),
      );
      if (!evicted) {
        return;
      }
    }
  }

  private async evictOldestInactiveCachedThread(
    fallbackConnection: CodexAppServerConnection,
    fallbackConnectionKey: string,
    timeoutMs: number,
  ): Promise<boolean> {
    for (const [cacheKey, handle] of this.threads) {
      if (this.isThreadProtected(handle.threadId)) {
        continue;
      }
      await this.evictCachedThread(fallbackConnection, fallbackConnectionKey, cacheKey, timeoutMs);
      return true;
    }

    logger.debug('[CodexAppServer] Thread pool is full, but all cached threads are active');
    return false;
  }

  private async evictCachedThread(
    fallbackConnection: CodexAppServerConnection,
    fallbackConnectionKey: string,
    cacheKey: string,
    timeoutMs: number,
  ): Promise<void> {
    const evicted = this.threads.get(cacheKey);
    this.threads.delete(cacheKey);
    if (!evicted) {
      return;
    }

    const connection =
      this.connections.get(evicted.connectionKey) ??
      (evicted.connectionKey === fallbackConnectionKey ? fallbackConnection : undefined);
    if (!connection) {
      logger.debug('[CodexAppServer] Evicted cached thread without an active connection', {
        threadId: evicted.threadId,
      });
      return;
    }

    try {
      await connection.request('thread/unsubscribe', { threadId: evicted.threadId }, { timeoutMs });
    } catch (error) {
      logger.warn('[CodexAppServer] Failed to unsubscribe evicted cached thread', {
        error,
        threadId: evicted.threadId,
      });
    }
  }

  private buildThreadStartParams(config: CodexAppServerConfig): Record<string, unknown> {
    return {
      ...(config.model ? { model: config.model } : {}),
      ...(config.model_provider ? { modelProvider: config.model_provider } : {}),
      ...(config.service_tier ? { serviceTier: config.service_tier } : {}),
      ...(config.working_dir ? { cwd: config.working_dir } : {}),
      approvalPolicy: config.approval_policy ?? 'never',
      ...(config.approvals_reviewer ? { approvalsReviewer: config.approvals_reviewer } : {}),
      sandbox: config.sandbox_mode ?? 'read-only',
      ...(Object.keys(config.cli_config ?? {}).length > 0 ? { config: config.cli_config } : {}),
      serviceName: 'promptfoo',
      ...(config.base_instructions ? { baseInstructions: config.base_instructions } : {}),
      ...(config.developer_instructions
        ? { developerInstructions: config.developer_instructions }
        : {}),
      ...(config.personality ? { personality: config.personality } : {}),
      ...(config.base_url
        ? { config: { ...(config.cli_config ?? {}), base_url: config.base_url } }
        : {}),
      ephemeral: config.ephemeral ?? true,
      experimentalRawEvents: config.experimental_raw_events ?? false,
      persistExtendedHistory: config.persist_extended_history ?? false,
    };
  }

  private buildThreadResumeParams(
    threadId: string,
    config: CodexAppServerConfig,
  ): Record<string, unknown> {
    return {
      threadId,
      ...(config.model ? { model: config.model } : {}),
      ...(config.model_provider ? { modelProvider: config.model_provider } : {}),
      ...(config.service_tier ? { serviceTier: config.service_tier } : {}),
      ...(config.working_dir ? { cwd: config.working_dir } : {}),
      approvalPolicy: config.approval_policy ?? 'never',
      ...(config.approvals_reviewer ? { approvalsReviewer: config.approvals_reviewer } : {}),
      sandbox: config.sandbox_mode ?? 'read-only',
      ...(Object.keys(config.cli_config ?? {}).length > 0 ? { config: config.cli_config } : {}),
      ...(config.base_instructions ? { baseInstructions: config.base_instructions } : {}),
      ...(config.developer_instructions
        ? { developerInstructions: config.developer_instructions }
        : {}),
      ...(config.personality ? { personality: config.personality } : {}),
      persistExtendedHistory: config.persist_extended_history ?? false,
    };
  }

  private buildTurnStartParams(
    threadId: string,
    input: CodexAppServerUserInput[],
    config: CodexAppServerConfig,
  ): Record<string, unknown> {
    return {
      threadId,
      input,
      ...(config.working_dir ? { cwd: config.working_dir } : {}),
      approvalPolicy: config.approval_policy ?? 'never',
      ...(config.approvals_reviewer ? { approvalsReviewer: config.approvals_reviewer } : {}),
      ...(config.sandbox_policy || config.network_access_enabled !== undefined
        ? { sandboxPolicy: this.buildSandboxPolicy(config) }
        : {}),
      ...(config.model ? { model: config.model } : {}),
      ...(config.service_tier ? { serviceTier: config.service_tier } : {}),
      ...(config.model_reasoning_effort ? { effort: config.model_reasoning_effort } : {}),
      ...(config.reasoning_summary ? { summary: config.reasoning_summary } : {}),
      ...(config.personality ? { personality: config.personality } : {}),
      ...(config.collaboration_mode ? { collaborationMode: config.collaboration_mode } : {}),
      ...(config.output_schema ? { outputSchema: config.output_schema } : {}),
    };
  }

  private buildSandboxPolicy(config: CodexAppServerConfig): Record<string, unknown> {
    if (config.sandbox_policy) {
      return config.sandbox_policy;
    }

    const networkAccess = config.network_access_enabled === true;
    switch (config.sandbox_mode ?? 'read-only') {
      case 'danger-full-access':
        return { type: 'dangerFullAccess' };
      case 'workspace-write':
        return {
          type: 'workspaceWrite',
          writableRoots: [
            config.working_dir as string,
            ...(config.additional_directories ?? []),
          ].filter(Boolean),
          readOnlyAccess: { type: 'fullAccess' },
          networkAccess,
          excludeTmpdirEnvVar: false,
          excludeSlashTmp: false,
        };
      case 'read-only':
      default:
        return {
          type: 'readOnly',
          access: { type: 'fullAccess' },
          networkAccess,
        };
    }
  }

  private parsePromptInput(prompt: string): CodexAppServerUserInput[] {
    let parsedPrompt: unknown;
    try {
      parsedPrompt = JSON.parse(prompt);
    } catch {
      // Non-JSON prompts are treated as plain text
      return [{ type: 'text', text: prompt, text_elements: [] }];
    }

    if (!Array.isArray(parsedPrompt) || parsedPrompt.length === 0) {
      return [{ type: 'text', text: prompt, text_elements: [] }];
    }

    const input: CodexAppServerUserInput[] = [];
    for (const item of parsedPrompt) {
      if (!this.isPromptInputItem(item)) {
        return [{ type: 'text', text: prompt, text_elements: [] }];
      }
      input.push(this.normalizePromptInputItem(item));
    }
    return input;
  }

  private isPromptInputItem(item: unknown): item is CodexAppServerPromptInputItem {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      return false;
    }

    if ('type' in item && item.type === 'text') {
      return 'text' in item && typeof item.text === 'string';
    }
    if ('type' in item && item.type === 'image') {
      return 'url' in item && typeof item.url === 'string';
    }
    if ('type' in item && (item.type === 'local_image' || item.type === 'localImage')) {
      return 'path' in item && typeof item.path === 'string';
    }
    if ('type' in item && (item.type === 'skill' || item.type === 'mention')) {
      return (
        'name' in item &&
        typeof item.name === 'string' &&
        'path' in item &&
        typeof item.path === 'string'
      );
    }
    return false;
  }

  private normalizePromptInputItem(item: CodexAppServerPromptInputItem): CodexAppServerUserInput {
    switch (item.type) {
      case 'text':
        return { type: 'text', text: item.text, text_elements: [] };
      case 'image':
        return { type: 'image', url: item.url };
      case 'local_image':
      case 'localImage':
        return { type: 'localImage', path: item.path };
      case 'skill':
        return { type: 'skill', name: item.name, path: item.path };
      case 'mention':
        return { type: 'mention', name: item.name, path: item.path };
    }
  }

  private formatPromptInputForTrace(input: CodexAppServerUserInput[]): string {
    return input
      .map((item) => {
        switch (item.type) {
          case 'text':
            return item.text;
          case 'image':
            return `[image: ${item.url}]`;
          case 'localImage':
            return `[local_image: ${item.path}]`;
          case 'skill':
            return `[skill: ${item.name} ${item.path}]`;
          case 'mention':
            return `[mention: ${item.name} ${item.path}]`;
        }
      })
      .join('\n');
  }

  private createTurnState(
    connection: CodexAppServerConnection,
    connectionKey: string,
    connectionInstanceId: string,
    threadId: string,
    promptInput: CodexAppServerUserInput[],
    config: CodexAppServerConfig,
    appServerEnv: Record<string, string>,
  ): CodexAppServerTurnState {
    return {
      connection,
      connectionKey,
      connectionInstanceId,
      threadId,
      config,
      appServerEnv,
      promptInput,
      items: [],
      itemStarts: [],
      notifications: [],
      notificationCount: 0,
      bufferedEventChars: 0,
      serverRequests: [],
      agentMessageDeltas: [],
      agentMessageDeltasByItemId: new Map(),
      commandExecutionOutputDeltasByItemId: new Map(),
      completed: createDeferred<void>(),
      activeSpans: new Map(),
      itemStartTimes: new Map(),
      lastEventTime: Date.now(),
      turnCount: 0,
      activeTurnSpan: undefined,
      activeTurnIndex: 0,
    };
  }

  private registerTurnState(state: CodexAppServerTurnState): void {
    this.activeTurnsByThread.set(state.threadId, state);
    if (state.turnId) {
      this.activeTurnsByTurn.set(state.turnId, state);
    }
  }

  private updateTurnStateId(state: CodexAppServerTurnState, turnId: string): void {
    if (state.turnId && state.turnId !== turnId) {
      this.activeTurnsByTurn.delete(state.turnId);
    }
    state.turnId = turnId;
    this.activeTurnsByTurn.set(turnId, state);
  }

  private unregisterTurnState(state: CodexAppServerTurnState): void {
    this.activeTurnsByThread.delete(state.threadId);
    if (state.turnId) {
      this.activeTurnsByTurn.delete(state.turnId);
    }
    this.endUnclosedItemSpans(state);
  }

  private protectThread(threadId: string): void {
    this.protectedThreadCounts.set(threadId, (this.protectedThreadCounts.get(threadId) ?? 0) + 1);
  }

  private unprotectThread(threadId: string): void {
    const count = this.protectedThreadCounts.get(threadId);
    if (!count || count <= 1) {
      this.protectedThreadCounts.delete(threadId);
      return;
    }
    this.protectedThreadCounts.set(threadId, count - 1);
  }

  private isThreadProtected(threadId: string): boolean {
    return (
      this.activeTurnsByThread.has(threadId) || (this.protectedThreadCounts.get(threadId) ?? 0) > 0
    );
  }

  private getTurnState(
    threadId?: string,
    turnId?: string | null,
  ): CodexAppServerTurnState | undefined {
    if (turnId) {
      return this.activeTurnsByTurn.get(turnId);
    }
    if (threadId) {
      return this.activeTurnsByThread.get(threadId);
    }
    return undefined;
  }

  private handleNotification(message: JsonRpcMessage): void {
    const params = message.params ?? {};
    const state = this.getTurnState(params.threadId, params.turnId);
    if (!state) {
      logger.debug('[CodexAppServer] Notification without active turn', { method: message.method });
      return;
    }

    if (!this.reserveTurnEvent(state, message)) {
      return;
    }

    state.notificationCount += 1;
    if (state.config.include_raw_events) {
      state.notifications.push(message);
    }
    const eventTime = Date.now();

    switch (message.method) {
      case 'turn/started':
        if (typeof params.turn?.id === 'string') {
          this.updateTurnStateId(state, params.turn.id);
        }
        this.startTurnSpan(state, eventTime, true);
        break;
      case 'item/started':
        if (!state.activeTurnSpan) {
          // App-server flows that ack `turn/start` as a request response (vs.
          // sending `turn/started` as a notification) reach the items first.
          // Lazily open a turn span so they still get a `gen_ai.turn.index`.
          this.startTurnSpan(state, eventTime);
        }
        this.handleItemStarted(state, params.item, eventTime);
        break;
      case 'item/completed':
        if (!state.activeTurnSpan) {
          this.startTurnSpan(state, eventTime);
        }
        this.handleItemCompleted(state, params.item, eventTime);
        break;
      case 'item/agentMessage/delta':
        this.handleAgentMessageDelta(state, params);
        break;
      case 'item/commandExecution/outputDelta':
        this.handleCommandExecutionOutputDelta(state, params);
        break;
      case 'thread/tokenUsage/updated':
        state.rawTokenUsage = params.tokenUsage;
        state.tokenUsage = this.buildTokenUsage(params.tokenUsage);
        break;
      case 'turn/completed':
        state.turn = params.turn;
        if (params.turn?.status === 'failed') {
          state.error = params.turn?.error?.message ?? 'Codex app-server turn failed';
        }
        if (!state.activeTurnSpan) {
          // Stream lacked any `turn/started`/`item.*` events with a usable
          // event time; synthesize a turn span from `lastEventTime`.
          this.startTurnSpan(state, state.lastEventTime);
        }
        this.endTurnSpan(state, eventTime, state.error);
        state.completed.resolve();
        break;
      case 'error':
        if (params.willRetry === true) {
          logger.debug('[CodexAppServer] Retryable error received', {
            error: params.error?.message,
            threadId: params.threadId,
            turnId: params.turnId,
          });
          break;
        }
        state.error = params.error?.message ?? 'Codex app-server error';
        if (!state.activeTurnSpan) {
          // An error before any `turn/started`/item event should still surface
          // an errored turn span, mirroring the `turn/completed` lazy-open path.
          this.startTurnSpan(state, state.lastEventTime);
        }
        this.endTurnSpan(state, eventTime, state.error);
        state.completed.resolve();
        break;
    }

    state.lastEventTime = eventTime;
  }

  private handleItemStarted(state: CodexAppServerTurnState, item: any, eventTime: number): void {
    if (!item) {
      return;
    }
    state.itemStarts.push(item);
    if (!item.id) {
      return;
    }

    const itemId = String(item.id);
    const span = this.startItemSpan(
      item,
      itemId,
      undefined,
      state.activeTurnIndex > 0 ? state.activeTurnIndex : undefined,
    );
    state.activeSpans.set(itemId, span);
    state.itemStartTimes.set(itemId, eventTime);
  }

  private handleItemCompleted(state: CodexAppServerTurnState, item: any, eventTime: number): void {
    if (!item) {
      return;
    }

    const completedItem = this.withCommandExecutionOutput(state, item);
    if (
      completedItem?.type === 'commandExecution' &&
      typeof completedItem.id === 'string' &&
      typeof completedItem.aggregatedOutput === 'string'
    ) {
      const existingOutput = state.commandExecutionOutputDeltasByItemId.get(completedItem.id);
      if (
        typeof existingOutput !== 'string' ||
        completedItem.aggregatedOutput.startsWith(existingOutput)
      ) {
        state.commandExecutionOutputDeltasByItemId.set(
          completedItem.id,
          completedItem.aggregatedOutput,
        );
      }
    }
    state.items.push(completedItem);
    const itemId = completedItem.id ? String(completedItem.id) : crypto.randomUUID();
    const span =
      state.activeSpans.get(itemId) ??
      this.startItemSpan(
        completedItem,
        itemId,
        state.lastEventTime,
        state.activeTurnIndex > 0 ? state.activeTurnIndex : undefined,
      );
    const startTime = state.itemStartTimes.get(itemId) ?? state.lastEventTime;
    this.applyItemCompletionAttributes(span, completedItem, eventTime, startTime);
    span.end();
    state.activeSpans.delete(itemId);
    state.itemStartTimes.delete(itemId);
  }

  private handleAgentMessageDelta(state: CodexAppServerTurnState, params: any): void {
    if (typeof params.delta !== 'string') {
      return;
    }
    state.agentMessageDeltas.push(params.delta);
    if (typeof params.itemId === 'string') {
      const existing = state.agentMessageDeltasByItemId.get(params.itemId) ?? '';
      state.agentMessageDeltasByItemId.set(params.itemId, existing + params.delta);
    }
  }

  private handleCommandExecutionOutputDelta(state: CodexAppServerTurnState, params: any): void {
    if (typeof params.itemId !== 'string' || typeof params.delta !== 'string') {
      return;
    }

    const existing = state.commandExecutionOutputDeltasByItemId.get(params.itemId) ?? '';
    const aggregatedOutput = existing + params.delta;
    state.commandExecutionOutputDeltasByItemId.set(params.itemId, aggregatedOutput);

    const completedItem = state.items.find(
      (item) => item?.type === 'commandExecution' && String(item.id) === params.itemId,
    );
    if (
      completedItem &&
      (typeof completedItem.aggregatedOutput !== 'string' ||
        completedItem.aggregatedOutput === existing)
    ) {
      completedItem.aggregatedOutput = aggregatedOutput;
    }
  }

  private withCommandExecutionOutput(state: CodexAppServerTurnState, item: any): any {
    if (item?.type !== 'commandExecution' || typeof item.id !== 'string') {
      return item;
    }

    const aggregatedOutput = state.commandExecutionOutputDeltasByItemId.get(item.id);
    if (typeof aggregatedOutput !== 'string') {
      return item;
    }

    if (
      typeof item.aggregatedOutput === 'string' &&
      !aggregatedOutput.startsWith(item.aggregatedOutput)
    ) {
      return item;
    }

    return {
      ...item,
      aggregatedOutput,
    };
  }

  private async handleServerRequest(
    message: JsonRpcMessage,
    config: CodexAppServerConfig,
  ): Promise<unknown> {
    const params = message.params ?? {};
    const state = this.getTurnState(params.threadId ?? params.conversationId, params.turnId);
    if (state && !this.reserveTurnEvent(state, message)) {
      throw new Error(state.error ?? 'Codex app-server turn event limit exceeded');
    }
    const record: ServerRequestRecord = {
      id: message.id as JsonRpcId,
      method: message.method ?? 'unknown',
      params: this.sanitizeForMetadata(params),
    };

    try {
      const response = this.buildServerRequestResponse(message, state?.config ?? config);
      record.response = this.sanitizeForMetadata(response);
      state?.serverRequests.push(record);
      return response;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      record.error = errorMessage;
      state?.serverRequests.push(record);
      throw error;
    }
  }

  private reserveTurnEvent(state: CodexAppServerTurnState, message: JsonRpcMessage): boolean {
    state.bufferedEventChars += JSON.stringify(message).length;
    if (state.bufferedEventChars <= MAX_BUFFERED_TURN_EVENT_CHARS) {
      return true;
    }

    state.error = `codex app-server turn events exceeded ${MAX_BUFFERED_TURN_EVENT_CHARS} characters`;
    this.handleConnectionClose(
      state.connectionKey,
      state.connectionInstanceId,
      new Error(state.error),
    );
    void state.connection.close();
    return false;
  }

  private buildServerRequestResponse(
    message: JsonRpcMessage,
    config: CodexAppServerConfig,
  ): unknown {
    const policy = config.server_request_policy ?? {};

    switch (message.method) {
      case 'item/commandExecution/requestApproval':
        return { decision: policy.command_execution ?? 'decline' };
      case 'execCommandApproval':
        return this.buildLegacyApprovalResponse(policy.command_execution);
      case 'item/fileChange/requestApproval':
        return { decision: policy.file_change ?? 'decline' };
      case 'applyPatchApproval':
        return this.buildLegacyApprovalResponse(policy.file_change);
      case 'item/permissions/requestApproval':
        return {
          permissions: policy.permissions?.permissions ?? {},
          scope: policy.permissions?.scope ?? 'turn',
          ...(policy.permissions?.strict_auto_review === undefined
            ? {}
            : { strictAutoReview: policy.permissions.strict_auto_review }),
        };
      case 'item/tool/requestUserInput':
        return this.buildUserInputResponse(message.params, policy.user_input ?? 'empty');
      case 'mcpServer/elicitation/request':
        return this.buildMcpElicitationResponse(policy.mcp_elicitation);
      case 'item/tool/call':
        return this.buildDynamicToolResponse(message.params, policy.dynamic_tools);
      case 'account/chatgptAuthTokens/refresh':
        throw new Error('ChatGPT auth token refresh requests are not supported by promptfoo');
      default:
        throw new Error(`Unsupported codex app-server request: ${message.method ?? 'unknown'}`);
    }
  }

  private buildLegacyApprovalResponse(
    decision:
      | CodexAppServerCommandExecutionApprovalDecision
      | CodexAppServerFileChangeApprovalDecision = 'decline',
  ): { decision: string } {
    if (typeof decision !== 'string') {
      return { decision: 'denied' };
    }

    switch (decision) {
      case 'accept':
        return { decision: 'approved' };
      case 'acceptForSession':
        return { decision: 'approved_for_session' };
      case 'cancel':
        return { decision: 'abort' };
      case 'decline':
        return { decision: 'denied' };
    }
  }

  private buildMcpElicitationResponse(policy: CodexAppServerMcpElicitationPolicy = 'decline'): {
    action: 'accept' | 'decline' | 'cancel';
    content: unknown;
    _meta: unknown;
  } {
    if (typeof policy === 'string') {
      return { action: policy, content: null, _meta: null };
    }

    return {
      action: policy.action,
      content: policy.content ?? null,
      _meta: policy._meta ?? null,
    };
  }

  private buildUserInputResponse(
    params: any,
    policy: CodexAppServerUserInputPolicy,
  ): { answers: Record<string, { answers: string[] }> } {
    const answers = Object.create(null) as Record<string, { answers: string[] }>;
    const questions = Array.isArray(params?.questions) ? params.questions : [];

    for (const question of questions) {
      if (!question?.id || typeof question.id !== 'string') {
        continue;
      }

      if (policy === 'empty') {
        answers[question.id] = { answers: [] };
        continue;
      }

      if (policy === 'first-option') {
        const firstLabel =
          Array.isArray(question.options) && typeof question.options[0]?.label === 'string'
            ? question.options[0].label
            : '';
        answers[question.id] = { answers: firstLabel ? [firstLabel] : [] };
        continue;
      }

      const configuredAnswer = Object.prototype.hasOwnProperty.call(policy, question.id)
        ? policy[question.id]
        : undefined;
      answers[question.id] = {
        answers: Array.isArray(configuredAnswer)
          ? configuredAnswer
          : configuredAnswer
            ? [configuredAnswer]
            : [],
      };
    }

    return { answers };
  }

  private buildDynamicToolResponse(
    params: any,
    tools: Record<string, CodexAppServerDynamicToolResponse> | undefined,
  ): {
    contentItems: Array<
      { type: 'inputText'; text: string } | { type: 'inputImage'; imageUrl: string }
    >;
    success: boolean;
  } {
    const configured =
      typeof params?.tool === 'string' &&
      tools &&
      Object.prototype.hasOwnProperty.call(tools, params.tool)
        ? tools[params.tool]
        : undefined;
    if (!configured) {
      return {
        contentItems: [{ type: 'inputText', text: 'No dynamic tool response configured.' }],
        success: false,
      };
    }

    return {
      contentItems: configured.contentItems ?? [{ type: 'inputText', text: configured.text ?? '' }],
      success: configured.success ?? true,
    };
  }

  private async waitForTurnCompletion(
    connection: CodexAppServerConnection,
    state: CodexAppServerTurnState,
    config: CodexAppServerConfig,
    callOptions?: CallApiOptionsParams,
  ): Promise<void> {
    const interruptTurn = () => {
      if (!state.turnId) {
        return;
      }
      void connection
        .request(
          'turn/interrupt',
          { threadId: state.threadId, turnId: state.turnId },
          { timeoutMs: 5_000 },
        )
        .catch((error) => {
          logger.debug('[CodexAppServer] Error interrupting turn', { error });
        });
    };
    let timeout: NodeJS.Timeout | undefined;
    let abortListener: (() => void) | undefined;

    const timeoutPromise = config.turn_timeout_ms
      ? new Promise<void>((_, reject) => {
          timeout = setTimeout(() => {
            interruptTurn();
            reject(new Error(`codex app-server turn timed out after ${config.turn_timeout_ms}ms`));
          }, config.turn_timeout_ms);
        })
      : undefined;

    const abortPromise = callOptions?.abortSignal
      ? new Promise<void>((_, reject) => {
          abortListener = () => {
            interruptTurn();
            reject(createAbortError('OpenAI Codex app-server call aborted'));
          };
          callOptions.abortSignal?.addEventListener('abort', abortListener, { once: true });
        })
      : undefined;

    try {
      await Promise.race(
        [state.completed.promise, timeoutPromise, abortPromise].filter(
          (promise): promise is Promise<void> => Boolean(promise),
        ),
      );
    } finally {
      if (timeout) {
        clearTimeout(timeout);
      }
      if (abortListener && callOptions?.abortSignal) {
        callOptions.abortSignal.removeEventListener('abort', abortListener);
      }
    }

    if (state.error) {
      throw new Error(state.error);
    }
  }

  private async cleanupThreadAfterTurn(
    connection: CodexAppServerConnection,
    threadHandle: ThreadHandle,
    config: CodexAppServerConfig,
    options: { skipIfActiveTurn?: boolean; skipIfProtected?: boolean } = {},
  ): Promise<void> {
    if (threadHandle.persistent || config.thread_cleanup === 'none') {
      return;
    }
    if (options.skipIfProtected && this.isThreadProtected(threadHandle.threadId)) {
      return;
    }
    if (options.skipIfActiveTurn && this.activeTurnsByThread.has(threadHandle.threadId)) {
      return;
    }
    if (config.thread_id && (this.protectedThreadCounts.get(threadHandle.threadId) ?? 0) > 1) {
      return;
    }
    if (config.thread_id && config.thread_cleanup === 'archive') {
      return;
    }

    try {
      if (config.thread_cleanup === 'archive') {
        await connection.request(
          'thread/archive',
          { threadId: threadHandle.threadId },
          { timeoutMs: this.getRequestTimeoutMs(config) },
        );
      } else {
        await connection.request(
          'thread/unsubscribe',
          { threadId: threadHandle.threadId },
          { timeoutMs: this.getRequestTimeoutMs(config) },
        );
      }
    } catch (error) {
      logger.warn('[CodexAppServer] Error cleaning up thread after turn', {
        threadId: threadHandle.threadId,
        error,
      });
    }
  }

  private getThreadRunQueueKey(
    config: CodexAppServerConfig,
    threadHandle: ThreadHandle,
  ): string | undefined {
    if (config.thread_id) {
      return `thread_id:${threadHandle.threadId}`;
    }
    if (config.deep_tracing) {
      return undefined;
    }
    if (threadHandle.persistent && threadHandle.cacheKey) {
      return threadHandle.cacheKey;
    }
    return undefined;
  }

  private async runSerializedThreadTurn<T>(
    queueKey: string | undefined,
    abortSignal: AbortSignal | undefined,
    executeTurn: () => Promise<T>,
  ): Promise<T> {
    if (!queueKey) {
      return executeTurn();
    }

    const previousRun = this.threadRunQueues.get(queueKey) ?? Promise.resolve();
    let releaseCurrentRun: () => void = () => {};
    const currentRun = new Promise<void>((resolve) => {
      releaseCurrentRun = resolve;
    });
    const queuedRun = previousRun.catch(() => undefined).then(() => currentRun);
    this.threadRunQueues.set(queueKey, queuedRun);
    void queuedRun.finally(() => {
      if (this.threadRunQueues.get(queueKey) === queuedRun) {
        this.threadRunQueues.delete(queueKey);
      }
    });

    try {
      await this.waitForPreviousThreadRun(previousRun, abortSignal);
      return await executeTurn();
    } finally {
      releaseCurrentRun();
    }
  }

  private async waitForPreviousThreadRun(
    previousRun: Promise<void>,
    abortSignal: AbortSignal | undefined,
  ): Promise<void> {
    const previousRunDone = previousRun.catch(() => undefined);
    if (!abortSignal) {
      await previousRunDone;
      return;
    }
    if (abortSignal.aborted) {
      throw createAbortError('Codex app-server thread turn wait aborted');
    }

    let onAbort: (() => void) | undefined;
    const abortPromise = new Promise<void>((_, reject) => {
      onAbort = () => reject(createAbortError('Codex app-server thread turn wait aborted'));
      abortSignal.addEventListener('abort', onAbort, { once: true });
    });

    try {
      await Promise.race([previousRunDone, abortPromise]);
    } finally {
      if (onAbort) {
        abortSignal.removeEventListener('abort', onAbort);
      }
    }
  }

  private buildProviderResponse(
    state: CodexAppServerTurnState,
    threadHandle: ThreadHandle,
    config: CodexAppServerConfig,
  ): ProviderResponse {
    const output = this.getFinalOutput(state);
    const normalizedItems = state.items.map((item) => this.normalizeItemForMetadata(item));
    const rawItems = state.items.map((item) => this.normalizeItemForRaw(item));
    const rawTokenUsage = this.sanitizeForMetadata(state.rawTokenUsage);
    const raw = {
      finalResponse: output,
      output,
      thread: this.sanitizeForMetadata(threadHandle.response?.thread),
      turn: this.sanitizeForMetadata(state.turn),
      items: rawItems,
      usage: this.buildSdkUsage(state.rawTokenUsage),
      tokenUsage: rawTokenUsage,
      serverRequests: state.serverRequests,
      ...(config.include_raw_events
        ? { notifications: this.sanitizeForMetadata(state.notifications) }
        : {}),
    };
    const metadata = this.buildResponseMetadata(state, threadHandle, config, normalizedItems);

    return {
      output,
      tokenUsage: state.tokenUsage,
      cost: this.calculateResponseCost(state.tokenUsage, config.model),
      metadata,
      raw: JSON.stringify(raw),
      sessionId: threadHandle.threadId,
    };
  }

  private getFinalOutput(state: CodexAppServerTurnState): string {
    const completedAgentMessages = state.items
      .filter((item) => item?.type === 'agentMessage' && typeof item.text === 'string')
      .map((item) => item.text);

    if (completedAgentMessages.length > 0) {
      return completedAgentMessages[completedAgentMessages.length - 1];
    }

    const deltaMessages = Array.from(state.agentMessageDeltasByItemId.values()).filter(Boolean);
    if (deltaMessages.length > 0) {
      return deltaMessages[deltaMessages.length - 1];
    }

    return state.agentMessageDeltas.join('');
  }

  private buildResponseMetadata(
    state: CodexAppServerTurnState,
    threadHandle: ThreadHandle,
    config: CodexAppServerConfig,
    normalizedItems: Record<string, unknown>[],
  ): ProviderResponse['metadata'] {
    const skillMetadata = this.buildSkillMetadata(
      state.items,
      this.getSkillRootPrefixes(config, state.appServerEnv),
    );
    return {
      codexAppServer: {
        threadId: threadHandle.threadId,
        turnId: state.turnId,
        model: config.model,
        modelProvider: config.model_provider,
        cwd: config.working_dir,
        sandboxMode: config.sandbox_mode ?? 'read-only',
        approvalPolicy: config.approval_policy ?? 'never',
        itemCounts: this.getItemCounts(state.items),
        items: normalizedItems,
        serverRequests: state.serverRequests,
        notificationCount: state.notificationCount,
      },
      ...getCodexSkillMetadataFields(skillMetadata),
    };
  }

  private normalizeItemForMetadata(item: any): Record<string, unknown> {
    const base: Record<string, unknown> = {
      id: item?.id,
      type: item?.type,
      status: item?.status,
    };

    switch (item?.type) {
      case 'commandExecution':
        return this.sanitizeForMetadata({
          ...base,
          command: item.command,
          cwd: item.cwd,
          exitCode: item.exitCode,
          durationMs: item.durationMs,
          aggregatedOutput: item.aggregatedOutput,
        }) as Record<string, unknown>;
      case 'fileChange':
        return this.sanitizeForMetadata({
          ...base,
          changes: item.changes,
        }) as Record<string, unknown>;
      case 'mcpToolCall':
        return this.sanitizeForMetadata({
          ...base,
          server: item.server,
          tool: item.tool,
          arguments: item.arguments,
          result: item.result,
          error: item.error,
          durationMs: item.durationMs,
        }) as Record<string, unknown>;
      case 'dynamicToolCall':
        return this.sanitizeForMetadata({
          ...base,
          tool: item.tool,
          arguments: item.arguments,
          success: item.success,
          contentItems: item.contentItems,
          durationMs: item.durationMs,
        }) as Record<string, unknown>;
      case 'webSearch':
        return this.sanitizeForMetadata({
          ...base,
          query: item.query,
          action: item.action,
        }) as Record<string, unknown>;
      case 'agentMessage':
        return this.sanitizeForMetadata({ ...base, text: item.text }) as Record<string, unknown>;
      case 'reasoning':
        return this.sanitizeForMetadata({
          ...base,
          summary: item.summary,
          content: item.content,
        }) as Record<string, unknown>;
      default:
        return this.sanitizeForMetadata(base) as Record<string, unknown>;
    }
  }

  private normalizeItemForRaw(item: any): Record<string, unknown> {
    const base: Record<string, unknown> = {
      id: item?.id,
      type: item?.type,
      status: item?.status,
    };

    switch (item?.type) {
      case 'commandExecution':
        return this.sanitizeForMetadata({
          ...base,
          type: 'command_execution',
          command: item.command,
          cwd: item.cwd,
          exit_code: item.exitCode,
          duration_ms: item.durationMs,
          aggregated_output: item.aggregatedOutput,
        }) as Record<string, unknown>;
      case 'fileChange':
        return this.sanitizeForMetadata({
          ...base,
          type: 'file_change',
          changes: item.changes,
        }) as Record<string, unknown>;
      case 'mcpToolCall':
        return this.sanitizeForMetadata({
          ...base,
          type: 'mcp_tool_call',
          server: item.server,
          tool: item.tool,
          arguments: item.arguments,
          result: item.result,
          error: item.error,
          duration_ms: item.durationMs,
        }) as Record<string, unknown>;
      case 'dynamicToolCall':
        return this.sanitizeForMetadata({
          ...base,
          type: 'dynamic_tool_call',
          tool: item.tool,
          arguments: item.arguments,
          success: item.success,
          content_items: item.contentItems,
          duration_ms: item.durationMs,
        }) as Record<string, unknown>;
      case 'webSearch':
        return this.sanitizeForMetadata({
          ...base,
          type: 'web_search',
          query: item.query,
          action: item.action,
        }) as Record<string, unknown>;
      case 'agentMessage':
        return this.sanitizeForMetadata({
          ...base,
          type: 'agent_message',
          text: item.text,
        }) as Record<string, unknown>;
      case 'reasoning':
        return this.sanitizeForMetadata({
          ...base,
          type: 'reasoning',
          text: this.extractReasoningText(item),
          summary: item.summary,
          content: item.content,
        }) as Record<string, unknown>;
      case 'todoList':
        return this.sanitizeForMetadata({
          ...base,
          type: 'todo_list',
          items: item.items,
        }) as Record<string, unknown>;
      case 'error':
        return this.sanitizeForMetadata({
          ...base,
          type: 'error',
          message: item.message,
        }) as Record<string, unknown>;
      case 'userMessage':
        return this.sanitizeForMetadata({
          ...base,
          type: 'user_message',
          content: item.content,
        }) as Record<string, unknown>;
      default:
        return this.sanitizeForMetadata(base) as Record<string, unknown>;
    }
  }

  private extractReasoningText(item: any): string | undefined {
    if (typeof item?.text === 'string') {
      return item.text;
    }
    const blocks = [item?.summary, item?.content].find(Array.isArray) as unknown[] | undefined;
    if (!blocks) {
      return undefined;
    }
    const parts = blocks.flatMap((block) => {
      if (typeof block === 'string') {
        return [block];
      }
      const text = (block as { text?: unknown } | null)?.text;
      return typeof text === 'string' && text.length > 0 ? [text] : [];
    });
    return parts.length > 0 ? parts.join('\n') : undefined;
  }

  private resolveRawUsage(rawTokenUsage: any):
    | {
        input: number;
        output: number;
        cached: number;
        reasoning: number;
      }
    | undefined {
    const usage = rawTokenUsage?.last ?? rawTokenUsage?.total ?? rawTokenUsage;
    if (!usage) {
      return undefined;
    }
    const input = usage.inputTokens ?? usage.input_tokens;
    const output = usage.outputTokens ?? usage.output_tokens;
    if (typeof input !== 'number' || typeof output !== 'number') {
      return undefined;
    }
    return {
      input,
      output,
      cached: usage.cachedInputTokens ?? usage.cached_input_tokens ?? 0,
      reasoning: usage.reasoningOutputTokens ?? usage.reasoning_output_tokens ?? 0,
    };
  }

  private buildSdkUsage(rawTokenUsage: any): CodexSdkUsage | undefined {
    const usage = this.resolveRawUsage(rawTokenUsage);
    if (!usage) {
      return undefined;
    }
    return {
      input_tokens: usage.input,
      cached_input_tokens: usage.cached,
      output_tokens: usage.output,
      reasoning_output_tokens: usage.reasoning,
    };
  }

  private buildTokenUsage(rawTokenUsage: any): ProviderResponse['tokenUsage'] {
    const usage = this.resolveRawUsage(rawTokenUsage);
    if (!usage) {
      return undefined;
    }
    return {
      prompt: usage.input,
      completion: usage.output,
      total: usage.input + usage.output,
      cached: usage.cached,
    };
  }

  private calculateResponseCost(
    tokenUsage: ProviderResponse['tokenUsage'],
    model: string | undefined,
  ): number | undefined {
    return calculateOpenAIUsageCostFromTokenUsage(model, tokenUsage);
  }

  private getItemCounts(items: any[]): Record<string, number> {
    const counts: Record<string, number> = {};
    for (const item of items) {
      const type = typeof item?.type === 'string' ? item.type : 'unknown';
      counts[type] = (counts[type] ?? 0) + 1;
    }
    return counts;
  }

  private validateWorkingDirectory(workingDir: string, skipGitCheck = false): void {
    const cacheKey = `${workingDir}:${skipGitCheck}`;
    if (this.validatedWorkingDirs.has(cacheKey)) {
      return;
    }

    let stats: fs.Stats;
    try {
      stats = fs.statSync(workingDir);
    } catch (err: any) {
      throw new Error(
        `Working directory ${workingDir} does not exist or isn't accessible: ${err.message}`,
      );
    }

    if (!stats.isDirectory()) {
      throw new Error(`Working directory ${workingDir} is not a directory`);
    }

    if (!skipGitCheck && !this.isInsideGitRepository(workingDir)) {
      throw new Error(
        dedent`Working directory ${workingDir} is not inside a Git repository.

        Codex app-server requires a Git repository by default to prevent unrecoverable errors.

        To bypass this check, set skip_git_repo_check: true in your provider config.`,
      );
    }

    this.validatedWorkingDirs.add(cacheKey);
  }

  private isInsideGitRepository(workingDir: string): boolean {
    return this.findGitRepositoryRoot(workingDir) !== undefined;
  }

  private findGitRepositoryRoot(workingDir: string): string | undefined {
    let currentDir = path.resolve(workingDir);
    while (true) {
      if (fs.existsSync(path.join(currentDir, '.git'))) {
        return currentDir;
      }
      const parentDir = path.dirname(currentDir);
      if (parentDir === currentDir) {
        return undefined;
      }
      currentDir = parentDir;
    }
  }

  private warnOnceForDeepTracingThreadOptions(config: CodexAppServerConfig): void {
    if (
      !config.deep_tracing ||
      this.deepTracingWarningShown ||
      (!config.persist_threads && (config.thread_pool_size ?? 0) <= 1)
    ) {
      return;
    }

    logger.warn(
      '[CodexAppServer] deep_tracing requires a fresh app-server process per call. ' +
        'Persistent thread pooling options (persist_threads, thread_pool_size) are ignored when deep_tracing is enabled. ' +
        'Explicit thread_id values are still resumed and serialized.',
    );
    this.deepTracingWarningShown = true;
  }

  private startItemSpan(item: any, itemId: string, startTime?: number, turnIndex?: number): Span {
    return trace.getTracer('promptfoo.codex-app-server').startSpan(this.getSpanNameForItem(item), {
      kind: SpanKind.INTERNAL,
      ...(startTime === undefined ? {} : { startTime }),
      attributes: addActiveSpanRoleAttribute({
        'codex.app_server.item.id': itemId,
        'codex.app_server.item.type': item?.type ?? 'unknown',
        ...(typeof turnIndex === 'number' ? { 'gen_ai.turn.index': turnIndex } : {}),
        ...this.getAttributesForItem(item),
      }),
    });
  }

  private startTurnSpan(
    state: CodexAppServerTurnState,
    eventTime: number,
    clearPreviousUsage = false,
  ): void {
    if (clearPreviousUsage && state.turnCount > 0) {
      // Usage is associated with the active protocol turn. Do not attribute the
      // previous turn's most recent update when an explicit later turn starts.
      // Lazy-open paths may run after usage for their current turn arrived.
      //
      // Guard on a prior turn existing (turnCount > 0): on the very first
      // `turn/started`, usage from an earlier `thread/tokenUsage/updated` belongs
      // to THIS turn, so clearing it would drop token counts and cost from the
      // final response.
      state.rawTokenUsage = undefined;
      state.tokenUsage = undefined;
    }
    openTurnSpan(state, {
      tracer: trace.getTracer('promptfoo.codex-app-server'),
      eventTime,
      system: 'openai',
      logLabel: 'CodexAppServer',
    });
  }

  private endTurnSpan(
    state: CodexAppServerTurnState,
    eventTime: number,
    errorMessage?: string,
  ): void {
    // Codex app-server typically delivers usage under `last`/`total`; reuse
    // the shared resolver so we honor both nested and flat shapes.
    const usage = this.resolveRawUsage(state.rawTokenUsage);
    const attributes: Attributes = {};
    if (usage) {
      attributes['gen_ai.usage.input_tokens'] = usage.input;
      attributes['gen_ai.usage.output_tokens'] = usage.output;
      if (usage.cached) {
        attributes[GenAIAttributes.USAGE_CACHE_READ_INPUT_TOKENS] = usage.cached;
      }
      if (usage.reasoning) {
        attributes[GenAIAttributes.USAGE_REASONING_OUTPUT_TOKENS] = usage.reasoning;
      }
    }
    closeTurnSpan(state, { eventTime, attributes, errorMessage, logLabel: 'CodexAppServer' });
  }

  private applyItemCompletionAttributes(
    span: Span,
    item: any,
    eventTime: number,
    startTime: number,
  ): void {
    for (const [key, value] of Object.entries(this.getCompletionAttributesForItem(item))) {
      span.setAttribute(key, value);
    }
    span.setAttribute('codex.app_server.duration_ms', eventTime - startTime);
    if (this.isItemError(item)) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: this.getItemErrorMessage(item) });
    } else {
      span.setStatus({ code: SpanStatusCode.OK });
    }
  }

  private endUnclosedItemSpans(state: CodexAppServerTurnState): void {
    for (const [itemId, span] of state.activeSpans) {
      logger.warn('[CodexAppServer] Item span not properly closed', { itemId });
      span.setStatus({ code: SpanStatusCode.ERROR, message: 'Span not properly closed' });
      span.end();
    }
    state.activeSpans.clear();
    state.itemStartTimes.clear();
    if (state.activeTurnSpan) {
      logger.warn('[CodexAppServer] Turn span not properly closed');
      closeTurnSpan(state, {
        errorMessage: 'Turn span not properly closed',
        logLabel: 'CodexAppServer',
      });
    }
  }

  private getSpanNameForItem(item: any): string {
    switch (item?.type) {
      case 'commandExecution': {
        const cmd =
          typeof item.command === 'string' ? item.command.split(' ')[0] || 'command' : 'command';
        return `exec ${cmd}`;
      }
      case 'fileChange':
        return 'file change';
      case 'mcpToolCall':
        return `mcp ${item.server ?? 'unknown'}/${item.tool ?? 'unknown'}`;
      case 'dynamicToolCall':
        return `tool ${item.tool ?? 'unknown'}`;
      case 'agentMessage':
        return 'agent response';
      case 'reasoning':
        return 'reasoning';
      case 'webSearch':
        return 'web search';
      default:
        return `codex.app_server.${item?.type ?? 'unknown'}`;
    }
  }

  private getAttributesForItem(item: any): Record<string, string | number | boolean> {
    const attrs: Record<string, string | number | boolean> = {};
    if (item?.type === 'commandExecution' && typeof item.command === 'string') {
      attrs['codex.command'] =
        this.sanitizeTraceText(item.command, 'Codex app-server command trace attribute') ?? '';
    }
    if (item?.type === 'mcpToolCall') {
      if (typeof item.server === 'string') {
        attrs['codex.mcp.server'] = item.server;
      }
      if (typeof item.tool === 'string') {
        attrs['gen_ai.operation.name'] = 'execute_tool';
        attrs['gen_ai.tool.name'] = item.tool;
        attrs['codex.mcp.tool'] = item.tool;
      }
    }
    if (item?.type === 'dynamicToolCall' && typeof item.tool === 'string') {
      attrs['gen_ai.operation.name'] = 'execute_tool';
      attrs['gen_ai.tool.name'] = item.tool;
      attrs['codex.tool.name'] = item.tool;
    }
    if (item?.type === 'webSearch' && typeof item.query === 'string') {
      attrs['codex.search.query'] =
        this.sanitizeTraceText(item.query, 'Codex app-server web search trace attribute') ?? '';
    }
    return attrs;
  }

  private getCompletionAttributesForItem(item: any): Record<string, string | number | boolean> {
    const attrs: Record<string, string | number | boolean> = {};
    if (typeof item?.status === 'string') {
      attrs['codex.status'] = item.status;
    }
    if (item?.type === 'commandExecution') {
      if (typeof item.exitCode === 'number') {
        attrs['codex.exit_code'] = item.exitCode;
      }
      if (typeof item.aggregatedOutput === 'string') {
        attrs['codex.output'] =
          this.sanitizeTraceText(
            item.aggregatedOutput,
            'Codex app-server command output trace attribute',
          ) ?? '';
      }
    }
    if (item?.type === 'agentMessage' && typeof item.text === 'string') {
      attrs['codex.message'] =
        this.sanitizeTraceText(item.text, 'Codex app-server message trace attribute') ?? '';
    }
    return attrs;
  }

  private isItemError(item: any): boolean {
    return (
      item?.status === 'failed' ||
      item?.status === 'declined' ||
      item?.error !== undefined ||
      (item?.type === 'commandExecution' &&
        typeof item.exitCode === 'number' &&
        item.exitCode !== 0)
    );
  }

  private getItemErrorMessage(item: any): string {
    return (
      (typeof item?.error?.message === 'string' ? item.error.message : null) ||
      (item?.type === 'commandExecution' && item.exitCode !== 0
        ? `Command exited with code ${item.exitCode}`
        : null) ||
      'Item failed'
    );
  }

  private getSkillRootPrefixes(
    config: CodexAppServerConfig,
    appServerEnv: Record<string, string>,
  ): string[] {
    const resolvedWorkingDir = config.working_dir
      ? path.resolve(config.working_dir).replace(/\\/g, '/')
      : undefined;

    return getCodexSkillRootPrefixes({
      codexHome: appServerEnv.CODEX_HOME,
      gitRepositoryRoot: resolvedWorkingDir
        ? this.findGitRepositoryRoot(resolvedWorkingDir)
        : undefined,
      homeDir: appServerEnv.HOME || appServerEnv.USERPROFILE,
      workingDir: resolvedWorkingDir,
    });
  }

  private buildSkillMetadata(items: any[], skillRootPrefixes: readonly string[]) {
    return buildCodexSkillMetadata(items, skillRootPrefixes, {
      getCommand: (item: any) =>
        item?.type === 'commandExecution' && typeof item.command === 'string' && item.command.trim()
          ? item.command
          : undefined,
      isSuccessfulCommand: (item: any) => this.isSuccessfulCommandExecution(item),
    });
  }

  private isSuccessfulCommandExecution(item: any): boolean {
    if (item?.type !== 'commandExecution') {
      return false;
    }
    if (typeof item.status === 'string' && item.status !== 'completed') {
      return false;
    }
    if (typeof item.exitCode === 'number' && item.exitCode !== 0) {
      return false;
    }
    return true;
  }

  private sanitizeTraceText(value: string, context: string): string | undefined {
    const sanitized = this.redactTracePii(sanitizeObject(value, { context }));
    if (typeof sanitized === 'string') {
      return sanitized;
    }
    if (sanitized === undefined || sanitized === null) {
      return undefined;
    }
    try {
      return JSON.stringify(sanitized);
    } catch (error) {
      logger.debug('[CodexAppServer] Failed to stringify sanitized trace text', { error });
      return undefined;
    }
  }

  private sanitizeForMetadata(value: unknown): unknown {
    return this.redactTracePii(sanitizeObject(value, { context: 'Codex app-server metadata' }));
  }

  private redactTracePii(value: unknown): unknown {
    if (typeof value === 'string') {
      return redactAppServerText(value);
    }

    if (Array.isArray(value)) {
      return value.map((item) => this.redactTracePii(item));
    }

    if (value && typeof value === 'object') {
      return Object.fromEntries(
        Object.entries(value as Record<string, unknown>).map(([key, entryValue]) => [
          key,
          normalizeFieldName(key).includes('email') ? REDACTED : this.redactTracePii(entryValue),
        ]),
      );
    }

    return value;
  }
}
