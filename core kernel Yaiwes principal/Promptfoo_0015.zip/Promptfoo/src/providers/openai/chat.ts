import { fetchWithCache } from '../../cache';
import { getEnvFloat, getEnvInt, getEnvString } from '../../envars';
import logger from '../../logger';
import { formatRateLimitErrorMessage, HttpRateLimitError } from '../../util/fetch/errors';
import { FINISH_REASON_MAP, normalizeFinishReason } from '../../util/finishReason';
import {
  maybeLoadFromExternalFileWithVars,
  maybeLoadResponseFormatFromExternalFile,
  maybeLoadToolsFromExternalFile,
  renderVarsInObject,
} from '../../util/index';
import {
  executeProviderFunctionCallback,
  loadProviderCallbackFromFileUrl,
} from '../functionCallbackUtils';
import { MCPClient } from '../mcp/client';
import { transformMCPToolsToOpenAi } from '../mcp/transform';
import { getMcpErrorMessage, isMcpErrorResult } from '../mcp/util';
import {
  getRequestTimeoutMs,
  parseChatPrompt,
  transformToolChoice,
  transformTools,
} from '../shared';
import {
  extractProviderResponseAttributes,
  type GenAISpanContext,
  withGenAISpan,
} from '../tracing';
import { OpenAiGenericProvider } from './';
import { calculateOpenAIUsageCost } from './billing';
import {
  appendOpenAiApiPath,
  assertOpenAiApiModel,
  getTokenUsage,
  OPENAI_CHAT_MODELS,
  validateFunctionCall,
} from './util';
import type OpenAI from 'openai';

import type { EnvOverrides } from '../../types/env';
import type {
  CallApiContextParams,
  CallApiOptionsParams,
  ProviderResponse,
} from '../../types/index';
import type { OpenAiCompletionOptions, ReasoningEffort } from './types';

export type OpenAiChatCompletionCostData = Pick<
  OpenAI.Chat.Completions.ChatCompletion,
  'service_tier' | 'usage'
>;

function getChatSearchCitations(
  annotations: unknown,
  output: unknown,
): Array<{ url: string; content: string }> {
  if (!Array.isArray(annotations)) {
    return [];
  }

  return annotations.flatMap((annotation) => {
    const citation = annotation?.type === 'url_citation' ? annotation.url_citation : undefined;
    if (typeof citation?.url !== 'string' || !/^https?:\/\//i.test(citation.url)) {
      return [];
    }

    const excerpt =
      typeof output === 'string' &&
      Number.isInteger(citation.start_index) &&
      Number.isInteger(citation.end_index)
        ? output.slice(citation.start_index, citation.end_index + 1).trim()
        : '';
    const title = typeof citation.title === 'string' ? citation.title.trim() : '';

    return [
      { url: citation.url, content: [title, excerpt].filter(Boolean).join(': ') || citation.url },
    ];
  });
}

function getChatSearchSurcharge(modelName: string): number {
  if (/(?:^|\/)gpt-5-search-api(?:-|$)/.test(modelName)) {
    return 0.01;
  }
  if (/(?:^|\/)gpt-4o(?:-mini)?-search-preview(?:-|$)/.test(modelName)) {
    return 0.025;
  }
  return 0;
}

export class OpenAiChatCompletionProvider extends OpenAiGenericProvider {
  static OPENAI_CHAT_MODELS = OPENAI_CHAT_MODELS;

  static OPENAI_CHAT_MODEL_NAMES = OPENAI_CHAT_MODELS.map((model) => model.id);

  config: OpenAiCompletionOptions;
  private mcpClient: MCPClient | null = null;
  private initializationPromise: Promise<void> | null = null;
  private loadedFunctionCallbacks: Record<string, Function> = {};

  constructor(
    modelName: string,
    options: { config?: OpenAiCompletionOptions; id?: string; env?: EnvOverrides } = {},
  ) {
    if (!OpenAiChatCompletionProvider.OPENAI_CHAT_MODEL_NAMES.includes(modelName)) {
      logger.debug(`Using unknown chat model: ${modelName}`);
    }
    super(modelName, options);
    this.config = options.config ? { ...options.config } : {};

    if (this.config.mcp?.enabled) {
      this.initializationPromise = this.initializeMCP();
    }
  }

  validateFunctionToolCall(output: string | object, vars?: CallApiContextParams['vars']): void {
    validateFunctionCall(output, this.config.functions, vars);
  }

  private async initializeMCP(): Promise<void> {
    this.mcpClient = new MCPClient(this.config.mcp!);
    await this.mcpClient.initialize();
  }

  async cleanup(): Promise<void> {
    if (this.mcpClient) {
      await this.initializationPromise;
      await this.mcpClient.cleanup();
      this.mcpClient = null;
    }
  }

  /**
   * Loads a function from an external file
   * @param fileRef The file reference in the format 'file://path/to/file:functionName'
   * @returns The loaded function
   */
  private async loadExternalFunction(fileRef: string): Promise<Function> {
    return loadProviderCallbackFromFileUrl(fileRef);
  }

  /**
   * Executes a function callback with proper error handling
   */
  private async executeFunctionCallback(
    functionName: string,
    args: string,
    config: OpenAiCompletionOptions,
    callId?: string,
  ): Promise<string> {
    return executeProviderFunctionCallback({
      functionName,
      args,
      callId,
      callbacks: config.functionToolCallbacks,
      cache: this.loadedFunctionCallbacks,
    });
  }

  async getOpenAiBody(
    prompt: string,
    context?: CallApiContextParams,
    callApiOptions?: CallApiOptionsParams,
  ) {
    // Merge configs from the provider and the prompt
    const config = {
      ...this.config,
      ...context?.prompt?.config,
    };

    const messages = parseChatPrompt(prompt, [{ role: 'user', content: prompt }]);

    const passthroughModel =
      typeof config.passthrough?.model === 'string' ? config.passthrough.model : undefined;
    const capabilityModelName = (passthroughModel ?? this.getCapabilityModelName()).replace(
      /(^|\/)ft:/,
      '$1',
    );
    const isGPT5Model =
      this.isGPT5Model() ||
      capabilityModelName.startsWith('gpt-5') ||
      capabilityModelName.includes('/gpt-5');
    const isOSeriesModel =
      capabilityModelName.startsWith('o1') ||
      capabilityModelName.startsWith('o3') ||
      capabilityModelName.startsWith('o4') ||
      capabilityModelName.includes('/o1') ||
      capabilityModelName.includes('/o3') ||
      capabilityModelName.includes('/o4');
    const isPassthroughReasoningModel =
      passthroughModel !== undefined && (isGPT5Model || isOSeriesModel);
    const isReasoningModel = this.isReasoningModel() || isGPT5Model || isOSeriesModel;
    const maxCompletionTokens = isReasoningModel
      ? (config.max_completion_tokens ?? getEnvInt('OPENAI_MAX_COMPLETION_TOKENS'))
      : undefined;
    const maxTokensDefault = config.omitDefaults
      ? getEnvString('OPENAI_MAX_TOKENS') === undefined
        ? undefined
        : getEnvInt('OPENAI_MAX_TOKENS')
      : getEnvInt('OPENAI_MAX_TOKENS', 1024);
    const maxTokens =
      isReasoningModel || isGPT5Model ? undefined : (config.max_tokens ?? maxTokensDefault);

    const temperatureDefault = config.omitDefaults
      ? getEnvString('OPENAI_TEMPERATURE') === undefined
        ? undefined
        : getEnvFloat('OPENAI_TEMPERATURE')
      : getEnvFloat('OPENAI_TEMPERATURE', 0);
    const temperature =
      this.supportsTemperature() && !isPassthroughReasoningModel
        ? (config.temperature ?? temperatureDefault)
        : undefined;
    const reasoningEffort = isReasoningModel
      ? (renderVarsInObject(config.reasoning_effort, context?.vars) as ReasoningEffort)
      : undefined;

    // --- MCP tool injection logic ---
    const mcpTools = this.mcpClient ? transformMCPToolsToOpenAi(this.mcpClient.getAllTools()) : [];
    const loadedTools = config.tools
      ? (await maybeLoadToolsFromExternalFile(config.tools, context?.vars)) || []
      : [];
    // Transform tools to OpenAI format if needed
    const fileTools = transformTools(loadedTools, 'openai') as typeof loadedTools;
    const allTools = [...mcpTools, ...fileTools];
    // --- End MCP tool injection logic ---

    const body = {
      model: this.modelName,
      messages,
      seed: config.seed,
      ...(maxTokens === undefined ? {} : { max_tokens: maxTokens }),
      ...(maxCompletionTokens === undefined ? {} : { max_completion_tokens: maxCompletionTokens }),
      ...(reasoningEffort ? { reasoning_effort: reasoningEffort } : {}),
      ...(temperature === undefined ? {} : { temperature }),
      ...(config.top_p !== undefined || getEnvString('OPENAI_TOP_P')
        ? { top_p: config.top_p ?? getEnvFloat('OPENAI_TOP_P', 1) }
        : {}),
      ...(config.presence_penalty !== undefined || getEnvString('OPENAI_PRESENCE_PENALTY')
        ? {
            presence_penalty: config.presence_penalty ?? getEnvFloat('OPENAI_PRESENCE_PENALTY', 0),
          }
        : {}),
      ...(config.frequency_penalty !== undefined || getEnvString('OPENAI_FREQUENCY_PENALTY')
        ? {
            frequency_penalty:
              config.frequency_penalty ?? getEnvFloat('OPENAI_FREQUENCY_PENALTY', 0),
          }
        : {}),
      ...(config.functions
        ? {
            functions: maybeLoadFromExternalFileWithVars(config.functions, context?.vars),
          }
        : {}),
      ...(config.function_call ? { function_call: config.function_call } : {}),
      ...(allTools.length > 0 ? { tools: allTools } : {}),
      ...(config.tool_choice
        ? { tool_choice: transformToolChoice(config.tool_choice, 'openai') }
        : {}),
      ...(config.tool_resources ? { tool_resources: config.tool_resources } : {}),
      ...(config.response_format
        ? {
            response_format: maybeLoadResponseFormatFromExternalFile(
              config.response_format,
              context?.vars,
            ),
          }
        : {}),
      ...(callApiOptions?.includeLogProbs ? { logprobs: callApiOptions.includeLogProbs } : {}),
      ...(config.stop ? { stop: config.stop } : {}),
      ...(config.prompt_cache_key === undefined
        ? {}
        : { prompt_cache_key: config.prompt_cache_key }),
      ...(config.prompt_cache_options === undefined
        ? {}
        : { prompt_cache_options: config.prompt_cache_options }),
      ...(config.prompt_cache_retention === undefined
        ? {}
        : { prompt_cache_retention: config.prompt_cache_retention }),
      ...(config.passthrough || {}),
      ...(capabilityModelName.includes('audio')
        ? {
            modalities: config.modalities || ['text', 'audio'],
            audio: config.audio || { voice: 'alloy', format: 'wav' },
          }
        : {}),
      // GPT-5 only: attach verbosity if provided
      ...(isGPT5Model && config.verbosity ? { verbosity: config.verbosity } : {}),
    };
    assertOpenAiApiModel(body.model, this.getApiUrl());

    // Handle reasoning_effort and reasoning parameters for reasoning models
    if (config.reasoning_effort && (isReasoningModel || capabilityModelName.includes('gpt-oss'))) {
      body.reasoning_effort = renderVarsInObject(config.reasoning_effort, context?.vars);
    }

    if (config.reasoning && isOSeriesModel) {
      body.reasoning = config.reasoning;
    }

    // Add other basic parameters
    if (config.service_tier) {
      body.service_tier = config.service_tier;
    }
    if (config.user) {
      body.user = config.user;
    }
    if (config.metadata) {
      body.metadata = config.metadata;
    }
    if (config.store !== undefined) {
      body.store = config.store;
    }

    // Sanitize body for models that reject max_tokens (e.g. GPT-5, reasoning models).
    // This catches max_tokens introduced via passthrough or YAML anchors that bypass
    // the normal maxTokens variable logic above.
    if ((isReasoningModel || isGPT5Model) && 'max_tokens' in body) {
      delete body.max_tokens;
    }

    return { body, config };
  }

  /**
   * Calculate the response cost from the provider's raw usage payload.
   *
   * OpenAI-compatible providers can override this hook when their API exposes
   * authoritative billing data or uses provider-specific token accounting.
   */
  protected calculateResponseCost(
    data: OpenAiChatCompletionCostData,
    config: OpenAiCompletionOptions,
    cached: boolean,
  ): number | undefined {
    const passthroughModel = (config.passthrough as { model?: unknown } | undefined)?.model;
    const modelName =
      typeof passthroughModel === 'string' ? passthroughModel : this.getBillingModelName(config);
    const billingModelName = modelName.split('/').pop() ?? modelName;
    const tokenCost = calculateOpenAIUsageCost(billingModelName, config, data.usage, {
      apiUrl: this.getApiUrl(),
      cachedResponse: cached,
      serviceTier: data.service_tier ?? config.service_tier,
    });
    const searchCost = cached ? 0 : getChatSearchSurcharge(modelName);

    return tokenCost === undefined ? searchCost || undefined : tokenCost + searchCost;
  }

  async callApi(
    prompt: string,
    context?: CallApiContextParams,
    callApiOptions?: CallApiOptionsParams,
  ): Promise<ProviderResponse> {
    if (this.initializationPromise != null) {
      await this.initializationPromise;
    }
    if (this.requiresApiKey() && !this.getApiKey()) {
      throw new Error(this.getMissingApiKeyErrorMessage());
    }

    // Set up tracing context
    const spanContext: GenAISpanContext = {
      system: this.getGenAISystem(),
      operationName: 'chat',
      openaiApiType: 'chat_completions',
      model: this.modelName,
      providerId: this.id(),
      // Optional request parameters
      maxTokens: this.config.max_tokens,
      temperature: this.config.temperature,
      topP: this.config.top_p,
      stopSequences: this.config.stop,
      // Promptfoo context from test case if available
      evalId: context?.evaluationId || context?.test?.metadata?.evaluationId,
      testIndex: context?.testIdx ?? (context?.test?.vars?.__testIdx as number | undefined),
      promptLabel: context?.prompt?.label,
      // W3C Trace Context for linking to evaluation trace
      traceparent: context?.traceparent,
      // Request body for debugging/observability
      requestBody: prompt,
    };

    // Wrap the API call in a span
    return withGenAISpan(
      spanContext,
      () => this.callApiInternal(prompt, context, callApiOptions),
      extractProviderResponseAttributes,
    );
  }

  /**
   * Internal implementation of callApi without tracing wrapper.
   * This is called by callApi after setting up the tracing span.
   */
  private async callApiInternal(
    prompt: string,
    context?: CallApiContextParams,
    callApiOptions?: CallApiOptionsParams,
  ): Promise<ProviderResponse> {
    const { body, config } = await this.getOpenAiBody(prompt, context, callApiOptions);

    type OpenAIChatCompletionResponse = OpenAI.ChatCompletion & {
      choices: Array<
        OpenAI.ChatCompletion.Choice & {
          message: OpenAI.ChatCompletion.Choice['message'] & {
            reasoning?: string;
            reasoning_content?: string;
            audio?: {
              id: string;
              expires_at: number;
              data: string;
              transcript: string;
              format?: string;
            };
          };
        }
      >;
      usage?: OpenAI.ChatCompletion['usage'] & {
        audio_prompt_tokens?: number;
        audio_completion_tokens?: number;
      };
      error?: {
        code?: string;
        message?: string;
      };
    };

    let data: OpenAIChatCompletionResponse;
    let status: number;
    let statusText: string;
    let cached = false;
    let latencyMs: number | undefined;
    let deleteFromCache: (() => Promise<void>) | undefined;
    let responseHeaders: Record<string, string> | undefined;
    try {
      ({
        data,
        cached,
        status,
        statusText,
        latencyMs,
        deleteFromCache,
        headers: responseHeaders,
      } = await fetchWithCache<OpenAIChatCompletionResponse>(
        appendOpenAiApiPath(this.getApiUrl(), 'chat/completions'),
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(this.getApiKey() ? { Authorization: `Bearer ${this.getApiKey()}` } : {}),
            ...this.getOpenAiRequestHeaders(config.headers),
          },
          body: JSON.stringify(body),
        },
        getRequestTimeoutMs(),
        'json',
        this.shouldBustCache(context),
        this.config.maxRetries,
      ));

      if (status < 200 || status >= 300) {
        const errorMessage = `API error: ${status} ${statusText}\n${typeof data === 'string' ? data : JSON.stringify(data)}`;

        // Check if this is an invalid_prompt error code (indicates refusal)
        if (typeof data === 'object' && data?.error?.code === 'invalid_prompt') {
          const cost = this.calculateResponseCost(data, config, cached);

          return {
            output: errorMessage,
            tokenUsage: data?.usage ? getTokenUsage(data, cached) : undefined,
            cached,
            latencyMs,
            ...(cost === undefined ? {} : { cost }),
            isRefusal: true,
            guardrails: {
              flagged: true,
              flaggedInput: true, // This error specifically indicates input was rejected
            },
            metadata: {
              http: {
                status,
                statusText,
                headers: responseHeaders ?? {},
              },
            },
          };
        }

        return {
          error: errorMessage,
          metadata: {
            http: {
              status,
              statusText,
              headers: responseHeaders ?? {},
            },
          },
        };
      }
    } catch (err) {
      logger.error(`API call error: ${String(err)}`);
      await deleteFromCache?.();
      // Preserve the structured rate-limit signal so the scheduler honors
      // the transport-layer fail-fast contract (no retry on hard quotas)
      // and so the user-facing message stays the canonical
      // "Rate limit exceeded:" / "Quota exceeded:" form rather than being
      // wrapped in "API call error: HttpRateLimitError: ...".
      if (err instanceof HttpRateLimitError) {
        return {
          error: formatRateLimitErrorMessage(err),
          metadata: {
            rateLimitKind: err.kind,
            http: {
              status: err.status,
              statusText: err.statusText,
              headers: err.headers ?? responseHeaders ?? {},
            },
          },
        };
      }
      return {
        error: `API call error: ${String(err)}`,
        metadata: {
          http: {
            status: 0,
            statusText: 'Error',
            headers: responseHeaders ?? {},
          },
        },
      };
    }

    try {
      const message = data.choices[0].message;
      const finishReason = normalizeFinishReason(data.choices[0].finish_reason);
      const cost = this.calculateResponseCost(data, config, cached);

      // Track content filtering for guardrails
      const contentFiltered = finishReason === FINISH_REASON_MAP.content_filter;

      if (message.refusal) {
        return {
          output: message.refusal,
          tokenUsage: getTokenUsage(data, cached),
          cached,
          latencyMs,
          ...(cost === undefined ? {} : { cost }),
          isRefusal: true,
          ...(finishReason && { finishReason }),
          guardrails: { flagged: true }, // Refusal is ALWAYS a guardrail violation
          metadata: {
            http: {
              status,
              statusText,
              headers: responseHeaders ?? {},
            },
          },
        };
      }

      // Check if content was filtered
      if (contentFiltered) {
        return {
          output: message.content || 'Content filtered by provider',
          tokenUsage: getTokenUsage(data, cached),
          cached,
          latencyMs,
          ...(cost === undefined ? {} : { cost }),
          isRefusal: true,
          finishReason: FINISH_REASON_MAP.content_filter,
          guardrails: {
            flagged: true,
          },
          metadata: {
            http: {
              status,
              statusText,
              headers: responseHeaders ?? {},
            },
          },
        };
      }

      let reasoning = '';
      let output: any = '';
      if (message.reasoning) {
        reasoning = message.reasoning;
        output = message.content;
      } else if (message.content && (message.function_call || message.tool_calls)) {
        if (Array.isArray(message.tool_calls) && message.tool_calls.length === 0) {
          output = message.content;
        } else {
          output = message;
        }
      } else if (
        message.content === null ||
        message.content === undefined ||
        (message.content === '' && message.tool_calls)
      ) {
        output = message.function_call || message.tool_calls;
      } else {
        output = message.content;
      }
      const logProbs = data.choices[0].logprobs?.content?.map(
        (logProbObj: { token: string; logprob: number }) => logProbObj.logprob,
      );

      // Handle structured output
      if (config.response_format?.type === 'json_schema' && typeof output === 'string') {
        try {
          output = JSON.parse(output);
        } catch (error) {
          logger.error(`Failed to parse JSON output: ${error}`);
        }
      }
      // Handle reasoning as thinking content if present and showThinking is enabled
      if (reasoning && typeof output === 'string' && (this.config.showThinking ?? true)) {
        output = `Thinking: ${reasoning}\n\n${output}`;
      }

      // Handle function tool callbacks
      const functionCalls: any = message.function_call
        ? [message.function_call]
        : message.tool_calls;
      if (functionCalls && (config.functionToolCallbacks || this.mcpClient)) {
        const results = [];
        let hasSuccessfulCallback = false;
        for (const functionCall of functionCalls) {
          const functionName = functionCall.name || functionCall.function?.name;

          // Try MCP first if available
          if (this.mcpClient) {
            const mcpTools = this.mcpClient.getAllTools();
            const mcpTool = mcpTools.find((tool) => tool.name === functionName);
            if (mcpTool) {
              try {
                const args = functionCall.arguments || functionCall.function?.arguments || '{}';
                const parsedArgs = typeof args === 'string' ? JSON.parse(args) : args;
                const mcpResult = await this.mcpClient.callTool(functionName, parsedArgs);

                if (isMcpErrorResult(mcpResult)) {
                  results.push(
                    `MCP Tool Error (${functionName}): ${getMcpErrorMessage(mcpResult)}`,
                  );
                } else {
                  // Normalize MCP content to a readable string
                  const normalizeContent = (content: any): string => {
                    if (content == null) {
                      return '';
                    }
                    if (typeof content === 'string') {
                      return content;
                    }
                    if (Array.isArray(content)) {
                      return content
                        .map((part) => {
                          if (typeof part === 'string') {
                            return part;
                          }
                          if (part && typeof part === 'object') {
                            if ('text' in part && (part as any).text != null) {
                              return String((part as any).text);
                            }
                            if ('json' in part) {
                              return JSON.stringify((part as any).json);
                            }
                            if ('data' in part) {
                              return JSON.stringify((part as any).data);
                            }
                            return JSON.stringify(part);
                          }
                          return String(part);
                        })
                        .join('\n');
                    }
                    return JSON.stringify(content);
                  };

                  const content = normalizeContent(mcpResult?.content);
                  results.push(`MCP Tool Result (${functionName}): ${content}`);
                }
                hasSuccessfulCallback = true;
                continue; // Skip to next function call
              } catch (error) {
                logger.debug(`MCP tool execution failed for ${functionName}: ${error}`);
                results.push(`MCP Tool Error (${functionName}): ${error}`);
                hasSuccessfulCallback = true;
                continue; // Skip to next function call
              }
            }
          }

          // Fall back to regular function callbacks
          if (config.functionToolCallbacks && config.functionToolCallbacks[functionName]) {
            try {
              const functionResult = await this.executeFunctionCallback(
                functionName,
                functionCall.arguments || functionCall.function?.arguments,
                config,
                functionCall.call_id ?? functionCall.id,
              );
              results.push(functionResult);
              hasSuccessfulCallback = true;
            } catch (error) {
              // If callback fails, fall back to original behavior (return the function call)
              logger.debug(
                `Function callback failed for ${functionName} with error ${error}, falling back to original output`,
              );
              hasSuccessfulCallback = false;
              break;
            }
          }
        }
        if (hasSuccessfulCallback && results.length > 0) {
          return {
            output: results.join('\n'),
            tokenUsage: getTokenUsage(data, cached),
            cached,
            latencyMs,
            logProbs,
            ...(finishReason && { finishReason }),
            cost,
            guardrails: { flagged: contentFiltered },
            metadata: {
              http: {
                status,
                statusText,
                headers: responseHeaders ?? {},
              },
            },
          };
        }
      }

      // Handle DeepSeek reasoning model's reasoning_content by prepending it to the output
      if (
        message.reasoning_content &&
        typeof message.reasoning_content === 'string' &&
        typeof output === 'string' &&
        (this.config.showThinking ?? true)
      ) {
        output = `Thinking: ${message.reasoning_content}\n\n${output}`;
      }
      if (message.audio) {
        return {
          output: message.audio.transcript || '',
          audio: {
            id: message.audio.id,
            expiresAt: message.audio.expires_at,
            data: message.audio.data,
            transcript: message.audio.transcript,
            format: message.audio.format || 'wav',
          },
          tokenUsage: getTokenUsage(data, cached),
          cached,
          latencyMs,
          logProbs,
          ...(finishReason && { finishReason }),
          cost,
          guardrails: { flagged: contentFiltered },
          metadata: {
            http: {
              status,
              statusText,
              headers: responseHeaders ?? {},
            },
          },
        };
      }

      const citations = getChatSearchCitations(message.annotations, output);

      return {
        output,
        tokenUsage: getTokenUsage(data, cached),
        cached,
        latencyMs,
        logProbs,
        ...(finishReason && { finishReason }),
        cost,
        guardrails: { flagged: contentFiltered },
        metadata: {
          http: {
            status,
            statusText,
            headers: responseHeaders ?? {},
          },
          // Include all choices for multi-response requests (n > 1)
          ...(data.choices.length > 1 && { choices: data.choices }),
          ...(Array.isArray(message.annotations) &&
            message.annotations.length > 0 && { annotations: message.annotations }),
          ...(citations.length > 0 && { citations }),
        },
      };
    } catch (err) {
      await deleteFromCache?.();
      return {
        error: `API error: ${String(err)}: ${JSON.stringify(data)}`,
        metadata: {
          http: {
            status,
            statusText,
            headers: responseHeaders ?? {},
          },
        },
      };
    }
  }
}
