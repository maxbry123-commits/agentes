import {
  CLAUDE_REGIONAL_ENDPOINT_PREMIUM,
  calculateCacheInputCost,
  isClaudeFableOrMythos5Model,
  isClaudeOpus5Model,
  isClaudeRegionalPremiumModel,
  isClaudeSonnet5Model,
} from '../anthropic/util';

export type BedrockServiceTier = {
  type: 'priority' | 'default' | 'flex';
};

type BedrockPricing = {
  input: number;
  output: number;
  /**
   * Rates that replace `input`/`output` once total input tokens reach `threshold`.
   * Cache rates are derived from the tier's input rate, matching how AWS prices the
   * `-cache-read/-cache-write-...-long-context-...` meters.
   */
  longContext?: { threshold: number; input: number; output: number };
};

/**
 * Amazon Nova bills prompt-cache reads at 25% of the model's input rate and cache writes at
 * $0.00. Confirmed for every Nova model AWS publishes a cache meter for (Micro, Lite, Pro,
 * Premier, 2.0 Lite) from the AWS Price List API on 2026-09-01 — the ratio is exactly 0.25 in
 * each case, and every `-cache-write-input-token-count` meter is zero.
 *
 * Claude has its own (different) cache economics and is handled by `calculateCacheInputCost`.
 * Models with no published cache meter keep the previous behaviour of ignoring cache tokens.
 */
const NOVA_CACHE_READ_RATIO = 0.25;

function isNovaPromptCachingModel(normalizedModelId: string): boolean {
  return normalizedModelId.includes('amazon.nova-');
}

/**
 * Bedrock model pricing per 1M tokens.
 *
 * Rates are the plain us-east-1 on-demand meters from the AWS Price List API
 * (`aws pricing get-products --service-code AmazonBedrock`), which is the authority — the
 * `-batch`, `-custom-model`, `-flex`, `-priority` and `-cross-region-global` meters carry
 * different rates and must not be used here. Last reconciled 2026-09-01.
 */
const BEDROCK_PRICING: Record<string, BedrockPricing> = {
  // Claude 5
  'anthropic.claude-fable-5': { input: 10, output: 50 },
  // Claude Opus 5 (same list rates as Opus 4.8; full 1M context bills at the standard rate)
  'anthropic.claude-opus-5': { input: 5, output: 25 },
  // Claude Opus 4.8
  'anthropic.claude-opus-4-8': { input: 5, output: 25 },
  // Claude Opus 4.7
  'anthropic.claude-opus-4-7': { input: 5, output: 25 },
  // Claude Opus 4.6
  'anthropic.claude-opus-4-6': { input: 5, output: 25 },
  // Claude Opus 4.5
  'anthropic.claude-opus-4-5': { input: 5, output: 25 },
  // Claude Opus 4/4.1
  'anthropic.claude-opus-4': { input: 15, output: 75 },
  // Claude Sonnet 5 (standard list pricing; full 1M context bills at the standard rate)
  'anthropic.claude-sonnet-5': { input: 3, output: 15 },
  // Claude Sonnet 4.x — the point releases must precede the bare `-4` prefix: lookup is first-match-wins
  // on `includes()`, and AWS publishes long-context meters only for Sonnet 4 itself. 4.5 and
  // 4.6 bill their full context flat, so they must not inherit Sonnet 4's surcharge — add an
  // explicit entry here for any future 4.x release for the same reason.
  'anthropic.claude-sonnet-4-6': { input: 3, output: 15 },
  'anthropic.claude-sonnet-4-5': { input: 3, output: 15 },
  // Claude Sonnet 4 is the only Bedrock Claude model with published long-context meters
  // (verified 2026-09-01 in us-east-1, us-east-2, us-west-2, eu-west-1 and ap-northeast-1):
  // above 200K input tokens input doubles to $6 and output is 1.5x at $22.50. The matching
  // `-cache-read/-cache-write-...-long-context-...` meters are 10% and 1.25x of the tier's
  // input rate, which falls out of deriving the cache rates from it.
  'anthropic.claude-sonnet-4': {
    input: 3,
    output: 15,
    longContext: { threshold: 200_000, input: 6, output: 22.5 },
  },
  // Claude Haiku 4.5
  'anthropic.claude-haiku-4': { input: 1, output: 5 },
  // Claude 3.x
  'anthropic.claude-3-opus': { input: 15, output: 75 },
  'anthropic.claude-3-5-sonnet': { input: 3, output: 15 },
  'anthropic.claude-3-7-sonnet': { input: 3, output: 15 },
  'anthropic.claude-3-5-haiku': { input: 0.8, output: 4 },
  'anthropic.claude-3-haiku': { input: 0.25, output: 1.25 },
  // Amazon Nova
  'amazon.nova-micro': { input: 0.035, output: 0.14 },
  'amazon.nova-lite': { input: 0.06, output: 0.24 },
  'amazon.nova-pro': { input: 0.8, output: 3.2 },
  'amazon.nova-premier': { input: 2.5, output: 12.5 },
  // Amazon Nova 2 (reasoning models). The cross-region global profile is cheaper
  // ($0.30/$2.50); this is the plain us-east-1 on-demand rate.
  'amazon.nova-2-lite': { input: 0.33, output: 2.75 },
  // Amazon Titan Text
  'amazon.titan-text-lite': { input: 0.15, output: 0.2 },
  'amazon.titan-text-express': { input: 0.2, output: 0.6 },
  'amazon.titan-text-premier': { input: 0.5, output: 1.5 },
  // Meta Llama
  'meta.llama3-1-8b': { input: 0.22, output: 0.22 },
  'meta.llama3-1-70b': { input: 0.72, output: 0.72 },
  'meta.llama3-1-405b': { input: 5.32, output: 16 },
  'meta.llama3-2-1b': { input: 0.1, output: 0.1 },
  'meta.llama3-2-3b': { input: 0.15, output: 0.15 },
  'meta.llama3-2-11b': { input: 0.16, output: 0.16 },
  'meta.llama3-2-90b': { input: 0.72, output: 0.72 },
  'meta.llama3-3-70b': { input: 0.72, output: 0.72 },
  'meta.llama4-scout': { input: 0.17, output: 0.66 },
  'meta.llama4-maverick': { input: 0.24, output: 0.97 },
  'meta.llama4': { input: 1.0, output: 3.0 },
  // Mistral
  'mistral.mistral-7b': { input: 0.15, output: 0.2 },
  'mistral.mixtral-8x7b': { input: 0.45, output: 0.7 },
  'mistral.mistral-large': { input: 4, output: 12 },
  'mistral.mistral-small': { input: 1, output: 3 },
  'mistral.pixtral-large': { input: 2, output: 6 },
  // AI21 Jamba
  'ai21.jamba-1-5-mini': { input: 0.2, output: 0.4 },
  'ai21.jamba-1-5-large': { input: 2, output: 8 },
  // Cohere
  'cohere.command-r-plus': { input: 3, output: 15 },
  'cohere.command-r': { input: 0.5, output: 1.5 },
  // DeepSeek
  'deepseek.deepseek-r1': { input: 1.35, output: 5.4 },
  'deepseek.r1': { input: 1.35, output: 5.4 },
  // Qwen
  'qwen.qwen3-32b': { input: 0.15, output: 0.6 },
  'qwen.qwen3-235b': { input: 0.18, output: 0.54 },
  'qwen.qwen3-coder-30b': { input: 0.15, output: 0.6 },
  'qwen.qwen3-coder-480b': { input: 1.5, output: 7.5 },
  'qwen.qwen3': { input: 0.5, output: 1.5 },
  // Writer Palmyra
  'writer.palmyra-vision': { input: 0.15, output: 0.6 },
  'writer.palmyra-x5': { input: 0.6, output: 6 },
  'writer.palmyra-x4': { input: 2.5, output: 10 },
  // Newer OpenAI Chat-compatible families (base rates from https://aws.amazon.com/bedrock/pricing/;
  // verify there as rates change). Keys are variant-specific because rates differ within a
  // family, and `includes()` matches the first key in insertion order — so list more specific
  // ids first (e.g. `glm-4.7-flash` before `glm-4.7`). `includes()` also tolerates geo prefixes
  // (e.g. `us.zai.glm-5`). Region-specific overrides are applied below where AWS publishes them.
  // Z.AI GLM
  'zai.glm-5': { input: 1.0, output: 3.2 },
  'zai.glm-4.7-flash': { input: 0.07, output: 0.4 },
  'zai.glm-4.7': { input: 0.6, output: 2.2 },
  // MiniMax (M2 / M2.1 / M2.5 share a rate)
  'minimax.minimax-m2': { input: 0.3, output: 1.2 },
  // Moonshot Kimi
  'kimi-k2.5': { input: 0.6, output: 3.0 },
  'kimi-k2-thinking': { input: 0.6, output: 2.5 },
  // NVIDIA Nemotron
  'nemotron-nano-12b-v2': { input: 0.2, output: 0.6 },
  'nemotron-nano-3-30b': { input: 0.06, output: 0.24 },
  'nemotron-nano': { input: 0.06, output: 0.23 },
  'nemotron-super': { input: 0.15, output: 0.65 },
  // Google Gemma 3
  'gemma-3-4b': { input: 0.04, output: 0.08 },
  'gemma-3-12b': { input: 0.09, output: 0.29 },
  'gemma-3-27b': { input: 0.23, output: 0.38 },
  // OpenAI GPT-OSS (open-weight models served via InvokeModel/Converse). The frontier
  // gpt-5.x models are not available through Converse — they use the OpenAI-compatible
  // Responses API (see src/providers/bedrock/openaiResponses.ts).
  'openai.gpt-oss-120b': { input: 0.15, output: 0.6 },
  'openai.gpt-oss-20b': { input: 0.07, output: 0.3 },
};

const BEDROCK_REGION_PRICING_MODEL_PREFIXES = [
  'zai.glm-',
  'minimax.minimax-',
  'kimi-k2',
  'nemotron-',
  'gemma-3-',
  'openai.gpt-oss-',
] as const;

// GPT-OSS is available in more regions than the newer OpenAI-compatible Runtime families, and
// its rates do not follow the same regional groupings. Keep its complete published region map
// separate so a configured region never silently falls back to the US rate.
const GPT_OSS_REGION_PRICING: Record<string, Record<string, BedrockPricing>> = {
  'ap-northeast-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.73 },
    'openai.gpt-oss-20b': { input: 0.08, output: 0.36 },
  },
  'ap-south-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.71 },
    'openai.gpt-oss-20b': { input: 0.08, output: 0.35 },
  },
  'ap-southeast-2': {
    'openai.gpt-oss-120b': { input: 0.1545, output: 0.618 },
    'openai.gpt-oss-20b': { input: 0.0721, output: 0.309 },
  },
  'ap-southeast-3': {
    'openai.gpt-oss-120b': { input: 0.16, output: 0.62 },
    'openai.gpt-oss-20b': { input: 0.07, output: 0.31 },
  },
  'eu-central-1': {
    'openai.gpt-oss-120b': { input: 0.2, output: 0.79 },
    'openai.gpt-oss-20b': { input: 0.09, output: 0.4 },
  },
  'eu-north-1': {
    'openai.gpt-oss-120b': { input: 0.15, output: 0.6 },
    'openai.gpt-oss-20b': { input: 0.07, output: 0.3 },
  },
  'eu-south-1': {
    'openai.gpt-oss-120b': { input: 0.2, output: 0.79 },
    'openai.gpt-oss-20b': { input: 0.09, output: 0.4 },
  },
  'eu-west-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.7 },
    'openai.gpt-oss-20b': { input: 0.08, output: 0.35 },
  },
  'eu-west-2': {
    'openai.gpt-oss-120b': { input: 0.23, output: 0.93 },
    'openai.gpt-oss-20b': { input: 0.11, output: 0.47 },
  },
  'sa-east-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.73 },
    'openai.gpt-oss-20b': { input: 0.08, output: 0.36 },
  },
  'us-east-1': {
    'openai.gpt-oss-120b': { input: 0.15, output: 0.6 },
    'openai.gpt-oss-20b': { input: 0.07, output: 0.3 },
  },
  'us-east-2': {
    'openai.gpt-oss-120b': { input: 0.15, output: 0.6 },
    'openai.gpt-oss-20b': { input: 0.07, output: 0.3 },
  },
  'us-gov-east-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.72 },
    'openai.gpt-oss-20b': { input: 0.084, output: 0.36 },
  },
  'us-gov-west-1': {
    'openai.gpt-oss-120b': { input: 0.18, output: 0.72 },
    'openai.gpt-oss-20b': { input: 0.084, output: 0.36 },
  },
  'us-west-2': {
    'openai.gpt-oss-120b': { input: 0.15, output: 0.6 },
    'openai.gpt-oss-20b': { input: 0.07, output: 0.3 },
  },
};

const AP_NORTHEAST_1_AND_SA_EAST_1_PRICING: Record<string, BedrockPricing> = {
  'zai.glm-5': { input: 1.2, output: 3.84 },
  'zai.glm-4.7-flash': { input: 0.08, output: 0.48 },
  'zai.glm-4.7': { input: 0.72, output: 2.64 },
  'minimax.minimax-m2.5': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2.1': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2': { input: 0.36, output: 1.45 },
  'kimi-k2.5': { input: 0.72, output: 3.6 },
  'kimi-k2-thinking': { input: 0.73, output: 3.03 },
  'nemotron-nano-12b-v2': { input: 0.24, output: 0.73 },
  'nemotron-nano-3-30b': { input: 0.07, output: 0.29 },
  'nemotron-nano': { input: 0.07, output: 0.28 },
  'nemotron-super': { input: 0.18, output: 0.78 },
  'gemma-3-4b': { input: 0.05, output: 0.1 },
  'gemma-3-12b': { input: 0.11, output: 0.35 },
  'gemma-3-27b': { input: 0.28, output: 0.46 },
};

const AP_SOUTHEAST_3_EU_CENTRAL_1_AND_EU_NORTH_1_PRICING: Record<string, BedrockPricing> = {
  'zai.glm-5': { input: 1.2, output: 3.84 },
  'zai.glm-4.7-flash': { input: 0.08, output: 0.48 },
  'zai.glm-4.7': { input: 0.72, output: 2.64 },
  'minimax.minimax-m2.5': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2.1': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2': { input: 0.36, output: 1.44 },
  'kimi-k2.5': { input: 0.72, output: 3.6 },
  'kimi-k2-thinking': { input: 0.72, output: 3.0 },
  'nemotron-nano-12b-v2': { input: 0.24, output: 0.72 },
  'nemotron-nano-3-30b': { input: 0.072, output: 0.288 },
  'nemotron-nano': { input: 0.072, output: 0.276 },
  'nemotron-super': { input: 0.18, output: 0.78 },
  'gemma-3-4b': { input: 0.048, output: 0.096 },
  'gemma-3-12b': { input: 0.108, output: 0.348 },
  'gemma-3-27b': { input: 0.276, output: 0.456 },
};

const EU_SOUTH_1_AND_EU_WEST_1_PRICING: Record<string, BedrockPricing> = {
  'zai.glm-5': { input: 1.2, output: 3.84 },
  'zai.glm-4.7-flash': { input: 0.08, output: 0.48 },
  'zai.glm-4.7': { input: 0.72, output: 2.64 },
  'minimax.minimax-m2.5': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2.1': { input: 0.36, output: 1.44 },
  'minimax.minimax-m2': { input: 0.35, output: 1.41 },
  'kimi-k2.5': { input: 0.72, output: 3.6 },
  'kimi-k2-thinking': { input: 0.72, output: 3.0 },
  'nemotron-nano-12b-v2': { input: 0.23, output: 0.7 },
  'nemotron-nano-3-30b': { input: 0.07, output: 0.28 },
  'nemotron-nano': { input: 0.07, output: 0.27 },
  'nemotron-super': { input: 0.18, output: 0.78 },
  'gemma-3-4b': { input: 0.05, output: 0.09 },
  'gemma-3-12b': { input: 0.11, output: 0.34 },
  'gemma-3-27b': { input: 0.27, output: 0.45 },
};

const US_GOV_PRICING: Record<string, BedrockPricing> = {
  'nemotron-nano-12b-v2': { input: 0.24, output: 0.72 },
  'nemotron-nano-3-30b': { input: 0.072, output: 0.288 },
  'nemotron-nano': { input: 0.072, output: 0.276 },
  'nemotron-super': { input: 0.18, output: 0.78 },
};

const BEDROCK_REGION_PRICING: Record<string, Record<string, BedrockPricing>> = {
  'ap-northeast-1': AP_NORTHEAST_1_AND_SA_EAST_1_PRICING,
  'ap-south-1': {
    'zai.glm-5': { input: 1.2, output: 3.84 },
    'zai.glm-4.7-flash': { input: 0.08, output: 0.48 },
    'zai.glm-4.7': { input: 0.72, output: 2.64 },
    'minimax.minimax-m2.5': { input: 0.36, output: 1.44 },
    'minimax.minimax-m2.1': { input: 0.36, output: 1.44 },
    'minimax.minimax-m2': { input: 0.35, output: 1.41 },
    'kimi-k2.5': { input: 0.72, output: 3.6 },
    'kimi-k2-thinking': { input: 0.71, output: 2.94 },
    'nemotron-nano-12b-v2': { input: 0.24, output: 0.71 },
    'nemotron-nano-3-30b': { input: 0.07, output: 0.28 },
    'nemotron-nano': { input: 0.07, output: 0.27 },
    'nemotron-super': { input: 0.18, output: 0.78 },
    'gemma-3-4b': { input: 0.05, output: 0.09 },
    'gemma-3-12b': { input: 0.11, output: 0.34 },
    'gemma-3-27b': { input: 0.27, output: 0.45 },
  },
  // These are AWS's published ap-southeast-2 meters, not the US rate scaled by a regional
  // uplift. Four entries had been derived that way and drifted from the real values.
  'ap-southeast-2': {
    'zai.glm-5': { input: 1.03, output: 3.3 },
    'zai.glm-4.7-flash': { input: 0.07, output: 0.41 },
    'zai.glm-4.7': { input: 0.62, output: 2.27 },
    'minimax.minimax-m2.5': { input: 0.31, output: 1.24 },
    'minimax.minimax-m2.1': { input: 0.31, output: 1.24 },
    'minimax.minimax-m2': { input: 0.309, output: 1.236 },
    'kimi-k2.5': { input: 0.62, output: 3.09 },
    'kimi-k2-thinking': { input: 0.618, output: 2.575 },
    'nemotron-nano-12b-v2': { input: 0.206, output: 0.618 },
    'nemotron-nano-3-30b': { input: 0.0618, output: 0.2472 },
    'nemotron-nano': { input: 0.0618, output: 0.2369 },
    'nemotron-super': { input: 0.15, output: 0.67 },
    'gemma-3-4b': { input: 0.0412, output: 0.0824 },
    'gemma-3-12b': { input: 0.0927, output: 0.2987 },
    'gemma-3-27b': { input: 0.2369, output: 0.3914 },
  },
  'ap-southeast-3': AP_SOUTHEAST_3_EU_CENTRAL_1_AND_EU_NORTH_1_PRICING,
  'eu-central-1': AP_SOUTHEAST_3_EU_CENTRAL_1_AND_EU_NORTH_1_PRICING,
  'eu-north-1': AP_SOUTHEAST_3_EU_CENTRAL_1_AND_EU_NORTH_1_PRICING,
  'eu-south-1': EU_SOUTH_1_AND_EU_WEST_1_PRICING,
  'eu-west-1': EU_SOUTH_1_AND_EU_WEST_1_PRICING,
  'eu-west-2': {
    'zai.glm-5': { input: 1.55, output: 4.96 },
    'zai.glm-4.7-flash': { input: 0.11, output: 0.62 },
    'zai.glm-4.7': { input: 0.93, output: 3.41 },
    'minimax.minimax-m2.5': { input: 0.47, output: 1.86 },
    'minimax.minimax-m2.1': { input: 0.47, output: 1.86 },
    'minimax.minimax-m2': { input: 0.47, output: 1.86 },
    'kimi-k2.5': { input: 0.93, output: 4.65 },
    'kimi-k2-thinking': { input: 0.93, output: 3.875 },
    'nemotron-nano-12b-v2': { input: 0.31, output: 0.93 },
    'nemotron-nano-3-30b': { input: 0.09, output: 0.37 },
    'nemotron-nano': { input: 0.09, output: 0.36 },
    'nemotron-super': { input: 0.23, output: 1.01 },
    'gemma-3-4b': { input: 0.06, output: 0.12 },
    'gemma-3-12b': { input: 0.14, output: 0.45 },
    'gemma-3-27b': { input: 0.36, output: 0.59 },
  },
  'sa-east-1': AP_NORTHEAST_1_AND_SA_EAST_1_PRICING,
  'us-gov-east-1': US_GOV_PRICING,
  'us-gov-west-1': US_GOV_PRICING,
};

function getBedrockPricing(normalizedModelId: string, region?: string): BedrockPricing | undefined {
  if (normalizedModelId.includes('openai.gpt-oss-') && region) {
    const pricing = GPT_OSS_REGION_PRICING[region.toLowerCase()];
    if (!pricing) {
      return undefined;
    }
    for (const [modelPrefix, modelPricing] of Object.entries(pricing)) {
      if (normalizedModelId.includes(modelPrefix)) {
        return modelPricing;
      }
    }
    return undefined;
  }

  const regionPricing = region ? BEDROCK_REGION_PRICING[region.toLowerCase()] : undefined;
  if (regionPricing) {
    for (const [modelPrefix, pricing] of Object.entries(regionPricing)) {
      if (normalizedModelId.includes(modelPrefix)) {
        return pricing;
      }
    }
    if (
      BEDROCK_REGION_PRICING_MODEL_PREFIXES.some((prefix) => normalizedModelId.includes(prefix))
    ) {
      return undefined;
    }
  }

  for (const [modelPrefix, pricing] of Object.entries(BEDROCK_PRICING)) {
    if (normalizedModelId.includes(modelPrefix)) {
      return pricing;
    }
  }
  return undefined;
}

const BEDROCK_INVOKE_PRICING_MODEL_PREFIXES = [
  'zai.glm-',
  'minimax.minimax-',
  'kimi-k2',
  'nemotron-',
  'gemma-3-',
  'writer.palmyra-',
  'openai.gpt-oss-',
] as const;

/**
 * Calculate cost based on model and token usage
 */
export function calculateBedrockCost(
  modelId: string,
  promptTokens?: number,
  completionTokens?: number,
  cacheReadTokens = 0,
  cacheWriteTokens = 0,
  region?: string,
  serviceTier?: BedrockServiceTier,
): number | undefined {
  if (promptTokens === undefined || completionTokens === undefined) {
    return undefined;
  }

  const normalizedModelId = modelId.toLowerCase();
  const pricing = getBedrockPricing(normalizedModelId, region);
  if (!pricing) {
    return undefined;
  }
  // Global endpoints bill at base rate; regional and geo endpoints carry a 10%
  // premium for Claude 4.5+ models. The model ID may be a bare `global.` profile
  // or an inference-profile ARN wrapping it (`arn:...:inference-profile/global....`).
  const isGlobalEndpoint =
    normalizedModelId.startsWith('global.') || normalizedModelId.includes('/global.');
  const endpointMultiplier =
    isClaudeRegionalPremiumModel(normalizedModelId) && !isGlobalEndpoint
      ? CLAUDE_REGIONAL_ENDPOINT_PREMIUM
      : 1;
  const serviceTierMultiplier =
    serviceTier?.type === 'priority' ? 1.75 : serviceTier?.type === 'flex' ? 0.5 : 1;
  const pricingMultiplier = endpointMultiplier * serviceTierMultiplier;
  // Long-context tiers are billed on total input size, which for Anthropic means the uncached
  // prompt plus any cache reads and writes (`input_tokens` excludes cached tokens).
  const totalInputTokens = promptTokens + cacheReadTokens + cacheWriteTokens;
  const tier =
    pricing.longContext && totalInputTokens >= pricing.longContext.threshold
      ? pricing.longContext
      : pricing;

  const inputRate = (tier.input / 1_000_000) * pricingMultiplier;
  const inputCost = normalizedModelId.includes('anthropic.claude')
    ? calculateCacheInputCost(inputRate, promptTokens, cacheReadTokens, cacheWriteTokens)
    : isNovaPromptCachingModel(normalizedModelId)
      ? promptTokens * inputRate + cacheReadTokens * inputRate * NOVA_CACHE_READ_RATIO
      : promptTokens * inputRate;
  const outputCost = (completionTokens / 1_000_000) * tier.output * pricingMultiplier;
  return inputCost + outputCost;
}

/**
 * Calculate InvokeModel cost only for models whose Runtime rates are verified here.
 *
 * The broader table preserves existing Converse cost coverage, but several legacy entries are
 * stale or refer to different variants. Before this shared calculator existed, InvokeModel only
 * reported Claude 5 cost. Keep that fail-closed behavior for legacy Runtime models instead of
 * emitting a plausible but incorrect cost.
 *
 * Claude 5 models (Fable 5, Mythos 5, Opus 5, and Sonnet 5) have verified Runtime rates, so they
 * report cost on the default `bedrock:` InvokeModel path — without this, `bedrock:anthropic.claude-opus-5`
 * reports token usage but `cost: 0`. Legacy Claude (e.g. Sonnet/Opus 4.x) stays fail-closed.
 */
export function calculateBedrockInvokeModelCost(
  modelId: string,
  promptTokens?: number,
  completionTokens?: number,
  cacheReadTokens = 0,
  cacheWriteTokens = 0,
  region?: string,
): number | undefined {
  const normalizedModelId = modelId.toLowerCase();
  if (
    !isClaudeFableOrMythos5Model(normalizedModelId) &&
    !isClaudeOpus5Model(normalizedModelId) &&
    !isClaudeSonnet5Model(normalizedModelId) &&
    !BEDROCK_INVOKE_PRICING_MODEL_PREFIXES.some((prefix) => normalizedModelId.includes(prefix))
  ) {
    return undefined;
  }

  return calculateBedrockCost(
    modelId,
    promptTokens,
    completionTokens,
    cacheReadTokens,
    cacheWriteTokens,
    region,
  );
}
