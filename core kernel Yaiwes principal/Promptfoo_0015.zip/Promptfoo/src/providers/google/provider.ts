/**
 * Unified Google Provider for Gemini models.
 *
 * This provider handles both Google AI Studio and Vertex AI modes
 * for Gemini models, with the mode determined by the `vertexai` config flag.
 *
 * @example
 * // Google AI Studio mode (default)
 * new GoogleProvider('gemini-2.5-pro', { config: { apiKey: 'your-key' }})
 *
 * // Vertex AI mode
 * new GoogleProvider('gemini-2.5-pro', { config: { vertexai: true, projectId: 'my-project' }})
 */

import { fetchWithCache } from '../../cache';
import cliState from '../../cliState';
import { getEnvString } from '../../envars';
import logger from '../../logger';
import { fetchWithProxy } from '../../util/fetch/index';
import { maybeLoadFromExternalFile } from '../../util/file';
import { renderVarsInObject } from '../../util/index';
import { getNunjucksEngine } from '../../util/templates';
import { getRequestTimeoutMs } from '../shared';
import { GoogleGenericProvider, type GoogleProviderOptions } from './base';
import { getVertexApiHostForRegion } from './shared';
import {
  calculateGoogleCostFromUsage,
  collectGroundingMetadata,
  createAuthCacheDiscriminator,
  formatCandidateContents,
  geminiFormatAndSystemInstructions,
  getCandidate,
  getGoogleClient,
  getLastPromptSafetyRatings,
  isNonCandidateStreamChunk,
  loadCredentials,
  mergeGoogleCompletionOptions,
  mergeParts,
  normalizeGeminiAudio,
  normalizeSafetySettings,
  removeDeprecatedGeminiGenerationParams,
  removeGoogleFunctionDeclarations,
  resolveGoogleToolConfig,
} from './util';

import type {
  CallApiContextParams,
  GuardrailResponse,
  ProviderResponse,
  TokenUsage,
} from '../../types/index';
import type { CompletionOptions } from './types';
import type { GeminiApiResponse, GeminiErrorResponse, GeminiResponseData } from './util';

// Type for Google API errors
type GaxiosError = any;

const DEFAULT_AI_STUDIO_HOST = 'generativelanguage.googleapis.com';

interface SafetyRelevantAssertion {
  type?: string;
  assert?: SafetyRelevantAssertion[];
}

type SafetyRelevantContext = CallApiContextParams & {
  test?: NonNullable<CallApiContextParams['test']> & {
    assert?: SafetyRelevantAssertion[];
  };
};

function hasScorableSafetyAssertion(assertion: SafetyRelevantAssertion): boolean {
  if (
    assertion.type === 'guardrails' ||
    assertion.type === 'not-guardrails' ||
    assertion.type?.startsWith('promptfoo:redteam:')
  ) {
    return true;
  }

  return (
    assertion.type === 'assert-set' &&
    Array.isArray(assertion.assert) &&
    assertion.assert.some(hasScorableSafetyAssertion)
  );
}

function shouldExposeSafetyBlockAsOutput(context?: CallApiContextParams): boolean {
  if (cliState.config?.redteam) {
    return true;
  }

  const test = (context as SafetyRelevantContext | undefined)?.test;
  if (
    typeof test?.metadata?.pluginId === 'string' &&
    (Boolean(test.metadata.pluginConfig) || Boolean(test.metadata.goal))
  ) {
    return true;
  }

  return test?.assert?.some(hasScorableSafetyAssertion) ?? false;
}

/**
 * Unified Google provider for Gemini models.
 *
 * Supports both Google AI Studio and Vertex AI modes, determined by the
 * `vertexai` configuration option (Python SDK alignment).
 *
 * Mode determination priority:
 * 1. Explicit `vertexai: true/false` in config
 * 2. `GOOGLE_GENAI_USE_VERTEXAI` environment variable
 * 3. Auto-detect from projectId/credentials presence
 * 4. Default: false (Google AI Studio)
 */
export class GoogleProvider extends GoogleGenericProvider {
  constructor(modelName: string, options: GoogleProviderOptions = {}) {
    super(modelName, options);

    // Log mode for debugging
    logger.debug(
      `[GoogleProvider] Initialized with model=${modelName}, vertexMode=${this.isVertexMode}`,
    );
  }

  /**
   * Get the API host based on mode.
   * Public for use by integrations like Adaline Gateway.
   */
  getApiHost(): string {
    if (this.isVertexMode) {
      // Vertex AI mode
      const region = this.getRegion();
      return (
        this.config.apiHost ||
        this.env?.VERTEX_API_HOST ||
        getEnvString('VERTEX_API_HOST') ||
        getVertexApiHostForRegion(region)
      );
    } else {
      // AI Studio mode
      const apiHost =
        this.config.apiHost ||
        this.env?.GOOGLE_API_HOST ||
        this.env?.PALM_API_HOST ||
        getEnvString('GOOGLE_API_HOST') ||
        getEnvString('PALM_API_HOST') ||
        DEFAULT_AI_STUDIO_HOST;
      return getNunjucksEngine().renderString(apiHost, {});
    }
  }

  /**
   * Get the API version.
   *
   * For Vertex AI: Uses config.apiVersion, env vars, or defaults to 'v1'.
   * For AI Studio: Uses config.apiVersion if set, otherwise defaults to
   * v1beta (including the Gemini 3.x family). The legacy
   * gemini-2.0-flash-thinking-exp model only responds on v1alpha.
   */
  private getApiVersion(): string {
    if (this.isVertexMode) {
      return (
        this.config.apiVersion ||
        this.env?.VERTEX_API_VERSION ||
        getEnvString('VERTEX_API_VERSION') ||
        'v1'
      );
    } else {
      // AI Studio: allow explicit override, then auto-detect based on model
      if (this.config.apiVersion) {
        return this.config.apiVersion;
      }
      // gemini-2.0-flash-thinking-exp only responds on v1alpha; everything
      // else (including Gemini 3.x) uses the stable v1beta endpoint.
      return this.modelName === 'gemini-2.0-flash-thinking-exp' ? 'v1alpha' : 'v1beta';
    }
  }

  /**
   * Get the publisher for Vertex AI.
   */
  private getPublisher(): string {
    return (
      this.config.publisher ||
      this.env?.VERTEX_PUBLISHER ||
      getEnvString('VERTEX_PUBLISHER') ||
      'google'
    );
  }

  /**
   * Get the API endpoint URL.
   *
   * @param action - Optional action like 'generateContent'
   * @returns The full API endpoint URL
   */
  getApiEndpoint(action?: string): string {
    const actionSuffix = action ? `:${action}` : '';

    if (this.isVertexMode) {
      return `https://${this.getApiHost()}/${this.getApiVersion()}/publishers/${this.getPublisher()}/models/${this.modelName}${actionSuffix}`;
    } else {
      const baseUrl = this.getApiBaseUrl();
      return `${baseUrl}/${this.getApiVersion()}/models/${this.modelName}${actionSuffix}`;
    }
  }

  /**
   * Get the base URL for AI Studio API.
   */
  private getApiBaseUrl(): string {
    // Check for apiHost first (most specific override)
    const apiHost =
      this.config.apiHost ||
      this.env?.GOOGLE_API_HOST ||
      this.env?.PALM_API_HOST ||
      getEnvString('GOOGLE_API_HOST') ||
      getEnvString('PALM_API_HOST');
    if (apiHost) {
      const renderedHost = getNunjucksEngine().renderString(apiHost, {});
      return `https://${renderedHost}`;
    }

    // Check for apiBaseUrl (less specific override)
    if (
      this.config.apiBaseUrl ||
      this.env?.GOOGLE_API_BASE_URL ||
      getEnvString('GOOGLE_API_BASE_URL')
    ) {
      return (
        this.config.apiBaseUrl ||
        this.env?.GOOGLE_API_BASE_URL ||
        getEnvString('GOOGLE_API_BASE_URL')!
      );
    }

    // Default: render the default host with Nunjucks for template variable support
    const renderedHost = getNunjucksEngine().renderString(DEFAULT_AI_STUDIO_HOST, {});
    return `https://${renderedHost}`;
  }

  /**
   * Get authentication headers.
   * API key is passed via x-goog-api-key header for improved security.
   */
  async getAuthHeaders(): Promise<Record<string, string>> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...this.config.headers,
    };

    // Add API key to headers if available and we're using express/API key mode
    if (!this.isVertexMode || this.isExpressMode()) {
      const apiKey = this.getApiKey();
      if (apiKey) {
        headers['x-goog-api-key'] = apiKey;
      }
    }

    return headers;
  }

  /**
   * Check if express mode should be used (API key without OAuth).
   *
   * Express mode is automatic when an API key is available - users don't need
   * to think about it. Just provide an API key and it works.
   *
   * Express mode is used when:
   * 1. API key is available (VERTEX_API_KEY, GOOGLE_API_KEY, or config.apiKey)
   * 2. User hasn't explicitly disabled it with `expressMode: false`
   * 3. No OAuth/ADC credentials are configured (OAuth takes priority)
   */
  private isExpressMode(): boolean {
    if (!this.isVertexMode) {
      return false;
    }

    const hasApiKey = Boolean(this.getApiKey());
    const explicitlyDisabled = this.config.expressMode === false;

    // Check if OAuth/ADC credentials are explicitly configured - they take priority
    const hasOAuthConfig = Boolean(
      this.config.credentials ||
        this.config.keyFilename ||
        this.config.googleAuthOptions?.keyFilename ||
        this.config.googleAuthOptions?.credentials,
    );

    // Auto-enable express mode when API key is available AND no OAuth config
    // OAuth credentials take priority over express mode
    return hasApiKey && !explicitlyDisabled && !hasOAuthConfig;
  }

  /**
   * Get Google client with credentials support for OAuth mode.
   */
  private async getClientWithCredentials() {
    const credentials = loadCredentials(this.config.credentials);
    const { client } = await getGoogleClient({
      credentials,
      googleAuthOptions: this.config.googleAuthOptions,
      scopes: this.config.scopes,
      keyFilename: this.config.keyFilename,
    });
    return client;
  }

  /**
   * Call the API with the given prompt.
   */
  async callApi(prompt: string, context?: CallApiContextParams): Promise<ProviderResponse> {
    // Wait for MCP initialization if pending
    if (this.initializationPromise != null) {
      await this.initializationPromise;
    }

    // Require API key for AI Studio mode
    if (!this.isVertexMode) {
      const apiKey = this.getApiKey();
      if (!apiKey) {
        throw new Error(
          'Google API key is not set. Set the GOOGLE_API_KEY or GEMINI_API_KEY environment variable or add `apiKey` to the provider config.',
        );
      }
    }

    return this.callGeminiApi(prompt, context);
  }

  /**
   * Call the Gemini API.
   */
  private async callGeminiApi(
    prompt: string,
    context?: CallApiContextParams,
  ): Promise<ProviderResponse> {
    // Merge configs from the provider and the prompt
    const config = mergeGoogleCompletionOptions(
      this.config,
      context?.prompt?.config as Partial<CompletionOptions> | undefined,
    );

    const { contents, systemInstruction } = geminiFormatAndSystemInstructions(
      prompt,
      context?.vars,
      config.systemInstruction,
      { useAssistantRole: config.useAssistantRole },
    );

    const { toolConfig, toolsDisabled } = resolveGoogleToolConfig(config);
    // Get all tools (MCP + config tools) using base class method
    const allTools = await this.getAllTools(context, {
      skipExecutableToolFiles: toolsDisabled,
    });
    const requestTools = toolsDisabled ? removeGoogleFunctionDeclarations(allTools) : allTools;
    const {
      service_tier: passthroughServiceTier,
      tools: passthroughTools,
      ...passthrough
    } = config.passthrough || {};
    const requestPassthroughTools =
      toolsDisabled && passthroughTools !== undefined
        ? removeGoogleFunctionDeclarations(passthroughTools)
        : passthroughTools;

    const body: Record<string, any> = {
      contents,
      generationConfig: {
        ...(config.temperature !== undefined && { temperature: config.temperature }),
        ...(config.topP !== undefined && { topP: config.topP }),
        ...(config.topK !== undefined && { topK: config.topK }),
        ...(config.stopSequences !== undefined && { stopSequences: config.stopSequences }),
        ...(config.maxOutputTokens !== undefined && { maxOutputTokens: config.maxOutputTokens }),
        ...config.generationConfig,
        ...(this.modelName.includes('-tts') && {
          response_modalities: undefined,
          responseModalities: config.generationConfig?.responseModalities ??
            config.generationConfig?.response_modalities?.map((modality) =>
              modality.toUpperCase(),
            ) ?? ['AUDIO'],
          speechConfig: config.generationConfig?.speechConfig ?? {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        }),
      },
      safetySettings: normalizeSafetySettings(config.safetySettings),
      ...(toolConfig ? { toolConfig } : {}),
      ...(requestTools.length > 0 ? { tools: requestTools } : {}),
      // Vertex AI uses camelCase (systemInstruction), AI Studio uses snake_case (system_instruction)
      ...(systemInstruction
        ? this.isVertexMode
          ? { systemInstruction }
          : { system_instruction: systemInstruction }
        : {}),
      ...(config.service_tier ? { serviceTier: config.service_tier } : {}),
      ...passthrough,
      // Normalize a single-object passthrough `tools` value to a one-element array and
      // always merge with requestTools so config/MCP tools aren't dropped and `tools`
      // stays the array shape the Gemini API requires.
      ...(requestPassthroughTools === undefined
        ? {}
        : {
            tools: [
              ...requestTools,
              ...(Array.isArray(requestPassthroughTools)
                ? requestPassthroughTools
                : [requestPassthroughTools]),
            ],
          }),
      ...(passthroughServiceTier ? { serviceTier: passthroughServiceTier } : {}),
    };
    body.generationConfig = removeDeprecatedGeminiGenerationParams(
      this.modelName,
      body.generationConfig,
    );

    // Handle response schema
    if (config.responseSchema) {
      if (body.generationConfig.response_schema) {
        throw new Error(
          '`responseSchema` provided but `generationConfig.response_schema` already set.',
        );
      }

      let schema = maybeLoadFromExternalFile(
        renderVarsInObject(config.responseSchema, context?.vars),
      );

      // Parse JSON string if it's a string
      if (typeof schema === 'string') {
        try {
          schema = JSON.parse(schema);
        } catch (error) {
          throw new Error(`Invalid JSON in responseSchema: ${error}`);
        }
      }

      // Apply variable substitution to the loaded schema
      schema = renderVarsInObject(schema, context?.vars);

      body.generationConfig.response_schema = schema;
      body.generationConfig.response_mime_type = 'application/json';
    }

    let data: GeminiApiResponse;
    let cached = false;

    try {
      if (this.isVertexMode && !this.isExpressMode()) {
        // Vertex AI OAuth mode
        const client = await this.getClientWithCredentials();
        const projectId = await this.getProjectId();
        const endpoint = config.streaming === true ? 'streamGenerateContent' : 'generateContent';
        const url = `https://${this.getApiHost()}/${this.getApiVersion()}/projects/${projectId}/locations/${this.getRegion()}/publishers/${this.getPublisher()}/models/${this.modelName}:${endpoint}`;

        const res = await client.request({
          url,
          method: 'POST',
          data: body,
          timeout: getRequestTimeoutMs(),
        });
        data = res.data as GeminiApiResponse;
      } else if (this.isVertexMode && this.isExpressMode()) {
        // Vertex AI express mode (API key)
        const endpoint = config.streaming === true ? 'streamGenerateContent' : 'generateContent';
        const url = `https://${this.getApiHost()}/${this.getApiVersion()}/publishers/${this.getPublisher()}/models/${this.modelName}:${endpoint}`;

        const res = await fetchWithProxy(url, {
          method: 'POST',
          headers: await this.getAuthHeaders(),
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(getRequestTimeoutMs()),
        });

        if (!res.ok) {
          const errorData = await res.json().catch(() => null);
          logger.debug(`Gemini API express mode error:\n${JSON.stringify(errorData)}`);
          return {
            error: `API call error: ${res.status} ${res.statusText}${errorData ? `: ${JSON.stringify(errorData)}` : ''}`,
          };
        }

        data = (await res.json()) as GeminiApiResponse;
      } else {
        // AI Studio mode
        const endpoint = this.getApiEndpoint('generateContent');
        const headers = await this.getAuthHeaders();
        const authDiscriminator = createAuthCacheDiscriminator(headers);
        const result = await fetchWithCache(
          endpoint,
          {
            method: 'POST',
            headers,
            body: JSON.stringify(body),
            // Include auth discriminator in cache key to prevent cross-tenant cache sharing
            ...(authDiscriminator && { _authHash: authDiscriminator }),
          } as RequestInit,
          getRequestTimeoutMs(),
          'json',
          false,
        );
        data = result.data as GeminiApiResponse;
        cached = result.cached;
      }
    } catch (err) {
      const geminiError = err as GaxiosError;
      if (geminiError.response?.data?.[0]?.error) {
        const errorDetails = geminiError.response.data[0].error;
        logger.error(`Gemini API error:\n${JSON.stringify(errorDetails)}`);
        return {
          error: `API call error: Status ${errorDetails.status}, Code ${errorDetails.code}, Message:\n\n${errorDetails.message}`,
        };
      }
      return {
        error: `API call error: ${String(err)}`,
      };
    }

    // Parse response
    return this.parseGeminiResponse(data, cached, config, context);
  }

  /**
   * Parse Gemini API response.
   */
  private async parseGeminiResponse(
    data: GeminiApiResponse,
    cached: boolean,
    config: CompletionOptions,
    context?: CallApiContextParams,
  ): Promise<ProviderResponse> {
    try {
      const { toolsDisabled } = resolveGoogleToolConfig(config);

      // Normalize response: non-streaming returns single object, streaming returns array
      const normalizedData = Array.isArray(data) ? data : [data];

      // Check for error response
      const dataWithError = normalizedData as GeminiErrorResponse[];
      const error = dataWithError[0]?.error;
      if (error) {
        return { error: `Error ${error.code}: ${error.message}` };
      }

      const dataWithResponse = normalizedData as GeminiResponseData[];
      let output: ReturnType<typeof formatCandidateContents> | undefined;

      for (const datum of dataWithResponse) {
        // Check for blockReason first
        if (datum.promptFeedback?.blockReason) {
          const isModelArmor = datum.promptFeedback.blockReason === 'MODEL_ARMOR';
          const blockReasonMessage =
            datum.promptFeedback.blockReasonMessage ||
            `Content was blocked due to ${isModelArmor ? 'Model Armor' : 'safety settings'}: ${datum.promptFeedback.blockReason}`;

          const tokenUsage = {
            total: datum.usageMetadata?.totalTokenCount || 0,
            prompt: datum.usageMetadata?.promptTokenCount || 0,
            completion: datum.usageMetadata?.candidatesTokenCount || 0,
          };

          const guardrails: GuardrailResponse = {
            flagged: true,
            flaggedInput: true,
            flaggedOutput: false,
            reason: blockReasonMessage,
          };

          return {
            output: blockReasonMessage,
            tokenUsage,
            guardrails,
            metadata: {
              modelArmor: isModelArmor
                ? {
                    blockReason: datum.promptFeedback.blockReason,
                    ...(datum.promptFeedback.blockReasonMessage && {
                      blockReasonMessage: datum.promptFeedback.blockReasonMessage,
                    }),
                  }
                : undefined,
            },
          };
        }

        if (Array.isArray(data) && isNonCandidateStreamChunk(datum)) {
          continue;
        }

        const candidate = getCandidate(datum);
        const safetyFinishReasons = [
          'SAFETY',
          'PROHIBITED_CONTENT',
          'RECITATION',
          'BLOCKLIST',
          'SPII',
          'IMAGE_SAFETY',
        ];

        if (candidate.finishReason && safetyFinishReasons.includes(candidate.finishReason)) {
          const finishReason = `Content was blocked due to safety settings with finish reason: ${candidate.finishReason}.`;
          const tokenUsage = {
            total: datum.usageMetadata?.totalTokenCount || 0,
            prompt: datum.usageMetadata?.promptTokenCount || 0,
            completion: datum.usageMetadata?.candidatesTokenCount || 0,
          };
          const guardrails: GuardrailResponse = {
            flagged: true,
            flaggedInput: false,
            flaggedOutput: true,
            reason: finishReason,
          };
          const safetyResponse = {
            tokenUsage,
            guardrails,
            raw: data,
            cached,
          };
          if (shouldExposeSafetyBlockAsOutput(context)) {
            // Assertions must receive safety refusals as scorable provider outputs.
            return { output: finishReason, ...safetyResponse };
          }
          return { error: finishReason, ...safetyResponse };
        } else if (candidate.finishReason && candidate.finishReason === 'MAX_TOKENS') {
          // MAX_TOKENS is treated as a successful completion
          if (candidate.content?.parts) {
            output = mergeParts(output, formatCandidateContents(candidate));
          }
        } else if (candidate.finishReason && candidate.finishReason !== 'STOP') {
          return {
            error: `Finish reason ${candidate.finishReason}: ${JSON.stringify(data)}`,
          };
        } else if (candidate.content?.parts) {
          output = mergeParts(output, formatCandidateContents(candidate));
        }
      }

      if (output === undefined) {
        return {
          error: `No output found in response: ${JSON.stringify(data)}`,
        };
      }

      const lastData = dataWithResponse[dataWithResponse.length - 1];
      const tokenUsage: TokenUsage = cached
        ? {
            cached: lastData.usageMetadata?.totalTokenCount,
            total: lastData.usageMetadata?.totalTokenCount,
            numRequests: 1,
            ...(lastData.usageMetadata?.thoughtsTokenCount !== undefined && {
              completionDetails: {
                reasoning: lastData.usageMetadata.thoughtsTokenCount,
                acceptedPrediction: 0,
                rejectedPrediction: 0,
              },
            }),
          }
        : {
            prompt:
              lastData.usageMetadata?.promptTokenCount === undefined
                ? undefined
                : lastData.usageMetadata.promptTokenCount +
                  (lastData.usageMetadata?.toolUsePromptTokenCount ?? 0),
            completion: lastData.usageMetadata?.candidatesTokenCount,
            total: lastData.usageMetadata?.totalTokenCount,
            numRequests: 1,
            ...(lastData.usageMetadata?.cachedContentTokenCount !== undefined && {
              cached: lastData.usageMetadata.cachedContentTokenCount,
            }),
            ...(lastData.usageMetadata?.thoughtsTokenCount !== undefined && {
              completionDetails: {
                reasoning: lastData.usageMetadata.thoughtsTokenCount,
                acceptedPrediction: 0,
                rejectedPrediction: 0,
              },
            }),
          };

      let guardrails: GuardrailResponse | undefined;
      const lastDataWithCandidate =
        dataWithResponse.filter((datum) => datum.candidates?.length).at(-1) ?? lastData;
      const candidate = getCandidate(lastDataWithCandidate);
      const promptSafetyRatings = getLastPromptSafetyRatings(dataWithResponse);
      if (promptSafetyRatings || candidate.safetyRatings) {
        const flaggedInput = promptSafetyRatings?.some((r) => r.probability !== 'NEGLIGIBLE');
        const flaggedOutput = candidate.safetyRatings?.some((r) => r.probability !== 'NEGLIGIBLE');
        const flagged = flaggedInput || flaggedOutput;
        guardrails = { flaggedInput, flaggedOutput, flagged };
      }

      const grounding = collectGroundingMetadata(dataWithResponse);

      // Include thinking tokens in output cost - Google bills them as output tokens
      const completionForCost =
        tokenUsage.completion == null
          ? undefined
          : tokenUsage.completion + (lastData.usageMetadata?.thoughtsTokenCount ?? 0);
      const cost = cached
        ? undefined
        : calculateGoogleCostFromUsage(
            this.modelName,
            this.isVertexMode ? { ...config, region: this.getRegion() } : config,
            lastData.usageMetadata?.promptTokenCount,
            completionForCost,
            this.isVertexMode,
            lastData.usageMetadata,
          );
      const audio = normalizeGeminiAudio(output);

      const response: ProviderResponse = {
        output,
        ...(audio && { audio }),
        tokenUsage,
        cost,
        raw: data,
        cached,
        ...(guardrails && { guardrails }),
        metadata: { ...grounding },
      };

      // Handle function tool callbacks
      if (!toolsDisabled && config.functionToolCallbacks && typeof output === 'string') {
        try {
          const parsed = JSON.parse(output);
          if (parsed.functionCall) {
            const functionName = parsed.functionCall.name;
            if (config.functionToolCallbacks[functionName]) {
              const functionResult = await this.executeFunctionCallback(
                functionName,
                JSON.stringify(
                  typeof parsed.functionCall.args === 'string'
                    ? JSON.parse(parsed.functionCall.args)
                    : parsed.functionCall.args,
                ),
                config,
                parsed.functionCall.id,
              );
              response.output = functionResult;
            }
          }
        } catch {
          // Not JSON or no function call, ignore
        }
      }

      return response;
    } catch (err) {
      return {
        error: `Gemini API response error: ${String(err)}. Response data: ${JSON.stringify(data)}`,
      };
    }
  }

  // cleanup() is inherited from GoogleGenericProvider
}
