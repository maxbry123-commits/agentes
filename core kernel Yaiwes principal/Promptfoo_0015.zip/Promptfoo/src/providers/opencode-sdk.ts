import { createRequire } from 'node:module';
import fs from 'fs';
import fsPromises from 'fs/promises';
import os from 'os';
import path from 'path';

import dedent from 'dedent';
import cliState from '../cliState';
import { getEnvString } from '../envars';
import { importModule } from '../esm';
import logger, { getLogLevel } from '../logger';
import {
  cacheResponse,
  generateCacheKey,
  getCachedResponse,
  initializeAgenticCache,
  resolveAgenticWorkingDir,
} from './agentic-utils';

import type { EnvOverrides } from '../types/env';
import type {
  ApiProvider,
  CallApiContextParams,
  CallApiOptionsParams,
  ProviderResponse,
  SkillCallEntry,
} from '../types/index';

/**
 * OpenCode SDK Provider
 *
 * This provider requires the @opencode-ai/sdk package, which is not installed by default.
 * Users must install it separately:
 *   npm install @opencode-ai/sdk
 *
 * OpenCode is an open-source AI coding agent for the terminal with support for 75+ LLM providers.
 *
 * Key features:
 * - Client-server architecture with local server management
 * - Support for 75+ LLM providers (Anthropic, OpenAI, Google, Ollama, etc.)
 * - Built-in tools (bash, read, write, edit, grep, glob, etc.)
 * - Session-based conversations with persistence
 * - MCP server integration
 * - Custom agent definitions
 *
 * Default configurations:
 * - No working_dir: Runs in temp directory with no tools (chat-only mode)
 * - With working_dir: Runs in specified directory with read-only tools (read, grep, glob, list)
 *
 * For side effects (file writes, bash commands), configure tools and permissions explicitly.
 */

// Default read-only tools when working_dir is specified (alphabetically sorted)
export const FS_READONLY_TOOLS = ['glob', 'grep', 'list', 'read'];

const EDIT_TOOL_ALIASES = new Set(['edit', 'write', 'patch', 'apply_patch']);

/**
 * Tool configuration for OpenCode SDK
 */
export interface OpenCodeToolConfig {
  bash?: boolean;
  edit?: boolean;
  write?: boolean;
  read?: boolean;
  grep?: boolean;
  glob?: boolean;
  list?: boolean;
  patch?: boolean;
  todowrite?: boolean;
  todoread?: boolean;
  webfetch?: boolean;
  /** Prompt user for input during execution */
  question?: boolean;
  /** Load SKILL.md files into conversation */
  skill?: boolean;
  /** Code intelligence queries (experimental - requires OPENCODE_EXPERIMENTAL_LSP_TOOL=true) */
  lsp?: boolean;
  [key: string]: boolean | undefined; // Plugin/MCP tools, e.g. <server>_<tool>
}

/**
 * Permission value type - simple or pattern-based
 * Pattern-based permissions use glob patterns as keys (e.g., "*.ts": "allow")
 */
export type OpenCodePermissionValue =
  | 'ask'
  | 'allow'
  | 'deny'
  | Record<string, 'ask' | 'allow' | 'deny'>;

/**
 * Permission configuration for specific tools
 *
 * Supports both simple values ('ask', 'allow', 'deny') and pattern-based
 * configuration using glob patterns for granular control.
 *
 * @example
 * ```yaml
 * permission:
 *   bash: allow  # Simple: allow all bash commands
 *   edit:
 *     "*.md": allow      # Pattern: allow editing markdown files
 *     "src/**": ask      # Pattern: ask for src directory
 *   external_directory: deny  # Deny access outside working dir
 * ```
 */
export interface OpenCodePermissionConfig {
  /** Shell command execution permission */
  bash?: OpenCodePermissionValue;
  /** File editing permission */
  edit?: OpenCodePermissionValue;
  /** File read permission */
  read?: OpenCodePermissionValue;
  /** File glob permission */
  glob?: OpenCodePermissionValue;
  /** File grep permission */
  grep?: OpenCodePermissionValue;
  /** File list permission */
  list?: OpenCodePermissionValue;
  /** Subtask execution permission */
  task?: OpenCodePermissionValue;
  /** LSP code intelligence permission */
  lsp?: OpenCodePermissionValue;
  /** SKILL.md loading permission */
  skill?: OpenCodePermissionValue;
  /** Web fetching permission */
  webfetch?: OpenCodePermissionValue;
  /** Web search permission */
  websearch?: OpenCodePermissionValue;
  /** Codebase search permission */
  codesearch?: OpenCodePermissionValue;
  /** Todo list write permission */
  todowrite?: OpenCodePermissionValue;
  /** Interactive question permission */
  question?: OpenCodePermissionValue;
  /** Prevents infinite agent loops (added in v1.1.1) */
  doom_loop?: OpenCodePermissionValue;
  /** Access to directories outside the working directory (added in v1.1.1) */
  external_directory?: OpenCodePermissionValue;
  /** Forward-compatible escape hatch for tools added upstream */
  [key: string]: OpenCodePermissionValue | undefined;
}

/**
 * Single permission rule passed to OpenCode v2 `session.create`.
 *
 * The v2 SDK types permission as `PermissionRuleset = Array<PermissionRule>`,
 * so promptfoo converts the user-facing `OpenCodePermissionConfig` object
 * shape into this rule-array shape before calling the server.
 */
export interface OpenCodePermissionRule {
  permission: string;
  pattern: string;
  action: 'ask' | 'allow' | 'deny';
}

/**
 * Custom agent configuration
 *
 * Defines a specialized agent with specific capabilities, model settings,
 * and tool access controls.
 */
export interface OpenCodeAgentConfig {
  /** Required description explaining the agent's purpose */
  description: string;
  /** Agent mode: 'primary' for main assistants, 'subagent' for specialized tasks, 'all' for both */
  mode?: 'primary' | 'subagent' | 'all';
  /** Model ID to use for this agent (overrides global model) */
  model?: string;
  /** Temperature for response randomness (0.0-1.0) */
  temperature?: number;
  /** Nucleus sampling parameter (0.0-1.0) */
  top_p?: number;
  /** Tool configuration for this agent */
  tools?: OpenCodeToolConfig;
  /** Permission configuration for this agent */
  permission?: OpenCodePermissionConfig;
  /** Custom system prompt for the agent */
  prompt?: string;
  /**
   * Maximum agentic iterations before forcing text-only response
   * @deprecated Use `steps` instead (deprecated in v1.1.1)
   */
  maxSteps?: number;
  /** Maximum agentic iterations before forcing text-only response (replaces maxSteps) */
  steps?: number;
  /** Hex color code for visual identification (e.g., "#ff5500") */
  color?: string;
  /** Disable this agent */
  disable?: boolean;
  /** Hide this agent from @ autocomplete (subagents only) */
  hidden?: boolean;
}

/**
 * MCP local server configuration
 */
export interface OpenCodeMCPLocalConfig {
  type: 'local';
  command: string[];
  environment?: Record<string, string>;
  enabled?: boolean;
  timeout?: number;
}

/**
 * OAuth configuration for MCP remote servers
 */
export interface OpenCodeMCPOAuthConfig {
  /** OAuth client ID */
  clientId: string;
  /** OAuth client secret */
  clientSecret?: string;
  /** OAuth scope(s) to request */
  scope?: string;
}

/**
 * MCP remote server configuration
 */
export interface OpenCodeMCPRemoteConfig {
  type: 'remote';
  url: string;
  headers?: Record<string, string>;
  /** OAuth configuration for authenticated MCP servers */
  oauth?: OpenCodeMCPOAuthConfig;
  enabled?: boolean;
  timeout?: number;
}

/**
 * MCP server configuration (local or remote)
 */
export type OpenCodeMCPServerConfig = OpenCodeMCPLocalConfig | OpenCodeMCPRemoteConfig;

export interface OpenCodeOutputFormatText {
  type: 'text';
}

export interface OpenCodeOutputFormatJsonSchema {
  type: 'json_schema';
  schema: Record<string, unknown>;
  retryCount?: number;
}

export type OpenCodeOutputFormat = OpenCodeOutputFormatText | OpenCodeOutputFormatJsonSchema;

/**
 * OpenCode SDK Provider Configuration
 */
export interface OpenCodeSDKConfig {
  /**
   * API key for the underlying LLM provider (e.g., Anthropic, OpenAI)
   * Falls back to provider-specific environment variables
   */
  apiKey?: string;

  /**
   * LLM provider ID (e.g., 'anthropic', 'openai', 'google', 'ollama')
   * Used for model selection and API key resolution
   */
  provider_id?: string;

  /**
   * Model ID to use (e.g., 'claude-sonnet-4-20250514', 'gpt-4o')
   * Combined with provider_id to specify the exact model
   */
  model?: string;

  /**
   * Base URL for connecting to an existing OpenCode server
   * If not specified, the provider will start its own server
   */
  baseUrl?: string;

  /**
   * Hostname for the OpenCode server (when starting a new server)
   * @default '127.0.0.1'
   */
  hostname?: string;

  /**
   * Port for the OpenCode server (when starting a new server)
   * @default 0 (random available port)
   */
  port?: number;

  /**
   * Timeout for server startup in milliseconds
   * @default 30000
   */
  timeout?: number;

  /**
   * Working directory for OpenCode to operate in
   * If not specified, uses a temporary directory
   */
  working_dir?: string;

  /**
   * Workspace identifier for OpenCode v2 workspace-aware APIs
   * Requires either working_dir or baseUrl
   */
  workspace?: string;

  /**
   * Tool configuration - enable/disable specific tools
   * When working_dir is set, defaults to read-only tools
   */
  tools?: OpenCodeToolConfig;

  /**
   * Permission configuration for tools
   * Controls whether tools require confirmation
   */
  permission?: OpenCodePermissionConfig;

  /**
   * Built-in agent to use ('build', 'plan', etc.)
   */
  agent?: string;

  /**
   * Output format for model responses
   * Supports plain text and JSON Schema-constrained responses
   */
  format?: OpenCodeOutputFormat;

  /**
   * Provider/model variant to use when OpenCode provider config defines variants
   */
  variant?: string;

  /**
   * Custom agent configuration
   */
  custom_agent?: OpenCodeAgentConfig;

  /**
   * Session ID to resume an existing session
   */
  session_id?: string;

  /**
   * Parent session ID for forked sessions (v2 only).
   * When set, the new session is created as a child fork of the given parent,
   * inheriting its compacted history. Ignored on the v1 SDK and when
   * `session_id` is provided (resumed sessions never fork on create).
   *
   * Tied to the upstream fix in opencode 1.14.30 that keeps compacted history
   * intact for forked sessions.
   */
  parent_session_id?: string;

  /**
   * Keep sessions alive between calls
   */
  persist_sessions?: boolean;

  /**
   * MCP server configuration
   */
  mcp?: Record<string, OpenCodeMCPServerConfig>;

  /**
   * When true, enables caching even when MCP servers are configured.
   * Use this when your MCP tools are deterministic (e.g., code search, static knowledge bases).
   * Different MCP configurations will produce different cache keys.
   * @default false
   */
  cache_mcp?: boolean;

  /**
   * Maximum retries for API calls
   * @default 2
   */
  max_retries?: number;

  /**
   * Log level for the SDK
   * @default 'warn'
   */
  log_level?: 'debug' | 'info' | 'warn' | 'error' | 'off';

  /**
   * Reserved for future SSE-based streaming support.
   * Currently a no-op for the OpenCode SDK provider; setting it logs a warning.
   * Use the `openai:codex-sdk` provider if you need streaming today.
   * @default false
   */
  enable_streaming?: boolean;
}

/**
 * Check if promptfoo is in debug mode
 */
function isDebugMode(): boolean {
  return getLogLevel() === 'debug';
}

/**
 * Maximum number of sessions to keep in memory to prevent unbounded growth
 */
const MAX_SESSIONS = 100;

/**
 * OpenCode SDK client interface
 */
interface OpenCodeClient {
  session: {
    create: (
      parameters: Record<string, unknown>,
    ) => Promise<OpenCodeSdkResult<Record<string, unknown>>>;
    prompt: (
      parameters: Record<string, unknown>,
    ) => Promise<OpenCodeSdkResult<OpenCodePromptResponse>>;
    delete: (parameters: Record<string, unknown>) => Promise<unknown>;
    abort?: (parameters: Record<string, unknown>) => Promise<unknown>;
  };
}

/**
 * OpenCode SDK server interface
 */
interface OpenCodeServer {
  url: string;
  close(): void;
}

/**
 * OpenCode SDK module interface
 */
interface OpenCodeSDKModule {
  createOpencode: (options: {
    hostname?: string;
    port?: number;
    timeout?: number;
    config?: Record<string, unknown>;
    env?: Record<string, string>;
  }) => Promise<{ client: OpenCodeClient; server: OpenCodeServer }>;
  createOpencodeClient: (options: { baseUrl: string }) => OpenCodeClient;
}

interface LoadedOpenCodeSDKModule extends OpenCodeSDKModule {
  apiVersion: 'v1' | 'v2';
}

interface OpenCodeSessionQuery {
  directory?: string;
  workspace?: string;
}

interface OpenCodeSessionPath {
  id: string;
  sessionID: string;
}

interface OpenCodeSessionHandle {
  id: string;
  query?: OpenCodeSessionQuery;
}

interface OpenCodePreparedCall {
  config: OpenCodeSDKConfig;
  isTempDir: boolean;
  workingDir?: string;
}

interface OpenCodeSessionContext {
  sessionId: string;
  sessionQuery?: OpenCodeSessionQuery;
  ephemeralSession?: OpenCodeSessionHandle;
}

type OpenCodeTokenCache =
  | number
  | {
      read?: number;
      write?: number;
    };

interface OpenCodeAssistantMessage {
  tokens?: {
    total?: number;
    input?: number;
    output?: number;
    reasoning?: number;
    cache?: OpenCodeTokenCache;
  };
  cost?: number;
  structured?: unknown;
}

interface OpenCodePromptPart {
  type: string;
  text?: string;
  tool?: string;
  state?: {
    status?: string;
    input?: Record<string, unknown>;
    metadata?: Record<string, unknown>;
  };
}

interface OpenCodePromptResponse {
  info?: OpenCodeAssistantMessage;
  parts?: OpenCodePromptPart[];
}

type OpenCodeSdkResult<T> =
  | T
  | {
      data?: T;
      error?: unknown;
    };

/**
 * Resolve ESM-only package entry point by reading package.json exports
 * Handles packages that only have "import" condition (no "require" condition)
 *
 * @param packageName - The package name (e.g., '@opencode-ai/sdk')
 * @param basePath - Base path for resolution
 * @returns Absolute path to the ESM entry point
 */
function resolveEsmPackage(
  packageName: string,
  exportPath: '.' | './v2',
  basePath: string,
): string {
  const require = createRequire(path.join(basePath, 'package.json'));

  // Try to find package.json using require.resolve with package.json subpath
  // This handles monorepos, workspaces, pnpm, etc.
  let packageJsonPath: string;
  try {
    packageJsonPath = require.resolve(`${packageName}/package.json`);
  } catch {
    // Fallback: construct direct path for simple node_modules structure
    packageJsonPath = path.join(
      basePath,
      'node_modules',
      ...packageName.split('/'),
      'package.json',
    );
    if (!fs.existsSync(packageJsonPath)) {
      throw new Error(`Cannot find ${packageName}/package.json`);
    }
  }

  const packageDir = path.dirname(packageJsonPath);
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));

  // Extract ESM entry point from exports field
  let esmEntry: string | undefined;

  if (packageJson.exports) {
    const mainExport =
      packageJson.exports[exportPath] ||
      (exportPath === '.' ? packageJson.exports['.'] || packageJson.exports : undefined);
    if (typeof mainExport === 'string') {
      esmEntry = mainExport;
    } else if (typeof mainExport === 'object') {
      // Prefer "import" condition for ESM
      esmEntry = mainExport.import || mainExport.default;
    }
  }

  // Fallback to module or main field
  if (!esmEntry) {
    esmEntry = packageJson.module || packageJson.main;
  }

  if (!esmEntry) {
    throw new Error(`Cannot find ESM entry point in ${packageName}/package.json`);
  }

  return path.join(packageDir, esmEntry);
}

function unwrapOpenCodeResult<T>(result: OpenCodeSdkResult<T> | undefined): T | undefined {
  if (result === undefined || result === null) {
    return undefined;
  }
  if (typeof result === 'object' && 'data' in result) {
    return result.data as T | undefined;
  }
  return result as T;
}

function getOpenCodeCacheDetails(cache: OpenCodeTokenCache | undefined): {
  read: number;
  write: number;
} {
  if (typeof cache === 'number') {
    return { read: cache, write: 0 };
  }
  if (!cache || typeof cache !== 'object') {
    return { read: 0, write: 0 };
  }
  return {
    read: cache.read ?? 0,
    write: cache.write ?? 0,
  };
}

function buildOpenCodeTokenUsage(
  tokens: OpenCodeAssistantMessage['tokens'],
): ProviderResponse['tokenUsage'] {
  if (!tokens) {
    return undefined;
  }

  const prompt = tokens.input ?? 0;
  const completion = tokens.output ?? 0;
  const cache = getOpenCodeCacheDetails(tokens.cache);
  const completionDetails: NonNullable<ProviderResponse['tokenUsage']>['completionDetails'] = {};

  if (typeof tokens.reasoning === 'number') {
    completionDetails.reasoning = tokens.reasoning;
  }
  if (tokens.cache !== undefined) {
    completionDetails.cacheReadInputTokens = cache.read;
    completionDetails.cacheCreationInputTokens = cache.write;
  }

  return {
    prompt,
    completion,
    total: tokens.total ?? prompt + completion,
    ...(tokens.cache === undefined ? {} : { cached: cache.read }),
    ...(Object.keys(completionDetails).length > 0 ? { completionDetails } : {}),
  };
}

function getSessionPath(sessionId: string): OpenCodeSessionPath {
  return {
    id: sessionId,
    sessionID: sessionId,
  };
}

/**
 * Convert the user-facing object-shaped permission config into the
 * rule-array shape required by the v2 `session.create.permission` API.
 *
 * - `{ bash: 'allow' }` → `[{ permission: 'bash', pattern: '*', action: 'allow' }]`
 * - `{ bash: { '*': 'ask', 'git *': 'allow' } }` → two rules with the
 *   corresponding glob pattern preserved per entry.
 *
 * Returns `undefined` when the config has no usable entries so callers can
 * omit the field entirely.
 */
export function convertPermissionConfigToRuleset(
  config: OpenCodePermissionConfig | undefined,
): OpenCodePermissionRule[] | undefined {
  if (config === undefined) {
    return undefined;
  }
  if (
    !config ||
    typeof config !== 'object' ||
    Array.isArray(config) ||
    ![Object.prototype, null].includes(Object.getPrototypeOf(config))
  ) {
    throw new Error('OpenCode permission must be an object mapping tools to permission rules');
  }

  const rules: OpenCodePermissionRule[] = [];
  for (const [tool, value] of Object.entries(config)) {
    if (value === undefined) {
      continue;
    }
    if (isOpenCodePermissionAction(value)) {
      rules.push({ permission: tool, pattern: '*', action: value });
      continue;
    }

    if (
      !value ||
      typeof value !== 'object' ||
      Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value))
    ) {
      throw new Error(`OpenCode permission.${tool} must be ask, allow, deny, or a pattern mapping`);
    }

    for (const [pattern, action] of Object.entries(value)) {
      if (!isOpenCodePermissionAction(action)) {
        throw new Error(`OpenCode permission.${tool}.${pattern} must be ask, allow, or deny`);
      }
      rules.push({ permission: tool, pattern, action });
    }
  }
  return rules.length > 0 ? rules : undefined;
}

function isOpenCodePermissionAction(value: unknown): value is 'ask' | 'allow' | 'deny' {
  return value === 'ask' || value === 'allow' || value === 'deny';
}

function convertToolsConfigToRuleset(config: OpenCodeToolConfig): OpenCodePermissionRule[] {
  return Object.entries(config).map(([permission, enabled]) => ({
    permission,
    pattern: '*',
    action: enabled ? 'allow' : 'deny',
  }));
}

function openCodeMcpContainsCacheSensitiveData(
  config: Record<string, OpenCodeMCPServerConfig> | undefined,
): boolean {
  return Object.values(config ?? {}).some((server) => {
    if (
      (server.type === 'local' &&
        (Object.keys(server.environment ?? {}).length > 0 || server.command.length > 1)) ||
      (server.type === 'remote' &&
        (Object.keys(server.headers ?? {}).length > 0 || server.oauth !== undefined))
    ) {
      return true;
    }
    if (server.type !== 'remote') {
      return false;
    }
    try {
      const url = new URL(server.url);
      return Boolean(url.username || url.password || url.search);
    } catch {
      return server.url.includes('?') || server.url.includes('@');
    }
  });
}

function openCodeBaseUrlContainsCacheSensitiveData(baseUrl: string | undefined): boolean {
  if (!baseUrl) {
    return false;
  }
  try {
    const url = new URL(baseUrl);
    return Boolean(url.username || url.password || url.search);
  } catch {
    return baseUrl.includes('?') || baseUrl.includes('@');
  }
}

function getCacheSafeOpenCodeBaseUrl(baseUrl: string | undefined): string | undefined {
  if (!baseUrl || !openCodeBaseUrlContainsCacheSensitiveData(baseUrl)) {
    return baseUrl;
  }
  try {
    const url = new URL(baseUrl);
    url.username = '';
    url.password = '';
    url.search = '';
    return url.toString();
  } catch {
    return undefined;
  }
}

function tryParseJson(value: string): string | undefined {
  try {
    return JSON.stringify(JSON.parse(value));
  } catch {
    return undefined;
  }
}

function normalizeStructuredText(value: string): string | undefined {
  const trimmedValue = value.trim();
  const directJson = tryParseJson(trimmedValue);
  if (directJson) {
    return directJson;
  }

  const fencedJsonMatch = trimmedValue.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (!fencedJsonMatch?.[1]) {
    return undefined;
  }

  return tryParseJson(fencedJsonMatch[1]);
}

/**
 * Helper to load the OpenCode SDK ESM module
 *
 * Uses a two-phase approach:
 * 1. Try simple dynamic import - works when SDK is in same node_modules tree
 * 2. Fall back to smart ESM resolution for edge cases (pnpm, global installs, monorepos)
 */
async function loadOpenCodeSDK(): Promise<LoadedOpenCodeSDKModule> {
  const directImports = [
    { specifier: '@opencode-ai/sdk/v2', exportPath: './v2' as const, apiVersion: 'v2' as const },
    { specifier: '@opencode-ai/sdk', exportPath: '.' as const, apiVersion: 'v1' as const },
  ];

  for (const candidate of directImports) {
    try {
      logger.debug(`Attempting dynamic import of ${candidate.specifier}`);
      const module = (await import(candidate.specifier)) as unknown as OpenCodeSDKModule;
      return { ...module, apiVersion: candidate.apiVersion };
    } catch (error) {
      logger.debug(`Dynamic import failed for ${candidate.specifier}`, { error });
    }
  }

  const basePath =
    cliState.basePath && path.isAbsolute(cliState.basePath) ? cliState.basePath : process.cwd();

  for (const candidate of directImports) {
    try {
      const modulePath = resolveEsmPackage('@opencode-ai/sdk', candidate.exportPath, basePath);
      logger.debug(`Resolved OpenCode SDK path (${candidate.apiVersion}): ${modulePath}`);
      const module = (await importModule(modulePath)) as OpenCodeSDKModule;
      return { ...module, apiVersion: candidate.apiVersion };
    } catch (error) {
      logger.debug(`Smart resolution failed for ${candidate.specifier}`, { error });
    }
  }

  const err = new Error('Failed to resolve @opencode-ai/sdk');
  logger.error(`Failed to load OpenCode SDK: ${err}`);
  throw new Error(
    dedent`The @opencode-ai/sdk package is required but not installed.

    To use the OpenCode SDK provider, install it with:
      npm install @opencode-ai/sdk

    For more information, see: https://www.promptfoo.dev/docs/providers/opencode-sdk/`,
  );
}

export class OpenCodeSDKProvider implements ApiProvider {
  config: OpenCodeSDKConfig;
  env?: EnvOverrides;

  private providerId = 'opencode:sdk';
  private opencodeModule?: LoadedOpenCodeSDKModule;
  private client?: OpenCodeClient;
  private clientInitialization?: Promise<void>;
  private server?: OpenCodeServer;
  private sessions: Map<string, OpenCodeSessionHandle> = new Map(); // cacheKey -> session info
  private sessionOrder: string[] = []; // Track insertion order for LRU eviction
  private sessionQueues = new Map<string, Promise<void>>();
  private readonly credentialCacheScope = crypto.randomUUID();
  private streamingWarningEmitted = false;

  constructor(
    options: {
      id?: string;
      config?: OpenCodeSDKConfig;
      env?: EnvOverrides;
    } = {},
  ) {
    const { config, env, id } = options;
    this.config = config ?? {};
    this.env = env;
    this.providerId = id ?? this.providerId;
  }

  id(): string {
    return this.providerId;
  }

  /**
   * Get API key based on provider_id or common environment variables
   */
  getApiKey(config: OpenCodeSDKConfig = this.config): string | undefined {
    if (config?.apiKey) {
      return config.apiKey;
    }

    // Check provider-specific env vars based on provider_id
    const providerId = config?.provider_id?.toLowerCase();
    if (providerId === 'anthropic') {
      return this.env?.ANTHROPIC_API_KEY || getEnvString('ANTHROPIC_API_KEY');
    }
    if (providerId === 'openai') {
      return this.env?.OPENAI_API_KEY || getEnvString('OPENAI_API_KEY');
    }
    if (providerId === 'google') {
      return this.env?.GOOGLE_API_KEY || getEnvString('GOOGLE_API_KEY');
    }

    // Fall back to common env vars
    return (
      this.env?.ANTHROPIC_API_KEY ||
      getEnvString('ANTHROPIC_API_KEY') ||
      this.env?.OPENAI_API_KEY ||
      getEnvString('OPENAI_API_KEY')
    );
  }

  private getCredentialCacheScope(config: OpenCodeSDKConfig): string | undefined {
    return config.baseUrl ? undefined : this.credentialCacheScope;
  }

  toString(): string {
    return '[OpenCode SDK Provider]';
  }

  async cleanup(): Promise<void> {
    await this.clientInitialization?.catch(() => undefined);
    this.clientInitialization = undefined;
    for (const session of this.sessions.values()) {
      try {
        await this.deleteSession(session);
      } catch (err) {
        logger.debug(`Failed to delete persistent session ${session.id}: ${err}`);
      }
    }
    this.sessions.clear();
    this.sessionOrder = [];
    this.sessionQueues.clear();

    // Close server if we started one
    if (this.server) {
      try {
        this.server.close();
      } catch (err) {
        logger.debug(`Failed to close OpenCode server: ${err}`);
      }
      this.server = undefined;
    }
    this.client = undefined;
  }

  /**
   * Build the tools configuration based on config and defaults
   */
  private buildToolsConfig(config: OpenCodeSDKConfig, includeDefaults = true): OpenCodeToolConfig {
    const configuredTools = config.tools;
    if (
      configuredTools !== undefined &&
      (!configuredTools ||
        typeof configuredTools !== 'object' ||
        Array.isArray(configuredTools) ||
        ![Object.prototype, null].includes(Object.getPrototypeOf(configuredTools)))
    ) {
      throw new Error('OpenCode tools must be an object mapping tool names to booleans');
    }

    const entries = new Map<string, boolean>();
    if (includeDefaults) {
      // OpenCode permissions use last-match-wins. A wildcard deny keeps future,
      // plugin, and MCP tools disabled unless the user explicitly enables them.
      entries.set('*', false);
      if (config.working_dir) {
        for (const tool of FS_READONLY_TOOLS) {
          entries.set(tool, true);
        }
      }
    }

    let editPermission: boolean | undefined;
    for (const [tool, enabled] of Object.entries(configuredTools ?? {})) {
      if (enabled === undefined) {
        continue;
      }
      if (typeof enabled !== 'boolean') {
        throw new Error(`OpenCode tools.${tool} must be a boolean`);
      }
      if (!tool.trim()) {
        throw new Error('OpenCode tool names must not be empty');
      }
      if (EDIT_TOOL_ALIASES.has(tool)) {
        if (editPermission !== undefined && editPermission !== enabled) {
          throw new Error(
            'OpenCode tools edit, write, patch, and apply_patch share one permission and cannot conflict',
          );
        }
        editPermission = enabled;
        continue;
      }
      entries.set(tool, enabled);
    }
    if (editPermission !== undefined) {
      entries.set('edit', editPermission);
    }

    return Object.fromEntries(entries);
  }

  private buildEffectiveToolsConfig(config: OpenCodeSDKConfig): OpenCodeToolConfig {
    const customAgent = config.agent ? undefined : config.custom_agent;
    const tools = new Map<string, boolean>();
    for (const [tool, enabled] of Object.entries(this.buildToolsConfig(config))) {
      if (enabled !== undefined) {
        tools.set(tool, enabled);
      }
    }
    for (const [tool, enabled] of Object.entries(
      this.buildToolsConfig({ ...config, tools: customAgent?.tools }, false),
    )) {
      if (enabled !== undefined) {
        tools.delete(tool);
        tools.set(tool, enabled);
      }
    }
    return Object.fromEntries(tools);
  }

  private buildConfiguredPermissionRules(config: OpenCodeSDKConfig): OpenCodePermissionRule[] {
    const customAgent = config.agent ? undefined : config.custom_agent;
    return [
      ...(convertPermissionConfigToRuleset(config.permission) ?? []),
      ...(convertPermissionConfigToRuleset(customAgent?.permission) ?? []),
    ];
  }

  private buildQuery(
    config: OpenCodeSDKConfig,
    workingDir: string | undefined,
  ): OpenCodeSessionQuery | undefined {
    const query: OpenCodeSessionQuery = {};

    if (config.working_dir && workingDir) {
      query.directory = workingDir;
    }
    if (config.workspace) {
      query.workspace = config.workspace;
    }

    return Object.keys(query).length > 0 ? query : undefined;
  }

  // Shared by buildSessionKey and the response cache key so they cannot drift.
  // Includes anything that changes which conversation history or model behavior
  // the server applies for a prompt.
  private historyAffectingInputs(config: OpenCodeSDKConfig): Record<string, unknown> {
    return {
      provider_id: config.provider_id,
      model: config.model,
      baseUrl: getCacheSafeOpenCodeBaseUrl(config.baseUrl),
      tools: this.buildToolsConfig(config),
      permission: config.permission,
      agent: config.agent,
      custom_agent: config.custom_agent,
      workspace: config.workspace,
      format: config.format,
      variant: config.variant,
      session_id: config.session_id,
      toolPolicyContractVersion: 2,
      parent_session_id: config.parent_session_id,
      credentialScope: this.getCredentialCacheScope(config),
      apiVersion: this.opencodeModule?.apiVersion,
    };
  }

  private buildSessionKey(config: OpenCodeSDKConfig, workingDir: string | undefined): string {
    return generateCacheKey('opencode:sdk:session', {
      ...this.historyAffectingInputs(config),
      workingDir: config.working_dir ? workingDir : undefined,
      mcp: config.mcp,
    });
  }

  private buildServerEnv(config: OpenCodeSDKConfig): Record<string, string> {
    const serverEnv: Record<string, string> = {};

    for (const [key, value] of Object.entries(process.env)) {
      if (value !== undefined) {
        serverEnv[key] = value;
      }
    }

    if (this.env) {
      for (const key of Object.keys(this.env).sort()) {
        const value = this.env[key];
        if (value !== undefined) {
          serverEnv[key] = value;
        }
      }
    }

    if (config.log_level === 'debug' || isDebugMode()) {
      serverEnv.DEBUG = serverEnv.DEBUG || 'opencode:*';
      logger.debug('[OpenCode SDK] Debug mode enabled, synced from promptfoo log level');
    }

    const homeDir = os.homedir();
    const opencodeBinPath = path.join(homeDir, '.opencode', 'bin');
    if (!serverEnv.PATH?.includes(opencodeBinPath)) {
      serverEnv.PATH = `${opencodeBinPath}:${serverEnv.PATH ?? ''}`;
      logger.debug(`Added ${opencodeBinPath} to PATH for OpenCode CLI`);
    }

    return serverEnv;
  }

  private buildServerConfig(config: OpenCodeSDKConfig): Record<string, unknown> {
    const serverConfig: Record<string, unknown> = {};

    if (config.log_level) {
      serverConfig.logLevel = config.log_level;
    }

    if (config.mcp && Object.keys(config.mcp).length > 0) {
      serverConfig.mcp = config.mcp;
      logger.debug(`[OpenCode SDK] Configuring MCP servers: ${Object.keys(config.mcp).join(', ')}`);
    }

    if (config.custom_agent) {
      serverConfig.agent = {
        custom: {
          description: config.custom_agent.description,
          model: config.custom_agent.model,
          temperature: config.custom_agent.temperature,
          top_p: config.custom_agent.top_p,
          tools:
            config.custom_agent.tools === undefined
              ? undefined
              : this.buildToolsConfig({ ...config, tools: config.custom_agent.tools }, false),
          permission: config.custom_agent.permission,
          prompt: config.custom_agent.prompt,
          mode: config.custom_agent.mode ?? 'primary',
          maxSteps: config.custom_agent.steps ?? config.custom_agent.maxSteps,
          color: config.custom_agent.color,
          disable: config.custom_agent.disable,
          hidden: config.custom_agent.hidden,
        },
      };
      logger.debug(`[OpenCode SDK] Configuring custom agent: ${config.custom_agent.description}`);
    }

    if (config.permission) {
      serverConfig.permission = config.permission;
      logger.debug('[OpenCode SDK] Configuring global permissions');
    }

    const toolsConfig = this.buildToolsConfig(config);
    if (toolsConfig) {
      serverConfig.tools = toolsConfig;
    }

    if (config.provider_id && config.apiKey) {
      serverConfig.provider = {
        [config.provider_id]: {
          options: {
            apiKey: config.apiKey,
          },
        },
      };
      logger.debug(`[OpenCode SDK] Injecting provider apiKey for ${config.provider_id}`);
    }

    return serverConfig;
  }

  private warnOnIgnoredBaseUrlConfig(config: OpenCodeSDKConfig): void {
    if (!config.baseUrl) {
      return;
    }

    const ignoredSettings = [
      config.hostname === undefined ? undefined : 'hostname',
      config.port === undefined ? undefined : 'port',
      config.timeout === undefined ? undefined : 'timeout',
      config.log_level === undefined ? undefined : 'log_level',
      config.mcp ? 'mcp' : undefined,
      config.custom_agent ? 'custom_agent' : undefined,
      config.apiKey ? 'apiKey' : undefined,
    ].filter(Boolean);

    if (ignoredSettings.length > 0) {
      logger.warn(
        `[OpenCode SDK] baseUrl uses an existing OpenCode server. These config keys are ignored unless that server is preconfigured: ${ignoredSettings.join(', ')}`,
      );
    }
  }

  private buildDeleteSessionParameters(session: OpenCodeSessionHandle): Record<string, unknown> {
    if (!this.opencodeModule) {
      throw new Error('OpenCode SDK module is not loaded');
    }

    if (this.opencodeModule.apiVersion === 'v2') {
      return {
        sessionID: session.id,
        ...session.query,
      };
    }

    return {
      path: getSessionPath(session.id),
      query: session.query,
    };
  }

  private async deleteSession(session: OpenCodeSessionHandle | undefined): Promise<void> {
    if (!session) {
      return;
    }
    await this.client?.session?.delete?.(this.buildDeleteSessionParameters(session));
  }

  private buildAbortSessionParameters(
    sessionId: string,
    sessionQuery: OpenCodeSessionQuery | undefined,
  ): Record<string, unknown> {
    // session.abort is v2-only. v1 has no equivalent endpoint.
    return {
      sessionID: sessionId,
      ...sessionQuery,
    };
  }

  /**
   * Add a session to the cache with LRU eviction
   */
  private addSession(cacheKey: string, session: OpenCodeSessionHandle): void {
    // Remove oldest sessions if we've hit the limit
    while (this.sessions.size >= MAX_SESSIONS && this.sessionOrder.length > 0) {
      const oldestKey = this.sessionOrder.shift();
      if (oldestKey) {
        const oldSession = this.sessions.get(oldestKey);
        this.sessions.delete(oldestKey);
        // Best-effort cleanup of old session
        if (oldSession) {
          this.deleteSession(oldSession).catch((err) => {
            logger.debug(`Failed to delete evicted session ${oldSession.id}: ${err}`);
          });
        }
      }
    }
    this.sessions.set(cacheKey, session);
    this.sessionOrder.push(cacheKey);
  }

  private prepareCall(context?: CallApiContextParams): OpenCodePreparedCall {
    const config: OpenCodeSDKConfig = {
      ...this.config,
      ...context?.prompt?.config,
    };

    if (config.apiKey !== this.config.apiKey) {
      throw new Error(
        'OpenCode SDK apiKey is provider-level configuration and cannot be overridden per prompt',
      );
    }
    if (config.baseUrl !== this.config.baseUrl) {
      throw new Error(
        'OpenCode SDK baseUrl is provider-level configuration and cannot be overridden per prompt',
      );
    }

    if (config.workspace && !config.baseUrl && !config.working_dir) {
      throw new Error('OpenCode SDK workspace support requires either baseUrl or working_dir');
    }

    if (config.apiKey && !config.provider_id && !config.baseUrl) {
      logger.warn(
        '[OpenCode SDK] apiKey is set without provider_id. Prefer setting provider_id so promptfoo can wire the credential into the spawned OpenCode server.',
      );
    }

    this.warnOnIgnoredBaseUrlConfig(config);

    if (config.working_dir) {
      const workingDir =
        resolveAgenticWorkingDir(config.working_dir, cliState.basePath) ?? process.cwd();

      let stats: fs.Stats;
      try {
        stats = fs.statSync(workingDir);
      } catch (err: any) {
        throw new Error(
          `Working directory ${config.working_dir} (resolved to ${workingDir}) does not exist or isn't accessible: ${err.message}`,
        );
      }

      if (!stats.isDirectory()) {
        throw new Error(
          `Working directory ${config.working_dir} (resolved to ${workingDir}) is not a directory`,
        );
      }

      return {
        config,
        isTempDir: false,
        workingDir,
      };
    }

    return {
      config,
      isTempDir: true,
      workingDir: fs.mkdtempSync(path.join(os.tmpdir(), 'promptfoo-opencode-sdk-')),
    };
  }

  private async ensureOpenCodeModule(): Promise<LoadedOpenCodeSDKModule> {
    if (!this.opencodeModule) {
      this.opencodeModule = await loadOpenCodeSDK();
    }
    return this.opencodeModule;
  }

  private async ensureClient(config: OpenCodeSDKConfig): Promise<void> {
    const opencodeModule = await this.ensureOpenCodeModule();

    this.validateSessionPolicyConfiguration(config);

    if (this.client) {
      return;
    }
    if (this.clientInitialization !== undefined) {
      return this.clientInitialization;
    }

    const { createOpencode, createOpencodeClient } = opencodeModule;
    let initialization: Promise<void>;
    initialization = (async () => {
      if (config.baseUrl) {
        this.client = createOpencodeClient({
          baseUrl: config.baseUrl,
        });
        return;
      }

      const serverOptions: {
        hostname: string;
        port: number;
        timeout: number;
        config?: Record<string, unknown>;
        env?: Record<string, string>;
      } = {
        hostname: config.hostname ?? '127.0.0.1',
        port: config.port ?? 0,
        timeout: config.timeout ?? 30000,
        env: this.buildServerEnv(config),
      };

      const serverConfig = this.buildServerConfig(config);
      if (Object.keys(serverConfig).length > 0) {
        serverOptions.config = serverConfig;
      }

      const opencode = await createOpencode(serverOptions);
      this.client = opencode.client;
      this.server = opencode.server;
      logger.debug(`OpenCode server started at ${opencode.server.url}`);
    })();
    this.clientInitialization = initialization;
    try {
      await initialization;
    } finally {
      if (this.clientInitialization === initialization) {
        this.clientInitialization = undefined;
      }
    }
  }

  private validateSessionPolicyConfiguration(config: OpenCodeSDKConfig): void {
    if (!this.opencodeModule) {
      return;
    }

    const hasPermissionRules = this.buildConfiguredPermissionRules(config).length > 0;
    if (this.opencodeModule.apiVersion === 'v2' && config.session_id && hasPermissionRules) {
      throw new Error(
        'OpenCode SDK v2 explicit session_id resumes cannot safely rebind permission rules; create a new session to change permission.',
      );
    }

    if (this.opencodeModule.apiVersion !== 'v1' || !hasPermissionRules) {
      return;
    }
    const staticPolicyMatches =
      JSON.stringify(this.buildEffectivePermissionRules(config)) ===
      JSON.stringify(this.buildEffectivePermissionRules(this.config));
    if (config.baseUrl || config.session_id || !staticPolicyMatches) {
      throw new Error(
        'OpenCode SDK v1 supports permission rules only for provider-level configuration on sessions started by Promptfoo; use tools for remote, resumed, or per-prompt policies.',
      );
    }
  }

  private async getOrCreateSession(
    config: OpenCodeSDKConfig,
    workingDir: string | undefined,
  ): Promise<OpenCodeSessionContext> {
    if (!this.client || !this.opencodeModule) {
      throw new Error('OpenCode SDK client is not initialized');
    }

    const sessionQuery = this.buildQuery(config, workingDir);
    if (config.session_id) {
      return {
        sessionId: config.session_id,
        sessionQuery,
      };
    }

    const sessionCacheKey = this.buildSessionKey(config, workingDir);
    if (config.persist_sessions && this.sessions.has(sessionCacheKey)) {
      return {
        sessionId: this.sessions.get(sessionCacheKey)!.id,
        sessionQuery,
      };
    }

    const createResult = await this.client.session.create(
      this.buildCreateSessionParameters(config, sessionQuery),
    );
    const createData = unwrapOpenCodeResult(createResult);
    const sessionId =
      (createData as { id?: string } | undefined)?.id ??
      (createResult as { id?: string } | undefined)?.id;

    if (!sessionId) {
      throw new Error('Failed to get session ID from OpenCode SDK response');
    }

    const session = {
      id: sessionId,
      query: sessionQuery,
    };

    if (config.persist_sessions) {
      this.addSession(sessionCacheKey, session);
      return {
        sessionId,
        sessionQuery,
      };
    }

    return {
      sessionId,
      sessionQuery,
      ephemeralSession: session,
    };
  }

  private buildPromptBody(config: OpenCodeSDKConfig, prompt: string): Record<string, unknown> {
    if (!this.opencodeModule) {
      throw new Error('OpenCode SDK module is not loaded');
    }

    const promptBody: Record<string, unknown> = {
      parts: [{ type: 'text', text: prompt }],
    };

    if (config.provider_id || config.model) {
      promptBody.model = {
        providerID: config.provider_id ?? '',
        modelID: config.model ?? '',
      };
    }

    if (config.agent) {
      promptBody.agent = config.agent;
    } else if (config.custom_agent) {
      promptBody.agent = 'custom';
    }

    if (config.custom_agent?.prompt) {
      promptBody.system = config.custom_agent.prompt;
    }
    if (config.format) {
      promptBody.format = config.format;
    }
    if (config.variant) {
      promptBody.variant = config.variant;
    }
    // The prompt API atomically replaces boolean tool rules. V1 uses it for
    // every supported call; v2 uses it for explicit resumes because new v2
    // sessions receive the full permission ruleset when they are created.
    if (
      (this.opencodeModule.apiVersion === 'v1' || Boolean(config.session_id)) &&
      this.buildConfiguredPermissionRules(config).length === 0
    ) {
      promptBody.tools = this.buildEffectiveToolsConfig(config);
    }
    return promptBody;
  }

  private buildEffectivePermissionRules(config: OpenCodeSDKConfig): OpenCodePermissionRule[] {
    const customAgent = config.agent ? undefined : config.custom_agent;
    return [
      ...convertToolsConfigToRuleset(this.buildToolsConfig(config)),
      ...(convertPermissionConfigToRuleset(config.permission) ?? []),
      ...convertToolsConfigToRuleset(
        this.buildToolsConfig({ ...config, tools: customAgent?.tools }, false),
      ),
      ...(convertPermissionConfigToRuleset(customAgent?.permission) ?? []),
    ];
  }

  private buildCreateSessionParameters(
    config: OpenCodeSDKConfig,
    sessionQuery: OpenCodeSessionQuery | undefined,
  ): Record<string, unknown> {
    if (!this.opencodeModule) {
      throw new Error('OpenCode SDK module is not loaded');
    }

    const createBody: {
      title?: string;
      permission?: OpenCodePermissionRule[];
      parentID?: string;
    } = {
      title: `promptfoo-${Date.now()}`,
    };
    // OpenCode treats legacy `tools` as permission sugar, then merges explicit
    // permissions over it. Mirror that ordering in the v2 rule-array contract.
    if (this.opencodeModule.apiVersion === 'v2') {
      createBody.permission = this.buildEffectivePermissionRules(config);
    }

    // parentID is only honored by the v2 session.create body. v1 has no fork
    // primitive, so silently dropping it there keeps configs portable.
    if (config.parent_session_id && this.opencodeModule.apiVersion === 'v2') {
      createBody.parentID = config.parent_session_id;
    }

    if (this.opencodeModule.apiVersion === 'v2') {
      return {
        ...sessionQuery,
        ...createBody,
      };
    }

    return {
      body: createBody,
      query: sessionQuery,
    };
  }

  private buildPromptParameters(
    config: OpenCodeSDKConfig,
    prompt: string,
    sessionId: string,
    sessionQuery: OpenCodeSessionQuery | undefined,
  ): Record<string, unknown> {
    if (!this.opencodeModule) {
      throw new Error('OpenCode SDK module is not loaded');
    }

    const promptBody = this.buildPromptBody(config, prompt);
    if (this.opencodeModule.apiVersion === 'v2') {
      return {
        sessionID: sessionId,
        ...sessionQuery,
        ...promptBody,
      };
    }

    return {
      path: getSessionPath(sessionId),
      body: promptBody,
      query: sessionQuery,
    };
  }

  private getSessionQueueKey(
    config: OpenCodeSDKConfig,
    workingDir: string | undefined,
  ): string | undefined {
    if (config.session_id) {
      return generateCacheKey('opencode:sdk:explicit-session', { sessionId: config.session_id });
    }
    return config.persist_sessions ? this.buildSessionKey(config, workingDir) : undefined;
  }

  private async runSerializedSessionCall<T>(
    queueKey: string | undefined,
    abortSignal: AbortSignal | undefined,
    run: () => Promise<T>,
  ): Promise<T> {
    if (!queueKey) {
      return run();
    }

    const previous = this.sessionQueues.get(queueKey) ?? Promise.resolve();
    let release: () => void = () => {};
    const current = new Promise<void>((resolve) => {
      release = resolve;
    });
    const queued = previous.catch(() => undefined).then(() => current);
    this.sessionQueues.set(queueKey, queued);
    void queued.finally(() => {
      if (this.sessionQueues.get(queueKey) === queued) {
        this.sessionQueues.delete(queueKey);
      }
    });

    try {
      await this.waitForPreviousSessionCall(previous, abortSignal);
      return await run();
    } finally {
      release();
    }
  }

  private async waitForPreviousSessionCall(
    previous: Promise<void>,
    abortSignal: AbortSignal | undefined,
  ): Promise<void> {
    const previousDone = previous.catch(() => undefined);
    if (!abortSignal) {
      await previousDone;
      return;
    }
    if (abortSignal.aborted) {
      const error = new Error('OpenCode SDK session wait aborted');
      error.name = 'AbortError';
      throw error;
    }

    let onAbort: (() => void) | undefined;
    const abortPromise = new Promise<void>((_, reject) => {
      onAbort = () => {
        const error = new Error('OpenCode SDK session wait aborted');
        error.name = 'AbortError';
        reject(error);
      };
      abortSignal.addEventListener('abort', onAbort, { once: true });
    });
    try {
      await Promise.race([previousDone, abortPromise]);
    } finally {
      if (onAbort) {
        abortSignal.removeEventListener('abort', onAbort);
      }
    }
  }

  private buildProviderResponse(
    config: OpenCodeSDKConfig,
    response: OpenCodeSdkResult<OpenCodePromptResponse>,
    sessionId: string,
  ): ProviderResponse {
    const responseData = unwrapOpenCodeResult(response);
    const assistantMessage = responseData?.info;
    const parts = responseData?.parts ?? [];

    let output = '';
    for (const part of parts) {
      if (part.type === 'text' && part.text) {
        output += (output ? '\n' : '') + part.text;
      }
    }

    if (config.format?.type === 'json_schema') {
      if (assistantMessage?.structured === undefined) {
        output = normalizeStructuredText(output) ?? output;
      } else {
        output = JSON.stringify(assistantMessage.structured);
      }
    }

    const tokens = assistantMessage?.tokens;
    const skillCalls = this.deriveSkillCalls(parts);

    return {
      output,
      tokenUsage: buildOpenCodeTokenUsage(tokens),
      ...(assistantMessage?.cost === undefined ? {} : { cost: assistantMessage.cost }),
      raw: JSON.stringify(response),
      sessionId,
      ...(skillCalls.length === 0 ? {} : { metadata: { skillCalls } }),
    };
  }

  private deriveSkillCalls(parts: OpenCodePromptPart[]): SkillCallEntry[] {
    return parts.flatMap((part) => {
      if (part.type !== 'tool' || part.tool !== 'skill') {
        return [];
      }

      const skillName =
        typeof part.state?.input?.name === 'string' ? part.state.input.name.trim() : '';
      if (!skillName) {
        return [];
      }

      const skillDir =
        typeof part.state?.metadata?.dir === 'string' ? part.state.metadata.dir.trim() : '';

      return [
        {
          name: skillName,
          input: part.state?.input,
          ...(skillDir ? { path: path.join(skillDir, 'SKILL.md') } : {}),
          source: 'tool',
          ...(part.state?.status === 'error' ? { is_error: true } : {}),
        },
      ];
    });
  }

  private handleCallError(error: unknown, callOptions?: CallApiOptionsParams): ProviderResponse {
    const isAbort =
      (error instanceof Error && error.name === 'AbortError') || callOptions?.abortSignal?.aborted;

    if (isAbort) {
      logger.warn('OpenCode SDK call aborted');
      return { error: 'OpenCode SDK call aborted' };
    }

    if (
      error &&
      typeof error === 'object' &&
      'code' in error &&
      error.code === 'ENOENT' &&
      'message' in error &&
      typeof error.message === 'string' &&
      error.message.includes('opencode')
    ) {
      const cliError = dedent`The OpenCode CLI is required but not installed.

        The OpenCode SDK requires the 'opencode' CLI to be installed and available in your PATH.

        Install it with:
          curl -fsSL https://opencode.ai/install | bash

        Or see: https://opencode.ai for other installation methods.`;
      logger.error(cliError);
      return { error: cliError };
    }

    const errorMessage = error instanceof Error ? error.message : String(error);
    logger.error('Error calling OpenCode SDK', { error });
    return {
      error: `Error calling OpenCode SDK: ${errorMessage}`,
    };
  }

  async callApi(
    prompt: string,
    context?: CallApiContextParams,
    callOptions?: CallApiOptionsParams,
  ): Promise<ProviderResponse> {
    const { config, isTempDir, workingDir } = this.prepareCall(context);
    let ephemeralSession: OpenCodeSessionHandle | undefined;
    let abortListener: (() => void) | undefined;

    try {
      this.buildEffectivePermissionRules(config);
      await this.ensureOpenCodeModule();
      this.validateSessionPolicyConfiguration(config);

      if (config.enable_streaming && !this.streamingWarningEmitted) {
        this.streamingWarningEmitted = true;
        logger.warn(
          '[OpenCode SDK] enable_streaming is currently a no-op for this provider; the prompt will run to completion before returning.',
        );
      }

      const mcpConfig = config.mcp && Object.keys(config.mcp).length > 0 ? config.mcp : undefined;
      const statefulSession = Boolean(config.session_id || config.persist_sessions);
      const hasPermissionRules = this.buildConfiguredPermissionRules(config).length > 0;
      const sensitiveMcpConfig = openCodeMcpContainsCacheSensitiveData(mcpConfig);
      const sensitiveBaseUrl = openCodeBaseUrlContainsCacheSensitiveData(config.baseUrl);
      const cacheResult =
        statefulSession || hasPermissionRules || sensitiveMcpConfig || sensitiveBaseUrl
          ? { shouldCache: false, shouldReadCache: false, shouldWriteCache: false }
          : await initializeAgenticCache(
              {
                cacheKeyPrefix: 'opencode:sdk',
                workingDir: config.working_dir ? workingDir : undefined,
                bustCache: context?.bustCache,
                mcp: mcpConfig,
                cacheMcp: config.cache_mcp,
              },
              {
                prompt,
                ...this.historyAffectingInputs(config),
              },
            );

      const cachedResponse = await getCachedResponse(cacheResult, 'OpenCode SDK');
      if (cachedResponse) {
        return cachedResponse;
      }

      if (callOptions?.abortSignal?.aborted) {
        return { error: 'OpenCode SDK call aborted before it started' };
      }

      await this.ensureClient(config);
      const sessionQueueKey = this.getSessionQueueKey(config, workingDir);
      return await this.runSerializedSessionCall(
        sessionQueueKey,
        callOptions?.abortSignal,
        async () => {
          const session = await this.getOrCreateSession(config, workingDir);
          ephemeralSession = session.ephemeralSession;
          if (callOptions?.abortSignal?.aborted) {
            return { error: 'OpenCode SDK call aborted before it started' };
          }

          const promptOptions = this.buildPromptParameters(
            config,
            prompt,
            session.sessionId,
            session.sessionQuery,
          );
          logger.debug(`OpenCode SDK prompt options:`, promptOptions);

          const client = this.client;
          if (!client) {
            throw new Error('OpenCode SDK client is not initialized');
          }

          // If the caller's abortSignal fires mid-prompt, ask the server to stop
          // rather than letting it run to completion while we discard the result.
          // session.abort is only on v2; v1 has no abort primitive, so we still
          // honor cancellation locally via the response check below.
          const abortSignal = callOptions?.abortSignal;
          if (abortSignal && client.session.abort && this.opencodeModule?.apiVersion === 'v2') {
            const abortParams = this.buildAbortSessionParameters(
              session.sessionId,
              session.sessionQuery,
            );
            abortListener = () => {
              client.session.abort?.(abortParams).catch((err) => {
                logger.debug(`[OpenCode SDK] Failed to abort session ${session.sessionId}: ${err}`);
              });
            };
            abortSignal.addEventListener('abort', abortListener, { once: true });
          }

          const response = await client.session.prompt(promptOptions);
          logger.debug(`OpenCode SDK response received`);

          if (abortSignal?.aborted) {
            return { error: 'OpenCode SDK call aborted' };
          }

          const providerResponse = this.buildProviderResponse(config, response, session.sessionId);
          await cacheResponse(cacheResult, providerResponse, 'OpenCode SDK');
          logger.debug(`OpenCode SDK response: ${providerResponse.output.slice(0, 100)}...`);
          return providerResponse;
        },
      );
    } catch (error) {
      return this.handleCallError(error, callOptions);
    } finally {
      if (abortListener && callOptions?.abortSignal) {
        callOptions.abortSignal.removeEventListener('abort', abortListener);
      }
      if (ephemeralSession) {
        try {
          await this.deleteSession(ephemeralSession);
        } catch (err) {
          logger.debug(`Failed to delete non-persistent session ${ephemeralSession.id}: ${err}`);
        }
      }

      // Clean up temp directory
      if (isTempDir && workingDir) {
        await fsPromises.rm(workingDir, { recursive: true, force: true });
      }
    }
  }
}
