import fs from 'fs/promises';
import path from 'path';

import confirm from '@inquirer/confirm';
import { AbortPromptError, ExitPromptError } from '@inquirer/core';
import select from '@inquirer/select';
import chalk from 'chalk';
import dedent from 'dedent';
import { getEnvString } from './envars';
import logger from './logger';
import { redteamInit } from './redteam/commands/init';
import telemetry, { type EventProperties } from './telemetry';
import { pathExists } from './util/file';
import { promptfooCommand } from './util/promptfooCommand';
import { getNunjucksEngine } from './util/templates';

import type { EnvOverrides } from './types/env';
import type { ProviderOptions } from './types/providers';

const CONFIG_TEMPLATE = `# yaml-language-server: $schema=https://promptfoo.dev/config-schema.json

# Learn more about building a configuration: https://promptfoo.dev/docs/configuration/guide

description: "My eval"

prompts:
  {% for prompt in prompts -%}
  - {{prompt | dump }}
  {% endfor %}

providers:
  {% for provider in providers -%}
  - {{provider | dump }}
  {% endfor %}

tests:
{%- if type == 'rag' or type == 'agent' %}
  - vars:
      inquiry: "I have a problem with my order"
      {% if language == 'python' -%}
      context: file://context.py
      {%- elif language == 'javascript' -%}
      context: file://context.js
      {%- else -%}
      context: file://context.py
      {%- endif %}

  - vars:
      inquiry: "I want to return my widget"
      # See how to use dynamic context to e.g. use a vector store https://promptfoo.dev/docs/guides/evaluate-rag/#using-dynamic-context
      {% if language == 'javascript' -%}
      context: file://context.js
      {%- else -%}
      context: file://context.py
      {%- endif %}
    assert:
      # For more information on assertions, see https://promptfoo.dev/docs/configuration/expected-outputs

      # Make sure output contains the phrase "return label"
      - type: icontains
        value: "return label"

      # Prefer shorter outputs
      {% if language == 'python' -%}
      - type: python
        value: 1 / (len(output) + 1)
      {%- else -%}
      - type: javascript
        value: 1 / (output.length + 1)
      {%- endif %}

  - vars:
      inquiry: "I need help with my account"
      context: |
        You can also hardcode context directly in the configuration.
        Username: Foobar
        Account ID: 123456
    assert:
      # For more information on model-graded evals, see https://promptfoo.dev/docs/configuration/expected-outputs/model-graded
      - type: llm-rubric
        value: ensure that the output is friendly and empathetic
{%- else %}
  - vars:
      topic: bananas

  - vars:
      topic: avocado toast
    assert:
      # For more information on assertions, see https://promptfoo.dev/docs/configuration/expected-outputs

      # Make sure output contains the word "avocado"
      - type: icontains
        value: avocado

      # Prefer shorter outputs
      - type: javascript
        value: 1 / (output.length + 1)

  - vars:
      topic: new york city
    assert:
      # For more information on model-graded evals, see https://promptfoo.dev/docs/configuration/expected-outputs/model-graded
      - type: llm-rubric
        value: ensure that the output is funny
{% endif %}
`;

const PYTHON_PROVIDER = `# Learn more about building a Python provider: https://promptfoo.dev/docs/providers/python/

def call_api(prompt, options, context):
    # The 'options' parameter contains additional configuration for the API call.
    config = options.get('config', None)
    additional_option = config.get('additionalOption', None)

    # The 'context' parameter provides info about which vars were used to create the final prompt.
    user_variable = context['vars'].get('userVariable', None)

    # The prompt is the final prompt string after the variables have been processed.
    # Custom logic to process the prompt goes here.
    # For instance, you might call an external API or run some computations.
    # TODO: Replace with actual LLM API implementation.
    def call_llm(prompt):
        return f"Stub response for prompt: {prompt}"
    output = call_llm(prompt)

    # The result should be a dictionary with at least an 'output' field.
    result = {
        "output": output,
    }

    # Optionally include error information:
    # result['error'] = "An error occurred during processing"

    # Optionally report token usage:
    # result['tokenUsage'] = {"total": 100, "prompt": 50, "completion": 50}

    # Optionally flag guardrail violations:
    # result['guardrails'] = {"flagged": True}

    return result
`;

const JAVASCRIPT_PROVIDER = `// Learn more about building a JavaScript provider: https://promptfoo.dev/docs/providers/custom-api
// customApiProvider.js

class CustomApiProvider {
  constructor(options) {
    // Provider ID can be overridden by the config file (e.g. when using multiple of the same provider)
    this.providerId = options.id || 'custom provider';

    // options.config contains any custom options passed to the provider
    this.config = options.config;
  }

  id() {
    return this.providerId;
  }

  async callApi(prompt, context) {
    // Add your custom API logic here
    // Use options like: \`this.config.temperature\`, \`this.config.max_tokens\`, etc.

    console.log('Vars for this test case:', JSON.stringify(context.vars));

    return {
      // Required
      output: 'Model output',

      // Optional
      tokenUsage: {
        total: 10,
        prompt: 5,
        completion: 5,
      },
    };
  }
}

module.exports = CustomApiProvider;
`;

const BASH_PROVIDER = `# Learn more about building any generic provider: https://promptfoo.dev/docs/providers/custom-script

# Anything printed to standard output will be captured as the output of the provider

echo "This is the LLM output"

# You can also call external scripts or executables
php my_script.php
`;

const WINDOWS_PROVIDER = `@echo off
REM Learn more about building any generic provider: https://promptfoo.dev/docs/providers/custom-script

REM Anything printed to standard output will be captured as the output of the provider

echo This is the LLM output

REM You can also call external scripts or executables
REM php my_script.php
`;

const PYTHON_VAR = `# Learn more about using dynamic variables: https://promptfoo.dev/docs/configuration/guide/#import-vars-from-separate-files
def get_var(var_name, prompt, other_vars):
    # This is where you can fetch documents from a database, call an API, etc.
    # ...

    if var_name == 'context':
        # Return value based on the variable name and test context
        return {
            'output': f"... Documents for {other_vars['inquiry']} in prompt: {prompt} ..."
        }

    # Default variable value
    return {'output': 'Document A, Document B, Document C, ...'}

    # Handle potential errors
    # return { 'error': 'Error message' }
`;

const JAVASCRIPT_VAR = `// Learn more about using dynamic variables: https://promptfoo.dev/docs/configuration/guide/#import-vars-from-separate-files
module.exports = function (varName, prompt, otherVars) {
  // This is where you can fetch documents from a database, call an API, etc.
  // ...

  if (varName === 'context') {
    // Return value based on the variable name and test context
    return {
      output: \`... Documents for \${otherVars.inquiry} for prompt: \${prompt} ...\`
    };
  }

  // Default variable value
  return {
    output: 'Document A, Document B, Document C, ...',
  };

  // Handle potential errors
  // return { error: 'Error message' }
};
`;

function getDefaultReadme(action?: string): string {
  const useCase =
    action === 'rag'
      ? 'RAG evaluation'
      : action === 'agent'
        ? 'agent evaluation'
        : 'prompt evaluation';

  return `# Promptfoo ${useCase}

## Quick start

1. Set your API key (if using a cloud provider):

\`\`\`bash
export OPENAI_API_KEY=sk-...
# Or for other providers:
# export ANTHROPIC_API_KEY=sk-ant-...
# export GOOGLE_API_KEY=...
\`\`\`

2. Edit \`promptfooconfig.yaml\` to customize prompts, providers, and test cases.

3. Run the evaluation:

\`\`\`bash
${promptfooCommand('eval')}
\`\`\`

4. View results in your browser:

\`\`\`bash
${promptfooCommand('view')}
\`\`\`

## Learn more

- Configuration guide: https://promptfoo.dev/docs/configuration/guide
- All providers: https://promptfoo.dev/docs/providers
- Assertions & metrics: https://promptfoo.dev/docs/configuration/expected-outputs
- Examples: https://github.com/promptfoo/promptfoo/tree/main/examples
`;
}

function recordOnboardingStep(step: string, properties: EventProperties = {}) {
  telemetry.record('funnel', {
    type: 'eval onboarding',
    step,
    ...properties,
  });
}

/**
 * Iterate through user choices and determine if the user has selected a provider that needs an API key
 * but has not set and API key in their environment.
 */
export function reportProviderAPIKeyWarnings(
  providerChoices: (string | ProviderOptions)[],
): string[] {
  const ids = providerChoices.map((c) => (typeof c === 'object' ? (c.id ?? '') : c));

  const map: Record<string, keyof EnvOverrides> = {
    openai: 'OPENAI_API_KEY',
    anthropic: 'ANTHROPIC_API_KEY',
    vertex: 'GOOGLE_API_KEY',
    google: 'GOOGLE_API_KEY',
    cohere: 'COHERE_API_KEY',
  };

  return Object.entries(map)
    .filter(([prefix, key]) => ids.some((id) => id.startsWith(prefix)) && !getEnvString(key))
    .map(
      ([_prefix, key]) => dedent`
    ${chalk.bold(`Warning: ${key} environment variable is not set.`)}
    Please set this environment variable like: export ${key}=<my-api-key>
  `,
    );
}

async function askForPermissionToOverwrite({
  absolutePath,
  relativePath,
  required,
}: {
  absolutePath: string;
  relativePath: string;
  required: boolean;
}): Promise<boolean> {
  if (!(await pathExists(absolutePath))) {
    return true;
  }

  const requiredText = required ? '(required)' : '(optional)';
  const hasPermissionToWrite = await confirm({
    message: `${relativePath} ${requiredText} already exists. Do you want to overwrite it?`,
    default: false,
  });

  return hasPermissionToWrite;
}

interface InitProjectResult {
  numPrompts: number;
  providerPrefixes: string[];
  action: string;
  language: string;
  outDirectory: string;
}

export async function createDummyFiles(
  directory: string | null,
  interactive: boolean = true,
): Promise<InitProjectResult> {
  const outDirectory = directory || '.';
  const outDirAbsolute = path.join(process.cwd(), outDirectory);

  async function writeFile({
    file,
    contents,
    required,
  }: {
    file: string;
    contents: string;
    required: boolean;
  }) {
    const relativePath = path.join(outDirectory, file);
    const absolutePath = path.join(outDirAbsolute, file);

    if (interactive) {
      const hasPermissionToWrite = await askForPermissionToOverwrite({
        absolutePath,
        relativePath,
        required,
      });

      if (!hasPermissionToWrite) {
        if (required) {
          logger.warn(`⚠️ Skipping required file ${relativePath} - configuration may be incomplete`);
        } else {
          logger.info(`⏩ Skipping ${relativePath}`);
        }
        return;
      }
    }

    await fs.writeFile(absolutePath, contents);
    logger.info(`📝 Wrote ${relativePath}`);
  }

  const prompts: string[] = [];
  const providers: (string | object)[] = [];
  let action: string;
  let language: string;

  await fs.mkdir(outDirAbsolute, { recursive: true });

  if (interactive) {
    recordOnboardingStep('start');

    logger.info(
      chalk.bold('\nWelcome to Promptfoo!\n') +
        chalk.gray("We'll set up a configuration file to get you started.\n"),
    );

    // Choose use case
    action = await select({
      message: 'What would you like to do?',
      choices: [
        {
          name: 'Not sure yet',
          value: 'compare',
          description: 'Get started with a basic prompt comparison',
        },
        {
          name: 'Compare prompts and models',
          value: 'compare',
          description: 'Test different prompts, models, or parameters side by side',
        },
        {
          name: 'Improve RAG performance',
          value: 'rag',
          description: 'Evaluate retrieval-augmented generation pipelines',
        },
        {
          name: 'Improve agent/chain of thought performance',
          value: 'agent',
          description: 'Test agent workflows and tool-calling behavior',
        },
        {
          name: 'Run a red team evaluation',
          value: 'redteam',
          description: 'Scan for security vulnerabilities and compliance risks',
        },
      ],
    });

    recordOnboardingStep('choose app type', {
      value: action,
    });

    if (action === 'redteam') {
      await redteamInit(outDirectory);
      return {
        numPrompts: 0,
        providerPrefixes: [],
        action: 'redteam',
        language: 'not_applicable',
        outDirectory,
      };
    }

    language = 'not_sure';
    if (action === 'rag' || action === 'agent') {
      language = await select({
        message: 'What programming language are you developing the app in?',
        choices: [
          { name: 'Not sure yet', value: 'not_sure' },
          { name: 'Python', value: 'python' },
          { name: 'Javascript', value: 'javascript' },
        ],
      });

      recordOnboardingStep('choose language', {
        value: language,
      });
    }

    const choices: { name: string; value: (string | ProviderOptions)[] }[] = [
      { name: `I'll choose later`, value: ['openai:gpt-5-mini', 'openai:gpt-5'] },
      {
        name: '[OpenAI] GPT 5, GPT 4.1, ...',
        value:
          action === 'agent'
            ? [
                {
                  id: 'openai:gpt-5',
                  config: {
                    tools: [
                      {
                        type: 'function',
                        function: {
                          name: 'get_current_weather',
                          description: 'Get the current weather in a given location',
                          parameters: {
                            type: 'object',
                            properties: {
                              location: {
                                type: 'string',
                                description: 'The city and state, e.g. San Francisco, CA',
                              },
                            },
                            required: ['location'],
                          },
                        },
                      },
                    ],
                  },
                },
              ]
            : ['openai:gpt-5-mini', 'openai:gpt-5'],
      },
      {
        name: '[Anthropic] Claude Fable, Opus, Sonnet, Haiku, ...',
        value: [
          'anthropic:messages:claude-fable-5',
          'anthropic:messages:claude-opus-5',
          'anthropic:messages:claude-opus-4-8',
          'anthropic:messages:claude-sonnet-5',
          'anthropic:messages:claude-sonnet-4-6',
          'anthropic:messages:claude-opus-4-6',
          'anthropic:messages:claude-haiku-4-5',
        ],
      },
      {
        name: '[Google] Gemini 3.7 Flash, 3.6 Flash, 3.5 Flash-Lite, ...',
        value: [
          ...['gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite'].map((id) => ({
            id: `vertex:${id}`,
            config: { region: 'global' },
          })),
          'vertex:gemini-3.1-pro-preview',
          'vertex:gemini-2.5-pro',
        ],
      },
      {
        name: '[HuggingFace] Llama, Phi, Gemma, ...',
        value: [
          'huggingface:text-generation:meta-llama/Meta-Llama-3.1-8B-Instruct',
          'huggingface:text-generation:microsoft/Phi-4-mini-instruct',
          'huggingface:text-generation:google/gemma-3-4b-it',
        ],
      },
      {
        name: 'Local Python script',
        value: ['file://provider.py'],
      },
      {
        name: 'Local Javascript script',
        value: ['file://provider.js'],
      },
      {
        name: 'Local executable',
        value: [process.platform === 'win32' ? 'exec:provider.bat' : 'exec:provider.sh'],
      },
      {
        name: 'HTTP endpoint',
        value: ['https://example.com/api/generate'],
      },
      {
        name: '[Azure] OpenAI, DeepSeek, Llama, ...',
        value: [
          {
            id: 'azure:chat:deploymentNameHere',
            config: {
              apiHost: 'xxxxxxxx.openai.azure.com',
            },
          },
        ],
      },
      {
        name: '[AWS Bedrock] Claude, Llama, Titan, ...',
        value: ['bedrock:us.anthropic.claude-sonnet-4-5-20250929-v1:0'],
      },
      {
        name: '[Cohere] Command R, Command R+, ...',
        value: ['cohere:command-r', 'cohere:command-r-plus'],
      },
      {
        name: '[Ollama] Llama, Qwen, Phi, ...',
        value: ['ollama:chat:llama3.3', 'ollama:chat:phi4'],
      },
      {
        name: '[WatsonX] Llama, IBM Granite, ...',
        value: [
          'watsonx:meta-llama/llama-3-2-11b-vision-instruct',
          'watsonx:ibm/granite-3-3-8b-instruct',
        ],
      },
    ];

    /**
     * The potential of the object type here is given by the agent action conditional
     * for openai as a value choice
     */
    const providerChoice = await select({
      message: 'Which model provider would you like to use?',
      choices,
      loop: false,
      pageSize: process.stdout.rows - 6,
    });
    const providerChoices: (string | ProviderOptions)[] = Array.isArray(providerChoice)
      ? providerChoice
      : [providerChoice];

    recordOnboardingStep('choose providers', {
      value: providerChoices.map((choice) =>
        typeof choice === 'string' ? choice : JSON.stringify(choice),
      ),
    });

    // Tell the user if they have providers selected without relevant API keys set in env.
    reportProviderAPIKeyWarnings(providerChoices).forEach((warningText) =>
      logger.warn(warningText),
    );

    if (providerChoices.length > 0) {
      if (providerChoices.length > 3) {
        providers.push(
          ...providerChoices.map((choice) => (Array.isArray(choice) ? choice[0] : choice)),
        );
      } else {
        providers.push(...providerChoices);
      }

      if (
        providerChoices.some(
          (choice) =>
            typeof choice === 'string' && choice.startsWith('file://') && choice.endsWith('.js'),
        )
      ) {
        await writeFile({
          file: 'provider.js',
          contents: JAVASCRIPT_PROVIDER,
          required: true,
        });
      }
      if (
        providerChoices.some((choice) => typeof choice === 'string' && choice.startsWith('exec:'))
      ) {
        // Generate platform-appropriate executable provider script
        const isWindows = process.platform === 'win32';
        await writeFile({
          file: isWindows ? 'provider.bat' : 'provider.sh',
          contents: isWindows ? WINDOWS_PROVIDER : BASH_PROVIDER,
          required: true,
        });
      }
      if (
        providerChoices.some(
          (choice) =>
            typeof choice === 'string' &&
            (choice.startsWith('python:') ||
              (choice.startsWith('file://') && choice.endsWith('.py'))),
        )
      ) {
        await writeFile({
          file: 'provider.py',
          contents: PYTHON_PROVIDER,
          required: true,
        });
      }
    } else {
      providers.push('openai:gpt-5-mini');
      providers.push('openai:gpt-5');
    }

    if (action === 'compare') {
      prompts.push(`Write a tweet about {{topic}}`);
      if (providers.length < 3) {
        prompts.push(`Write a concise, funny tweet about {{topic}}`);
      }
    } else if (action === 'rag') {
      prompts.push(
        'Write a customer service response to:\n\n{{inquiry}}\n\nUse these documents:\n\n{{context}}',
      );
    } else if (action === 'agent') {
      prompts.push(`Fulfill this user helpdesk ticket: {{inquiry}}`);
    }

    if (action === 'rag' || action === 'agent') {
      if (language === 'javascript') {
        await writeFile({
          file: 'context.js',
          contents: JAVASCRIPT_VAR,
          required: true,
        });
      } else {
        await writeFile({
          file: 'context.py',
          contents: PYTHON_VAR,
          required: true,
        });
      }
    }

    recordOnboardingStep('complete');
  } else {
    action = 'compare';
    language = 'not_sure';
    prompts.push(`Write a tweet about {{topic}}`);
    prompts.push(`Write a concise, funny tweet about {{topic}}`);
    providers.push('openai:gpt-5-mini');
    providers.push('openai:gpt-5');
  }

  const nunjucks = getNunjucksEngine();
  const config = nunjucks.renderString(CONFIG_TEMPLATE, {
    prompts,
    providers,
    type: action,
    language,
  });

  await writeFile({
    file: 'README.md',
    contents: getDefaultReadme(action),
    required: false,
  });

  await writeFile({
    file: 'promptfooconfig.yaml',
    contents: config,
    required: true,
  });

  return {
    numPrompts: prompts.length,
    providerPrefixes: providers.map((p) => (typeof p === 'string' ? p.split(':')[0] : 'unknown')),
    action,
    language,
    outDirectory,
  };
}

export async function initializeProject(directory: string | null, interactive: boolean = true) {
  try {
    const result = await createDummyFiles(directory, interactive);
    const { outDirectory, ...telemetryDetails } = result;

    const runCommand = promptfooCommand('eval');
    const viewCommand = promptfooCommand('view');

    logger.info('');
    if (outDirectory === '.') {
      logger.info(chalk.green(`✅ Setup complete! Next steps:\n`));
      logger.info(`  ${chalk.bold('1.')} Run ${chalk.cyan(runCommand)} to evaluate your prompts`);
      logger.info(
        `  ${chalk.bold('2.')} Run ${chalk.cyan(viewCommand)} to view results in your browser`,
      );
    } else {
      logger.info(chalk.green(`✅ Wrote promptfooconfig.yaml to ./${outDirectory}\n`));
      logger.info(`  ${chalk.bold('1.')} Run ${chalk.cyan(`cd ${outDirectory}`)}`);
      logger.info(`  ${chalk.bold('2.')} Run ${chalk.cyan(runCommand)} to evaluate your prompts`);
      logger.info(
        `  ${chalk.bold('3.')} Run ${chalk.cyan(viewCommand)} to view results in your browser`,
      );
    }
    logger.info('');
    logger.info(chalk.gray(`  Docs: https://promptfoo.dev/docs/configuration/guide`));

    return telemetryDetails;
  } catch (err) {
    if (err instanceof AbortPromptError || err instanceof ExitPromptError) {
      const runCommand = promptfooCommand('init');
      logger.info(
        '\n' +
          chalk.blue('Initialization paused. To continue setup later, use the command: ') +
          chalk.bold(runCommand),
      );
      logger.info(
        chalk.blue('For help or feedback, visit ') +
          chalk.green('https://www.promptfoo.dev/contact/'),
      );
      await recordOnboardingStep('early exit');
      process.exitCode = 130;
      return;
    } else {
      throw err;
    }
  }
}
