import fs from 'fs/promises';
import * as path from 'path';

import chalk from 'chalk';
import chokidar from 'chokidar';
import dedent from 'dedent';
import { globSync } from 'glob';
import ora from 'ora';
import { z } from 'zod';
import { disableCache } from '../cache';
import cliState from '../cliState';
import { DEFAULT_MAX_CONCURRENCY } from '../constants';
import { getEnvBool, getEnvFloat, getEnvInt, isCI } from '../envars';
import { evaluate, PromptSuggestionsRejectedError } from '../evaluator';
import {
  checkEmailStatusAndMaybeExit,
  EmailValidationError,
  getAuthor,
  promptForEmailUnverified,
} from '../globalConfig/accounts';
import { cloudConfig } from '../globalConfig/cloud';
import logger, { getLogLevel } from '../logger';
import { runDbMigrations } from '../migrate';
import Eval from '../models/eval';
import { loadApiProvider } from '../providers/index';
import { neverGenerateRemote } from '../redteam/remoteGeneration';
import { createShareableUrl, isSharingEnabled } from '../share';
import { generateTable } from '../table';
import telemetry from '../telemetry';
import { EMAIL_OK_STATUS } from '../types/email';
import { isCliEventSource } from '../types/eventSource';
import { CommandLineOptionsSchema, MAX_SUGGESTIONS_COUNT, TestSuiteSchema } from '../types/index';
import { isApiProvider } from '../types/providers';
import { checkCloudPermissions, getEvalConfigFromCloud, getOrgContext } from '../util/cloud';
import { clearConfigCache, loadDefaultConfig } from '../util/config/default';
import { DEFAULT_CONFIG_EXTENSIONS } from '../util/config/extensions';
import {
  ConfigResolutionError,
  logConfigResolutionError,
  maybeReadConfig,
  renderConfigEnvTemplates,
  resolveConfigs,
} from '../util/config/load';
import {
  filterProviders,
  getPersistedProviderFilterOptions,
  getProviderFilterRegexError,
} from '../util/eval/filterProviders';
import { filterTests } from '../util/eval/filterTests';
import { warnIfRedteamConfigHasNoTests } from '../util/eval/redteamWarning';
import { generateEvalSummary } from '../util/eval/summary';
import { maybeLoadFromExternalFile } from '../util/file';
import {
  printBorder,
  setupEnv,
  warnOnDegradedJsonlRecovery,
  writeMultipleOutputs,
} from '../util/index';
import { promptfooCommand } from '../util/promptfooCommand';
import { checkProviderApiKeys } from '../util/provider';
import { shouldShareResults } from '../util/sharing';
import { resolveTestsWatchPaths } from '../util/testCaseReader';
import { TokenUsageTracker } from '../util/tokenUsage';
import { accumulateTokenUsage, createEmptyTokenUsage } from '../util/tokenUsageUtils';
import { isUuid } from '../util/uuid';
import { deleteErrorResults, getErrorResultIds, recalculatePromptMetrics } from './retry';
import { notCloudEnabledShareInstructions } from './shareInstructions';
import type { FSWatcher } from 'chokidar';
import type { Command } from 'commander';

import type {
  CommandLineOptions,
  EvalRuntimeOptions,
  Scenario,
  TestSuite,
  UnifiedConfig,
} from '../types/index';
import type { InternalEvaluateOptions } from '../types/internal';
import type { FilterOptions } from '../util/eval/filterTests';

export const EvalCommandSchema = CommandLineOptionsSchema.extend({
  help: z.boolean().optional(),
  interactiveProviders: z.boolean().optional(),
  remote: z.boolean().optional(),
  noShare: z.boolean().optional(),
  retryErrors: z.boolean().optional(),
  // CLI alias preserved for the existing --suggest-prompts <n> flag; canonical key is suggestionsCount.
  suggestPrompts: z.coerce.number().int().positive().max(MAX_SUGGESTIONS_COUNT).optional(),
  extension: z.array(z.string()).optional(),
  // Allow --resume or --resume <id>
  resume: z.union([z.string(), z.boolean()]).optional(),
}).partial();

export type EvalCommandOptions = z.infer<typeof EvalCommandSchema>;

function runtimeTagsForEval(
  cmdObj: Partial<CommandLineOptions & Command>,
  commandLineOptions: Record<string, any> | undefined,
): Record<string, string> | undefined {
  const tags = {
    ...(commandLineOptions?.tags || {}),
    ...(cmdObj.tags || {}),
  };

  return Object.keys(tags).length > 0 ? tags : undefined;
}

async function resolveReplayConfigs(
  evalRecord: Eval,
  action: 'resuming' | 'retrying errors for',
): Promise<Awaited<ReturnType<typeof resolveConfigs>>> {
  const providerFilterOptions = getPersistedProviderFilterOptions(
    evalRecord.runtimeOptions?.providerFilter,
  );
  const providerFilter = providerFilterOptions.filterProviders;

  // Validate the stored pattern up front so a regex failure is attributed to the filter,
  // while unrelated resolution errors (missing prompt files, provider load failures)
  // propagate unchanged with their original class and stack.
  const regexError = providerFilter ? getProviderFilterRegexError(providerFilter) : undefined;
  if (providerFilter && regexError) {
    throw new ConfigResolutionError(
      `Could not apply stored provider filter "${providerFilter}" while ${action} evaluation ${evalRecord.id}: ${regexError}. The evaluation was not changed.`,
    );
  }

  let replayConfig = evalRecord.config;
  if (replayConfig.tracing?.provider) {
    const renderedReplayConfig = renderConfigEnvTemplates(replayConfig);
    replayConfig = {
      ...replayConfig,
      ...(renderedReplayConfig.env && { env: renderedReplayConfig.env }),
      tracing: renderedReplayConfig.tracing,
    };
  }

  const configs = await resolveConfigs(providerFilterOptions, replayConfig);
  // The original run filtered twice: raw configs in resolveConfigs, then instantiated
  // providers by live id()/label below in doEval. Replay both stages so the resumed
  // provider set matches the original even when an instantiated id or label diverges
  // from its raw config reference.
  configs.testSuite.providers = filterProviders(configs.testSuite.providers, providerFilter);
  return configs;
}

export class EvalRunError extends Error {
  readonly exitCode: number;

  constructor(message: string, exitCode: number = 1) {
    super(message);
    this.name = 'EvalRunError';
    // POSIX exit codes are 1-255 (0 means success). Coerce silly values to the
    // default rather than letting `exitCode = 0` silently mask a real failure.
    this.exitCode = Number.isInteger(exitCode) && exitCode >= 1 && exitCode <= 255 ? exitCode : 1;
  }
}

function failEvalRun(
  message: string,
  isCliInvocation: boolean,
  options: { logForCli?: () => void; cliFallback?: Eval } = {},
): Eval {
  if (isCliInvocation) {
    (options.logForCli ?? (() => logger.error(chalk.red(message))))();
    process.exitCode = 1;
    // Preserve a real Eval (e.g. a just-completed run flagged for a follow-up
    // failure like watch-mode setup) so downstream summaries don't misreport.
    return options.cliFallback ?? new Eval({}, { persisted: false });
  }

  throw new EvalRunError(message);
}

function handleRecoverableWatchError(error: unknown): boolean {
  if (error instanceof ConfigResolutionError) {
    logConfigResolutionError(error);
    return true;
  }
  if (error instanceof EmailValidationError) {
    // Account helpers already render these user-facing failures.
    return true;
  }
  if (error instanceof EvalRunError || error instanceof PromptSuggestionsRejectedError) {
    logger.error(error.message);
    return true;
  }
  return false;
}

/**
 * Keep the CLI alive for as long as watch mode is watching.
 *
 * `main()` resolves as soon as the eval command's action handler returns, and its
 * `finally` then runs `shutdownGracefully()`, which closes the database and the HTTP
 * dispatcher and calls `process.exit()` 100ms later. Returning while a watcher is still
 * running therefore tore down everything a re-run needs and killed the process before
 * chokidar could report a single change. Long-running commands avoid this by not
 * resolving until they are done -- `startServer()` does exactly this -- so watch mode
 * does the same and settles only once the watcher is closed.
 *
 * Signal handlers are removed as soon as one fires, so a second Ctrl-C falls back to
 * Node's default behaviour and terminates immediately.
 */
function watchUntilTerminated(watcher: FSWatcher): Promise<void> {
  const signals = ['SIGINT', 'SIGTERM'] as const;
  return new Promise<void>((resolve) => {
    const onSignal = () => {
      for (const signal of signals) {
        process.removeListener(signal, onSignal);
      }
      logger.info('Stopping watch mode...');
      // Settle regardless: a watcher that fails to close must not wedge the CLI.
      watcher
        .close()
        .catch((error) =>
          logger.warn(
            `Error closing file watcher: ${error instanceof Error ? error.message : error}`,
          ),
        )
        .finally(resolve);
    };

    for (const signal of signals) {
      process.on(signal, onSignal);
    }
  });
}

function resolveSuggestionOptions(
  cmdObj: Partial<CommandLineOptions & Command>,
  commandLineOptions: Record<string, any> | undefined,
  evaluateOptions: InternalEvaluateOptions,
): Pick<InternalEvaluateOptions, 'generateSuggestions' | 'suggestionsCount'> {
  const { suggestPrompts } = cmdObj as EvalCommandOptions;

  // --suggest-prompts is itself an enable signal — passing a count opts in even
  // if some other source explicitly set generateSuggestions=false.
  if (suggestPrompts !== undefined) {
    return { generateSuggestions: true, suggestionsCount: suggestPrompts };
  }

  const explicitGenerate =
    cmdObj.generateSuggestions ??
    commandLineOptions?.generateSuggestions ??
    evaluateOptions.generateSuggestions;

  if (explicitGenerate !== true) {
    // Return explicit false so Object.assign clears any truthy default already on options.
    return explicitGenerate === false ? { generateSuggestions: false } : {};
  }

  // Read cmdObj.suggestionsCount too: doEval is exported and non-Commander
  // callers may pass the canonical key directly instead of the suggestPrompts CLI alias.
  const suggestionsCount =
    cmdObj.suggestionsCount ??
    commandLineOptions?.suggestionsCount ??
    evaluateOptions.suggestionsCount;
  return suggestionsCount === undefined
    ? { generateSuggestions: true }
    : { generateSuggestions: true, suggestionsCount };
}

export function showRedteamProviderLabelMissingWarning(testSuite: TestSuite) {
  const hasProviderWithoutLabel = testSuite.providers.some((p) => !p.label);
  if (hasProviderWithoutLabel) {
    logger.warn(
      dedent`
      ${chalk.bold.yellow('Warning')}: Your target (provider) does not have a label specified.

      Labels are used to uniquely identify redteam targets. Please set a meaningful and unique label (e.g., 'helpdesk-search-agent') for your targets/providers in your redteam config.

      Provider ID will be used as a fallback if no label is specified.
      `,
    );
  }
}

/**
 * Whether a config file can be read without executing it.
 *
 * readConfig() only routes through importModule() for JavaScript and TypeScript. Its
 * YAML and JSON branch reads the file, dereferences `$ref`, and renders environment
 * templates, none of which execute user code. Restricting the re-read to those formats
 * therefore keeps the normalisation while guaranteeing a config is never run twice.
 */
function isDeclarativeConfig(configPath: string): boolean {
  return ['.yaml', '.yml', '.json'].includes(path.extname(configPath).toLowerCase());
}

export async function doEval(
  cmdObj: Partial<CommandLineOptions & Command>,
  defaultConfig: Partial<UnifiedConfig>,
  defaultConfigPath: string | undefined,
  evaluateOptions: InternalEvaluateOptions,
): Promise<Eval> {
  // Phase 1: Load environment from CLI args (preserves existing behavior)
  setupEnv(cmdObj.envPath);
  const isCliInvocation = isCliEventSource(evaluateOptions);

  let config: Partial<UnifiedConfig> | undefined = undefined;
  let testSuite: TestSuite | undefined = undefined;
  let _basePath: string | undefined = undefined;
  let commandLineOptions: Record<string, any> | undefined = undefined;

  const configArgs = Array.isArray(cmdObj.config)
    ? cmdObj.config
    : typeof cmdObj.config === 'string'
      ? [cmdObj.config]
      : [];
  const uuidConfigArgs = configArgs.filter((configArg) => isUuid(configArg));

  if (configArgs.length > 1 && uuidConfigArgs.length > 0) {
    throw new Error(
      'Cloud config UUID mode supports exactly one -c value. Use: promptfoo eval -c <cloud-config-uuid>',
    );
  }

  if (configArgs.length === 1 && uuidConfigArgs.length === 1) {
    const cloudConfigId = uuidConfigArgs[0];
    if (cmdObj.watch) {
      throw new Error(
        '--watch is not supported when using a cloud config UUID with -c. Use a local config file path for watch mode.',
      );
    }

    try {
      defaultConfig = await getEvalConfigFromCloud(cloudConfigId);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      throw new Error(
        `Failed to load cloud eval config "${cloudConfigId}". ${reason}. Cloud UUID inputs do not fall back to local file paths. Check authentication and that the UUID exists.`,
      );
    }

    cmdObj.config = undefined;
    defaultConfigPath = undefined;
  }

  // Set once watch mode starts watching; awaited before doEval returns so the CLI does
  // not shut down underneath the watcher.
  let watchTermination: Promise<void> | undefined;

  const runEvaluation = async (initialization?: boolean) => {
    const startTime = Date.now();
    telemetry.record('command_used', {
      name: 'eval - started',
      watch: Boolean(cmdObj.watch),
      // Only set when redteam is enabled for sure, because we don't know if config is loaded yet
      ...(Boolean(config?.redteam) && { isRedteam: true }),
    });

    if (cmdObj.write) {
      await runDbMigrations();
    }

    // Reload default config - because it may have changed.
    if (defaultConfigPath) {
      const configDir = path.dirname(defaultConfigPath);
      const configName = path.basename(defaultConfigPath, path.extname(defaultConfigPath));
      const { defaultConfig: newDefaultConfig } = await loadDefaultConfig(configDir, configName);
      defaultConfig = newDefaultConfig;
    }

    if (cmdObj.config !== undefined) {
      // Normalize to an array up front (Commander's variadic --config already yields one) so
      // the directory resolution below — and the array operations on cmdObj.config later in
      // this function — stay safe regardless of the caller's input shape.
      const configPaths: string[] = Array.isArray(cmdObj.config) ? cmdObj.config : [cmdObj.config];
      // Rebuild the list in iteration order: combineConfigs() applies configs in array order
      // (later entries override earlier ones), so a directory entry must resolve in place
      // rather than be appended (e.g. `--config base.yaml dir/ override.yaml`).
      const resolvedConfigPaths: string[] = [];
      const configlessDirs: string[] = [];
      const noConfigHint = `Looked for promptfooconfig.{${DEFAULT_CONFIG_EXTENSIONS.join(',')}}. Run "${promptfooCommand('init')}" or pass --config path/to/promptfooconfig.yaml.`;
      for (const configPath of configPaths) {
        const configStats = await fs.stat(configPath).catch(() => undefined);
        if (!configStats?.isDirectory()) {
          resolvedConfigPaths.push(configPath);
          continue;
        }
        const { defaultConfig: dirConfig, defaultConfigPath: newConfigPath } =
          await loadDefaultConfig(configPath);
        if (newConfigPath) {
          resolvedConfigPaths.push(newConfigPath);
          defaultConfig = { ...defaultConfig, ...dirConfig };
        } else {
          // Drop the directory from the list: leaving it in would surface later as a
          // confusing "Unsupported configuration file format" error from readConfig().
          configlessDirs.push(configPath);
          logger.warn(`No configuration file found in directory: ${configPath}. ${noConfigHint}`);
        }
      }

      if (configlessDirs.length > 0 && resolvedConfigPaths.length === 0) {
        return failEvalRun(
          `No configuration file found in ${configlessDirs.join(', ')}. ${noConfigHint}`,
          isCliInvocation,
        );
      }
      cmdObj.config = resolvedConfigPaths;
    }

    // Check for conflicting options
    const resumeRaw = (cmdObj as any).resume as string | boolean | undefined;
    const retryErrors = cmdObj.retryErrors;

    if (resumeRaw && retryErrors) {
      return failEvalRun(
        'Cannot use --resume and --retry-errors together. Please use one or the other.',
        isCliInvocation,
      );
    }

    const hasRuntimeTags = Boolean(cmdObj.tags && Object.keys(cmdObj.tags).length > 0);
    if (resumeRaw && hasRuntimeTags) {
      return failEvalRun(
        'Cannot use --tag with --resume. Resumed evaluations keep their original tags.',
        isCliInvocation,
      );
    }
    if (retryErrors && hasRuntimeTags) {
      return failEvalRun(
        'Cannot use --tag with --retry-errors. Retried evaluations keep their original tags.',
        isCliInvocation,
      );
    }

    // If resuming, load config from existing eval and avoid CLI filters that could change indices
    let resumeEval: Eval | undefined;
    let retryErrorResultIds: string[] | undefined;
    const resumeId =
      resumeRaw === true || resumeRaw === undefined ? 'latest' : (resumeRaw as string);
    if (resumeRaw) {
      // Check if --no-write is set with --resume
      if (cmdObj.write === false) {
        return failEvalRun(
          'Cannot use --resume with --no-write. Resume functionality requires database persistence.',
          isCliInvocation,
        );
      }
      resumeEval = resumeId === 'latest' ? await Eval.latest() : await Eval.findById(resumeId);
      if (!resumeEval) {
        const message = `Could not find evaluation to resume: ${resumeId}`;
        return failEvalRun(message, isCliInvocation, {
          logForCli: () => logger.error(message),
        });
      }
      logger.info(chalk.cyan(`Resuming evaluation ${resumeEval.id}...`));
      // Use the saved config as our base to ensure identical test ordering
      ({
        config,
        testSuite,
        basePath: _basePath,
        commandLineOptions,
      } = await resolveReplayConfigs(resumeEval, 'resuming'));
      // Ensure prompts exactly match the previous run to preserve IDs and content
      if (Array.isArray(resumeEval.prompts) && resumeEval.prompts.length > 0) {
        testSuite.prompts = resumeEval.prompts.map(
          (p) =>
            ({
              raw: p.raw,
              label: p.label,
              config: p.config,
            }) as any,
        );
      }
    } else if (retryErrors) {
      // Check if --no-write is set with --retry-errors
      if (cmdObj.write === false) {
        return failEvalRun(
          'Cannot use --retry-errors with --no-write. Retry functionality requires database persistence.',
          isCliInvocation,
        );
      }

      logger.info('🔄 Retrying ERROR results from latest evaluation...');

      // Find the latest evaluation
      const latestEval = await Eval.latest();
      if (!latestEval) {
        const message = 'No previous evaluation found to retry errors from';
        return failEvalRun(message, isCliInvocation, {
          logForCli: () => logger.error(message),
        });
      }

      // Get all ERROR result IDs - capture BEFORE retry so we know what to delete on success
      retryErrorResultIds = await getErrorResultIds(latestEval.id);
      if (retryErrorResultIds.length === 0) {
        logger.info('✅ No ERROR results found in the latest evaluation');
        return latestEval;
      }

      logger.info(`Found ${retryErrorResultIds.length} ERROR results to retry`);

      // NOTE (v0.121.0): ERROR results are deleted AFTER successful retry, not before.
      // Previously, deletion happened before evaluate(), causing data loss if retry failed.
      // Now we delete AFTER successful retry to preserve ERROR results for re-retry on failure.
      logger.info(
        `🔄 Running evaluation with resume mode to retry ${retryErrorResultIds.length} test cases...`,
      );

      // Set up for resume mode
      resumeEval = latestEval;

      // Use the saved config as our base to ensure identical test ordering
      ({
        config,
        testSuite,
        basePath: _basePath,
        commandLineOptions,
      } = await resolveReplayConfigs(resumeEval, 'retrying errors for'));

      // Ensure prompts exactly match the previous run to preserve IDs and content
      if (Array.isArray(resumeEval.prompts) && resumeEval.prompts.length > 0) {
        testSuite.prompts = resumeEval.prompts.map(
          (p) =>
            ({
              raw: p.raw,
              label: p.label,
              config: p.config,
            }) as any,
        );
      }
    } else {
      ({
        config,
        testSuite,
        basePath: _basePath,
        commandLineOptions,
      } = await resolveConfigs(cmdObj, defaultConfig));
    }

    const describeReplayAction = (isRetryErrors: boolean | undefined) =>
      isRetryErrors ? 'retrying errors for' : 'resuming';

    const persistedProviderFilterOptions = resumeEval
      ? getPersistedProviderFilterOptions(resumeEval.runtimeOptions?.providerFilter)
      : {};
    const persistedProviderFilter = persistedProviderFilterOptions.filterProviders;
    const cliProviderFilter = cmdObj.filterProviders || cmdObj.filterTargets;
    if (resumeEval && cliProviderFilter && cliProviderFilter !== persistedProviderFilter) {
      logger.warn(
        `Ignoring --filter-providers/--filter-targets "${cliProviderFilter}": ${describeReplayAction(retryErrors)} evaluation ${resumeEval.id} with stored provider filter ${persistedProviderFilter ? `"${persistedProviderFilter}"` : '(none)'} to preserve test indices.`,
      );
    }
    if (resumeEval && persistedProviderFilter && testSuite.providers.length === 0) {
      return failEvalRun(
        `Stored provider filter "${persistedProviderFilter}" matched no providers while ${describeReplayAction(retryErrors)} evaluation ${resumeEval.id}. The evaluation was not changed.`,
        isCliInvocation,
      );
    }
    if (resumeEval) {
      cliState.resume = true;
      if (retryErrorResultIds) {
        cliState.retryMode = true;
        cliState._retryErrorResultIds = retryErrorResultIds;
      }
    }

    // Phase 2: Load environment from config files if not already set via CLI
    if ((!cmdObj.envPath || cmdObj.envPath.length === 0) && commandLineOptions?.envPath) {
      logger.debug(`Loading additional environment from config: ${commandLineOptions.envPath}`);
      setupEnv(commandLineOptions.envPath);
    }

    warnIfRedteamConfigHasNoTests(config, testSuite);

    // TODO(faizan): Crazy condition to see when we run the example redteam config.
    // Remove this once we have a better way to track this.
    if (
      config.redteam &&
      Array.isArray(config.providers) &&
      config.providers.length > 0 &&
      typeof config.providers[0] === 'object' &&
      config.providers[0].id === 'http'
    ) {
      const maybeUrl: unknown = (config.providers[0] as any)?.config?.url;
      if (typeof maybeUrl === 'string' && maybeUrl.includes('promptfoo.app')) {
        telemetry.record('feature_used', {
          feature: 'redteam_run_with_example',
        });
      }
    }

    // Ensure evaluateOptions from the config file are applied. Pin eventSource
    // to the caller's value — a config file must not be able to flip a library
    // run into CLI semantics (process.exitCode mutation, SIGINT handlers).
    if (config.evaluateOptions) {
      evaluateOptions = {
        ...evaluateOptions,
        ...config.evaluateOptions,
        eventSource: evaluateOptions.eventSource,
        generationEventId: evaluateOptions.generationEventId,
        generationTokenUsage: evaluateOptions.generationTokenUsage,
      };
    }

    // Resolve runtime options. If resuming, prefer persisted options stored with the eval.
    let repeat: number;
    let cache: boolean | undefined;
    let maxConcurrency: number;
    let delay: number;
    if (resumeRaw) {
      const persisted = (resumeEval?.runtimeOptions ||
        config.evaluateOptions ||
        {}) as InternalEvaluateOptions;
      repeat =
        Number.isSafeInteger(persisted.repeat || 0) && (persisted.repeat as number) > 0
          ? (persisted.repeat as number)
          : 1;
      cache = persisted.cache ?? true;
      maxConcurrency = (persisted.maxConcurrency as number | undefined) ?? DEFAULT_MAX_CONCURRENCY;
      delay = (persisted.delay as number | undefined) ?? 0;
    } else {
      // Misc settings with proper CLI vs config priority
      // CLI values explicitly provided by user should override config, but defaults should not
      const iterations =
        cmdObj.repeat ?? commandLineOptions?.repeat ?? evaluateOptions.repeat ?? Number.NaN;
      repeat = Number.isSafeInteger(iterations) && iterations > 0 ? iterations : 1;
      cache = cmdObj.cache ?? commandLineOptions?.cache ?? evaluateOptions.cache ?? true;
      maxConcurrency =
        cmdObj.maxConcurrency ??
        commandLineOptions?.maxConcurrency ??
        evaluateOptions.maxConcurrency ??
        DEFAULT_MAX_CONCURRENCY;
      delay = cmdObj.delay ?? commandLineOptions?.delay ?? evaluateOptions.delay ?? 0;
    }

    if (cache === false) {
      logger.info('Cache is disabled.');
      disableCache();
    }

    // Propagate maxConcurrency to cliState for providers (e.g., Python worker pool)
    // Check if maxConcurrency was explicitly set (not using DEFAULT_MAX_CONCURRENCY)
    // For resume mode, include persisted value as "explicit", with fallback to config when
    // runtimeOptions are missing (e.g., older evals that didn't persist runtimeOptions)
    const explicitMaxConcurrency = resumeRaw
      ? ((resumeEval?.runtimeOptions as InternalEvaluateOptions | undefined)?.maxConcurrency ??
        cmdObj.maxConcurrency ??
        commandLineOptions?.maxConcurrency ??
        evaluateOptions.maxConcurrency)
      : (cmdObj.maxConcurrency ??
        commandLineOptions?.maxConcurrency ??
        evaluateOptions.maxConcurrency);

    if (delay > 0) {
      maxConcurrency = 1;
      // Also limit Python workers to 1 when delay is set (no point having more workers than concurrency)
      cliState.maxConcurrency = 1;
      logger.info(
        `Running at concurrency=1 because ${delay}ms delay was requested between API calls`,
      );
    } else if (explicitMaxConcurrency !== undefined) {
      cliState.maxConcurrency = explicitMaxConcurrency;
    }

    const hasScenarios = Boolean(testSuite.scenarios?.length);
    const canSynthesizeImplicitDefaultTest = testSuite.scenarios === undefined;
    const explicitTestCountBeforeFiltering = testSuite.tests?.length;
    const resumeRuntimeOptions = resumeEval?.runtimeOptions as InternalEvaluateOptions | undefined;
    const persistedFilterRange =
      typeof resumeRuntimeOptions?.filterRange === 'string'
        ? resumeRuntimeOptions.filterRange
        : undefined;
    const resumeConfigFilterRange = commandLineOptions?.filterRange ?? evaluateOptions.filterRange;
    const resumeFilterRange = persistedFilterRange ?? resumeConfigFilterRange;
    if (resumeEval && cmdObj.filterRange && cmdObj.filterRange !== resumeFilterRange) {
      logger.warn(
        `Ignoring --filter-range ${cmdObj.filterRange}: resuming ${resumeEval.id} with stored range ${resumeFilterRange ?? '(none)'} to preserve test indices.`,
      );
    }
    const filterRange = resumeEval
      ? resumeFilterRange
      : (cmdObj.filterRange ?? commandLineOptions?.filterRange ?? evaluateOptions.filterRange);
    const filterSample = cmdObj.filterSample ?? commandLineOptions?.filterSample;
    const filterSampleSeed = cmdObj.filterSampleSeed ?? commandLineOptions?.filterSampleSeed;
    const hasActiveTestFilter =
      filterRange !== undefined ||
      cmdObj.filterFailing !== undefined ||
      cmdObj.filterFailingOnly !== undefined ||
      cmdObj.filterErrorsOnly !== undefined ||
      cmdObj.filterFirstN !== undefined ||
      cmdObj.filterMetadata !== undefined ||
      cmdObj.filterPattern !== undefined ||
      filterSample !== undefined;
    const shouldApplyFiltersToImplicitDefaultTest =
      hasActiveTestFilter && canSynthesizeImplicitDefaultTest && !testSuite.tests?.length;

    // Apply filtering only when not resuming, to preserve test indices
    if (!resumeEval) {
      if (shouldApplyFiltersToImplicitDefaultTest) {
        const defaultMetadata =
          typeof testSuite.defaultTest === 'object' ? testSuite.defaultTest?.metadata : undefined;
        testSuite.tests = defaultMetadata ? [{ metadata: defaultMetadata }] : [{}];
      }
      const filterOptions: FilterOptions = {
        failing: cmdObj.filterFailing,
        failingOnly: cmdObj.filterFailingOnly,
        errorsOnly: cmdObj.filterErrorsOnly,
        firstN: cmdObj.filterFirstN,
        metadata: cmdObj.filterMetadata,
        pattern: cmdObj.filterPattern,
        range: hasScenarios ? undefined : filterRange,
        sample: filterSample,
        sampleSeed: filterSampleSeed,
      };
      testSuite.tests = await filterTests(testSuite, filterOptions);
      const shouldSuppressImplicitDefaultTest =
        testSuite.tests.length === 0 &&
        ((explicitTestCountBeforeFiltering ?? 0) > 0 || shouldApplyFiltersToImplicitDefaultTest);
      if (!hasScenarios && shouldSuppressImplicitDefaultTest) {
        testSuite.scenarios = [];
      }
    }

    if (
      !neverGenerateRemote() &&
      config.redteam &&
      config.redteam.plugins &&
      config.redteam.plugins.length > 0 &&
      testSuite.tests &&
      testSuite.tests.length > 0
    ) {
      let hasValidEmail = false;
      while (!hasValidEmail) {
        const { emailNeedsValidation } = await promptForEmailUnverified();
        const res = await checkEmailStatusAndMaybeExit({ validate: emailNeedsValidation });
        hasValidEmail = res === EMAIL_OK_STATUS;
      }
    }

    if (!resumeEval) {
      testSuite.providers = filterProviders(
        testSuite.providers,
        cmdObj.filterProviders || cmdObj.filterTargets,
      );
    }

    // Check for missing API keys after provider filtering
    const missingApiKeys = checkProviderApiKeys(testSuite.providers, { useDescriptions: true });

    if (missingApiKeys.size > 0) {
      const missingKeysMessage = `Missing required API keys: ${Array.from(missingApiKeys.entries())
        .map(([envVar, providerDescriptions]) => `${envVar} (${providerDescriptions.join(', ')})`)
        .join('; ')}`;
      return failEvalRun(missingKeysMessage, isCliInvocation, {
        logForCli: () => {
          for (const [envVar, providerDescriptions] of missingApiKeys) {
            logger.error(chalk.red(`  ✗ Missing ${envVar} (${providerDescriptions.join(', ')})`));
          }
          logger.error('');
          logger.error(`To fix, set the environment variable or use ${chalk.bold('--env-file')}:`);
          for (const envVar of missingApiKeys.keys()) {
            logger.error(`    export ${envVar}=your-api-key-here`);
          }
          logger.error('');
        },
      });
    }

    await checkCloudPermissions(config as UnifiedConfig);

    const providerFilter = resumeEval ? persistedProviderFilter : cliProviderFilter;

    // Strip any providerFilter a config file injected via evaluateOptions — only the
    // normalized CLI/persisted value above may be persisted and replayed.
    const { providerFilter: _ignoredProviderFilter, ...safeEvaluateOptions } =
      evaluateOptions as InternalEvaluateOptions & { providerFilter?: unknown };
    const options: InternalEvaluateOptions = {
      ...safeEvaluateOptions,
      showProgressBar:
        getLogLevel() === 'debug'
          ? false
          : cmdObj.progressBar === undefined
            ? evaluateOptions.showProgressBar === undefined
              ? true
              : evaluateOptions.showProgressBar
            : cmdObj.progressBar !== false,
      repeat,
      delay: !Number.isNaN(delay) && delay > 0 ? delay : undefined,
      filterRange,
      maxConcurrency,
      cache,
    };

    if (!resumeEval && cmdObj.grader) {
      if (typeof testSuite.defaultTest === 'string') {
        testSuite.defaultTest = {};
      }
      testSuite.defaultTest = testSuite.defaultTest || {};
      testSuite.defaultTest.options = testSuite.defaultTest.options || {};
      testSuite.defaultTest.options.provider = await loadApiProvider(cmdObj.grader, {
        basePath: cliState.basePath,
      });
      // Also update cliState.config so redteam providers can access the grader
      if (cliState.config) {
        // Normalize string shorthand to object
        if (typeof cliState.config.defaultTest === 'string') {
          cliState.config.defaultTest = {};
        }
        cliState.config.defaultTest = cliState.config.defaultTest || {};
        cliState.config.defaultTest.options = cliState.config.defaultTest.options || {};
        cliState.config.defaultTest.options.provider = testSuite.defaultTest.options.provider;
      }
    }
    if (!resumeEval && cmdObj.var) {
      if (typeof testSuite.defaultTest === 'string') {
        testSuite.defaultTest = {};
      }
      testSuite.defaultTest = testSuite.defaultTest || {};
      testSuite.defaultTest.vars = { ...testSuite.defaultTest.vars, ...cmdObj.var };
    }
    const runtimeTags = resumeEval ? undefined : runtimeTagsForEval(cmdObj, commandLineOptions);
    if (runtimeTags) {
      // config.tags is the persisted sink (Eval.create reads it); cliState.config
      // is the same object reference, and nothing reads testSuite.tags.
      config.tags = { ...(config.tags || {}), ...runtimeTags };
    }
    if (!resumeEval) {
      Object.assign(options, resolveSuggestionOptions(cmdObj, commandLineOptions, options));
    }
    // load scenarios or tests from an external file
    if (testSuite.scenarios) {
      testSuite.scenarios = (await maybeLoadFromExternalFile(testSuite.scenarios)) as Scenario[];
      // Flatten the scenarios array in case glob patterns were used
      testSuite.scenarios = testSuite.scenarios.flat();
    }
    for (const scenario of testSuite.scenarios || []) {
      if (scenario.tests) {
        scenario.tests = await maybeLoadFromExternalFile(scenario.tests);
      }
    }

    const testSuiteSchema = TestSuiteSchema.safeParse(testSuite);
    if (!testSuiteSchema.success) {
      logger.warn(
        chalk.yellow(dedent`
      TestSuite Schema Validation Error:

        ${z.prettifyError(testSuiteSchema.error)}

      Please review your promptfooconfig.yaml configuration.`),
      );
    }

    const runtimeOptions: EvalRuntimeOptions = {
      ...options,
      ...(providerFilter ? { providerFilter } : {}),
    };

    if (!resumeEval && config.metadata && 'generationAccounting' in config.metadata) {
      const { generationAccounting: _staleGenerationAccounting, ...metadata } = config.metadata;
      config = { ...config, metadata };
    }

    if (!resumeEval && evaluateOptions.generationTokenUsage) {
      config = {
        ...config,
        metadata: {
          ...(config.metadata ?? {}),
          generationAccounting: {
            id: evaluateOptions.generationEventId,
            tokenUsage: evaluateOptions.generationTokenUsage,
          },
        },
      };
    }

    // Create or load eval record
    const author = getAuthor();
    const evalRecord = resumeEval
      ? resumeEval
      : cmdObj.write
        ? await Eval.create(config, testSuite.prompts, { author, runtimeOptions })
        : new Eval(config, { author, runtimeOptions });

    // Graceful pause support via Ctrl+C (only when writing to database)
    const abortController = new AbortController();
    const previousAbortSignal = evaluateOptions.abortSignal;
    evaluateOptions.abortSignal = previousAbortSignal
      ? AbortSignal.any([previousAbortSignal, abortController.signal])
      : abortController.signal;

    let paused = false;
    let sigintHandler: NodeJS.SignalsListener | undefined;
    let forceExitTimeout: NodeJS.Timeout | undefined;

    const cleanupHandler = () => {
      if (sigintHandler) {
        process.removeListener('SIGINT', sigintHandler);
        sigintHandler = undefined;
      }
      if (forceExitTimeout) {
        clearTimeout(forceExitTimeout);
        forceExitTimeout = undefined;
      }
      // Restore original abort signal for watch mode
      evaluateOptions.abortSignal = previousAbortSignal;
    };

    // Pause/resume SIGINT behavior is CLI policy. Reusable callers should own cancellation.
    if (isCliInvocation && cmdObj.write !== false) {
      sigintHandler = () => {
        // Atomic check-and-set to handle rapid successive SIGINTs safely
        const wasPaused = paused;
        paused = true;

        if (wasPaused) {
          // Second Ctrl+C: immediate force exit
          // Clear the timeout to avoid resource leak
          if (forceExitTimeout) {
            clearTimeout(forceExitTimeout);
            forceExitTimeout = undefined;
          }
          // Skip closeDbIfOpen() - it could block on WAL checkpoint, defeating the escape hatch
          // Database will recover on next run via WAL replay
          logger.warn('Force exiting...');
          process.exit(130);
        }

        logger.info(chalk.yellow('Pausing evaluation... Press Ctrl+C again to force exit.'));
        abortController.abort();

        // Set a timeout for force exit if evaluate() hangs after abort signal
        // Note: This covers the evaluation phase only. Shutdown (telemetry/logger)
        // is covered by main.ts signal handling.
        forceExitTimeout = setTimeout(() => {
          // Skip closeDbIfOpen() - could block, defeating the timeout
          logger.warn('Evaluation shutdown timed out, force exiting...');
          process.exit(130);
        }, 10000).unref();
      };

      // Use process.on instead of process.once to handle second Ctrl+C
      process.on('SIGINT', sigintHandler);
    }

    // Run the evaluation!!!!!!
    let ret;
    try {
      ret = await evaluate(testSuite, evalRecord, {
        ...options,
        filterRange: hasScenarios || resumeEval ? filterRange : undefined,
        abortSignal: evaluateOptions.abortSignal,
        isRedteam: Boolean(config.redteam),
      });

      // Post-evaluation cleanup for retry-errors mode
      // SUCCESS: Now it's safe to delete the old ERROR results and recalculate metrics
      // Skip if evaluation was paused - no point cleaning up incomplete retry
      if (retryErrors && cliState._retryErrorResultIds && !paused) {
        const errorResultIds = cliState._retryErrorResultIds;
        try {
          await deleteErrorResults(errorResultIds);
          await recalculatePromptMetrics(ret);
          logger.debug(
            `Cleaned up ${errorResultIds.length} old ERROR results after successful retry`,
          );
        } catch (cleanupError) {
          // Cleanup failure is non-fatal - retry itself succeeded
          logger.warn('Post-retry cleanup had issues. Retry results are saved.', {
            error: cleanupError,
          });
        } finally {
          // Clear the stored error result IDs
          delete cliState._retryErrorResultIds;
          // Clear retry mode flags
          cliState.retryMode = false;
        }
      }
    } finally {
      cleanupHandler(); // Always cleanup, even if evaluate() throws
    }

    // Clear resume flag after run completes
    cliState.resume = false;

    // If paused, print minimal guidance and skip the rest of the reporting
    if (paused && cmdObj.write !== false) {
      printBorder();
      logger.info(`${chalk.yellow('⏸')} Evaluation paused. ID: ${chalk.cyan(evalRecord.id)}`);
      logger.info(`» Resume with: ${chalk.green.bold('promptfoo eval --resume ' + evalRecord.id)}`);
      printBorder();
      return ret;
    }

    // Persisted evals can reload results later. No-write evals only have the
    // in-memory results left for table and output rendering.
    if (evalRecord.persisted) {
      evalRecord.clearResults();
    }

    // Determine sharing using shared utility (DRY - same logic as retry command)
    const wantsToShare = shouldShareResults({
      cliShare: cmdObj.share,
      cliNoShare: cmdObj.noShare,
      configShare: commandLineOptions?.share,
      configSharing: config.sharing,
    });
    const hasExplicitDisable =
      cmdObj.share === false || cmdObj.noShare === true || getEnvBool('PROMPTFOO_DISABLE_SHARING');

    const canShareEval = isSharingEnabled(evalRecord);

    logger.debug(`Wants to share: ${wantsToShare}`);
    logger.debug(`Can share eval: ${canShareEval}`);

    // Start sharing in background (don't await yet) - this allows us to show results immediately
    const willShare = wantsToShare && canShareEval;
    let sharePromise: Promise<string | null> | null = null;
    if (willShare) {
      // Start the share operation in background with silent mode (no progress bar)
      sharePromise = createShareableUrl(evalRecord, { silent: true });
    }

    let successes = 0;
    let failures = 0;
    let errors = 0;
    const tokenUsage = createEmptyTokenUsage();

    // Calculate our total successes and failures
    for (const prompt of evalRecord.prompts) {
      if (prompt.metrics?.testPassCount) {
        successes += prompt.metrics.testPassCount;
      }
      if (prompt.metrics?.testFailCount) {
        failures += prompt.metrics.testFailCount;
      }
      if (prompt.metrics?.testErrorCount) {
        errors += prompt.metrics.testErrorCount;
      }
      accumulateTokenUsage(tokenUsage, prompt.metrics?.tokenUsage);
    }
    const generationTokenUsage = evalRecord.getStats().tokenUsage.generation;
    if (generationTokenUsage) {
      tokenUsage.generation = generationTokenUsage;
    }
    const totalTests = successes + failures + errors;
    const passRate = (successes / totalTests) * 100;

    // Output results table immediately (before share completes)
    if (cmdObj.table && getLogLevel() !== 'debug' && totalTests < 500) {
      const table = await evalRecord.getTable();
      // Output CLI table
      const outputTable = generateTable(
        table,
        cmdObj.tableCellMaxLength ?? commandLineOptions?.tableCellMaxLength,
      );

      logger.info('\n' + outputTable);
      if (table.body.length > 25) {
        const rowsLeft = table.body.length - 25;
        logger.info(`... ${rowsLeft} more row${rowsLeft === 1 ? '' : 's'} not shown ...\n`);
      }
    } else if (failures !== 0) {
      logger.debug(
        `At least one evaluation failure occurred. This might be caused by the underlying call to the provider, or a test failure. Context: \n${JSON.stringify(
          evalRecord.prompts,
        )}`,
      );
    }

    if (totalTests >= 500) {
      logger.info('Skipping table output because there are more than 500 tests.');
    }

    const { outputPath } = config;

    // JSONL rows are streamed (already redacted) during evaluation, then the file is
    // rewritten from the completed eval so rows that were never streamed — timeout rows
    // and deferred max-score/select-best grading — are reflected on disk.
    const paths = (Array.isArray(outputPath) ? outputPath : [outputPath]).filter(
      (p): p is string => typeof p === 'string' && p.length > 0,
    );

    const isRedteam = Boolean(config.redteam);
    const duration = Math.round((Date.now() - startTime) / 1000);
    const tracker = TokenUsageTracker.getInstance();

    // Check if scan was aborted due to target error (efficient DB query, not loading all results)
    const targetErrorStatus = await evalRecord.findTargetErrorStatus();

    // Generate and display summary immediately (before share completes)
    const summaryLines = generateEvalSummary({
      evalId: evalRecord.id,
      isRedteam,
      writeToDatabase: cmdObj.write !== false,
      shareableUrl: null, // Not available yet if sharing in background
      wantsToShare,
      hasExplicitDisable,
      cloudEnabled: cloudConfig.isEnabled(),
      activelySharing: willShare,
      tokenUsage,
      successes,
      failures,
      errors,
      duration,
      maxConcurrency,
      tracker,
      targetErrorStatus,
    });

    // Special case: show cloud signup instructions when user wants to share but can't
    if (cmdObj.write && wantsToShare && !canShareEval) {
      logger.info(summaryLines[0]); // Show just the completion message
      notCloudEnabledShareInstructions();
      // Skip the guidance lines and show the rest
      for (let i = 1; i < summaryLines.length; i++) {
        if (summaryLines[i].includes('View results:')) {
          // Skip guidance section
          while (i < summaryLines.length && !summaryLines[i].includes('Total Tokens:')) {
            i++;
          }
          i--; // Back up one so the for loop increment works
        } else {
          logger.info(summaryLines[i]);
        }
      }
    } else {
      // Normal case: show all summary lines
      for (const line of summaryLines) {
        logger.info(line);
      }
    }

    // Now wait for share to complete and show spinner (as the last output)
    let shareableUrl: string | null = null;
    if (sharePromise != null) {
      // Determine org context for spinner text
      const orgContext = await getOrgContext();
      const orgSuffix = orgContext
        ? ` to ${orgContext.organizationName}${orgContext.teamName ? ` > ${orgContext.teamName}` : ''}`
        : '';

      // Only show spinner in TTY (not CI)
      if (process.stdout.isTTY && !isCI()) {
        const spinner = ora({
          text: `Sharing${orgSuffix}...`,
          prefixText: chalk.dim('»'),
          spinner: 'dots',
        }).start();

        try {
          shareableUrl = await sharePromise;
          if (shareableUrl) {
            evalRecord.shared = true;
            spinner.succeed(shareableUrl);
          } else {
            spinner.fail(chalk.red('Share failed'));
          }
        } catch (error) {
          spinner.fail(chalk.red('Share failed'));
          logger.debug(`Share error: ${error}`);
        }
      } else {
        // CI mode - just await and log result
        try {
          shareableUrl = await sharePromise;
          if (shareableUrl) {
            evalRecord.shared = true;
            logger.info(`${chalk.dim('»')} ${chalk.green('✓')} ${shareableUrl}`);
          }
        } catch (error) {
          logger.debug(`Share error: ${error}`);
        }
      }
    }

    logger.debug(`Shareable URL: ${shareableUrl}`);

    // Write outputs after share completes (so we can include shareableUrl)
    warnOnDegradedJsonlRecovery(evalRecord, paths);
    if (paths.length) {
      await writeMultipleOutputs(paths, evalRecord, shareableUrl);
      logger.info(chalk.yellow(`Writing output to ${paths.join(', ')}`));
    }

    telemetry.record('command_used', {
      name: 'eval',
      watch: Boolean(cmdObj.watch),
      duration: Math.round((Date.now() - startTime) / 1000),
      isRedteam,
    });

    if (cmdObj.watch && !resumeEval) {
      if (initialization) {
        const configPaths = (cmdObj.config || [defaultConfigPath]).filter(Boolean) as string[];
        if (!configPaths.length) {
          const message = `Could not locate config file(s) to watch. Pass --config path/to/promptfooconfig.yaml or run from a directory containing promptfooconfig.{${DEFAULT_CONFIG_EXTENSIONS.join(
            ',',
          )}}.`;
          return failEvalRun(message, isCliInvocation, {
            logForCli: () => logger.error(message),
            cliFallback: ret,
          });
        }
        const basePath = path.dirname(configPaths[0]);
        const promptPaths = Array.isArray(config.prompts)
          ? (config.prompts
              .map((p) => {
                if (typeof p === 'string' && p.startsWith('file://')) {
                  return path.resolve(basePath, p.slice('file://'.length));
                } else if (typeof p === 'object' && p.id && p.id.startsWith('file://')) {
                  return path.resolve(basePath, p.id.slice('file://'.length));
                }
                return null;
              })
              .filter(Boolean) as string[])
          : [];
        const providerPaths = Array.isArray(config.providers)
          ? (config.providers
              .map((p) =>
                typeof p === 'string' && p.startsWith('file://')
                  ? path.resolve(basePath, p.slice('file://'.length))
                  : null,
              )
              .filter(Boolean) as string[])
          : [];
        // `--tests`, and its `--vars` alias, replace the config's own tests entirely
        // (see resolveConfigs), so `config.tests` already holds the command-line value.
        const cliTests = cmdObj.tests || cmdObj.vars;
        const varPaths: string[] = [];
        if (cliTests) {
          // resolveConfigs loads `--tests` with no base path, so it resolves against the
          // working directory rather than the directory holding the config file.
          // `--vars` keeps the config's base path.
          varPaths.push(
            ...resolveTestsWatchPaths(cliTests, cmdObj.tests ? process.cwd() : basePath),
          );
        } else {
          // The array form survives combineConfigs() untouched, so inline test cases and
          // their `vars` file references are still readable from the resolved config.
          varPaths.push(...resolveTestsWatchPaths(config.tests, basePath));
          // A scalar reference (`tests: file://cases.yaml`) and a generator object are
          // expanded into concrete test cases by combineConfigs(), so by this point the
          // reference they came from is gone. Recover it by reading the config again.
          for (const configPathPattern of configPaths) {
            // --config accepts globs, which combineConfigs() expands, so expand here too
            // rather than handing a literal wildcard to the reader.
            const resolvedConfigPaths = globSync(path.resolve(process.cwd(), configPathPattern), {
              windowsPathsNoEscape: true,
            });
            for (const resolvedConfigPath of resolvedConfigPaths) {
              if (!isDeclarativeConfig(resolvedConfigPath)) {
                continue;
              }
              const rawConfig = await maybeReadConfig(resolvedConfigPath);
              if (rawConfig?.tests != null && !Array.isArray(rawConfig.tests)) {
                varPaths.push(
                  ...resolveTestsWatchPaths(rawConfig.tests, path.dirname(resolvedConfigPath)),
                );
              }
            }
          }
        }
        const watchPaths = Array.from(
          new Set([...configPaths, ...promptPaths, ...providerPaths, ...varPaths]),
        );
        const watcher = chokidar.watch(watchPaths, { ignored: /^\./, persistent: true });
        // Library callers own their own process lifetime, so only the CLI blocks here.
        if (isCliInvocation) {
          watchTermination = watchUntilTerminated(watcher);
        }

        watcher
          .on('change', async (path) => {
            printBorder();
            logger.info(`File change detected: ${path}`);
            printBorder();
            clearConfigCache();
            try {
              await runEvaluation();
            } catch (error) {
              if (handleRecoverableWatchError(error)) {
                return;
              }
              throw error;
            }
          })
          .on('error', (error) => logger.error(`Watcher error: ${error}`))
          .on('ready', () =>
            watchPaths.forEach((watchPath) =>
              logger.info(`Watching for file changes on ${watchPath} ...`),
            ),
          );
      }
    } else {
      const passRateThreshold = getEnvFloat('PROMPTFOO_PASS_RATE_THRESHOLD', 100);
      const failedTestExitCode = getEnvInt('PROMPTFOO_FAILED_TEST_EXIT_CODE', 100);

      if (
        isCliInvocation &&
        passRate < (Number.isFinite(passRateThreshold) ? passRateThreshold : 100)
      ) {
        if (getEnvFloat('PROMPTFOO_PASS_RATE_THRESHOLD') !== undefined) {
          logger.info(
            chalk.white(
              `Pass rate ${chalk.red.bold(passRate.toFixed(2))}${chalk.red('%')} is below the threshold of ${chalk.red.bold(passRateThreshold)}${chalk.red('%')}`,
            ),
          );
        }
        process.exitCode = Number.isSafeInteger(failedTestExitCode) ? failedTestExitCode : 100;
        return ret;
      }
    }
    if (testSuite.redteam) {
      showRedteamProviderLabelMissingWarning(testSuite);
    }

    // Clean up any WebSocket connections
    if (testSuite.providers.length > 0) {
      for (const provider of testSuite.providers) {
        if (isApiProvider(provider)) {
          const cleanup = provider?.cleanup?.();
          if (cleanup instanceof Promise) {
            await cleanup;
          }
        }
      }
    }

    return ret;
  };

  const result = await runEvaluation(true /* initialization */);
  if (watchTermination) {
    await watchTermination;
  }
  return result;
}
