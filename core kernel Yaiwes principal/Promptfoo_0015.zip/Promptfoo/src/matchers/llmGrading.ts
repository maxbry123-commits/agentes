import cliState from '../cliState';
import logger from '../logger';
import {
  DEFAULT_GRADING_PROMPT,
  GEVAL_PROMPT_EVALUATE,
  GEVAL_PROMPT_STEPS,
  OPENAI_CLOSED_QA_PROMPT,
  PROMPTFOO_FACTUALITY_PROMPT,
  TRAJECTORY_GOAL_SUCCESS_PROMPT,
} from '../prompts/index';
import { getDefaultProviders } from '../providers/defaults';
import { doRemoteGrading } from '../remoteGrading';
import { doRemoteScoringWithPi } from '../remoteScoring';
import invariant from '../util/invariant';
import { extractFirstJsonObject } from '../util/json';
import { accumulateTokenUsage } from '../util/tokenUsageUtils';
import {
  callProviderWithContext,
  getAndCheckProvider,
  getRemoteGradingContext,
  shouldUseRemoteGrading,
} from './providers';
import {
  LlmRubricProviderError,
  loadRubricPrompt,
  materializeImageOutputsForGrading,
  renderLlmRubricPrompt,
  runJsonGradingPrompt,
} from './rubric';
import { fail, graderFail, normalizeMatcherTokenUsage, tryParse } from './shared';

import type {
  Assertion,
  CallApiContextParams,
  GradingConfig,
  GradingResult,
  ProviderResponse,
  VarValue,
} from '../types/index';

type LlmRubricGradingConfig = GradingConfig & {
  __promptfooPreferRemote?: boolean;
};

const ATTACHED_IMAGE_OUTPUT_PLACEHOLDER =
  '[Image output attached. Inspect the attached image directly for visual grading.]';

const FACTUALITY_CATEGORY_DESCRIPTIONS: Record<string, string> = {
  A: 'The submitted answer is a subset of the expert answer and is fully consistent with it.',
  B: 'The submitted answer is a superset of the expert answer and is fully consistent with it.',
  C: 'The submitted answer contains all the same details as the expert answer.',
  D: 'There is a disagreement between the submitted answer and the expert answer.',
  E: "The answers differ, but these differences don't matter from the perspective of factuality.",
};

function getFactualityScoreLookup(grading: GradingConfig): Record<string, number> {
  return {
    A: grading.factuality?.subset ?? 1,
    B: grading.factuality?.superset ?? 1,
    C: grading.factuality?.agree ?? 1,
    D: grading.factuality?.disagree ?? 0,
    E: grading.factuality?.differButFactual ?? 1,
  };
}

function buildFactualityResult(
  option: string,
  reason: string,
  grading: GradingConfig,
  resp: ProviderResponse,
): Omit<GradingResult, 'assertion'> {
  const scoreLookup = getFactualityScoreLookup(grading);
  const passing = Object.keys(scoreLookup).filter((key) => scoreLookup[key] > 0);
  const failing = Object.keys(scoreLookup).filter((key) => scoreLookup[key] === 0);
  const pass = passing.includes(option) && !failing.includes(option);
  const score = scoreLookup[option] ?? (pass ? 1 : 0);

  return {
    pass,
    score,
    reason,
    tokensUsed: normalizeMatcherTokenUsage(resp.tokenUsage),
  };
}

function parseFactualityJsonResponse(
  responseText: string,
): { option: string; reason: string } | undefined {
  try {
    const jsonData = extractFirstJsonObject<{ category?: string; reason?: string }>(responseText);
    if (!jsonData?.category || typeof jsonData.category !== 'string') {
      return undefined;
    }

    const option = jsonData.category.trim().toUpperCase();
    if (!/^[A-E]$/.test(option)) {
      throw new Error(`Invalid category value: ${option}`);
    }

    return {
      option,
      reason:
        jsonData.reason?.trim() ||
        `Category ${option}: ${FACTUALITY_CATEGORY_DESCRIPTIONS[option]}`,
    };
  } catch (err) {
    const error = err as Error;
    if (error.message.startsWith('Invalid category value:')) {
      throw error;
    }
    logger.debug(`JSON parsing failed: ${error.message}`);
    return undefined;
  }
}

function parseLegacyFactualityResponse(responseText: string): { option: string; reason: string } {
  const answerMatch = responseText.match(/\s*\(?([a-eA-E])\)/);
  if (!answerMatch) {
    throw new Error(`Factuality checker output did not match expected format: ${responseText}`);
  }

  const option = answerMatch[1].toUpperCase();
  const reasonMatch = responseText.match(/\)\s*(.*)/s);

  return {
    option,
    reason: reasonMatch?.[1] ? reasonMatch[1].trim() : responseText,
  };
}

function getDataUriPayload(data: string): string | undefined {
  const [metadata, payload] = data.trim().split(',', 2);
  if (!payload || !metadata.toLowerCase().startsWith('data:image/')) {
    return undefined;
  }
  return payload;
}

function getGradingOutputForImages(llmOutput: string, imageOutputs: ProviderResponse['images']) {
  if (!imageOutputs?.length) {
    return llmOutput;
  }

  const trimmedOutput = llmOutput.trim();
  if (!trimmedOutput) {
    return ATTACHED_IMAGE_OUTPUT_PLACEHOLDER;
  }

  if (/^data:image\/[^;,]+;base64,/i.test(trimmedOutput)) {
    return ATTACHED_IMAGE_OUTPUT_PLACEHOLDER;
  }

  if (
    imageOutputs.some((image) => {
      if (!image.data) {
        return false;
      }
      const imageData = image.data.trim();
      return imageData === trimmedOutput || getDataUriPayload(imageData) === trimmedOutput;
    })
  ) {
    return ATTACHED_IMAGE_OUTPUT_PLACEHOLDER;
  }

  return llmOutput;
}

export async function matchesLlmRubric(
  rubric: string | object,
  llmOutput: string,
  grading?: GradingConfig,
  vars?: Record<string, VarValue>,
  assertion?: Assertion,
  options?: {
    throwOnError?: boolean;
    preferRemote?: boolean;
    providerResponse?: ProviderResponse;
  },
  providerCallContext?: CallApiContextParams,
): Promise<GradingResult> {
  if (!grading) {
    throw new Error(
      'Cannot grade output without grading config. Specify --grader option or grading config.',
    );
  }

  // Use remote grading when no provider is explicitly configured, or when a
  // caller injected an implicit default provider but still prefers remote.
  const shouldPreferRemote =
    options?.preferRemote ||
    (grading as LlmRubricGradingConfig).__promptfooPreferRemote ||
    !grading.provider;
  const { imageOutputs } = materializeImageOutputsForGrading(options?.providerResponse?.images);
  const gradingOutput = getGradingOutputForImages(llmOutput, imageOutputs);
  if (
    !grading.rubricPrompt &&
    shouldPreferRemote &&
    !cliState.config?.redteam?.provider &&
    cliState.config?.redteam &&
    shouldUseRemoteGrading({ canUseCodexDefaultProvider: true })
  ) {
    try {
      return {
        ...(await doRemoteGrading({
          task: 'llm-rubric',
          rubric,
          output: gradingOutput,
          vars: vars || {},
          ...(imageOutputs.length ? { images: imageOutputs } : {}),
          ...getRemoteGradingContext(),
        })),
        assertion,
      };
    } catch (error) {
      return {
        ...graderFail(`Could not perform remote grading: ${error}`),
        assertion,
      };
    }
  }

  try {
    return await runJsonGradingPrompt({
      assertion,
      checkName: 'llm-rubric check',
      defaultPrompt: DEFAULT_GRADING_PROMPT,
      grading,
      label: 'llm-rubric',
      providerCallContext,
      throwOnError: options?.throwOnError,
      images: imageOutputs,
      vars: {
        ...(vars || {}),
        output: tryParse(gradingOutput),
        rubric,
      },
    });
  } catch (error) {
    if (options?.throwOnError) {
      throw new LlmRubricProviderError((error as Error).message || 'No output');
    }
    // Rethrow so the evaluator's "Assertion grading failed" path logs and
    // marks the row as errored. SyntaxError/TypeError/etc. from a misbehaving
    // grader represent real bugs and must not be silently suppressed —
    // `handleLlmRubric` lets the rejection propagate, so the evaluator
    // converts it to a row-level error rather than a passing inverse result.
    throw error;
  }
}

export async function matchesTrajectoryGoalSuccess(
  goal: string,
  trajectory: string,
  llmOutput: string,
  grading?: GradingConfig,
  vars?: Record<string, VarValue>,
  assertion?: Assertion,
  providerCallContext?: CallApiContextParams,
): Promise<GradingResult> {
  if (!grading) {
    throw new Error(
      'Cannot grade output without grading config. Specify --grader option or grading config.',
    );
  }

  return runJsonGradingPrompt({
    assertion,
    checkName: 'trajectory:goal-success check',
    defaultPrompt: TRAJECTORY_GOAL_SUCCESS_PROMPT,
    grading,
    label: 'trajectory:goal-success',
    providerCallContext,
    vars: {
      ...(vars || {}),
      goal,
      output: tryParse(llmOutput),
      trajectory,
    },
  });
}

export async function matchesPiScore(
  renderedValue: string,
  llmInput: string,
  llmOutput: string,
  assertion?: Assertion,
): Promise<GradingResult> {
  return {
    ...(await doRemoteScoringWithPi(
      {
        llm_input: llmInput,
        llm_output: llmOutput,
        scoring_spec: [
          {
            question: renderedValue,
          },
        ],
      },
      assertion?.threshold,
    )),
    assertion,
  };
}

export async function matchesFactuality(
  input: string,
  expected: string,
  output: string,
  grading?: GradingConfig,
  vars?: Record<string, VarValue>,
  providerCallContext?: CallApiContextParams,
): Promise<Omit<GradingResult, 'assertion'>> {
  if (!grading) {
    throw new Error(
      'Cannot grade output without grading config. Specify --grader option or grading config.',
    );
  }

  const parsedOutput = tryParse(output);
  const templateVars = { ...(vars || {}), input, ideal: expected, completion: parsedOutput };

  const rubricPrompt = await loadRubricPrompt(grading?.rubricPrompt, PROMPTFOO_FACTUALITY_PROMPT);
  const prompt = await renderLlmRubricPrompt(rubricPrompt, templateVars);

  const finalProvider = await getAndCheckProvider(
    'text',
    grading.provider,
    (await getDefaultProviders()).gradingProvider,
    'factuality check',
  );

  const resp = await callProviderWithContext(
    finalProvider,
    prompt,
    'factuality',
    templateVars,
    providerCallContext,
  );
  if (resp.error || !resp.output) {
    return fail(resp.error || 'No output', resp.tokenUsage);
  }

  invariant(typeof resp.output === 'string', 'factuality produced malformed response');

  try {
    const parsedJson = parseFactualityJsonResponse(resp.output);
    if (parsedJson) {
      return buildFactualityResult(parsedJson.option, parsedJson.reason, grading, resp);
    }
  } catch (err) {
    return fail((err as Error).message, resp.tokenUsage);
  }

  // Fallback to old pattern matching format
  logger.info('Falling back to legacy pattern matching for factuality check');
  try {
    const parsedLegacy = parseLegacyFactualityResponse(resp.output);
    return buildFactualityResult(parsedLegacy.option, parsedLegacy.reason, grading, resp);
  } catch (err) {
    return fail((err as Error).message, resp.tokenUsage);
  }
}

export async function matchesClosedQa(
  input: string,
  expected: string,
  output: string,
  grading?: GradingConfig,
  vars?: Record<string, VarValue>,
  providerCallContext?: CallApiContextParams,
): Promise<Omit<GradingResult, 'assertion'>> {
  if (!grading) {
    throw new Error(
      'Cannot grade output without grading config. Specify --grader option or grading config.',
    );
  }

  const parsedOutput = tryParse(output);
  const templateVars = { ...(vars || {}), input, criteria: expected, completion: parsedOutput };

  const rubricPrompt = await loadRubricPrompt(grading?.rubricPrompt, OPENAI_CLOSED_QA_PROMPT);
  const prompt = await renderLlmRubricPrompt(rubricPrompt, templateVars);

  const finalProvider = await getAndCheckProvider(
    'text',
    grading.provider,
    (await getDefaultProviders()).gradingProvider,
    'model-graded-closedqa check',
  );
  const resp = await callProviderWithContext(
    finalProvider,
    prompt,
    'model-graded-closedqa',
    templateVars,
    providerCallContext,
  );
  if (resp.error || !resp.output) {
    return fail(resp.error || 'No output', resp.tokenUsage);
  }

  invariant(typeof resp.output === 'string', 'model-graded-closedqa produced malformed response');
  try {
    const pass = resp.output.trimEnd().endsWith('Y');
    let reason;
    if (pass) {
      reason = `The submission meets the criterion:\n${resp.output}`;
    } else if (resp.output.trimEnd().endsWith('N')) {
      reason = `The submission does not meet the criterion:\n${resp.output}`;
    } else {
      reason = `Model grader produced a malformed response:\n${resp.output}`;
    }
    return {
      pass,
      score: pass ? 1 : 0,
      reason,
      tokensUsed: normalizeMatcherTokenUsage(resp.tokenUsage),
    };
  } catch (err) {
    return fail(`Error parsing output: ${(err as Error).message}`, resp.tokenUsage);
  }
}

/**
 * Type guard: is this a grader transport/parse failure from a `matches*`
 * helper that uses `metadata.graderError` to mark hard failures? Callers that
 * support inverse semantics (e.g. `not-g-eval`) must propagate such results
 * verbatim without flipping pass/score — a grader error is not evidence that
 * the criterion was or was not met.
 */
export const isGraderFailure = (resp: Omit<GradingResult, 'assertion'>): boolean =>
  resp.metadata?.graderError === true;

export async function matchesGEval(
  criteria: string,
  input: string,
  output: string,
  threshold: number,
  grading?: GradingConfig,
  providerCallContext?: CallApiContextParams,
): Promise<Omit<GradingResult, 'assertion'>> {
  if (!input) {
    throw Error('No source text to estimate reply');
  }

  const maxScore = 10;
  const textProvider = await getAndCheckProvider(
    'text',
    grading?.provider,
    (await getDefaultProviders()).gradingProvider,
    'reply geval check',
  );

  const tokensUsed = normalizeMatcherTokenUsage(undefined);

  const failWithTokens = (reason: string) => graderFail(reason, tokensUsed);
  const failNoOutput = (phase: 'step-generation' | 'evaluation') =>
    failWithTokens(`G-Eval ${phase} call to ${textProvider.id()} returned no output`);

  // Step 1: Get evaluation steps using renderLlmRubricPrompt
  const stepsRubricPrompt =
    typeof grading?.rubricPrompt === 'object' && !Array.isArray(grading?.rubricPrompt)
      ? grading?.rubricPrompt?.['steps']
      : undefined;
  const stepsPrompt = await loadRubricPrompt(stepsRubricPrompt, GEVAL_PROMPT_STEPS);
  const promptSteps = await renderLlmRubricPrompt(stepsPrompt, { criteria });

  const respSteps = await callProviderWithContext(
    textProvider,
    promptSteps,
    'g-eval-steps',
    {
      criteria,
    },
    providerCallContext,
  );
  accumulateTokenUsage(tokensUsed, respSteps.tokenUsage);
  if (respSteps.error) {
    return failWithTokens(respSteps.error);
  }
  if (!respSteps.output) {
    return failNoOutput('step-generation');
  }
  if (typeof respSteps.output !== 'string') {
    return failWithTokens('LLM-proposed evaluation steps response is not a string');
  }
  let steps;

  try {
    // NOTE: use regexp for reliable, because sometimes LLM wraps response to markdown format ```json...```
    const stepsMatch = respSteps.output.match(/\{"steps".+\}/g);
    if (!stepsMatch) {
      return failWithTokens(
        `LLM-proposed evaluation steps are not in JSON format: ${respSteps.output}`,
      );
    }
    steps = JSON.parse(stepsMatch[0]).steps;

    if (!Array.isArray(steps)) {
      return failWithTokens(
        `G-Eval steps response has invalid or missing steps: ${JSON.stringify(steps)}`,
      );
    }
    if (steps.length === 0) {
      return failWithTokens('LLM does not propose any evaluation step');
    }
    if (!steps.every((step) => typeof step === 'string' && step.trim() !== '')) {
      return failWithTokens(
        `G-Eval steps response contains invalid steps: ${JSON.stringify(steps)}`,
      );
    }
  } catch (err) {
    return failWithTokens(
      `LLM-proposed evaluation steps are not in JSON format: ${(err as Error).message}\n\n${respSteps.output}`,
    );
  }

  // Step 2: Use steps to evaluate using renderLlmRubricPrompt
  const evalRubricPrompt =
    typeof grading?.rubricPrompt === 'object' && !Array.isArray(grading?.rubricPrompt)
      ? grading?.rubricPrompt?.['evaluate']
      : undefined;
  const evalPrompt = await loadRubricPrompt(evalRubricPrompt, GEVAL_PROMPT_EVALUATE);
  const evalVars = {
    criteria,
    steps: steps.join('\n- '),
    maxScore: maxScore.toString(),
    input: tryParse(input),
    output: tryParse(output),
  };
  const promptText = await renderLlmRubricPrompt(evalPrompt, evalVars);

  const resp = await callProviderWithContext(
    textProvider,
    promptText,
    'g-eval',
    evalVars,
    providerCallContext,
  );
  accumulateTokenUsage(tokensUsed, resp.tokenUsage);
  if (resp.error) {
    return failWithTokens(resp.error);
  }
  if (!resp.output) {
    return failNoOutput('evaluation');
  }
  if (typeof resp.output !== 'string') {
    return failWithTokens('LLM-proposed evaluation result response is not a string');
  }
  let result;

  try {
    const resultMatch = resp.output.match(/\{.+\}/g);
    if (!resultMatch) {
      return failWithTokens(`LLM-proposed evaluation result is not in JSON format: ${resp.output}`);
    }
    result = JSON.parse(resultMatch[0]);
  } catch (err) {
    return failWithTokens(
      `LLM-proposed evaluation result is not in JSON format: ${(err as Error).message}\n\n${resp.output}`,
    );
  }

  const rawScore =
    typeof result.score === 'number'
      ? result.score
      : typeof result.score === 'string' && result.score.trim() !== ''
        ? Number(result.score)
        : Number.NaN;
  if (!Number.isFinite(rawScore)) {
    return failWithTokens(
      `G-Eval result has invalid or missing score: ${JSON.stringify(result.score)}`,
    );
  }
  if (rawScore < 0 || rawScore > maxScore) {
    return failWithTokens(
      `G-Eval result score ${rawScore} is outside the expected 0-${maxScore} range`,
    );
  }
  if (typeof result.reason !== 'string' || result.reason.trim() === '') {
    return failWithTokens(
      `G-Eval result has invalid or missing reason: ${JSON.stringify(result.reason)}`,
    );
  }

  return {
    pass: rawScore / maxScore >= threshold,
    score: rawScore / maxScore,
    reason: result.reason,
    tokensUsed,
  };
}
