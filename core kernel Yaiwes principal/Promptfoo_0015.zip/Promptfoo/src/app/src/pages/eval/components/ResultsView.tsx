import React from 'react';

import { Alert, AlertContent, AlertDescription, AlertTitle } from '@app/components/ui/alert';
import { Badge } from '@app/components/ui/badge';
import { Button } from '@app/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@app/components/ui/dialog';
import { DropdownMenuItem } from '@app/components/ui/dropdown-menu';
import { SearchInput } from '@app/components/ui/search-input';
import { Separator } from '@app/components/ui/separator';
import { Spinner } from '@app/components/ui/spinner';
import { Tooltip, TooltipContent, TooltipTrigger } from '@app/components/ui/tooltip';
import { IS_RUNNING_LOCALLY } from '@app/constants';
import { EVAL_ROUTES, ROUTES } from '@app/constants/routes';
import { useToast } from '@app/hooks/useToast';
import { useStore as useMainStore } from '@app/stores/evalConfig';
import { callApi } from '@app/utils/api';
import { displayNameOverrides } from '@promptfoo/redteam/constants/metadata';
import { formatPolicyIdentifierAsMetric } from '@promptfoo/redteam/plugins/policy/utils';
import invariant from '@promptfoo/util/invariant';
import { BarChart, Copy, Edit, Eye, Play, Settings, Share, Trash2, X } from 'lucide-react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useDebouncedCallback } from 'use-debounce';
import { ColumnSelector } from './ColumnSelector';
import CompareEvalMenuItem from './CompareEvalMenuItem';
import ConfigModal from './ConfigModal';
import { ConfirmEvalNameDialog } from './ConfirmEvalNameDialog';
import { DownloadDialog, DownloadMenuItem } from './DownloadMenu';
import EvalHeader from './EvalHeader';
import EvalSelectorDialog from './EvalSelectorDialog';
import { FilterChips } from './FilterChips';
import { useFilterMode } from './FilterModeProvider';
import { FilterModeSelector } from './FilterModeSelector';
import { HiddenColumnChips } from './HiddenColumnChips';
import ResultsCharts from './ResultsCharts';
import FiltersForm from './ResultsFilters/FiltersForm';
import ResultsTable from './ResultsTable';
import ShareModal from './ShareModal';
import { useResultsViewSettingsStore, useTableStore } from './store';
import SettingsModal from './TableSettings/TableSettingsModal';
import { buildEvalUrlWithSearchParams, hashVarSchema, setEvalDetailsHash } from './utils';
import type { EvalResultsFilterMode, ResultLightweightWithLabel } from '@promptfoo/types';
import type { CopyEvalResponse } from '@promptfoo/types/api/eval';
import type { VisibilityState } from '@tanstack/table-core';

import type { ActiveView } from './EvalHeader';
import type { ResultsFilter } from './store';

const Report = React.lazy(() => import('@app/pages/redteam/report/components/Report'));

const MAX_SEARCH_BADGE_LENGTH = 5;
const MAX_FILTER_VALUE_LENGTH = 50;
const MAX_PROMPT_LABEL_LENGTH = 60;

// Default to showing charts only on sufficiently tall viewports to avoid crowding above-the-fold content.
const MIN_VIEWPORT_HEIGHT_FOR_CHARTS = 1100;

interface ResultsViewProps {
  recentEvals: ResultLightweightWithLabel[];
  onRecentEvalSelected: (file: string) => void;
  defaultEvalId?: string;
}

interface ResultsChartsSectionProps {
  canRenderResultsCharts: boolean;
  isRedteamEval: boolean;
  resultsChartsScores: number[];
  resultsChartsUnavailableReasons: string[];
  children: (toggleButton: React.ReactNode | null) => React.ReactNode;
}

interface AppliedFilterBadgesProps {
  filters: ResultsFilter[];
  isRedteamEval: boolean;
  onRemoveFilter: (id: string) => void;
  policyIdToNameMap?: Record<string, string | undefined>;
}

function getAppliedFilterLabel(
  filter: ResultsFilter,
  policyIdToNameMap?: Record<string, string | undefined>,
): string | null {
  if (filter.type === 'metadata' && filter.operator === 'exists') {
    return filter.field ? `Metadata: ${filter.field}` : null;
  }

  if (filter.type === 'metric' && filter.operator === 'is_defined') {
    return filter.field ? `Metric: ${filter.field}` : null;
  }

  if (filter.type === 'metadata' || filter.type === 'metric') {
    if (!filter.value || !filter.field) {
      return null;
    }
  } else if (!filter.value) {
    return null;
  }

  const filterValue = filter.value ?? '';
  const truncatedValue =
    filterValue.length > MAX_FILTER_VALUE_LENGTH
      ? `${filterValue.slice(0, MAX_FILTER_VALUE_LENGTH)}...`
      : filterValue;

  if (filter.type === 'metric') {
    const operatorSymbols: Record<string, string> = {
      is_defined: 'is defined',
      eq: '==',
      neq: '!=',
      gt: '>',
      gte: '≥',
      lt: '<',
      lte: '≤',
    };
    const operatorDisplay = operatorSymbols[filter.operator] || filter.operator;
    return `${filter.field} ${operatorDisplay} ${truncatedValue}`;
  }

  if (filter.type === 'plugin') {
    const displayName =
      displayNameOverrides[filter.value as keyof typeof displayNameOverrides] || filter.value;
    return filter.operator === 'not_equals' ? `Plugin != ${displayName}` : `Plugin: ${displayName}`;
  }

  if (filter.type === 'strategy') {
    const displayName =
      displayNameOverrides[filter.value as keyof typeof displayNameOverrides] || filter.value;
    return `Strategy: ${displayName}`;
  }

  if (filter.type === 'severity') {
    return `Severity: ${filter.value.charAt(0).toUpperCase() + filter.value.slice(1)}`;
  }

  if (filter.type === 'policy') {
    return formatPolicyIdentifierAsMetric(policyIdToNameMap?.[filter.value] ?? filter.value);
  }

  return `${filter.field} ${filter.operator.replace('_', ' ')} "${truncatedValue}"`;
}

function AppliedFilterBadges({
  filters,
  isRedteamEval,
  onRemoveFilter,
  policyIdToNameMap,
}: AppliedFilterBadgesProps) {
  return filters.map((filter) => {
    if (isRedteamEval && filter.type === 'metric' && filter.operator === 'is_defined') {
      return null;
    }

    const label = getAppliedFilterLabel(filter, policyIdToNameMap);
    if (!label) {
      return null;
    }

    return (
      <Badge key={filter.id} variant="secondary" className="text-xs h-5 gap-1" title={filter.value}>
        {label}
        <button
          type="button"
          onClick={() => onRemoveFilter(filter.id)}
          className="ml-1 cursor-pointer hover:bg-muted rounded-full"
        >
          <X className="size-3" />
        </button>
      </Badge>
    );
  });
}

export function ResultsChartsSection({
  canRenderResultsCharts,
  isRedteamEval,
  resultsChartsScores,
  resultsChartsUnavailableReasons,
  children,
}: ResultsChartsSectionProps) {
  const [renderResultsCharts, setRenderResultsCharts] = React.useState(
    !isRedteamEval &&
      window.innerHeight >= MIN_VIEWPORT_HEIGHT_FOR_CHARTS &&
      canRenderResultsCharts,
  );

  if (isRedteamEval) {
    return <>{children(null)}</>;
  }

  const toggleButton = (
    <Button variant="ghost" size="sm" onClick={() => setRenderResultsCharts((prev) => !prev)}>
      <BarChart className="size-4 mr-2" />
      {renderResultsCharts ? 'Hide Charts' : 'Show Charts'}
    </Button>
  );

  return (
    <>
      {children(toggleButton)}
      <div
        aria-hidden={!renderResultsCharts}
        className="overflow-hidden transition-all duration-200 ease-out motion-reduce:transition-none"
        style={{
          maxHeight: renderResultsCharts ? '1200px' : '0px',
          opacity: renderResultsCharts ? 1 : 0,
          transform: renderResultsCharts ? 'translateY(0)' : 'translateY(-4px)',
          pointerEvents: renderResultsCharts ? 'auto' : 'none',
        }}
      >
        {renderResultsCharts &&
          (canRenderResultsCharts ? (
            <ResultsCharts scores={resultsChartsScores} />
          ) : (
            <Alert variant="info" className="mt-4 items-start">
              <BarChart className="size-4 mt-0.5" />
              <AlertContent>
                <AlertTitle>Charts are unavailable for this evaluation</AlertTitle>
                <AlertDescription className="space-y-3">
                  <p>
                    We can show charts when the results include comparable prompts and chartable
                    scores.
                  </p>
                  <ul className="list-disc pl-5 space-y-1">
                    {resultsChartsUnavailableReasons.map((reason) => (
                      <li key={reason}>{reason}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </AlertContent>
            </Alert>
          ))}
      </div>
    </>
  );
}

export default function ResultsView({
  recentEvals,
  onRecentEvalSelected,
  defaultEvalId,
}: ResultsViewProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const {
    table,

    config,
    setConfig,
    evalId,
    totalResultsCount,
    highlightedResultsCount,
    userRatedResultsCount,
    filters,
    removeFilter,
  } = useTableStore();

  const { filterMode, setFilterMode } = useFilterMode();

  const {
    setInComparisonMode,
    columnStates,
    setColumnState,
    maxTextLength,
    wordBreak,
    showInferenceDetails,
    comparisonEvalIds,
    setComparisonEvalIds,
    hiddenVarNamesBySchema,
    setHiddenVarNamesForSchema,
  } = useResultsViewSettingsStore();

  const { updateConfig } = useMainStore();

  const { showToast } = useToast();
  const initialSearchText = searchParams.get('search') || '';
  const [searchInputValue, setSearchInputValue] = React.useState(initialSearchText); // local, for responsive input
  const [debouncedSearchText, setDebouncedSearchText] = React.useState(initialSearchText); // debounced, for table/URL/pill

  // Debounced update for URL, table, and pill. Search changes can change the
  // visible result set, so drop any existing details deep-link while replacing the URL.
  const debouncedUpdate = useDebouncedCallback((text: string) => {
    setDebouncedSearchText(text);
    setEvalDetailsHash('');
    navigate(
      buildEvalUrlWithSearchParams(
        { pathname: location.pathname, search: location.search, hash: '' },
        (params) => {
          params.delete('rowId');
          if (text) {
            params.set('search', text);
          } else {
            params.delete('search');
          }
        },
      ),
      { replace: true },
    );
  }, 300);

  const handleClearSearch = () => {
    setSearchInputValue('');
    debouncedUpdate.cancel();
    setDebouncedSearchText('');
    setEvalDetailsHash('');
    navigate(
      buildEvalUrlWithSearchParams(
        { pathname: location.pathname, search: location.search, hash: '' },
        (params) => {
          params.delete('rowId');
          params.delete('search');
        },
      ),
      { replace: true },
    );
  };

  const [failureFilter, setFailureFilter] = React.useState<{ [key: string]: boolean }>({});
  // biome-ignore lint/correctness/useExhaustiveDependencies: intentional
  const handleFailureFilterToggle = React.useCallback(
    (columnId: string, checked: boolean) => {
      setFailureFilter((prevFailureFilter) => ({ ...prevFailureFilter, [columnId]: checked }));
    },
    [setFailureFilter],
  );

  const viewParam = searchParams.get('view');
  const activeView: ActiveView = viewParam === 'report' ? 'report' : 'results';
  const setActiveView = React.useCallback(
    (view: ActiveView) => {
      setEvalDetailsHash('');
      navigate(
        buildEvalUrlWithSearchParams(
          { pathname: location.pathname, search: location.search, hash: '' },
          (params) => {
            params.delete('rowId');
            if (view === 'results') {
              params.delete('view');
            } else {
              params.set('view', view);
            }
          },
        ),
        { replace: true },
      );
    },
    [location.pathname, location.search, navigate],
  );
  const [reportActions, setReportActions] = React.useState<React.ReactNode>(null);

  invariant(table, 'Table data must be loaded before rendering ResultsView');
  const { head } = table;

  const handleFilterModeChange = (mode: EvalResultsFilterMode) => {
    setFilterMode(mode);

    const newFailureFilter: { [key: string]: boolean } = {};
    head.prompts.forEach((_, idx) => {
      const columnId = `Prompt ${idx + 1}`;
      newFailureFilter[columnId] = mode === 'failures';
    });
    setFailureFilter(newFailureFilter);
  };

  const [shareModalOpen, setShareModalOpen] = React.useState(false);
  const [shareLoading, setShareLoading] = React.useState(false);

  // State for compare eval dialog
  const [compareDialogOpen, setCompareDialogOpen] = React.useState(false);

  // State for download dialog
  const [downloadDialogOpen, setDownloadDialogOpen] = React.useState(false);

  const currentEvalId = evalId || defaultEvalId || 'default';
  const validEvalId = evalId || defaultEvalId;
  const currentDatasetId = recentEvals.find(
    (recentEval) => recentEval.evalId === currentEvalId,
  )?.datasetId;

  const handleShareButtonClick = async () => {
    if (IS_RUNNING_LOCALLY) {
      setShareLoading(true);
      setShareModalOpen(true);
    } else {
      // For non-local instances, just show the modal
      setShareModalOpen(true);
    }
  };

  const handleShare = async (id: string): Promise<string> => {
    try {
      if (!IS_RUNNING_LOCALLY) {
        // For non-local instances, include base path in the URL
        const basePath = import.meta.env.VITE_PUBLIC_BASENAME || '';
        return `${window.location.host}${basePath}${EVAL_ROUTES.DETAIL(id)}`;
      }

      const response = await callApi('/results/share', {
        method: 'POST',
        body: JSON.stringify({ id }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to generate share URL');
      }
      const { url } = await response.json();
      return url;
    } catch (error) {
      console.error('Failed to generate share URL:', error);
      throw error;
    } finally {
      setShareLoading(false);
    }
  };

  const handleComparisonEvalSelected = async (compareEvalId: string) => {
    // Prevent self-comparison
    if (compareEvalId === currentEvalId) {
      setCompareDialogOpen(false);
      return;
    }
    setInComparisonMode(true);
    setComparisonEvalIds([...comparisonEvalIds, compareEvalId]);
    setCompareDialogOpen(false);
  };

  const hasAnyDescriptions = React.useMemo(
    () => table.body?.some((row) => row.description),
    [table.body],
  );

  const promptOptions = head.prompts.map((prompt, idx) => {
    const label = prompt.label || prompt.display || prompt.raw;
    const provider = prompt.provider || 'unknown';
    const truncatedLabel =
      label &&
      `"${label.slice(0, MAX_PROMPT_LABEL_LENGTH)}${
        label.length > MAX_PROMPT_LABEL_LENGTH ? '...' : ''
      }"`;
    const displayLabel = [truncatedLabel, provider && `[${provider}]`].filter(Boolean).join(' ');

    return {
      value: `Prompt ${idx + 1}`,
      label: displayLabel,
      description: label,
      group: 'Outputs',
    };
  });

  const columnData = React.useMemo(() => {
    return [
      ...(hasAnyDescriptions ? [{ value: 'description', label: 'Description' }] : []),
      ...head.vars.map((_, idx) => ({
        value: `Variable ${idx + 1}`,
        label: `Var ${idx + 1}: ${
          head.vars[idx].length > 100 ? head.vars[idx].slice(0, 97) + '...' : head.vars[idx]
        }`,
        group: 'Variables',
      })),
      ...promptOptions,
    ];
  }, [head.vars, promptOptions, hasAnyDescriptions]);

  const [configModalOpen, setConfigModalOpen] = React.useState(false);
  const [viewSettingsModalOpen, setViewSettingsModalOpen] = React.useState(false);
  const [editNameDialogOpen, setEditNameDialogOpen] = React.useState(false);
  const [copyDialogOpen, setCopyDialogOpen] = React.useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = React.useState(false);
  const [isDeleting, setIsDeleting] = React.useState(false);

  const allColumns = React.useMemo(
    () => [
      ...(hasAnyDescriptions ? ['description'] : []),
      ...head.vars.map((_, idx) => `Variable ${idx + 1}`),
      ...head.prompts.map((_, idx) => `Prompt ${idx + 1}`),
    ],
    [hasAnyDescriptions, head.vars, head.prompts],
  );

  const getVarNameFromColumnId = React.useCallback(
    (columnId: string): string | null => {
      const match = columnId.match(/^Variable (\d+)$/);
      if (match) {
        const varIndex = parseInt(match[1], 10) - 1;
        return head.vars[varIndex] ?? null;
      }
      return null;
    },
    [head.vars],
  );

  const schemaHash = React.useMemo(() => hashVarSchema(head.vars), [head.vars]);

  const hiddenVarNames = React.useMemo(
    () => hiddenVarNamesBySchema[schemaHash] ?? [],
    [hiddenVarNamesBySchema, schemaHash],
  );

  const currentColumnState = React.useMemo(() => {
    const savedState = columnStates[currentEvalId];
    const columnVisibility: VisibilityState = {};
    const selectedColumns: string[] = [];

    allColumns.forEach((col) => {
      const varName = getVarNameFromColumnId(col);
      if (varName === null) {
        // Non-variable columns (description, prompts): use per-eval state, default to visible
        const isVisible = savedState?.columnVisibility[col] ?? true;
        columnVisibility[col] = isVisible;
        if (isVisible) {
          selectedColumns.push(col);
        }
      } else {
        const isHidden = hiddenVarNames.includes(varName);
        columnVisibility[col] = !isHidden;
        if (!isHidden) {
          selectedColumns.push(col);
        }
      }
    });

    return { selectedColumns, columnVisibility };
  }, [allColumns, getVarNameFromColumnId, hiddenVarNames, columnStates, currentEvalId]);

  const visiblePromptCount = React.useMemo(
    () =>
      head.prompts.filter(
        (_, idx) => currentColumnState.columnVisibility[`Prompt ${idx + 1}`] !== false,
      ).length,
    [head.prompts, currentColumnState.columnVisibility],
  );

  const updateColumnVisibility = React.useCallback(
    (columns: string[]) => {
      const newHiddenVarNames: string[] = [];

      allColumns.forEach((col) => {
        const varName = getVarNameFromColumnId(col);
        if (varName !== null) {
          const isVisible = columns.includes(col);
          if (!isVisible) {
            newHiddenVarNames.push(varName);
          }
        }
      });

      setHiddenVarNamesForSchema(schemaHash, newHiddenVarNames);

      const newColumnVisibility: VisibilityState = {};
      allColumns.forEach((col) => {
        newColumnVisibility[col] = columns.includes(col);
      });
      setColumnState(currentEvalId, {
        selectedColumns: columns,
        columnVisibility: newColumnVisibility,
      });
    },
    [
      allColumns,
      getVarNameFromColumnId,
      schemaHash,
      setHiddenVarNamesForSchema,
      setColumnState,
      currentEvalId,
    ],
  );

  const handleChange = React.useCallback(
    (newSelectedColumns: string[]) => {
      updateColumnVisibility(newSelectedColumns);
    },
    [updateColumnVisibility],
  );

  const handleSaveEvalName = React.useCallback(
    async (newName: string) => {
      try {
        invariant(config, 'Config must be loaded before updating its description');
        const newConfig = { ...config, description: newName };

        const response = await callApi(`/eval/${evalId}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ config: newConfig }),
        });

        if (!response.ok) {
          throw new Error('Failed to update eval name');
        }

        setConfig(newConfig);
      } catch (error) {
        console.error('Failed to update eval name:', error);
        showToast(
          `Failed to update eval name: ${error instanceof Error ? error.message : 'Unknown error'}`,
          'error',
        );
        throw error;
      }
    },
    [config, evalId, setConfig, showToast],
  );

  const handleCopyEval = React.useCallback(
    async (description: string) => {
      try {
        invariant(evalId, 'Eval ID must be set before copying');

        const response = await callApi(`/eval/${evalId}/copy`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ description }),
        });

        if (!response.ok) {
          throw new Error('Failed to copy evaluation');
        }

        const { id: newEvalId, distinctTestCount }: CopyEvalResponse = await response.json();

        // Open in new tab (Google Docs pattern)
        window.open(EVAL_ROUTES.DETAIL(newEvalId), '_blank');

        // Show success toast
        showToast(`Copied ${distinctTestCount.toLocaleString()} results successfully`, 'success');
      } catch (error) {
        console.error('Failed to copy evaluation:', error);
        showToast(
          `Failed to copy evaluation: ${error instanceof Error ? error.message : 'Unknown error'}`,
          'error',
        );
        throw error;
      }
    },
    [evalId, showToast],
  );

  /**
   * Determines the next eval to navigate to after deleting the current one
   * @returns The eval ID to navigate to, or null to go home
   */
  const getNextEvalAfterDelete = (): string | null => {
    if (!evalId || recentEvals.length === 0) {
      return null;
    }

    const currentIndex = recentEvals.findIndex((e) => e.evalId === evalId);

    // If current eval not in list or only one eval, go home
    if (currentIndex === -1 || recentEvals.length === 1) {
      return null;
    }

    // Try next eval first
    if (currentIndex < recentEvals.length - 1) {
      return recentEvals[currentIndex + 1].evalId;
    }

    // If this is the last eval, go to previous
    if (currentIndex > 0) {
      return recentEvals[currentIndex - 1].evalId;
    }

    return null;
  };

  const handleDeleteEvalClick = () => {
    if (!evalId) {
      showToast('Cannot delete: Eval ID not found', 'error');
      return;
    }

    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!evalId) {
      return;
    }

    setIsDeleting(true);

    try {
      const response = await callApi(`/eval/${evalId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to delete eval');
      }

      showToast('Eval deleted', 'success');

      // Navigate to next eval or home
      const nextEvalId = getNextEvalAfterDelete();
      if (nextEvalId) {
        onRecentEvalSelected(nextEvalId);
      } else {
        navigate('/', { replace: true });
      }
    } catch (error) {
      console.error('Failed to delete eval:', error);
      showToast(
        `Failed to delete eval: ${error instanceof Error ? error.message : 'Unknown error'}`,
        'error',
      );
    } finally {
      setIsDeleting(false);
      setDeleteDialogOpen(false);
    }
  };

  // Render the charts if a) they can be rendered, and b) the viewport, at mount-time, is tall enough.
  const resultsChartsScores = React.useMemo(() => {
    if (!table?.body) {
      return [];
    }
    return table.body
      .flatMap((row) => row.outputs.map((output) => output?.score))
      .filter((score) => typeof score === 'number' && !Number.isNaN(score));
  }, [table]);

  // Determine if charts should be rendered based on score variance
  const uniqueScores = React.useMemo(() => new Set(resultsChartsScores), [resultsChartsScores]);
  const hasVariedScores = uniqueScores.size > 1;
  // When all scores are identical, still show charts if the uniform score
  // is not a binary edge value (0 or 1). Graded assertions (like llm-rubric)
  // can produce meaningful uniform scores (e.g., 0.85) that users want to visualize.
  const hasMeaningfulUniformScore =
    uniqueScores.size === 1 && ![0, 1].includes([...uniqueScores][0]);
  const isRedteamEval = config?.redteam !== undefined;

  const resultsChartsUnavailableReasons = React.useMemo(() => {
    const reasons: string[] = [];

    if (!config) {
      reasons.push('This evaluation is still loading its chart configuration.');
    }

    if (table.head.prompts.length <= 1) {
      reasons.push('Charts require at least two prompts to compare side by side.');
    }

    if (resultsChartsScores.length === 0) {
      reasons.push('Charts require at least one valid numeric score.');
    } else if (!hasVariedScores && !hasMeaningfulUniformScore) {
      reasons.push(
        'All scores are the same binary edge value (0 or 1), so there is no meaningful distribution to visualize.',
      );
    }

    return reasons;
  }, [config, hasMeaningfulUniformScore, hasVariedScores, resultsChartsScores.length, table]);

  const canRenderResultsCharts = resultsChartsUnavailableReasons.length === 0;
  const appliedFilters = React.useMemo(() => Object.values(filters.values), [filters.values]);

  const [resultsTableZoom, setResultsTableZoom] = React.useState(1);

  const evalActionsMenuItems = (
    <>
      <DropdownMenuItem onClick={() => setEditNameDialogOpen(true)}>
        <Edit className="size-4 mr-2" />
        Edit name
      </DropdownMenuItem>
      <DropdownMenuItem
        disabled={!config}
        onClick={() => {
          if (!config) {
            return;
          }
          updateConfig(config);
          navigate(ROUTES.SETUP, { state: { sourceEvalId: evalId } });
        }}
      >
        <Play className="size-4 mr-2" />
        Edit and re-run
      </DropdownMenuItem>
      <CompareEvalMenuItem onClick={() => setCompareDialogOpen(true)} />
      <DropdownMenuItem onClick={() => setConfigModalOpen(true)}>
        <Eye className="size-4 mr-2" />
        View YAML
      </DropdownMenuItem>
      <DownloadMenuItem onClick={() => setDownloadDialogOpen(true)} />
      <DropdownMenuItem onClick={() => setCopyDialogOpen(true)}>
        <Copy className="size-4 mr-2" />
        Copy
      </DropdownMenuItem>
      <DropdownMenuItem onClick={handleShareButtonClick} disabled={shareLoading}>
        {shareLoading ? <Spinner className="size-4 mr-2" /> : <Share className="size-4 mr-2" />}
        Share
      </DropdownMenuItem>
      <DropdownMenuItem onClick={handleDeleteEvalClick} className="text-destructive">
        <Trash2 className="size-4 mr-2" />
        Delete
      </DropdownMenuItem>
    </>
  );

  return (
    <>
      <div
        className="flex flex-col bg-zinc-50 dark:bg-zinc-950 print:bg-white"
        style={{
          isolation: 'isolate',
          minHeight: 'calc(100vh - var(--nav-height) - var(--update-banner-height, 0px))',
        }}
      >
        <EvalHeader
          recentEvals={recentEvals}
          onRecentEvalSelected={onRecentEvalSelected}
          defaultEvalId={defaultEvalId}
          activeView={activeView}
          onActiveViewChange={setActiveView}
          actions={
            activeView === 'report' ? reportActions : config ? evalActionsMenuItems : undefined
          }
          contentClassName={activeView === 'report' ? 'max-w-7xl mx-auto w-full' : undefined}
        >
          {activeView === 'results' && (
            <ResultsChartsSection
              key={`${currentEvalId}:${isRedteamEval ? 'redteam' : canRenderResultsCharts ? 'eligible' : 'ineligible'}`}
              canRenderResultsCharts={canRenderResultsCharts}
              isRedteamEval={isRedteamEval}
              resultsChartsScores={resultsChartsScores}
              resultsChartsUnavailableReasons={resultsChartsUnavailableReasons}
            >
              {(chartsToggleButton) => (
                <div className="flex flex-col gap-3 mt-4 pt-4 border-t border-border/50">
                  <div className="flex flex-wrap gap-2 items-center">
                    <SearchInput
                      value={searchInputValue}
                      onChange={(value) => {
                        setSearchInputValue(value);
                        debouncedUpdate(value);
                      }}
                      onClear={handleClearSearch}
                      containerClassName="w-[200px]"
                      className="h-8 text-xs"
                    />
                    <FiltersForm />
                    <div className="flex-1" />
                    <ColumnSelector
                      columnData={columnData}
                      selectedColumns={currentColumnState.selectedColumns}
                      onChange={handleChange}
                    />
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setViewSettingsModalOpen(true)}
                        >
                          <Settings className="size-4 mr-2" />
                          Table Settings
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>Edit table view settings</TooltipContent>
                    </Tooltip>
                    {chartsToggleButton}
                  </div>
                  <div className="flex flex-wrap gap-2 items-center">
                    <span className="text-xs font-medium text-muted-foreground">Display:</span>
                    <FilterModeSelector
                      filterMode={filterMode}
                      onChange={handleFilterModeChange}
                      showDifferentOption={visiblePromptCount > 1}
                    />
                    {config?.redteam !== undefined && (
                      <>
                        <Separator orientation="vertical" className="h-5 mx-1" />
                        <FilterChips />
                      </>
                    )}
                    {debouncedSearchText && (
                      <Badge variant="secondary" className="text-xs h-5 gap-1">
                        Search:{' '}
                        {debouncedSearchText.length > MAX_SEARCH_BADGE_LENGTH
                          ? debouncedSearchText.substring(0, MAX_SEARCH_BADGE_LENGTH) + '...'
                          : debouncedSearchText}
                        <button
                          type="button"
                          onClick={handleClearSearch}
                          className="ml-1 cursor-pointer hover:bg-muted rounded-full"
                        >
                          <X className="size-3" />
                        </button>
                      </Badge>
                    )}
                    {filterMode !== 'all' && (
                      <Badge variant="secondary" className="text-xs h-5 gap-1">
                        Filter: {filterMode}
                        <button
                          type="button"
                          onClick={() => setFilterMode('all')}
                          className="ml-1 cursor-pointer hover:bg-muted rounded-full"
                        >
                          <X className="size-3" />
                        </button>
                      </Badge>
                    )}
                    {filters.appliedCount > 0 && (
                      <AppliedFilterBadges
                        filters={appliedFilters}
                        isRedteamEval={isRedteamEval}
                        onRemoveFilter={removeFilter}
                        policyIdToNameMap={filters.policyIdToNameMap}
                      />
                    )}
                    {highlightedResultsCount > 0 && (
                      <Badge className="bg-primary/10 text-primary border border-primary/20 font-medium">
                        {highlightedResultsCount} highlighted
                      </Badge>
                    )}
                    {userRatedResultsCount > 0 && (
                      <Tooltip>
                        <TooltipTrigger>
                          <Badge
                            className="bg-purple-50 text-purple-700 border border-purple-200 font-medium cursor-pointer hover:bg-purple-100 dark:bg-purple-950/30 dark:text-purple-300 dark:border-purple-800 dark:hover:bg-purple-950/50"
                            onClick={() => setFilterMode('user-rated')}
                          >
                            {userRatedResultsCount} user-rated
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          {userRatedResultsCount} output{userRatedResultsCount === 1 ? '' : 's'}{' '}
                          with user ratings. Click to filter.
                        </TooltipContent>
                      </Tooltip>
                    )}
                  </div>
                </div>
              )}
            </ResultsChartsSection>
          )}
          {currentColumnState.selectedColumns.length < columnData.length && (
            <div className="flex flex-wrap gap-2 items-center mt-2">
              <HiddenColumnChips
                columnData={columnData}
                selectedColumns={currentColumnState.selectedColumns}
                onChange={handleChange}
              />
            </div>
          )}
        </EvalHeader>
        {activeView === 'results' && (
          <div className="px-4 flex flex-1 min-h-0 flex-col">
            <ResultsTable
              key={currentEvalId}
              maxTextLength={maxTextLength}
              columnVisibility={currentColumnState.columnVisibility}
              wordBreak={wordBreak}
              showStats={showInferenceDetails}
              filterMode={filterMode}
              failureFilter={failureFilter}
              debouncedSearchText={debouncedSearchText}
              onFailureFilterToggle={handleFailureFilterToggle}
              zoom={resultsTableZoom}
            />
          </div>
        )}
        {activeView === 'report' && validEvalId && (
          <React.Suspense
            fallback={
              <div className="flex flex-col gap-3 justify-center items-center h-36">
                <Spinner className="size-5" />
                <span className="text-sm text-muted-foreground">Loading report...</span>
              </div>
            }
          >
            <Report evalId={validEvalId} embedded onActionsReady={setReportActions} />
          </React.Suspense>
        )}
      </div>
      <ConfigModal open={configModalOpen} onClose={() => setConfigModalOpen(false)} />
      <ShareModal
        open={shareModalOpen}
        onClose={() => setShareModalOpen(false)}
        evalId={currentEvalId}
        onShare={handleShare}
      />
      <EvalSelectorDialog
        open={compareDialogOpen}
        onClose={() => setCompareDialogOpen(false)}
        onEvalSelected={handleComparisonEvalSelected}
        description="Only evals with the same dataset can be compared."
        focusedEvalId={currentEvalId}
        filterByDatasetId
        focusedDatasetId={currentDatasetId}
      />
      <DownloadDialog open={downloadDialogOpen} onClose={() => setDownloadDialogOpen(false)} />
      <SettingsModal
        open={viewSettingsModalOpen}
        onClose={() => setViewSettingsModalOpen(false)}
        resultsTableZoom={resultsTableZoom}
        onResultsTableZoomChange={setResultsTableZoom}
      />
      <ConfirmEvalNameDialog
        open={editNameDialogOpen}
        onClose={() => setEditNameDialogOpen(false)}
        title="Edit Eval Name"
        label="Description"
        currentName={config?.description || ''}
        actionButtonText="Save"
        onConfirm={handleSaveEvalName}
      />
      <ConfirmEvalNameDialog
        open={copyDialogOpen}
        onClose={() => setCopyDialogOpen(false)}
        title="Copy Evaluation"
        label="Description"
        currentName={`${config?.description || 'Evaluation'} (Copy)`}
        actionButtonText="Create Copy"
        onConfirm={handleCopyEval}
        showSizeWarning={totalResultsCount > 10000}
        itemCount={totalResultsCount}
        itemLabel="results"
      />

      {/* Delete confirmation dialog */}
      <Dialog
        open={deleteDialogOpen}
        onOpenChange={(open) => !isDeleting && setDeleteDialogOpen(open)}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="size-5 text-destructive" />
              Delete eval?
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Alert variant="warning">
              <AlertContent>
                <AlertDescription>This action cannot be undone.</AlertDescription>
              </AlertContent>
            </Alert>
            <p className="text-sm text-muted-foreground">You are about to permanently delete:</p>
            <div className="mt-2 p-3 bg-muted/50 rounded-md border border-border">
              <p className="font-medium">{config?.description || evalId || 'Unnamed eval'}</p>
              <div className="flex gap-2 mt-1 text-sm text-muted-foreground">
                <span>
                  {totalResultsCount.toLocaleString()} result{totalResultsCount === 1 ? '' : 's'}
                </span>
                <span>•</span>
                <span>
                  {head.prompts.length} prompt{head.prompts.length === 1 ? '' : 's'}
                </span>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleConfirmDelete} disabled={isDeleting}>
              {isDeleting ? (
                <>
                  <Spinner className="size-4 mr-2" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="size-4 mr-2" />
                  Delete
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
