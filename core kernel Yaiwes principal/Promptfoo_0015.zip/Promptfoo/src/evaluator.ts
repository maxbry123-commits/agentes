import readline from 'readline';
import { isDeepStrictEqual } from 'util';

import async from 'async';
import chalk from 'chalk';
import cliProgress from 'cli-progress';
import { globSync } from 'glob';
import { LRUCache } from 'lru-cache';
import {
  getAssertionBaseType,
  hasTraceAwareAssertions,
  MODEL_GRADED_ASSERTION_TYPES,
  runAssertions,
  runCompareAssertion,
} from './assertions/index';
import { extractAndStoreBinaryData } from './blobs/extractor';
import { getCache, withCacheNamespace } from './cache';
import cliState from './cliState';
import { DEFAULT_MAX_CONCURRENCY, FILE_METADATA_KEY } from './constants';
import { getEnvBool, getEnvInt, getEvalTimeoutMs, getMaxEvalTimeMs, isCI } from './envars';
import { collectFileMetadata, renderPrompt, runExtensionHook } from './evaluatorHelpers';
import logger, { globalLogCallback, setLogCallback } from './logger';
import { selectMaxScore } from './matchers/comparison';
import { getResultIndexKey, sanitizeResultForJsonlArtifact } from './models/evalResult';
import { generateIdFromPrompt } from './models/prompt';
import { nodeEvaluatorRuntime } from './node/evaluatorRuntime';
import { CIProgressReporter } from './progress/ciProgressReporter';
import { maybeEmitAzureOpenAiWarning } from './providers/azure/warnings';
import { providerRegistry } from './providers/providerRegistry';
import { isPromptfooSampleTarget } from './providers/shared';
import { maybeWrapMcpProviderForRedteam } from './redteam/mcpTargetProvider';
import { redteamProviderManager } from './redteam/providers/shared';
import { throwIfTargetPromptExceedsMaxChars } from './redteam/shared/promptLength';
import { getSessionId } from './redteam/util';
import {
  createProviderRateLimitOptions,
  createRateLimitRegistry,
  type RateLimitRegistry,
} from './scheduler';
import {
  withProviderCallExecutionContext,
  withProviderCallTracingContext,
} from './scheduler/providerCallExecutionContext';
import { type ProviderCallQueue, ProviderGroupedCallQueue } from './scheduler/providerCallQueue';
import { generatePrompts } from './suggestions';
import telemetry from './telemetry';
import {
  generateTraceContextIfNeeded,
  isOtlpReceiverStarted,
  startOtlpReceiverIfNeeded,
  stopOtlpReceiverIfNeeded,
} from './tracing/evaluatorTracing';
import { getDefaultOtelConfig } from './tracing/otelConfig';
import { flushOtel, initializeOtel, shutdownOtel } from './tracing/otelSdk';
import { isExternalTraceProvider } from './tracing/providers';
import { getActiveTraceparent } from './tracing/spanRoles';
import { withGraderSpan, withTestCaseSpan, withTracedProviderCall } from './tracing/targetTracer';
import { fetchTraceContext } from './tracing/traceContext';
import { isCliEventSource } from './types/eventSource';
import {
  type Assertion,
  type AssertionOrSet,
  type AssertionType,
  type AtomicTestCase,
  type CompletedPrompt,
  type EnvOverrides,
  type EvaluateResult,
  type EvaluateStats,
  type GradingResult,
  MAX_SUGGESTIONS_COUNT,
  type Prompt,
  type ProviderResponse,
  ResultFailureReason,
  type RunEvalOptions,
  type TestSuite,
} from './types/index';
import { type ApiProvider, isApiProvider } from './types/providers';
import { isAbortError, isNonTransientHttpStatus } from './util/fetch/errors';
import { filterByRange } from './util/filterRange';
import { warnEmptyFilterRange } from './util/filterRangeWarn';
import { loadFunction, parseFileUrl } from './util/functions/loadFunction';
import {
  buildConfiguredProviderMap,
  resolveConfiguredProviderReference,
} from './util/gradingProvider';
import invariant from './util/invariant';
import { safeJsonStringify, summarizeEvaluateResultForLogging } from './util/json';
import { accumulateNamedMetric, backfillNamedScoreWeights } from './util/namedMetrics';
import { filterFiniteScores } from './util/numeric';
import { isPromptAllowed } from './util/promptMatching';
import {
  getProviderIdentifier,
  isAnthropicProvider,
  isGoogleProvider,
  isOpenAiProvider,
  isProviderAllowed,
  sanitizeProviderIdForLog,
} from './util/provider';
import { promptYesNo } from './util/readline';
import { analyzeTemplateReference, extractVariablesFromTemplate } from './util/templates';
import { sleep } from './util/time';
import { TokenUsageTracker } from './util/tokenUsage';
import {
  accumulateAssertionTokenUsage,
  accumulateGradingRequest,
  accumulateGradingTokenUsage,
  accumulateResponseTokenUsage,
  cloneTokenUsageBreakdown,
  createEmptyAssertions,
  createEmptyTokenUsage,
} from './util/tokenUsageUtils';
import { TransformInputType, transform } from './util/transform';
import type { SingleBar } from 'cli-progress';
import type winston from 'winston';

import type {
  EvaluationRecord,
  EvaluationStore,
  EvaluationStoreResult,
  EvaluatorResultWriter,
  EvaluatorRuntime,
} from './evaluator/runtime';
import type {
  EvalConversations,
  EvalRegisters,
  PromptMetrics,
  ProviderOptions,
  RateLimitRegistryRef,
  ScoringFunction,
  TokenUsage,
  Vars,
  VarValue,
} from './types/index';
import type { InternalEvaluateOptions } from './types/internal';
import type { CallApiContextParams } from './types/providers';

export class PromptSuggestionsRejectedError extends Error {
  constructor(message = 'No prompts selected. Aborting.') {
    super(message);
    this.name = 'PromptSuggestionsRejectedError';
  }
}

const CONVERSATION_VAR_NAME = '_conversation';
const PROMPT_CONVERSATION_CACHE_MAX = 1024;
const PROMPTS_FLUSH_INTERVAL_MS = 1000;
const promptUsesConversationVariableCache = new LRUCache<string, boolean>({
  max: PROMPT_CONVERSATION_CACHE_MAX,
});

function promptUsesConversationVariable(prompt: Pick<Prompt, 'raw'>): boolean {
  const cached = promptUsesConversationVariableCache.get(prompt.raw);
  if (cached !== undefined) {
    return cached;
  }

  const { referenced, parsed } = analyzeTemplateReference(prompt.raw, CONVERSATION_VAR_NAME);
  // Only cache successfully parsed results. Caching a parse failure would
  // poison the cache for the lifetime of the process and silently downgrade
  // future conversation-aware runs to parallel execution.
  if (parsed) {
    promptUsesConversationVariableCache.set(prompt.raw, referenced);
  }
  return referenced;
}

/** Test-only: reset the per-process prompt conversation-variable cache. */
export function __resetPromptConversationCacheForTests(): void {
  promptUsesConversationVariableCache.clear();
}

/**
 * Manages a single progress bar for the evaluation
 */
export class ProgressBarManager {
  private progressBar: SingleBar | undefined;
  private isWebUI: boolean;
  private originalLogCallback: ((message: string) => void) | null = null;
  private installedLogCallback: ((message: string) => void) | null = null;
  private pendingRender: ReturnType<typeof setImmediate> | null = null;

  // Track overall progress
  private totalCount: number = 0;
  private completedCount: number = 0;
  private concurrency: number = 1;

  constructor(isWebUI: boolean) {
    this.isWebUI = isWebUI;
  }

  private clearProgressBarLine(): void {
    readline.cursorTo(process.stderr, 0);
    readline.clearLine(process.stderr, 0);
  }

  private scheduleRender(): void {
    if (!this.progressBar || this.pendingRender) {
      return;
    }

    this.pendingRender = setImmediate(() => {
      this.pendingRender = null;
      // biome-ignore lint/suspicious/noExplicitAny: cli-progress SingleBar.render() is not in public typings
      (this.progressBar as any)?.render();
    });
  }

  private handleLogMessage(): void {
    if (!this.progressBar) {
      return;
    }

    // Clear the progress bar's stream before Winston writes to the terminal,
    // then re-render the bar after the log line has been emitted.
    this.clearProgressBarLine();
    this.scheduleRender();
  }

  /**
   * Coordinate console logging with the progress bar to prevent visual corruption.
   */
  installLogInterceptor(): void {
    if (!this.progressBar || this.isWebUI || this.installedLogCallback) {
      return;
    }

    this.originalLogCallback = globalLogCallback;
    this.installedLogCallback = (message: string) => {
      this.originalLogCallback?.(message);
      this.handleLogMessage();
    };
    setLogCallback(this.installedLogCallback);
  }

  /**
   * Remove the log interceptor and restore original logger callback behavior.
   */
  removeLogInterceptor(): void {
    if (this.pendingRender) {
      clearImmediate(this.pendingRender);
      this.pendingRender = null;
    }

    if (this.installedLogCallback && globalLogCallback === this.installedLogCallback) {
      setLogCallback(this.originalLogCallback);
    }

    this.installedLogCallback = null;
    this.originalLogCallback = null;
  }

  /**
   * Initialize progress bar
   */
  async initialize(
    runEvalOptions: RunEvalOptions[],
    concurrency: number,
    compareRowsCount: number,
  ): Promise<void> {
    if (this.isWebUI) {
      return;
    }

    this.totalCount = runEvalOptions.length + compareRowsCount;
    this.concurrency = concurrency;

    // Create single progress bar
    this.progressBar = new cliProgress.SingleBar(
      {
        format: (options, params, payload) => {
          const barsize = options.barsize ?? 40;
          const barCompleteString = options.barCompleteString ?? '=';
          const barIncompleteString = options.barIncompleteString ?? '-';

          const bar = barCompleteString.substring(0, Math.round(params.progress * barsize));
          const spaces = barIncompleteString.substring(0, barsize - bar.length);
          const percentage = Math.round(params.progress * 100);

          // Only show errors if count > 0
          const errorsText = payload.errors > 0 ? ` (errors: ${payload.errors})` : '';

          return `Evaluating [${bar}${spaces}] ${percentage}% | ${params.value}/${params.total}${errorsText} | ${payload.provider} ${payload.prompt} ${payload.vars}`;
        },
        hideCursor: true,
        gracefulExit: true,
        stream: process.stderr,
      },
      cliProgress.Presets.shades_classic,
    );

    // Start the progress bar
    this.progressBar.start(this.totalCount, 0, {
      provider: '',
      prompt: '',
      vars: '',
      errors: 0,
    });
  }

  /**
   * Update progress for a specific evaluation
   */
  updateProgress(
    _index: number,
    evalStep: RunEvalOptions | undefined,
    _phase: 'serial' | 'concurrent' = 'concurrent',
    metrics?: PromptMetrics,
  ): void {
    if (this.isWebUI || !evalStep || !this.progressBar) {
      return;
    }

    this.completedCount++;
    const provider = evalStep.provider.label || evalStep.provider.id();
    const prompt = `"${evalStep.prompt.raw.slice(0, 10).replace(/\n/g, ' ')}"`;
    const vars = formatVarsForDisplay(evalStep.test.vars, 40);

    this.progressBar.increment({
      provider,
      prompt: prompt || '""',
      vars: vars || '',
      errors: metrics?.testErrorCount ?? 0,
    });
  }

  /**
   * Update comparison progress
   */
  updateComparisonProgress(prompt: string): void {
    if (this.isWebUI || !this.progressBar) {
      return;
    }

    this.completedCount++;
    this.progressBar.increment({
      provider: 'Grading',
      prompt: `"${prompt.slice(0, 10).replace(/\n/g, ' ')}"`,
      vars: '',
      errors: 0,
    });
  }

  /**
   * Update total count when comparison count is determined
   */
  updateTotalCount(additionalCount: number): void {
    if (this.isWebUI || !this.progressBar || additionalCount <= 0) {
      return;
    }

    this.totalCount += additionalCount;
    this.progressBar.setTotal(this.totalCount);
  }

  /**
   * Mark evaluation as complete
   */
  complete(): void {
    if (this.isWebUI || !this.progressBar) {
      return;
    }

    // Just ensure we're at 100% - the bar will be stopped in stop()
    this.progressBar.update(this.totalCount);
  }

  /**
   * Stop the progress bar
   */
  stop(): void {
    if (this.progressBar) {
      this.progressBar.stop();
    }
  }
}

/**
 * Update token usage metrics with assertion token usage
 */
function updateAssertionMetrics(
  metrics: { tokenUsage: Partial<TokenUsage> },
  assertionTokens: Partial<TokenUsage>,
  options?: { cached?: boolean },
): void {
  if (metrics.tokenUsage && assertionTokens) {
    const reportedTotal =
      assertionTokens.total ?? (assertionTokens.prompt ?? 0) + (assertionTokens.completion ?? 0);
    const cachedTokens = assertionTokens.cached ?? 0;
    const cachedResponse =
      options?.cached === true ||
      (options?.cached === undefined &&
        assertionTokens.numRequests === 0 &&
        cachedTokens > 0 &&
        reportedTotal <= cachedTokens);

    if (cachedResponse && !metrics.tokenUsage.incurredTokenUsage) {
      metrics.tokenUsage.incurredTokenUsage = cloneTokenUsageBreakdown(metrics.tokenUsage);
    }

    if (!metrics.tokenUsage.assertions) {
      metrics.tokenUsage.assertions = createEmptyAssertions();
    }

    // Accumulate assertion tokens using the specialized assertion function
    accumulateAssertionTokenUsage(metrics.tokenUsage.assertions, assertionTokens);

    if (metrics.tokenUsage.incurredTokenUsage && !cachedResponse) {
      metrics.tokenUsage.incurredTokenUsage.assertions ??= createEmptyAssertions();
      accumulateAssertionTokenUsage(
        metrics.tokenUsage.incurredTokenUsage.assertions,
        assertionTokens.incurredTokenUsage ?? assertionTokens,
      );
    }
  }
}

/**
 * Validates if a given prompt is allowed based on the provided list of allowed
 * prompt references. Providers and tests can be configured with a `prompts` attribute,
 * which corresponds to an array of prompt labels or IDs. References can either match
 * exactly or use wildcard patterns. Examples:
 *
 * - `prompts: ['examplePrompt']` matches prompt with label OR id 'examplePrompt'
 * - `prompts: ['exampleGroup:*']` matches any prompt with label/id starting with 'exampleGroup:'
 * - `prompts: ['exampleGroup']` matches 'exampleGroup' exactly OR any label/id starting with 'exampleGroup:'
 *
 * If no `prompts` attribute is present, all prompts are allowed by default.
 *
 * @param prompt - The prompt object to check.
 * @param allowedPrompts - The list of allowed prompt labels or IDs.
 * @returns Returns true if the prompt is allowed, false otherwise.
 */
export function isAllowedPrompt(prompt: Prompt, allowedPrompts: string[] | undefined): boolean {
  return isPromptAllowed(prompt, allowedPrompts);
}

function isGeneratedRedteamAssertion(assertion: { type?: string }): boolean {
  return typeof assertion.type === 'string' && assertion.type.startsWith('promptfoo:redteam:');
}

type NestedAssertion = {
  type?: string;
  assert?: NestedAssertion[];
};

function hasNestedRedteamAssertion(assertion: NestedAssertion): boolean {
  if (isGeneratedRedteamAssertion(assertion)) {
    return true;
  }

  return (
    assertion.type === 'assert-set' &&
    Array.isArray(assertion.assert) &&
    assertion.assert.some(hasNestedRedteamAssertion)
  );
}

function getRepeatCacheNamespace(
  repeatIndex: number,
  evaluateOptions?: InternalEvaluateOptions,
): string | undefined {
  if (repeatIndex > 0 || (evaluateOptions?.repeat ?? 1) > 1) {
    return `repeat:${repeatIndex}`;
  }
  return undefined;
}

function normalizeRepeatCount(repeat: number | undefined, fallback = 1): number {
  return typeof repeat === 'number' && Number.isSafeInteger(repeat) && repeat > 0
    ? repeat
    : fallback;
}

function hasGeneratedRedteamMetadata(test: AtomicTestCase): boolean {
  return (
    typeof test.metadata?.pluginId === 'string' &&
    (Boolean(test.metadata?.pluginConfig) || Boolean(test.metadata?.goal))
  );
}

function shouldSkipRedteamInjectVar(
  test: AtomicTestCase,
  testSuite: TestSuite | undefined,
  isRedteam: boolean,
): boolean {
  if (isRedteam || testSuite?.redteam) {
    return true;
  }

  // Exported/generated redteam configs may not include a top-level `redteam` block,
  // but they still carry redteam metadata or nested redteam assertions.
  return hasGeneratedRedteamMetadata(test) || Boolean(test.assert?.some(hasNestedRedteamAssertion));
}

function getRedteamInjectVar(test: AtomicTestCase, prompt: Prompt, testSuite?: TestSuite): string {
  if (testSuite?.redteam?.injectVar) {
    return testSuite.redteam.injectVar;
  }

  const promptTemplate = prompt.template ?? prompt.raw;
  const promptVars = extractVariablesFromTemplate(promptTemplate);

  if (
    testSuite?.redteam &&
    promptVars.includes('prompt') &&
    Object.prototype.hasOwnProperty.call(test.vars ?? {}, 'prompt')
  ) {
    return 'prompt';
  }

  const matchingVars = promptVars.filter((variableName) =>
    Object.prototype.hasOwnProperty.call(test.vars ?? {}, variableName),
  );

  // Mirror redteam generation behavior by preferring the last prompt variable.
  return matchingVars.at(-1) ?? promptVars.at(-1) ?? 'prompt';
}

const deferredGradingPromises = new WeakMap<EvaluateResult, Promise<void>>();

const PROVIDER_GROUPED_ASSERTION_TYPES = new Set<AssertionType>([
  ...MODEL_GRADED_ASSERTION_TYPES,
  'conversation-relevance',
  'g-eval',
]);

function hasProviderGroupedAssertion(assertion: AssertionOrSet): boolean {
  if (assertion.type === 'assert-set') {
    return assertion.assert.some(hasProviderGroupedAssertion);
  }

  return PROVIDER_GROUPED_ASSERTION_TYPES.has(getAssertionBaseType(assertion));
}

function shouldDeferGradingForTest(test: AtomicTestCase): boolean {
  return Boolean(test.assert?.some(hasProviderGroupedAssertion));
}

function logGroupedGradingStatus({
  concurrency,
  hasEvalStepTimeout,
  runEvalOptions,
  shouldGroupGradingByProvider,
  usesConversationVar,
}: {
  concurrency: number;
  hasEvalStepTimeout: boolean;
  runEvalOptions: RunEvalOptions[];
  shouldGroupGradingByProvider: boolean;
  usesConversationVar: boolean;
}) {
  const hasModelGradedAssertion = runEvalOptions.some(({ test }) =>
    shouldDeferGradingForTest(test),
  );
  if (!hasModelGradedAssertion) {
    return;
  }
  if (shouldGroupGradingByProvider) {
    logger.info(
      'Grouping model-graded assertions by provider to minimize local-model reload overhead.',
    );
    return;
  }
  if (concurrency !== 1) {
    return;
  }
  const reasons: string[] = [];
  if (hasEvalStepTimeout) {
    reasons.push('per-eval-step timeout is configured');
  }
  if (usesConversationVar) {
    reasons.push('conversation variables require per-row ordering');
  }
  if (reasons.length > 0) {
    logger.info(
      `Serial grading grouping disabled because ${reasons.join(' and ')}; model-graded judges may reload between rows.`,
    );
  }
}

// When an afterEach hook replaces response.metadata, a legacy top-level metadata.headers that
// was copied from the OLD transport headers becomes stale — and would persist as stale (and
// possibly sensitive) headers. Only re-sync when the original top-level headers provably came
// from the original transport (deep-equal) and the hook left that top-level copy unchanged;
// otherwise the hook owns metadata.headers and we leave it alone.
function synchronizeLegacyTransportHeaders(
  originalMetadata: Record<string, unknown> | undefined,
  originalResponseMetadata: Record<string, unknown> | undefined,
  hookMetadata: Record<string, unknown> | undefined,
  hookResponseMetadata: Record<string, unknown> | undefined,
) {
  const originalHeaders = originalMetadata?.headers;
  if (
    originalHeaders === undefined ||
    !isDeepStrictEqual(originalHeaders, originalResponseMetadata?.headers) ||
    !isDeepStrictEqual(hookMetadata?.headers, originalHeaders)
  ) {
    return hookMetadata;
  }

  const { headers: _staleHeaders, ...metadataWithoutHeaders } = hookMetadata ?? {};
  if (hookResponseMetadata?.headers === undefined) {
    return metadataWithoutHeaders;
  }
  return { ...metadataWithoutHeaders, headers: hookResponseMetadata.headers };
}

function applyGradingResult(row: EvaluateResult, checkResult: GradingResult) {
  if (!checkResult.pass) {
    row.error = checkResult.reason;
    row.failureReason = ResultFailureReason.ASSERT;
  }
  row.success = checkResult.pass;
  row.score = checkResult.score;
  row.namedScores = checkResult.namedScores || {};

  if (!row.tokenUsage) {
    row.tokenUsage = createEmptyTokenUsage();
  }
  accumulateGradingTokenUsage(row.tokenUsage, checkResult.tokensUsed, {
    cached: checkResult.metadata?.cachedResponse,
  });
  row.gradingResult = checkResult;
}

const ABORTED_GRADING_PREFIX = 'Aborted: ';

function applyGradingError(row: EvaluateResult, error: unknown, abortSignal?: AbortSignal) {
  const errorAsError = error instanceof Error ? error : undefined;
  // Require both signals: a third-party SDK that throws `AbortError` during a
  // non-aborted run is a real bug, and a real SyntaxError caught microseconds
  // after an unrelated abort is also a real bug.
  const aborted = Boolean(abortSignal?.aborted) && isAbortError(error);

  if (aborted) {
    // Skip stack serialization on the abort path — debug logs usually go
    // unread and a noisy shutdown can fire this per row.
    const shortMessage = errorAsError?.message ?? String(error);
    logger.debug('Assertion grading aborted', {
      error: shortMessage,
      promptIdx: row.promptIdx,
      testIdx: row.testIdx,
    });
    row.error = `${ABORTED_GRADING_PREFIX}${shortMessage}`;
  } else {
    const fullMessage = errorAsError ? (errorAsError.stack ?? errorAsError.message) : String(error);
    logger.error('Assertion grading failed during eval', {
      error: fullMessage,
      promptIdx: row.promptIdx,
      testIdx: row.testIdx,
    });
    row.error = fullMessage;
  }
  row.failureReason = ResultFailureReason.ERROR;
  row.success = false;
  row.score = 0;
  row.namedScores = {};
}

function getNonTransientTargetStatus(row: EvaluateResult): number | undefined {
  const httpStatus = row.response?.metadata?.http?.status;
  return typeof httpStatus === 'number' && isNonTransientHttpStatus(httpStatus)
    ? httpStatus
    : undefined;
}

type RunEvalSetup = Pick<EvaluateResult, 'prompt' | 'vars'> & {
  provider: EvaluateResult['provider'] & { config?: ApiProvider['config'] };
};

interface RunEvalState {
  conversationKey: string;
  fileMetadata: Record<string, unknown>;
  promptForRender: Prompt;
  setup: RunEvalSetup;
  vars: Vars;
}

interface RenderedRunEvalPrompt {
  renderedJson: unknown;
  renderedPrompt: string;
  setup: RunEvalSetup;
}

interface ProviderCallResult {
  latencyMs: number;
  response: ProviderResponse;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
}

function mergeProviderPromptConfig(
  promptConfig: Prompt['config'],
  testOptions: AtomicTestCase['options'],
): Prompt['config'] {
  const { repeat: _repeat, ...providerOptions } = testOptions ?? {};
  return {
    ...(promptConfig ?? {}),
    ...providerOptions,
  };
}

function createRunEvalState({
  provider,
  prompt,
  promptIndex,
  test,
}: Pick<RunEvalOptions, 'provider' | 'prompt' | 'test'> & {
  promptIndex: number;
}): RunEvalState {
  const vars = structuredClone(test.vars || {});
  const fileMetadata = collectFileMetadata(vars);
  // Provider identifiers and prompt ids can both collide, but every result-table
  // column has a unique index. Encode the components as a tuple because identifiers
  // can contain separators that would make concatenated keys ambiguous.
  const conversationKey = JSON.stringify([
    getProviderIdentifier(provider),
    prompt.id,
    promptIndex,
    test.metadata?.conversationId,
  ]);

  const setup = createRunEvalSetup({
    provider,
    prompt,
    promptConfig: mergeProviderPromptConfig(prompt.config, test.options),
    vars,
  });

  return {
    conversationKey,
    fileMetadata,
    promptForRender: { ...prompt },
    setup,
    vars,
  };
}

/**
 * Reserved keys for eval-step runtime vars. `EvalRuntimeVars` below is keyed by
 * this tuple, so adding a new key to {@link getEvalRuntimeVars} fails to
 * type-check until the key is added here too — keeping the omit list and the
 * producer in lockstep.
 */
const EVAL_RUNTIME_VAR_KEYS = ['__evalId', '__evalStepId', '__repeatIndex'] as const;
const EVAL_RUNTIME_VAR_KEY_SET: ReadonlySet<string> = new Set(EVAL_RUNTIME_VAR_KEYS);
type EvalRuntimeVars = Partial<Record<(typeof EVAL_RUNTIME_VAR_KEYS)[number], Vars[string]>>;

function getEvalRuntimeVars({
  evalId,
  promptIndex,
  repeatIndex,
  testIndex,
}: {
  evalId?: string;
  promptIndex: number;
  repeatIndex: number;
  testIndex: number;
}): EvalRuntimeVars {
  return {
    ...(evalId ? { __evalId: evalId } : {}),
    __evalStepId: `test-${testIndex}-prompt-${promptIndex}-repeat-${repeatIndex}`,
    __repeatIndex: repeatIndex,
  };
}

/**
 * Returns a copy of `vars` without the reserved `__eval*` runtime vars. They are
 * merged into an eval step's vars so prompts and providers can reference them,
 * but must not reach the persisted `EvaluateResult.vars` or assertion/grader
 * inputs: they are positional per-step identifiers that would pollute stored
 * results and — being `_`-prefixed — get restored onto re-run `test.vars` by
 * `--filter-*` re-runs. The input is not mutated; it is shared by reference
 * with the provider call context.
 */
function omitEvalRuntimeVars(vars: Vars): Vars {
  const result: Vars = {};
  for (const [key, value] of Object.entries(vars)) {
    if (!EVAL_RUNTIME_VAR_KEY_SET.has(key)) {
      result[key] = value;
    }
  }
  return result;
}

function attachConversationVar({
  conversations,
  conversationKey,
  prompt,
  test,
  vars,
}: {
  conversations?: EvalConversations;
  conversationKey: string;
  prompt: Prompt;
  test: AtomicTestCase;
  vars: Vars;
}) {
  const usesConversation = promptUsesConversationVariable(prompt);
  if (
    !getEnvBool('PROMPTFOO_DISABLE_CONVERSATION_VAR') &&
    !test.options?.disableConversationVar &&
    usesConversation
  ) {
    vars._conversation = conversations?.[conversationKey] || [];
  }
}

function createRunEvalSetup({
  provider,
  prompt,
  promptConfig,
  vars,
}: {
  provider: ApiProvider;
  prompt: Prompt;
  promptConfig: Prompt['config'];
  vars: Vars;
}): RunEvalSetup {
  return {
    provider: {
      id: provider.id(),
      label: provider.label,
      config: provider.config,
    },
    prompt: {
      raw: '',
      label: prompt.label,
      config: promptConfig,
    },
    vars,
  };
}

async function renderRunEvalPrompt({
  filters,
  isRedteam,
  provider,
  promptForRender,
  test,
  testSuite,
  vars,
}: {
  filters: RunEvalOptions['nunjucksFilters'];
  isRedteam: boolean;
  provider: ApiProvider;
  promptForRender: Prompt;
  test: AtomicTestCase;
  testSuite?: TestSuite;
  vars: Vars;
}): Promise<RenderedRunEvalPrompt> {
  const skipRenderVars = shouldSkipRedteamInjectVar(test, testSuite, isRedteam)
    ? [getRedteamInjectVar(test, promptForRender, testSuite)]
    : undefined;
  const renderedPrompt = await renderPrompt(
    promptForRender,
    vars,
    filters,
    provider,
    skipRenderVars,
  );
  if (isRedteam) {
    throwIfTargetPromptExceedsMaxChars(renderedPrompt, testSuite?.redteam?.maxCharsPerMessage);
  }
  const promptConfig = mergeProviderPromptConfig(promptForRender.config, test.options);
  const setup = createRunEvalSetup({ provider, prompt: promptForRender, promptConfig, vars });
  setup.prompt.raw = renderedPrompt;
  return {
    renderedJson: tryParseJson(renderedPrompt),
    renderedPrompt,
    setup,
  };
}

function tryParseJson(value: string): unknown {
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
}

async function callProviderForRunEval({
  abortSignal,
  evalId,
  filters,
  promptForRender,
  provider,
  rateLimitRegistry,
  renderedPrompt,
  repeatIndex,
  test,
  testIndex,
  testSuite,
  traceContext,
  vars,
}: Pick<
  RunEvalOptions,
  | 'abortSignal'
  | 'evalId'
  | 'nunjucksFilters'
  | 'provider'
  | 'rateLimitRegistry'
  | 'repeatIndex'
  | 'test'
  | 'testSuite'
> & {
  filters: RunEvalOptions['nunjucksFilters'];
  promptForRender: Prompt;
  renderedPrompt: string;
  testIndex: number;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  vars: Vars;
}): Promise<ProviderCallResult> {
  const startTime = Date.now();
  let response: ProviderResponse | undefined;
  let providerInvoked = false;
  let providerFailed = false;

  try {
    if (test.providerOutput) {
      response = {
        output: test.providerOutput,
        tokenUsage: createEmptyTokenUsage(),
        cost: 0,
        cached: false,
      };
    } else {
      response = await callActiveProvider({
        abortSignal,
        evalId,
        filters,
        onProviderInvoked: () => {
          providerInvoked = true;
        },
        promptForRender,
        provider,
        rateLimitRegistry,
        renderedPrompt,
        repeatIndex,
        test,
        testIndex,
        testSuite,
        traceContext,
        vars,
      });
    }

    sanitizeResponseMetadata(response);

    return {
      latencyMs: Date.now() - startTime,
      response,
      traceContext,
    };
  } catch (error) {
    providerFailed = true;
    throw error;
  } finally {
    if (providerInvoked && isExternalTraceProvider(testSuite?.tracing?.provider)) {
      await collectExternalTraceAfterProviderCall({
        abortSignal,
        providerFailed,
        response,
        test,
        testSuite,
        traceContext,
      });
    }
  }
}

async function collectExternalTraceAfterProviderCall({
  abortSignal,
  providerFailed,
  response,
  test,
  testSuite,
  traceContext,
}: {
  abortSignal?: AbortSignal;
  providerFailed: boolean;
  response?: ProviderResponse;
  test: AtomicTestCase;
  testSuite?: TestSuite;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
}): Promise<void> {
  const traceId = getTraceId(traceContext);
  if (!traceId || abortSignal?.aborted) {
    return;
  }

  if (response?.cached) {
    logger.debug(
      `[Evaluator] Skipping external trace fetch for cached response traceId=${traceId}`,
    );
    return;
  }

  const tracingConfig = testSuite?.tracing;
  const needsTraceForGrading =
    !providerFailed &&
    !response?.error &&
    response?.output !== null &&
    response?.output !== undefined &&
    hasTraceAwareAssertions(test.assert);

  try {
    if (needsTraceForGrading) {
      await flushOtel();
    }

    logger.debug(`[Evaluator] Fetching traces from external provider for traceId=${traceId}`);
    const trace = await fetchTraceContext(traceId, {
      providerConfig: tracingConfig?.provider,
      queryDelay: tracingConfig?.queryDelay,
      maxRetries: needsTraceForGrading ? 5 : 0,
      retryDelayMs: 1000,
      includeInternalSpans: true,
      sanitizeAttributes: true,
      redactAttributes: tracingConfig?.otlp?.http?.redactAttributes,
      abortSignal,
    });

    if (trace) {
      logger.debug(`[Evaluator] Successfully fetched traces for traceId=${traceId}`);
    } else {
      logger.debug(`[Evaluator] No external traces found for traceId=${traceId}`);
    }
  } catch (error) {
    if (abortSignal?.aborted) {
      if (!providerFailed) {
        throw error;
      }
      return;
    }
    logger.warn(`[Evaluator] Failed to fetch external traces: ${error}`);
  }
}

async function callActiveProvider({
  abortSignal,
  evalId,
  filters,
  onProviderInvoked,
  promptForRender,
  provider,
  rateLimitRegistry,
  renderedPrompt,
  repeatIndex,
  test,
  testIndex,
  testSuite,
  traceContext,
  vars,
}: Pick<
  RunEvalOptions,
  'abortSignal' | 'evalId' | 'provider' | 'rateLimitRegistry' | 'repeatIndex' | 'test' | 'testSuite'
> & {
  filters: RunEvalOptions['nunjucksFilters'];
  onProviderInvoked: () => void;
  promptForRender: Prompt;
  renderedPrompt: string;
  testIndex: number;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  vars: Vars;
}): Promise<ProviderResponse> {
  const originalProvider = maybeWrapMcpProviderForRedteam(provider, test);
  const activeProvider = maybeWrapMcpProviderForRedteam(
    isApiProvider(test.provider) ? test.provider : originalProvider,
    test,
  );
  logger.debug(`Provider type: ${sanitizeProviderIdForLog(activeProvider.id())}`);

  const callApiContext = buildCallApiContext({
    evalId,
    filters,
    originalProvider,
    promptForRender,
    repeatIndex,
    test,
    testIndex,
    traceContext,
    vars,
  });
  const callApiOptions = abortSignal ? { abortSignal } : undefined;

  const callApi = () => {
    onProviderInvoked();
    const invoke = () =>
      traceContext?.traceparent
        ? withTracedProviderCall(
            {
              provider: activeProvider,
              callContext: callApiContext,
              promptLabel: promptForRender.label,
              evalId: callApiContext.evaluationId,
              testIndex,
            },
            async (context) => activeProvider.callApi(renderedPrompt, context, callApiOptions),
          )
        : activeProvider.callApi(renderedPrompt, callApiContext, callApiOptions);
    return testSuite?.tracing
      ? cliState.withRequestTracingConfig(testSuite.tracing, invoke)
      : invoke();
  };
  const response = rateLimitRegistry
    ? await rateLimitRegistry.execute(activeProvider, callApi, createProviderRateLimitOptions())
    : await callApi();

  logger.debug(`Provider response properties: ${Object.keys(response).join(', ')}`);
  logger.debug(`Provider response cached property explicitly: ${response.cached}`);
  return response;
}

function buildCallApiContext({
  evalId,
  filters,
  originalProvider,
  promptForRender,
  repeatIndex,
  test,
  testIndex,
  traceContext,
  vars,
}: {
  evalId?: string;
  filters: RunEvalOptions['nunjucksFilters'];
  originalProvider: ApiProvider;
  promptForRender: Prompt;
  repeatIndex: number;
  test: AtomicTestCase;
  testIndex: number;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  vars: Vars;
}): CallApiContextParams {
  const callApiContext: CallApiContextParams = {
    vars,
    prompt: promptForRender,
    filters,
    originalProvider,
    test,
    logger: logger as unknown as winston.Logger,
    getCache,
    repeatIndex,
    testIdx: testIndex,
  };

  if (evalId) {
    callApiContext.evaluationId = evalId;
  }
  if (traceContext) {
    callApiContext.traceparent = traceContext.traceparent;
    callApiContext.evaluationId = traceContext.evaluationId;
    callApiContext.testCaseId = traceContext.testCaseId;
  }

  return callApiContext;
}

function sanitizeResponseMetadata(response: ProviderResponse) {
  if (!response.metadata) {
    return;
  }
  const sanitizedMetadata = safeJsonStringify(response.metadata);
  response.metadata = sanitizedMetadata ? JSON.parse(sanitizedMetadata) : {};
}

function updateConversationHistory({
  conversationKey,
  conversations,
  renderedJson,
  renderedPrompt,
  response,
}: {
  conversationKey: string;
  conversations?: EvalConversations;
  renderedJson: unknown;
  renderedPrompt: string;
  response: ProviderResponse;
}) {
  if (!conversations) {
    return;
  }

  const conversationLastInput = getConversationLastInput(renderedJson);
  conversations[conversationKey] = conversations[conversationKey] || [];
  conversations[conversationKey].push({
    prompt: renderedJson || renderedPrompt,
    input: conversationLastInput || renderedJson || renderedPrompt,
    output: response.output || '',
    metadata: response.metadata,
  });
}

function getConversationLastInput(renderedJson: unknown) {
  if (!Array.isArray(renderedJson)) {
    return undefined;
  }
  const lastElt = renderedJson[renderedJson.length - 1];
  return lastElt?.content || lastElt;
}

async function applyProviderDelayIfNeeded(provider: ApiProvider, response: ProviderResponse) {
  if (!response.cached && provider.delay && provider.delay > 0) {
    logger.debug(`Sleeping for ${provider.delay}ms`);
    await sleep(provider.delay);
  } else if (response.cached) {
    logger.debug(`Skipping delay because response is cached`);
  }
}

function createEvaluateResult({
  fileMetadata,
  latencyMs,
  prompt,
  promptIdx,
  rendered,
  response,
  setup,
  test,
  testIdx,
  traceContext,
  evalId,
  vars,
}: {
  fileMetadata: Record<string, unknown>;
  latencyMs: number;
  prompt: Prompt;
  promptIdx: number;
  rendered: RenderedRunEvalPrompt;
  response: ProviderResponse;
  setup: RunEvalSetup;
  test: AtomicTestCase;
  testIdx: number;
  traceContext?: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  evalId?: string;
  vars: Vars;
}): EvaluateResult {
  const ret: EvaluateResult = {
    ...setup,
    // Use the caller-provided vars (which exclude the __eval* runtime vars)
    // for the persisted result rather than setup.vars.
    vars,
    prompt: { ...rendered.setup.prompt, raw: rendered.renderedPrompt },
    response,
    success: false,
    failureReason: ResultFailureReason.NONE,
    score: 0,
    namedScores: {},
    latencyMs: response.latencyMs ?? latencyMs,
    cost: response.cost,
    ...(response.incurredCost !== undefined && { incurredCost: response.incurredCost }),
    metadata: {
      ...test.metadata,
      ...response.metadata,
      [FILE_METADATA_KEY]: fileMetadata,
    },
    promptIdx,
    testIdx,
    testCase: test,
    promptId: prompt.id || '',
    tokenUsage: createEmptyTokenUsage(),
    ...getTraceLinkage(traceContext, evalId),
  };

  if (!ret.metadata?.sessionIds && !ret.metadata?.sessionId) {
    ret.metadata ??= {};
    ret.metadata.sessionId = getSessionId(response, { vars });
  }

  return ret;
}

/** Persist both the logical evaluation footprint and the work actually incurred. */
function normalizeCachedTargetResponse(response: ProviderResponse): ProviderResponse {
  if (!response.cached && !response.tokenUsage) {
    return response;
  }

  const tokenUsage = createEmptyTokenUsage();
  accumulateResponseTokenUsage(tokenUsage, response);
  return {
    ...response,
    tokenUsage,
    ...(response.cost !== undefined &&
      (response.cached || response.incurredCost !== undefined) && {
        incurredCost: response.incurredCost ?? (response.cached ? 0 : response.cost),
      }),
  };
}

function trackProviderUsage(provider: ApiProvider, response: ProviderResponse) {
  if (!response.tokenUsage) {
    return;
  }
  const providerId = provider.id();
  const trackingId = provider.constructor?.name
    ? `${providerId} (${provider.constructor.name})`
    : providerId;
  TokenUsageTracker.getInstance().trackResponseUsage(trackingId, response);
}

async function applyRunEvalResponseOutcome({
  abortSignal,
  deferGrading,
  evalId,
  isRedteam,
  latencyMs,
  prompt,
  promptIdx,
  provider,
  providerCallQueue,
  rateLimitRegistry,
  renderedPrompt,
  response,
  ret,
  test,
  testIdx,
  testSuite,
  traceContext,
  vars,
}: {
  abortSignal?: AbortSignal;
  deferGrading?: boolean;
  evalId?: string;
  isRedteam: boolean;
  latencyMs: number;
  prompt: Prompt;
  promptIdx: number;
  provider: ApiProvider;
  providerCallQueue?: ProviderCallQueue;
  rateLimitRegistry?: RateLimitRegistryRef;
  renderedPrompt: string;
  response: ProviderResponse;
  ret: EvaluateResult;
  test: AtomicTestCase;
  testIdx: number;
  testSuite?: TestSuite;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  vars: Vars;
}) {
  if (response.error) {
    ret.error = response.error;
    ret.failureReason = ResultFailureReason.ERROR;
    ret.success = false;
    return;
  }

  if (response.output === null || response.output === undefined) {
    applyEmptyResponseOutcome(ret, isRedteam);
    return;
  }

  await gradeRunEvalResponse({
    abortSignal,
    deferGrading,
    evalId,
    latencyMs,
    prompt,
    promptIdx,
    provider,
    providerCallQueue,
    rateLimitRegistry,
    renderedPrompt,
    response,
    ret,
    test,
    testIdx,
    testSuite,
    traceContext,
    vars,
  });
}

function applyEmptyResponseOutcome(ret: EvaluateResult, isRedteam: boolean) {
  if (isRedteam) {
    ret.success = true;
  } else {
    ret.success = false;
    ret.score = 0;
    ret.error = 'No output';
  }
}

async function gradeRunEvalResponse({
  abortSignal,
  deferGrading,
  evalId,
  latencyMs,
  prompt,
  promptIdx,
  provider,
  providerCallQueue,
  rateLimitRegistry,
  renderedPrompt,
  response,
  ret,
  test,
  testIdx,
  testSuite,
  traceContext,
  vars,
}: {
  abortSignal?: AbortSignal;
  deferGrading?: boolean;
  evalId?: string;
  latencyMs: number;
  prompt: Prompt;
  promptIdx: number;
  provider: ApiProvider;
  providerCallQueue?: ProviderCallQueue;
  rateLimitRegistry?: RateLimitRegistryRef;
  renderedPrompt: string;
  response: ProviderResponse;
  ret: EvaluateResult;
  test: AtomicTestCase;
  testIdx: number;
  testSuite?: TestSuite;
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>>;
  vars: Vars;
}) {
  const { processedResponse, providerTransformedOutput } = await transformRunEvalResponse({
    evalId,
    prompt,
    promptIdx,
    provider,
    response,
    test,
    testIdx,
    vars,
  });
  const traceId = getTraceId(traceContext);
  if (
    traceId &&
    hasTraceAwareAssertions(test.assert) &&
    !isExternalTraceProvider(testSuite?.tracing?.provider)
  ) {
    await flushOtel();
  }

  const assertionProviderResponse = {
    ...processedResponse,
    providerTransformedOutput,
  };

  if (deferGrading) {
    invariant(providerCallQueue, 'providerCallQueue is required when deferGrading is enabled');
    ret.response = processedResponse;
    const gradingPromise = withProviderCallExecutionContext(
      { abortSignal, providerCallQueue, rateLimitRegistry },
      () =>
        runAssertions({
          prompt: renderedPrompt,
          provider,
          providerResponse: assertionProviderResponse,
          test,
          vars,
          latencyMs: response.latencyMs ?? latencyMs,
          assertScoringFunction: test.assertScoringFunction as ScoringFunction,
          traceId,
        }).then((checkResult) => applyGradingResult(ret, checkResult)),
    ).catch((error) => {
      applyGradingError(ret, error, abortSignal);
    });
    deferredGradingPromises.set(ret, gradingPromise);
    return;
  }

  const checkResult = await withProviderCallExecutionContext(
    { abortSignal, rateLimitRegistry },
    () =>
      runAssertions({
        prompt: renderedPrompt,
        provider,
        providerResponse: assertionProviderResponse,
        test,
        vars,
        latencyMs: response.latencyMs ?? latencyMs,
        assertScoringFunction: test.assertScoringFunction as ScoringFunction,
        traceId,
      }),
  );
  applyGradingResult(ret, checkResult);
  ret.response = processedResponse;
}

async function transformRunEvalResponse({
  evalId,
  prompt,
  promptIdx,
  provider,
  response,
  test,
  testIdx,
  vars,
}: {
  evalId?: string;
  prompt: Prompt;
  promptIdx: number;
  provider: ApiProvider;
  response: ProviderResponse;
  test: AtomicTestCase;
  testIdx: number;
  vars: Vars;
}): Promise<{
  processedResponse: ProviderResponse;
  providerTransformedOutput: ProviderResponse['output'];
}> {
  const processedResponse = { ...response };
  if (provider.transform) {
    processedResponse.output = await transform(provider.transform, processedResponse.output, {
      vars,
      prompt,
    });
  }
  const providerTransformedOutput = processedResponse.output;

  const testTransform = test.options?.transform || test.options?.postprocess;
  if (testTransform) {
    processedResponse.output = await transform(testTransform, processedResponse.output, {
      vars,
      prompt,
      ...(response && response.metadata && { metadata: response.metadata }),
    });
  }

  invariant(processedResponse.output != null, 'Response output should not be null');
  const blobbedResponse = await extractAndStoreBinaryData(processedResponse, {
    evalId,
    testIdx,
    promptIdx,
  });

  return {
    processedResponse: blobbedResponse || processedResponse,
    providerTransformedOutput,
  };
}

export function getTraceId(
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>> | undefined,
) {
  if (!traceContext?.traceparent) {
    return undefined;
  }
  // W3C traceparent: `version-traceId-spanId-flags`. Version 00 has exactly 4 dash-separated
  // parts; future versions MAY append fields after flags. Validate the required fields before
  // surfacing linkage so malformed or sentinel IDs never become persisted row metadata.
  const parts = traceContext.traceparent.split('-');
  const [version, traceId, parentId, flags] = parts;
  const validPartCount = version === '00' ? parts.length === 4 : parts.length >= 4;
  const validTraceId = /^[0-9a-f]{32}$/.test(traceId) && !/^0+$/.test(traceId);
  const validParentId = /^[0-9a-f]{16}$/.test(parentId) && !/^0+$/.test(parentId);
  if (
    !/^[0-9a-f]{2}$/.test(version) ||
    version === 'ff' ||
    !validPartCount ||
    !validTraceId ||
    !validParentId ||
    !/^[0-9a-f]{2}$/.test(flags)
  ) {
    logger.warn(`[Evaluator] Malformed traceparent; dropping trace linkage on this row.`);
    return undefined;
  }
  return traceId;
}

export function getTraceLinkage(
  traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>> | undefined,
  evalId?: string,
) {
  const traceId = getTraceId(traceContext);
  // Only set evaluationId when a trace context exists. Pairing it with traceId keeps
  // the field's presence as a "this row was traced" signal for downstream consumers.
  const evaluationId = traceContext ? (traceContext.evaluationId ?? evalId) : undefined;
  return {
    ...(traceId ? { traceId } : {}),
    ...(evaluationId ? { evaluationId } : {}),
  };
}

/**
 * Runs a single test case.
 * @param options - The options for running the test case.
 * {
 *   provider - The provider to use for the test case.
 *   prompt - The raw prompt to use for the test case.
 *   test - The test case to run with assertions, etc.
 *   delay - A delay in ms to wait before any provider calls
 *   nunjucksFilters - The nunjucks filters to use for the test case.
 *   evaluateOptions - Currently unused
 *   testIdx - The index of the test case among all tests (row in the results table).
 *   promptIdx - The index of the prompt among all prompts (column in the results table).
 *   conversations - Evals can be run serially across multiple turns of a conversation. This gives access to the conversation history.
 *   registers - The registers to use for the test case to store values for later tests.
 *   isRedteam - Whether the test case is a redteam test case.
 * }
 * @returns The result of the test case.
 */
export async function runEval(options: RunEvalOptions): Promise<EvaluateResult[]> {
  return withCacheNamespace(
    getRepeatCacheNamespace(options.repeatIndex, options.evaluateOptions),
    () => runEvalInternal(options),
  );
}

async function runEvalInternal({
  provider,
  prompt, // raw prompt
  test,
  testSuite,
  delay,
  nunjucksFilters: filters,
  evaluateOptions,
  // TODO(ian): Rename these public `Idx` fields to `Index` with compatibility handling.
  testIdx: testIndex,
  promptIdx: promptIndex,
  repeatIndex,
  conversations,
  registers,
  isRedteam,
  abortSignal,
  deferGrading,
  evalId,
  providerCallQueue,
  rateLimitRegistry,
}: RunEvalOptions): Promise<EvaluateResult[]> {
  provider.delay ??= delay ?? getEnvInt('PROMPTFOO_DELAY_MS', 0);
  invariant(
    typeof provider.delay === 'number',
    `Provider delay should be set for ${provider.label}`,
  );

  const state = createRunEvalState({ provider, prompt, promptIndex, test });
  attachConversationVar({
    conversations,
    conversationKey: state.conversationKey,
    prompt,
    test,
    vars: state.vars,
  });
  Object.assign(state.vars, registers);
  Object.assign(
    state.vars,
    getEvalRuntimeVars({
      evalId,
      promptIndex,
      repeatIndex,
      testIndex,
    }),
  );

  let setup = state.setup;
  let latencyMs = 0;
  let traceContext: Awaited<ReturnType<typeof generateTraceContextIfNeeded>> | undefined;

  try {
    const rendered = await renderRunEvalPrompt({
      filters,
      isRedteam,
      provider,
      promptForRender: state.promptForRender,
      test,
      testSuite,
      vars: state.vars,
    });
    setup = rendered.setup;

    traceContext = test.providerOutput
      ? null
      : await generateTraceContextIfNeeded(
          test,
          evaluateOptions,
          testIndex,
          promptIndex,
          testSuite,
          {
            providerId: (isApiProvider(test.provider) ? test.provider : provider).id(),
            promptLabel: state.promptForRender.label,
            repeatIndex,
          },
        );
    const executionTraceContext = traceContext;
    const runExecution = () =>
      withTestCaseSpan(
        executionTraceContext?.rootSpan,
        async () => {
          const providerCall = await callProviderForRunEval({
            abortSignal,
            evalId,
            filters,
            promptForRender: {
              ...state.promptForRender,
              config: rendered.setup.prompt.config,
            },
            provider,
            rateLimitRegistry,
            renderedPrompt: rendered.renderedPrompt,
            repeatIndex,
            test,
            testIndex,
            testSuite,
            traceContext: executionTraceContext,
            vars: state.vars,
          });
          const response = normalizeCachedTargetResponse(providerCall.response);
          latencyMs = providerCall.latencyMs;

          updateConversationHistory({
            conversationKey: state.conversationKey,
            conversations,
            renderedJson: rendered.renderedJson,
            renderedPrompt: rendered.renderedPrompt,
            response,
          });

          logger.debug('Evaluator response', {
            responsePreview: (safeJsonStringify(response) ?? '').slice(0, 100),
          });
          logger.debug(
            `Evaluator checking cached flag: response.cached = ${Boolean(response.cached)}, provider.delay = ${provider.delay}`,
          );

          await applyProviderDelayIfNeeded(provider, response);

          // The __eval* runtime vars were exposed to prompt/provider rendering above.
          // Build a copy without them for the persisted result, assertions, and
          // graders. state.vars itself is left intact — it is shared by reference
          // with the provider call context.
          const persistedVars = omitEvalRuntimeVars(state.vars);

          const ret = createEvaluateResult({
            fileMetadata: state.fileMetadata,
            latencyMs,
            prompt,
            promptIdx: promptIndex,
            rendered,
            response,
            setup,
            test,
            testIdx: testIndex,
            traceContext: executionTraceContext,
            evalId,
            vars: persistedVars,
          });

          invariant(ret.tokenUsage, 'This is always defined, just doing this to shut TS up');

          trackProviderUsage(provider, response);
          await applyRunEvalResponseOutcome({
            abortSignal,
            deferGrading,
            evalId,
            isRedteam,
            latencyMs,
            prompt,
            promptIdx: promptIndex,
            provider,
            providerCallQueue,
            rateLimitRegistry,
            renderedPrompt: rendered.renderedPrompt,
            response,
            ret,
            test,
            testIdx: testIndex,
            testSuite,
            traceContext: executionTraceContext,
            vars: persistedVars,
          });

          // Update token usage stats
          if (response.tokenUsage) {
            accumulateResponseTokenUsage(ret.tokenUsage, response);
          }

          if (test.options?.storeOutputAs && ret.response?.output && registers) {
            // Save the output in a register for later use
            registers[test.options.storeOutputAs] = ret.response.output;
          }

          return [ret];
        },
        (rows) => deferredGradingPromises.get(rows[0]),
      );
    return executionTraceContext
      ? await withProviderCallTracingContext(
          {
            getActiveTraceparent,
            testIndex,
            withGraderSpan,
            withProviderSpan: withTracedProviderCall,
          },
          runExecution,
        )
      : await runExecution();
  } catch (err) {
    const { errorWithStack, metadata, logContext } = buildProviderErrorContext({
      error: err,
      provider,
      test,
      promptIdx: promptIndex,
      testIdx: testIndex,
    });

    // Don't log AbortError - these are expected when scan is aborted (e.g., target unavailable)
    const isAbortError = err instanceof Error && err.name === 'AbortError';
    if (!isAbortError) {
      logger.error('Provider call failed during eval', logContext);
    }

    return [
      {
        ...setup,
        // Exclude the __eval* runtime vars from the persisted error result.
        vars: omitEvalRuntimeVars(setup.vars),
        error: errorWithStack,
        success: false,
        failureReason: ResultFailureReason.ERROR,
        score: 0,
        namedScores: {},
        latencyMs,
        promptIdx: promptIndex,
        testIdx: testIndex,
        testCase: test,
        promptId: prompt.id || '',
        metadata,
        ...getTraceLinkage(traceContext, evalId),
      },
    ];
  }
}

function buildProviderErrorContext({
  error,
  provider,
  test,
  promptIdx,
  testIdx,
}: {
  error: unknown;
  provider: ApiProvider;
  test: AtomicTestCase;
  promptIdx: number;
  testIdx: number;
}) {
  const providerId = provider.id();
  const providerLabel = provider.label;
  // Type guard for errors with HTTP response information
  const errorWithResponse = error as {
    response?: { status?: number; statusText?: string; data?: unknown };
  };
  const status = errorWithResponse?.response?.status;
  const statusText = errorWithResponse?.response?.statusText;
  const responseData = errorWithResponse?.response?.data;
  const responseSnippet = (() => {
    if (responseData == null) {
      return undefined;
    }
    const asString =
      typeof responseData === 'string' ? responseData : safeJsonStringify(responseData);
    if (!asString) {
      return undefined;
    }
    return asString.length > 500 ? `${asString.slice(0, 500)}...` : asString;
  })();
  const errorMessage = String(error);
  const stack = (error as Error)?.stack;
  // Stack traces typically start with the error message, so check if stack already contains
  // the message to avoid duplication like "Error: msg\n\nError: msg\n    at ..."
  const errorWithStack = stack
    ? stack.startsWith(errorMessage)
      ? stack // Stack already contains the message
      : `${errorMessage}\n\n${stack}`
    : errorMessage;

  return {
    errorWithStack,
    metadata: {
      ...(test.metadata || {}),
      errorContext: {
        providerId,
        providerLabel,
        status,
        statusText,
        responseSnippet,
      },
    },
    logContext: {
      providerId,
      providerLabel,
      status,
      statusText,
      responseSnippet,
      promptIdx,
      testIdx,
      pluginId: test.metadata?.pluginId,
      strategyId: test.metadata?.strategyId,
      error,
    },
  };
}

/**
 * Safely formats variables for display in progress bars and logs.
 * Handles extremely large variables that could cause RangeError crashes.
 *
 * @param vars - Variables to format
 * @param maxLength - Maximum length of the final formatted string
 * @returns Formatted variables string or fallback message
 */
export function formatVarsForDisplay(
  vars: Record<string, unknown> | undefined,
  maxLength: number,
): string {
  if (!vars || Object.keys(vars).length === 0) {
    return '';
  }

  try {
    // Simple approach: limit individual values, then truncate the whole result
    const formatted = Object.entries(vars)
      .map(([key, value]) => {
        // Prevent memory issues by limiting individual values first
        const valueStr = String(value).slice(0, 100);
        return `${key}=${valueStr}`;
      })
      .join(' ')
      .replace(/\n/g, ' ')
      .slice(0, maxLength);

    return formatted;
  } catch {
    // Any error - return safe fallback
    return '[vars unavailable]';
  }
}

export function generateVarCombinations(
  vars: Record<string, string | string[] | unknown>,
): Record<string, VarValue>[] {
  const keys = Object.keys(vars);
  const combinations: Record<string, VarValue>[] = [{}];

  for (const key of keys) {
    let values: Array<string | object> = [];

    if (typeof vars[key] === 'string' && vars[key].startsWith('file://')) {
      const filePath = vars[key].slice('file://'.length);

      // For glob patterns, we need to resolve the base directory and use relative patterns
      const basePath = cliState.basePath || '';
      const filePaths =
        globSync(filePath, {
          cwd: basePath || process.cwd(),
          windowsPathsNoEscape: true,
        }) || [];

      values = filePaths.map((path: string) => `file://${path}`);
      if (values.length === 0) {
        throw new Error(
          `No files found for variable ${key} at path ${filePath} in directory ${basePath || process.cwd()}`,
        );
      }
    } else {
      values = Array.isArray(vars[key]) ? vars[key] : [vars[key]];
    }

    // Check if it's an array but not a string array
    if (Array.isArray(vars[key]) && typeof vars[key][0] !== 'string') {
      values = [vars[key]];
    }

    const newCombinations: Record<string, VarValue>[] = [];

    for (const combination of combinations) {
      for (const value of values) {
        newCombinations.push({ ...combination, [key]: value });
      }
    }

    combinations.length = 0;
    combinations.push(...newCombinations);
  }

  return combinations;
}

function updatePromptResultCounts(metrics: PromptMetrics, row: EvaluateResult) {
  metrics.testPassCount += row.success ? 1 : 0;
  if (!row.success) {
    if (row.failureReason === ResultFailureReason.ERROR) {
      metrics.testErrorCount += 1;
    } else {
      metrics.testFailCount += 1;
    }
  }
}

async function updateDerivedMetrics(
  metrics: PromptMetrics,
  derivedMetrics: NonNullable<TestSuite['derivedMetrics']>,
  evalStep: RunEvalOptions,
  promptEvalCount: number,
) {
  const math = await import('mathjs');
  if (Object.prototype.hasOwnProperty.call(metrics.namedScores, '__count')) {
    logger.warn("Metric name '__count' is reserved for derived metrics and will be overridden.");
  }

  const evalContext: Record<string, number> = {
    ...metrics.namedScores,
    __count: promptEvalCount,
  };
  for (const metric of derivedMetrics) {
    metrics.namedScores[metric.name] ??= 0;
    try {
      metrics.namedScores[metric.name] =
        typeof metric.value === 'function'
          ? metric.value(evalContext, evalStep)
          : math.evaluate(metric.value, evalContext);
      evalContext[metric.name] = metrics.namedScores[metric.name];
    } catch (error) {
      logger.debug(
        `Could not evaluate derived metric '${metric.name}': ${(error as Error).message}`,
      );
    }
  }
}

function updateComparisonReporterTotals({
  ciProgressReporter,
  compareRowsCount,
  progressBarManager,
  runEvalOptions,
}: {
  ciProgressReporter: CIProgressReporter | null;
  compareRowsCount: number;
  progressBarManager: ProgressBarManager | null;
  runEvalOptions: RunEvalOptions[];
}) {
  if (progressBarManager && compareRowsCount > 0) {
    progressBarManager.updateTotalCount(compareRowsCount);
  } else if (ciProgressReporter && compareRowsCount > 0) {
    ciProgressReporter.updateTotalTests(runEvalOptions.length + compareRowsCount);
  }
}

function updateComparisonReporterProgress({
  ciProgressReporter,
  compareCount,
  isWebUI,
  label,
  progressBarManager,
  promptRaw,
  runEvalOptions,
}: {
  ciProgressReporter: CIProgressReporter | null;
  compareCount: number;
  isWebUI: boolean;
  label: string;
  progressBarManager: ProgressBarManager | null;
  promptRaw: string;
  runEvalOptions: RunEvalOptions[];
}) {
  if (progressBarManager) {
    progressBarManager.updateComparisonProgress(promptRaw);
  } else if (ciProgressReporter) {
    ciProgressReporter.update(runEvalOptions.length + compareCount);
  } else if (!isWebUI) {
    logger.debug(`${label} complete`);
  }
}

function resultHasModelGradedAssertion(result: EvaluationStoreResult) {
  return result.testCase?.assert?.some((assertion) =>
    MODEL_GRADED_ASSERTION_TYPES.has(assertion.type as AssertionType),
  );
}

function mergeComparisonTokenUsage(
  result: EvaluationStoreResult,
  gradingResult: GradingResult,
  evalTokenUsage: TokenUsage,
) {
  if (!result.gradingResult || !gradingResult.tokensUsed) {
    return;
  }

  result.gradingResult.tokensUsed ||= {
    total: 0,
    prompt: 0,
    completion: 0,
  };
  const rowTokensUsed = result.gradingResult.tokensUsed;
  const rowMetrics = {
    tokenUsage: {
      assertions: rowTokensUsed,
      ...(rowTokensUsed.incurredTokenUsage && {
        incurredTokenUsage: { assertions: rowTokensUsed.incurredTokenUsage },
      }),
    },
  };
  updateAssertionMetrics(rowMetrics, gradingResult.tokensUsed, {
    cached: gradingResult.metadata?.cachedResponse,
  });
  if (rowMetrics.tokenUsage.incurredTokenUsage?.assertions) {
    rowTokensUsed.incurredTokenUsage = rowMetrics.tokenUsage.incurredTokenUsage.assertions;
  }

  if (resultHasModelGradedAssertion(result)) {
    updateAssertionMetrics({ tokenUsage: evalTokenUsage }, gradingResult.tokensUsed, {
      cached: gradingResult.metadata?.cachedResponse,
    });
  }
}

function mergeSelectBestGradingResult(
  result: EvaluationStoreResult,
  gradingResult: GradingResult,
  evalTokenUsage: TokenUsage,
) {
  mergeComparisonTokenUsage(result, gradingResult, evalTokenUsage);

  if (result.gradingResult) {
    if (
      result.gradingResult.metadata?.cachedResponse === true &&
      gradingResult.metadata?.cachedResponse !== true
    ) {
      const { cachedResponse: _cachedResponse, ...metadata } = result.gradingResult.metadata;
      result.gradingResult.metadata = Object.keys(metadata).length > 0 ? metadata : undefined;
    }

    result.success = result.gradingResult.pass = result.gradingResult.pass && gradingResult.pass;
    if (!gradingResult.pass) {
      result.gradingResult.reason = gradingResult.reason;
      result.score = result.gradingResult.score = gradingResult.score;
    }
    result.gradingResult.componentResults ||= [];
    result.gradingResult.componentResults.push(gradingResult);
    return;
  }

  const newPass = result.success && gradingResult.pass;
  result.gradingResult = {
    ...gradingResult,
    pass: newPass,
  };
  result.success = newPass;
  if (!gradingResult.pass) {
    result.score = result.gradingResult.score = gradingResult.score;
  }
}

function mergeMaxScoreGradingResult(result: EvaluationStoreResult, gradingResult: GradingResult) {
  const existingComponentResults = result.gradingResult?.componentResults || [];
  const existingGradingResult = result.gradingResult;
  const comparisonPassed = gradingResult.pass;
  const previousPass = existingGradingResult?.pass ?? result.success;
  const nextPass = previousPass && comparisonPassed;
  const newScore = comparisonPassed
    ? (existingGradingResult?.score ?? result.score)
    : gradingResult.score;

  result.gradingResult = {
    ...(existingGradingResult || {}),
    pass: nextPass,
    score: newScore,
    reason:
      !comparisonPassed && previousPass
        ? gradingResult.reason
        : (existingGradingResult?.reason ?? ''),
    componentResults: [...existingComponentResults, gradingResult],
    namedScores: {
      ...(existingGradingResult?.namedScores || {}),
      ...gradingResult.namedScores,
    },
    tokensUsed: existingGradingResult?.tokensUsed || gradingResult.tokensUsed,
    assertion: gradingResult.assertion,
  };

  result.success = nextPass;
  if (!comparisonPassed) {
    result.score = newScore;
  }
}

function ensureDefaultTestForExtensions(testSuite: TestSuite) {
  if (!testSuite.extensions?.length) {
    return;
  }
  if (!testSuite.defaultTest) {
    testSuite.defaultTest = {};
  }
  if (typeof testSuite.defaultTest !== 'string' && !testSuite.defaultTest.assert) {
    testSuite.defaultTest.assert = [];
  }
}

async function maybeAddGeneratedPrompts(testSuite: TestSuite, options: InternalEvaluateOptions) {
  if (!options.generateSuggestions) {
    return true;
  }

  // Library callers bypass CLI/config schema validation, so re-clamp here.
  const rawCount = options.suggestionsCount ?? 1;
  let requestedCount = Number.isInteger(rawCount) && rawCount >= 1 ? rawCount : 1;
  if (requestedCount > MAX_SUGGESTIONS_COUNT) {
    logger.warn(
      `suggestionsCount=${rawCount} exceeds max of ${MAX_SUGGESTIONS_COUNT}; clamping to ${MAX_SUGGESTIONS_COUNT}.`,
    );
    requestedCount = MAX_SUGGESTIONS_COUNT;
  }
  logger.info(`Generating prompt variations...`);
  const { prompts: newPrompts, error } = await generatePrompts(
    testSuite.prompts[0].raw,
    requestedCount,
  );
  if (error || !newPrompts) {
    throw new Error(`Failed to generate prompts: ${error}`);
  }
  if (newPrompts.length < requestedCount) {
    logger.warn(
      chalk.yellow(
        `Only ${newPrompts.length} of ${requestedCount} requested prompt variants were generated. See warnings above for details.`,
      ),
    );
  }

  logger.info(chalk.blue('Generated prompts:'));
  let numAdded = 0;
  for (const prompt of newPrompts) {
    logger.info('--------------------------------------------------------');
    logger.info(`${prompt}`);
    logger.info('--------------------------------------------------------');

    if (await promptYesNo('Do you want to test this prompt?', false)) {
      testSuite.prompts.push({ raw: prompt, label: prompt });
      numAdded++;
    } else {
      logger.info('Skipping this prompt.');
    }
  }

  if (numAdded > 0) {
    return true;
  }
  logger.info(chalk.red('No prompts selected. Aborting.'));
  if (isCliEventSource(options)) {
    process.exitCode = 1;
    return false;
  }
  throw new PromptSuggestionsRejectedError();
}

function createDefaultPromptMetrics(): PromptMetrics {
  return {
    score: 0,
    testPassCount: 0,
    testFailCount: 0,
    testErrorCount: 0,
    assertPassCount: 0,
    assertFailCount: 0,
    totalLatencyMs: 0,
    tokenUsage: createEmptyTokenUsage(),
    namedScores: {},
    namedScoresCount: {},
    namedScoreWeights: {},
    cost: 0,
  };
}

function buildExistingPromptsMap(store: EvaluationStore) {
  const existingPromptsMap = new Map<string, CompletedPrompt>();
  if (cliState.resume && store.persisted && store.prompts.length > 0) {
    logger.debug('Resuming evaluation: preserving metrics from previous run');
    for (const existingPrompt of store.prompts) {
      existingPromptsMap.set(`${existingPrompt.provider}:${existingPrompt.id}`, existingPrompt);
    }
  }
  return existingPromptsMap;
}

/**
 * The results-table columns owned by one provider, in table order. `promptIdx` is the
 * column's position in the table, which is how results are addressed everywhere else.
 */
type ProviderColumns = {
  provider: ApiProvider;
  columns: { promptIdx: number; prompt: Prompt }[];
};

/**
 * Builds the results-table columns, one per (provider, prompt) pair, and returns them
 * both flattened (for the table header) and grouped by provider (for scheduling work).
 *
 * Callers must derive a result's column from `columns` rather than looking one up by
 * `providerKey:promptId`, because neither component is unique: two providers can share
 * a label (or resolve to the same id), and two prompts can share a label, which is what
 * `generateIdFromPrompt` hashes. Resolving by identity collapses duplicates into a
 * single column and silently drops the other columns' results.
 */
function buildCompletedPrompts(
  testSuite: TestSuite,
  store: EvaluationStore,
): { prompts: CompletedPrompt[]; columnsByProvider: ProviderColumns[] } {
  const prompts: CompletedPrompt[] = [];
  const columnsByProvider: ProviderColumns[] = [];
  const existingPromptsMap = buildExistingPromptsMap(store);

  for (const provider of testSuite.providers) {
    const providerKey = getProviderIdentifier(provider);
    const columns: ProviderColumns['columns'] = [];

    for (const prompt of testSuite.prompts) {
      if (!isAllowedPrompt(prompt, testSuite.providerPromptMap?.[providerKey])) {
        continue;
      }

      const promptId = generateIdFromPrompt(prompt);
      const existingPrompt = existingPromptsMap.get(`${providerKey}:${promptId}`);
      if (existingPrompt?.metrics) {
        backfillNamedScoreWeights(existingPrompt.metrics);
      }

      columns.push({ promptIdx: prompts.length, prompt });
      prompts.push({
        ...prompt,
        id: promptId,
        provider: providerKey,
        label: prompt.label,
        // `existingPromptsMap` is still keyed by identity, so duplicate providers resolve
        // to the same stored prompt. Clone its metrics so the columns do not accumulate
        // into one shared object. (Resume has deeper duplicate-provider problems; see
        // `doEval`, which rebuilds `testSuite.prompts` from the previous run's columns.)
        metrics: existingPrompt?.metrics
          ? structuredClone(existingPrompt.metrics)
          : createDefaultPromptMetrics(),
      });
    }

    columnsByProvider.push({ provider, columns });
  }

  return { prompts, columnsByProvider };
}

function resolveAssertionProviderReferences(
  assertion: AssertionOrSet,
  providerMap: Record<string, ApiProvider>,
  env?: EnvOverrides,
): AssertionOrSet {
  if (assertion.type === 'assert-set') {
    const resolvedAssertions = assertion.assert.map(
      (child) => resolveAssertionProviderReferences(child, providerMap, env) as Assertion,
    );
    if (resolvedAssertions.every((child, index) => child === assertion.assert[index])) {
      return assertion;
    }
    return { ...assertion, assert: resolvedAssertions };
  }

  const provider = resolveConfiguredProviderReference(assertion.provider, providerMap, env);
  return provider === assertion.provider ? assertion : { ...assertion, provider };
}

function resolveRuntimeGradingProviderReferences(
  testCase: AtomicTestCase,
  providerMap: Record<string, ApiProvider>,
  env?: EnvOverrides,
): void {
  if (testCase.options?.provider) {
    const provider = resolveConfiguredProviderReference(
      testCase.options.provider,
      providerMap,
      env,
    );
    if (provider !== testCase.options.provider) {
      testCase.options = { ...testCase.options, provider };
    }
  }

  if (testCase.assert) {
    const assertions = testCase.assert.map((assertion) =>
      resolveAssertionProviderReferences(assertion, providerMap, env),
    );
    if (assertions.some((assertion, index) => assertion !== testCase.assert?.[index])) {
      testCase.assert = assertions;
    }
  }
}

function getDefaultTest(testSuite: TestSuite) {
  return typeof testSuite.defaultTest === 'object' ? testSuite.defaultTest : undefined;
}

function buildTestsFromSuite(testSuite: TestSuite): AtomicTestCase[] {
  const tests = getInitialTests(testSuite);
  if (!testSuite.scenarios?.length) {
    return tests;
  }

  telemetry.record('feature_used', { feature: 'scenarios' });
  let scenarioIndex = 0;
  for (const scenario of testSuite.scenarios) {
    for (const data of scenario.config) {
      tests.push(...buildScenarioTests(testSuite, scenario, data, scenarioIndex));
      scenarioIndex++;
    }
  }
  return tests;
}

function getInitialTests(testSuite: TestSuite): AtomicTestCase[] {
  if (testSuite.tests && testSuite.tests.length > 0) {
    return testSuite.tests as AtomicTestCase[];
  }
  return testSuite.scenarios ? [] : [{} as AtomicTestCase];
}

function buildScenarioTests(
  testSuite: TestSuite,
  scenario: NonNullable<TestSuite['scenarios']>[number],
  data: NonNullable<TestSuite['scenarios']>[number]['config'][number],
  scenarioIndex: number,
): AtomicTestCase[] {
  const scenarioTests = scenario.tests || [{}];
  return scenarioTests.map((test) => mergeScenarioTest(testSuite, data, test, scenarioIndex));
}

function mergeScenarioTest(
  testSuite: TestSuite,
  data: NonNullable<TestSuite['scenarios']>[number]['config'][number],
  test: NonNullable<TestSuite['scenarios']>[number]['tests'][number],
  scenarioIndex: number,
): AtomicTestCase {
  const defaultTest = getDefaultTest(testSuite);
  const mergedMetadata = {
    ...(defaultTest?.metadata || {}),
    ...data.metadata,
    ...test.metadata,
  };
  mergedMetadata.conversationId ??= `__scenario_${scenarioIndex}__`;

  return {
    ...(defaultTest || {}),
    ...data,
    ...test,
    vars: {
      ...(defaultTest?.vars || {}),
      ...data.vars,
      ...test.vars,
    },
    options: {
      ...(defaultTest?.options || {}),
      ...data.options,
      ...test.options,
    },
    assert: [...(data.assert || []), ...(test.assert || [])],
    metadata: mergedMetadata,
  } as AtomicTestCase;
}

async function prepareTestVariables(
  tests: AtomicTestCase[],
  testSuite: TestSuite,
): Promise<Set<string>> {
  const varNames = new Set<string>();
  const inputTransformDefault = getDefaultTest(testSuite)?.options?.transformVars;

  for (const testCase of tests) {
    testCase.vars = {
      ...(getDefaultTest(testSuite)?.vars || {}),
      ...testCase?.vars,
    };
    if (!testCase.vars) {
      continue;
    }

    await applyInputTransform(testCase, inputTransformDefault);
    for (const varName of Object.keys(testCase.vars)) {
      varNames.add(varName);
    }
  }

  return varNames;
}

async function applyInputTransform(
  testCase: AtomicTestCase,
  inputTransformDefault: NonNullable<AtomicTestCase['options']>['transformVars'] | undefined,
) {
  const inputTransform = testCase.options?.transformVars || inputTransformDefault;
  if (!inputTransform) {
    return;
  }

  const transformedVars = await transform(
    inputTransform,
    testCase.vars,
    {
      prompt: {},
      uuid: crypto.randomUUID(),
    },
    true,
    TransformInputType.VARS,
  );
  invariant(
    typeof transformedVars === 'object',
    'Transform function did not return a valid object',
  );
  testCase.vars = { ...testCase.vars, ...transformedVars };
}

async function buildRunEvalOptions({
  concurrency,
  conversations,
  evalId,
  options,
  columnsByProvider,
  providerAbortSignal,
  rateLimitRegistry,
  registers,
  testSuite,
  tests,
}: {
  concurrency: number;
  conversations: EvalConversations;
  evalId: string;
  options: InternalEvaluateOptions;
  columnsByProvider: ProviderColumns[];
  providerAbortSignal?: AbortSignal;
  rateLimitRegistry?: RateLimitRegistryRef;
  registers: EvalRegisters;
  testSuite: TestSuite;
  tests: AtomicTestCase[];
}): Promise<RunEvalOptions[]> {
  const runEvalOptions: RunEvalOptions[] = [];
  const configuredProviderMap = buildConfiguredProviderMap(testSuite.providers);

  let testIdx = 0;
  for (let index = 0; index < tests.length; index++) {
    const testCase = tests[index];
    await prepareTestCaseForEval(testSuite, testCase, index);
    resolveRuntimeGradingProviderReferences(testCase, configuredProviderMap, testSuite.env);
    testIdx = appendRunEvalOptionsForTestCase({
      concurrency,
      conversations,
      evalId,
      nextTestIdx: testIdx,
      options,
      columnsByProvider,
      providerAbortSignal,
      rateLimitRegistry,
      registers,
      runEvalOptions,
      testCase,
      testSuite,
    });
  }

  return runEvalOptions;
}

async function prepareTestCaseForEval(
  testSuite: TestSuite,
  testCase: AtomicTestCase,
  index: number,
) {
  const defaultTest = getDefaultTest(testSuite);
  invariant(
    !defaultTest || Array.isArray(defaultTest.assert || []),
    `defaultTest.assert is not an array in test case #${index + 1}`,
  );
  invariant(
    Array.isArray(testCase.assert || []),
    `testCase.assert is not an array in test case #${index + 1}`,
  );

  const disableDefaultAsserts = testCase.options?.disableDefaultAsserts === true;
  testCase.assert = [
    ...(disableDefaultAsserts ? [] : defaultTest?.assert || []),
    ...(testCase.assert || []),
  ];
  testCase.threshold = testCase.threshold ?? defaultTest?.threshold;
  testCase.options = {
    ...(defaultTest?.options || {}),
    ...testCase.options,
  };
  testCase.metadata = {
    ...(defaultTest?.metadata || {}),
    ...testCase.metadata,
  };
  testCase.prompts = testCase.prompts ?? defaultTest?.prompts;
  testCase.provider = await resolveDefaultTestProvider(defaultTest, testCase);
  testCase.assertScoringFunction =
    testCase.assertScoringFunction || defaultTest?.assertScoringFunction;
  testCase.providers = testCase.providers ?? defaultTest?.providers;

  if (typeof testCase.assertScoringFunction === 'string') {
    const { filePath: resolvedPath, functionName } = parseFileUrl(testCase.assertScoringFunction);
    testCase.assertScoringFunction = await loadFunction<ScoringFunction>({
      filePath: resolvedPath,
      functionName,
    });
  }
}

async function resolveDefaultTestProvider(
  defaultTest: ReturnType<typeof getDefaultTest>,
  testCase: AtomicTestCase,
) {
  if (testCase.provider || !defaultTest?.provider) {
    return testCase.provider;
  }

  const defaultProvider = defaultTest.provider;
  if (isApiProvider(defaultProvider)) {
    return defaultProvider;
  }
  if (typeof defaultProvider === 'object' && defaultProvider.id) {
    const { loadApiProvider } = await import('./providers');
    const providerId =
      typeof defaultProvider.id === 'function' ? defaultProvider.id() : defaultProvider.id;
    return loadApiProvider(providerId, {
      options: defaultProvider as ProviderOptions,
    });
  }
  return defaultProvider;
}

function appendRunEvalOptionsForTestCase({
  concurrency,
  conversations,
  evalId,
  nextTestIdx,
  options,
  columnsByProvider,
  providerAbortSignal,
  rateLimitRegistry,
  registers,
  runEvalOptions,
  testCase,
  testSuite,
}: {
  concurrency: number;
  conversations: EvalConversations;
  evalId: string;
  nextTestIdx: number;
  options: InternalEvaluateOptions;
  columnsByProvider: ProviderColumns[];
  providerAbortSignal?: AbortSignal;
  rateLimitRegistry?: RateLimitRegistryRef;
  registers: EvalRegisters;
  runEvalOptions: RunEvalOptions[];
  testCase: AtomicTestCase;
  testSuite: TestSuite;
}) {
  const promptPrefix = testCase.options?.prefix || getDefaultTest(testSuite)?.options?.prefix || '';
  const promptSuffix = testCase.options?.suffix || getDefaultTest(testSuite)?.options?.suffix || '';
  const varCombinations =
    getEnvBool('PROMPTFOO_DISABLE_VAR_EXPANSION') || testCase.options?.disableVarExpansion
      ? [testCase.vars]
      : generateVarCombinations(testCase.vars || {});

  const globalRepeat = normalizeRepeatCount(options.repeat);
  const testRepeat = normalizeRepeatCount(testCase.options?.repeat, globalRepeat);
  const effectiveOptions = {
    ...options,
    repeat: testRepeat,
  };
  for (let repeatIndex = 0; repeatIndex < testRepeat; repeatIndex++) {
    for (const vars of varCombinations) {
      appendRunEvalOptionsForVars({
        concurrency,
        conversations,
        evalId,
        options: effectiveOptions,
        columnsByProvider,
        promptPrefix,
        promptSuffix,
        providerAbortSignal,
        rateLimitRegistry,
        registers,
        repeatIndex,
        runEvalOptions,
        testCase,
        testIdx: nextTestIdx,
        testSuite,
        vars,
      });
      nextTestIdx++;
    }
  }

  return nextTestIdx;
}

function appendRunEvalOptionsForVars({
  concurrency,
  conversations,
  evalId,
  options,
  columnsByProvider,
  promptPrefix,
  promptSuffix,
  providerAbortSignal,
  rateLimitRegistry,
  registers,
  repeatIndex,
  runEvalOptions,
  testCase,
  testIdx,
  testSuite,
  vars,
}: {
  concurrency: number;
  conversations: EvalConversations;
  evalId: string;
  options: InternalEvaluateOptions;
  columnsByProvider: ProviderColumns[];
  promptPrefix: string;
  promptSuffix: string;
  providerAbortSignal?: AbortSignal;
  rateLimitRegistry?: RateLimitRegistryRef;
  registers: EvalRegisters;
  repeatIndex: number;
  runEvalOptions: RunEvalOptions[];
  testCase: AtomicTestCase;
  testIdx: number;
  testSuite: TestSuite;
  vars: Vars | undefined;
}) {
  for (const { provider, columns } of columnsByProvider) {
    if (!isProviderAllowed(provider, testCase.providers)) {
      continue;
    }
    appendRunEvalOptionsForProvider({
      columns,
      concurrency,
      conversations,
      evalId,
      options,
      promptPrefix,
      promptSuffix,
      provider,
      providerAbortSignal,
      rateLimitRegistry,
      registers,
      repeatIndex,
      runEvalOptions,
      testCase,
      testIdx,
      testSuite,
      vars,
    });
  }
}

function appendRunEvalOptionsForProvider({
  columns,
  concurrency,
  conversations,
  evalId,
  options,
  promptPrefix,
  promptSuffix,
  provider,
  providerAbortSignal,
  rateLimitRegistry,
  registers,
  repeatIndex,
  runEvalOptions,
  testCase,
  testIdx,
  testSuite,
  vars,
}: {
  columns: ProviderColumns['columns'];
  concurrency: number;
  conversations: EvalConversations;
  evalId: string;
  options: InternalEvaluateOptions;
  promptPrefix: string;
  promptSuffix: string;
  provider: ApiProvider;
  providerAbortSignal?: AbortSignal;
  rateLimitRegistry?: RateLimitRegistryRef;
  registers: EvalRegisters;
  repeatIndex: number;
  runEvalOptions: RunEvalOptions[];
  testCase: AtomicTestCase;
  testIdx: number;
  testSuite: TestSuite;
  vars: Vars | undefined;
}) {
  for (const { promptIdx, prompt } of columns) {
    if (!isAllowedPrompt(prompt, testCase.prompts)) {
      continue;
    }

    runEvalOptions.push(
      createRunEvalOption({
        concurrency,
        conversations,
        evalId,
        options,
        prompt,
        promptIdx,
        promptPrefix,
        promptSuffix,
        provider,
        providerAbortSignal,
        rateLimitRegistry,
        registers,
        repeatIndex,
        testCase,
        testIdx,
        testSuite,
        vars,
      }),
    );
  }
}

function createRunEvalOption({
  concurrency,
  conversations,
  evalId,
  options,
  prompt,
  promptIdx,
  promptPrefix,
  promptSuffix,
  provider,
  providerAbortSignal,
  rateLimitRegistry,
  registers,
  repeatIndex,
  testCase,
  testIdx,
  testSuite,
  vars,
}: {
  concurrency: number;
  conversations: EvalConversations;
  evalId: string;
  options: InternalEvaluateOptions;
  prompt: Prompt;
  promptIdx: number;
  promptPrefix: string;
  promptSuffix: string;
  provider: ApiProvider;
  providerAbortSignal?: AbortSignal;
  rateLimitRegistry?: RateLimitRegistryRef;
  registers: EvalRegisters;
  repeatIndex: number;
  testCase: AtomicTestCase;
  testIdx: number;
  testSuite: TestSuite;
  vars: Vars | undefined;
}): RunEvalOptions {
  return {
    delay: options.delay || 0,
    provider,
    prompt: {
      ...prompt,
      raw: promptPrefix + prompt.raw + promptSuffix,
      template: prompt.template ?? prompt.raw,
    },
    testSuite,
    test: createRunEvalTest(testSuite, testCase, vars, evalId),
    nunjucksFilters: testSuite.nunjucksFilters,
    testIdx,
    promptIdx,
    repeatIndex,
    evaluateOptions: options,
    conversations,
    registers,
    isRedteam: testSuite.redteam != null,
    concurrency,
    abortSignal: providerAbortSignal,
    evalId,
    rateLimitRegistry,
  };
}

function createRunEvalTest(
  testSuite: TestSuite,
  testCase: AtomicTestCase,
  vars: Vars | undefined,
  evalId: string,
): AtomicTestCase {
  const globalGraderExamples = testSuite.redteam?.graderExamples;
  const testOptions = globalGraderExamples
    ? { ...testCase.options, redteamGraderExamples: globalGraderExamples }
    : testCase.options;
  const baseTest = {
    ...testCase,
    vars,
    options: testOptions,
  };

  if (!isTracingEnabledForTest(testSuite, testCase)) {
    return baseTest;
  }
  return {
    ...baseTest,
    metadata: {
      ...testCase.metadata,
      tracingEnabled: true,
      evaluationId: evalId,
    },
  };
}

function isTracingEnabledForTest(testSuite: TestSuite, testCase: AtomicTestCase) {
  const tracingEnvEnabled = getEnvBool('PROMPTFOO_TRACING_ENABLED', false);
  const tracingEnabled =
    tracingEnvEnabled ||
    testCase.metadata?.tracingEnabled === true ||
    testSuite.tracing?.enabled === true;

  logger.debug(
    `[Evaluator] Tracing check: env=${tracingEnvEnabled}, testCase.metadata?.tracingEnabled=${testCase.metadata?.tracingEnabled}, testSuite.tracing?.enabled=${testSuite.tracing?.enabled}, tracingEnabled=${tracingEnabled}`,
  );

  return tracingEnabled;
}

function markComparisonRows(
  runEvalOptions: RunEvalOptions[],
  rowsWithSelectBestAssertion: Set<number>,
  rowsWithMaxScoreAssertion: Set<number>,
) {
  for (const evalOption of runEvalOptions) {
    if (evalOption.test.assert?.some((a) => a.type === 'select-best')) {
      rowsWithSelectBestAssertion.add(evalOption.testIdx);
    }
    if (evalOption.test.assert?.some((a) => a.type === 'max-score')) {
      rowsWithMaxScoreAssertion.add(evalOption.testIdx);
    }
  }
}

type RepeatCacheContext = Pick<RunEvalOptions, 'evaluateOptions' | 'repeatIndex'>;

function buildRepeatCacheContextByTestIdx(runEvalOptions: RunEvalOptions[]) {
  const repeatCacheContextByTestIdx = new Map<number, RepeatCacheContext>();
  for (const evalOption of runEvalOptions) {
    repeatCacheContextByTestIdx.set(evalOption.testIdx, {
      evaluateOptions: evalOption.evaluateOptions,
      repeatIndex: evalOption.repeatIndex,
    });
  }
  return repeatCacheContextByTestIdx;
}

async function filterCompletedResumeSteps(
  runEvalOptions: RunEvalOptions[],
  store: EvaluationStore,
) {
  if (!cliState.resume || !store.persisted) {
    return;
  }

  try {
    const completedPairs = await store.readCompletedIndexPairs({
      excludeErrors: cliState.retryMode,
    });
    const originalCount = runEvalOptions.length;
    for (let i = runEvalOptions.length - 1; i >= 0; i--) {
      const step = runEvalOptions[i];
      if (completedPairs.has(`${step.testIdx}:${step.promptIdx}`)) {
        runEvalOptions.splice(i, 1);
      }
    }
    const skipped = originalCount - runEvalOptions.length;
    if (skipped > 0) {
      logger.info(`Resuming: skipping ${skipped} previously completed cases`);
    }
  } catch (err) {
    logger.warn(
      `Resume: failed to load completed results. Running full evaluation. ${String(err)}`,
    );
  }
}

function adjustConcurrencyForSerialFeatures({
  concurrency,
  prompts,
  providers,
  tests,
}: {
  concurrency: number;
  prompts: CompletedPrompt[];
  providers: ApiProvider[];
  tests: AtomicTestCase[];
}) {
  const usesConversationVar = prompts.some(promptUsesConversationVariable);
  if (concurrency <= 1) {
    return { concurrency, usesConversationVar };
  }

  const usesStoreOutputAs = tests.some((t) => t.options?.storeOutputAs);
  const usesPersistentBrowserSession = providers.some(
    (provider) => provider.id() === 'browser-provider' && provider.config?.persistSession === true,
  );
  if (usesConversationVar) {
    logger.info(
      `Setting concurrency to 1 because the ${chalk.cyan(CONVERSATION_VAR_NAME)} variable is used.`,
    );
    return { concurrency: 1, usesConversationVar };
  }
  if (usesStoreOutputAs) {
    logger.info(`Setting concurrency to 1 because storeOutputAs is used.`);
    return { concurrency: 1, usesConversationVar };
  }
  if (usesPersistentBrowserSession) {
    logger.info(`Setting concurrency to 1 because browser persistSession is enabled.`);
    return { concurrency: 1, usesConversationVar };
  }
  return { concurrency, usesConversationVar };
}

interface ProcessEvalStepOptions {
  deferGrading?: boolean;
  onRowsReady?: () => void;
  precomputedRows?: EvaluateResult[];
  providerCallQueue?: ProviderCallQueue;
  shouldSkipStaleRows?: () => boolean;
}

interface GroupedRows {
  evalStep: RunEvalOptions;
  index: number;
  rows: EvaluateResult[];
}

interface EvalProcessingContext {
  assertionTypes: Set<string>;
  concurrency: number;
  numComplete: number;
  options: InternalEvaluateOptions;
  promptEvalCounts: number[];
  prompts: CompletedPrompt[];
  rowsWithMaxScoreAssertion: Set<number>;
  rowsWithSelectBestAssertion: Set<number>;
  runEvalOptionsLength: number;
  targetErrorAbortController: AbortController;
  targetErrorStatus?: number;
  targetUnavailable: boolean;
  testSuite: TestSuite;
  vars: Set<string>;
}

async function runGroupedGradingForRows(
  entries: GroupedRows[],
  providerCallQueue: ProviderGroupedCallQueue,
  onRowsGraded: (entry: GroupedRows) => Promise<void>,
) {
  const rowsWithDeferredGrading = getRowsWithDeferredGrading(entries);
  if (rowsWithDeferredGrading.length === 0) {
    return;
  }

  const deferredRows = new Set(rowsWithDeferredGrading.map(({ row }) => row));
  const completedRows = new Set<EvaluateResult>();
  const processedEntries = new Set<GroupedRows>();
  let pendingCount = rowsWithDeferredGrading.length;
  let resolveAllDone: () => void = () => {};
  const allDone = new Promise<void>((resolve) => {
    resolveAllDone = resolve;
  });

  const gradingPromises = rowsWithDeferredGrading.map(({ row, gradingPromise }) =>
    gradingPromise.finally(() => {
      deferredGradingPromises.delete(row);
      completedRows.add(row);
      pendingCount--;
      if (pendingCount === 0) {
        resolveAllDone();
      }
    }),
  );

  const processReadyEntries = async () => {
    for (const entry of entries) {
      if (processedEntries.has(entry)) {
        continue;
      }
      if (!entry.rows.every((row) => !deferredRows.has(row) || completedRows.has(row))) {
        break;
      }
      processedEntries.add(entry);
      await onRowsGraded(entry);
    }
  };

  let currentProviderId: string | undefined;
  while (pendingCount > 0 || providerCallQueue.hasJobs()) {
    if (!providerCallQueue.hasJobs()) {
      await Promise.race([providerCallQueue.waitForJob(), allDone]);
      await processReadyEntries();
    }

    const group = providerCallQueue.takeNextGroup(currentProviderId);
    if (group.length === 0) {
      continue;
    }

    currentProviderId = group[0].providerId;
    for (const job of group) {
      await providerCallQueue.run(job);
      await Promise.resolve();
      await processReadyEntries();
    }
  }

  await Promise.all(gradingPromises);
  await processReadyEntries();
}

function getRowsWithDeferredGrading(entries: GroupedRows[]) {
  return entries
    .flatMap((entry) => entry.rows.map((row) => ({ entry, row })))
    .map(({ entry, row }) => ({ entry, row, gradingPromise: deferredGradingPromises.get(row) }))
    .filter(
      (
        item,
      ): item is {
        entry: GroupedRows;
        row: EvaluateResult;
        gradingPromise: Promise<void>;
      } => item.gradingPromise !== undefined,
    );
}

function trackComparisonRowsForEvalStep(
  evalStep: RunEvalOptions,
  row: EvaluateResult,
  rowsWithSelectBestAssertion: Set<number>,
  rowsWithMaxScoreAssertion: Set<number>,
) {
  if (evalStep.test.assert?.some((a) => a.type === 'select-best')) {
    rowsWithSelectBestAssertion.add(row.testIdx);
  }
  if (evalStep.test.assert?.some((a) => a.type === 'max-score')) {
    rowsWithMaxScoreAssertion.add(row.testIdx);
  }
}

function createPromptEvalCounts(prompts: CompletedPrompt[]) {
  return prompts.map((prompt) => {
    const metrics = prompt.metrics;
    return metrics ? metrics.testPassCount + metrics.testFailCount + metrics.testErrorCount : 0;
  });
}

function reservePromptEvalCount(context: EvalProcessingContext, promptIdx: number) {
  context.promptEvalCounts[promptIdx] = (context.promptEvalCounts[promptIdx] ?? 0) + 1;
  return context.promptEvalCounts[promptIdx];
}

function createEvalStepTimeoutResult(
  evalStep: RunEvalOptions,
  sanitizedTestCase: AtomicTestCase,
  timeoutMs: number,
  error: unknown,
): EvaluateResult {
  return {
    provider: {
      id: evalStep.provider.id(),
      label: evalStep.provider.label,
      config: evalStep.provider.config,
    } as EvaluateResult['provider'],
    prompt: {
      raw: evalStep.prompt.raw,
      label: evalStep.prompt.label,
      config: evalStep.prompt.config,
    },
    vars: evalStep.test.vars || {},
    error: `Evaluation timed out after ${timeoutMs}ms: ${String(error)}`,
    success: false,
    failureReason: ResultFailureReason.ERROR,
    score: 0,
    namedScores: {},
    latencyMs: timeoutMs,
    promptIdx: evalStep.promptIdx,
    testIdx: evalStep.testIdx,
    testCase: sanitizedTestCase,
    promptId: evalStep.prompt.id || '',
  };
}

function createTimeoutMetrics(timeoutMs: number): PromptMetrics {
  return {
    score: 0,
    testPassCount: 0,
    testFailCount: 0,
    testErrorCount: 1,
    assertPassCount: 0,
    assertFailCount: 0,
    totalLatencyMs: timeoutMs,
    tokenUsage: {
      total: 0,
      prompt: 0,
      completion: 0,
      cached: 0,
      numRequests: 0,
    },
    namedScores: {},
    namedScoresCount: {},
    namedScoreWeights: {},
    cost: 0,
  };
}

function cleanupProgressAfterError(
  progressBarManager: ProgressBarManager | null,
  ciProgressReporter: CIProgressReporter | null,
  error: unknown,
) {
  progressBarManager?.removeLogInterceptor();
  progressBarManager?.stop();
  ciProgressReporter?.error(`Evaluation failed: ${String(error)}`);
}

function logWebUiEvalStepStart(
  isWebUI: boolean,
  processingContext: EvalProcessingContext,
  evalStep: RunEvalOptions,
) {
  if (!isWebUI) {
    return;
  }
  const provider = evalStep.provider.label || evalStep.provider.id();
  const vars = formatVarsForDisplay(evalStep.test.vars || {}, 50);
  logger.info(
    `[${processingContext.numComplete}/${processingContext.runEvalOptionsLength}] Running ${provider} with vars: ${vars}`,
  );
}

function cleanupProgressReporters(
  progressBarManager: ProgressBarManager | null,
  ciProgressReporter: CIProgressReporter | null,
) {
  try {
    if (progressBarManager) {
      progressBarManager.removeLogInterceptor();
      progressBarManager.complete();
      progressBarManager.stop();
    } else if (ciProgressReporter) {
      ciProgressReporter.finish();
    }
  } catch (cleanupErr) {
    logger.warn(`Error during progress reporter cleanup: ${cleanupErr}`);
  }
}

function createMaxDurationTimeoutResult(
  evalStep: RunEvalOptions,
  maxEvalTimeMs: number,
  startTime: number,
): EvaluateResult {
  return {
    provider: {
      id: evalStep.provider.id(),
      label: evalStep.provider.label,
      config: evalStep.provider.config,
    } as EvaluateResult['provider'],
    prompt: {
      raw: evalStep.prompt.raw,
      label: evalStep.prompt.label,
      config: evalStep.prompt.config,
    },
    vars: evalStep.test.vars || {},
    error: `Evaluation exceeded max duration of ${maxEvalTimeMs}ms`,
    success: false,
    failureReason: ResultFailureReason.ERROR,
    score: 0,
    namedScores: {},
    latencyMs: Date.now() - startTime,
    promptIdx: evalStep.promptIdx,
    testIdx: evalStep.testIdx,
    testCase: evalStep.test,
    promptId: evalStep.prompt.id || '',
  };
}

function getAssertionTelemetryStats(prompts: CompletedPrompt[], assertionTypes: Set<string>) {
  const totalAssertions = prompts.reduce(
    (acc, p) => acc + (p.metrics?.assertPassCount || 0) + (p.metrics?.assertFailCount || 0),
    0,
  );
  const passedAssertions = prompts.reduce((acc, p) => acc + (p.metrics?.assertPassCount || 0), 0);
  const modelGradedAssertions = Array.from(assertionTypes).filter((type) =>
    MODEL_GRADED_ASSERTION_TYPES.has(type as AssertionType),
  ).length;

  return {
    numAssertions: totalAssertions,
    passedAssertions,
    modelGradedAssertions,
    assertionPassRate: totalAssertions > 0 ? passedAssertions / totalAssertions : 0,
  };
}

function getAverageLatencyMs(results: EvaluationStoreResult[]) {
  const totalLatencyMs = results.reduce((sum, result) => sum + (result.latencyMs || 0), 0);
  return results.length > 0 ? totalLatencyMs / results.length : 0;
}

function getProviderPrefixes(testSuite: TestSuite) {
  return Array.from(
    new Set(
      testSuite.providers.map((p) => {
        const idParts = p.id().split(':');
        return idParts.length > 1 ? idParts[0] : 'unknown';
      }),
    ),
  );
}

function usesTransforms(testSuite: TestSuite, tests: AtomicTestCase[]) {
  return Boolean(
    tests.some((t) => t.options?.transform || t.options?.postprocess) ||
      testSuite.providers.some((p) => Boolean(p.transform)),
  );
}

function usesExampleProvider(testSuite: TestSuite) {
  return testSuite.providers.some((provider) => {
    const url = typeof provider.config?.url === 'string' ? provider.config.url : '';
    const label = provider.label || '';
    return url.includes('promptfoo.app') || label.toLowerCase().includes('example');
  });
}

class Evaluator<TEvaluation extends EvaluationRecord, TResult extends EvaluationStoreResult> {
  store: EvaluationStore<TEvaluation, TResult>;
  testSuite: TestSuite;
  options: InternalEvaluateOptions;
  stats: EvaluateStats;
  conversations: EvalConversations;
  registers: EvalRegisters;
  fileWriters: EvaluatorResultWriter[];
  rateLimitRegistry: RateLimitRegistry | undefined;
  constructor(
    testSuite: TestSuite,
    store: EvaluationStore<TEvaluation, TResult>,
    options: InternalEvaluateOptions,
    runtime: EvaluatorRuntime<TEvaluation, TResult>,
  ) {
    this.testSuite = testSuite;
    this.store = store;
    this.options = options;
    this.stats = {
      successes: 0,
      failures: 0,
      errors: 0,
      tokenUsage: createEmptyTokenUsage(),
    };
    this.conversations = {};
    this.registers = {};

    this.fileWriters = runtime.createResultWriters(store.config.outputPath, {
      append: Boolean(cliState.resume),
    });

    // Create rate limit registry for adaptive concurrency control
    this.rateLimitRegistry = createRateLimitRegistry({
      maxConcurrency: options.maxConcurrency || DEFAULT_MAX_CONCURRENCY,
    });

    // Add debug logging for rate limit events
    this.rateLimitRegistry.on('ratelimit:hit', (data) => {
      logger.debug(`[Scheduler] Rate limit hit for ${data.rateLimitKey}`, {
        retryAfterMs: data.retryAfterMs,
        resetAt: data.resetAt,
        concurrencyChange: data.concurrencyChange,
      });
    });
    this.rateLimitRegistry.on('ratelimit:learned', (data) => {
      logger.debug(`[Scheduler] Learned rate limits for ${data.rateLimitKey}`, {
        requestLimit: data.requestLimit,
        tokenLimit: data.tokenLimit,
      });
    });
    this.rateLimitRegistry.on('concurrency:decreased', (data) => {
      logger.debug(`[Scheduler] Concurrency decreased for ${data.rateLimitKey}`, {
        previous: data.previous,
        current: data.current,
      });
    });
    this.rateLimitRegistry.on('concurrency:increased', (data) => {
      logger.debug(`[Scheduler] Concurrency increased for ${data.rateLimitKey}`, {
        previous: data.previous,
        current: data.current,
      });
    });

    // Share rate limit registry with redteam provider manager
    // This ensures redteam internal providers also benefit from rate limiting
    redteamProviderManager.setRateLimitRegistry(this.rateLimitRegistry);
  }

  /**
   * Updates metrics and stats after a comparison assertion (select-best or max-score).
   */
  private updateComparisonStats(
    result: TResult,
    passed: boolean,
    reason: string,
    tokensUsed: TokenUsage | undefined,
    wasSuccess: boolean,
    wasScore: number,
    metrics: CompletedPrompt['metrics'] | undefined,
    gradingCached?: boolean,
  ): void {
    if (metrics) {
      metrics.assertPassCount += passed ? 1 : 0;
      metrics.assertFailCount += passed ? 0 : 1;
      if (tokensUsed) {
        updateAssertionMetrics(metrics, tokensUsed, { cached: gradingCached });
      }
      if (!passed && result.score !== wasScore) {
        metrics.score += result.score - wasScore;
      }
    }
    if (wasSuccess && !result.success) {
      result.failureReason = ResultFailureReason.ASSERT;
      result.error = reason;
      if (metrics) {
        metrics.testPassCount -= 1;
        metrics.testFailCount += 1;
      }
      this.stats.successes -= 1;
      this.stats.failures += 1;
    }
  }

  private trackRowStats(row: EvaluateResult): void {
    if (row.success) {
      this.stats.successes++;
    } else if (row.failureReason === ResultFailureReason.ERROR) {
      this.stats.errors++;
    } else {
      this.stats.failures++;
    }

    if (row.tokenUsage) {
      accumulateResponseTokenUsage(this.stats.tokenUsage, { tokenUsage: row.tokenUsage });
    }
  }

  // Buffer the authoritative copy of a row only once a DB persistence failure has been
  // observed. Before any failure, rows are recoverable from the streamed JSONL file and
  // the database during finalization; after a failure we can no longer trust the DB, so
  // we keep the in-memory copy of every subsequent row (timeout / deferred-grading rows
  // that never stream) to override stale entries in the recovery merge.
  private trackFinalJsonlResult(row: TResult | EvaluateResult): void {
    if (this.fileWriters.length > 0 && this.store.resultPersistenceFailed) {
      this.store.recordFinalResult(this.store.toEvaluateResult(row));
    }
  }

  private async persistEvalRow(row: EvaluateResult): Promise<void> {
    try {
      await this.store.appendResult(row);
    } catch (error) {
      this.store.recordResultPersistenceFailure(row);
      const resultSummary = summarizeEvaluateResultForLogging(row);
      logger.error('[Evaluator] Error saving result', {
        error,
        resultSummary,
      });
    }

    for (const writer of this.fileWriters) {
      await writer.write(sanitizeResultForJsonlArtifact(row));
    }
  }

  private async updatePromptMetricsForRow({
    derivedMetrics,
    evalStep,
    metrics,
    promptEvalCount,
    row,
  }: {
    derivedMetrics: TestSuite['derivedMetrics'];
    evalStep: RunEvalOptions;
    metrics: PromptMetrics;
    promptEvalCount: number;
    row: EvaluateResult;
  }): Promise<void> {
    metrics.score += row.score;
    for (const [key, value] of Object.entries(row.namedScores)) {
      accumulateNamedMetric(metrics, {
        metricName: key,
        metricValue: value,
        gradingResult: row.gradingResult,
        testVars: row.testCase?.vars || {},
      });
    }

    if (derivedMetrics) {
      await updateDerivedMetrics(metrics, derivedMetrics, evalStep, promptEvalCount);
    }

    updatePromptResultCounts(metrics, row);
    metrics.assertPassCount +=
      row.gradingResult?.componentResults?.filter((r) => r.pass).length || 0;
    metrics.assertFailCount +=
      row.gradingResult?.componentResults?.filter((r) => !r.pass).length || 0;
    metrics.totalLatencyMs += row.latencyMs || 0;
    accumulateResponseTokenUsage(metrics.tokenUsage, row.response, {
      countCachedAsRequest: (row.tokenUsage?.numRequests ?? 0) > 0,
    });

    if (row.gradingResult?.tokensUsed) {
      accumulateGradingTokenUsage(metrics.tokenUsage, row.gradingResult.tokensUsed, {
        cached: row.gradingResult.metadata?.cachedResponse,
      });
    }

    if (row.incurredCost !== undefined || metrics.incurredCost !== undefined) {
      metrics.incurredCost =
        (metrics.incurredCost ?? metrics.cost) + (row.incurredCost ?? row.cost ?? 0);
    }
    metrics.cost += row.cost || 0;
  }

  private async processEvalStep(
    evalStep: RunEvalOptions,
    index: number,
    {
      deferGrading = false,
      onRowsReady,
      precomputedRows,
      providerCallQueue,
      shouldSkipStaleRows,
    }: ProcessEvalStepOptions,
    context: EvalProcessingContext,
  ) {
    return await withCacheNamespace(
      getRepeatCacheNamespace(evalStep.repeatIndex, evalStep.evaluateOptions),
      async () => {
        const rows =
          precomputedRows ||
          (await this.runEvalStepAfterBeforeEach(evalStep, {
            deferGrading,
            onRowsReady,
            providerCallQueue,
            testSuite: context.testSuite,
          }));

        if (!deferGrading) {
          await this.processEvalRows(evalStep, index, rows, shouldSkipStaleRows, context);
        }
        return rows;
      },
    );
  }

  private async runEvalStepAfterBeforeEach(
    evalStep: RunEvalOptions,
    {
      deferGrading,
      onRowsReady,
      providerCallQueue,
      testSuite,
    }: {
      deferGrading: boolean;
      onRowsReady?: () => void;
      providerCallQueue?: ProviderCallQueue;
      testSuite: TestSuite;
    },
  ) {
    const beforeEachOut = await runExtensionHook(testSuite.extensions, 'beforeEach', {
      test: evalStep.test,
    });
    evalStep.test = beforeEachOut.test;

    const rows = await runEvalInternal({
      ...evalStep,
      deferGrading,
      providerCallQueue: deferGrading ? providerCallQueue : undefined,
    });
    onRowsReady?.();
    return rows;
  }

  private async processEvalRows(
    evalStep: RunEvalOptions,
    index: number,
    rows: EvaluateResult[],
    shouldSkipStaleRows: (() => boolean) | undefined,
    context: EvalProcessingContext,
  ) {
    for (const row of rows) {
      if (shouldSkipStaleRows?.()) {
        return;
      }

      // NOTE: trackCompletedRow runs before afterEach hooks intentionally. It only
      // reads success/failureReason/tokenUsage — not namedScores or metadata — so
      // the hook's mutations don't need to be applied first. If future changes add
      // namedScores tracking here, move afterEach above this call.
      this.trackCompletedRow(evalStep, row, context);
      context.numComplete++;
      const promptEvalCount = reservePromptEvalCount(context, row.promptIdx);

      // Apply afterEach hook mutations before persisting. Pass a shallow copy
      // so in-place mutations don't corrupt the row on hook failure.
      if (context.testSuite.extensions?.length) {
        try {
          const originalMetadata = row.metadata;
          const originalResponseMetadata = row.response?.metadata;
          const afterEachOut = await runExtensionHook(context.testSuite.extensions, 'afterEach', {
            test: evalStep.test,
            result: {
              ...row,
              namedScores: { ...row.namedScores },
              metadata: { ...row.metadata },
              response: row.response
                ? { ...row.response, metadata: { ...row.response.metadata } }
                : row.response,
            },
          });
          // runExtensionHook sanitizes namedScores via filterFiniteScores;
          // re-sanitize here to also catch in-place mutations that bypass the merge.
          row.namedScores = filterFiniteScores(afterEachOut.result.namedScores);
          // If a hook replaced response.metadata, a legacy top-level metadata.headers copied
          // from the old transport would otherwise persist as stale credentials. Re-sync it.
          row.metadata = synchronizeLegacyTransportHeaders(
            originalMetadata,
            originalResponseMetadata,
            afterEachOut.result.metadata,
            afterEachOut.result.response?.metadata,
          );
          if (row.response && afterEachOut.result.response) {
            row.response.metadata = afterEachOut.result.response.metadata;
          }
        } catch (error) {
          logger.error(
            `afterEach extension hook failed, persisting row without hook modifications`,
            { error },
          );
        }
      }

      await this.persistEvalRow(row);

      if (this.abortIfTargetUnavailable(row, context)) {
        break;
      }

      const metrics = context.prompts[row.promptIdx].metrics;
      invariant(metrics, 'Expected prompt.metrics to be set');
      await this.updatePromptMetricsForRow({
        derivedMetrics: context.testSuite.derivedMetrics,
        evalStep,
        metrics,
        promptEvalCount,
        row,
      });

      context.options.progressCallback?.(
        context.numComplete,
        context.runEvalOptionsLength,
        index,
        evalStep,
        metrics,
      );
    }
  }

  private trackCompletedRow(
    evalStep: RunEvalOptions,
    row: EvaluateResult,
    context: EvalProcessingContext,
  ) {
    for (const varName of Object.keys(row.vars)) {
      context.vars.add(varName);
    }
    this.trackRowStats(row);
    trackComparisonRowsForEvalStep(
      evalStep,
      row,
      context.rowsWithSelectBestAssertion,
      context.rowsWithMaxScoreAssertion,
    );
    for (const assert of evalStep.test.assert || []) {
      if (assert.type) {
        context.assertionTypes.add(assert.type);
      }
    }
  }

  private abortIfTargetUnavailable(row: EvaluateResult, context: EvalProcessingContext) {
    const httpStatus = getNonTransientTargetStatus(row);
    if (httpStatus === undefined) {
      return false;
    }

    context.targetUnavailable = true;
    context.targetErrorStatus = httpStatus;
    logger.error(
      `Target returned HTTP ${httpStatus}. Aborting scan - this error will not resolve on retry.`,
    );
    context.targetErrorAbortController.abort();
    return true;
  }

  private async processEvalStepWithTimeout(
    evalStep: RunEvalOptions,
    index: number,
    processOptions: Pick<ProcessEvalStepOptions, 'deferGrading' | 'providerCallQueue'>,
    context: EvalProcessingContext,
  ) {
    const { deferGrading = false, providerCallQueue } = processOptions;
    const timeoutMs = context.options.timeoutMs || getEvalTimeoutMs();

    if (timeoutMs <= 0) {
      return await this.processEvalStep(
        evalStep,
        index,
        { deferGrading, providerCallQueue },
        context,
      );
    }

    const abortController = new AbortController();
    const evalStepWithSignal = {
      ...evalStep,
      abortSignal: evalStep.abortSignal
        ? AbortSignal.any([evalStep.abortSignal, abortController.signal])
        : abortController.signal,
    };

    let timeoutId: NodeJS.Timeout | undefined;
    let didTimeout = false;
    const clearEvalStepTimeout = () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = undefined;
      }
    };

    try {
      return await Promise.race([
        this.processEvalStep(
          evalStepWithSignal,
          index,
          {
            deferGrading,
            onRowsReady: clearEvalStepTimeout,
            providerCallQueue,
            shouldSkipStaleRows: () => didTimeout,
          },
          context,
        ),
        new Promise<void>((_, reject) => {
          timeoutId = setTimeout(() => {
            didTimeout = true;
            abortController.abort();
            reject(new Error(`Evaluation timed out after ${timeoutMs}ms`));
          }, timeoutMs);
        }),
      ]);
    } catch (error) {
      if (!didTimeout) {
        throw error;
      }
      await this.addEvalStepTimeoutResult(evalStep, index, timeoutMs, error, context);
    } finally {
      clearEvalStepTimeout();
    }
  }

  private async addEvalStepTimeoutResult(
    evalStep: RunEvalOptions,
    index: number,
    timeoutMs: number,
    error: unknown,
    context: EvalProcessingContext,
  ) {
    const sanitizedTestCase = { ...evalStep.test };
    delete (sanitizedTestCase as Partial<AtomicTestCase>).provider;

    const timeoutResult = createEvalStepTimeoutResult(
      evalStep,
      sanitizedTestCase,
      timeoutMs,
      error,
    );
    this.trackFinalJsonlResult(timeoutResult);
    await this.store.appendResult(timeoutResult);
    this.stats.errors++;

    const { metrics } = context.prompts[evalStep.promptIdx];
    if (metrics) {
      metrics.testErrorCount += 1;
      metrics.totalLatencyMs += timeoutMs;
    }

    context.numComplete++;
    context.options.progressCallback?.(
      context.numComplete,
      context.runEvalOptionsLength,
      index,
      evalStep,
      metrics || createTimeoutMetrics(timeoutMs),
    );
  }

  private async executeEvalSteps({
    checkAbort,
    ciProgressReporter,
    combinedAbortSignal,
    concurrentRunEvalOptions,
    evalStepIndexMap,
    globalTimeout,
    groupedRunEvalOptions,
    isEvalTimedOut,
    isWebUI,
    maxEvalTimeMs,
    processingContext,
    processedIndices,
    progressBarManager,
    prompts,
    serialRunEvalOptions,
    shouldGroupGradingByProvider,
  }: {
    checkAbort: () => void;
    ciProgressReporter: CIProgressReporter | null;
    combinedAbortSignal: AbortSignal;
    concurrentRunEvalOptions: RunEvalOptions[];
    evalStepIndexMap: Map<RunEvalOptions, number>;
    globalTimeout?: NodeJS.Timeout;
    groupedRunEvalOptions: RunEvalOptions[];
    isEvalTimedOut: () => boolean;
    isWebUI: boolean;
    maxEvalTimeMs: number;
    processingContext: EvalProcessingContext;
    processedIndices: Set<number>;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    serialRunEvalOptions: RunEvalOptions[];
    shouldGroupGradingByProvider: boolean;
  }): Promise<TEvaluation | undefined> {
    try {
      if (shouldGroupGradingByProvider) {
        await this.runGroupedEvalSteps({
          checkAbort,
          evalStepIndexMap,
          groupedRunEvalOptions,
          isWebUI,
          processingContext,
          processedIndices,
          prompts,
        });
      } else {
        await this.runSerialEvalSteps({
          checkAbort,
          evalStepIndexMap,
          isWebUI,
          processingContext,
          processedIndices,
          prompts,
          serialRunEvalOptions,
        });
        await this.runConcurrentEvalSteps({
          checkAbort,
          concurrentRunEvalOptions,
          evalStepIndexMap,
          processingContext,
          processedIndices,
          prompts,
        });
      }
    } catch (err) {
      if (!combinedAbortSignal.aborted) {
        cleanupProgressAfterError(progressBarManager, ciProgressReporter, err);
        throw err;
      }

      if (isEvalTimedOut()) {
        logger.warn(`Evaluation stopped after reaching max duration (${maxEvalTimeMs}ms)`);
      } else if (!processingContext.targetUnavailable) {
        return this.saveInterruptedEval({
          ciProgressReporter,
          globalTimeout,
          processingContext,
          progressBarManager,
          prompts,
        });
      }
    }

    return this.saveTargetUnavailableEvalIfNeeded({
      ciProgressReporter,
      globalTimeout,
      processingContext,
      progressBarManager,
      prompts,
    });
  }

  private async runGroupedEvalSteps({
    checkAbort,
    evalStepIndexMap,
    groupedRunEvalOptions,
    isWebUI,
    processingContext,
    processedIndices,
    prompts,
  }: {
    checkAbort: () => void;
    evalStepIndexMap: Map<RunEvalOptions, number>;
    groupedRunEvalOptions: RunEvalOptions[];
    isWebUI: boolean;
    processingContext: EvalProcessingContext;
    processedIndices: Set<number>;
    prompts: CompletedPrompt[];
  }): Promise<void> {
    const providerCallQueue = new ProviderGroupedCallQueue();
    const groupedRows: GroupedRows[] = [];
    let lastPromptsFlush = 0;
    const flushPromptMetrics = async () => {
      const now = Date.now();
      if (now - lastPromptsFlush < PROMPTS_FLUSH_INTERVAL_MS) {
        return;
      }

      lastPromptsFlush = now;
      await this.store.appendPrompts(prompts);
    };
    const processGroupedRows = async ({ evalStep, index, rows }: GroupedRows) => {
      await this.processEvalStep(evalStep, index, { precomputedRows: rows }, processingContext);
      processedIndices.add(index);
      await flushPromptMetrics();
    };
    const flushGroupedRows = () =>
      runGroupedGradingForRows(groupedRows, providerCallQueue, processGroupedRows);

    try {
      for (const evalStep of groupedRunEvalOptions) {
        checkAbort();
        logWebUiEvalStepStart(isWebUI, processingContext, evalStep);
        const idx = evalStepIndexMap.get(evalStep)!;
        const shouldDeferEvalStepGrading = shouldDeferGradingForTest(evalStep.test);
        const rows =
          (await this.processEvalStepWithTimeout(
            evalStep,
            idx,
            {
              deferGrading: shouldDeferEvalStepGrading,
              providerCallQueue,
            },
            processingContext,
          )) || [];

        if (
          await this.handleGroupedRowsAfterRun({
            evalStep,
            groupedRows,
            idx,
            processGroupedRows,
            processedIndices,
            flushPromptMetrics,
            rows,
            shouldDeferEvalStepGrading,
            processingContext,
          })
        ) {
          break;
        }
      }
    } catch (error) {
      // Best-effort: flush any rows whose target calls completed but whose
      // deferred grading hadn't started/completed yet, so a mid-eval interrupt
      // doesn't lose the already-computed target outputs. Failures here must
      // not shadow the original error, so we log and rethrow the outer error.
      const pendingRowCount = groupedRows.reduce((sum, entry) => sum + entry.rows.length, 0);
      try {
        await flushGroupedRows();
      } catch (flushError) {
        logger.warn('Failed to flush grouped rows after error; target outputs may be lost', {
          error: flushError instanceof Error ? flushError.message : String(flushError),
          pendingRowCount,
        });
      }
      throw error;
    }

    await flushGroupedRows();
  }

  private async handleGroupedRowsAfterRun({
    evalStep,
    groupedRows,
    idx,
    processGroupedRows,
    processedIndices,
    flushPromptMetrics,
    rows,
    shouldDeferEvalStepGrading,
    processingContext,
  }: {
    evalStep: RunEvalOptions;
    groupedRows: GroupedRows[];
    idx: number;
    processGroupedRows: (entry: GroupedRows) => Promise<void>;
    processedIndices: Set<number>;
    flushPromptMetrics: () => Promise<void>;
    rows: EvaluateResult[];
    shouldDeferEvalStepGrading: boolean;
    processingContext: EvalProcessingContext;
  }) {
    if (!shouldDeferEvalStepGrading) {
      processedIndices.add(idx);
      await flushPromptMetrics();
      return processingContext.targetUnavailable;
    }
    if (rows.length === 0) {
      processedIndices.add(idx);
      return false;
    }
    if (rows.some((row) => deferredGradingPromises.has(row))) {
      groupedRows.push({ evalStep, index: idx, rows });
      return rows.some((row) => getNonTransientTargetStatus(row) !== undefined);
    }

    await processGroupedRows({ evalStep, index: idx, rows });
    return processingContext.targetUnavailable;
  }

  private async runSerialEvalSteps({
    checkAbort,
    evalStepIndexMap,
    isWebUI,
    processingContext,
    processedIndices,
    prompts,
    serialRunEvalOptions,
  }: {
    checkAbort: () => void;
    evalStepIndexMap: Map<RunEvalOptions, number>;
    isWebUI: boolean;
    processingContext: EvalProcessingContext;
    processedIndices: Set<number>;
    prompts: CompletedPrompt[];
    serialRunEvalOptions: RunEvalOptions[];
  }) {
    let lastPromptsFlush = 0;
    for (const evalStep of serialRunEvalOptions) {
      checkAbort();
      logWebUiEvalStepStart(isWebUI, processingContext, evalStep);
      const idx = evalStepIndexMap.get(evalStep)!;
      await this.processEvalStepWithTimeout(evalStep, idx, {}, processingContext);
      processedIndices.add(idx);
      const now = Date.now();
      if (now - lastPromptsFlush >= PROMPTS_FLUSH_INTERVAL_MS) {
        lastPromptsFlush = now;
        await this.store.appendPrompts(prompts);
      }
    }
  }

  private async runConcurrentEvalSteps({
    checkAbort,
    concurrentRunEvalOptions,
    evalStepIndexMap,
    processingContext,
    processedIndices,
    prompts,
  }: {
    checkAbort: () => void;
    concurrentRunEvalOptions: RunEvalOptions[];
    evalStepIndexMap: Map<RunEvalOptions, number>;
    processingContext: EvalProcessingContext;
    processedIndices: Set<number>;
    prompts: CompletedPrompt[];
  }) {
    let lastPromptsFlush = 0;
    await async.forEachOfLimit(
      concurrentRunEvalOptions,
      processingContext.concurrency,
      async (evalStep) => {
        checkAbort();
        const idx = evalStepIndexMap.get(evalStep)!;
        await this.processEvalStepWithTimeout(evalStep, idx, {}, processingContext);
        processedIndices.add(idx);
        const now = Date.now();
        if (now - lastPromptsFlush >= PROMPTS_FLUSH_INTERVAL_MS) {
          lastPromptsFlush = now;
          await this.store.appendPrompts(prompts);
        }
      },
    );
  }

  private async saveInterruptedEval({
    ciProgressReporter,
    globalTimeout,
    processingContext,
    progressBarManager,
    prompts,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    globalTimeout?: NodeJS.Timeout;
    processingContext: EvalProcessingContext;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
  }) {
    logger.info('Evaluation interrupted, saving progress...');
    if (globalTimeout) {
      clearTimeout(globalTimeout);
    }
    progressBarManager?.removeLogInterceptor();
    progressBarManager?.stop();
    ciProgressReporter?.finish();
    this.store.setVars(Array.from(processingContext.vars));
    await this.store.appendPrompts(prompts);
    return this.store.evaluation;
  }

  private async saveTargetUnavailableEvalIfNeeded({
    ciProgressReporter,
    globalTimeout,
    processingContext,
    progressBarManager,
    prompts,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    globalTimeout?: NodeJS.Timeout;
    processingContext: EvalProcessingContext;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
  }) {
    if (!processingContext.targetUnavailable) {
      return undefined;
    }
    if (globalTimeout) {
      clearTimeout(globalTimeout);
    }
    progressBarManager?.stop();
    ciProgressReporter?.error(`Target unavailable (HTTP ${processingContext.targetErrorStatus})`);
    this.store.setVars(Array.from(processingContext.vars));
    await this.store.appendPrompts(prompts);
    return this.store.evaluation;
  }

  private async processComparisonAssertions({
    ciProgressReporter,
    isWebUI,
    progressBarManager,
    prompts,
    providerAbortSignal,
    repeatCacheContextByTestIdx,
    rowsWithMaxScoreAssertion,
    rowsWithSelectBestAssertion,
    runEvalOptions,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    isWebUI: boolean;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    providerAbortSignal?: AbortSignal;
    repeatCacheContextByTestIdx: Map<number, RepeatCacheContext>;
    rowsWithMaxScoreAssertion: Set<number>;
    rowsWithSelectBestAssertion: Set<number>;
    runEvalOptions: RunEvalOptions[];
  }) {
    const compareRowsCount = rowsWithSelectBestAssertion.size + rowsWithMaxScoreAssertion.size;
    updateComparisonReporterTotals({
      ciProgressReporter,
      compareRowsCount,
      progressBarManager,
      runEvalOptions,
    });

    const compareCount = await this.processSelectBestAssertions({
      ciProgressReporter,
      compareRowsCount,
      isWebUI,
      progressBarManager,
      prompts,
      providerAbortSignal,
      repeatCacheContextByTestIdx,
      rowsWithSelectBestAssertion,
      runEvalOptions,
    });

    await this.processMaxScoreAssertions({
      ciProgressReporter,
      compareCount,
      isWebUI,
      progressBarManager,
      prompts,
      rowsWithMaxScoreAssertion,
      runEvalOptions,
    });
  }

  private async processSelectBestAssertions({
    ciProgressReporter,
    compareRowsCount,
    isWebUI,
    progressBarManager,
    prompts,
    providerAbortSignal,
    repeatCacheContextByTestIdx,
    rowsWithSelectBestAssertion,
    runEvalOptions,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    compareRowsCount: number;
    isWebUI: boolean;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    providerAbortSignal?: AbortSignal;
    repeatCacheContextByTestIdx: Map<number, RepeatCacheContext>;
    rowsWithSelectBestAssertion: Set<number>;
    runEvalOptions: RunEvalOptions[];
  }) {
    let compareCount = 0;
    for (const testIdx of rowsWithSelectBestAssertion) {
      compareCount++;
      await this.processSelectBestAssertionForTest({
        ciProgressReporter,
        compareCount,
        compareRowsCount,
        isWebUI,
        progressBarManager,
        prompts,
        providerAbortSignal,
        repeatCacheContextByTestIdx,
        runEvalOptions,
        testIdx,
      });
    }
    return compareCount;
  }

  private async processSelectBestAssertionForTest({
    ciProgressReporter,
    compareCount,
    compareRowsCount,
    isWebUI,
    progressBarManager,
    prompts,
    providerAbortSignal,
    repeatCacheContextByTestIdx,
    runEvalOptions,
    testIdx,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    compareCount: number;
    compareRowsCount: number;
    isWebUI: boolean;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    providerAbortSignal?: AbortSignal;
    repeatCacheContextByTestIdx: Map<number, RepeatCacheContext>;
    runEvalOptions: RunEvalOptions[];
    testIdx: number;
  }) {
    if (isWebUI) {
      logger.info(`Running model-graded comparison ${compareCount} of ${compareRowsCount}...`);
    }

    const resultsToCompare = await this.getResultsToCompare(testIdx);
    if (resultsToCompare.length === 0) {
      logger.warn(`Expected results to be found for test index ${testIdx}`);
      return;
    }

    const compareAssertion = resultsToCompare[0].testCase.assert?.find(
      (a) => a.type === 'select-best',
    ) as Assertion;
    if (!compareAssertion) {
      return;
    }

    const repeatCacheContext = repeatCacheContextByTestIdx.get(testIdx);
    const outputs = resultsToCompare.map((r) => r.response?.output || '');
    const gradingResults = await withCacheNamespace(
      repeatCacheContext
        ? getRepeatCacheNamespace(
            repeatCacheContext.repeatIndex,
            repeatCacheContext.evaluateOptions,
          )
        : undefined,
      () =>
        withProviderCallExecutionContext(
          { abortSignal: providerAbortSignal, rateLimitRegistry: this.rateLimitRegistry },
          () =>
            runCompareAssertion(
              resultsToCompare[0].testCase,
              compareAssertion,
              outputs,
              this.getComparisonCallApiContext(resultsToCompare[0], repeatCacheContext),
            ),
        ),
    );

    for (let index = 0; index < resultsToCompare.length; index++) {
      await this.applySelectBestGradingResult({
        gradingResult: gradingResults[index],
        metrics: prompts[resultsToCompare[index].promptIdx]?.metrics,
        result: resultsToCompare[index],
      });
    }

    updateComparisonReporterProgress({
      ciProgressReporter,
      compareCount,
      isWebUI,
      label: `Model-graded comparison #${compareCount} of ${compareRowsCount}`,
      progressBarManager,
      promptRaw: resultsToCompare[0].prompt.raw,
      runEvalOptions,
    });
  }

  private async processMaxScoreAssertions({
    ciProgressReporter,
    compareCount,
    isWebUI,
    progressBarManager,
    prompts,
    rowsWithMaxScoreAssertion,
    runEvalOptions,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    compareCount: number;
    isWebUI: boolean;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    rowsWithMaxScoreAssertion: Set<number>;
    runEvalOptions: RunEvalOptions[];
  }) {
    if (rowsWithMaxScoreAssertion.size > 0) {
      logger.info(`Processing ${rowsWithMaxScoreAssertion.size} max-score assertions...`);
    }

    let currentCompareCount = compareCount;
    for (const testIdx of rowsWithMaxScoreAssertion) {
      currentCompareCount++;
      await this.processMaxScoreAssertionForTest({
        ciProgressReporter,
        compareCount: currentCompareCount,
        isWebUI,
        progressBarManager,
        prompts,
        runEvalOptions,
        testIdx,
      });
    }
  }

  private async processMaxScoreAssertionForTest({
    ciProgressReporter,
    compareCount,
    isWebUI,
    progressBarManager,
    prompts,
    runEvalOptions,
    testIdx,
  }: {
    ciProgressReporter: CIProgressReporter | null;
    compareCount: number;
    isWebUI: boolean;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    runEvalOptions: RunEvalOptions[];
    testIdx: number;
  }) {
    const resultsToCompare = await this.getResultsToCompare(testIdx);
    if (resultsToCompare.length === 0) {
      logger.warn(`Expected results to be found for test index ${testIdx}`);
      return;
    }

    const maxScoreAssertion = resultsToCompare[0].testCase.assert?.find(
      (a) => a.type === 'max-score',
    ) as Assertion;
    if (!maxScoreAssertion) {
      return;
    }

    const outputs = resultsToCompare.map((r) => r.response?.output || '');
    const maxScoreGradingResults = await selectMaxScore(
      outputs,
      resultsToCompare,
      maxScoreAssertion,
    );

    updateComparisonReporterProgress({
      ciProgressReporter,
      compareCount,
      isWebUI,
      label: `Max-score assertion for test #${testIdx}`,
      progressBarManager,
      promptRaw: resultsToCompare[0].prompt.raw,
      runEvalOptions,
    });

    for (let index = 0; index < resultsToCompare.length; index++) {
      await this.applyMaxScoreGradingResult({
        gradingResult: {
          ...maxScoreGradingResults[index],
          assertion: maxScoreAssertion,
        },
        metrics: prompts[resultsToCompare[index].promptIdx]?.metrics,
        result: resultsToCompare[index],
      });
    }
  }

  private async getResultsToCompare(testIdx: number): Promise<TResult[]> {
    const base = this.store.persisted
      ? await this.store.readResultsByTestIdx(testIdx)
      : this.store.results.filter((r) => r.testIdx === testIdx);
    if (!this.store.resultPersistenceFailed) {
      return base;
    }
    // A row that failed to persist is absent from the database (and from `results`), so it
    // would otherwise be excluded from the comparison — skewing the winner for its siblings
    // and leaving the failed row with stale, pre-comparison grading. Merge it back in.
    const failed = await this.store.readFailedResultsByTestIdx(testIdx);
    if (failed.length === 0) {
      return base;
    }
    const seen = new Set(base.map(getResultIndexKey));
    return [...base, ...failed.filter((r) => !seen.has(getResultIndexKey(r)))].sort(
      (a, b) => a.promptIdx - b.promptIdx,
    );
  }

  private getComparisonCallApiContext(
    firstResult: TResult,
    repeatCacheContext?: RepeatCacheContext,
  ): CallApiContextParams {
    const providerId = firstResult.provider.id;
    const originalProvider = this.testSuite.providers.find((p) => p.id() === providerId);
    return {
      getCache,
      ...(originalProvider && { originalProvider }),
      prompt: firstResult.prompt,
      promptIdx: firstResult.promptIdx,
      repeatIndex: repeatCacheContext?.repeatIndex,
      testIdx: firstResult.testIdx,
      vars: firstResult.testCase.vars || {},
    };
  }

  // Shared tail for the comparison graders: record the pass/score transition, capture the
  // canonical row for JSONL finalization, and persist (unless this row already failed to
  // persist, in which case re-saving would just re-throw). `wasSuccess`/`wasScore` must be
  // captured by the caller before its merge mutates `result`.
  private async finalizeComparisonGrading({
    gradingResult,
    metrics,
    result,
    wasSuccess,
    wasScore,
  }: {
    gradingResult: GradingResult;
    metrics: CompletedPrompt['metrics'] | undefined;
    result: TResult;
    wasSuccess: boolean;
    wasScore: number;
  }) {
    this.updateComparisonStats(
      result,
      gradingResult.pass,
      gradingResult.reason || '',
      gradingResult.tokensUsed,
      wasSuccess,
      wasScore,
      metrics,
      gradingResult.metadata?.cachedResponse,
    );
    if (
      result.response?.cached &&
      result.response.tokenUsage &&
      (result.response.tokenUsage.numRequests ?? 0) === 0 &&
      gradingResult.tokensUsed
    ) {
      const comparisonUsage = createEmptyAssertions();
      accumulateGradingRequest(comparisonUsage, gradingResult.tokensUsed, {
        cached: gradingResult.metadata?.cachedResponse,
      });
      if ((comparisonUsage.numRequests ?? 0) > 0) {
        result.response.tokenUsage.numRequests = 1;
        const evaluatedResult = this.store.toEvaluateResult(result);
        if (evaluatedResult.tokenUsage) {
          evaluatedResult.tokenUsage.numRequests = Math.max(
            evaluatedResult.tokenUsage.numRequests ?? 0,
            1,
          );
        }
        this.stats.tokenUsage.numRequests = (this.stats.tokenUsage.numRequests ?? 0) + 1;
        if (metrics) {
          metrics.tokenUsage.numRequests = (metrics.tokenUsage.numRequests ?? 0) + 1;
        }
      }
    }
    this.trackFinalJsonlResult(result);
    if (this.store.persisted && !this.store.hasResultPersistenceFailure(result)) {
      await this.store.saveResult(result);
    }
  }

  private async applySelectBestGradingResult({
    gradingResult,
    metrics,
    result,
  }: {
    gradingResult: GradingResult;
    metrics: CompletedPrompt['metrics'] | undefined;
    result: TResult;
  }) {
    const wasSuccess = result.success;
    const wasScore = result.score;
    mergeSelectBestGradingResult(result, gradingResult, this.stats.tokenUsage);
    await this.finalizeComparisonGrading({ gradingResult, metrics, result, wasSuccess, wasScore });
  }

  private async applyMaxScoreGradingResult({
    gradingResult,
    metrics,
    result,
  }: {
    gradingResult: GradingResult;
    metrics: CompletedPrompt['metrics'] | undefined;
    result: TResult;
  }) {
    const wasSuccess = result.success;
    const wasScore = result.score;
    mergeMaxScoreGradingResult(result, gradingResult);
    await this.finalizeComparisonGrading({ gradingResult, metrics, result, wasSuccess, wasScore });
  }

  private async finalizeEvaluation({
    assertionTypes,
    ciProgressReporter,
    concurrency,
    evalTimedOut,
    globalTimeout,
    maxEvalTimeMs,
    options,
    processedIndices,
    progressBarManager,
    prompts,
    runEvalOptions,
    startTime,
    testSuite,
    tests,
    usesConversationVar,
    varNames,
    vars,
  }: {
    assertionTypes: Set<string>;
    ciProgressReporter: CIProgressReporter | null;
    concurrency: number;
    evalTimedOut: boolean;
    globalTimeout?: NodeJS.Timeout;
    maxEvalTimeMs: number;
    options: InternalEvaluateOptions;
    processedIndices: Set<number>;
    progressBarManager: ProgressBarManager | null;
    prompts: CompletedPrompt[];
    runEvalOptions: RunEvalOptions[];
    startTime: number;
    testSuite: TestSuite;
    tests: AtomicTestCase[];
    usesConversationVar: boolean;
    varNames: Set<string>;
    vars: Set<string>;
  }) {
    await this.store.appendPrompts(prompts);
    cleanupProgressReporters(progressBarManager, ciProgressReporter);

    if (globalTimeout) {
      clearTimeout(globalTimeout);
    }
    if (evalTimedOut) {
      await this.addMaxDurationTimeoutResults({
        maxEvalTimeMs,
        processedIndices,
        prompts,
        runEvalOptions,
        startTime,
      });
    }

    this.store.setVars(Array.from(vars));
    await this.runAfterAllExtensions(testSuite);
    this.recordEvalTelemetry({
      assertionTypes,
      concurrency,
      evalTimedOut,
      options,
      prompts,
      startTime,
      testSuite,
      tests,
      usesConversationVar,
      varNames,
    });

    if (this.store.persisted) {
      await this.store.save();
    }
  }

  private async addMaxDurationTimeoutResults({
    maxEvalTimeMs,
    processedIndices,
    prompts,
    runEvalOptions,
    startTime,
  }: {
    maxEvalTimeMs: number;
    processedIndices: Set<number>;
    prompts: CompletedPrompt[];
    runEvalOptions: RunEvalOptions[];
    startTime: number;
  }) {
    for (let i = 0; i < runEvalOptions.length; i++) {
      if (processedIndices.has(i)) {
        continue;
      }
      const evalStep = runEvalOptions[i];
      const timeoutResult = createMaxDurationTimeoutResult(evalStep, maxEvalTimeMs, startTime);
      this.trackFinalJsonlResult(timeoutResult);
      await this.store.appendResult(timeoutResult);
      this.stats.errors++;
      const { metrics } = prompts[evalStep.promptIdx];
      if (metrics) {
        metrics.testErrorCount += 1;
        metrics.totalLatencyMs += timeoutResult.latencyMs;
      }
    }
  }

  private async runAfterAllExtensions(testSuite: TestSuite) {
    if (!testSuite.extensions?.length) {
      return;
    }

    const allResults = await this.store.readResults();
    const resultsForExtension = allResults.map((result) => this.store.toEvaluateResult(result));

    await runExtensionHook(testSuite.extensions, 'afterAll', {
      prompts: this.store.prompts,
      results: resultsForExtension,
      suite: testSuite,
      evalId: this.store.id,
      config: this.store.config,
    });
  }

  private recordEvalTelemetry({
    assertionTypes,
    concurrency,
    evalTimedOut,
    options,
    prompts,
    startTime,
    testSuite,
    tests,
    usesConversationVar,
    varNames,
  }: {
    assertionTypes: Set<string>;
    concurrency: number;
    evalTimedOut: boolean;
    options: InternalEvaluateOptions;
    prompts: CompletedPrompt[];
    startTime: number;
    testSuite: TestSuite;
    tests: AtomicTestCase[];
    usesConversationVar: boolean;
    varNames: Set<string>;
  }) {
    const totalEvalTimeMs = Date.now() - startTime;
    this.store.setDurationMs(totalEvalTimeMs);

    const assertionStats = getAssertionTelemetryStats(prompts, assertionTypes);
    const avgLatencyMs = getAverageLatencyMs(this.store.results);
    const timeoutOccurred =
      evalTimedOut ||
      this.store.results.some(
        (r) => r.failureReason === ResultFailureReason.ERROR && r.error?.includes('timed out'),
      );

    telemetry.record('eval_ran', {
      numPrompts: prompts.length,
      numTests: this.stats.successes + this.stats.failures + this.stats.errors,
      numRequests: this.stats.tokenUsage.numRequests || 0,
      numResults: this.store.results.length,
      numVars: varNames.size,
      numProviders: testSuite.providers.length,
      numRepeat: options.repeat || 1,
      providerPrefixes: getProviderPrefixes(testSuite).sort(),
      assertionTypes: Array.from(assertionTypes).sort(),
      eventSource: options.eventSource || 'default',
      ci: isCI(),
      hasAnyPass: this.stats.successes > 0,
      numPasses: this.stats.successes,
      numFails: this.stats.failures,
      numErrors: this.stats.errors,
      totalEvalTimeMs,
      avgLatencyMs: Math.round(avgLatencyMs),
      concurrencyUsed: concurrency,
      timeoutOccurred,
      totalTokens: this.stats.tokenUsage.total,
      promptTokens: this.stats.tokenUsage.prompt,
      completionTokens: this.stats.tokenUsage.completion,
      cachedTokens: this.stats.tokenUsage.cached,
      totalCost: prompts.reduce((acc, p) => acc + (p.metrics?.cost || 0), 0),
      totalRequests: this.stats.tokenUsage.numRequests,
      ...assertionStats,
      usesConversationVar,
      usesTransforms: usesTransforms(testSuite, tests),
      usesScenarios: Boolean(testSuite.scenarios?.length),
      usesExampleProvider: usesExampleProvider(testSuite),
      isPromptfooSampleTarget: testSuite.providers.some(isPromptfooSampleTarget),
      isRedteam: Boolean(options.isRedteam),
      hasOpenAiProviders: testSuite.providers.some((p) => isOpenAiProvider(p.id())),
      hasAnthropicProviders: testSuite.providers.some((p) => isAnthropicProvider(p.id())),
      hasGoogleProviders: testSuite.providers.some((p) => isGoogleProvider(p.id())),
    });
  }

  private async _runEvaluation(): Promise<TEvaluation> {
    const { options } = this;
    let { testSuite } = this;

    const startTime = Date.now();
    const maxEvalTimeMs = options.maxEvalTimeMs ?? getMaxEvalTimeMs();
    let evalTimedOut = false;
    let globalTimeout: NodeJS.Timeout | undefined;
    let globalAbortController: AbortController | undefined;
    const processedIndices = new Set<number>();

    const targetErrorAbortController = new AbortController();

    // Progress reporters declared here for cleanup in finally block
    let ciProgressReporter: CIProgressReporter | null = null;
    let progressBarManager: ProgressBarManager | null = null;

    // Create abort signals:
    // - providerAbortSignal: passed to providers (user signal + timeout, but NOT target error)
    // - combinedAbortSignal: used internally for checkAbort (includes target error signal)
    // Target error signal is not passed to providers because by the time we detect a 403 etc,
    // the provider call has already completed - it's only used to stop the evaluator loop.
    let providerAbortSignal: AbortSignal | undefined = options.abortSignal;
    let combinedAbortSignal: AbortSignal = options.abortSignal
      ? AbortSignal.any([options.abortSignal, targetErrorAbortController.signal])
      : targetErrorAbortController.signal;

    if (maxEvalTimeMs > 0) {
      globalAbortController = new AbortController();
      // Providers need timeout signal to cancel long-running requests
      providerAbortSignal = providerAbortSignal
        ? AbortSignal.any([providerAbortSignal, globalAbortController.signal])
        : globalAbortController.signal;
      // Internal signal includes all abort sources
      combinedAbortSignal = AbortSignal.any([combinedAbortSignal, globalAbortController.signal]);
      globalTimeout = setTimeout(() => {
        evalTimedOut = true;
        globalAbortController?.abort();
      }, maxEvalTimeMs);
    }

    const vars = new Set<string>();
    const checkAbort = () => {
      if (combinedAbortSignal.aborted) {
        throw new Error('Operation cancelled');
      }
    };

    if (!options.silent) {
      logger.info(`Starting evaluation ${this.store.id}`);
    }

    // Add abort checks at key points
    checkAbort();

    const assertionTypes = new Set<string>();
    const rowsWithSelectBestAssertion = new Set<number>();
    const rowsWithMaxScoreAssertion = new Set<number>();

    ensureDefaultTestForExtensions(testSuite);
    const beforeAllOut = await runExtensionHook(testSuite.extensions, 'beforeAll', {
      suite: testSuite,
    });
    testSuite = beforeAllOut.suite;

    if (!(await maybeAddGeneratedPrompts(testSuite, options))) {
      return this.store.evaluation;
    }

    const { prompts, columnsByProvider } = buildCompletedPrompts(testSuite, this.store);

    await this.store.appendPrompts(prompts);

    let tests = buildTestsFromSuite(testSuite);
    tests = filterByRange(tests, options.filterRange, warnEmptyFilterRange);
    maybeEmitAzureOpenAiWarning(testSuite, tests);

    const varNames = await prepareTestVariables(tests, testSuite);
    // Preserve configured/transformed variable order before concurrent rows finish.
    // Result-only variables discovered at runtime are appended as they appear.
    for (const varName of varNames) {
      vars.add(varName);
    }
    let concurrency = options.maxConcurrency || DEFAULT_MAX_CONCURRENCY;
    const runEvalOptions = await buildRunEvalOptions({
      concurrency,
      conversations: this.conversations,
      evalId: this.store.id,
      options,
      columnsByProvider,
      providerAbortSignal,
      rateLimitRegistry: this.rateLimitRegistry,
      registers: this.registers,
      testSuite,
      tests,
    });
    markComparisonRows(runEvalOptions, rowsWithSelectBestAssertion, rowsWithMaxScoreAssertion);
    const repeatCacheContextByTestIdx = buildRepeatCacheContextByTestIdx(runEvalOptions);
    await filterCompletedResumeSteps(runEvalOptions, this.store);

    const concurrencySettings = adjustConcurrencyForSerialFeatures({
      concurrency,
      prompts,
      providers: runEvalOptions.map((evalOption) => evalOption.provider),
      tests,
    });
    concurrency = concurrencySettings.concurrency;
    const { usesConversationVar } = concurrencySettings;

    const processingContext: EvalProcessingContext = {
      assertionTypes,
      concurrency,
      numComplete: 0,
      options,
      promptEvalCounts: createPromptEvalCounts(prompts),
      prompts,
      rowsWithMaxScoreAssertion,
      rowsWithSelectBestAssertion,
      runEvalOptionsLength: runEvalOptions.length,
      targetErrorAbortController,
      targetErrorStatus: undefined,
      targetUnavailable: false,
      testSuite,
      vars,
    };

    // Set up progress tracking
    const originalProgressCallback = this.options.progressCallback;
    const isWebUI = Boolean(cliState.webUI);

    // Choose appropriate progress reporter
    logger.debug(
      `Progress bar settings: showProgressBar=${this.options.showProgressBar}, isWebUI=${isWebUI}`,
    );

    if (isCI() && !isWebUI) {
      // Use CI-friendly progress reporter
      ciProgressReporter = new CIProgressReporter(runEvalOptions.length);
      ciProgressReporter.start();
    } else if (this.options.showProgressBar && process.stderr.isTTY) {
      // Use visual progress bars
      progressBarManager = new ProgressBarManager(isWebUI);
    }

    this.options.progressCallback = (completed, total, index, evalStep, metrics) => {
      if (originalProgressCallback) {
        originalProgressCallback(completed, total, index, evalStep, metrics);
      }

      if (isWebUI) {
        const provider = evalStep.provider.label || evalStep.provider.id();
        const vars = formatVarsForDisplay(evalStep.test.vars, 50);
        logger.info(
          `[${processingContext.numComplete}/${total}] Running ${provider} with vars: ${vars}`,
        );
      } else if (progressBarManager) {
        // Progress bar update is handled by the manager
        const phase = evalStep.test.options?.runSerially ? 'serial' : 'concurrent';
        progressBarManager.updateProgress(index, evalStep, phase, metrics);
      } else if (ciProgressReporter) {
        // CI progress reporter update
        ciProgressReporter.update(processingContext.numComplete);
      } else {
        logger.debug(
          `Eval #${index + 1} complete (${processingContext.numComplete} of ${runEvalOptions.length})`,
        );
      }
    };

    // Separate serial and concurrent eval options
    const serialRunEvalOptions: RunEvalOptions[] = [];
    const concurrentRunEvalOptions: RunEvalOptions[] = [];
    // O(1) lookup for the original index of each eval step (avoids O(n) indexOf in hot loop)
    const evalStepIndexMap = new Map<RunEvalOptions, number>();

    for (let i = 0; i < runEvalOptions.length; i++) {
      const evalOption = runEvalOptions[i];
      evalStepIndexMap.set(evalOption, i);
      if (evalOption.test.options?.runSerially) {
        serialRunEvalOptions.push(evalOption);
      } else {
        concurrentRunEvalOptions.push(evalOption);
      }
    }
    const hasEvalStepTimeout = (options.timeoutMs || getEvalTimeoutMs()) > 0;
    const shouldGroupGradingByProvider =
      concurrency === 1 && !hasEvalStepTimeout && !usesConversationVar;

    // Print info messages before starting progress bar
    if (!this.options.silent) {
      if (serialRunEvalOptions.length > 0) {
        logger.info(`Running ${serialRunEvalOptions.length} test cases serially...`);
      }
      if (concurrentRunEvalOptions.length > 0) {
        logger.info(
          `Running ${concurrentRunEvalOptions.length} test cases (up to ${concurrency} at a time)...`,
        );
      }

      logGroupedGradingStatus({
        concurrency,
        hasEvalStepTimeout,
        runEvalOptions,
        shouldGroupGradingByProvider,
        usesConversationVar,
      });
    }

    // Now start the progress bar after info messages
    if (this.options.showProgressBar && progressBarManager) {
      await progressBarManager.initialize(runEvalOptions, concurrency, 0);
      progressBarManager.installLogInterceptor();
    }

    const interruptedEval = await this.executeEvalSteps({
      checkAbort,
      ciProgressReporter,
      combinedAbortSignal,
      concurrentRunEvalOptions,
      evalStepIndexMap,
      globalTimeout,
      groupedRunEvalOptions: [...serialRunEvalOptions, ...concurrentRunEvalOptions],
      isEvalTimedOut: () => evalTimedOut,
      isWebUI,
      maxEvalTimeMs,
      processingContext,
      processedIndices,
      progressBarManager,
      prompts,
      serialRunEvalOptions,
      shouldGroupGradingByProvider,
    });
    if (interruptedEval) {
      return interruptedEval;
    }

    await this.processComparisonAssertions({
      ciProgressReporter,
      isWebUI,
      progressBarManager,
      prompts,
      providerAbortSignal,
      repeatCacheContextByTestIdx,
      rowsWithMaxScoreAssertion,
      rowsWithSelectBestAssertion,
      runEvalOptions,
    });

    await this.finalizeEvaluation({
      assertionTypes,
      ciProgressReporter,
      concurrency,
      evalTimedOut,
      globalTimeout,
      maxEvalTimeMs,
      options,
      processedIndices,
      progressBarManager,
      prompts,
      runEvalOptions,
      startTime,
      testSuite,
      tests,
      usesConversationVar,
      varNames,
      vars,
    });
    return this.store.evaluation;
  }

  async evaluate(): Promise<TEvaluation> {
    // Initialize OTEL SDK if tracing is enabled
    // Check env flag, test suite level, and default test metadata
    const tracingEnabled =
      getEnvBool('PROMPTFOO_TRACING_ENABLED', false) ||
      this.testSuite.tracing?.enabled === true ||
      (typeof this.testSuite.defaultTest === 'object' &&
        this.testSuite.defaultTest?.metadata?.tracingEnabled === true) ||
      this.testSuite.tests?.some((t) => t.metadata?.tracingEnabled === true);
    let otelInitialized = false;
    let otlpReceiverAcquired = false;

    let evaluationError: unknown;
    try {
      otlpReceiverAcquired = await startOtlpReceiverIfNeeded(this.testSuite, this.store.id);
      if (tracingEnabled) {
        logger.debug('[Evaluator] Initializing OTEL SDK for tracing');
        const otelConfig = getDefaultOtelConfig();
        initializeOtel(otelConfig);
        otelInitialized = true;
      }

      return await this._runEvaluation();
    } catch (error) {
      evaluationError = error;
      throw error;
    } finally {
      // Close the JSONL writers first, before the (possibly multi-second) OTEL / provider
      // teardown below, so the streamed file is fully flushed before the post-run rewrite
      // reads it back and the file handle is released promptly. allSettled so one writer's
      // close failure neither blocks cleanup nor masks another writer's error.
      const writerCloseResults = await Promise.allSettled(
        this.fileWriters.map((writer) => writer.close()),
      );
      const writerCloseErrors = writerCloseResults.flatMap((result) =>
        result.status === 'rejected' ? [result.reason] : [],
      );

      let cleanupError: unknown;
      try {
        // Flush and shutdown OTEL SDK
        if (otelInitialized) {
          logger.debug('[Evaluator] Flushing OTEL spans...');
          await flushOtel();
          await shutdownOtel();
        }

        if (otlpReceiverAcquired && isOtlpReceiverStarted()) {
          // Add a delay to allow providers to finish exporting spans
          logger.debug('[Evaluator] Waiting for span exports to complete...');
          await sleep(3000);
        }
        await stopOtlpReceiverIfNeeded(otlpReceiverAcquired, this.store.id);

        // Clean up Python worker pools to prevent resource leaks
        await providerRegistry.shutdownAll();

        // Log rate limit metrics for debugging before cleanup
        if (this.rateLimitRegistry) {
          const metrics = this.rateLimitRegistry.getMetrics();
          for (const [key, m] of Object.entries(metrics)) {
            if (m.totalRequests > 0) {
              logger.debug(`[Scheduler] Final metrics for ${sanitizeProviderIdForLog(key)}`, {
                totalRequests: m.totalRequests,
                completedRequests: m.completedRequests,
                failedRequests: m.failedRequests,
                rateLimitHits: m.rateLimitHits,
                retriedRequests: m.retriedRequests,
                avgLatencyMs: Math.round(m.avgLatencyMs),
                p50LatencyMs: Math.round(m.p50LatencyMs),
                p99LatencyMs: Math.round(m.p99LatencyMs),
              });
            }
          }
        }

        // Clean up rate limit registry resources
        this.rateLimitRegistry?.dispose();

        // Clear registry from redteam provider manager
        redteamProviderManager.setRateLimitRegistry(undefined);

        // Reset cliState.maxConcurrency to prevent stale state between evaluations
        cliState.maxConcurrency = undefined;
      } catch (error) {
        cleanupError = error;
        throw error;
      } finally {
        if (writerCloseErrors.length > 0) {
          logger.error('[Evaluator] Error closing JSONL output', { errors: writerCloseErrors });
          // Only surface a writer-close failure when nothing else failed, so the original
          // evaluation/cleanup error is never masked by a secondary I/O error.
          if (evaluationError === undefined && cleanupError === undefined) {
            // When results persisted to the database, that copy is authoritative and the
            // post-run rewrite (writeMultipleOutputs) regenerates the JSONL artifact from
            // it, so a close error (e.g. a delayed fd-close writeback failure) is recoverable
            // — log it rather than failing an otherwise-successful run. Only when persistence
            // failed is the streamed JSONL the sole copy whose truncation must be surfaced.
            if (this.store.resultPersistenceFailed) {
              throw writerCloseErrors.length === 1
                ? writerCloseErrors[0]
                : new AggregateError(
                    writerCloseErrors,
                    'Multiple JSONL output writers failed to close',
                  );
            }
            logger.warn(
              `JSONL output writer reported a close error after results persisted; the output file will be regenerated from the database. ${writerCloseErrors.map((error) => (error instanceof Error ? error.message : String(error))).join('; ')}`,
            );
          }
        }
      }
    }
  }
}

type DefaultEvaluation = Parameters<typeof nodeEvaluatorRuntime.createEvaluationStore>[0];

export function evaluate<TEvaluation extends DefaultEvaluation>(
  testSuite: TestSuite,
  evalRecord: TEvaluation,
  options: InternalEvaluateOptions,
): Promise<TEvaluation>;
export function evaluate<
  TEvaluation extends EvaluationRecord,
  TResult extends EvaluationStoreResult = EvaluationStoreResult,
>(
  testSuite: TestSuite,
  evalRecord: TEvaluation,
  options: InternalEvaluateOptions,
  runtime: EvaluatorRuntime<TEvaluation, TResult>,
): Promise<TEvaluation>;
export function evaluate<
  TEvaluation extends EvaluationRecord,
  TResult extends EvaluationStoreResult = EvaluationStoreResult,
>(
  testSuite: TestSuite,
  evalRecord: TEvaluation,
  options: InternalEvaluateOptions,
  runtime?: EvaluatorRuntime<TEvaluation, TResult>,
): Promise<TEvaluation> {
  const resolvedRuntime =
    runtime ?? (nodeEvaluatorRuntime as unknown as EvaluatorRuntime<TEvaluation, TResult>);
  const runtimeTestSuite =
    resolvedRuntime.resolveRuntimeTestSuite?.(testSuite) ??
    nodeEvaluatorRuntime.resolveRuntimeTestSuite?.(testSuite) ??
    testSuite;
  const store = resolvedRuntime.createEvaluationStore(evalRecord);
  const ev = new Evaluator(runtimeTestSuite, store, options, resolvedRuntime);
  return ev.evaluate();
}
