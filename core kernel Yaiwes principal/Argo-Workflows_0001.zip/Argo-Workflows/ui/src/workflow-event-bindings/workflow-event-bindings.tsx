import {Page} from 'argo-ui/src/components/page/page';
import {SlidingPanel} from 'argo-ui/src/components/sliding-panel/sliding-panel';
import * as React from 'react';
import {useContext, useEffect, useRef, useState} from 'react';
import {RouteComponentProps} from 'react-router-dom';

import {absoluteUrl, uiUrl} from '../shared/base';
import {ErrorNotice} from '../shared/components/error-notice';
import {InfoIcon} from '../shared/components/fa-icons';
import {GraphPanel} from '../shared/components/graph/graph-panel';
import {Graph} from '../shared/components/graph/types';
import {Loading} from '../shared/components/loading';
import {NamespaceFilter} from '../shared/components/namespace-filter';
import {SerializingObjectEditor} from '../shared/components/object-editor';
import {ZeroState} from '../shared/components/zero-state';
import {Context} from '../shared/context';
import {Footnote} from '../shared/footnote';
import {historyUrl} from '../shared/history';
import {WorkflowEventBinding} from '../shared/models';
import * as nsUtils from '../shared/namespaces';
import {services} from '../shared/services';
import {useCollectEvent} from '../shared/use-collect-event';
import {useQueryParams} from '../shared/use-query-params';
import {ID} from './id';

const introductionText = (
    <>
        Workflow event bindings allow you to trigger workflows when a webhook event is received. For example, start a build on a Git commit, or start a machine learning pipeline
        from a remote system.
    </>
);
const learnMore = (
    <a href={'https://argo-workflows.readthedocs.io/en/latest/events/'} target='_blank' rel='noreferrer'>
        Learn more
    </a>
);

export function WorkflowEventBindings({match, location, history}: RouteComponentProps<any>) {
    // boiler-plate
    const isFirstRender = useRef(true);
    const ctx = useContext(Context);
    const queryParams = new URLSearchParams(location.search);

    // state for URL and query parameters
    const [namespace, setNamespace] = useState(nsUtils.getNamespace(match.params.namespace) || '');
    const [selectedWorkflowEventBinding, setSelectedWorkflowEventBinding] = useState(queryParams.get('selectedWorkflowEventBinding'));

    useEffect(
        useQueryParams(history, p => {
            setSelectedWorkflowEventBinding(p.get('selectedWorkflowEventBinding'));
        }),
        [history]
    );

    useEffect(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
            return;
        }
        history.push(
            historyUrl('workflow-event-bindings' + (nsUtils.getManagedNamespace() ? '' : '/{namespace}'), {
                namespace,
                selectedWorkflowEventBinding
            })
        );
    }, [namespace, selectedWorkflowEventBinding]);

    // internal state
    const [error, setError] = useState<Error>();
    const [workflowEventBindings, setWorkflowEventBindings] = useState<WorkflowEventBinding[]>();

    const selected = (workflowEventBindings || []).find(x => x.metadata.namespace + '/' + x.metadata.name === selectedWorkflowEventBinding);

    const g = new Graph();
    (workflowEventBindings || []).forEach(web => {
        const bindingId = ID.join('WorkflowEventBinding', web.metadata.namespace, web.metadata.name);
        g.nodes.set(bindingId, {label: web.spec.event.selector, genre: 'event', icon: 'cloud'});
        if (web.spec.submit) {
            const x = web.spec.submit.workflowTemplateRef;
            const templateId = ID.join(x.clusterScope ? 'ClusterWorkflowTemplate' : 'WorkflowTemplate', web.metadata.namespace, x.name);
            g.nodes.set(templateId, {
                label: x.name,
                genre: x.clusterScope ? 'cluster-template' : 'template',
                icon: x.clusterScope ? 'window-restore' : 'window-maximize'
            });
            g.edges.set({v: bindingId, w: templateId}, {});
        }
    });

    useEffect(() => {
        services.event
            .listWorkflowEventBindings(namespace)
            .then(list => setWorkflowEventBindings(list.items || []))
            .then(() => setError(null))
            .catch(setError);
    }, [namespace]);

    useCollectEvent('openedWorkflowEventBindings');

    return (
        <Page
            title='Workflow Event Bindings'
            toolbar={{
                breadcrumbs: [
                    {title: 'Workflow Event Bindings', path: uiUrl('workflow-event-bindings')},
                    {title: namespace, path: uiUrl('workflow-event-bindings/' + namespace)}
                ],
                tools: [<NamespaceFilter key='namespace-filter' value={namespace} onChange={setNamespace} extraNamespaces={nsUtils.getUniqueNamespaces(workflowEventBindings)} />]
            }}>
            <ErrorNotice error={error} />
            {!workflowEventBindings ? (
                <Loading />
            ) : workflowEventBindings.length === 0 ? (
                <ZeroState>
                    <p>{introductionText}</p>
                    <p>
                        Once you&apos;ve created a workflow event binding, you can test it from the CLI using <code>curl</code>, for example:
                    </p>
                    <p>
                        <code>
                            curl &apos;{absoluteUrl('api/v1/events/{namespace}/-')}&apos; -H &apos;Content-Type: application/json&apos; -H &apos;Authorization: $ARGO_TOKEN&apos; -d
                            &apos;&#123;&#125;&apos;
                        </code>
                    </p>
                    <p>
                        You can also experiment with viewing the{' '}
                        <a href='https://argo-workflows.readthedocs.io/en/latest/swagger/' target='_blank' rel='noreferrer'>
                            graphical interface to the API
                        </a>{' '}
                        - look for &quot;EventService&quot;.
                    </p>
                    <p>{learnMore}</p>
                </ZeroState>
            ) : (
                <>
                    <GraphPanel
                        storageScope='workflow-event-bindings'
                        graph={g}
                        nodeGenresTitle={'Type'}
                        nodeGenres={{'event': true, 'template': true, 'cluster-template': true}}
                        horizontal={true}
                        onNodeSelect={id => {
                            const x = ID.split(id);
                            if (x.type === 'ClusterWorkflowTemplate') {
                                ctx.navigation.goto(uiUrl('cluster-workflow-templates/' + x.name));
                            } else if (x.type === 'WorkflowTemplate') {
                                ctx.navigation.goto(uiUrl('workflow-templates/' + x.namespace + '/' + x.name));
                            } else {
                                setSelectedWorkflowEventBinding(x.namespace + '/' + x.name);
                            }
                        }}
                    />
                    <Footnote>
                        <InfoIcon /> {introductionText} {learnMore}.
                    </Footnote>
                    <SlidingPanel isShown={!!selectedWorkflowEventBinding} onClose={() => setSelectedWorkflowEventBinding(null)}>
                        {selected && <SerializingObjectEditor value={selected} />}
                    </SlidingPanel>
                </>
            )}
        </Page>
    );
}
