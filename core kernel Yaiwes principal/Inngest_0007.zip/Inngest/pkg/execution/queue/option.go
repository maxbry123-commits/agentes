package queue

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/inngest/inngest/pkg/backoff"
	"github.com/inngest/inngest/pkg/constraintapi"
	"github.com/inngest/inngest/pkg/consts"
	"github.com/inngest/inngest/pkg/execution/state"
	"github.com/inngest/inngest/pkg/logger"
	"github.com/inngest/inngest/pkg/telemetry/trace"
	"github.com/jonboulle/clockwork"
	"github.com/oklog/ulid/v2"
)

// PartitionPriorityFinder returns the priority for a given queue partition.
type PartitionPriorityFinder func(ctx context.Context, part QueuePartition) uint

// AccountPriorityFinder returns the priority for a given account.
type AccountPriorityFinder func(ctx context.Context, accountId uuid.UUID) uint

// AccountExists reports whether an account can still process queue partitions.
type AccountExists func(ctx context.Context, accountID uuid.UUID) (bool, error)

type PartitionPausedInfo struct {
	Stale  bool
	Paused bool
}
type PartitionPausedGetter func(ctx context.Context, fnID uuid.UUID) PartitionPausedInfo

type QueueOpt func(q *QueueOptions)

type QueueProcessorOpt func(q *queueProcessor)

// AccountShardIterationEnabled controls whether account-scoped queue reads
// should fan out across every shard instead of resolving the account's shard.
type AccountShardIterationEnabled func(ctx context.Context, accountID uuid.UUID) bool

// DisableSemaphoreConstraintChecks controls whether semaphore constraints should
// be ignored for an account while semaphores are rolled out.
type DisableSemaphoreConstraintChecks func(ctx context.Context, accountID uuid.UUID) bool

// QueueItemEarliestPeekTimeConfig controls earliest-peek-time side-key stamping.
// Items already visited by the iterator are stamped individually when Enabled is
// true. BulkStampLimit is only the additional tail budget used if the iterator
// stops early after hitting account or function concurrency, and is ignored
// unless Enabled is true.
type QueueItemEarliestPeekTimeConfig struct {
	Enabled        bool
	BulkStampLimit int
}

// QueueItemEarliestPeekTimeEnabled returns the earliest-peek-time side-key
// stamping config for a queue item scope.
type QueueItemEarliestPeekTimeEnabled func(ctx context.Context, shardName string, acctID, envID, fnID uuid.UUID) QueueItemEarliestPeekTimeConfig

func WithName(name string) QueueProcessorOpt {
	return func(q *queueProcessor) {
		q.name = name
	}
}

func WithQueueLifecycles(l ...QueueLifecycleListener) QueueOpt {
	return func(q *QueueOptions) {
		q.lifecycles = l
	}
}

func WithPartitionPriorityFinder(ppf PartitionPriorityFinder) QueueOpt {
	return func(q *QueueOptions) {
		q.PartitionPriorityFinder = ppf
	}
}

func WithPartitionPausedGetter(partitionPausedGetter PartitionPausedGetter) QueueOpt {
	return func(q *QueueOptions) {
		q.PartitionPausedGetter = partitionPausedGetter
	}
}

func WithAccountPriorityFinder(apf AccountPriorityFinder) QueueOpt {
	return func(q *QueueOptions) {
		q.AccountPriorityFinder = apf
	}
}

func WithAccountExists(f AccountExists) QueueOpt {
	return func(q *QueueOptions) {
		if f != nil {
			q.AccountExists = f
		}
	}
}

func WithAccountShardIterationEnabled(f AccountShardIterationEnabled) QueueOpt {
	return func(q *QueueOptions) {
		if f != nil {
			q.AccountShardIterationEnabled = f
		}
	}
}

func WithQueueItemEarliestPeekTimeEnabled(f QueueItemEarliestPeekTimeEnabled) QueueOpt {
	return func(q *QueueOptions) {
		if f != nil {
			q.QueueItemEarliestPeekTimeEnabled = f
		}
	}
}

func (o QueueOptions) ItemEarliestPeekTimeConfig(ctx context.Context, shardName string, item QueueItem) QueueItemEarliestPeekTimeConfig {
	if o.QueueItemEarliestPeekTimeEnabled == nil {
		return QueueItemEarliestPeekTimeConfig{}
	}

	config := o.QueueItemEarliestPeekTimeEnabled(
		ctx,
		shardName,
		item.Data.Identifier.AccountID,
		item.Data.Identifier.WorkspaceID,
		item.FunctionID,
	)
	if config.BulkStampLimit < 0 {
		config.BulkStampLimit = 0
	}

	return config
}

func WithIdempotencyTTL(t time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.IdempotencyTTL = t
	}
}

// WithIdempotencyTTLFunc returns custom idempotecy durations given a QueueItem.
// This allows customization of the idempotency TTL based off of specific jobs.
func WithIdempotencyTTLFunc(f func(context.Context, QueueItem) time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.IdempotencyTTLFunc = f
	}
}

func WithNumWorkers(n int32) QueueOpt {
	return func(q *QueueOptions) {
		q.numWorkers = n
	}
}

func WithShadowNumWorkers(n int32) QueueOpt {
	return func(q *QueueOptions) {
		q.numShadowWorkers = n
	}
}

func WithNumPartitionWorkers(n int32) QueueOpt {
	return func(q *QueueOptions) {
		q.numPartitionWorkers = n
	}
}

func WithPeekSizeRange(min int64, max int64) QueueOpt {
	return func(q *QueueOptions) {
		if max > AbsoluteQueuePeekMax {
			max = AbsoluteQueuePeekMax
		}
		q.PeekMin = min
		q.PeekMax = max
	}
}

func WithShadowPeekSizeRange(min int64, max int64) QueueOpt {
	return func(q *QueueOptions) {
		if max > AbsoluteShadowPartitionPeekMax {
			max = AbsoluteShadowPartitionPeekMax
		}
		q.shadowPeekMin = min
		q.shadowPeekMax = max
	}
}

func WithBacklogRefillLimit(limit int64) QueueOpt {
	return func(q *QueueOptions) {
		q.backlogRefillLimit = limit
	}
}

func WithBacklogNormalizationConcurrency(limit int64) QueueOpt {
	return func(q *QueueOptions) {
		q.backlogNormalizeConcurrency = limit
	}
}

func WithPartitionBacklogSizeConcurrency(limit int64) QueueOpt {
	return func(q *QueueOptions) {
		q.partitionBacklogSizeConcurrency = limit
	}
}

func (o QueueOptions) PartitionBacklogSizeConcurrency() int64 {
	if o.partitionBacklogSizeConcurrency <= 0 {
		return defaultPartitionBacklogSizeConcurrency
	}
	return o.partitionBacklogSizeConcurrency
}

// WithPausedRequeueExtension overrides how far into the future a paused
// partition is requeued once it is confirmed paused in the database. When not
// set (or non-positive), PartitionPausedRequeueExtension is used.
func WithPausedRequeueExtension(d time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.pausedRequeueExtension = d
	}
}

func (o QueueOptions) PausedRequeueExtension() time.Duration {
	if o.pausedRequeueExtension <= 0 {
		return PartitionPausedRequeueExtension
	}
	return o.pausedRequeueExtension
}

// WithSemaphoreRequeueExtension overrides how far into the future a partition
// is requeued when only the local semaphore limit is reached. When not set (or
// non-positive), PartitionSemaphoreLimitRequeueExtension is used.
func WithSemaphoreRequeueExtension(d time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.semaphoreRequeueExtension = d
	}
}

func (o QueueOptions) SemaphoreRequeueExtension() time.Duration {
	if o.semaphoreRequeueExtension <= 0 {
		return PartitionSemaphoreLimitRequeueExtension
	}
	return o.semaphoreRequeueExtension
}

func WithPeekConcurrencyMultiplier(m int64) QueueOpt {
	return func(q *QueueOptions) {
		q.peekCurrMultiplier = m
	}
}

func WithPeekEWMALength(l int) QueueOpt {
	return func(q *QueueOptions) {
		q.PeekEWMALen = l
	}
}

// WithPollTick specifies the interval at which the queue will poll the backing store
// for available partitions.
func WithPollTick(t time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.pollTick = t
	}
}

// WithShadowPollTick specifies the interval at which the queue will poll the backing store
// for available shadow partitions.
func WithShadowPollTick(t time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.shadowPollTick = t
	}
}

// WithBacklogNormalizePollTick specifies the interval at which the queue will poll the backing store
// for available backlogs to normalize.
func WithBacklogNormalizePollTick(t time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.backlogNormalizePollTick = t
	}
}

// WithDenyQueueNames specifies that the worker cannot select jobs from queue partitions
// within the given list of names.  This means that the worker will never work on jobs
// in the specified queues.
//
// NOTE: If this is set and this worker claims the sequential lease, there is no guarantee
// on latency or fairness in the denied queue partitions.
func WithDenyQueueNames(queues ...string) QueueOpt {
	return func(q *QueueOptions) {
		q.DenyQueues = queues
		q.DenyQueueMap = make(map[string]*struct{})
		q.DenyQueuePrefixes = make(map[string]*struct{})
		for _, i := range queues {
			q.DenyQueueMap[i] = &struct{}{}
			// If WithDenyQueueNames includes "user:*", trim the asterisc and use
			// this as a prefix match.
			if strings.HasSuffix(i, "*") {
				q.DenyQueuePrefixes[strings.TrimSuffix(i, "*")] = &struct{}{}
			}
		}
	}
}

// WithAllowQueueNames specifies that the worker can only select jobs from queue partitions
// within the given list of names.  This means that the worker will never work on jobs in
// other queues.
func WithAllowQueueNames(queues ...string) QueueOpt {
	return func(q *QueueOptions) {
		q.AllowQueues = queues
		q.AllowQueueMap = make(map[string]*struct{})
		q.AllowQueuePrefixes = make(map[string]*struct{})
		for _, i := range queues {
			q.AllowQueueMap[i] = &struct{}{}
			// If WithAllowQueueNames includes "user:*", trim the asterisc and use
			// this as a prefix match.
			if strings.HasSuffix(i, "*") {
				q.AllowQueuePrefixes[strings.TrimSuffix(i, "*")] = &struct{}{}
			}
		}
	}
}

// WithKindToQueueMapping maps queue.Item.Kind strings to queue names.  For example,
// when pushing a queue.Item with a kind of PayloadEdge, this job can be mapped to
// a specific queue name here.
//
// The mapping must be provided in terms of item kind to queue name.  If the item
// kind doesn't exist in the mapping the job's queue name will be left nil.  This
// means that the item will be placed in the workflow ID's queue.
func WithKindToQueueMapping(mapping map[string]string) QueueOpt {
	// XXX: Refactor osqueue.Item and this package to resolve these interfaces
	// and clean up this function.
	return func(q *QueueOptions) {
		q.queueKindMapping = mapping
	}
}

func WithDisableFifoForFunctions(mapping map[string]struct{}) QueueOpt {
	return func(q *QueueOptions) {
		q.disableFifoForFunctions = mapping
	}
}

func WithPeekSizeForFunction(mapping map[string]int64) QueueOpt {
	return func(q *QueueOptions) {
		q.peekSizeForFunctions = mapping
	}
}

func WithDisableFifoForAccounts(mapping map[string]struct{}) QueueOpt {
	return func(q *QueueOptions) {
		q.disableFifoForAccounts = mapping
	}
}

func WithLogger(l logger.Logger) QueueOpt {
	return func(q *QueueOptions) {
		q.log = l
	}
}

func WithBackoffFunc(f backoff.BackoffFunc) QueueOpt {
	return func(q *QueueOptions) {
		q.backoffFunc = f
	}
}

func WithRunMode(m QueueRunMode) QueueOpt {
	return func(q *QueueOptions) {
		q.runMode = m
	}
}

func WithQueueRoles(roles ...QueueRole) QueueOpt {
	return func(q *QueueOptions) {
		q.roles = append(q.roles, roles...)
	}
}

// WithClock allows replacing the queue's default (real) clock by a mock, for testing.
func WithClock(c clockwork.Clock) QueueOpt {
	return func(q *QueueOptions) {
		q.Clock = c
	}
}

// WithQueueContinuationLimit sets the continuation limit in the queue, eg. how many
// sequential steps cause hints in the queue to continue executing the same partition.
func WithQueueContinuationLimit(limit uint) QueueOpt {
	return func(q *QueueOptions) {
		q.continuationLimit = limit
	}
}

// WithQueueShadowContinuationLimit sets the shadow continuation limit in the queue, eg. how many
// sequential steps cause hints in the queue to continue executing the same shadow partition.
func WithQueueShadowContinuationLimit(limit uint) QueueOpt {
	return func(q *QueueOptions) {
		q.shadowContinuationLimit = limit
	}
}

type QueueRunMode struct {
	// Sequential determines whether Run() instance acquires sequential lease and processes items sequentially if lease is granted
	Sequential bool

	// Scavenger determines whether scavenger lease is acquired and scavenger is processed if lease is granted
	Scavenger bool

	// Partition determines whether partitions are processed
	Partition bool

	// Account determines whether accounts are processed
	Account bool

	// AccountWeight is the weight of processing accounts over partitions between 0 - 100 where 100 means only process accounts
	AccountWeight int

	// Continuations enables continuations
	Continuations bool

	// Shadow enables shadow partition processing
	ShadowPartition bool

	// AccountShadowPartition enables scanning of accounts for fair shadow partition processing
	AccountShadowPartition bool

	// AccountShadowPartitionWeight is the weight of processing accounts over global shadow partitions between 0 - 100 where 100 means only process accounts
	AccountShadowPartitionWeight int

	// ShadowContinuations enables shadow continuations
	ShadowContinuations bool

	// ShadowContinuationSkipProbability represents the probability to skip continuations (defaults to 0.2)
	ShadowContinuationSkipProbability float64

	// NormalizePartition enables the processing of partitions for normalization
	NormalizePartition bool

	// ExclusiveAccounts defines a list of account IDs to peek exclusively.
	// This can be used to configure executors processing only a static subset of accounts.
	ExclusiveAccounts []uuid.UUID

	// ShardGroup enables the executor to determine which shard to process items from during run time.
	ShardGroup string
}

type QueueOptions struct {
	PartitionPriorityFinder          PartitionPriorityFinder
	AccountPriorityFinder            AccountPriorityFinder
	AccountExists                    AccountExists
	PartitionPausedGetter            PartitionPausedGetter
	AccountShardIterationEnabled     AccountShardIterationEnabled
	QueueItemEarliestPeekTimeEnabled QueueItemEarliestPeekTimeEnabled

	lifecycles QueueLifecycleListeners

	AllowKeyQueues                  AllowKeyQueues
	PartitionConstraintConfigGetter PartitionConstraintConfigGetter

	shadowPartitionProcessCount QueueShadowPartitionProcessCount

	TenantInstrumentor TenantInstrumentor

	// IdempotencyTTL is the default or static idempotency duration apply to jobs,
	// if idempotencyTTLFunc is not defined.
	IdempotencyTTL time.Duration
	// IdempotencyTTLFunc returns an time.Duration representing how long job IDs
	// remain idempotent.
	IdempotencyTTLFunc func(context.Context, QueueItem) time.Duration
	// pollTick is the interval between each scan for jobs.
	pollTick                 time.Duration
	shadowPollTick           time.Duration
	backlogNormalizePollTick time.Duration
	// numWorkers stores the number of workers available to concurrently process jobs.
	numWorkers int32
	// numShadowWorkers stores the number of workers available to concurrently scan partitions
	numShadowWorkers int32
	// numPartitionWorkers stores the number of goroutines available to concurrently process partitions.
	numPartitionWorkers int32
	// numBacklogNormalizationWorkers stores the maximum number of workers available to concurrenctly scan normalization partitions
	numBacklogNormalizationWorkers int32
	// peek min & max sets the range for partitions to peek for items
	PeekMin int64
	PeekMax int64
	// PeekSizeExponent is the exp. on the random skewed distribution
	PeekSizeExponent float64
	// usePeekEWMA specifies whether we should use EWMA for peeking.
	usePeekEWMA bool
	// peekCurrMultiplier is a multiplier used for calculating the dynamic peek size
	// based on the EWMA values
	peekCurrMultiplier int64
	// PeekEWMALen is the size of the list to hold the most recent values
	PeekEWMALen int
	// queueKindMapping stores a map of job kind => queue names
	queueKindMapping        map[string]string
	queueProducer           Producer
	queueConsumer           Consumer
	queueRunReader          RunQueueReader
	queueStatusReader       QueueStatusReader
	queuePartitionReader    QueuePartitionReader
	queueBacklogReader      QueueBacklogReader
	queueItemReader         QueueItemReader
	queueAttemptResetter    AttemptResetter
	disableFifoForFunctions map[string]struct{}
	disableFifoForAccounts  map[string]struct{}
	peekSizeForFunctions    map[string]int64
	log                     logger.Logger

	// DenyQueues provides a denylist ensuring that the queue will never claim
	// this partition, meaning that no jobs from this queue will run on this worker.
	DenyQueues        []string
	DenyQueueMap      map[string]*struct{}
	DenyQueuePrefixes map[string]*struct{}

	// AllowQueues provides an allowlist, ensuring that the queue only peeks the specified
	// partitions.  jobs from other partitions will never be scanned or processed.
	AllowQueues   []string
	AllowQueueMap map[string]*struct{}
	// AllowQueuePrefixes are memoized prefixes that can be allowed.
	AllowQueuePrefixes map[string]*struct{}

	// instrumentInterval represents the frequency and instrumentation will attempt to run
	instrumentInterval time.Duration

	// backoffFunc is the backoff function to use when retrying operations.
	backoffFunc backoff.BackoffFunc

	Clock clockwork.Clock

	// runMode defines the processing scopes or capabilities of the queue instances
	runMode QueueRunMode

	roles []QueueRole

	continuationLimit uint

	shadowContinuationLimit uint

	shadowPeekMin                   int64
	shadowPeekMax                   int64
	backlogRefillLimit              int64
	backlogNormalizeConcurrency     int64
	partitionBacklogSizeConcurrency int64

	// pausedRequeueExtension is how far into the future a paused partition is
	// requeued when it is confirmed paused in the database. Falls back to
	// PartitionPausedRequeueExtension when unset.
	pausedRequeueExtension time.Duration
	// semaphoreRequeueExtension is how far into the future a partition is
	// requeued when only the local semaphore limit is reached. Falls back to
	// PartitionSemaphoreLimitRequeueExtension when unset.
	semaphoreRequeueExtension time.Duration

	NormalizeRefreshItemCustomConcurrencyKeys NormalizeRefreshItemCustomConcurrencyKeysFn
	RefreshItemThrottle                       RefreshItemThrottleFn

	enableJobPromotion bool

	latencyPartition *LatencyPartitionOptions

	CapacityManager                     constraintapi.CapacityManager
	EnableCapacityLeaseInstrumentation  constraintapi.EnableHighCardinalityInstrumentation
	CapacityLeaseExtendInterval         time.Duration
	AcquireCapacityLeaseOnBacklogRefill bool
	DisableSemaphoreConstraintChecks    DisableSemaphoreConstraintChecks

	ConditionalTracer trace.ConditionalTracer

	ShardAssignmentConfig ShardAssignmentConfig
	// OnShardLeaseAcquired is called immediately after a shard lease is successfully claimed.
	// The shardName parameter is the name of the specific shard that was leased.
	OnShardLeaseAcquired func(ctx context.Context, shardName string)
	ShardLeaseKeySuffix  string
}

func WithShardAssignmentConfig(cfg ShardAssignmentConfig) QueueOpt {
	return func(q *QueueOptions) {
		q.ShardAssignmentConfig = cfg
	}
}

func WithOnShardLeaseAcquired(f func(ctx context.Context, shardName string)) QueueOpt {
	return func(q *QueueOptions) {
		q.OnShardLeaseAcquired = f
	}
}

func WithShardLeaseKeySuffix(suffix string) QueueOpt {
	return func(q *QueueOptions) {
		q.ShardLeaseKeySuffix = suffix
	}
}

func WithPeekEWMA(on bool) QueueOpt {
	return func(q *QueueOptions) {
		q.usePeekEWMA = on
	}
}

// PartitionConstraintConfigGetter returns the constraint configuration for a given partition
type PartitionConstraintConfigGetter func(ctx context.Context, p PartitionIdentifier) PartitionConstraintConfig

// WithPartitionConstraintConfigGetter assigns a function that returns queue constraints for a given partition.
func WithPartitionConstraintConfigGetter(f PartitionConstraintConfigGetter) QueueOpt {
	return func(q *QueueOptions) {
		q.PartitionConstraintConfigGetter = f
	}
}

// AllowKeyQueues determines if key queues should be enabled for the account
type AllowKeyQueues func(ctx context.Context, acctID, envID, fnID uuid.UUID) bool

func WithAllowKeyQueues(kq AllowKeyQueues) QueueOpt {
	return func(q *QueueOptions) {
		q.AllowKeyQueues = kq
	}
}

// QueueShadowPartitionProcessCount determines how many times the shadow scanner
// continue to process a shadow partition's backlog.
// This helps with reducing churn on leases for the shadow partition and allow handling
// larger amount of backlogs if there are a ton of backlog due to keys
type QueueShadowPartitionProcessCount func(ctx context.Context, acctID uuid.UUID) int

func WithQueueShadowPartitionProcessCount(spc QueueShadowPartitionProcessCount) QueueOpt {
	return func(q *QueueOptions) {
		q.shadowPartitionProcessCount = spc
	}
}

type (
	NormalizeRefreshItemCustomConcurrencyKeysFn func(ctx context.Context, item *QueueItem, existingKeys []state.CustomConcurrency, shadowPartition *QueueShadowPartition) ([]state.CustomConcurrency, error)
	RefreshItemThrottleFn                       func(ctx context.Context, item *QueueItem) (*Throttle, error)
)

func WithNormalizeRefreshItemCustomConcurrencyKeys(fn NormalizeRefreshItemCustomConcurrencyKeysFn) QueueOpt {
	return func(q *QueueOptions) {
		q.NormalizeRefreshItemCustomConcurrencyKeys = fn
	}
}

func WithRefreshItemThrottle(fn RefreshItemThrottleFn) QueueOpt {
	return func(q *QueueOptions) {
		q.RefreshItemThrottle = fn
	}
}

type TenantInstrumentor func(ctx context.Context, partitionID string) error

func WithTenantInstrumentor(fn TenantInstrumentor) QueueOpt {
	return func(q *QueueOptions) {
		q.TenantInstrumentor = fn
	}
}

func WithInstrumentInterval(t time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		if t > 0 {
			q.instrumentInterval = t
		}
	}
}

func WithEnableJobPromotion(enable bool) QueueOpt {
	return func(q *QueueOptions) {
		q.enableJobPromotion = enable
	}
}

func WithQueueProducer(producer Producer) QueueOpt {
	return func(q *QueueOptions) {
		q.queueProducer = producer
	}
}

func WithQueueConsumer(consumer Consumer) QueueOpt {
	return func(q *QueueOptions) {
		q.queueConsumer = consumer
	}
}

// WithQueueRunReader overrides the queue's default run reader.
func WithQueueRunReader(reader RunQueueReader) QueueOpt {
	return func(q *QueueOptions) { q.queueRunReader = reader }
}

// WithQueueStatusReader overrides the queue's default status reader.
func WithQueueStatusReader(reader QueueStatusReader) QueueOpt {
	return func(q *QueueOptions) { q.queueStatusReader = reader }
}

// WithQueuePartitionReader overrides the queue's default partition reader.
func WithQueuePartitionReader(reader QueuePartitionReader) QueueOpt {
	return func(q *QueueOptions) { q.queuePartitionReader = reader }
}

// WithQueueBacklogReader overrides the queue's default backlog reader.
func WithQueueBacklogReader(reader QueueBacklogReader) QueueOpt {
	return func(q *QueueOptions) { q.queueBacklogReader = reader }
}

// WithQueueItemReader overrides the queue's default item reader.
func WithQueueItemReader(reader QueueItemReader) QueueOpt {
	return func(q *QueueOptions) { q.queueItemReader = reader }
}

// WithQueueAttemptResetter overrides the queue's default shard-backed attempt resetter.
func WithQueueAttemptResetter(resetter AttemptResetter) QueueOpt {
	return func(q *QueueOptions) {
		q.queueAttemptResetter = resetter
	}
}

func WithCapacityManager(capacityManager constraintapi.CapacityManager) QueueOpt {
	return func(q *QueueOptions) {
		q.CapacityManager = capacityManager
	}
}

func WithCapacityLeaseExtendInterval(interval time.Duration) QueueOpt {
	return func(q *QueueOptions) {
		q.CapacityLeaseExtendInterval = interval
	}
}

func WithCapacityLeaseInstrumentation(enable constraintapi.EnableHighCardinalityInstrumentation) QueueOpt {
	return func(q *QueueOptions) {
		q.EnableCapacityLeaseInstrumentation = enable
	}
}

func WithAcquireCapacityLeaseOnBacklogRefill(acquire bool) QueueOpt {
	return func(q *QueueOptions) {
		q.AcquireCapacityLeaseOnBacklogRefill = acquire
	}
}

func WithDisableSemaphoreConstraintChecks(f DisableSemaphoreConstraintChecks) QueueOpt {
	return func(q *QueueOptions) {
		q.DisableSemaphoreConstraintChecks = f
	}
}

func WithConditionalTracer(tracer trace.ConditionalTracer) QueueOpt {
	return func(q *QueueOptions) {
		q.ConditionalTracer = tracer
	}
}

func WithPeekSizeExponent(n float64) QueueOpt {
	return func(q *QueueOptions) {
		q.PeekSizeExponent = n
	}
}

// WithLatencyPartition adds latency partition tracking jobs which enter the queue
// without flow control, and when peeked and executed run the provided callback
// to report enqueue-to-process delay E2E.
func WithLatencyPartition(o LatencyPartitionOptions) QueueOpt {
	return func(q *QueueOptions) {
		// Only a single partition supported for now.
		if o.Partitions != 1 {
			o.Partitions = 1
		}
		if o.Interval <= 0 {
			o.Interval = 5 * time.Second
		}
		q.latencyPartition = &o
	}
}

// LatencyPartitionOptions sets latency tracking jobs in the queue.
type LatencyPartitionOptions struct {
	// Partitions is the number of unique partition IDs to create for job tracking.
	Partitions int // will create eg. uuid.New("ffffffff-ffff-ffff-ffff-fffffffffff1"),
	// Interval is the duration between tracking jobs
	Interval time.Duration // time.Second*5
	// Callback is called when the job executes, with the full RunInfo
	// containing latency, sojourn delay, and other processing metadata.
	Callback func(ctx context.Context, info RunInfo)
}

// continuation represents a partition continuation, forcung the queue to continue working
// on a partition once a job from a partition has been processed.
type continuation struct {
	partition *QueuePartition
	// count is stored and incremented each time the partition is enqueued.
	count uint
}

// ShadowContinuation is the equivalent of continuation for shadow partitions
type ShadowContinuation struct {
	ShadowPart *QueueShadowPartition
	Count      uint
}

// ProcessItem references the queue item and scanner-provided metadata to be processed by a worker.
type ProcessItem struct {
	I QueueItem

	Priority      uint
	ContinueCount uint

	CapacityLease *CapacityLease

	ConditionalTraceCtx context.Context
	result              *dispatchedItemHandle
}

type capacityLease struct {
	currentCapacityLeaseID *ulid.ULID
	capacityLeaseLock      sync.Mutex

	initialLeaseIssuedAt time.Time
}

func newCapacityLease(initialLease *CapacityLease) *capacityLease {
	cl := &capacityLease{
		capacityLeaseLock: sync.Mutex{},
	}
	if initialLease != nil {
		cl.currentCapacityLeaseID = &initialLease.LeaseID
		cl.initialLeaseIssuedAt = time.UnixMilli(initialLease.IssuedAtMS)
	}

	return cl
}

func (p *capacityLease) set(leaseID *ulid.ULID) {
	p.capacityLeaseLock.Lock()
	defer p.capacityLeaseLock.Unlock()
	p.currentCapacityLeaseID = leaseID
}

func (p *capacityLease) get() *ulid.ULID {
	p.capacityLeaseLock.Lock()
	defer p.capacityLeaseLock.Unlock()
	return p.currentCapacityLeaseID
}

func (p *capacityLease) issuedAt() time.Time {
	return p.initialLeaseIssuedAt
}

func (p *capacityLease) has() bool {
	p.capacityLeaseLock.Lock()
	defer p.capacityLeaseLock.Unlock()
	return p.currentCapacityLeaseID != nil
}

// FnMetadata is stored within the queue for retrieving
type FnMetadata struct {
	// NOTE: This is not encoded via JSON as we should always have the function
	// ID prior to doing a lookup, or should be able to retrieve the function ID
	// via the key.
	FnID uuid.UUID `json:"fnID"`

	// Paused represents whether the fn is paused.  This allows us to prevent leases
	// to a given partition if the partition belongs to a fn.
	Paused bool `json:"off"`

	// Migrate indicates if this queue is to be migrated or not
	Migrate bool `json:"migrate"`
}

type PartitionIdentifier struct {
	SystemQueueName *string
	FunctionID      uuid.UUID
	AccountID       uuid.UUID
	EnvID           uuid.UUID
}

func NewQueueOptions(
	options ...QueueOpt,
) *QueueOptions {
	o := &QueueOptions{
		PartitionPriorityFinder: func(_ context.Context, _ QueuePartition) uint {
			return PriorityDefault
		},
		AccountPriorityFinder: func(_ context.Context, _ uuid.UUID) uint {
			return PriorityDefault
		},
		AccountExists: func(_ context.Context, _ uuid.UUID) (bool, error) {
			return true, nil
		},
		AccountShardIterationEnabled: func(context.Context, uuid.UUID) bool {
			return false
		},
		PartitionPausedGetter: func(ctx context.Context, fnID uuid.UUID) PartitionPausedInfo {
			return PartitionPausedInfo{}
		},
		PeekMin:                         DefaultQueuePeekMin,
		PeekMax:                         DefaultQueuePeekMax,
		PeekSizeExponent:                7,
		shadowPeekMin:                   ShadowPartitionPeekMinBacklogs,
		shadowPeekMax:                   ShadowPartitionPeekMaxBacklogs,
		backlogRefillLimit:              BacklogRefillHardLimit,
		backlogNormalizeConcurrency:     defaultBacklogNormalizeConcurrency,
		partitionBacklogSizeConcurrency: defaultPartitionBacklogSizeConcurrency,
		runMode: QueueRunMode{
			Sequential:                        true,
			Scavenger:                         true,
			Partition:                         true,
			Account:                           true,
			AccountWeight:                     85,
			ShadowPartition:                   true,
			AccountShadowPartition:            true,
			AccountShadowPartitionWeight:      85,
			NormalizePartition:                true,
			ShadowContinuationSkipProbability: consts.QueueContinuationSkipProbability,
		},
		numWorkers:                     defaultNumWorkers,
		numShadowWorkers:               defaultNumShadowWorkers,
		numPartitionWorkers:            defaultNumPartitionWorkers,
		numBacklogNormalizationWorkers: defaultBacklogNormalizationWorkers,
		pollTick:                       defaultPollTick,
		shadowPollTick:                 defaultShadowPollTick,
		backlogNormalizePollTick:       defaultBacklogNormalizePollTick,
		IdempotencyTTL:                 defaultIdempotencyTTL,
		queueKindMapping:               make(map[string]string),
		peekSizeForFunctions:           make(map[string]int64),
		instrumentInterval:             DefaultInstrumentInterval,
		PartitionConstraintConfigGetter: func(ctx context.Context, pi PartitionIdentifier) PartitionConstraintConfig {
			def := DefaultConcurrency

			return PartitionConstraintConfig{
				Concurrency: PartitionConcurrency{
					AccountConcurrency:  def,
					FunctionConcurrency: def,
				},
			}
		},
		AllowKeyQueues: func(ctx context.Context, acctID, envID, fnID uuid.UUID) bool {
			return false
		},
		QueueItemEarliestPeekTimeEnabled: func(ctx context.Context, shardName string, acctID, envID, fnID uuid.UUID) QueueItemEarliestPeekTimeConfig {
			return QueueItemEarliestPeekTimeConfig{}
		},
		shadowPartitionProcessCount: func(ctx context.Context, acctID uuid.UUID) int {
			return 5
		},
		TenantInstrumentor: func(ctx context.Context, partitionID string) error {
			return nil
		},
		backoffFunc:       backoff.DefaultBackoff,
		Clock:             clockwork.NewRealClock(),
		continuationLimit: consts.DefaultQueueContinueLimit,
		NormalizeRefreshItemCustomConcurrencyKeys: func(ctx context.Context, item *QueueItem, existingKeys []state.CustomConcurrency, shadowPartition *QueueShadowPartition) ([]state.CustomConcurrency, error) {
			return existingKeys, nil
		},
		RefreshItemThrottle: func(ctx context.Context, item *QueueItem) (*Throttle, error) {
			return nil, nil
		},
		CapacityLeaseExtendInterval: QueueLeaseDuration / 2,
		ConditionalTracer:           trace.NoopConditionalTracer(),
		EnableCapacityLeaseInstrumentation: func(ctx context.Context, accountID, envID, functionID uuid.UUID) (enable bool) {
			return false
		},
	}

	for _, qopt := range options {
		qopt(o)
	}

	return o
}

func (q *queueProcessor) configureQueueRoles() {
	q.roles = append(q.defaultQueueRoles(), q.roles...)
	q.roles = filterQueueRoles(q.QueueOptions, q.roles)
}

// configureScannerRoles appends roles declared by the selected scanner.
// Registration happens after shard selection and before role goroutines start,
// which also supports dynamically assigned shard groups.
func (q *queueProcessor) configureScannerRoles(scanner QueueScanner) error {
	provider, ok := scanner.(QueueScannerRoleProvider)
	if !ok {
		return nil
	}
	provided := filterQueueRoles(q.QueueOptions, provider.QueueScannerRoles())
	existing := make(map[string]struct{}, len(q.roles)+len(provided))
	for _, role := range q.roles {
		existing[role.Name()] = struct{}{}
	}
	for _, role := range provided {
		name := role.Name()
		if _, ok := existing[name]; ok {
			return fmt.Errorf("queue scanner role %q is already configured", name)
		}
		existing[name] = struct{}{}
	}
	q.roles = append(q.roles, provided...)
	return nil
}

func (q *queueProcessor) defaultQueueRoles() []QueueRole {
	roles := []QueueRole{}
	if q.runMode.Scavenger {
		roles = append(roles, NewScavengerRole())
	}
	roles = append(roles, newInstrumentationRole(q, WithRoleRunInterval(q.instrumentInterval)))
	if q.latencyPartition != nil {
		roles = append(roles, NewLatencyTrackerRole(*q.latencyPartition, WithRoleRunInterval(q.latencyPartition.Interval)))
	}
	return roles
}

func filterQueueRoles(o *QueueOptions, roles []QueueRole) []QueueRole {
	filtered := make([]QueueRole, 0, len(roles))
	for _, role := range roles {
		if role == nil {
			continue
		}
		if role.Name() == QueueRoleSequential && !includeSequentialRole(o) {
			continue
		}
		filtered = append(filtered, role)
	}
	return filtered
}
