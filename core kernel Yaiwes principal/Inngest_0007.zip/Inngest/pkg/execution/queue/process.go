package queue

import (
	"context"
	"errors"
	"fmt"
	"runtime/debug"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/inngest/inngest/pkg/constraintapi"
	"github.com/inngest/inngest/pkg/execution/state"
	"github.com/inngest/inngest/pkg/logger"
	"github.com/inngest/inngest/pkg/service"
	"github.com/inngest/inngest/pkg/telemetry/metrics"
	"github.com/jonboulle/clockwork"
	"github.com/oklog/ulid/v2"
	"go.opentelemetry.io/otel/attribute"
)

func (q *queueProcessor) ProcessItem(
	ctx context.Context,
	i ProcessItem,
	f RunFunc,
) (ProcessItemResult, error) {
	shard := q.Shard()
	accountID := i.I.Data.Identifier.AccountID
	envID := i.I.Data.Identifier.WorkspaceID
	fnID := i.I.Data.Identifier.WorkflowID
	if fnID == uuid.Nil {
		fnID = i.I.FunctionID
	}
	runID := i.I.Data.Identifier.RunID

	l := logger.StdlibLogger(ctx).With(
		"item_id", i.I.ID,
		"account_id", accountID,
		"env_id", envID,
		"fn_id", fnID,
		"run_id", i.I.Data.Identifier.RunID,
	)

	ctx, span := q.ConditionalTracer.NewSpan(ctx, "queue.ProcessItem", TraceScopeFromQueueItem(i.I, shard.Name()))
	defer span.End()
	span.SetAttributes(attribute.String("item_id", i.I.ID))
	span.SetAttributes(attribute.String("item_kind", i.I.Data.Kind))
	span.SetAttributes(attribute.String("run_id", runID.String()))
	if i.I.Data.JobID != nil {
		span.SetAttributes(attribute.String("job_id", *i.I.Data.JobID))
	}
	if i.CapacityLease != nil {
		span.SetAttributes(attribute.String("capacity_lease_id", i.CapacityLease.LeaseID.String()))
	}

	qi := i.I
	continuationCtr := i.ContinueCount

	leaseID := qi.LeaseID
	leaseMu := sync.RWMutex{}
	processResult := ProcessItemResult{}

	currentLeaseID := func() *ulid.ULID {
		leaseMu.RLock()
		defer leaseMu.RUnlock()
		if leaseID == nil {
			return nil
		}
		current := *leaseID
		return &current
	}

	setLeaseID := func(next *ulid.ULID) {
		leaseMu.Lock()
		defer leaseMu.Unlock()
		leaseID = next
	}

	itemWithCurrentLease := func(item QueueItem) QueueItem {
		item.LeaseID = currentLeaseID()
		return item
	}

	// Allow the main runner to block until this work is done
	q.wg.Add(1)
	defer q.wg.Done()

	errCh := make(chan error, 1)

	// XXX: Add a max job time here, configurable.
	jobCtx, jobDone := context.WithCancel(context.WithoutCancel(ctx))
	defer jobDone()

	// Add the job ID to the queue context.  This allows any logic that handles the run function
	// to inspect job IDs, eg. for tracing or logging, without having to thread this down as
	// arguments.
	//
	// NOTE: It is important that we keep this here for every job;  the exeuctor uses this to pass
	// along the job ID as metadata to the SDK.  We also need to pass in shard information.
	jobCtx = WithShardID(jobCtx, shard.Name())
	jobCtx = WithJobID(jobCtx, qi.ID)
	jobCtx = WithGenerationID(jobCtx, qi.GenerationID)
	// Same with the group ID, if it exists.
	if qi.Data.GroupID != "" {
		jobCtx = state.WithGroupID(jobCtx, qi.Data.GroupID)
	}

	// Continually extend lease in the background while we're working on this job
	extendLeaseTick := q.Clock().NewTicker(QueueLeaseDuration / 2)
	defer extendLeaseTick.Stop()
	leaseRenewalDone := make(chan struct{})
	go func() {
		defer close(leaseRenewalDone)

		for {
			select {
			case <-jobCtx.Done():
				return
			case <-extendLeaseTick.Chan():
				if ctx.Err() != nil {
					// Don't extend lease when the ctx is done.
					return
				}

				current := currentLeaseID()
				if current == nil {
					l.Error("cannot extend lease since lease ID is nil", "qi", qi)
					// Don't extend lease since one doesn't exist
					errCh <- fmt.Errorf("cannot extend lease since lease ID is nil")
					return
				}

				// Once a job has started, use a BG context to always renew.
				nextLeaseID, err := shard.ExtendLease(
					context.Background(),
					qi,
					*current,
					QueueLeaseDuration,
				)
				if err != nil {
					// log error if unexpected; the queue item may be removed by a Dequeue() operation
					// invoked by finalize() (Cancellations, Parallelism)
					if !errors.Is(err, ErrQueueItemNotFound) {
						l.Error("error extending lease", "error", err, "qi", qi)
					}

					// always stop processing the queue item if lease cannot be extended
					errCh <- fmt.Errorf("error extending lease while processing: %w", err)
					return
				}
				setLeaseID(nextLeaseID)
			}
		}
	}()
	stopItemLeaseRenewal := func() {
		jobDone()
		// Ensure cleanup observes any lease renewal that won the race with job
		// completion before passing a lease token to Requeue or Dequeue.
		<-leaseRenewalDone
	}

	// If a capacity lease is set on the item, continue extending it and cancel execution if lease expires
	capacityLeaseID := newCapacityLease(i.CapacityLease)
	instrumentCapacityLease := i.CapacityLease != nil && q.EnableCapacityLeaseInstrumentation != nil && q.EnableCapacityLeaseInstrumentation(ctx, accountID, envID, fnID)
	var extendCapacityLeaseTick clockwork.Ticker

	// Only extend if initial capacity lease was provided for this queue item
	// We will not expect a lease when
	// - the item is enqueued to a system queue
	// - the Constraint API is disabled or the current account is not enrolled
	extendCapacityLeaseCtx, cancelExtendCapacityLease := context.WithCancel(jobCtx)
	defer cancelExtendCapacityLease()

	releaseCapacityLease := func() {
		cancelExtendCapacityLease()

		currentLeaseID := capacityLeaseID.get()
		if currentLeaseID == nil {
			return
		}

		leaseIssuedAt := capacityLeaseID.issuedAt()

		res, err := q.CapacityManager.Release(context.Background(), &constraintapi.CapacityReleaseRequest{
			AccountID:      accountID,
			IdempotencyKey: qi.ID,
			LeaseID:        *currentLeaseID,
			Source: constraintapi.LeaseSource{
				Location:          constraintapi.CallerLocationItemLease,
				Service:           constraintapi.ServiceExecutor,
				RunProcessingMode: constraintapi.RunProcessingModeBackground,
			},
			LeaseIssuedAt: leaseIssuedAt,
		})
		if err != nil {
			l.ReportError(err, "failed to release capacity", logger.WithErrorReportTags(map[string]string{
				"account_id":      accountID.String(),
				"lease_id":        currentLeaseID.String(),
				"function_id":     fnID.String(),
				"lease_issued_at": leaseIssuedAt.String(),
			}))
			return
		}

		if instrumentCapacityLease {
			l.Debug(
				"released capacity lease",
				"res", res,
				"lease_id", currentLeaseID.String(),
			)
		}
	}

	if capacityLeaseID.has() {
		extendCapacityLeaseTick = q.Clock().NewTicker(q.CapacityLeaseExtendInterval)
		defer extendCapacityLeaseTick.Stop()

		// Cancel processing if the current capacity lease reaches its expiry
		// before a renewal succeeds. The renewal request itself may be delayed or
		// hang, so relying only on its eventual response can allow work to
		// continue after the concurrency reservation has been scavenged.
		go func() {
			for {
				currentCapacityLease := capacityLeaseID.get()
				if currentCapacityLease == nil {
					return
				}

				untilExpiry := currentCapacityLease.Timestamp().Sub(q.Clock().Now())
				if untilExpiry > 0 {
					expiryTimer := q.Clock().NewTimer(untilExpiry)
					select {
					case <-extendCapacityLeaseCtx.Done():
						expiryTimer.Stop()
						return
					case <-expiryTimer.Chan():
					}
				}

				if extendCapacityLeaseCtx.Err() != nil {
					return
				}

				latestCapacityLease := capacityLeaseID.get()
				if latestCapacityLease != nil && latestCapacityLease.Timestamp().After(q.Clock().Now()) {
					// A renewal won the race with the previous lease's expiry.
					continue
				}

				select {
				case errCh <- AlwaysRetryError(fmt.Errorf("capacity lease expired while processing")):
				case <-extendCapacityLeaseCtx.Done():
				}
				return
			}
		}()

		go func() {
			lastCapacityLeaseExtension := time.Now()
			for {
				select {
				case <-extendCapacityLeaseCtx.Done():
					return
				case <-extendCapacityLeaseTick.Chan():
					if extendCapacityLeaseCtx.Err() != nil {
						// The capacity lease was released early (or the job
						// finished) after this tick was buffered. Don't extend
						// a lease we no longer hold.
						return
					}

					if ctx.Err() != nil {
						// Don't extend lease when the ctx is done.
						return
					}

					currentCapacityLease := capacityLeaseID.get()
					if currentCapacityLease == nil {
						l.Error("cannot extend capacity lease since capacity lease ID is nil", "qi", qi)
						// Don't extend lease since one doesn't exist
						errCh <- AlwaysRetryError(fmt.Errorf("cannot extend capacity lease since lease ID is nil"))
						return
					}

					// This idempotency key will change with every refreshed lease, which makes sense.
					operationIdempotencyKey := currentCapacityLease.String()

					res, err := q.CapacityManager.ExtendLease(context.Background(), &constraintapi.CapacityExtendLeaseRequest{
						AccountID:      accountID,
						IdempotencyKey: operationIdempotencyKey,
						LeaseID:        *currentCapacityLease,
						Duration:       QueueLeaseDuration,
						Source: constraintapi.LeaseSource{
							Location:          constraintapi.CallerLocationItemLease,
							RunProcessingMode: constraintapi.RunProcessingModeBackground,
							Service:           constraintapi.ServiceExecutor,
						},
						LeaseIssuedAt: capacityLeaseID.issuedAt(),
					})
					if err != nil {
						if extendCapacityLeaseCtx.Err() != nil {
							// The lease was released early while this extension
							// was in flight; releaseCapacityLease cancels the
							// context before releasing, so a failure observed
							// after cancellation is expected and must not
							// requeue the item.
							return
						}

						l.ReportError(
							err,
							"error extending capacity lease",
							logger.WithErrorReportLog(true),
							logger.WithErrorReportTags(map[string]string{
								"accountID": accountID.String(),
								"item":      qi.ID,
								"leaseID":   currentCapacityLease.String(),
							}),
						)

						// always stop processing the queue item if lease cannot be extended
						errCh <- AlwaysRetryError(fmt.Errorf("error extending capacity lease while processing: %w", err))
						return
					}

					if res.LeaseID == nil {
						if extendCapacityLeaseCtx.Err() != nil {
							// The lease was released early while this extension
							// was in flight (release wins over extend on the
							// capacity manager); this is expected and must not
							// requeue the item.
							return
						}

						// Lease could not be extended
						l.Error("failed to extend capacity lease, no new lease ID received", "qi", qi)
						errCh <- AlwaysRetryError(fmt.Errorf("failed to extend capacity lease, no new lease ID received"))
						return
					}

					// Record current + next lease if high-cardinality instrumentation is enabled
					if instrumentCapacityLease {
						l.Debug(
							"extended capacity lease",
							"last_extension", time.Since(lastCapacityLeaseExtension),
							"lease_id", currentCapacityLease.String(),
							"next_lease", res.LeaseID.String(),
						)
					}

					// Update capacity lease
					capacityLeaseID.set(res.LeaseID)

					lastCapacityLeaseExtension = time.Now()
				}
			}
		}()

		// When capacity is leased, release it after the job function has completed.
		// This is optional and best-effort to free up concurrency capacity as quickly as possible
		// for the next worker to lease a queue item.
		defer service.Go(releaseCapacityLease)
	}

	startedAt := q.Clock().Now()
	go func() {
		longRunningJobStatusTick := q.Clock().NewTicker(5 * time.Minute)
		defer longRunningJobStatusTick.Stop()

		for {
			select {
			case <-jobCtx.Done():
				return
			case <-longRunningJobStatusTick.Chan():
			}

			l.Debug("long running queue job tick", "item", qi, "dur", q.Clock().Now().Sub(startedAt).String())
		}
	}()

	go func() {
		defer func() {
			if r := recover(); r != nil {
				// Always retry this job.
				stack := debug.Stack()
				l.Error("job panicked", "error", fmt.Errorf("%v", r), "stack", string(stack))
				errCh <- AlwaysRetryError(fmt.Errorf("job panicked: %v", r))
			}
		}()

		// This job may be up to 1999 ms in the future, as explained in processPartition.
		// Just... wait until the job is available.
		delay := time.UnixMilli(qi.AtMS).Sub(q.Clock().Now())

		if delay > 0 {
			<-q.Clock().After(delay)
			l.Trace("delaying job in memory",
				"at", qi.AtMS,
				"ms", delay.Milliseconds(),
			)
		}
		n := q.Clock().Now()

		// Track the sojourn (concurrency) latency.
		sojourn := qi.SojournLatency(n)
		doCtx := context.WithValue(jobCtx, sojournKey, sojourn)

		// Track the latency on average globally.  Do this in a goroutine so that it doesn't
		// at all delay the job during concurrenty locking contention.
		if qi.WallTimeMS == 0 {
			qi.WallTimeMS = qi.AtMS // backcompat while WallTimeMS isn't valid.
		}
		latency := qi.Latency(n)
		doCtx = context.WithValue(doCtx, latencyKey, latency)

		// store started at and latency in ctx
		doCtx = context.WithValue(doCtx, startedAtKey, n)

		go func() {
			// Update the ewma
			latencySem.Lock()
			latencyAvg.Add(float64(latency))
			metrics.GaugeQueueItemLatencyEWMA(ctx, int64(latencyAvg.Value()/1e6), metrics.GaugeOpt{
				PkgName: pkgName,
				Tags:    map[string]any{"kind": qi.Data.Kind, "queue_shard": shard.Name()},
			})
			latencySem.Unlock()

			// Set the metrics historgram and gauge, which reports the ewma value.
			metrics.HistogramQueueItemLatency(ctx, latency.Milliseconds(), metrics.HistogramOpt{
				PkgName: pkgName,
				Tags:    map[string]any{"kind": qi.Data.Kind, "queue_shard": shard.Name()},
			})
		}()

		metrics.IncrQueueItemStatusCounter(ctx, metrics.CounterOpt{
			PkgName: pkgName,
			Tags:    map[string]any{"status": "started", "queue_shard": shard.Name()},
		})

		// If a capacity lease was acquired for this item,
		// we want to allow the called function to invoke Release
		// early.
		// In this case, we need to stop extending the lease,
		// and call Release() in a non-blocking way.
		if i.CapacityLease != nil {
			// Provide the release handle
			i.CapacityLease.release = func() error {
				// Stop extending capacity lease
				cancelExtendCapacityLease()

				// Release capacity lease, if acquired
				service.Go(releaseCapacityLease)

				return nil
			}
		}

		runInfo := RunInfo{
			Latency:             latency,
			SojournDelay:        sojourn,
			Priority:            i.Priority,
			QueueShardName:      shard.Name(),
			ContinueCount:       continuationCtr,
			RefilledFromBacklog: qi.RefilledFrom,
			CapacityLease:       i.CapacityLease,
			ScavengeCount:       qi.ScavengeCount,
		}

		// Call the run func.
		res, err := f(doCtx, runInfo, qi.Data)
		processResult.RunResult = res

		{
			// Clean up leases and such
			extendLeaseTick.Stop()

			if extendCapacityLeaseTick != nil {
				extendCapacityLeaseTick.Stop()
			}

		}

		status := "completed"
		if err != nil {
			status = "errored"
			errCh <- err
		}

		metrics.IncrQueueItemStatusCounter(ctx, metrics.CounterOpt{
			PkgName: pkgName,
			Tags:    map[string]any{"status": status, "queue_shard": shard.Name()},
		})

		// NOTE:  We only want to clean up the jobDone channel here on success.
		// This is becasue errCh cleans up jobDone after handling the job as
		// an error.
		if err == nil {
			jobDone()
		}
	}()

	select {
	case err := <-errCh:
		// Job errored or extending lease errored.  Signal that the job is done to
		// stop everything.
		stopItemLeaseRenewal()

		if ShouldRetry(err, qi.Data.Attempt, qi.Data.GetMaxAttempts()) {
			at := q.backoffFunc(qi.Data.Attempt)

			// Attempt to find any RetryAtSpecifier in the error tree.
			if specifier := AsRetryAtError(err); specifier != nil {
				next := specifier.NextRetryAt()
				at = *next
			}

			if !IsAlwaysRetryable(err) {
				qi.Data.Attempt += 1
			}

			qi.AtMS = at.UnixMilli()
			requeueItem := itemWithCurrentLease(qi)
			if requeueErr := q.Requeue(context.WithoutCancel(ctx), shard.Name(), requeueItem, at); requeueErr != nil {
				if requeueErr == ErrQueueItemNotFound {
					// The item is gone, so there is nothing to requeue and this retry is
					// dropped.
					//
					// A cancelled run is the expected, high-volume case: Finalize()
					// dequeues the run's jobs, and the in-flight job then returns
					// ErrFunctionCancelled, which ShouldRetry treats as retryable because
					// it is a plain error.  The run is already terminal, so dropping the
					// retry is correct and not worth logging -- it would emit a line for
					// every cancellation that catches a job in flight.
					//
					// Any other cause is suspicious: if the run is still live, nothing
					// remains to drive it to a terminal state, so it stays non-terminal
					// and holds its function concurrency capacity until cancelled by hand.
					if !errors.Is(err, state.ErrFunctionCancelled) {
						l.Warn("dropped retry; queue item not found on requeue",
							"cause", err,
							"next_attempt", qi.Data.Attempt,
							"max_attempts", qi.Data.GetMaxAttempts(),
							"lease_id", requeueItem.LeaseID,
							"requeue_at", at,
						)
					}
					return ProcessItemResult{}, nil
				}

				l.Error("error requeuing job", "error", requeueErr, "item", requeueItem)
				return ProcessItemResult{}, requeueErr
			}
			if _, ok := err.(QuitError); ok {
				q.quit <- err
				return ProcessItemResult{}, err
			}
			return ProcessItemResult{}, nil
		}

		// Dequeue this entirely, as this permanently failed.
		// XXX: Increase permanently failed counter here.
		if err := q.Dequeue(context.WithoutCancel(ctx), shard.Name(), itemWithCurrentLease(qi)); err != nil {
			if err == ErrQueueItemNotFound {
				// Safe. The executor may have dequeued.
				return ProcessItemResult{}, nil
			}
			return ProcessItemResult{}, err
		}

		if _, ok := err.(QuitError); ok {
			l.Warn("received queue quit error", "error", err)
			q.quit <- err
			return ProcessItemResult{}, err
		}
	case <-jobCtx.Done():
		stopItemLeaseRenewal()
		if err := q.Dequeue(context.WithoutCancel(ctx), shard.Name(), itemWithCurrentLease(qi)); err != nil {
			if err == ErrQueueItemNotFound {
				// Safe. The executor may have dequeued.
				return processResult, nil
			}
			return ProcessItemResult{}, err
		}
	}

	return processResult, nil
}
