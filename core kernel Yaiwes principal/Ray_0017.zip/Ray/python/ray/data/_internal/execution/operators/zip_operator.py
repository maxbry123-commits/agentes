import collections
import itertools
from dataclasses import replace
from typing import TYPE_CHECKING, List, Optional, Tuple

from typing_extensions import override

import ray
from ray.data._internal.delegating_block_builder import DelegatingBlockBuilder
from ray.data._internal.execution.bundle_queue import BaseBundleQueue, FIFOBundleQueue
from ray.data._internal.execution.interfaces import (
    BlockEntry,
    PhysicalOperator,
    RefBundle,
)
from ray.data._internal.execution.operators.base_physical_operator import (
    InternalQueueOperatorMixin,
    NAryOperator,
)
from ray.data._internal.remote_fn import cached_remote_fn
from ray.data._internal.split import _split_at_indices
from ray.data._internal.stats import StatsDict
from ray.data.block import (
    Block,
    BlockAccessor,
    BlockExecStats,
    to_stats,
)
from ray.data.context import DataContext

if TYPE_CHECKING:

    from ray.data.block import BlockMetadataWithSchema


class ZipOperator(InternalQueueOperatorMixin, NAryOperator):
    """An operator that zips its inputs together.

    NOTE: the implementation is bulk for now, which materializes all its inputs in
    object store, before starting execution. Should re-implement it as a streaming
    operator in the future.
    """

    def __init__(
        self,
        data_context: DataContext,
        *input_ops: PhysicalOperator,
    ):
        """Create a ZipOperator.

        Args:
            data_context: The :class:`DataContext` to use for this operator.
            *input_ops: Operators generating input data for this operator to zip.
        """
        assert len(input_ops) >= 2
        self._input_buffers: List[FIFOBundleQueue] = [
            FIFOBundleQueue() for _ in range(len(input_ops))
        ]
        self._output_buffer: FIFOBundleQueue = FIFOBundleQueue()
        self._stats: StatsDict = {}
        super().__init__(
            data_context,
            *input_ops,
        )

    @property
    @override
    def _input_queues(self) -> List["BaseBundleQueue"]:
        return self._input_buffers

    @property
    @override
    def _output_queues(self) -> List["BaseBundleQueue"]:
        return [self._output_buffer]

    def num_outputs_total(self) -> Optional[int]:
        num_outputs = None
        for input_op in self.input_dependencies:
            input_num_outputs = input_op.num_outputs_total()
            if input_num_outputs is None:
                continue
            if num_outputs is None:
                num_outputs = input_num_outputs
            else:
                num_outputs = max(num_outputs, input_num_outputs)
        return num_outputs

    def num_output_rows_total(self) -> Optional[int]:
        num_rows = None
        for input_op in self.input_dependencies:
            input_num_rows = input_op.num_output_rows_total()
            if input_num_rows is None:
                continue
            if num_rows is None:
                num_rows = input_num_rows
            else:
                num_rows = max(num_rows, input_num_rows)
        return num_rows

    def _add_input_inner(self, refs: RefBundle, input_index: int) -> None:
        assert not self.has_completed()
        assert 0 <= input_index <= len(self._input_dependencies), input_index
        self._input_buffers[input_index].add(refs)
        self._metrics.on_input_queued(refs, input_index=input_index)

    def all_inputs_done(self) -> None:
        assert len(self._output_buffer) == 0, len(self._output_buffer)

        # Start with the first input buffer
        while self._input_buffers[0].has_next():
            refs = self._input_buffers[0].get_next()
            self._output_buffer.add(refs)
            self._metrics.on_input_dequeued(refs, input_index=0)

        # Process each additional input buffer
        for idx, input_buffer in enumerate(self._input_buffers[1:], start=1):
            output_buffer, self._stats = self._zip(self._output_buffer, input_buffer)
            self._output_buffer = FIFOBundleQueue(bundles=output_buffer)

            # Clear the input buffer AFTER using it in _zip
            while input_buffer.has_next():
                refs = input_buffer.get_next()
                self._metrics.on_input_dequeued(refs, input_index=idx)

        # Zipping creates new blocks; register them for memory tracking.
        for ref in self._output_buffer:
            for entry in ref.blocks:
                self._block_ref_counter.on_block_produced(
                    entry.ref, entry.metadata.size_bytes or 0, self.id
                )
            self._metrics.on_output_queued(ref)

        super().all_inputs_done()

    def has_next(self) -> bool:
        return len(self._output_buffer) > 0

    def _get_next_inner(self) -> RefBundle:
        refs = self._output_buffer.get_next()
        self._metrics.on_output_dequeued(refs)
        return refs

    def get_stats(self) -> StatsDict:
        return self._stats

    def throttling_disabled(self) -> bool:
        # TODO revert once zip becomes streaming
        return True

    def _zip(
        self,
        left_input: FIFOBundleQueue,
        right_input: FIFOBundleQueue,
    ) -> Tuple[collections.deque[RefBundle], StatsDict]:
        """Zip the RefBundles from `left_input` and `right_input` together.

        Zip is done in 2 steps: aligning blocks, and zipping blocks from
        both sides.

        Aligning blocks (optional): check the blocks from `left_input` and
        `right_input` are aligned or not, i.e. if having different number of blocks, or
        having different number of rows in some blocks. If not aligned, repartition the
        smaller input with `_split_at_indices` to align with larger input.

        Zipping blocks: after blocks from both sides are aligned, zip
        blocks from both sides together in parallel.
        """
        left_entries: List[BlockEntry] = []
        for bundle in left_input:
            left_entries.extend(bundle.blocks)
        right_entries: List[BlockEntry] = []
        for bundle in right_input:
            right_entries.extend(bundle.blocks)

        left_block_rows, left_block_bytes = self._calculate_blocks_rows_and_bytes(
            left_entries
        )
        right_block_rows, right_block_bytes = self._calculate_blocks_rows_and_bytes(
            right_entries
        )

        # Check that both sides have the same number of rows.
        # TODO(Clark): Support different number of rows via user-directed
        # dropping/padding.
        total_left_rows = sum(left_block_rows)
        total_right_rows = sum(right_block_rows)
        if total_left_rows != total_right_rows:
            raise ValueError(
                "Cannot zip datasets of different number of rows: "
                f"{total_left_rows}, {total_right_rows}"
            )

        # Whether the left and right input sides are inverted
        input_side_inverted = False
        if sum(right_block_bytes) > sum(left_block_bytes):
            # Make sure that right side is smaller, so we minimize splitting
            # work when aligning both sides.
            # TODO(Clark): Improve this heuristic for minimizing splitting work,
            # e.g. by generating the splitting plans for each route (via
            # _generate_per_block_split_indices) and choosing the plan that splits
            # the least cumulative bytes.
            left_entries, right_entries = right_entries, left_entries
            left_block_rows, right_block_rows = right_block_rows, left_block_rows
            input_side_inverted = True

        # Get the split indices that will align both sides.
        indices = list(itertools.accumulate(left_block_rows))
        indices.pop(-1)

        # Split other at the alignment indices, such that for every block from
        # left side, we have a list of blocks from right side that have the same
        # cumulative number of rows as that left block.
        # NOTE: _split_at_indices has a no-op fastpath if the blocks are already
        # aligned.
        label_selector = self.data_context.execution_options.label_selector
        aligned_right_blocks_with_metadata = _split_at_indices(
            [(e.ref, e.metadata) for e in right_entries],
            indices,
            block_rows=right_block_rows,
            label_selector=label_selector,
        )
        del right_entries

        left_blocks = [e.ref for e in left_entries]
        right_blocks_list = aligned_right_blocks_with_metadata[0]
        del left_entries, aligned_right_blocks_with_metadata

        zip_one_block = cached_remote_fn(_zip_one_block, num_returns=2)
        if label_selector:
            zip_one_block = zip_one_block.options(label_selector=label_selector)

        output_blocks = []
        output_metadata_schema = []
        for left_block, right_blocks in zip(left_blocks, right_blocks_list):
            # For each block from left side, zip it together with 1 or more blocks from
            # right side. We're guaranteed to have that left_block has the same number
            # of rows as right_blocks has cumulatively.
            res, meta_with_schema = zip_one_block.remote(
                left_block, *right_blocks, inverted=input_side_inverted
            )
            output_blocks.append(res)
            output_metadata_schema.append(meta_with_schema)

        # Early release memory.
        del left_blocks, right_blocks_list

        # TODO(ekl) it might be nice to have a progress bar here.
        output_metadata_schema: List[BlockMetadataWithSchema] = ray.get(
            output_metadata_schema
        )

        output_refs: collections.deque[RefBundle] = collections.deque()
        input_owned = all(b.owns_blocks for b in left_input)
        for block, meta_with_schema in zip(output_blocks, output_metadata_schema):
            output_refs.append(
                RefBundle(
                    [BlockEntry(block, meta_with_schema.metadata)],
                    owns_blocks=input_owned,
                    schema=meta_with_schema.schema,
                )
            )
        stats = {self._name: to_stats(output_metadata_schema)}

        # Clean up inputs.
        for ref in left_input:
            ref.destroy_if_owned()
        for ref in right_input:
            ref.destroy_if_owned()

        return output_refs, stats

    def _calculate_blocks_rows_and_bytes(
        self,
        entries: List[BlockEntry],
    ) -> Tuple[List[int], List[int]]:
        """Calculate the number of rows and size in bytes for a list of blocks with
        metadata.
        """
        get_num_rows_and_bytes = cached_remote_fn(_get_num_rows_and_bytes)
        label_selector = self.data_context.execution_options.label_selector
        if label_selector:
            get_num_rows_and_bytes = get_num_rows_and_bytes.options(
                label_selector=label_selector
            )
        block_rows = []
        block_bytes = []
        for entry in entries:
            metadata = entry.metadata
            if metadata.num_rows is None or metadata.size_bytes is None:
                # Need to fetch number of rows or size in bytes, so just fetch both.
                num_rows, size_bytes = ray.get(get_num_rows_and_bytes.remote(entry.ref))
                # Cache on the block metadata.
                metadata = replace(metadata, num_rows=num_rows, size_bytes=size_bytes)
            block_rows.append(metadata.num_rows)
            block_bytes.append(metadata.size_bytes)
        return block_rows, block_bytes


def _zip_one_block(
    block: Block, *other_blocks: Block, inverted: bool = False
) -> Tuple[Block, "BlockMetadataWithSchema"]:
    """Zip together `block` with `other_blocks`."""
    stats = BlockExecStats.builder()
    # Concatenate other blocks.
    # TODO(Clark): Extend BlockAccessor.zip() to work with N other blocks,
    # so we don't need to do this concatenation.
    builder = DelegatingBlockBuilder()
    for other_block in other_blocks:
        builder.add_block(other_block)
    other_block = builder.build()
    if inverted:
        # Swap blocks if ordering was inverted during block alignment splitting.
        block, other_block = other_block, block
    # Zip block and other blocks.
    result = BlockAccessor.for_block(block).zip(other_block)
    from ray.data.block import BlockMetadataWithSchema

    return result, BlockMetadataWithSchema.from_block(
        result, block_exec_stats=stats.build()
    )


def _get_num_rows_and_bytes(block: Block) -> Tuple[int, int]:
    block = BlockAccessor.for_block(block)
    return block.num_rows(), block.size_bytes()
