import copy
import functools
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

import ray
import ray.exceptions
from .base_autoscaling_coordinator import (
    AutoscalingCoordinator,
    LabelKey,
    LabelSelector,
    LabelValue,
    RequesterId,
    ResourceDict,
    ResourceRequestPriority,
)
from ray._common.utils import env_bool
from ray.data._internal.execution.util import memory_string
from ray.util.scheduling_strategies import NodeAffinitySchedulingStrategy

logger = logging.getLogger(__name__)

HEAD_NODE_RESOURCE_LABEL = "node:__internal_head__"
_RESOURCE_LOG_KEYS = ("CPU", "GPU", "memory", "object_store_memory")
_RESOURCE_LOG_MEMORY_KEYS = {"memory", "object_store_memory"}
# Label key the cluster autoscaler uses to bucket nodes by subcluster.
# Hardcoded so all components agree without per-Dataset configuration.
SUBCLUSTER_LABEL_KEY: LabelKey = "ray-subcluster"
# Sentinel for "no subcluster" — used as both a node-label fallback and
# the bucket key for unlabeled nodes in ``_cluster_node_resources``.
DEFAULT_SUBCLUSTER: Optional[LabelValue] = None


RAY_DATA_AUTOSCALING_COORDINATOR_LOG_TRACEBACK = env_bool(
    "RAY_DATA_AUTOSCALING_COORDINATOR_LOG_TRACEBACK", True
)


def _format_resource_value_for_log(resource_name: str, value: float) -> str:
    """Format a numerical resource value to a human-readable string.

    Args:
        resource_name: The resource name.
        value: The resource value.

    Returns:
        A human-readable string.
    """
    if resource_name in _RESOURCE_LOG_MEMORY_KEYS:
        return memory_string(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _format_resource_bundle_for_log(bundle: ResourceDict) -> str:
    """Format a resource bundle to a human-readable string.

    Drops custom resource keys (e.g. ``anyscale/...``, ``node:...``) and
    zero-valued resources, keeping only the standard keys in ``_RESOURCE_LOG_KEYS``.

    Args:
        bundle: The resource bundle to format.

    Returns:
        A human-readable string, e.g. ``"{CPU: 8, memory: 32.0GiB}"``.

    Example:
        >>> from ray.data._internal.util import GiB
        >>> _format_resource_bundle_for_log({"CPU": 8, "GPU": 0, "memory": 32 * GiB})
        '{CPU: 8, memory: 32.0GiB}'
    """
    resources = []
    for resource_name in _RESOURCE_LOG_KEYS:
        value = bundle.get(resource_name, 0)
        if value == 0:
            continue
        resources.append(
            f"{resource_name}: {_format_resource_value_for_log(resource_name, value)}"
        )
    return "{" + ", ".join(resources) + "}"


def _format_resources_for_log(resources: List[ResourceDict]) -> str:
    """Format and aggregate resource bundles for logging.

    Bundles that format to the same string (after dropping custom/zero-valued
    resources) are collapsed into a single ``N x {...}`` entry.

    Args:
        resources: The resource bundles to format.

    Returns:
        A human-readable string, e.g. ``"[2 x {CPU: 1}, 1 x {GPU: 1}]"``.

    Example:
        >>> _format_resources_for_log([{"CPU": 1}, {"CPU": 1}, {"GPU": 1}])
        '[2 x {CPU: 1}, 1 x {GPU: 1}]'
    """
    bundle_counts: Dict[str, int] = {}
    for resource in resources:
        bundle = _format_resource_bundle_for_log(resource)
        if bundle == "{}":
            continue
        bundle_counts[bundle] = bundle_counts.get(bundle, 0) + 1

    return (
        "["
        + ", ".join(f"{count} x {bundle}" for bundle, count in bundle_counts.items())
        + "]"
    )


@dataclass
class OngoingRequest:
    """Represents an ongoing resource request from a requester."""

    # The time when the request was first received.
    first_request_time: float
    # Requested resources.
    requested_resources: List[ResourceDict]
    # The expiration time of the request.
    expiration_time: float
    # If true, after reserving requested resources to each requester,
    # remaining resources will also be reserved to this requester.
    request_remaining: bool
    # The priority of the request, higher value means higher priority.
    priority: int
    # Resources that are already reserved to the requester.
    reserved_resources: List[ResourceDict]
    # Per-bundle label selectors, parallel to ``requested_resources``.
    # Empty dicts mean no label constraint on that bundle. Required to have
    # the same length as ``requested_resources``.
    requested_label_selectors: List[LabelSelector]

    def __lt__(self, other):
        """Used to sort requests when reserving resources.

        Higher priority first, then earlier first_request_time first.
        """
        if self.priority != other.priority:
            return self.priority > other.priority
        return self.first_request_time < other.first_request_time


class DefaultAutoscalingCoordinator(AutoscalingCoordinator):
    """Non-blocking client-side proxy for the _AutoscalingCoordinatorActor.

    Not thread-safe; all methods must be called from a single thread.

    Create one instance per requester. Multiple instances sharing the same
    ``requester_id`` will have diverging caches and break the FIFO ordering
    guarantee that ``request_resources`` and ``get_reserved_resources`` rely on.
    """

    def __init__(
        self,
        requester_id: RequesterId,
        autoscaling_coordinator_actor=None,  # For testing only: injects an actor instead of using the shared named singleton.
        subcluster_selector: Optional[LabelSelector] = None,
    ):
        self._requester_id = requester_id
        # Label selector keyed by ``SUBCLUSTER_LABEL_KEY`` pinning this
        # requester to a single subcluster.
        self._subcluster_selector = subcluster_selector
        self._cached_reserved_resources: List[ResourceDict] = []
        # In-flight get_reserved_resources ref, or None if no request is pending.
        self._pending_reserved_resources: Optional[ray.ObjectRef] = None
        if autoscaling_coordinator_actor is not None:
            # Bypass the cached_property by injecting the actor directly.
            # Used in tests to avoid the shared named actor.
            self.__dict__["_autoscaling_coordinator"] = autoscaling_coordinator_actor

    @functools.cached_property
    def _autoscaling_coordinator(self):
        # Lazy: avoids creating the actor in __init__.
        return get_or_create_autoscaling_coordinator()

    def request_resources(
        self,
        resources: List[ResourceDict],
        expire_after_s: float,
        request_remaining: bool = False,
        priority: ResourceRequestPriority = ResourceRequestPriority.MEDIUM,
        label_selectors: Optional[List[LabelSelector]] = None,
    ) -> None:
        """Fire-and-forget: submit a resource request to the coordinator actor.

        Actor-side errors are not surfaced to the caller.
        """
        self._autoscaling_coordinator.request_resources.remote(
            requester_id=self._requester_id,
            resources=resources,
            expire_after_s=expire_after_s,
            request_remaining=request_remaining,
            priority=priority,
            label_selectors=label_selectors,
            subcluster_selector=self._subcluster_selector,
        )

    def cancel_request(self) -> None:
        """Fire-and-forget: cancel a resource request on the coordinator actor.

        Also clears client-side state (pending ref and cached reservation) so
        a subsequent ``get_reserved_resources`` call returns a fresh result
        rather than stale data from a prior pipeline run.
        """
        self._pending_reserved_resources = None
        self._cached_reserved_resources = []
        self._autoscaling_coordinator.cancel_request.remote(self._requester_id)

    def get_reserved_resources(self) -> List[ResourceDict]:
        """Return reserved resources without blocking.

        Submits an async RPC and immediately returns the last cached result.
        The cache is updated the next time the pending RPC completes.

        Because the actor processes calls in FIFO order, the result always
        reflects state after all previously submitted ``request_resources`` calls
        to the same actor.

        On actor errors, returns the cached value and logs a warning; never raises.
        """
        ref = self._pending_reserved_resources
        if ref is not None:
            ready, _ = ray.wait([ref], timeout=0)
            if ready:
                self._pending_reserved_resources = None
                try:
                    self._cached_reserved_resources = ray.get(ref, timeout=0)
                except ray.exceptions.RayError:
                    logger.warning(
                        f"Failed to get reserved resources for {self._requester_id};"
                        " falling back to the cached value."
                        " If this persists, file a GitHub issue.",
                        exc_info=RAY_DATA_AUTOSCALING_COORDINATOR_LOG_TRACEBACK,
                    )

        # Submit a new request if none is currently in-flight
        # (first call, or the previous request completed or errored).
        if self._pending_reserved_resources is None:
            self._pending_reserved_resources = (
                self._autoscaling_coordinator.get_reserved_resources.remote(
                    self._requester_id,
                )
            )

        return self._cached_reserved_resources


def _default_send_resources_request(
    bundles: List[ResourceDict],
    label_selectors: Optional[List[LabelSelector]] = None,
) -> None:
    """Default ``send_resources_request`` implementation for the actor."""
    ray.autoscaler.sdk.request_resources(
        bundles=bundles, bundle_label_selectors=label_selectors
    )


class _AutoscalingCoordinatorActor:
    """An actor to coordinate autoscaling resource requests from different components.

    This actor is responsible for:
    * Merging received requests and dispatching them to Ray Autoscaler.
    * Reserving cluster resources to the requesters.
    """

    TICK_INTERVAL_S = 20

    def __init__(
        self,
        get_current_time: Callable[[], float] = time.time,
        send_resources_request: Callable[
            [List[ResourceDict], Optional[List[LabelSelector]]], None
        ] = _default_send_resources_request,
        get_cluster_nodes: Callable[[], List[Dict]] = ray.nodes,
    ):
        self._get_current_time = get_current_time
        self._send_resources_request = send_resources_request
        self._get_cluster_nodes = get_cluster_nodes

        self._ongoing_reqs: Dict[RequesterId, OngoingRequest] = {}
        # Map from requester id to its subcluster selector.
        self._subcluster_selectors: Dict[RequesterId, Optional[LabelSelector]] = {}
        # Node resources bucketed by their ``SUBCLUSTER_LABEL_KEY`` value.
        # Nodes without the key fall under ``DEFAULT_SUBCLUSTER``.
        self._cluster_node_resources: Dict[
            Optional[LabelValue], List[ResourceDict]
        ] = {}
        # Lock for thread-safe access to shared state from the background
        self._lock = threading.Lock()
        self._update_cluster_node_resources()

        # This is an actor, so the following check should always be True.
        # It's only needed for unit tests.
        if ray.is_initialized():
            # Start a thread to perform periodical operations.
            def tick_thread_run():
                while True:
                    time.sleep(self.TICK_INTERVAL_S)
                    self._tick()

            self._tick_thread = threading.Thread(target=tick_thread_run, daemon=True)
            self._tick_thread.start()

    def _tick(self):
        """Used to perform periodical operations, e.g., purge expired requests,
        merge and send requests, check cluster resource updates, etc."""
        with self._lock:
            self._merge_and_send_requests()
            self._update_cluster_node_resources()
            self._rereserve_resources()

    def request_resources(
        self,
        requester_id: RequesterId,
        resources: List[ResourceDict],
        expire_after_s: float,
        request_remaining: bool = False,
        priority: ResourceRequestPriority = ResourceRequestPriority.MEDIUM,
        label_selectors: Optional[List[LabelSelector]] = None,
        subcluster_selector: Optional[LabelSelector] = None,
    ) -> None:
        logger.debug(
            "Received request from %s: %s "
            "(label_selectors=%s, subcluster_selector=%s).",
            requester_id,
            resources,
            label_selectors,
            subcluster_selector,
        )
        if label_selectors is None:
            label_selectors = [{} for _ in resources]
        elif len(label_selectors) != len(resources):
            raise ValueError(
                f"label_selectors length ({len(label_selectors)}) must match "
                f"resources length ({len(resources)})."
            )
        if subcluster_selector and label_selectors:
            req_subcluster = subcluster_selector.get(SUBCLUSTER_LABEL_KEY)
            for i, sel in enumerate(label_selectors):
                bundle_subcluster = sel.get(SUBCLUSTER_LABEL_KEY)
                if (
                    bundle_subcluster is not None
                    and bundle_subcluster != req_subcluster
                ):
                    raise ValueError(
                        f"Bundle {i} label_selector targets subcluster "
                        f"{bundle_subcluster!r}, but requester is registered to "
                        f"{req_subcluster!r}. Per-bundle cross-subcluster "
                        f"reservation is not supported."
                    )
        with self._lock:
            now = self._get_current_time()
            request_updated = False
            old_req = self._ongoing_reqs.get(requester_id)
            if old_req is not None:
                if request_remaining != old_req.request_remaining:
                    raise ValueError(
                        "Cannot change request_remaining flag of an ongoing request."
                    )
                if priority.value != old_req.priority:
                    raise ValueError("Cannot change priority of an ongoing request.")
                if (
                    requester_id in self._subcluster_selectors
                    and self._subcluster_selectors[requester_id] != subcluster_selector
                ):
                    raise ValueError(
                        "Cannot change subcluster_selector of an ongoing request "
                        f"from {self._subcluster_selectors[requester_id]!r} to "
                        f"{subcluster_selector!r}."
                    )

                request_updated = (
                    resources != old_req.requested_resources
                    or label_selectors != old_req.requested_label_selectors
                )
                old_req.requested_resources = resources
                old_req.requested_label_selectors = label_selectors
                old_req.expiration_time = now + expire_after_s
            else:
                request_updated = True
                self._ongoing_reqs[requester_id] = OngoingRequest(
                    first_request_time=now,
                    requested_resources=resources,
                    requested_label_selectors=label_selectors,
                    request_remaining=request_remaining,
                    priority=priority.value,
                    expiration_time=now + expire_after_s,
                    reserved_resources=[],
                )
            # Write subcluster after all validations so a rejected call
            # never leaves the registry on a new subcluster.
            self._subcluster_selectors[requester_id] = subcluster_selector
            if request_updated:
                # If the request has updated, immediately send
                # a new request and rereserve resources.
                self._merge_and_send_requests()
                self._rereserve_resources()

    def cancel_request(
        self,
        requester_id: RequesterId,
    ):
        logger.debug("Canceling request for %s.", requester_id)
        with self._lock:
            if requester_id not in self._ongoing_reqs:
                return
            del self._ongoing_reqs[requester_id]
            self._subcluster_selectors.pop(requester_id, None)
            self._merge_and_send_requests()
            self._rereserve_resources()

    def _purge_expired_requests(self):
        now = self._get_current_time()
        live = {
            requester_id: req
            for requester_id, req in self._ongoing_reqs.items()
            if req.expiration_time > now
        }
        for expired_id in self._ongoing_reqs.keys() - live.keys():
            self._subcluster_selectors.pop(expired_id, None)
        self._ongoing_reqs = live

    def _merge_and_send_requests(self):
        """Merge requests and send them to Ray Autoscaler.

        Each bundle's forwarded selector is the union of its per-bundle
        ``requested_label_selectors`` entry and the requester's
        ``subcluster_selector``. The subcluster pin wins on key conflict,
        so the autoscaler always sees the correct subcluster regardless
        of what the per-bundle selectors contain.
        """
        self._purge_expired_requests()
        merged_req: List[ResourceDict] = []
        merged_selectors: List[LabelSelector] = []
        for requester_id, req in self._ongoing_reqs.items():
            merged_req.extend(req.requested_resources)
            subcluster_selector = self._subcluster_selectors.get(requester_id) or {}
            for per_bundle in req.requested_label_selectors:
                merged_selectors.append({**per_bundle, **subcluster_selector})
        if any(merged_selectors):
            self._send_resources_request(merged_req, label_selectors=merged_selectors)
        else:
            self._send_resources_request(merged_req)

    def get_reserved_resources(self, requester_id: RequesterId) -> List[ResourceDict]:
        """Get the reserved resources for the requester."""
        with self._lock:
            if requester_id not in self._ongoing_reqs:
                return []
            return self._ongoing_reqs[requester_id].reserved_resources

    def _maybe_subtract_resources(self, res1: ResourceDict, res2: ResourceDict) -> bool:
        """If res2<=res1, subtract res2 from res1 in-place, and return True.
        Otherwise return False."""
        if any(res1.get(key, 0) < res2[key] for key in res2):
            return False
        for key in res2:
            if key in res1:
                res1[key] -= res2[key]
        return True

    def _update_cluster_node_resources(self) -> bool:
        """Update cluster resources bucketed by subcluster. Return True if changed."""

        def _is_node_eligible(node):
            # Exclude dead nodes.
            if not node["Alive"]:
                return False
            resources = node["Resources"]
            # Exclude the head node if it doesn't have CPUs and GPUs,
            # because the object store is not usable.
            if HEAD_NODE_RESOURCE_LABEL in resources and (
                resources.get("CPU", 0) == 0 and resources.get("GPU", 0) == 0
            ):
                return False
            return True

        nodes = list(filter(_is_node_eligible, self._get_cluster_nodes()))
        nodes = sorted(nodes, key=lambda node: node.get("NodeID", ""))
        cluster_node_resources: Dict[Optional[LabelValue], List[ResourceDict]] = {}
        for node in nodes:
            # Safeguard against case where the value of Labels is None.
            labels = node.get("Labels") or {}
            subcluster = labels.get(SUBCLUSTER_LABEL_KEY, DEFAULT_SUBCLUSTER)
            cluster_node_resources.setdefault(subcluster, []).append(node["Resources"])
        if cluster_node_resources == self._cluster_node_resources:
            return False
        logger.debug("Cluster resources updated: %s.", cluster_node_resources)
        self._cluster_node_resources = cluster_node_resources
        return True

    def _rereserve_resources(self):
        """Rereserve cluster resources.

        Each requester's subcluster comes from its ``subcluster_selector``.
        A requester without one is eligible only for the ``None`` bucket.
        """
        now = self._get_current_time()
        cluster_node_resources: Dict[
            Optional[LabelValue], List[ResourceDict]
        ] = copy.deepcopy(self._cluster_node_resources)
        live_items = [
            (req_id, req)
            for req_id, req in self._ongoing_reqs.items()
            if req.expiration_time >= now
        ]
        live_items.sort(key=lambda item: item[1])

        def _subcluster_of(requester_id: RequesterId) -> Optional[LabelValue]:
            selector = self._subcluster_selectors.get(requester_id)
            return (selector or {}).get(SUBCLUSTER_LABEL_KEY, DEFAULT_SUBCLUSTER)

        # TODO(hchen): Optimize the following triple loop.
        for requester_id, ongoing_req in live_items:
            ongoing_req.reserved_resources = []
            subcluster = _subcluster_of(requester_id)
            for bundle in ongoing_req.requested_resources:
                for node_resource in cluster_node_resources.get(subcluster, []):
                    if self._maybe_subtract_resources(node_resource, bundle):
                        ongoing_req.reserved_resources.append(bundle)
                        break

        # Reserve remaining resources. Multiple concurrent requesters in
        # the same subcluster split that subcluster's leftovers equally.
        remaining_items = [
            (req_id, req) for req_id, req in live_items if req.request_remaining
        ]
        for subcluster, node_resources in cluster_node_resources.items():
            eligible = [
                req
                for req_id, req in remaining_items
                if _subcluster_of(req_id) == subcluster
            ]
            if not eligible:
                continue
            for node_resource in node_resources:
                # Integer division may leave some resources unreserved.
                divided = {k: v // len(eligible) for k, v in node_resource.items()}
                if not any(v > 0 for v in divided.values()):
                    continue
                for r in eligible:
                    r.reserved_resources.append(divided)

        if logger.isEnabledFor(logging.DEBUG):
            msg = "Reserved resources:\n"
            for requester_id, ongoing_req in self._ongoing_reqs.items():
                reserved_resources_log_str = _format_resources_for_log(
                    ongoing_req.reserved_resources
                )
                msg += f"Requester {requester_id}: {reserved_resources_log_str}\n"
            logger.debug(msg)


_get_or_create_lock = threading.Lock()


def get_or_create_autoscaling_coordinator():
    """Get or create the AutoscalingCoordinator actor."""
    # Create the actor on the local node,
    # to reduce network overhead.
    scheduling_strategy = NodeAffinitySchedulingStrategy(
        ray.get_runtime_context().get_node_id(),
        soft=False,
    )
    actor_cls = ray.remote(num_cpus=0, max_restarts=-1, max_task_retries=-1)(
        _AutoscalingCoordinatorActor
    ).options(
        name="AutoscalingCoordinator",
        namespace="AutoscalingCoordinator",
        get_if_exists=True,
        lifetime="detached",
        scheduling_strategy=scheduling_strategy,
    )
    # NOTE: Need the following lock, because Ray Core doesn't allow creating the same
    # actor from multiple threads simultaneously.
    with _get_or_create_lock:
        return actor_cls.remote()
