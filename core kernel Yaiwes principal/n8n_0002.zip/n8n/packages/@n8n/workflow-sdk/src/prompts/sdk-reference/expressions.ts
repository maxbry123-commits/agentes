/**
 * Expression context reference — documents variables available inside expr()
 *
 * Consumed by:
 * - Code Builder Agent (ai-workflow-builder.ee)
 * - MCP Server (external SDK reference)
 * - Instance AI workflow-builder skill
 */
export const EXPRESSION_REFERENCE = `Available variables inside \`expr('{{ ... }}')\`:

- \`$json\` — current item's JSON data from the immediate predecessor node only
- \`$('NodeName').item.json\` — access the output item from another node that is paired with the current item
- \`nodeJson(node, 'field.path')\` — SDK helper equivalent to \`expr('{{ $("NodeName").item.json.field.path }}')\`
- \`$input.first()\` — first item from immediate predecessor
- \`$input.all()\` — all items from immediate predecessor
- \`$input.item\` — current item being processed
- \`$binary\` — binary data of current item from immediate predecessor
- \`$now\` — current date/time (Luxon DateTime). Example: \`$now.toISO()\`
- \`$today\` — start of today (Luxon DateTime). Example: \`$today.plus(1, 'days')\`
- \`$itemIndex\` — index of current item being processed
- \`$runIndex\` — current run index
- \`$execution.id\` — unique execution ID
- \`$execution.mode\` — 'test' or 'production'
- \`$workflow.id\` — workflow ID
- \`$workflow.name\` — workflow name

String composition — variables MUST always be inside \`{{ }}\`, never outside as JS variables:

- \`expr('Hello {{ $json.name }}, welcome!')\` — variable embedded in text
- \`expr('Report for {{ $now.toFormat("MMMM d, yyyy") }} - {{ $json.title }}')\` — multiple variables with method call
- \`expr('{{ $json.firstName }} {{ $json.lastName }}')\` — combining multiple fields
- \`expr('Total: {{ $json.items.length }} items, updated {{ $now.toISO() }}')\` — expressions with method calls
- \`expr('Status: {{ $json.count > 0 ? "active" : "empty" }}')\` — inline ternary

Dynamic data from other nodes — \`$()\` MUST always be inside \`{{ }}\`, never used as plain JavaScript:

- WRONG: \`expr('{{ ' + JSON.stringify($('Source').all().map(i => i.json.name)) + ' }}')\` — $() outside {{ }}
- CORRECT: \`expr('{{ $("Source").all().map(i => ({ option: i.json.name })) }}')\` — $() inside {{ }}
- CORRECT: \`expr('{{ { "fields": [{ "values": $("Fetch Projects").all().map(i => ({ option: i.json.name })) }] } }}')\` — complex JSON inside {{ }}

Item flow semantics — choose the reference that matches the current item:

- Use \`$('NodeName').item.json.field\` or \`nodeJson(sourceNode, 'field')\` when the current node needs the value from the same paired item produced upstream.
- Do NOT use \`.first()\` or \`$input.first()\` for per-item data in a multi-item workflow. \`.first()\` always reads item 0, so every downstream item reuses the first value.
- Use \`.first()\` only when the workflow genuinely needs one global first item, such as a single configuration row.
- If an upstream value is needed after another node replaces item JSON, reference the upstream node explicitly with \`$('Extract Data').item.json.field\`; do not expect the value to still exist on \`$json\`.

When \`$json\` is unsafe - use \`nodeJson(node, 'path')\` or \`$('NodeName').item.json.path\` instead:

- AI Agent subnodes: memory, language model, parser, retriever, vector store, and tool subnodes do not have the same immediate predecessor context as a main-flow node.
  WRONG: \`sessionKey: expr('{{ $json.chatId }}')\`
  CORRECT: \`sessionKey: nodeJson(telegramTrigger, 'message.chat.id')\`
- Multi-branch fan-in: if a node receives data after IF/Switch/Merge-style branching, \`$json\` only means the current incoming item and may not contain the source field you need.
  WRONG: \`expr('{{ $json.userId }}')\`
  CORRECT: \`nodeJson(userLookup, 'user.id')\`
- Replacing nodes: if the current output no longer contains a field extracted earlier, read the earlier node directly.
  WRONG: \`expr('{{ $json.eventId }}')\`
  CORRECT: \`nodeJson(extractEventId, 'eventId')\`
- Further-upstream data: if the value comes from any node other than the immediate main predecessor, reference that node explicitly.
  WRONG: \`expr('{{ $json.email }}')\`
  CORRECT: \`nodeJson(formTrigger, 'body.email')\``;
