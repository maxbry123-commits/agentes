STALE = "initial"
