from __future__ import annotations

from pydantic import BaseModel, RootModel

from . import models


class OptionalModel(RootModel[str]):
    root: str


class Id(RootModel[str]):
    root: str


class Error(BaseModel):
    code: int
    message: str


class Result(BaseModel):
    event: models.Event | None = None


class Source(BaseModel):
    country: str | None = None


class DifferentTea(BaseModel):
    foo: Tea | None = None
    nested: Tea_1 | None = None


class Tea(BaseModel):
    flavour: str | None = None
    id: Id | None = None


class Cocoa(BaseModel):
    quality: int | None = None


class Tea_1(BaseModel):
    flavour: str | None = None
    id: Id | None = None
    self: Tea_1 | None = None
    optional: list[OptionalModel] | None = None


class TeaClone(BaseModel):
    flavour: str | None = None
    id: Id | None = None
    self: Tea_1 | None = None
    optional: list[OptionalModel] | None = None


class ListModel(RootModel[list[Tea_1]]):
    root: list[Tea_1]


Tea_1.model_rebuild()
