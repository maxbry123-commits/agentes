from __future__ import annotations

from datetime import date
from typing import Dict, List, Optional, Union

from pydantic import BaseModel, RootModel, constr


class Pet(BaseModel):
    id: int
    name: str
    tag: Optional[str] = None


class Car(BaseModel):
    id: int
    name: str
    tag: Optional[str] = None


class OneOfItem1(BaseModel):
    name: Optional[str] = None


class OneOfItem(RootModel[Union[Pet, Car, OneOfItem1, constr(max_length=5000)]]):
    root: Union[Pet, Car, OneOfItem1, constr(max_length=5000)]


class Item(BaseModel):
    name: Optional[str] = None


class OneOfobj(BaseModel):
    item: Optional[Union[Pet, Car, Item, constr(max_length=5000)]] = None


class OneOfArray1(BaseModel):
    name: Optional[str] = None
    birthday: Optional[date] = None


class OneOfArray(
    RootModel[List[Union[Pet, Car, OneOfArray1, constr(max_length=5000)]]]
):
    root: List[Union[Pet, Car, OneOfArray1, constr(max_length=5000)]]


class Error(BaseModel):
    code: int
    message: str


class Config(BaseModel):
    setting: Optional[Dict[str, Union[str, List[str]]]] = None
