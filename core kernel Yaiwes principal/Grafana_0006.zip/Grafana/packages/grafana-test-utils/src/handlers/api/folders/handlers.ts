import { Chance } from 'chance';
import { HttpResponse, http, type HttpResponseResolver } from 'msw';

import { treeViewersCanEdit, wellFormedTree } from '../../../fixtures/folders';

const [mockTree, { folderB }] = wellFormedTree();
// folderD is included in mockTree and will be returned by the handlers with managedBy: 'repo'
const [mockTreeThatViewersCanEdit] = treeViewersCanEdit();
const collator = new Intl.Collator();

// TODO: Generalise access control response and additional properties
const mockAccessControl = {
  'dashboards.permissions:write': true,
  'dashboards:create': true,
  'folders:write': true,
};
const additionalProperties = {
  canAdmin: true,
  canDelete: true,
  canEdit: true,
  canSave: true,
  created: '2025-07-14T12:07:36+02:00',
  createdBy: 'Anonymous',
  hasAcl: false,
  orgId: 1,
  updated: '2025-07-15T18:01:36+02:00',
  updatedBy: 'Anonymous',
  url: '/grafana/dashboards/f/1ca93012-1ffc-5d64-ae2e-54835c234c67/rik-cujahda-pi',
  version: 1,
};

// from public/app/features/search/service/types.ts
interface NestedFolderDTO {
  uid: string;
  title: string;
}

export const minimalCustomFoldersHandler = (folders: NestedFolderDTO[]) =>
  http.get('/api/folders', ({ request }) => {
    return HttpResponse.json(folders);
  });

const listFoldersHandler = () =>
  http.get('/api/folders', ({ request }) => {
    const url = new URL(request.url);
    const parentUid = url.searchParams.get('parentUid') ?? undefined;
    const permission = url.searchParams.get('permission');

    const limit = parseInt(url.searchParams.get('limit') ?? '1000', 10);
    const page = parseInt(url.searchParams.get('page') ?? '1', 10);

    const tree = permission?.toLowerCase() === 'edit' ? mockTreeThatViewersCanEdit : mockTree;

    // reconstruct a folder API response from the flat tree fixture
    const folders = tree
      .filter((v) => v.item.kind === 'folder' && v.item.parentUID === parentUid)
      .map((folder) => {
        const random = Chance(folder.item.uid);
        return {
          id: random.integer({ min: 1, max: 1000 }),
          uid: folder.item.uid,
          title: folder.item.kind === 'folder' ? folder.item.title : "invalid - this shouldn't happen",
          ...('managedBy' in folder.item && folder.item.managedBy ? { managedBy: folder.item.managedBy } : {}),
        };
      })
      .sort((a, b) => collator.compare(a.title, b.title)) // API always sorts by title
      .slice(limit * (page - 1), limit * page);

    return HttpResponse.json(folders);
  });

const getFolderHandler = () =>
  http.get('/api/folders/:uid', ({ params, request }) => {
    const { uid } = params;
    const url = new URL(request.url);
    const accessControlQueryParam = url.searchParams.get('accesscontrol');

    const folder = mockTree.find((v) => v.item.uid === uid);

    if (!folder) {
      return HttpResponse.json({ message: 'folder not found', status: 'not-found' }, { status: 404 });
    }

    const random = Chance(folder.item.uid);

    return HttpResponse.json({
      id: random.integer({ min: 1, max: 1000 }),
      title: folder?.item.title,
      uid: folder?.item.uid,
      ...additionalProperties,
      ...(accessControlQueryParam ? { accessControl: mockAccessControl } : {}),
      ...('managedBy' in folder.item && folder.item.managedBy ? { managedBy: folder.item.managedBy } : {}),
    });
  });

const getFolderByIdHandler = () =>
  http.get('/api/folders/id/:id', ({ params }) => {
    const id = Number(params.id);
    // ids aren't stored in the tree fixture, so match by deriving them the same way listFoldersHandler does
    const folder = mockTree.find(
      (v) => v.item.kind === 'folder' && Chance(v.item.uid).integer({ min: 1, max: 1000 }) === id
    );

    if (!folder) {
      return HttpResponse.json({ message: 'folder not found', status: 'not-found' }, { status: 404 });
    }

    return HttpResponse.json({
      id,
      title: folder.item.title,
      uid: folder.item.uid,
      ...additionalProperties,
    });
  });

const createFolderHandler = () =>
  http.post<never, { title: string; parentUid?: string }>('/api/folders', async ({ request }) => {
    const body = await request.json();
    if (!body || !body.title) {
      return HttpResponse.json({ message: 'folder title cannot be empty' }, { status: 400 });
    }
    const random = Chance(body.title);
    const uid = random.string({ length: 10 });
    const id = random.integer({ min: 1, max: 1000 });

    return HttpResponse.json({
      id,
      uid: uid,
      orgId: 1,
      title: body.title,
      url: `/dashboards/f/${uid}/${body.title}`,
      hasAcl: false,
      canSave: true,
      canEdit: true,
      canAdmin: true,
      canDelete: true,
      parentUid: body.parentUid,
      createdBy: 'admin',
      created: '2025-08-26T12:19:27+01:00',
      updatedBy: 'admin',
      updated: '2025-08-26T12:19:27+01:00',
      version: 1,
    });
  });

const saveFolderHandler = () =>
  http.put<{ uid: string }, { title: string; version: number }>('/api/folders/:uid', async ({ params, request }) => {
    const { uid } = params;
    const body = await request.json();
    const folder = mockTree.find((v) => v.item.uid === uid);

    if (!folder) {
      return HttpResponse.json({ message: 'folder not found' }, { status: 404 });
    }

    return HttpResponse.json({ ...folder.item, title: body.title });
  });

const getMockFolderCounts = (folders: number, dashboards: number, library_elements: number, alertrules: number) => {
  return {
    folders,
    dashboards,
    library_elements,
    alertrules,
  };
};

export const customFolderCountsHandler = (resolver: HttpResponseResolver) =>
  http.get('/api/folders/:uid/counts', resolver);

const folderCountsHandler = () =>
  customFolderCountsHandler(async ({ params }) => {
    const { uid } = params;
    const folder = mockTree.find((v) => v.item.uid === uid);

    if (!folder) {
      // The legacy API returns 0's for a folder that doesn't exist 🤷‍♂️
      return HttpResponse.json(getMockFolderCounts(0, 0, 0, 0));
    }

    if (uid === folderB.item.uid) {
      return HttpResponse.json({}, { status: 500 });
    }

    return HttpResponse.json(getMockFolderCounts(1, 1, 1, 1));
  });

export const customCreateFolderHandler = (resolver: HttpResponseResolver) => http.post('/api/folders', resolver);

const handlers = [
  listFoldersHandler(),
  getFolderByIdHandler(),
  getFolderHandler(),
  createFolderHandler(),
  saveFolderHandler(),
  folderCountsHandler(),
];

export default handlers;
