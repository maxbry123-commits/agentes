/**
 * NOTE: This file was auto generated.  DO NOT EDIT DIRECTLY!
 * To change feature flags, edit:
 *  pkg/services/featuremgmt/registry.go
 * Then run:
 *  make gen-feature-toggles
 */

import {
  type ReactFlagEvaluationOptions,
  useFlag,
} from "@openfeature/react-sdk";

// Flag key constants for programmatic access
export const FlagKeys = {
  /** Enable manually starting an Assistant investigation from the alert instance drawer. */
  AlertingManualAssistantInvestigation: "alerting.manualAssistantInvestigation",
  /** Enable the alert quality tab, which surfaces the health of your alert rules and recommends actions to improve them. */
  AlertingRuleQuality: "alerting.ruleQuality",
  /** Automatically syncs external Alertmanager datasource configuration as ExtraConfiguration in Grafana */
  AlertingSyncExternalAlertmanager: "alerting.syncExternalAlertmanager",
  /** Enables new analytics framework */
  AnalyticsFramework: "analyticsFramework",
  /** Enables the assistant-powered Generate dashboard prompt and the plan card that approves the dashboard before it is built */
  AssistantDashboardPlanning: "assistant.dashboardPlanning",
  /** Enables the template dashboard assistant */
  AssistantFrontendToolsDashboardTemplates: "assistant.frontend.tools.dashboardTemplates",
  /** Enables the global fullscreen Workspace (Grafana Assistant workspace shell) in the top bar */
  AssistantFullscreenWorkspace: "assistant.fullscreenWorkspace",
  /** Generate a per-datasource external ID for Grafana Assume Role (jsonData.grafanaExternalId). When disabled, new datasources keep using the stack-level external ID. */
  AwsAssumeRolePerDatasourceExternalId: "awsAssumeRolePerDatasourceExternalId",
  /** Enable notebooks, a resource in the dashboard API group for mixing text cells, code cells, and visualization panels */
  DashboardNotebooks: "dashboard.notebooks",
  /** Load the Recently deleted dashboard list from the search API trash endpoint, instead of listing every deleted dashboard and filtering in the browser */
  DashboardRecentlyDeletedViaTrash: "dashboard.recentlyDeletedViaTrash",
  /** Exposes the semantic (vector) search endpoint for dashboards under the dashboard API */
  DashboardVectorSearch: "dashboard.vectorSearch",
  /** Enables the Assistant button in the dashboard templates card */
  DashboardTemplatesAssistantButton: "dashboardTemplatesAssistantButton",
  /** Use the new datasource API groups for datasource resource requests, frontend flag */
  DatasourcesApiserverUseNewAPIsForDatasourceResources: "datasources.apiserver.useNewAPIsForDatasourceResources",
  /** Enables the Metrics Batch API for the Azure Monitor data source, allowing up to 50 resources to be queried in a single request */
  DatasourcesAzureMonitorBatchAPI: "datasources.azureMonitorBatchAPI",
  /** Use the new datasource API groups for datasource CRUD requests, frontend flag */
  DatasourcesConfigUiUseNewDatasourceCRUDAPIs: "datasources.config.ui.useNewDatasourceCRUDAPIs",
  /** Data source query gateway */
  DatasourcesQueryGateway: "datasources.queryGateway",
  /** Send Datsource health requests to /apis/ API routes instead of the legacy /api/datasources/uid/{uid}/health route. */
  DatasourcesApiServerEnableHealthEndpointFrontend: "datasourcesApiServerEnableHealthEndpointFrontend",
  /** Enables additional experimental color schemes for visualizations. */
  DatavizExperimentalColorSchemes: "dataviz.experimentalColorSchemes",
  /** A/A test for recently viewed dashboards feature */
  ExperimentRecentlyViewedDashboards: "experimentRecentlyViewedDashboards",
  /** Enable Faro session replay for Grafana */
  FaroSessionReplay: "faroSessionReplay",
  /** Enables the feedback button in the dashboard edit sidebar */
  FeedbackButton: "feedbackButton",
  /** Renders the flame graph's top table using TableNG instead of the legacy Table */
  FlameGraphTableNg: "flameGraph.tableNg",
  /** Enables the new Flame Graph UI containing the Call Tree view */
  FlameGraphWithCallTree: "flameGraphWithCallTree",
  /** Enables global and folder-scoped dashboard variables via dashboard.grafana.app */
  GlobalDashboardVariables: "globalDashboardVariables",
  /** Uses the hybrid (lexical + semantic) search endpoint as the dashboard search backend in the command palette */
  GrafanaCmdkHybridSearch: "grafana.cmdkHybridSearch",
  /** Enables custom dashboard templates for enterprise */
  GrafanaCustomDashboardTemplates: "grafana.customDashboardTemplates",
  /** Allows users to customise the mega menu by hiding top-level navigation items they are not interested in */
  GrafanaCustomizableMegaMenu: "grafana.customizableMegaMenu",
  /** Uses auto grid as the default layout for new dashboards */
  GrafanaDashboardAutoGridDefault: "grafana.dashboardAutoGridDefault",
  /** Enables global and folder-scoped dashboard variables via dashboard.grafana.app */
  GrafanaDashboardGlobalVariables: "grafana.dashboardGlobalVariables",
  /** Redesigns dashboard settings page into Advanced Settings in a modal window */
  GrafanaDashboardSettingsRedesign: "grafana.dashboardSettingsRedesign",
  /** Enables the auto-height feature for dashboard panels */
  GrafanaDashboardsAutoHeightPanels: "grafana.dashboardsAutoHeightPanels",
  /** Check for the existence of logs when linking from the Trace View */
  GrafanaDynamicTraceToLogs: "grafana.dynamicTraceToLogs",
  /** Enables UI changes for integrations that require a scope to always be selected (for example, hides the scope selector's Remove all button) */
  GrafanaEnableScopesFirstMode: "grafana.enableScopesFirstMode",
  /** Enables the sidebar in Explore metrics (Metrics Drilldown) */
  GrafanaExploreMetricsSidebar: "grafana.exploreMetricsSidebar",
  /** Enables interactive grouped-label filtering through the tooltip in state timeline, status history and histogram panels */
  GrafanaFilterablePanels: "grafana.filterablePanels",
  /** Enables PLG-focused growth redesign of the unified homepage */
  GrafanaGrowthHomepage: "grafana.growthHomepage",
  /** Enables usage of the new annotations API client */
  GrafanaKubernetesAnnotationsClient: "grafana.kubernetesAnnotationsClient",
  /** Enables log level inference from log line contents when level is not defined as a field or a label */
  GrafanaLogLevelInference: "grafana.logLevelInference",
  /** Builds the navigation tree client-side instead of reading it from /bootdata */
  GrafanaMultiTenantNavTree: "grafana.multiTenantNavTree",
  /** Enables a new UI for query errors and notices */
  GrafanaNewPanelQueryErrorsUI: "grafana.newPanelQueryErrorsUI",
  /** Enables the new text panel */
  GrafanaNewTextPanel: "grafana.newTextPanel",
  /** Adds a 'Download diagnostics' action that bundles diagnostic artifacts such as HTTP traffic (HAR), server log, dashboard and panel JSONs, and more */
  GrafanaOnDemandDiagnostics: "grafana.onDemandDiagnostics",
  /** Enables firing an event for PanelEditNext feedback that triggers an in-house survey */
  GrafanaPanelEditNextFeedbackEvent: "grafana.panelEditNextFeedbackEvent",
  /** Let panel plugins register system transformations */
  GrafanaPanelPluginTransformations: "grafana.panelPluginTransformations",
  /** Enables a redesigned query variable editor with split-pane preview and a spreadsheet for managing static options */
  GrafanaQueryVarEditorRedesign: "grafana.queryVarEditorRedesign",
  /** Enables the dedicated Saved queries page and its navigation entry */
  GrafanaSavedQueriesPage: "grafana.savedQueriesPage",
  /** Prevents flickering in dashboards */
  GrafanaScenesFlickeringFix: "grafana.scenesFlickeringFix",
  /** Enable referencing an existing secret in an active keeper when creating a secure value */
  GrafanaSecretsReferenceValueUI: "grafana.secretsReferenceValueUI",
  /** Enables starring folders and a virtual Starred folders folder in the dashboards list and folder picker */
  GrafanaStarredFolders: "grafana.starredFolders",
  /** Enables using dashboard variables in panel threshold values */
  GrafanaThresholdsInterpolation: "grafana.thresholdsInterpolation",
  /** Render the core Grafana data source picker behind the DataSourcePicker that @grafana/runtime exposes to plugins */
  GrafanaUnifiedDataSourcePicker: "grafana.unifiedDataSourcePicker",
  /** Use the find default scope endpoint to seed the initial scope selection when none is set. */
  GrafanaUseDefaultScopesEndpoint: "grafana.useDefaultScopesEndpoint",
  /** Enables semantic (vector) dashboard search in the command palette */
  GrafanaVectorSearchCmdk: "grafana.vectorSearchCmdk",
  /** Enables the sidebar pane with new toggles and options in panel view mode */
  GrafanaViewPanelPane: "grafana.viewPanelPane",
  /** Enables the new visual design refresh for the Grafana UI */
  GrafanaVisualDesignRefresh: "grafana.visualDesignRefresh",
  /** Enables an inline version of Log Details that creates no new scrolls */
  InlineLogDetailsNoScrolls: "inlineLogDetailsNoScrolls",
  /** Enables team APIs in the app platform */
  KubernetesTeamsApi: "kubernetesTeamsApi",
  /** Routes library panel requests from /api to the /apis endpoint */
  LibraryelementsKubernetesLibraryPanels: "libraryelements.kubernetesLibraryPanels",
  /** Enables the logs tableNG panel to replace existing tableRT */
  LogsTablePanelNG: "logsTablePanelNG",
  /** Use stream shards to split queries into smaller subqueries */
  LokiShardSplitting: "lokiShardSplitting",
  /** Enables managed plugins v2 (expanded rollout, community plugin coverage) */
  ManagedPluginsV2: "managedPluginsV2",
  /** Enables the new Saved queries (query library) modal experience */
  NewSavedQueriesExperience: "newSavedQueriesExperience",
  /** Applies OTel formatting templates to displayed logs */
  OtelLogsFormatting: "otelLogsFormatting",
  /** Shows text labels on the add and stacked view buttons in PanelEditNext */
  PaneleditButtonLabels: "paneledit.buttonLabels",
  /** Enables RBAC for playlists */
  PlaylistsRBAC: "playlistsRBAC",
  /** Initializes data source instance settings asynchronously from the API instead of synchronously from boot data */
  PluginsInitDataSourcesAsync: "plugins.initDataSourcesAsync",
  /** Enables plugins setting from new apis */
  PluginsUseMTPluginSettings: "plugins.useMTPluginSettings",
  /** Enables plugins decoupling from bootdata */
  PluginsUseMTPlugins: "plugins.useMTPlugins",
  /** Enable configurable commit message, branch name, and pull request title conventions for Git Sync */
  ProvisioningGitConventions: "provisioning.gitConventions",
  /** Render the README.md of a Git Sync provisioned folder inline below its dashboards list */
  ProvisioningReadmes: "provisioning.readmes",
  /** Author Git Sync commits as the acting Grafana user */
  ProvisioningUserAttribution: "provisioning.userAttribution",
  /** Enable export functionality for provisioned resources */
  ProvisioningExport: "provisioningExport",
  /** Allow setting folder metadata for provisioned folders */
  ProvisioningFolderMetadata: "provisioningFolderMetadata",
  /** Enables next generation query editor experience */
  QueryEditorNext: "queryEditorNext",
  /** Store query history in browser IndexedDB instead of server-side */
  QueryHistoryLocalOnly: "queryHistory.localOnly",
  /** Replace the Query History drawer with a new Recent Queries modal UI */
  QueryHistoryRecentQueriesUI: "queryHistory.recentQueriesUI",
  /** Enables AI-assisted coauthoring in code query editors */
  QueryeditorCoauthoringUi: "queryeditor.coauthoringUi",
  /** Renders the raw Prometheus query results table using TableNG instead of the legacy Table */
  RawPrometheusTableNg: "rawPrometheus.tableNg",
  /** Enables recently viewed dashboards section in the browsing dashboard page */
  RecentlyViewedDashboards: "recentlyViewedDashboards",
  /** Enables reporting for any page in Grafana */
  ReportingAnyPageReporting: "reporting.anyPageReporting",
  /** Routes snapshot requests from /api to the /apis endpoint */
  SnapshotsKubernetesSnapshots: "snapshots.kubernetesSnapshots",
  /** Enables the splash screen modal for introducing new Grafana features on first session */
  SplashScreen: "splashScreen",
  /** Enables CodeMirror editor for SQL Expressions */
  SqlExpressionsCodeMirror: "sqlExpressionsCodeMirror",
  /** Enables column autocomplete for SQL Expressions */
  SqlExpressionsColumnAutoComplete: "sqlExpressionsColumnAutoComplete",
  /** Enables option to position series names above bars in the state timeline panel */
  StateTimelineNameAboveBars: "stateTimeline.nameAboveBars",
  /** Enables the 'Customize with Assistant' button on suggested dashboard cards */
  SuggestedDashboardsAssistantButton: "suggestedDashboardsAssistantButton",
  /** Sizes TableNG auto-width columns to fit their content instead of distributing evenly */
  TableAutoColumnWidths: "table.autoColumnWidths",
  /** Enables TableNG in the panel inspector's Data tab, replacing the legacy Table (TableRT) */
  TableInspectDataTableNG: "table.inspectDataTableNG",
  /** Enables configuring a fixed page size for paginated tables instead of deriving it from the panel height */
  TablePaginationPageSize: "table.paginationPageSize",
  /** Enables the refreshed table experience: reworked column headers and ad hoc column interactions */
  TableRefresh: "table.refresh",
  /** Enables the new features in text panel */
  TextNewFeatures: "text.newFeatures",
  /** Routes short URL requests from /api to the /apis endpoint in the frontend. Depends on kubernetesShortURLs */
  UseKubernetesShortURLsAPI: "useKubernetesShortURLsAPI",
} as const;

/**
 * Enable manually starting an Assistant investigation from the alert instance drawer.
 *
 * **Details:**
 * - flag key: `alerting.manualAssistantInvestigation`
 * - default value: `false`
 */
export const useFlagAlertingManualAssistantInvestigation = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("alerting.manualAssistantInvestigation", false, options).value;
};

/**
 * Enable the alert quality tab, which surfaces the health of your alert rules and recommends actions to improve them.
 *
 * **Details:**
 * - flag key: `alerting.ruleQuality`
 * - default value: `false`
 */
export const useFlagAlertingRuleQuality = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("alerting.ruleQuality", false, options).value;
};

/**
 * Automatically syncs external Alertmanager datasource configuration as ExtraConfiguration in Grafana
 *
 * **Details:**
 * - flag key: `alerting.syncExternalAlertmanager`
 * - default value: `false`
 */
export const useFlagAlertingSyncExternalAlertmanager = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("alerting.syncExternalAlertmanager", false, options).value;
};

/**
 * Enables new analytics framework
 *
 * **Details:**
 * - flag key: `analyticsFramework`
 * - default value: `false`
 */
export const useFlagAnalyticsFramework = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("analyticsFramework", false, options).value;
};

/**
 * Enables the assistant-powered Generate dashboard prompt and the plan card that approves the dashboard before it is built
 *
 * **Details:**
 * - flag key: `assistant.dashboardPlanning`
 * - default value: `false`
 */
export const useFlagAssistantDashboardPlanning = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("assistant.dashboardPlanning", false, options).value;
};

/**
 * Enables the template dashboard assistant
 *
 * **Details:**
 * - flag key: `assistant.frontend.tools.dashboardTemplates`
 * - default value: `false`
 */
export const useFlagAssistantFrontendToolsDashboardTemplates = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("assistant.frontend.tools.dashboardTemplates", false, options).value;
};

/**
 * Enables the global fullscreen Workspace (Grafana Assistant workspace shell) in the top bar
 *
 * **Details:**
 * - flag key: `assistant.fullscreenWorkspace`
 * - default value: `false`
 */
export const useFlagAssistantFullscreenWorkspace = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("assistant.fullscreenWorkspace", false, options).value;
};

/**
 * Generate a per-datasource external ID for Grafana Assume Role (jsonData.grafanaExternalId). When disabled, new datasources keep using the stack-level external ID.
 *
 * **Details:**
 * - flag key: `awsAssumeRolePerDatasourceExternalId`
 * - default value: `false`
 */
export const useFlagAwsAssumeRolePerDatasourceExternalId = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("awsAssumeRolePerDatasourceExternalId", false, options).value;
};

/**
 * Enable notebooks, a resource in the dashboard API group for mixing text cells, code cells, and visualization panels
 *
 * **Details:**
 * - flag key: `dashboard.notebooks`
 * - default value: `false`
 */
export const useFlagDashboardNotebooks = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("dashboard.notebooks", false, options).value;
};

/**
 * Load the Recently deleted dashboard list from the search API trash endpoint, instead of listing every deleted dashboard and filtering in the browser
 *
 * **Details:**
 * - flag key: `dashboard.recentlyDeletedViaTrash`
 * - default value: `false`
 */
export const useFlagDashboardRecentlyDeletedViaTrash = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("dashboard.recentlyDeletedViaTrash", false, options).value;
};

/**
 * Exposes the semantic (vector) search endpoint for dashboards under the dashboard API
 *
 * **Details:**
 * - flag key: `dashboard.vectorSearch`
 * - default value: `false`
 */
export const useFlagDashboardVectorSearch = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("dashboard.vectorSearch", false, options).value;
};

/**
 * Enables the Assistant button in the dashboard templates card
 *
 * **Details:**
 * - flag key: `dashboardTemplatesAssistantButton`
 * - default value: `false`
 */
export const useFlagDashboardTemplatesAssistantButton = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("dashboardTemplatesAssistantButton", false, options).value;
};

/**
 * Use the new datasource API groups for datasource resource requests, frontend flag
 *
 * **Details:**
 * - flag key: `datasources.apiserver.useNewAPIsForDatasourceResources`
 * - default value: `false`
 */
export const useFlagDatasourcesApiserverUseNewAPIsForDatasourceResources = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("datasources.apiserver.useNewAPIsForDatasourceResources", false, options).value;
};

/**
 * Enables the Metrics Batch API for the Azure Monitor data source, allowing up to 50 resources to be queried in a single request
 *
 * **Details:**
 * - flag key: `datasources.azureMonitorBatchAPI`
 * - default value: `true`
 */
export const useFlagDatasourcesAzureMonitorBatchAPI = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("datasources.azureMonitorBatchAPI", true, options).value;
};

/**
 * Use the new datasource API groups for datasource CRUD requests, frontend flag
 *
 * **Details:**
 * - flag key: `datasources.config.ui.useNewDatasourceCRUDAPIs`
 * - default value: `false`
 */
export const useFlagDatasourcesConfigUiUseNewDatasourceCRUDAPIs = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("datasources.config.ui.useNewDatasourceCRUDAPIs", false, options).value;
};

/**
 * Data source query gateway
 *
 * **Details:**
 * - flag key: `datasources.queryGateway`
 * - default value: `false`
 */
export const useFlagDatasourcesQueryGateway = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("datasources.queryGateway", false, options).value;
};

/**
 * Send Datsource health requests to /apis/ API routes instead of the legacy /api/datasources/uid/{uid}/health route.
 *
 * **Details:**
 * - flag key: `datasourcesApiServerEnableHealthEndpointFrontend`
 * - default value: `false`
 */
export const useFlagDatasourcesApiServerEnableHealthEndpointFrontend = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("datasourcesApiServerEnableHealthEndpointFrontend", false, options).value;
};

/**
 * Enables additional experimental color schemes for visualizations.
 *
 * **Details:**
 * - flag key: `dataviz.experimentalColorSchemes`
 * - default value: `false`
 */
export const useFlagDatavizExperimentalColorSchemes = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("dataviz.experimentalColorSchemes", false, options).value;
};

/**
 * A/A test for recently viewed dashboards feature
 *
 * **Details:**
 * - flag key: `experimentRecentlyViewedDashboards`
 * - default value: `false`
 */
export const useFlagExperimentRecentlyViewedDashboards = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("experimentRecentlyViewedDashboards", false, options).value;
};

/**
 * Enable Faro session replay for Grafana
 *
 * **Details:**
 * - flag key: `faroSessionReplay`
 * - default value: `false`
 */
export const useFlagFaroSessionReplay = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("faroSessionReplay", false, options).value;
};

/**
 * Enables the feedback button in the dashboard edit sidebar
 *
 * **Details:**
 * - flag key: `feedbackButton`
 * - default value: `true`
 */
export const useFlagFeedbackButton = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("feedbackButton", true, options).value;
};

/**
 * Renders the flame graph's top table using TableNG instead of the legacy Table
 *
 * **Details:**
 * - flag key: `flameGraph.tableNg`
 * - default value: `false`
 */
export const useFlagFlameGraphTableNg = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("flameGraph.tableNg", false, options).value;
};

/**
 * Enables the new Flame Graph UI containing the Call Tree view
 *
 * **Details:**
 * - flag key: `flameGraphWithCallTree`
 * - default value: `false`
 */
export const useFlagFlameGraphWithCallTree = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("flameGraphWithCallTree", false, options).value;
};

/**
 * Enables global and folder-scoped dashboard variables via dashboard.grafana.app
 *
 * **Details:**
 * - flag key: `globalDashboardVariables`
 * - default value: `false`
 */
export const useFlagGlobalDashboardVariables = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("globalDashboardVariables", false, options).value;
};

/**
 * Uses the hybrid (lexical + semantic) search endpoint as the dashboard search backend in the command palette
 *
 * **Details:**
 * - flag key: `grafana.cmdkHybridSearch`
 * - default value: `false`
 */
export const useFlagGrafanaCmdkHybridSearch = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.cmdkHybridSearch", false, options).value;
};

/**
 * Enables custom dashboard templates for enterprise
 *
 * **Details:**
 * - flag key: `grafana.customDashboardTemplates`
 * - default value: `false`
 */
export const useFlagGrafanaCustomDashboardTemplates = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.customDashboardTemplates", false, options).value;
};

/**
 * Allows users to customise the mega menu by hiding top-level navigation items they are not interested in
 *
 * **Details:**
 * - flag key: `grafana.customizableMegaMenu`
 * - default value: `false`
 */
export const useFlagGrafanaCustomizableMegaMenu = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.customizableMegaMenu", false, options).value;
};

/**
 * Uses auto grid as the default layout for new dashboards
 *
 * **Details:**
 * - flag key: `grafana.dashboardAutoGridDefault`
 * - default value: `true`
 */
export const useFlagGrafanaDashboardAutoGridDefault = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.dashboardAutoGridDefault", true, options).value;
};

/**
 * Enables global and folder-scoped dashboard variables via dashboard.grafana.app
 *
 * **Details:**
 * - flag key: `grafana.dashboardGlobalVariables`
 * - default value: `false`
 */
export const useFlagGrafanaDashboardGlobalVariables = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.dashboardGlobalVariables", false, options).value;
};

/**
 * Redesigns dashboard settings page into Advanced Settings in a modal window
 *
 * **Details:**
 * - flag key: `grafana.dashboardSettingsRedesign`
 * - default value: `true`
 */
export const useFlagGrafanaDashboardSettingsRedesign = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.dashboardSettingsRedesign", true, options).value;
};

/**
 * Enables the auto-height feature for dashboard panels
 *
 * **Details:**
 * - flag key: `grafana.dashboardsAutoHeightPanels`
 * - default value: `false`
 */
export const useFlagGrafanaDashboardsAutoHeightPanels = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.dashboardsAutoHeightPanels", false, options).value;
};

/**
 * Check for the existence of logs when linking from the Trace View
 *
 * **Details:**
 * - flag key: `grafana.dynamicTraceToLogs`
 * - default value: `false`
 */
export const useFlagGrafanaDynamicTraceToLogs = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.dynamicTraceToLogs", false, options).value;
};

/**
 * Enables UI changes for integrations that require a scope to always be selected (for example, hides the scope selector's Remove all button)
 *
 * **Details:**
 * - flag key: `grafana.enableScopesFirstMode`
 * - default value: `false`
 */
export const useFlagGrafanaEnableScopesFirstMode = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.enableScopesFirstMode", false, options).value;
};

/**
 * Enables the sidebar in Explore metrics (Metrics Drilldown)
 *
 * **Details:**
 * - flag key: `grafana.exploreMetricsSidebar`
 * - default value: `false`
 */
export const useFlagGrafanaExploreMetricsSidebar = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.exploreMetricsSidebar", false, options).value;
};

/**
 * Enables interactive grouped-label filtering through the tooltip in state timeline, status history and histogram panels
 *
 * **Details:**
 * - flag key: `grafana.filterablePanels`
 * - default value: `false`
 */
export const useFlagGrafanaFilterablePanels = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.filterablePanels", false, options).value;
};

/**
 * Enables PLG-focused growth redesign of the unified homepage
 *
 * **Details:**
 * - flag key: `grafana.growthHomepage`
 * - default value: `false`
 */
export const useFlagGrafanaGrowthHomepage = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.growthHomepage", false, options).value;
};

/**
 * Enables usage of the new annotations API client
 *
 * **Details:**
 * - flag key: `grafana.kubernetesAnnotationsClient`
 * - default value: `false`
 */
export const useFlagGrafanaKubernetesAnnotationsClient = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.kubernetesAnnotationsClient", false, options).value;
};

/**
 * Enables log level inference from log line contents when level is not defined as a field or a label
 *
 * **Details:**
 * - flag key: `grafana.logLevelInference`
 * - default value: `false`
 */
export const useFlagGrafanaLogLevelInference = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.logLevelInference", false, options).value;
};

/**
 * Builds the navigation tree client-side instead of reading it from /bootdata
 *
 * **Details:**
 * - flag key: `grafana.multiTenantNavTree`
 * - default value: `false`
 */
export const useFlagGrafanaMultiTenantNavTree = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.multiTenantNavTree", false, options).value;
};

/**
 * Enables a new UI for query errors and notices
 *
 * **Details:**
 * - flag key: `grafana.newPanelQueryErrorsUI`
 * - default value: `false`
 */
export const useFlagGrafanaNewPanelQueryErrorsUI = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.newPanelQueryErrorsUI", false, options).value;
};

/**
 * Enables the new text panel
 *
 * **Details:**
 * - flag key: `grafana.newTextPanel`
 * - default value: `false`
 */
export const useFlagGrafanaNewTextPanel = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.newTextPanel", false, options).value;
};

/**
 * Adds a 'Download diagnostics' action that bundles diagnostic artifacts such as HTTP traffic (HAR), server log, dashboard and panel JSONs, and more
 *
 * **Details:**
 * - flag key: `grafana.onDemandDiagnostics`
 * - default value: `false`
 */
export const useFlagGrafanaOnDemandDiagnostics = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.onDemandDiagnostics", false, options).value;
};

/**
 * Enables firing an event for PanelEditNext feedback that triggers an in-house survey
 *
 * **Details:**
 * - flag key: `grafana.panelEditNextFeedbackEvent`
 * - default value: `false`
 */
export const useFlagGrafanaPanelEditNextFeedbackEvent = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.panelEditNextFeedbackEvent", false, options).value;
};

/**
 * Let panel plugins register system transformations
 *
 * **Details:**
 * - flag key: `grafana.panelPluginTransformations`
 * - default value: `false`
 */
export const useFlagGrafanaPanelPluginTransformations = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.panelPluginTransformations", false, options).value;
};

/**
 * Enables a redesigned query variable editor with split-pane preview and a spreadsheet for managing static options
 *
 * **Details:**
 * - flag key: `grafana.queryVarEditorRedesign`
 * - default value: `true`
 */
export const useFlagGrafanaQueryVarEditorRedesign = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.queryVarEditorRedesign", true, options).value;
};

/**
 * Enables the dedicated Saved queries page and its navigation entry
 *
 * **Details:**
 * - flag key: `grafana.savedQueriesPage`
 * - default value: `false`
 */
export const useFlagGrafanaSavedQueriesPage = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.savedQueriesPage", false, options).value;
};

/**
 * Prevents flickering in dashboards
 *
 * **Details:**
 * - flag key: `grafana.scenesFlickeringFix`
 * - default value: `true`
 */
export const useFlagGrafanaScenesFlickeringFix = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.scenesFlickeringFix", true, options).value;
};

/**
 * Enable referencing an existing secret in an active keeper when creating a secure value
 *
 * **Details:**
 * - flag key: `grafana.secretsReferenceValueUI`
 * - default value: `false`
 */
export const useFlagGrafanaSecretsReferenceValueUI = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.secretsReferenceValueUI", false, options).value;
};

/**
 * Enables starring folders and a virtual Starred folders folder in the dashboards list and folder picker
 *
 * **Details:**
 * - flag key: `grafana.starredFolders`
 * - default value: `false`
 */
export const useFlagGrafanaStarredFolders = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.starredFolders", false, options).value;
};

/**
 * Enables using dashboard variables in panel threshold values
 *
 * **Details:**
 * - flag key: `grafana.thresholdsInterpolation`
 * - default value: `false`
 */
export const useFlagGrafanaThresholdsInterpolation = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.thresholdsInterpolation", false, options).value;
};

/**
 * Render the core Grafana data source picker behind the DataSourcePicker that @grafana/runtime exposes to plugins
 *
 * **Details:**
 * - flag key: `grafana.unifiedDataSourcePicker`
 * - default value: `true`
 */
export const useFlagGrafanaUnifiedDataSourcePicker = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.unifiedDataSourcePicker", true, options).value;
};

/**
 * Use the find default scope endpoint to seed the initial scope selection when none is set.
 *
 * **Details:**
 * - flag key: `grafana.useDefaultScopesEndpoint`
 * - default value: `false`
 */
export const useFlagGrafanaUseDefaultScopesEndpoint = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.useDefaultScopesEndpoint", false, options).value;
};

/**
 * Enables semantic (vector) dashboard search in the command palette
 *
 * **Details:**
 * - flag key: `grafana.vectorSearchCmdk`
 * - default value: `false`
 */
export const useFlagGrafanaVectorSearchCmdk = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.vectorSearchCmdk", false, options).value;
};

/**
 * Enables the sidebar pane with new toggles and options in panel view mode
 *
 * **Details:**
 * - flag key: `grafana.viewPanelPane`
 * - default value: `true`
 */
export const useFlagGrafanaViewPanelPane = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.viewPanelPane", true, options).value;
};

/**
 * Enables the new visual design refresh for the Grafana UI
 *
 * **Details:**
 * - flag key: `grafana.visualDesignRefresh`
 * - default value: `false`
 */
export const useFlagGrafanaVisualDesignRefresh = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("grafana.visualDesignRefresh", false, options).value;
};

/**
 * Enables an inline version of Log Details that creates no new scrolls
 *
 * **Details:**
 * - flag key: `inlineLogDetailsNoScrolls`
 * - default value: `false`
 */
export const useFlagInlineLogDetailsNoScrolls = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("inlineLogDetailsNoScrolls", false, options).value;
};

/**
 * Enables team APIs in the app platform
 *
 * **Details:**
 * - flag key: `kubernetesTeamsApi`
 * - default value: `false`
 */
export const useFlagKubernetesTeamsApi = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("kubernetesTeamsApi", false, options).value;
};

/**
 * Routes library panel requests from /api to the /apis endpoint
 *
 * **Details:**
 * - flag key: `libraryelements.kubernetesLibraryPanels`
 * - default value: `false`
 */
export const useFlagLibraryelementsKubernetesLibraryPanels = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("libraryelements.kubernetesLibraryPanels", false, options).value;
};

/**
 * Enables the logs tableNG panel to replace existing tableRT
 *
 * **Details:**
 * - flag key: `logsTablePanelNG`
 * - default value: `false`
 */
export const useFlagLogsTablePanelNG = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("logsTablePanelNG", false, options).value;
};

/**
 * Use stream shards to split queries into smaller subqueries
 *
 * **Details:**
 * - flag key: `lokiShardSplitting`
 * - default value: `false`
 */
export const useFlagLokiShardSplitting = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("lokiShardSplitting", false, options).value;
};

/**
 * Enables managed plugins v2 (expanded rollout, community plugin coverage)
 *
 * **Details:**
 * - flag key: `managedPluginsV2`
 * - default value: `false`
 */
export const useFlagManagedPluginsV2 = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("managedPluginsV2", false, options).value;
};

/**
 * Enables the new Saved queries (query library) modal experience
 *
 * **Details:**
 * - flag key: `newSavedQueriesExperience`
 * - default value: `true`
 */
export const useFlagNewSavedQueriesExperience = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("newSavedQueriesExperience", true, options).value;
};

/**
 * Applies OTel formatting templates to displayed logs
 *
 * **Details:**
 * - flag key: `otelLogsFormatting`
 * - default value: `false`
 */
export const useFlagOtelLogsFormatting = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("otelLogsFormatting", false, options).value;
};

/**
 * Shows text labels on the add and stacked view buttons in PanelEditNext
 *
 * **Details:**
 * - flag key: `paneledit.buttonLabels`
 * - default value: `false`
 */
export const useFlagPaneleditButtonLabels = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("paneledit.buttonLabels", false, options).value;
};

/**
 * Enables RBAC for playlists
 *
 * **Details:**
 * - flag key: `playlistsRBAC`
 * - default value: `false`
 */
export const useFlagPlaylistsRBAC = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("playlistsRBAC", false, options).value;
};

/**
 * Initializes data source instance settings asynchronously from the API instead of synchronously from boot data
 *
 * **Details:**
 * - flag key: `plugins.initDataSourcesAsync`
 * - default value: `false`
 */
export const useFlagPluginsInitDataSourcesAsync = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("plugins.initDataSourcesAsync", false, options).value;
};

/**
 * Enables plugins setting from new apis
 *
 * **Details:**
 * - flag key: `plugins.useMTPluginSettings`
 * - default value: `false`
 */
export const useFlagPluginsUseMTPluginSettings = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("plugins.useMTPluginSettings", false, options).value;
};

/**
 * Enables plugins decoupling from bootdata
 *
 * **Details:**
 * - flag key: `plugins.useMTPlugins`
 * - default value: `false`
 */
export const useFlagPluginsUseMTPlugins = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("plugins.useMTPlugins", false, options).value;
};

/**
 * Enable configurable commit message, branch name, and pull request title conventions for Git Sync
 *
 * **Details:**
 * - flag key: `provisioning.gitConventions`
 * - default value: `true`
 */
export const useFlagProvisioningGitConventions = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("provisioning.gitConventions", true, options).value;
};

/**
 * Render the README.md of a Git Sync provisioned folder inline below its dashboards list
 *
 * **Details:**
 * - flag key: `provisioning.readmes`
 * - default value: `true`
 */
export const useFlagProvisioningReadmes = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("provisioning.readmes", true, options).value;
};

/**
 * Author Git Sync commits as the acting Grafana user
 *
 * **Details:**
 * - flag key: `provisioning.userAttribution`
 * - default value: `true`
 */
export const useFlagProvisioningUserAttribution = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("provisioning.userAttribution", true, options).value;
};

/**
 * Enable export functionality for provisioned resources
 *
 * **Details:**
 * - flag key: `provisioningExport`
 * - default value: `false`
 */
export const useFlagProvisioningExport = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("provisioningExport", false, options).value;
};

/**
 * Allow setting folder metadata for provisioned folders
 *
 * **Details:**
 * - flag key: `provisioningFolderMetadata`
 * - default value: `true`
 */
export const useFlagProvisioningFolderMetadata = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("provisioningFolderMetadata", true, options).value;
};

/**
 * Enables next generation query editor experience
 *
 * **Details:**
 * - flag key: `queryEditorNext`
 * - default value: `false`
 */
export const useFlagQueryEditorNext = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("queryEditorNext", false, options).value;
};

/**
 * Store query history in browser IndexedDB instead of server-side
 *
 * **Details:**
 * - flag key: `queryHistory.localOnly`
 * - default value: `false`
 */
export const useFlagQueryHistoryLocalOnly = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("queryHistory.localOnly", false, options).value;
};

/**
 * Replace the Query History drawer with a new Recent Queries modal UI
 *
 * **Details:**
 * - flag key: `queryHistory.recentQueriesUI`
 * - default value: `false`
 */
export const useFlagQueryHistoryRecentQueriesUI = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("queryHistory.recentQueriesUI", false, options).value;
};

/**
 * Enables AI-assisted coauthoring in code query editors
 *
 * **Details:**
 * - flag key: `queryeditor.coauthoringUi`
 * - default value: `false`
 */
export const useFlagQueryeditorCoauthoringUi = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("queryeditor.coauthoringUi", false, options).value;
};

/**
 * Renders the raw Prometheus query results table using TableNG instead of the legacy Table
 *
 * **Details:**
 * - flag key: `rawPrometheus.tableNg`
 * - default value: `false`
 */
export const useFlagRawPrometheusTableNg = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("rawPrometheus.tableNg", false, options).value;
};

/**
 * Enables recently viewed dashboards section in the browsing dashboard page
 *
 * **Details:**
 * - flag key: `recentlyViewedDashboards`
 * - default value: `false`
 */
export const useFlagRecentlyViewedDashboards = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("recentlyViewedDashboards", false, options).value;
};

/**
 * Enables reporting for any page in Grafana
 *
 * **Details:**
 * - flag key: `reporting.anyPageReporting`
 * - default value: `false`
 */
export const useFlagReportingAnyPageReporting = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("reporting.anyPageReporting", false, options).value;
};

/**
 * Routes snapshot requests from /api to the /apis endpoint
 *
 * **Details:**
 * - flag key: `snapshots.kubernetesSnapshots`
 * - default value: `false`
 */
export const useFlagSnapshotsKubernetesSnapshots = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("snapshots.kubernetesSnapshots", false, options).value;
};

/**
 * Enables the splash screen modal for introducing new Grafana features on first session
 *
 * **Details:**
 * - flag key: `splashScreen`
 * - default value: `false`
 */
export const useFlagSplashScreen = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("splashScreen", false, options).value;
};

/**
 * Enables CodeMirror editor for SQL Expressions
 *
 * **Details:**
 * - flag key: `sqlExpressionsCodeMirror`
 * - default value: `false`
 */
export const useFlagSqlExpressionsCodeMirror = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("sqlExpressionsCodeMirror", false, options).value;
};

/**
 * Enables column autocomplete for SQL Expressions
 *
 * **Details:**
 * - flag key: `sqlExpressionsColumnAutoComplete`
 * - default value: `false`
 */
export const useFlagSqlExpressionsColumnAutoComplete = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("sqlExpressionsColumnAutoComplete", false, options).value;
};

/**
 * Enables option to position series names above bars in the state timeline panel
 *
 * **Details:**
 * - flag key: `stateTimeline.nameAboveBars`
 * - default value: `false`
 */
export const useFlagStateTimelineNameAboveBars = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("stateTimeline.nameAboveBars", false, options).value;
};

/**
 * Enables the 'Customize with Assistant' button on suggested dashboard cards
 *
 * **Details:**
 * - flag key: `suggestedDashboardsAssistantButton`
 * - default value: `false`
 */
export const useFlagSuggestedDashboardsAssistantButton = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("suggestedDashboardsAssistantButton", false, options).value;
};

/**
 * Sizes TableNG auto-width columns to fit their content instead of distributing evenly
 *
 * **Details:**
 * - flag key: `table.autoColumnWidths`
 * - default value: `false`
 */
export const useFlagTableAutoColumnWidths = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("table.autoColumnWidths", false, options).value;
};

/**
 * Enables TableNG in the panel inspector's Data tab, replacing the legacy Table (TableRT)
 *
 * **Details:**
 * - flag key: `table.inspectDataTableNG`
 * - default value: `false`
 */
export const useFlagTableInspectDataTableNG = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("table.inspectDataTableNG", false, options).value;
};

/**
 * Enables configuring a fixed page size for paginated tables instead of deriving it from the panel height
 *
 * **Details:**
 * - flag key: `table.paginationPageSize`
 * - default value: `false`
 */
export const useFlagTablePaginationPageSize = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("table.paginationPageSize", false, options).value;
};

/**
 * Enables the refreshed table experience: reworked column headers and ad hoc column interactions
 *
 * **Details:**
 * - flag key: `table.refresh`
 * - default value: `false`
 */
export const useFlagTableRefresh = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("table.refresh", false, options).value;
};

/**
 * Enables the new features in text panel
 *
 * **Details:**
 * - flag key: `text.newFeatures`
 * - default value: `false`
 */
export const useFlagTextNewFeatures = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("text.newFeatures", false, options).value;
};

/**
 * Routes short URL requests from /api to the /apis endpoint in the frontend. Depends on kubernetesShortURLs
 *
 * **Details:**
 * - flag key: `useKubernetesShortURLsAPI`
 * - default value: `true`
 */
export const useFlagUseKubernetesShortURLsAPI = (options?: ReactFlagEvaluationOptions): boolean => {
  return useFlag("useKubernetesShortURLsAPI", true, options).value;
};

