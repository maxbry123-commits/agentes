/**
 * This file is used to share internal grafana/runtime code with Grafana core.
 * Note that these exports are also used within Enterprise.
 *
 * Through the exports declared in package.json we can import this code in core Grafana and the grafana/runtime
 * package will continue to be able to access all code when it's published to npm as it's private to the package.
 *
 * During the yarn pack lifecycle the exports[./internal] property is deleted from the package.json
 * preventing the code from being importable by plugins or other npm packages making it truly "internal".
 *
 */

export { LegacyDataSourcePicker, setDataSourcePicker } from '../components/DataSourcePicker';
export { setPanelDataErrorView } from '../components/PanelDataErrorView';
export { setPanelRenderer } from '../components/PanelRenderer';
export { type PageInfoItem, setPluginPage } from '../components/PluginPage';

export { ExpressionDatasourceRef } from '../utils/expressionRef';
export { standardStreamOptionsProvider, toStreamingDataResponse } from '../utils/DataSourceWithBackend';

export {
  setGetObservablePluginComponents,
  type GetObservablePluginComponents,
} from '../services/pluginExtensions/getObservablePluginComponents';
export {
  setGetObservablePluginLinks,
  type GetObservablePluginLinks,
} from '../services/pluginExtensions/getObservablePluginLinks';

export { UserStorage, useUserStorage } from '../utils/userStorage';

export {
  initOpenFeature,
  getFeatureFlagClient,
  getLocalStorageProvider,
  getOFREPWebProvider,
} from '../internal/openFeature';
export * from '../internal/openFeature/openfeature.gen';

export { getAppPluginMeta, getAppPluginMetas, setAppPluginMetas } from '../services/pluginMeta/apps';
export {
  getDatasourcePluginMeta,
  getDatasourcePluginMetas,
  setDatasourcePluginMetas,
  refetchDatasourcePluginMetas,
  getPluginIdFromDatasourceInstanceType,
} from '../services/pluginMeta/datasources';
export {
  useAppPluginMeta,
  useAppPluginMetas,
  useDatasourcePluginMeta,
  useDatasourcePluginMetas,
  useListedPanelPluginMetas,
  usePanelPluginMeta,
  usePanelPluginMetas,
  usePanelPluginMetasMap,
} from '../services/pluginMeta/hooks';
export type { AppPluginMetas, DatasourcePluginMetas, PanelPluginMetas } from '../services/pluginMeta/types';
export {
  getCachedPromise,
  getCachedPromiseWithArgs,
  invalidateCachedPromisesCache,
  invalidateCachedPromise,
  replaceCachedPromise,
  getCacheKeyFromPromise,
} from '../utils/getCachedPromise';
export { type JourneyStartOptions, setJourneyTracker, setJourneyRegistry } from '../services/JourneyTracker';
export {
  getListedPanelPluginMetas,
  getPanelPluginMeta,
  getPanelPluginMetas,
  getPanelPluginMetasMap,
  getPanelPluginMetasMapSync,
  setPanelPluginMetas,
  refetchPanelPluginMetas,
} from '../services/pluginMeta/panels';
export { installPluginMeta, uninstallPluginMeta } from '../services/pluginMeta/plugins';
export { logPluginMetaError, logPluginMetaWarning } from '../services/pluginMeta/logging';
export { refetchPluginSettings } from '../services/pluginSettings/refetchPluginSettings';
export { invalidatePluginSettingsCache } from '../services/pluginSettings/invalidatePluginSettingsCache';

export {
  initDataSourceInstanceSettings,
  setDataSourceInstanceSettings,
  syncDataSourceInstanceSettings,
} from '../services/dataSource/settings';
export { setDataSourcePluginImporter } from '../services/dataSource/dataSource';
export { setExpressionDataSourceInstance } from '../services/dataSource/expressionDs';
