/* eslint-disable @grafana/no-restricted-img-srcs */
import type { PluginMetasResponse } from '../types';
import type { Meta } from '../types/meta/meta_object_gen';

export const myOrgTestAppMeta: Meta = structuredClone({
  kind: 'Meta',
  apiVersion: 'plugins.grafana.app/v0alpha1',
  metadata: {
    name: 'myorg-test-app',
    namespace: 'default',
  },
  spec: {
    aliasIds: ['fake-alias'],
    pluginJson: {
      id: 'myorg-test-app',
      type: 'app',
      name: 'Test',
      info: {
        keywords: ['app'],
        logos: {
          small: 'public/plugins/myorg-test-app/img/logo.svg',
          large: 'public/plugins/myorg-test-app/img/logo.svg',
        },
        updated: '2026-04-20',
        version: '1.0.0',
        author: {
          name: 'Myorg',
        },
      },
      dependencies: {
        grafanaDependency: '\u003e=12.3.0',
        grafanaVersion: '*',
      },
      buildMode: 'production',
      includes: [
        {
          type: 'page',
          name: 'Page One',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-test-app/one',
          addToNav: true,
          defaultNav: true,
        },
        {
          type: 'page',
          name: 'Page Two',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-test-app/two',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Page Three',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-test-app/three',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Page Four',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-test-app/four',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Configuration',
          role: 'Admin',
          path: '/plugins/myorg-test-app',
          addToNav: true,
          icon: 'cog',
        },
      ],
    },
    class: 'external',
    module: {
      path: 'public/plugins/myorg-test-app/module.js',
      loadingStrategy: 'script',
      hash: 'fake hash',
    },
    baseURL: 'public/plugins/myorg-test-app',
    signature: {
      status: 'unsigned',
    },
  },
  status: {},
});

export const clockPanelMetaOnPrem: Meta = structuredClone({
  kind: 'Meta',
  apiVersion: 'plugins.grafana.app/v0alpha1',
  metadata: {
    name: 'grafana-clock-panel',
    namespace: 'default',
  },
  spec: {
    pluginJson: {
      id: 'grafana-clock-panel',
      type: 'panel',
      name: 'Clock',
      info: {
        keywords: ['clock', 'panel'],
        logos: {
          small: 'public/plugins/grafana-clock-panel/img/clock.svg',
          large: 'public/plugins/grafana-clock-panel/img/clock.svg',
        },
        updated: '2025-12-10',
        version: '3.2.0',
        author: {
          name: 'Grafana Labs',
          url: 'https://grafana.com',
        },
        description: 'Clock panel for grafana',
        links: [
          {
            name: 'Project site',
            url: 'https://github.com/grafana/clock-panel',
          },
          {
            name: 'MIT License',
            url: 'https://github.com/grafana/clock-panel/blob/master/LICENSE',
          },
        ],
        screenshots: [
          {
            name: 'Showcase',
            path: 'public/plugins/grafana-clock-panel/img/screenshot-showcase.png',
          },
          {
            name: 'Options',
            path: 'public/plugins/grafana-clock-panel/img/screenshot-clock-options.png',
          },
        ],
      },
      dependencies: {
        grafanaDependency: '\u003e=11.0.0',
        grafanaVersion: '*',
      },
      buildMode: 'production',
      languages: [
        'en-US',
        'es-ES',
        'de-DE',
        'cs-CZ',
        'fr-FR',
        'hu-HU',
        'id-ID',
        'it-IT',
        'ja-JP',
        'ko-KR',
        'nl-NL',
        'pl-PL',
        'pt-BR',
        'pt-PT',
        'ru-RU',
        'sv-SE',
        'tr-TR',
        'zh-Hans',
        'zh-Hant',
      ],
    },
    class: 'external',
    module: {
      path: 'public/plugins/grafana-clock-panel/module.js',
      loadingStrategy: 'script',
    },
    baseURL: 'public/plugins/grafana-clock-panel',
    signature: {
      status: 'valid',
      type: 'grafana',
      org: 'Grafana Labs',
    },
    translations: {
      'cs-CZ': 'public/plugins/grafana-clock-panel/locales/cs-CZ/grafana-clock-panel.json',
      'de-DE': 'public/plugins/grafana-clock-panel/locales/de-DE/grafana-clock-panel.json',
      'en-US': 'public/plugins/grafana-clock-panel/locales/en-US/grafana-clock-panel.json',
      'es-ES': 'public/plugins/grafana-clock-panel/locales/es-ES/grafana-clock-panel.json',
      'fr-FR': 'public/plugins/grafana-clock-panel/locales/fr-FR/grafana-clock-panel.json',
      'hu-HU': 'public/plugins/grafana-clock-panel/locales/hu-HU/grafana-clock-panel.json',
      'id-ID': 'public/plugins/grafana-clock-panel/locales/id-ID/grafana-clock-panel.json',
      'it-IT': 'public/plugins/grafana-clock-panel/locales/it-IT/grafana-clock-panel.json',
      'ja-JP': 'public/plugins/grafana-clock-panel/locales/ja-JP/grafana-clock-panel.json',
      'ko-KR': 'public/plugins/grafana-clock-panel/locales/ko-KR/grafana-clock-panel.json',
      'nl-NL': 'public/plugins/grafana-clock-panel/locales/nl-NL/grafana-clock-panel.json',
      'pl-PL': 'public/plugins/grafana-clock-panel/locales/pl-PL/grafana-clock-panel.json',
      'pt-BR': 'public/plugins/grafana-clock-panel/locales/pt-BR/grafana-clock-panel.json',
      'pt-PT': 'public/plugins/grafana-clock-panel/locales/pt-PT/grafana-clock-panel.json',
      'ru-RU': 'public/plugins/grafana-clock-panel/locales/ru-RU/grafana-clock-panel.json',
      'sv-SE': 'public/plugins/grafana-clock-panel/locales/sv-SE/grafana-clock-panel.json',
      'tr-TR': 'public/plugins/grafana-clock-panel/locales/tr-TR/grafana-clock-panel.json',
      'zh-Hans': 'public/plugins/grafana-clock-panel/locales/zh-Hans/grafana-clock-panel.json',
      'zh-Hant': 'public/plugins/grafana-clock-panel/locales/zh-Hant/grafana-clock-panel.json',
    },
  },
  status: {},
});

export const clockPanelMetaCDN: Meta = structuredClone({
  kind: 'Meta',
  apiVersion: 'plugins.grafana.app/v0alpha1',
  metadata: {
    name: 'grafana-clock-panel',
    namespace: 'stacks-10265',
  },
  spec: {
    pluginJson: {
      id: 'grafana-clock-panel',
      type: 'panel',
      name: 'Clock',
      info: {
        keywords: ['clock', 'panel'],
        logos: {
          small: 'img/clock.svg',
          large: 'img/clock.svg',
        },
        updated: '2026-01-12',
        version: '3.2.1',
        author: {
          name: 'Grafana Labs',
          url: 'https://grafana.com',
        },
        description: 'Clock panel for grafana',
        links: [
          {
            name: 'Project site',
            url: 'https://github.com/grafana/clock-panel',
          },
          {
            name: 'MIT License',
            url: 'https://github.com/grafana/clock-panel/blob/master/LICENSE',
          },
        ],
        screenshots: [
          {
            name: 'Showcase',
            path: 'img/screenshot-showcase.png',
          },
          {
            name: 'Options',
            path: 'img/screenshot-clock-options.png',
          },
        ],
      },
      dependencies: {
        grafanaDependency: '\u003e=11.0.0',
      },
      buildMode: 'production',
      languages: [
        'en-US',
        'es-ES',
        'de-DE',
        'cs-CZ',
        'fr-FR',
        'hu-HU',
        'id-ID',
        'it-IT',
        'ja-JP',
        'ko-KR',
        'nl-NL',
        'pl-PL',
        'pt-BR',
        'pt-PT',
        'ru-RU',
        'sv-SE',
        'tr-TR',
        'zh-Hans',
        'zh-Hant',
      ],
    },
    class: 'external',
    module: {
      path: 'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/module.js',
      hash: '55639ded661056f85f137ea99dbbd91e8206db92243bd69a5d827054a9c7e77f',
      loadingStrategy: 'script',
    },
    baseURL: 'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel',
    signature: {
      status: 'valid',
      type: 'grafana',
      org: 'grafana',
    },
    translations: {
      'cs-CZ':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/cs-CZ/grafana-clock-panel.json',
      'de-DE':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/de-DE/grafana-clock-panel.json',
      'en-US':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/en-US/grafana-clock-panel.json',
      'es-ES':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/es-ES/grafana-clock-panel.json',
      'fr-FR':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/fr-FR/grafana-clock-panel.json',
      'hu-HU':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/hu-HU/grafana-clock-panel.json',
      'id-ID':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/id-ID/grafana-clock-panel.json',
      'it-IT':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/it-IT/grafana-clock-panel.json',
      'ja-JP':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/ja-JP/grafana-clock-panel.json',
      'ko-KR':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/ko-KR/grafana-clock-panel.json',
      'nl-NL':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/nl-NL/grafana-clock-panel.json',
      'pl-PL':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/pl-PL/grafana-clock-panel.json',
      'pt-BR':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/pt-BR/grafana-clock-panel.json',
      'pt-PT':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/pt-PT/grafana-clock-panel.json',
      'ru-RU':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/ru-RU/grafana-clock-panel.json',
      'sv-SE':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/sv-SE/grafana-clock-panel.json',
      'tr-TR':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/tr-TR/grafana-clock-panel.json',
      'zh-Hans':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/zh-Hans/grafana-clock-panel.json',
      'zh-Hant':
        'https://plugins-cdn.grafana-dev.net/grafana-clock-panel/3.2.1/public/plugins/grafana-clock-panel/locales/zh-Hant/grafana-clock-panel.json',
    },
  },
  status: {},
});

export const v0alpha1Meta: Meta = structuredClone({
  kind: 'Meta',
  apiVersion: 'plugins.grafana.app/v0alpha1',
  metadata: {
    name: 'myorg-someplugin-app',
    namespace: 'default',
  },
  spec: {
    pluginJson: {
      id: 'myorg-someplugin-app',
      type: 'app',
      name: 'Some-Plugin',
      info: {
        keywords: ['app'],
        logos: {
          small: 'public/plugins/myorg-someplugin-app/img/logo.svg',
          large: 'public/plugins/myorg-someplugin-app/img/logo.svg',
        },
        updated: '2025-12-15',
        version: '1.0.0',
        author: {
          name: 'Myorg',
        },
      },
      dependencies: {
        grafanaDependency: '>=10.4.0',
        grafanaVersion: '*',
      },
      includes: [
        {
          type: 'page',
          name: 'Page One',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-someplugin-app/one',
          addToNav: true,
          defaultNav: true,
        },
        {
          type: 'page',
          name: 'Page Two',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-someplugin-app/two',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Page Three',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-someplugin-app/three',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Page Four',
          role: 'Viewer',
          action: 'plugins.app:access',
          path: '/a/myorg-someplugin-app/four',
          addToNav: true,
        },
        {
          type: 'page',
          name: 'Configuration',
          role: 'Admin',
          path: '/plugins/myorg-someplugin-app',
          addToNav: true,
          icon: 'cog',
        },
      ],
    },
    class: 'external',
    module: {
      path: 'public/plugins/myorg-someplugin-app/module.js',
      loadingStrategy: 'script',
    },
    baseURL: 'public/plugins/myorg-someplugin-app',
    signature: {
      status: 'unsigned',
    },
    angular: {
      detected: false,
    },
  },
  status: {},
});

export const v0alpha1Response: PluginMetasResponse = structuredClone({
  items: [
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'alertlist',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'alertlist',
          type: 'panel',
          name: 'Alert list',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/alertlist/img/icn-singlestat-panel.svg',
              large: 'app/plugins/panel/alertlist/img/icn-singlestat-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Shows list of alerts and their current status',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/alert-list/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          skipDataQuery: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/alertlist',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/alertlist',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'alertmanager',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'alertmanager',
          type: 'datasource',
          name: 'Alertmanager',
          info: {
            keywords: ['alerts', 'alerting', 'prometheus', 'alertmanager', 'mimir', 'cortex'],
            logos: {
              small: 'app/plugins/datasource/alertmanager/dist/img/logo.svg',
              large: 'app/plugins/datasource/alertmanager/dist/img/logo.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Prometheus alertmanager',
              url: 'https://grafana.com',
            },
            description:
              'Add external Alertmanagers (supports Prometheus and Mimir implementations) so you can use the Grafana Alerting UI to manage silences, contact points, and notification policies.',
            links: [
              {
                name: 'Learn more',
                url: 'https://prometheus.io/docs/alerting/latest/alertmanager/',
              },
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/alertmanager/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          routes: [
            {
              path: 'alertmanager/api/v2/silences',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v2/silences',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'alertmanager/api/v2/silences',
              method: 'POST',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'api/v2/silences',
              method: 'POST',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'alertmanager/api/v2/silence/',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v2/silence/',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'alertmanager/api/v2/silence/',
              method: 'DELETE',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'api/v2/silence/',
              method: 'DELETE',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'alertmanager/api/v2/alerts/groups',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v2/alerts/groups',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'alertmanager/api/v2/alerts',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v2/alerts',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'alertmanager/api/v2/alerts',
              method: 'POST',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'api/v2/alerts',
              method: 'POST',
              reqRole: 'Editor',
              reqAction: 'alert.instances.external:write',
            },
            {
              path: 'alertmanager/api/v2/status',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.notifications.external:read',
            },
            {
              path: 'api/v2/status',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.notifications.external:read',
            },
            {
              path: 'alertmanager/api/v2/receivers',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v2/receivers',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.instances.external:read',
            },
            {
              path: 'api/v1/alerts',
              method: 'GET',
              reqRole: 'Viewer',
              reqAction: 'alert.notifications.external:read',
            },
            {
              path: 'api/v1/alerts',
              method: 'POST',
              reqRole: 'Editor',
              reqAction: 'alert.notifications.external:write',
            },
            {
              path: 'api/v1/alerts',
              method: 'DELETE',
              reqRole: 'Editor',
              reqAction: 'alert.notifications.external:write',
            },
            {
              method: 'POST',
              reqRole: 'Admin',
            },
            {
              method: 'PUT',
              reqRole: 'Admin',
            },
            {
              method: 'DELETE',
              reqRole: 'Admin',
            },
            {
              method: 'GET',
              reqRole: 'Admin',
            },
          ],
        },
        class: 'core',
        module: {
          path: 'core:plugin/alertmanager',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/alertmanager',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'annolist',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'annolist',
          type: 'panel',
          name: 'Annotations list',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/annolist/img/icn-annolist-panel.svg',
              large: 'app/plugins/panel/annolist/img/icn-annolist-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'List annotations',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/annotations/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          skipDataQuery: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/annolist',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/annolist',
        aliasIds: ['ryantxu-annolist-panel'],
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'barchart',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'barchart',
          type: 'panel',
          name: 'Bar chart',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/barchart/img/barchart.svg',
              large: 'app/plugins/panel/barchart/img/barchart.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Categorical charts with group support',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/bar-chart/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/barchart',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/barchart',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'bargauge',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'bargauge',
          type: 'panel',
          name: 'Bar gauge',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/bargauge/img/icon_bar_gauge.svg',
              large: 'app/plugins/panel/bargauge/img/icon_bar_gauge.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Horizontal and vertical gauges',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/bar-gauge/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/bargauge',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/bargauge',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'candlestick',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'candlestick',
          type: 'panel',
          name: 'Candlestick',
          info: {
            keywords: ['financial', 'price', 'currency', 'k-line'],
            logos: {
              small: 'app/plugins/panel/candlestick/img/candlestick.svg',
              large: 'app/plugins/panel/candlestick/img/candlestick.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Graphical representation of price movements of a security, derivative, or currency.',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/candlestick/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/candlestick',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/candlestick',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'canvas',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'canvas',
          type: 'panel',
          name: 'Canvas',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/canvas/img/icn-canvas.svg',
              large: 'app/plugins/panel/canvas/img/icn-canvas.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Explicit element placement',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/canvas/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/canvas',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/canvas',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'cloudwatch',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'cloudwatch',
          type: 'datasource',
          name: 'CloudWatch',
          info: {
            keywords: ['aws', 'amazon'],
            logos: {
              small: 'app/plugins/datasource/cloudwatch/dist/img/amazon-web-services.png',
              large: 'app/plugins/datasource/cloudwatch/dist/img/amazon-web-services.png',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Data source for Amazon AWS monitoring service',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/aws-cloudwatch/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          alerting: true,
          annotations: true,
          backend: true,
          category: 'cloud',
          includes: [
            {
              type: 'dashboard',
              name: 'EC2',
              role: 'Viewer',
              path: 'dashboards/ec2.json',
            },
            {
              type: 'dashboard',
              name: 'EBS',
              role: 'Viewer',
              path: 'dashboards/EBS.json',
            },
            {
              type: 'dashboard',
              name: 'Lambda',
              role: 'Viewer',
              path: 'dashboards/Lambda.json',
            },
            {
              type: 'dashboard',
              name: 'Logs',
              role: 'Viewer',
              path: 'dashboards/Logs.json',
            },
            {
              type: 'dashboard',
              name: 'RDS',
              role: 'Viewer',
              path: 'dashboards/RDS.json',
            },
          ],
          logs: true,
          metrics: true,
          queryOptions: {
            minInterval: true,
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/cloudwatch',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/cloudwatch',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'dashboard',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'dashboard',
          type: 'datasource',
          name: '-- Dashboard --',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/datasource/dashboard/dist/img/icn-reusequeries.svg',
              large: 'app/plugins/datasource/dashboard/dist/img/icn-reusequeries.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Uses the result set from another panel in the same dashboard',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          builtIn: true,
          metrics: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/dashboard',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/dashboard',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'dashlist',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'dashlist',
          type: 'panel',
          name: 'Dashboard list',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/dashlist/img/icn-dashlist-panel.svg',
              large: 'app/plugins/panel/dashlist/img/icn-dashlist-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'List of dynamic links to other dashboards',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/dashboard-list/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          skipDataQuery: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/dashlist',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/dashlist',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'debug',
        namespace: 'default',
      },
      spec: {
        aliasIds: ['debugX'],
        pluginJson: {
          id: 'debug',
          type: 'panel',
          name: 'Debug',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/debug/img/icn-debug.svg',
              large: 'app/plugins/panel/debug/img/icn-debug.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Debug Panel for Grafana',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          state: 'alpha',
        },
        class: 'core',
        module: {
          path: 'core:plugin/debug',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/debug',
        signature: {
          status: 'internal',
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'elasticsearch',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'elasticsearch',
          type: 'datasource',
          name: 'Elasticsearch',
          info: {
            keywords: ['elasticsearch', 'datasource', 'database', 'logs', 'nosql', 'traces'],
            logos: {
              small: 'app/plugins/datasource/elasticsearch/dist/img/elasticsearch.svg',
              large: 'app/plugins/datasource/elasticsearch/dist/img/elasticsearch.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Open source logging & analytics database',
            links: [
              {
                name: 'Learn more',
                url: 'https://grafana.com/docs/features/datasources/elasticsearch/',
              },
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/elasticsearch/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          alerting: true,
          annotations: true,
          backend: true,
          category: 'logging',
          logs: true,
          metrics: true,
          queryOptions: {
            minInterval: true,
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/elasticsearch',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/elasticsearch',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'flamegraph',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'flamegraph',
          type: 'panel',
          name: 'Flame Graph',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/flamegraph/img/icn-flamegraph.svg',
              large: 'app/plugins/panel/flamegraph/img/icn-flamegraph.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/flame-graph/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/flamegraph',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/flamegraph',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'gauge',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'gauge',
          type: 'panel',
          name: 'Gauge',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/gauge/img/icon_gauge.svg',
              large: 'app/plugins/panel/gauge/img/icon_gauge.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Standard gauge visualization',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/gauge/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/gauge',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/gauge',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'geomap',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'geomap',
          type: 'panel',
          name: 'Geomap',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/geomap/img/icn-geomap.svg',
              large: 'app/plugins/panel/geomap/img/icn-geomap.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Geomap panel',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/geomap/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/geomap',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/geomap',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana',
          type: 'datasource',
          name: '-- Grafana --',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/datasource/grafana/dist/img/icn-grafanadb.svg',
              large: 'app/plugins/datasource/grafana/dist/img/icn-grafanadb.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description:
              'A built-in data source that generates random walk data and can poll the Testdata data source. This helps you test visualizations and run experiments.',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          annotations: true,
          backend: true,
          builtIn: true,
          metrics: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/grafana',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/grafana',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-azure-monitor-datasource',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-azure-monitor-datasource',
          type: 'datasource',
          name: 'Azure Monitor',
          info: {
            keywords: ['azure', 'monitor', 'Application Insights', 'Log Analytics', 'App Insights'],
            logos: {
              small: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/img/logo.jpg',
              large: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/img/logo.jpg',
            },
            updated: '',
            version: '12.4.0-pre',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Data source for Microsoft Azure Monitor & Application Insights',
            links: [
              {
                name: 'Learn more',
                url: 'https://grafana.com/docs/grafana/latest/datasources/azuremonitor/',
              },
              {
                name: 'License',
                url: 'https://github.com/grafana/grafana/blob/HEAD/LICENSE',
              },
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/azure-monitor/',
              },
            ],
            screenshots: [
              {
                name: 'Azure Contoso Loans',
                path: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/img/contoso_loans_grafana_dashboard.png',
              },
              {
                name: 'Azure Monitor Network',
                path: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/img/azure_monitor_network.png',
              },
              {
                name: 'Azure Monitor CPU',
                path: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/img/azure_monitor_cpu.png',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=10.3.0',
            grafanaVersion: '*',
          },
          alerting: true,
          annotations: true,
          backend: true,
          category: 'cloud',
          executable: 'gpx_azuremonitor',
          includes: [
            {
              type: 'dashboard',
              name: 'Azure / Alert Consumption',
              role: 'Viewer',
              path: 'dashboards/v1Alerts.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Infrastructure / Apps Monitoring',
              role: 'Viewer',
              path: 'dashboards/azureInfraApps.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Infrastructure / Compute Monitoring',
              role: 'Viewer',
              path: 'dashboards/azureInfraCompute.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Infrastructure / Data Monitoring',
              role: 'Viewer',
              path: 'dashboards/azureInfraData.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Infrastructure / Network Monitoring',
              role: 'Viewer',
              path: 'dashboards/azureInfraNetwork.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Infrastructure / Storage and Key Vaults Monitoring',
              role: 'Viewer',
              path: 'dashboards/azureInfraStorageVaults.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Azure PostgreSQL / Flexible Server Monitoring',
              role: 'Viewer',
              path: 'dashboards/postgresFlexibleServer.json',
            },
            {
              type: 'dashboard',
              name: 'Azure Monitor / Container Insights / Syslog',
              role: 'Viewer',
              path: 'dashboards/containerInsightsSyslog.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications',
              role: 'Viewer',
              path: 'dashboards/appInsights.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications / Performance / Operations',
              role: 'Viewer',
              path: 'dashboards/appInsightsPerfOperations.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications / Performance / Dependencies',
              role: 'Viewer',
              path: 'dashboards/appInsightsPerfDependencies.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications / Failures / Operations',
              role: 'Viewer',
              path: 'dashboards/appInsightsFailureOperations.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications / Failures / Dependencies',
              role: 'Viewer',
              path: 'dashboards/appInsightsFailureDependencies.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications / Failures / Exceptions',
              role: 'Viewer',
              path: 'dashboards/appInsightsFailureExceptions.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Applications Test Availability Geo Map',
              role: 'Viewer',
              path: 'dashboards/appInsightsGeoMap.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / CosmosDB',
              role: 'Viewer',
              path: 'dashboards/cosmosdb.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Data Explorer Clusters',
              role: 'Viewer',
              path: 'dashboards/adx.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Key Vaults',
              role: 'Viewer',
              path: 'dashboards/keyvault.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Networks',
              role: 'Viewer',
              path: 'dashboards/networkInsightsDashboard.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / SQL Database',
              role: 'Viewer',
              path: 'dashboards/sqldb.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Storage Accounts',
              role: 'Viewer',
              path: 'dashboards/storage.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Virtual Machines by Resource Group',
              role: 'Viewer',
              path: 'dashboards/vMInsightsRG.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Insights / Virtual Machines by Workspace',
              role: 'Viewer',
              path: 'dashboards/vMInsightsWorkspace.json',
            },
            {
              type: 'dashboard',
              name: 'Azure / Resources Overview',
              role: 'Viewer',
              path: 'dashboards/arg.json',
            },
          ],
          logs: true,
          metrics: true,
          tracing: true,
        },
        class: 'core',
        module: {
          path: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/grafana-azure-monitor-datasource/dist',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
        translations: {
          'cs-CZ':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/cs-CZ/grafana-azure-monitor-datasource.json',
          'de-DE':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/de-DE/grafana-azure-monitor-datasource.json',
          'en-US':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/en-US/grafana-azure-monitor-datasource.json',
          'es-ES':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/es-ES/grafana-azure-monitor-datasource.json',
          'fr-FR':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/fr-FR/grafana-azure-monitor-datasource.json',
          'hu-HU':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/hu-HU/grafana-azure-monitor-datasource.json',
          'id-ID':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/id-ID/grafana-azure-monitor-datasource.json',
          'it-IT':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/it-IT/grafana-azure-monitor-datasource.json',
          'ja-JP':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/ja-JP/grafana-azure-monitor-datasource.json',
          'ko-KR':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/ko-KR/grafana-azure-monitor-datasource.json',
          'nl-NL':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/nl-NL/grafana-azure-monitor-datasource.json',
          'pl-PL':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/pl-PL/grafana-azure-monitor-datasource.json',
          'pt-BR':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/pt-BR/grafana-azure-monitor-datasource.json',
          'pt-PT':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/pt-PT/grafana-azure-monitor-datasource.json',
          'ru-RU':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/ru-RU/grafana-azure-monitor-datasource.json',
          'sv-SE':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/sv-SE/grafana-azure-monitor-datasource.json',
          'tr-TR':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/tr-TR/grafana-azure-monitor-datasource.json',
          'zh-Hans':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/zh-Hans/grafana-azure-monitor-datasource.json',
          'zh-Hant':
            'app/plugins/datasource/grafana-azure-monitor-datasource/locales/zh-Hant/grafana-azure-monitor-datasource.json',
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-exploretraces-app',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-exploretraces-app',
          type: 'app',
          name: 'Grafana Traces Drilldown',
          info: {
            keywords: ['app', 'tempo', 'traces', 'explore'],
            logos: {
              small: 'app/plugins/panel/grafana-exploretraces-app/img/logo.svg',
              large: 'app/plugins/panel/grafana-exploretraces-app/img/logo.svg',
            },
            updated: '2025-12-04',
            version: '1.2.2',
            author: {
              name: 'Grafana',
            },
            description:
              'Use Rate, Errors, and Duration (RED) metrics derived from traces to investigate errors within complex distributed systems.',
            links: [
              {
                name: 'Github',
                url: 'https://github.com/grafana/explore-traces',
              },
              {
                name: 'Report bug',
                url: 'https://github.com/grafana/explore-traces/issues/new',
              },
            ],
            screenshots: [
              {
                name: 'histogram-breakdown',
                path: 'app/plugins/panel/grafana-exploretraces-app/img/histogram-breakdown.png',
              },
              {
                name: 'errors-metric-flow',
                path: 'app/plugins/panel/grafana-exploretraces-app/img/errors-metric-flow.png',
              },
              {
                name: 'errors-root-cause',
                path: 'app/plugins/panel/grafana-exploretraces-app/img/errors-root-cause.png',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=11.5.0',
            grafanaVersion: '*',
            extensions: {
              exposedComponents: [
                'grafana-asserts-app/entity-assertions-widget/v1',
                'grafana-asserts-app/insights-timeline-widget/v1',
              ],
            },
          },
          autoEnabled: true,
          includes: [
            {
              type: 'page',
              name: 'Explore',
              role: 'Viewer',
              action: 'datasources:explore',
              path: '/a/grafana-exploretraces-app/',
              addToNav: true,
              defaultNav: true,
            },
          ],
          preload: true,
          extensions: {
            addedComponents: [
              {
                targets: ['grafana-asserts-app/entity-assertions-widget/v1'],
                title: 'Asserts widget',
                description: 'A block with assertions for a given service',
              },
              {
                targets: ['grafana-asserts-app/insights-timeline-widget/v1'],
                title: 'Insights Timeline Widget',
                description: 'Widget for displaying insights timeline in other apps',
              },
            ],
            addedLinks: [
              {
                targets: ['grafana/dashboard/panel/menu'],
                title: 'Open in Traces Drilldown',
                description: 'Open current query in the Traces Drilldown app',
              },
              {
                targets: ['grafana/explore/toolbar/action'],
                title: 'Open in Grafana Traces Drilldown',
                description: 'Try our new queryless experience for traces',
              },
            ],
            exposedComponents: [
              {
                id: 'grafana-exploretraces-app/open-in-explore-traces-button/v1',
                title: 'Open in Traces Drilldown button',
                description: 'A button that opens a traces view in the Traces Drilldown app.',
              },
              {
                id: 'grafana-exploretraces-app/embedded-trace-exploration/v1',
                title: 'Embedded Trace Exploration',
                description:
                  'A component that renders a trace exploration view that can be embedded in other parts of Grafana.',
              },
            ],
            extensionPoints: [
              {
                id: 'grafana-exploretraces-app/investigation/v1',
              },
              {
                id: 'grafana-exploretraces-app/get-logs-drilldown-link/v1',
              },
            ],
          },
        },
        class: 'external',
        module: {
          path: 'public/plugins/grafana-exploretraces-app/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/grafana-exploretraces-app',
        signature: {
          status: 'valid',
          type: 'grafana',
          org: 'Grafana Labs',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-lokiexplore-app',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-lokiexplore-app',
          type: 'app',
          name: 'Grafana Logs Drilldown',
          info: {
            keywords: ['app', 'loki', 'explore', 'logs', 'drilldown', 'drill', 'down', 'drill-down'],
            logos: {
              small: 'app/plugins/panel/grafana-lokiexplore-app/img/logo.svg',
              large: 'app/plugins/panel/grafana-lokiexplore-app/img/logo.svg',
            },
            updated: '2025-12-09',
            version: '1.0.32',
            author: {
              name: 'Grafana',
            },
            description:
              'Visualize log volumes to easily detect anomalies or significant changes over time, without needing to compose LogQL queries.',
            links: [
              {
                name: 'Github',
                url: 'https://github.com/grafana/explore-logs',
              },
              {
                name: 'Report bug',
                url: 'https://github.com/grafana/explore-logs/issues/new',
              },
            ],
            screenshots: [
              {
                name: 'patterns',
                path: 'app/plugins/panel/grafana-lokiexplore-app/img/patterns.png',
              },
              {
                name: 'fields',
                path: 'app/plugins/panel/grafana-lokiexplore-app/img/fields.png',
              },
              {
                name: 'table',
                path: 'app/plugins/panel/grafana-lokiexplore-app/img/table.png',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=11.6.0',
            grafanaVersion: '*',
            extensions: {
              exposedComponents: [
                'grafana-adaptivelogs-app/temporary-exemptions/v1',
                'grafana-lokiexplore-app/embedded-logs-exploration/v1',
                'grafana-asserts-app/insights-timeline-widget/v1',
                'grafana/add-to-dashboard-form/v1',
              ],
            },
          },
          autoEnabled: true,
          includes: [
            {
              type: 'page',
              name: 'Grafana Logs Drilldown',
              role: 'Viewer',
              action: 'datasources:explore',
              path: '/a/grafana-lokiexplore-app/explore',
              addToNav: true,
              defaultNav: true,
            },
          ],
          preload: true,
          extensions: {
            addedComponents: [
              {
                targets: ['grafana-asserts-app/insights-timeline-widget/v1'],
                title: 'Insights Timeline Widget',
                description: 'Widget for displaying insights timeline in other apps',
              },
            ],
            addedLinks: [
              {
                targets: [
                  'grafana/dashboard/panel/menu',
                  'grafana/explore/toolbar/action',
                  'grafana-metricsdrilldown-app/open-in-logs-drilldown/v1',
                  'grafana-assistant-app/navigateToDrilldown/v1',
                ],
                title: 'Open in Grafana Logs Drilldown',
                description: 'Open current query in the Grafana Logs Drilldown view',
              },
            ],
            addedFunctions: [
              {
                targets: ['grafana-exploretraces-app/get-logs-drilldown-link/v1'],
                title: 'Open Logs Drilldown',
                description: 'Returns url to logs drilldown app',
              },
            ],
            exposedComponents: [
              {
                id: 'grafana-lokiexplore-app/open-in-explore-logs-button/v1',
                title: 'Open in Logs Drilldown button',
                description: 'A button that opens a logs view in the Logs Drilldown app.',
              },
              {
                id: 'grafana-lokiexplore-app/embedded-logs-exploration/v1',
                title: 'Embedded Logs Exploration',
                description:
                  'A component that renders a logs exploration view that can be embedded in other parts of Grafana.',
              },
            ],
            extensionPoints: [
              {
                id: 'grafana-lokiexplore-app/investigation/v1',
              },
            ],
          },
        },
        class: 'external',
        module: {
          path: 'public/plugins/grafana-lokiexplore-app/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/grafana-lokiexplore-app',
        signature: {
          status: 'valid',
          type: 'grafana',
          org: 'Grafana Labs',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-metricsdrilldown-app',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-metricsdrilldown-app',
          type: 'app',
          name: 'Grafana Metrics Drilldown',
          info: {
            keywords: ['drilldown', 'metrics', 'app', 'prometheus', 'mimir'],
            logos: {
              small: 'app/plugins/panel/grafana-metricsdrilldown-app/img/logo.svg',
              large: 'app/plugins/panel/grafana-metricsdrilldown-app/img/logo.svg',
            },
            updated: '2025-12-17',
            version: '1.0.26',
            author: {
              name: 'Grafana',
            },
            description:
              'Quickly find related metrics with a few clicks, without needing to write PromQL queries to retrieve metrics.',
            links: [
              {
                name: 'GitHub',
                url: 'https://github.com/grafana/metrics-drilldown',
              },
              {
                name: 'Report a bug',
                url: 'https://github.com/grafana/metrics-drilldown/issues/new',
              },
            ],
            screenshots: [
              {
                name: 'metricselect',
                path: 'app/plugins/panel/grafana-metricsdrilldown-app/img/metrics-drilldown.png',
              },
              {
                name: 'breakdown',
                path: 'app/plugins/panel/grafana-metricsdrilldown-app/img/breakdown.png',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=11.6.0',
            grafanaVersion: '*',
            extensions: {
              exposedComponents: ['grafana/add-to-dashboard-form/v1'],
            },
          },
          autoEnabled: true,
          includes: [
            {
              type: 'page',
              name: 'Grafana Metrics Drilldown',
              role: 'Viewer',
              action: 'datasources:explore',
              path: '/a/grafana-metricsdrilldown-app/drilldown',
              addToNav: true,
              defaultNav: true,
            },
          ],
          preload: true,
          extensions: {
            addedLinks: [
              {
                targets: [
                  'grafana/dashboard/panel/menu',
                  'grafana/explore/toolbar/action',
                  'grafana-assistant-app/navigateToDrilldown/v1',
                  'grafana/alerting/alertingrule/queryeditor',
                ],
                title: 'Open in Grafana Metrics Drilldown',
                description: 'Open current query in the Grafana Metrics Drilldown view',
              },
              {
                targets: ['grafana-metricsdrilldown-app/grafana-assistant-app/navigateToDrilldown/v0-alpha'],
                title: 'Navigate to metrics drilldown',
                description: 'Build a url path to the metrics drilldown',
              },
              {
                targets: ['grafana/datasources/config/actions', 'grafana/datasources/config/status'],
                title: 'Open in Metrics Drilldown',
                description: 'Browse metrics in Grafana Metrics Drilldown',
              },
            ],
            exposedComponents: [
              {
                id: 'grafana-metricsdrilldown-app/label-breakdown-component/v1',
                title: 'Label Breakdown',
                description: 'A metrics label breakdown view from the Metrics Drilldown app.',
              },
              {
                id: 'grafana-metricsdrilldown-app/knowledge-graph-insight-metrics/v1',
                title: 'Knowledge Graph Source Metrics',
                description: 'Explore the underlying metrics related to a Knowledge Graph insight',
              },
            ],
            extensionPoints: [
              {
                id: 'grafana-exploremetrics-app/investigation/v1',
              },
              {
                id: 'grafana-metricsdrilldown-app/open-in-logs-drilldown/v1',
              },
            ],
          },
        },
        class: 'external',
        module: {
          path: 'public/plugins/grafana-metricsdrilldown-app/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/grafana-metricsdrilldown-app',
        signature: {
          status: 'valid',
          type: 'grafana',
          org: 'Grafana Labs',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-pyroscope-app',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-pyroscope-app',
          type: 'app',
          name: 'Grafana Profiles Drilldown',
          info: {
            keywords: ['app', 'pyroscope', 'profiling', 'explore', 'profiles', 'performance', 'drilldown'],
            logos: {
              small: 'app/plugins/panel/grafana-pyroscope-app/img/logo.svg',
              large: 'app/plugins/panel/grafana-pyroscope-app/img/logo.svg',
            },
            updated: '2025-12-18',
            version: '1.14.2',
            author: {
              name: 'Grafana',
            },
            description:
              'View and analyze high-level service performance, identify problem processes for optimization, and diagnose issues to determine root causes.',
            links: [
              {
                name: 'GitHub',
                url: 'https://github.com/grafana/profiles-drilldown',
              },
              {
                name: 'Report bug',
                url: 'https://github.com/grafana/profiles-drilldown/issues/new',
              },
            ],
            screenshots: [
              {
                name: 'Hero Image',
                path: 'app/plugins/panel/grafana-pyroscope-app/img/hero-image.png',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=11.5.0',
            grafanaVersion: '*',
            extensions: {
              exposedComponents: [
                'grafana-o11yinsights-app/insights-launcher/v1',
                'grafana-adaptiveprofiles-app/resolution-boost/v1',
              ],
            },
          },
          autoEnabled: true,
          includes: [
            {
              type: 'page',
              name: 'Profiles',
              role: 'Viewer',
              action: 'datasources:explore',
              path: '/a/grafana-pyroscope-app/explore',
              addToNav: true,
              defaultNav: true,
            },
          ],
          preload: true,
          extensions: {
            addedLinks: [
              {
                targets: [
                  'grafana/explore/toolbar/action',
                  'grafana/traceview/details',
                  'grafana-assistant-app/navigateToDrilldown/v1',
                ],
                title: 'Open in Grafana Profiles Drilldown',
                description: 'Try our new queryless experience for profiles',
              },
            ],
            exposedComponents: [
              {
                id: 'grafana-pyroscope-app/embedded-profiles-exploration/v1',
                title: 'Embedded Profiles Exploration',
                description:
                  'A component that renders a profiles exploration view that can be embedded in other parts of Grafana.',
              },
            ],
            extensionPoints: [
              {
                id: 'grafana-pyroscope-app/investigation/v1',
              },
              {
                id: 'grafana-pyroscope-app/settings/v1',
              },
            ],
          },
        },
        class: 'external',
        module: {
          path: 'public/plugins/grafana-pyroscope-app/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/grafana-pyroscope-app',
        signature: {
          status: 'valid',
          type: 'grafana',
          org: 'Grafana Labs',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'grafana-testdata-datasource',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'grafana-testdata-datasource',
          type: 'datasource',
          name: 'TestData',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/datasource/grafana-testdata-datasource/dist/img/testdata.svg',
              large: 'app/plugins/datasource/grafana-testdata-datasource/dist/img/testdata.svg',
            },
            updated: '',
            version: '12.4.0-pre',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Generates test data in different forms',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/testdata/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=10.3.0-0',
            grafanaVersion: '*',
          },
          alerting: true,
          annotations: true,
          backend: true,
          executable: 'gpx_testdata',
          includes: [
            {
              type: 'dashboard',
              name: 'Streaming Example',
              role: 'Viewer',
              path: 'dashboards/streaming.json',
            },
          ],
          logs: true,
          metrics: true,
          queryOptions: {
            maxDataPoints: true,
            minInterval: true,
          },
        },
        class: 'core',
        module: {
          path: 'app/plugins/datasource/grafana-testdata-datasource/dist/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/grafana-testdata-datasource/dist',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'graphite',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'graphite',
          type: 'datasource',
          name: 'Graphite',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/datasource/graphite/dist/img/graphite_logo.png',
              large: 'app/plugins/datasource/graphite/dist/img/graphite_logo.png',
            },
            updated: '',
            version: '12.4.0-pre',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Open source time series database',
            links: [
              {
                name: 'Learn more',
                url: 'https://graphiteapp.org/',
              },
              {
                name: 'Graphite 1.1 Release',
                url: 'https://grafana.com/blog/2018/01/11/graphite-1.1-teaching-an-old-dog-new-tricks/',
              },
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/graphite/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '>=10.3.0',
            grafanaVersion: '*',
          },
          alerting: true,
          annotations: true,
          backend: true,
          category: 'tsdb',
          executable: 'gpx_graphite',
          includes: [
            {
              type: 'dashboard',
              name: 'Graphite Carbon Metrics',
              role: 'Viewer',
              path: 'dashboards/carbon_metrics.json',
            },
            {
              type: 'dashboard',
              name: 'Metrictank (Graphite alternative)',
              role: 'Viewer',
              path: 'dashboards/metrictank.json',
            },
          ],
          metrics: true,
          queryOptions: {
            maxDataPoints: true,
            cacheTimeout: true,
          },
        },
        class: 'core',
        module: {
          path: 'app/plugins/datasource/graphite/dist/module.js',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/graphite/dist',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'heatmap',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'heatmap',
          type: 'panel',
          name: 'Heatmap',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/heatmap/img/icn-heatmap-panel.svg',
              large: 'app/plugins/panel/heatmap/img/icn-heatmap-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Like a histogram over time',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/heatmap/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/heatmap',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/heatmap',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'histogram',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'histogram',
          type: 'panel',
          name: 'Histogram',
          info: {
            keywords: ['distribution', 'bar chart', 'frequency', 'proportional'],
            logos: {
              small: 'app/plugins/panel/histogram/img/histogram.svg',
              large: 'app/plugins/panel/histogram/img/histogram.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Distribution of values presented as a bar chart.',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/histogram/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/histogram',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/histogram',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'logs',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'logs',
          type: 'panel',
          name: 'Logs',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/logs/img/icn-logs-panel.svg',
              large: 'app/plugins/panel/logs/img/icn-logs-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/logs/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/logs',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/logs',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'mixed',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'mixed',
          type: 'datasource',
          name: '-- Mixed --',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/datasource/mixed/dist/img/icn-mixeddatasources.svg',
              large: 'app/plugins/datasource/mixed/dist/img/icn-mixeddatasources.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Lets you query multiple data sources in the same panel.',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/datasources/#special-data-sources',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          builtIn: true,
          metrics: true,
          queryOptions: {
            minInterval: true,
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/mixed',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/datasource/mixed',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'news',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'news',
          type: 'panel',
          name: 'News',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/news/img/news.svg',
              large: 'app/plugins/panel/news/img/news.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'RSS feed reader',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/news/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          skipDataQuery: true,
          state: 'beta',
        },
        class: 'core',
        module: {
          path: 'core:plugin/news',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/news',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'nodeGraph',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'nodeGraph',
          type: 'panel',
          name: 'Node Graph',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/nodeGraph/img/icn-node-graph.svg',
              large: 'app/plugins/panel/nodeGraph/img/icn-node-graph.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/node-graph/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/nodeGraph',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/nodeGraph',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'piechart',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'piechart',
          type: 'panel',
          name: 'Pie chart',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/piechart/img/icon_piechart.svg',
              large: 'app/plugins/panel/piechart/img/icon_piechart.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'The new core pie chart visualization',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/pie-chart/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/piechart',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/piechart',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'stat',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'stat',
          type: 'panel',
          name: 'Stat',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/stat/img/icn-singlestat-panel.svg',
              large: 'app/plugins/panel/stat/img/icn-singlestat-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Big stat values & sparklines',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/stat/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/stat',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/stat',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'state-timeline',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'state-timeline',
          type: 'panel',
          name: 'State timeline',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/state-timeline/img/timeline.svg',
              large: 'app/plugins/panel/state-timeline/img/timeline.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'State changes and durations',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/state-timeline/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/state-timeline',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/state-timeline',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'status-history',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'status-history',
          type: 'panel',
          name: 'Status history',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/status-history/img/status.svg',
              large: 'app/plugins/panel/status-history/img/status.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Periodic status history',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/status-history/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/status-history',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/status-history',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'table',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'table',
          type: 'panel',
          name: 'Table',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/table/img/icn-table-panel.svg',
              large: 'app/plugins/panel/table/img/icn-table-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Supports many column styles',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/table/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/table',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/table',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'text',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'text',
          type: 'panel',
          name: 'Text',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/text/img/icn-text-panel.svg',
              large: 'app/plugins/panel/text/img/icn-text-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Supports markdown and html content',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/text/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          skipDataQuery: true,
        },
        class: 'core',
        module: {
          path: 'core:plugin/text',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/text',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'timeseries',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'timeseries',
          type: 'panel',
          name: 'Time series',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/timeseries/img/icn-timeseries-panel.svg',
              large: 'app/plugins/panel/timeseries/img/icn-timeseries-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Time based line, area and bar charts',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/time-series/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/timeseries',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/timeseries',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'traces',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'traces',
          type: 'panel',
          name: 'Traces',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/traces/img/traces-panel.svg',
              large: 'app/plugins/panel/traces/img/traces-panel.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/traces/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/traces',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/traces',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'trend',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'trend',
          type: 'panel',
          name: 'Trend',
          info: {
            keywords: [],
            logos: {
              small: 'app/plugins/panel/trend/img/trend.svg',
              large: 'app/plugins/panel/trend/img/trend.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Like timeseries, but when x != time',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/trend/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
          state: 'beta',
        },
        class: 'core',
        module: {
          path: 'core:plugin/trend',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/trend',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
    {
      kind: 'Meta',
      apiVersion: 'plugins.grafana.app/v0alpha1',
      metadata: {
        name: 'xychart',
        namespace: 'default',
      },
      spec: {
        pluginJson: {
          id: 'xychart',
          type: 'panel',
          name: 'XY Chart',
          info: {
            keywords: ['scatter', 'plot'],
            logos: {
              small: 'app/plugins/panel/xychart/img/icn-xychart.svg',
              large: 'app/plugins/panel/xychart/img/icn-xychart.svg',
            },
            updated: '',
            version: '',
            author: {
              name: 'Grafana Labs',
              url: 'https://grafana.com',
            },
            description: 'Supports arbitrary X vs Y in a graph to visualize the relationship between two variables.',
            links: [
              {
                name: 'Raise issue',
                url: 'https://github.com/grafana/grafana/issues/new',
              },
              {
                name: 'Documentation',
                url: 'https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/xy-chart/',
              },
            ],
          },
          dependencies: {
            grafanaDependency: '',
            grafanaVersion: '*',
          },
        },
        class: 'core',
        module: {
          path: 'core:plugin/xychart',
          loadingStrategy: 'script',
        },
        baseURL: 'app/plugins/panel/xychart',
        signature: {
          status: 'internal',
        },
        angular: {
          detected: false,
        },
      },
      status: {},
    },
  ],
});
