import { act, renderHook, waitFor } from '@testing-library/react';

import { type DataSourceInstanceListItem, type DataSourceInstanceSettings } from '@grafana/data';

import { setBackendSrv } from '../backendSrv';
import { setDatasourcePluginMetas } from '../pluginMeta/datasources';
import { setTemplateSrv, type TemplateSrv } from '../templateSrv';

import { _resetForTests as resetPlugin, setDataSourcePluginImporter } from './dataSource';
import {
  useDataSourceInstance,
  useDataSourceInstanceList,
  useDataSourceInstanceListItem,
  useDataSourceInstanceSettings,
  useDefaultDataSourceInstanceListItem,
  useHasDataSourceInstance,
} from './hooks';
import { setDataSourceInstanceSettings } from './settings';

function ds(overrides: Partial<DataSourceInstanceSettings>): DataSourceInstanceSettings {
  return {
    id: 1,
    uid: 'uid',
    name: 'name',
    type: 'test-db',
    access: 'direct',
    jsonData: {},
    readOnly: false,
    meta: {
      id: 'test-db',
      name: 'Test DB',
      type: 'datasource',
      module: '',
      baseUrl: '',
      info: {
        author: { name: '' },
        description: '',
        links: [],
        logos: { small: '', large: '' },
        screenshots: [],
        updated: '',
        version: '',
      },
      metrics: true,
    },
    ...overrides,
  } as DataSourceInstanceSettings;
}

const fixtures: Record<string, DataSourceInstanceSettings> = {
  Alpha: ds({ id: 1, uid: 'uid-alpha', name: 'Alpha', type: 'test-db' }),
  Bravo: ds({ id: 2, uid: 'uid-bravo', name: 'Bravo', type: 'test-db', isDefault: true }),
};

const templateSrv = {
  getVariables: () => [],
  replace: (value?: string) => value ?? '',
} as unknown as TemplateSrv;

beforeAll(() => {
  setTemplateSrv(templateSrv);
  setBackendSrv({
    get: jest.fn().mockResolvedValue({ datasources: fixtures, defaultDatasource: 'Bravo' }),
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  } as any);
});

// Distinguishable from the copy embedded on the instance settings, so the list-item hook's
// assertions prove which cache answered.
const testDbPluginMeta = { ...ds({}).meta, name: 'Test DB (plugin meta)' };

beforeEach(() => {
  resetPlugin();
  setDataSourceInstanceSettings(fixtures, 'Bravo');
  setDatasourcePluginMetas({ 'test-db': testDbPluginMeta });
});

describe('useDataSourceInstanceSettings', () => {
  it('starts loading then resolves to data', async () => {
    const { result } = renderHook(() => useDataSourceInstanceSettings('uid-alpha'));

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.settings?.name).toBe('Alpha');
    expect(result.current.error).toBeUndefined();
  });

  it('refetches when the ref changes', async () => {
    const { result, rerender } = renderHook(({ ref }) => useDataSourceInstanceSettings(ref), {
      initialProps: { ref: 'uid-alpha' },
    });

    await waitFor(() => expect(result.current.settings?.name).toBe('Alpha'));

    rerender({ ref: 'uid-bravo' });
    await waitFor(() => expect(result.current.settings?.name).toBe('Bravo'));
  });
});

describe('useDataSourceInstanceListItem', () => {
  it('starts loading then resolves to the list item', async () => {
    const { result } = renderHook(() => useDataSourceInstanceListItem('uid-alpha'));

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.item?.name).toBe('Alpha');
    expect(result.current.item?.type).toBe('test-db');
    expect(result.current.item?.meta.name).toBe('Test DB (plugin meta)');
    expect(result.current.error).toBeUndefined();
  });

  it('resolves to undefined without an error for an unknown ref', async () => {
    const { result } = renderHook(() => useDataSourceInstanceListItem('nonexistent'));

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.item).toBeUndefined();
    expect(result.current.error).toBeUndefined();
  });

  it('refetches when the ref changes', async () => {
    const { result, rerender } = renderHook(({ ref }) => useDataSourceInstanceListItem(ref), {
      initialProps: { ref: 'uid-alpha' },
    });

    await waitFor(() => expect(result.current.item?.name).toBe('Alpha'));

    rerender({ ref: 'uid-bravo' });
    await waitFor(() => expect(result.current.item?.name).toBe('Bravo'));
  });
});

describe('useDataSourceInstanceList', () => {
  it('populates items', async () => {
    const { result } = renderHook(() => useDataSourceInstanceList());

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.items.length).toBeGreaterThan(0);
  });

  it('does not re-fetch when the same filter function reference is re-rendered', async () => {
    const stableFilter = (x: DataSourceInstanceListItem) => Boolean(x.meta.metrics);
    const { result, rerender } = renderHook(({ filter }) => useDataSourceInstanceList({ filter }), {
      initialProps: { filter: stableFilter },
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    const itemsAfterFirstRender = result.current.items;

    rerender({ filter: stableFilter });
    await act(async () => {});

    // Same reference — no new fetch cycle, items reference is unchanged.
    expect(result.current.isLoading).toBe(false);
    expect(result.current.items).toBe(itemsAfterFirstRender);
  });

  it('re-fetches and updates items when the filter function reference changes', async () => {
    const filterA = (x: DataSourceInstanceListItem) => x.name === 'Alpha';
    const filterB = (x: DataSourceInstanceListItem) => x.name === 'Bravo';

    const { result, rerender } = renderHook(({ filter }) => useDataSourceInstanceList({ filter }), {
      initialProps: { filter: filterA },
    });

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.items.every((x) => x.name === 'Alpha')).toBe(true);

    rerender({ filter: filterB });
    await waitFor(() => expect(result.current.isLoading).toBe(false));

    expect(result.current.items.every((x) => x.name === 'Bravo')).toBe(true);
  });
});

describe('useDataSourceInstance', () => {
  it('starts loading then resolves to a plugin instance', async () => {
    const instance = { name: 'mock-ds' };
    setDataSourcePluginImporter(
      jest.fn().mockResolvedValue({ DataSourceClass: jest.fn().mockReturnValue(instance), components: {} })
    );

    const { result } = renderHook(() => useDataSourceInstance('uid-alpha'));
    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.dataSource).toBeTruthy();
    expect(result.current.error).toBeUndefined();
  });

  it('reports errors when lookup fails', async () => {
    const { result } = renderHook(() => useDataSourceInstance('missing'));
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.error).toBeInstanceOf(Error);
  });
});

describe('useDefaultDataSourceInstanceListItem', () => {
  it('starts loading then resolves to the default instance of the type', async () => {
    const { result } = renderHook(() => useDefaultDataSourceInstanceListItem('test-db'));

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.item?.name).toBe('Bravo');
    expect(result.current.error).toBeUndefined();
  });

  it('resolves to undefined for an unknown type', async () => {
    const { result } = renderHook(() => useDefaultDataSourceInstanceListItem('nonexistent'));

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.item).toBeUndefined();
  });
});

describe('useHasDataSourceInstance', () => {
  it('starts loading then resolves to true for an existing type', async () => {
    const { result } = renderHook(() => useHasDataSourceInstance('test-db'));

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.hasInstance).toBe(true);
    expect(result.current.error).toBeUndefined();
  });

  it('resolves to false for an unknown type', async () => {
    const { result } = renderHook(() => useHasDataSourceInstance('nonexistent'));

    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.hasInstance).toBe(false);
  });
});
