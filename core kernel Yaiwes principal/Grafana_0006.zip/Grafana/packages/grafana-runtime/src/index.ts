/**
 * A library containing services, configurations etc. used to interact with the Grafana engine.
 *
 * @packageDocumentation
 */
export * from './services';
export * from './config';
export * from './analytics/types';
export { loadPluginCss, type PluginCssOptions, setPluginImportUtils, getPluginImportUtils } from './utils/plugin';
export {
  MAX_PAGE_URL_LENGTH,
  TRUNCATION_MARKER,
  reportMetaAnalytics,
  reportInteraction,
  reportPageview,
  reportExperimentView,
  onInteraction,
} from './analytics/utils';
export { featureEnabled } from './utils/licensing';
export {
  logInfo,
  logDebug,
  logWarning,
  logError,
  createMonitoringLogger,
  logMeasurement,
  type MonitoringLogger,
} from './utils/logging';
export { TracedError } from './utils/TracedError';
export {
  DataSourceWithBackend,
  HealthCheckError,
  type HealthCheckResult,
  type HealthCheckResultDetails,
  HealthStatus,
  type StreamOptionsProvider,
} from './utils/DataSourceWithBackend';
export { isExpressionReference } from './utils/expressionRef';
export {
  toDataQueryResponse,
  frameToMetricFindValue,
  type BackendDataSourceResponse,
  type DataResponse,
  type TestingStatus,
} from './utils/queryResponse';
export { PanelRenderer, type PanelRendererProps } from './components/PanelRenderer';
export { PanelDataErrorView, type PanelDataErrorViewProps } from './components/PanelDataErrorView';
export { toDataQueryError } from './utils/toDataQueryError';
export {
  setQueryRunnerFactory,
  createQueryRunner,
  type QueryRunnerFactory,
  setRunRequest,
  getRunRequest,
} from './services/QueryRunner';
export { PluginPage } from './components/PluginPage';
export type { PluginPageType, PluginPageProps, PluginPageBackground } from './components/PluginPage';
export { DataSourcePicker, type DataSourcePickerProps } from './components/DataSourcePicker';
export {
  type PluginEventProperties,
  createPluginEventProperties,
  type DataSourcePluginEventProperties,
  createDataSourcePluginEventProperties,
} from './analytics/plugins/eventProperties';
export { usePluginInteractionReporter } from './analytics/plugins/usePluginInteractionReporter';
export { setReturnToPreviousHook, useReturnToPrevious } from './utils/returnToPrevious';
export { setMegaMenuOpenHook, useMegaMenuOpen } from './utils/megaMenuOpen';
export { setChromeHeaderHeightHook, useChromeHeaderHeight } from './utils/chromeHeaderHeight';
export { type EmbeddedDashboardProps, EmbeddedDashboard, setEmbeddedDashboard } from './components/EmbeddedDashboard';
export { hasPermission, hasPermissionInMetadata, hasAllPermissions, hasAnyPermission } from './utils/rbac';
export { QueryEditorWithMigration } from './components/QueryEditorWithMigration';
export { type MigrationHandler, isMigrationHandler, migrateQuery, migrateRequest } from './utils/migrationHandler';
export { usePluginUserStorage } from './utils/userStorage';
export { useFavoriteDatasources, type FavoriteDatasources } from './utils/useFavoriteDatasources';
export { FolderPicker, setFolderPicker } from './components/FolderPicker';
export {
  type CorrelationsService,
  type CorrelationData,
  type CorrelationsData,
  type CorrelationExternal,
  type CorrelationQuery,
  getCorrelationsService,
  setCorrelationsService,
} from './services/CorrelationsService';
export {
  type PanelScreenshotService,
  type PanelScreenshotOptions,
  getPanelScreenshotService,
  setPanelScreenshotService,
} from './services/PanelScreenshotService';
export { getAppPluginVersion, isAppPluginInstalled } from './services/pluginMeta/apps';
export {
  useAppPluginInstalled,
  useAppPluginVersion,
  useListedPanelPluginIds,
  usePanelPluginInstalled,
  usePanelPluginVersion,
} from './services/pluginMeta/hooks';
export { getListedPanelPluginIds, getPanelPluginVersion, isPanelPluginInstalled } from './services/pluginMeta/panels';
export { isAppPluginEnabled } from './services/pluginSettings/settings';
export { useAppPluginEnabled } from './services/pluginSettings/hooks';
export { createOpenFeatureOFREPWebProvider, createOpenFeatureLocalStorageProvider } from './utils/openfeature';
