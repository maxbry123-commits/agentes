from __future__ import annotations

MCP_PORT = 18787
"""Non-default port to avoid conflicts with a running dev MCP server."""

DJANGO_LIVE_PORT = 18000
"""Non-default port for the in-process Django server."""

LLM_GATEWAY_PORT = 13308
"""Non-default port to avoid conflicts with a running dev LLM gateway."""

PERSONHOG_REPLICA_PORT = 15051
"""Non-default port so a dev-stack personhog-replica on 50051 never collides."""

PERSONHOG_ROUTER_PORT = 15052
"""Non-default port; the harness points PERSONHOG_ADDR at this router."""
