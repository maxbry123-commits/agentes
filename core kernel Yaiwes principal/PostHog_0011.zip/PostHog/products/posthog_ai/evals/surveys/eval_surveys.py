"""Survey creation eval cases for the sandboxed coding agent.

Intent mirrors ``ee/hogai/eval/ci/eval_surveys.py``. The CI version calls
Max's ``CreateSurveyTool`` directly and checks Django state. This version
asks the sandboxed agent to create surveys through the PostHog MCP
``survey-create`` tool and scores the payload/result it produced.

To run:
    flox activate -- bash -c "set -a; source .env; set +a; python -m products.posthog_ai.eval_harness.harness eval_surveys"
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from products.posthog_ai.eval_harness.base import SandboxedPublicEval
from products.posthog_ai.eval_harness.config import SandboxedEvalCase
from products.posthog_ai.eval_harness.harness.context import EvalContext
from products.posthog_ai.eval_harness.scorers import NoToolCall
from products.posthog_ai.eval_harness.seeders.survey import seed_survey_feature_flags
from products.posthog_ai.evals.product_analytics.scorers import INSIGHT_WRITE_TOOLS
from products.posthog_ai.evals.surveys.scorers import (
    SURVEY_FORBIDDEN_WRITE_TOOLS,
    SurveyCreateOutcome,
    SurveyCreateReturnedId,
    SurveyCreateSchemaAlignment,
    SurveyIdInFinalMessage,
)
from products.tasks.backend.facade.agents import CustomPromptSandboxContext


def _survey_case(
    *,
    name: str,
    prompt: str,
    expected_survey: dict[str, Any],
    setup: Callable[[CustomPromptSandboxContext], dict[str, Any]] | None = None,
) -> SandboxedEvalCase:
    return SandboxedEvalCase(
        name=name,
        prompt=prompt,
        expected={
            "survey_created": {"should_create": True},
            "survey_create_alignment": expected_survey,
            "survey_id_in_final_message": {"required": True},
        },
        setup=setup,
    )


async def eval_surveys(ctx: EvalContext) -> None:
    cases: list[SandboxedEvalCase] = [
        _survey_case(
            name="survey_nps_draft",
            prompt=(
                "Create a draft popover survey named '[sandboxed] NPS Survey' with description "
                "'Net Promoter Score survey'. Add one NPS rating question: "
                "'How likely are you to recommend us to a friend or colleague?' with lower label "
                "'Not likely at all' and upper label 'Extremely likely'. Do not launch it."
            ),
            expected_survey={
                "name": "[sandboxed] NPS Survey",
                "description": "Net Promoter Score survey",
                "type": "popover",
                "should_launch": False,
                "questions": [
                    {
                        "type": "rating",
                        "question": "How likely are you to recommend us to a friend or colleague?",
                        "scale": 10,
                        "display": "number",
                        "lowerBoundLabel": "Not likely at all",
                        "upperBoundLabel": "Extremely likely",
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_csat_launched",
            prompt=(
                "Create and launch a popover survey named '[sandboxed] CSAT Survey' with description "
                "'Customer satisfaction survey'. It should ask one CSAT rating question: "
                "'How satisfied are you with our product?'"
            ),
            expected_survey={
                "name": "[sandboxed] CSAT Survey",
                "description": "Customer satisfaction survey",
                "type": "popover",
                "should_launch": True,
                "questions": [
                    {
                        "type": "rating",
                        "question": "How satisfied are you with our product?",
                        "scale": 5,
                        "display": "number",
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_nps_with_followup",
            prompt=(
                "Create a draft popover survey named '[sandboxed] NPS with Follow-up' with description "
                "'NPS survey with optional follow-up question'. Add two questions in this order: an NPS rating "
                "question 'How likely are you to recommend us?' and an optional open-text follow-up "
                "'What could we improve?'."
            ),
            expected_survey={
                "name": "[sandboxed] NPS with Follow-up",
                "description": "NPS survey with optional follow-up question",
                "type": "popover",
                "should_launch": False,
                "questions": [
                    {
                        "type": "rating",
                        "question": "How likely are you to recommend us?",
                        "scale": 10,
                        "display": "number",
                    },
                    {
                        "type": "open",
                        "question": "What could we improve?",
                        "optional": True,
                    },
                ],
            },
        ),
        _survey_case(
            name="survey_pmf_single_choice",
            prompt=(
                "Create a draft popover PMF survey named '[sandboxed] PMF Survey' with description "
                "'Product-market fit survey'. Ask one single-choice question: "
                "'How would you feel if you could no longer use our product?' with choices "
                "'Very disappointed', 'Somewhat disappointed', and 'Not disappointed'."
            ),
            expected_survey={
                "name": "[sandboxed] PMF Survey",
                "description": "Product-market fit survey",
                "type": "popover",
                "should_launch": False,
                "questions": [
                    {
                        "type": "single_choice",
                        "question": "How would you feel if you could no longer use our product?",
                        "choices": ["Very disappointed", "Somewhat disappointed", "Not disappointed"],
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_checkout_feature_flag",
            prompt=(
                "Create a draft popover survey named '[sandboxed] Checkout Feedback' with description "
                "'Feedback for new checkout flow users'. Ask one open-text question: "
                "'How was your checkout experience?' Link it to the existing feature flag with key "
                "'new-checkout-flow'."
            ),
            expected_survey={
                "name": "[sandboxed] Checkout Feedback",
                "description": "Feedback for new checkout flow users",
                "type": "popover",
                "should_launch": False,
                "linked_flag_key": "new-checkout-flow",
                "questions": [
                    {
                        "type": "open",
                        "question": "How was your checkout experience?",
                    }
                ],
            },
            setup=seed_survey_feature_flags,
        ),
        _survey_case(
            name="survey_ab_test_treatment_variant",
            prompt=(
                "Create a draft popover survey named '[sandboxed] A/B Test Treatment Survey' with description "
                "'Survey for users in treatment variant'. Ask one CSAT rating question: "
                "'How do you like the new design?' Link it to the existing feature flag with key "
                "'ab-test-experiment' and target only users in the 'treatment' variant."
            ),
            expected_survey={
                "name": "[sandboxed] A/B Test Treatment Survey",
                "description": "Survey for users in treatment variant",
                "type": "popover",
                "should_launch": False,
                "linked_flag_key": "ab-test-experiment",
                "conditions": {"linkedFlagVariant": "treatment"},
                "questions": [
                    {
                        "type": "rating",
                        "question": "How do you like the new design?",
                        "scale": 5,
                        "display": "number",
                    }
                ],
            },
            setup=seed_survey_feature_flags,
        ),
        _survey_case(
            name="survey_pricing_page_url_targeting",
            prompt=(
                "Create a draft popover survey named '[sandboxed] Pricing Page Feedback' with description "
                "'Feedback from pricing page visitors'. Ask one single-choice question: "
                "'Is our pricing clear?' with choices 'Yes, very clear', 'Somewhat clear', and "
                "'Not clear at all'. Target URLs containing '/pricing'."
            ),
            expected_survey={
                "name": "[sandboxed] Pricing Page Feedback",
                "description": "Feedback from pricing page visitors",
                "type": "popover",
                "should_launch": False,
                "conditions": {"url": "/pricing", "urlMatchType": "icontains"},
                "questions": [
                    {
                        "type": "single_choice",
                        "question": "Is our pricing clear?",
                        "choices": ["Yes, very clear", "Somewhat clear", "Not clear at all"],
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_feature_usage_multiple_choice",
            prompt=(
                "Create a draft popover survey named '[sandboxed] Feature Usage Survey' with description "
                "'Survey about feature usage'. Ask one multiple-choice question: 'Which features do you use most?' "
                "with choices 'Dashboard', 'Insights', 'Session Replay', 'Feature Flags', and 'Experiments'."
            ),
            expected_survey={
                "name": "[sandboxed] Feature Usage Survey",
                "description": "Survey about feature usage",
                "type": "popover",
                "should_launch": False,
                "questions": [
                    {
                        "type": "multiple_choice",
                        "question": "Which features do you use most?",
                        "choices": ["Dashboard", "Insights", "Session Replay", "Feature Flags", "Experiments"],
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_widget_feedback",
            prompt=(
                "Create a draft widget survey named '[sandboxed] Widget Feedback' with description "
                "'Widget-based feedback survey'. Ask one open-text question: "
                "'What do you think of our product?'"
            ),
            expected_survey={
                "name": "[sandboxed] Widget Feedback",
                "description": "Widget-based feedback survey",
                "type": "widget",
                "should_launch": False,
                "questions": [
                    {
                        "type": "open",
                        "question": "What do you think of our product?",
                    }
                ],
            },
        ),
        _survey_case(
            name="survey_empty_questions_allowed",
            prompt=(
                "Create a draft popover survey named '[sandboxed] Empty Questions Survey' with description "
                "'Survey with no questions'. Use an empty questions list and do not add a placeholder question."
            ),
            expected_survey={
                "name": "[sandboxed] Empty Questions Survey",
                "description": "Survey with no questions",
                "type": "popover",
                "should_launch": False,
                "questions": [],
            },
        ),
    ]

    await SandboxedPublicEval(
        experiment_name="sandboxed-surveys-cli",
        cases=cases,
        scorers=[
            NoToolCall(
                forbidden=SURVEY_FORBIDDEN_WRITE_TOOLS | INSIGHT_WRITE_TOOLS,
                name="no_forbidden_survey_side_effects",
            ),
            SurveyCreateOutcome(),
            SurveyCreateReturnedId(),
            SurveyCreateSchemaAlignment(),
            SurveyIdInFinalMessage(),
        ],
        ctx=ctx,
    )
