import { CronExpressionParser } from 'cron-parser'
import {
    MakeLogicType,
    actions,
    afterMount,
    connect,
    kea,
    key,
    listeners,
    path,
    props,
    reducers,
    selectors,
    sharedListeners,
} from 'kea'
import type { BreakPointFunction } from 'kea'
import { DeepPartialMap, ValidationErrorType, forms } from 'kea-forms'
import type { DeepPartial, FieldName } from 'kea-forms'
import { loaders } from 'kea-loaders'
import { beforeUnload, router, urlToAction } from 'kea-router'
import { CombinedLocation } from 'kea-router/lib/utils'
import { createElement } from 'react'

import api, { PaginatedResponse } from 'lib/api'
import { isAccessDeniedError } from 'lib/api-error'
import { handleApprovalRequired } from 'lib/approvals/utils'
import { ACTIVITY_SEARCH_PARAM } from 'lib/components/ActivityLog/activityLogLogic'
import { tryShowMCPHint } from 'lib/components/MCPHint/mcpHintLogic'
import { SetupTaskId, globalSetupLogic } from 'lib/components/ProductSetup'
import { FEATURE_FLAGS } from 'lib/constants'
import { describeCron } from 'lib/cron'
import { Dayjs, dayjs } from 'lib/dayjs'
import { scrollToFormError } from 'lib/forms/scrollToFormError'
import { LemonDialog } from 'lib/lemon-ui/LemonDialog'
import { lemonToast } from 'lib/lemon-ui/LemonToast/LemonToast'
import { featureFlagLogic as enabledFeaturesLogic } from 'lib/logic/featureFlagLogic'
import { trackedActionToUrl } from 'lib/logic/scenes/trackedActionToUrl'
import { deleteWithUndo } from 'lib/utils/deleteWithUndo'
import { eventUsageLogic } from 'lib/utils/eventUsageLogic'
import { stringifyWithBigInts } from 'lib/utils/json'
import { removeProjectIdIfPresent } from 'lib/utils/kea-router'
import { objectsEqual } from 'lib/utils/objects'
import { slugify } from 'lib/utils/strings'
import { experimentLogic } from 'scenes/experiments/experimentLogic'
import { FeatureFlagsTab, featureFlagsLogic, isFeatureFlagsTab } from 'scenes/feature-flags/featureFlagsLogic'
import { projectLogic } from 'scenes/projectLogic'
import { Scene } from 'scenes/sceneTypes'
import { NEW_SURVEY, NewSurvey, SURVEY_CREATED_SOURCE } from 'scenes/surveys/constants'
import { urls } from 'scenes/urls'
import { userLogic } from 'scenes/userLogic'

import { sidePanelStateLogic } from '~/layout/navigation-3000/sidepanel/sidePanelStateLogic'
import { SIDE_PANEL_CONTEXT_KEY, SidePanelSceneContext } from '~/layout/navigation-3000/sidepanel/types'
import { deleteFromTree, refreshTreeItem } from '~/layout/panel-layout/ProjectTree/projectTreeLogic'
import { groupsModel } from '~/models/groupsModel'
import { getQueryBasedInsightModel } from '~/queries/nodes/InsightViz/utils'
import { ProductIntentContext, ProductKey } from '~/queries/schema/schema-general'
import {
    AccessControlLevel,
    ActivityScope,
    AvailableFeature,
    Breadcrumb,
    CohortType,
    EarlyAccessFeatureType,
    FeatureFlagBucketingIdentifier,
    FeatureFlagEvaluationRuntime,
    FeatureFlagGroupType,
    FeatureFlagStatusResponse,
    FeatureFlagType,
    FilterLogicalOperator,
    InsightModel,
    JsonType,
    MultivariateFlagOptions,
    MultivariateFlagVariant,
    NewEarlyAccessFeatureType,
    OrganizationFeatureFlag,
    ProjectTreeRef,
    PropertyFilterType,
    PropertyOperator,
    QueryBasedInsightModel,
    RecordingUniversalFilters,
    RecurrenceInterval,
    ScheduledChangeOperationType,
    ScheduledChangeRequestState,
    ScheduledChangeType,
    Survey,
    SurveyQuestionType,
} from '~/types'

import { NEW_EARLY_ACCESS_FEATURE } from 'products/early_access_features/frontend/earlyAccessFeatureLogic'
import { TEMPLATE_NAMES } from 'products/feature_flags/frontend/featureFlagTemplateConstants'
import {
    featureFlagsCopyFlagsCreate,
    featureFlagsCopyFlagsDependencyRequirementsCreate,
    featureFlagsList,
} from 'products/feature_flags/frontend/generated/api'
import type { CopyFlagsDependencyRequirementsResponseApi } from 'products/feature_flags/frontend/generated/api.schemas'

import type { CopyFlagsResponseApi } from '../../../../products/feature_flags/frontend/generated/api.schemas'
import type { FeatureFlagsSet } from '../../lib/logic/featureFlagLogic'
import type { ProductIntentProperties } from '../../lib/utils/product-intents'
import type { Noun } from '../../models/groupsModel'
import type { Node } from '../../queries/schema/schema-general'
import type {
    AnyPropertyFilter,
    Experiment,
    FeatureFlagFilters,
    MinimalEarlyAccessFeatureType,
    OrganizationType,
    SidePanelTab,
    TeamPublicType,
    TeamType,
    UserBasicType,
    UserType,
} from '../../types'
import { organizationLogic } from '../organizationLogic'
import { teamLogic } from '../teamLogic'
import { defaultEvaluationContextsLogic } from './defaultEvaluationContextsLogic'
import type { DefaultEvaluationContextsResponse } from './defaultEvaluationContextsLogic'
import { defaultReleaseConditionsLogic, resolveDefaultReleaseConditions } from './defaultReleaseConditionsLogic'
import type { DefaultReleaseConditionsResponse } from './defaultReleaseConditionsLogic'
import { uniformAggregationGroupTypeIndex } from './defaultReleaseConditionsUtils'
import { FeatureFlagArchivedSource, reportFeatureFlagArchived } from './featureFlagArchiveDialog'
import { checkFeatureFlagConfirmation } from './featureFlagConfirmationLogic'
import type { FlagIntent } from './featureFlagIntentWarningLogic'
import {
    ScheduleOccurrence,
    expandScheduleOccurrences,
    hasDeniedApprovalRequest,
    isSchedulePaused,
} from './scheduleOccurrences'
import { flagToggleKey, updateFlagActiveInProject } from './updateFlagActiveInProject'

const VALID_INTENTS: FlagIntent[] = ['local-eval', 'first-page-load']

const TAB_SEARCH_PARAM = 'tab'

export function hasDirectFlagDependency(featureFlag: FeatureFlagType): boolean {
    const groups = featureFlag.filters?.groups
    if (!Array.isArray(groups)) {
        return false
    }

    return groups.some((group) => {
        if (!group || typeof group !== 'object') {
            return false
        }
        const properties = group.properties
        return (
            Array.isArray(properties) &&
            properties.some(
                (property) => !!property && typeof property === 'object' && property.type === PropertyFilterType.Flag
            )
        )
    })
}

export function dependencyActionLabel(
    loading: boolean,
    req: CopyFlagsDependencyRequirementsResponseApi | null
): string {
    if (loading || !req) {
        return 'Copy dependencies: Checking'
    }

    if (req.can_copy_dependencies) {
        return `Copy dependencies: ${req.copied_dependency_keys.length} missing`
    }

    if (req.warnings.length > 0) {
        return 'Copy dependencies: Unavailable'
    }

    return 'Copy dependencies: Already satisfied'
}

export function dependencyDisabledReason(
    loading: boolean,
    req: CopyFlagsDependencyRequirementsResponseApi | null
): string | undefined {
    if (loading || !req) {
        return 'Checking dependency availability'
    }

    return req.can_copy_dependencies ? undefined : req.reason
}

export function hasStaticCohortDependency(featureFlag: FeatureFlagType, cohorts: CohortType[]): boolean {
    const staticCohortIds = new Set(cohorts.filter((cohort) => cohort.is_static).map((cohort) => cohort.id))
    const groups = featureFlag.filters?.groups
    if (!Array.isArray(groups)) {
        return false
    }

    return groups.some((group) => {
        if (!group || typeof group !== 'object' || !Array.isArray(group.properties)) {
            return false
        }

        return group.properties.some((property) => {
            return (
                !!property &&
                typeof property === 'object' &&
                property.type === PropertyFilterType.Cohort &&
                staticCohortIds.has(property.value)
            )
        })
    })
}

const COPY_DEPENDENCY_REQUIREMENTS_UNAVAILABLE: CopyFlagsDependencyRequirementsResponseApi = {
    can_copy_dependencies: false,
    dependency_count: 0,
    copied_dependency_keys: [],
    reused_dependency_keys: [],
    warnings: ['Unable to check dependency availability. Try again or copy this flag without dependencies.'],
    reason: 'Unable to check dependency availability. Try again or copy this flag without dependencies.',
}

function parseUrlIntent(): FlagIntent | undefined {
    const raw = router.values.searchParams.intent
    return VALID_INTENTS.includes(raw) ? (raw as FlagIntent) : undefined
}

/** Apply the intent from the URL param (idempotent — no-ops if already applied). */
function maybeApplyUrlIntent(
    values: { urlIntentApplied: boolean; featureFlag: FeatureFlagType },
    actions: {
        setFlagIntent: (intent: FlagIntent) => void
        applyUrlIntent: () => void
        setFeatureFlag: (flag: FeatureFlagType) => void
    }
): void {
    if (values.urlIntentApplied) {
        return
    }
    const intent = parseUrlIntent()
    if (!intent) {
        return
    }
    actions.setFlagIntent(intent)
    actions.applyUrlIntent()
    if (intent === 'local-eval') {
        actions.setFeatureFlag({
            ...values.featureFlag,
            evaluation_runtime: FeatureFlagEvaluationRuntime.SERVER,
            ensure_experience_continuity: false,
        })
    }
    // 'first-page-load' applies no presets — it only surfaces warnings via featureFlagIntentWarningLogic
}

type FlagType = 'boolean' | 'multivariate' | 'remote_config'

// Paired schedule presets create two complementary enable/disable schedules in one action.
// The backend has no concept of "paired" — this is a frontend convenience.
export type PairedPresetKey = 'business_hours' | 'weekdays_only' | 'custom_pair'

interface PairedPresetDefinition {
    label: string
    description: string
    enableCron: string
    disableCron: string
}

/**
 * Schedule pickers operate on the browser's wall clock, but users expect the time they enter
 * to be interpreted in the project's timezone (shown via `ScheduleTimezoneHint`).
 *
 * These helpers convert between the browser-local Dayjs used by the calendar and the
 * project-timezone UTC ISO string stored on the backend, keeping the displayed wall clock
 * identical in both directions.
 */
export function scheduleDateToProjectTzISO(localDayjs: Dayjs, timezone: string): string {
    // Reinterpret the wall clock as being in the project timezone, then emit as UTC.
    return localDayjs.tz(timezone, true).toISOString()
}

export function scheduleDateFromStoredISO(isoString: string, timezone: string): Dayjs {
    // Convert the stored UTC moment to the project timezone, then present that wall clock
    // as a browser-local Dayjs so the calendar renders the same values the user picked.
    // Sub-second precision is preserved so end-of-day sentinels (.999 ms) round-trip unchanged.
    return dayjs(dayjs.utc(isoString).tz(timezone).format('YYYY-MM-DDTHH:mm:ss.SSS'))
}

// Order scheduled changes by their `scheduled_at` time, soonest first. `scheduled_at` holds the
// next occurrence for recurring changes too, so it is a uniform sort key across all change types.
// Unparseable/missing dates sort last; ties break by `id` (creation order) for a stable order.
export function byScheduledAt(a: ScheduledChangeType, b: ScheduledChangeType): number {
    const epoch = (sc: ScheduledChangeType): number => {
        if (!sc.scheduled_at) {
            return Number.POSITIVE_INFINITY
        }
        const ms = dayjs(sc.scheduled_at).valueOf()
        return Number.isNaN(ms) ? Number.POSITIVE_INFINITY : ms
    }
    return epoch(a) - epoch(b) || a.id - b.id
}

// Order executed changes by `executed_at`, most recently executed first, so the history reads as a
// real execution timeline even when execution is delayed. Unparseable/missing dates sort last; ties
// break by `id` (creation order) for a stable order.
export function byExecutedAt(a: ScheduledChangeType, b: ScheduledChangeType): number {
    const epoch = (sc: ScheduledChangeType): number => {
        if (!sc.executed_at) {
            return Number.NEGATIVE_INFINITY
        }
        const ms = dayjs(sc.executed_at).valueOf()
        return Number.isNaN(ms) ? Number.NEGATIVE_INFINITY : ms
    }
    return epoch(b) - epoch(a) || b.id - a.id
}

// A one-time schedule whose approval request was rejected or expired will never apply: the
// applier skips it at fire time. It reads as terminal in the UI and sorts with history.
// Recurring schedules are excluded because each occurrence is re-gated with a fresh request.
export function isScheduleDeniedApproval(sc: ScheduledChangeType): boolean {
    return !sc.is_recurring && !sc.recurrence_interval && !sc.cron_expression && hasDeniedApprovalRequest(sc)
}

export const PAIRED_PRESETS: Record<Exclude<PairedPresetKey, 'custom_pair'>, PairedPresetDefinition> = {
    business_hours: {
        label: 'Business hours',
        description: 'Enable at 9:00 AM and disable at 5:00 PM, Monday through Friday',
        enableCron: '0 9 * * 1-5',
        disableCron: '0 17 * * 1-5',
    },
    weekdays_only: {
        label: 'Weekdays only',
        description: 'Enable at midnight Monday and disable at end of day Friday',
        enableCron: '0 0 * * 1',
        disableCron: '59 23 * * 5',
    },
}

/** Resolution state of the schedule creation form: unknown while schedules first load,
 * then collapsed behind a button when the flag already has a plan to read. */
export type ScheduleFormState = 'loading' | 'collapsed' | 'expanded'

export type ScheduleFlagPayload = Pick<FeatureFlagType, 'filters' | 'active'> & {
    variants?: MultivariateFlagVariant[]
    payloads?: Record<string, any>
}

export type VariantError = {
    key: string | undefined
}

export interface DependentFlag {
    id: number
    key: string
    name: string
}

export const NEW_FLAG: FeatureFlagType = {
    id: null,
    created_at: null,
    updated_at: null,
    key: '',
    name: '',
    filters: {
        groups: [{ properties: [], rollout_percentage: 0, variant: null }],
        multivariate: null,
        payloads: {},
    },
    deleted: false,
    active: true,
    archived: false,
    created_by: null,
    ensure_experience_continuity: false,
    experiment_set: null,
    experiment_set_metadata: null,
    features: [],
    surveys: null,
    can_edit: true,
    user_access_level: AccessControlLevel.Editor,
    tags: [],
    evaluation_contexts: [],
    is_remote_configuration: false,
    has_encrypted_payloads: false,
    status: 'ACTIVE',
    version: 0,
    last_modified_by: null,
    evaluation_runtime: FeatureFlagEvaluationRuntime.ALL,
    bucketing_identifier: null,
}
const NEW_VARIANT = {
    key: '',
    name: '',
    rollout_percentage: 0,
}
const EMPTY_MULTIVARIATE_OPTIONS: MultivariateFlagOptions = {
    variants: [
        {
            key: 'control',
            name: '',
            rollout_percentage: 50,
        },
        {
            key: 'test',
            name: '',
            rollout_percentage: 50,
        },
    ],
}

const FLAG_DEPENDENCY_TIMEOUT_MS = 2000

// Only returns true when groups are present and ALL explicitly set to 0.
// In feature flags, null/undefined rollout_percentage means "serve to all" (100%), not 0%.
export function hasZeroRollout(filters: FeatureFlagType['filters'] | undefined | null): boolean {
    const groups = filters?.groups
    if (!groups || groups.length === 0) {
        return false
    }
    return groups.every((g) => g.rollout_percentage === 0)
}

// In feature flags, null/undefined rollout_percentage means "serve to all" (100%), so treat as active.
export function hasMultipleVariantsActive(filters: FeatureFlagType['filters'] | undefined | null): boolean {
    const variants = filters?.multivariate?.variants
    if (!variants) {
        return false
    }
    return variants.filter(({ rollout_percentage }) => rollout_percentage !== 0).length > 1
}

// Normalize a value into a valid feature flag key: spaces to dashes, strip invalid chars.
// fromTitleInput: when auto-filling from a name field, downcase and trim both ends.
// Direct key input preserves case and only trims the start (so users can can continue typing with spaces).
// Note that lowercase should not be enforced as users do use camelCase or UPPERCASE
export function slugifyFeatureFlagKey(
    value: string,
    { fromTitleInput = false }: { fromTitleInput?: boolean } = {}
): string {
    return slugify(value, { lowercase: fromTitleInput, trimBothEnds: fromTitleInput })
}

/** Check whether a string is a valid feature flag key. If not, a reason string is returned - otherwise undefined. */
export function validateFeatureFlagKey(key: string): string | undefined {
    return !key
        ? 'Please set a key'
        : key.length > 400
          ? 'Key must be 400 characters or less.'
          : !key.match?.(/^[a-zA-Z0-9_-]+$/)
            ? 'Only letters, numbers, hyphens (-) & underscores (_) are allowed.'
            : undefined
}

/** Check whether a string is a valid variant key. If not, a reason string is returned - otherwise undefined.
 * Wider than flag keys: dots and slashes are allowed because variant keys often carry values SDKs consume
 * directly (e.g. model IDs like "provider/model-1.2"), and the API has always accepted them. */
export function validateFeatureFlagVariantKey(key: string): string | undefined {
    return !key
        ? 'Please set a key'
        : key.length > 400
          ? 'Key must be 400 characters or less.'
          : !key.match?.(/^[a-zA-Z0-9_\-./]+$/)
            ? 'Only letters, numbers, hyphens (-), underscores (_), dots (.) & slashes (/) are allowed.'
            : undefined
}

function getVariantRolloutSum(variants: MultivariateFlagVariant[] = []): number {
    return variants.reduce((sum, { rollout_percentage }) => sum + (rollout_percentage || 0), 0)
}

// Absorbs float drift (0.01/64.04/35.95 adds up to 100.00000000000001) while staying below the
// 0.01 this form can express. Mirrored by products/feature_flags/backend/variant_rollout.py.
const ROLLOUT_SUM_TOLERANCE = 1e-9

/** Reason string when variant rollouts do not add up, otherwise undefined.
 * Boolean flags carry no variants and are exempt. */
export function validateVariantRolloutSum(variants?: MultivariateFlagVariant[]): string | undefined {
    if (!variants?.length) {
        return undefined
    }
    const rolloutSum = getVariantRolloutSum(variants)
    if (Math.abs(rolloutSum - 100) <= ROLLOUT_SUM_TOLERANCE) {
        return undefined
    }
    // Hides float artifacts (99.05000000000001), but stays finer than the tolerance above so a
    // rejected total never reads as exactly 100.
    const displayedSum = parseFloat(rolloutSum.toFixed(10))
    return `Percentage rollouts for variants must sum to 100 (currently ${displayedSum}).`
}

function validatePayloadRequired(is_remote_configuration: boolean, payload?: JsonType): string | undefined {
    if (!is_remote_configuration) {
        return undefined
    }
    if (payload === undefined || payload === '') {
        return 'Payload is required for remote configuration flags.'
    }
    return undefined
}

export interface FeatureFlagLogicProps {
    id: number | 'new' | 'link'
}

function isOnFeatureFlagPage(id: FeatureFlagLogicProps['id']): boolean {
    return removeProjectIdIfPresent(router.values.location.pathname) === urls.featureFlag(id)
}

// KLUDGE: Payloads are returned in a <variant-key>: <payload> mapping.
// This doesn't work for forms because variant-keys can be updated too which would invalidate the dictionary entry.
// If a multivariant flag is returned, the payload dictionary will be transformed to be <variant-key-index>: <payload>
export const variantKeyToIndexFeatureFlagPayloads = (flag: FeatureFlagType): FeatureFlagType => {
    if (!flag.filters.multivariate) {
        return flag
    }

    const newPayloads: Record<number, JsonType> = {}
    flag.filters.multivariate?.variants.forEach((variant, index) => {
        if (flag.filters.payloads?.[variant.key] !== undefined) {
            newPayloads[index] = flag.filters.payloads[variant.key]
        }
    })
    return {
        ...flag,
        filters: {
            ...flag.filters,
            payloads: newPayloads,
        },
    }
}

// Reverse of `variantKeyToIndexFeatureFlagPayloads`: converts form-state payloads
// (keyed by variant index) back to API-shape payloads (keyed by variant key).
// Inputs MUST be index-keyed — passing variant-key-keyed payloads here will drop them.
// This matters when variant keys are numeric strings (e.g. "0", "1"), which would
// otherwise collide with index keys.
export const convertIndexBasedPayloadsToVariantKeys = (
    variants: MultivariateFlagVariant[] = [],
    payloads?: Record<number, JsonType>
): Record<string, JsonType> => {
    const newPayloads: Record<string, JsonType> = {}

    variants.forEach((variant, index) => {
        const payload = payloads?.[index]
        if (payload !== undefined && variant.key) {
            newPayloads[variant.key] = payload
        }
    })

    return newPayloads
}

export const indexToVariantKeyFeatureFlagPayloads = (flag: Partial<FeatureFlagType>): Partial<FeatureFlagType> => {
    if (flag.filters?.multivariate) {
        const newPayloads = convertIndexBasedPayloadsToVariantKeys(
            flag.filters.multivariate.variants,
            flag.filters.payloads || {}
        )
        return {
            ...flag,
            filters: {
                ...flag.filters,
                payloads: newPayloads,
            },
        }
    }
    if (flag.filters && !flag.filters.multivariate) {
        let cleanedPayloadValue = {}
        if (flag.filters.payloads?.['true']) {
            cleanedPayloadValue = { true: flag.filters.payloads['true'] }
        }
        return {
            ...flag,
            filters: {
                ...flag.filters,
                payloads: cleanedPayloadValue,
            },
        }
    }
    return flag
}

// Helper function to reorder variant state and synchronize payloads
const reorderVariantState = (
    state: FeatureFlagType,
    variants: MultivariateFlagVariant[],
    fromIndex: number,
    toIndex: number
): FeatureFlagType => {
    // Create new variants array with reordered elements
    const newVariants = [...variants]
    const [movedVariant] = newVariants.splice(fromIndex, 1)
    newVariants.splice(toIndex, 0, movedVariant)

    // Synchronize payloads with the new variant order
    const currentPayloads = { ...state.filters.payloads }
    const newPayloads: Record<string | number, any> = {}

    // Create index mapping from old to new positions
    const indexMapping = new Map<number, number>()
    variants.forEach((_, oldIndex) => {
        let newIndex = oldIndex
        if (oldIndex === fromIndex) {
            newIndex = toIndex
        } else if (fromIndex < toIndex && oldIndex > fromIndex && oldIndex <= toIndex) {
            newIndex = oldIndex - 1
        } else if (fromIndex > toIndex && oldIndex >= toIndex && oldIndex < fromIndex) {
            newIndex = oldIndex + 1
        }
        indexMapping.set(oldIndex, newIndex)
    })

    // Rebuild payloads using the index mapping
    Object.keys(currentPayloads).forEach((key) => {
        const oldIndex = parseInt(key)
        if (Number.isFinite(oldIndex) && indexMapping.has(oldIndex)) {
            const newIndex = indexMapping.get(oldIndex)!
            newPayloads[newIndex] = currentPayloads[oldIndex]
        } else {
            // Preserve non-numeric keys (like 'true' for boolean flags)
            newPayloads[key] = currentPayloads[key]
        }
    })

    return {
        ...state,
        filters: {
            ...state.filters,
            multivariate: {
                ...state.filters.multivariate,
                variants: newVariants,
            },
            payloads: newPayloads,
        },
    }
}

// Helper function to remap openVariants after reordering to handle keyless variants
const remapOpenVariantsAfterReorder = (openVariants: string[], fromIndex: number, toIndex: number): string[] => {
    return openVariants.map((key) => {
        // Check if this is a keyless variant ID (variant-0, variant-1, etc.)
        const match = key.match(/^variant-(\d+)$/)
        if (!match) {
            // Not a keyless variant, return as-is
            return key
        }

        const variantIndex = parseInt(match[1], 10)
        let newIndex = variantIndex

        // Apply the same reordering logic as reorderVariantState
        if (variantIndex === fromIndex) {
            newIndex = toIndex
        } else if (fromIndex < toIndex && variantIndex > fromIndex && variantIndex <= toIndex) {
            newIndex = variantIndex - 1
        } else if (fromIndex > toIndex && variantIndex >= toIndex && variantIndex < fromIndex) {
            newIndex = variantIndex + 1
        }

        return `variant-${newIndex}`
    })
}

export const getRecordingFilterForFlagVariant = (
    flagKey: string,
    variantKey: string | null,
    hasEnrichedAnalytics?: boolean
): Partial<RecordingUniversalFilters> => {
    return {
        filter_group: {
            type: FilterLogicalOperator.And,
            values: [
                {
                    type: FilterLogicalOperator.And,
                    values: [
                        hasEnrichedAnalytics
                            ? {
                                  id: '$feature_interaction',
                                  type: 'events',
                                  order: 0,
                                  name: '$feature_interaction',
                                  properties: [
                                      {
                                          key: 'feature_flag',
                                          value: [flagKey],
                                          operator: PropertyOperator.Exact,
                                          type: PropertyFilterType.Event,
                                      },
                                  ],
                              }
                            : {
                                  type: PropertyFilterType.Event,
                                  key: `$feature/${flagKey}`,
                                  operator: PropertyOperator.Exact,
                                  value: [variantKey ? variantKey : 'true'],
                              },
                    ],
                },
            ],
        },
    }
}

function cleanFlag(flag: Partial<FeatureFlagType>): Partial<FeatureFlagType> {
    const { created_at, id, created_by, last_modified_by, ...cleanedFlag } = flag
    return {
        ...cleanedFlag,
        filters: {
            ...cleanedFlag.filters,
            groups: cleanFilterGroups(cleanedFlag.filters?.groups) || [],
        },
    }
}

// Shape a freshly-loaded server flag into the `originalFeatureFlag` baseline the dirty check
// compares against. Callers must pass server-authoritative state — never the in-progress
// working copy — or an unsaved edit would be folded into the baseline and read as clean.
function toFeatureFlagBaseline(flag: FeatureFlagType | null): FeatureFlagType | null {
    return flag ? (indexToVariantKeyFeatureFlagPayloads(cleanFlag(flag)) as FeatureFlagType) : null
}

// Strip out sort_key from groups before saving. The sort_key is here for React to be able to
// render the release conditions in the correct order.
function cleanFilterGroups(groups?: FeatureFlagGroupType[]): FeatureFlagGroupType[] | undefined {
    if (groups === undefined || groups === null) {
        return undefined
    }
    return groups.map(({ sort_key, ...rest }: FeatureFlagGroupType) => rest)
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface featureFlagLogicValues {
    defaultEvaluationContexts: DefaultEvaluationContextsResponse | null // defaultEvaluationContextsLogic
    defaultReleaseConditions: DefaultReleaseConditionsResponse | null // defaultReleaseConditionsLogic
    enabledFeatures: FeatureFlagsSet // enabledFeaturesLogic
    aggregationLabel: (groupTypeIndex: number | null | undefined, deferToUserWording?: boolean) => Noun // groupsModel
    currentOrganization: OrganizationType | null // organizationLogic
    currentOrganizationId: string // organizationLogic
    currentProjectId: number | null // projectLogic
    currentTeam: TeamPublicType | TeamType | null // teamLogic
    currentTeamId: number | null // teamLogic
    hasAvailableFeature: (feature: AvailableFeature, currentUsage?: number | undefined) => boolean // userLogic
    user: UserType | null // userLogic
    accessDeniedToFeatureFlag: boolean
    activeRecurringSchedules: ScheduledChangeType[]
    activeSchedules: ScheduledChangeType[]
    activeTab: FeatureFlagsTab
    aggregationTargetName: string
    availableTabs: FeatureFlagsTab[]
    breadcrumbs: Breadcrumb[]
    canCreateEarlyAccessFeature: boolean
    canCreatePairedSchedule: boolean
    completedSchedules: ScheduledChangeType[]
    copyDependencies: boolean
    copyDependencyRequirements: CopyFlagsDependencyRequirementsResponseApi | null
    copyDependencyRequirementsLoading: boolean
    copyDestinationProject: number | null
    copySchedule: boolean
    cronExpression: string | null
    cronPreview: string | null
    customPairDisableCron: string
    customPairDisableCronPreview: string | null
    customPairEnableCron: string
    customPairEnableCronPreview: string | null
    dependentFlags: DependentFlag[]
    dependentFlagsLoading: boolean
    disableCopiedFlag: boolean
    earlyAccessFeaturesList: MinimalEarlyAccessFeatureType[]
    emailDomain: string
    endDate: Dayjs | null
    expandAdvancedOnEdit: boolean
    experiment: any
    experimentLoading: boolean
    featureFlag: FeatureFlagType
    featureFlagActiveUpdate: FeatureFlagType | null
    featureFlagActiveUpdateLoading: boolean
    featureFlagAllErrors: Record<string, any>
    featureFlagChanged: boolean
    featureFlagCopy: any
    featureFlagCopyLoading: boolean
    featureFlagErrors: DeepPartialMap<
        {
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        },
        ValidationErrorType
    >
    featureFlagHasErrors: boolean
    featureFlagKey: string
    featureFlagLoading: boolean
    featureFlagManualErrors: Record<string, any>
    featureFlagMissing: boolean
    featureFlagRefresh: FeatureFlagType | null
    featureFlagRefreshLoading: boolean
    featureFlagTouched: boolean
    featureFlagTouches: Record<string, boolean>
    featureFlagValidationErrors: DeepPartialMap<
        {
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        },
        ValidationErrorType
    >
    flagIntent: FlagIntent | null
    flagStatus: FeatureFlagStatusResponse | null
    flagStatusLoading: boolean
    flagType: 'boolean' | 'multivariate' | 'remote_config'
    flagTypeString:
        | 'Multiple variants with rollout percentages (A/B/n test)'
        | 'Release toggle (boolean)'
        | 'Remote configuration (single payload)'
    hasEarlyAccessFeatures: boolean
    hasEncryptedPayloadBeenSaved: boolean | undefined
    hasExperiment: boolean | null
    hasSurveys: boolean | null
    hasUnsavedChanges: boolean
    isDraftExperiment: boolean
    isEditingFlag: boolean
    isFeatureFlagSubmitting: boolean
    isFeatureFlagValid: boolean
    isFormDirty: boolean
    isRecurring: boolean
    multivariateEnabled: boolean
    newCohort: CohortType | null
    newCohortLoading: boolean
    newEarlyAccessFeature: EarlyAccessFeatureType | null
    newEarlyAccessFeatureLoading: boolean
    newSurvey: Survey | null
    newSurveyLoading: boolean
    nonEmptyVariants: MultivariateFlagVariant[]
    openVariants: string[]
    originalFeatureFlag: FeatureFlagType | null
    pausedRecurringSchedules: ScheduledChangeType[]
    payloadExpanded: boolean
    projectFlagsToggling: Record<string, boolean>
    projectTreeRef: ProjectTreeRef
    projectsWithCurrentFlag: OrganizationFeatureFlag[]
    projectsWithCurrentFlagLoading: boolean
    properties: AnyPropertyFilter[]
    propertySelectErrors: any
    props: any
    recordingFilterForFlag: Partial<RecordingUniversalFilters>
    recurrenceInterval: RecurrenceInterval | null
    relatedInsights: QueryBasedInsightModel[]
    relatedInsightsLoading: boolean
    repeatsValue: RecurrenceInterval | 'cron' | 'none'
    roleBasedAccessEnabled: boolean
    scheduleDateMarker: any
    scheduleDefaultsAppliedFromFlag: boolean
    scheduleFormCollapsible: boolean
    scheduleFormManuallyExpanded: boolean | null
    scheduleFormState: ScheduleFormState
    schedulePayload: ScheduleFlagPayload
    schedulePayloadErrors: any
    schedulePreset: PairedPresetKey | null
    scheduleTimelineOccurrences: ScheduleOccurrence[]
    scheduledChange: ScheduledChangeType
    scheduledChangeLoading: boolean
    scheduledChangeOperation: ScheduledChangeOperationType
    scheduledChanges: ScheduledChangeType[]
    scheduledChangesLoaded: boolean
    scheduledChangesLoading: boolean
    selectedTab: FeatureFlagsTab
    showFeatureFlagErrors: boolean
    showImplementation: boolean
    sidePanelContext: SidePanelSceneContext | null
    templateExpanded: boolean
    templates: Array<{
        description: string
        getValues: (flag: FeatureFlagType) => Partial<FeatureFlagType>
        id: string
        name: string
    }>
    upcomingOneTimeSchedules: ScheduledChangeType[]
    urlIntentApplied: boolean
    urlTemplateApplied: boolean
    variantErrors: VariantError[]
    variants: MultivariateFlagVariant[]
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface featureFlagLogicActions {
    loadDefaultEvaluationContexts: () => {
        value: true
    } // defaultEvaluationContextsLogic
    loadDefaultReleaseConditions: () => any // defaultReleaseConditionsLogic
    deleteFlag: (id: number) => {
        id: number
    } // featureFlagsLogic
    updateFlag: (flag: FeatureFlagType) => {
        flag: FeatureFlagType
    } // featureFlagsLogic
    closeSidePanel: (tab?: SidePanelTab | undefined) => {
        tab: SidePanelTab | undefined
    } // sidePanelStateLogic
    addProductIntent: (properties: ProductIntentProperties) => ProductIntentProperties // teamLogic
    addVariant: () => {
        value: true
    }
    applyScheduleDefaultsFromFlag: () => {
        value: true
    }
    applyTemplate: (templateId: string) => {
        templateId: string
    }
    applyUrlIntent: () => {
        value: true
    }
    applyUrlTemplate: (templateId: string) => {
        templateId: string
    }
    copyFlag: () => any
    copyFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    copyFlagSuccess: (
        featureFlagCopy: CopyFlagsResponseApi | undefined,
        payload?: any
    ) => {
        featureFlagCopy: CopyFlagsResponseApi | undefined
        payload?: any
    }
    createEarlyAccessFeature: () => any
    createEarlyAccessFeatureFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    createEarlyAccessFeatureSuccess: (
        newEarlyAccessFeature: EarlyAccessFeatureType,
        payload?: any
    ) => {
        newEarlyAccessFeature: EarlyAccessFeatureType
        payload?: any
    }
    createPairedSchedule: () => {
        value: true
    }
    createScheduledChange: () => any
    createScheduledChangeFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    createScheduledChangeSuccess: (
        scheduledChange: ScheduledChangeType | undefined,
        payload?: any
    ) => {
        scheduledChange: ScheduledChangeType | undefined
        payload?: any
    }
    createStaticCohort: () => any
    createStaticCohortFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    createStaticCohortSuccess: (
        newCohort: CohortType | null,
        payload?: any
    ) => {
        newCohort: CohortType | null
        payload?: any
    }
    createSurvey: () => any
    createSurveyFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    createSurveySuccess: (
        newSurvey: Survey,
        payload?: any
    ) => {
        newSurvey: Survey
        payload?: any
    }
    deleteFeatureFlag: (featureFlag: Partial<FeatureFlagType>) => {
        featureFlag: Partial<FeatureFlagType>
    }
    deleteScheduledChange: (scheduledChangeId: any) => any
    deleteScheduledChangeFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    deleteScheduledChangeSuccess: (
        scheduledChange:
            | {
                  scheduled_change: ScheduledChangeType
              }
            | undefined,
        payload?: any
    ) => {
        scheduledChange:
            | {
                  scheduled_change: ScheduledChangeType
              }
            | undefined
        payload?: any
    }
    distributeVariantsEqually: () => {
        value: true
    }
    duplicateVariant: (index: number) => {
        index: number
    }
    editFeatureFlag: (
        editing: boolean,
        options?: {
            expandAdvanced?: boolean
        }
    ) => {
        editing: boolean
        expandAdvanced: boolean
    }
    enrichUsageDashboard: () => {
        value: true
    }
    loadCopyDependencyRequirements: () => {
        value: true
    }
    loadCopyDependencyRequirementsFailure: (
        error: string,
        errorObject?: unknown
    ) => {
        error: string
        errorObject: unknown
    }
    loadCopyDependencyRequirementsSuccess: (
        copyDependencyRequirements: CopyFlagsDependencyRequirementsResponseApi | null
    ) => {
        copyDependencyRequirements: CopyFlagsDependencyRequirementsResponseApi | null
    }
    loadDependentFlags: () => any
    loadDependentFlagsFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadDependentFlagsSuccess: (
        dependentFlags: DependentFlag[],
        payload?: any
    ) => {
        dependentFlags: DependentFlag[]
        payload?: any
    }
    loadExperiment: () => any
    loadExperimentFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadExperimentSuccess: (
        experiment: Experiment | null,
        payload?: any
    ) => {
        experiment: Experiment | null
        payload?: any
    }
    loadFeatureFlag: () => any
    loadFeatureFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadFeatureFlagStatus: () => any
    loadFeatureFlagStatusFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadFeatureFlagStatusSuccess: (
        flagStatus: Promise<FeatureFlagStatusResponse> | null,
        payload?: any
    ) => {
        flagStatus: Promise<FeatureFlagStatusResponse> | null
        payload?: any
    }
    loadFeatureFlagSuccess: (
        featureFlag: FeatureFlagType,
        payload?: any
    ) => {
        featureFlag: FeatureFlagType
        payload?: any
    }
    loadProjectsWithCurrentFlag: () => any
    loadProjectsWithCurrentFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadProjectsWithCurrentFlagSuccess: (
        projectsWithCurrentFlag: OrganizationFeatureFlag[],
        payload?: any
    ) => {
        projectsWithCurrentFlag: OrganizationFeatureFlag[]
        payload?: any
    }
    loadRelatedInsights: () => any
    loadRelatedInsightsFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadRelatedInsightsSuccess: (
        relatedInsights: QueryBasedInsightModel<Node<Record<string, any>>>[],
        payload?: any
    ) => {
        relatedInsights: QueryBasedInsightModel<Node<Record<string, any>>>[]
        payload?: any
    }
    loadScheduledChanges: () => any
    loadScheduledChangesFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadScheduledChangesSuccess: (
        scheduledChanges: ScheduledChangeType[] | undefined,
        payload?: any
    ) => {
        scheduledChanges: ScheduledChangeType[] | undefined
        payload?: any
    }
    moveVariantDown: (index: number) => {
        index: number
    }
    moveVariantUp: (index: number) => {
        index: number
    }
    projectFlagActiveUpdateFailed: (
        teamId: number,
        flagId: number
    ) => {
        flagId: number
        teamId: number
    }
    projectFlagActiveUpdated: (
        teamId: number,
        flagId: number,
        active: boolean
    ) => {
        active: boolean
        flagId: number
        teamId: number
    }
    refreshFeatureFlag: () => any
    refreshFeatureFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    refreshFeatureFlagSuccess: (
        featureFlagRefresh: FeatureFlagType | null,
        payload?: any
    ) => {
        featureFlagRefresh: FeatureFlagType | null
        payload?: any
    }
    removeVariant: (index: number) => {
        index: number
    }
    reorderVariants: (
        fromIndex: number,
        toIndex: number
    ) => {
        fromIndex: number
        toIndex: number
    }
    resetEncryptedPayload: () => {}
    resetFeatureFlag: (values?: {
        _create_in_folder?: string | null | undefined
        active: boolean
        archived: boolean
        bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
        can_edit: boolean
        created_at: string | null
        created_by: UserBasicType | null
        deleted: boolean
        ensure_experience_continuity: boolean
        evaluation_contexts: string[]
        evaluation_runtime: FeatureFlagEvaluationRuntime
        experiment_set: number[] | null
        experiment_set_metadata:
            | {
                  id: number
                  is_running: boolean
                  name: string
              }[]
            | null
        features: MinimalEarlyAccessFeatureType[] | null
        filters: FeatureFlagFilters
        has_encrypted_payloads: boolean
        has_enriched_analytics?: boolean | undefined
        id: number | null
        is_remote_configuration: boolean
        is_used_in_replay_settings?: boolean | undefined
        key: string
        last_called_at?: string | null | undefined
        last_modified_by: UserBasicType | null
        name: string
        status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
        surveys: Survey[] | null
        tags: string[]
        updated_at: string | null
        usage_dashboard?: number | null | undefined
        user_access_level: AccessControlLevel
        version: number | null
    }) => {
        values?: {
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        }
    }
    resetScheduleFormExpanded: () => {
        value: true
    }
    restoreFeatureFlag: (featureFlag: Partial<FeatureFlagType>) => {
        featureFlag: Partial<FeatureFlagType>
    }
    resumeRecurringScheduledChange: (scheduledChangeId: number) => {
        scheduledChangeId: number
    }
    saveDescriptionInline: (name: string) => {
        name: string
    }
    saveFeatureFlag: (updatedFlag: Partial<FeatureFlagType>) => Partial<FeatureFlagType>
    saveFeatureFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    saveFeatureFlagSuccess: (
        featureFlag: FeatureFlagType,
        payload?: Partial<FeatureFlagType>
    ) => {
        featureFlag: FeatureFlagType
        payload?: Partial<FeatureFlagType>
    }
    saveSidebarExperimentFeatureFlag: (updatedFlag: Partial<FeatureFlagType>) => Partial<FeatureFlagType>
    saveSidebarExperimentFeatureFlagFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    saveSidebarExperimentFeatureFlagSuccess: (
        featureFlag: FeatureFlagType,
        payload?: Partial<FeatureFlagType>
    ) => {
        featureFlag: FeatureFlagType
        payload?: Partial<FeatureFlagType>
    }
    saveTagsInline: (tags: string[]) => {
        tags: string[]
    }
    setAccessDeniedToFeatureFlag: () => {
        value: true
    }
    setBucketingIdentifier: (bucketingIdentifier: FeatureFlagBucketingIdentifier | null) => {
        bucketingIdentifier: FeatureFlagBucketingIdentifier | null
    }
    setCopyDependencies: (copyDependencies: boolean) => {
        copyDependencies: boolean
    }
    setCopyDestinationProject: (id: number | null) => {
        id: number | null
    }
    setCopySchedule: (copySchedule: boolean) => {
        copySchedule: boolean
    }
    setCronExpression: (cronExpression: string | null) => {
        cronExpression: string | null
    }
    setCustomPairCron: (
        which: 'disable' | 'enable',
        expression: string
    ) => {
        expression: string
        which: 'disable' | 'enable'
    }
    setDisableCopiedFlag: (disableCopiedFlag: boolean) => {
        disableCopiedFlag: boolean
    }
    setEndDate: (endDate: Dayjs | null) => {
        endDate: Dayjs | null
    }
    setFeatureFlag: (featureFlag: FeatureFlagType) => {
        featureFlag: FeatureFlagType
    }
    setFeatureFlagFilters: (
        filters: FeatureFlagType['filters'],
        errors: any
    ) => {
        errors: any
        filters: FeatureFlagFilters
    }
    setFeatureFlagManualErrors: (errors: Record<string, any>) => {
        errors: Record<string, any>
    }
    setFeatureFlagMissing: () => {
        value: true
    }
    setFeatureFlagValue: (
        key: FieldName,
        value: any
    ) => {
        name: FieldName
        value: any
    }
    setFeatureFlagValues: (
        values: DeepPartial<{
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        }>
    ) => {
        values: DeepPartial<{
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        }>
    }
    setFlagIntent: (intent: FlagIntent | null) => {
        intent: FlagIntent | null
    }
    setIsRecurring: (isRecurring: boolean) => {
        isRecurring: boolean
    }
    setMultivariateEnabled: (enabled: boolean) => {
        enabled: boolean
    }
    setMultivariateOptions: (multivariateOptions: MultivariateFlagOptions | null) => {
        multivariateOptions: MultivariateFlagOptions | null
    }
    setOpenVariants: (openVariants: string[]) => {
        openVariants: string[]
    }
    setOriginalFeatureFlag: (featureFlag: FeatureFlagType | null) => {
        featureFlag: FeatureFlagType | null
    }
    setPayloadExpanded: (expanded: boolean) => {
        expanded: boolean
    }
    setRecurrenceInterval: (interval: RecurrenceInterval | null) => {
        interval: RecurrenceInterval | null
    }
    setRemoteConfigEnabled: (enabled: boolean) => {
        enabled: boolean
    }
    setRepeatsValue: (value: RecurrenceInterval | 'cron' | 'none') => {
        value: RecurrenceInterval | 'cron' | 'none'
    }
    setScheduleDateMarker: (dateMarker: any) => {
        dateMarker: any
    }
    setScheduleFormExpanded: (expanded: boolean) => {
        expanded: boolean
    }
    setSchedulePayload: (
        filters: FeatureFlagType['filters'] | null,
        active: FeatureFlagType['active'] | null,
        errors?: any,
        variants?: MultivariateFlagVariant[] | null,
        payloads?: Record<string, any> | null
    ) => {
        active: boolean | null
        errors: any
        filters: FeatureFlagFilters | null
        payloads: Record<string, any> | null | undefined
        variants: MultivariateFlagVariant[] | null | undefined
    }
    setSchedulePreset: (preset: PairedPresetKey | null) => {
        preset: PairedPresetKey | null
    }
    setScheduledChangeOperation: (changeType: ScheduledChangeOperationType) => {
        changeType: ScheduledChangeOperationType
    }
    setSelectedTab: (tab: FeatureFlagsTab) => {
        tab: FeatureFlagsTab
    }
    setShowImplementation: (show: boolean) => {
        show: boolean
    }
    setTemplateExpanded: (expanded: boolean) => {
        expanded: boolean
    }
    showDependentFlagsConfirmation: (payload: {
        dependentFlags: DependentFlag[]
        isBeingDisabled?: boolean
        onConfirm: () => void
        onDisableAndArchive?: () => void
        originalFlag: FeatureFlagType | null
        requireStatusConfirmation?: boolean
        updatedFlag: Partial<FeatureFlagType>
    }) => {
        dependentFlags: DependentFlag[]
        isBeingDisabled?: boolean | undefined
        onConfirm: () => void
        onDisableAndArchive?: (() => void) | undefined
        originalFlag: FeatureFlagType | null
        requireStatusConfirmation?: boolean | undefined
        updatedFlag: Partial<FeatureFlagType>
    }
    stopRecurringScheduledChange: (scheduledChangeId: number) => {
        scheduledChangeId: number
    }
    submitFeatureFlag: () => {
        value: boolean
    }
    submitFeatureFlagFailure: (
        error: Error,
        errors: Record<string, any>
    ) => {
        error: Error
        errors: Record<string, any>
    }
    submitFeatureFlagRequest: (featureFlag: {
        _create_in_folder?: string | null | undefined
        active: boolean
        archived: boolean
        bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
        can_edit: boolean
        created_at: string | null
        created_by: UserBasicType | null
        deleted: boolean
        ensure_experience_continuity: boolean
        evaluation_contexts: string[]
        evaluation_runtime: FeatureFlagEvaluationRuntime
        experiment_set: number[] | null
        experiment_set_metadata:
            | {
                  id: number
                  is_running: boolean
                  name: string
              }[]
            | null
        features: MinimalEarlyAccessFeatureType[] | null
        filters: FeatureFlagFilters
        has_encrypted_payloads: boolean
        has_enriched_analytics?: boolean | undefined
        id: number | null
        is_remote_configuration: boolean
        is_used_in_replay_settings?: boolean | undefined
        key: string
        last_called_at?: string | null | undefined
        last_modified_by: UserBasicType | null
        name: string
        status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
        surveys: Survey[] | null
        tags: string[]
        updated_at: string | null
        usage_dashboard?: number | null | undefined
        user_access_level: AccessControlLevel
        version: number | null
    }) => {
        featureFlag: {
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        }
    }
    submitFeatureFlagSuccess: (featureFlag: {
        _create_in_folder?: string | null | undefined
        active: boolean
        archived: boolean
        bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
        can_edit: boolean
        created_at: string | null
        created_by: UserBasicType | null
        deleted: boolean
        ensure_experience_continuity: boolean
        evaluation_contexts: string[]
        evaluation_runtime: FeatureFlagEvaluationRuntime
        experiment_set: number[] | null
        experiment_set_metadata:
            | {
                  id: number
                  is_running: boolean
                  name: string
              }[]
            | null
        features: MinimalEarlyAccessFeatureType[] | null
        filters: FeatureFlagFilters
        has_encrypted_payloads: boolean
        has_enriched_analytics?: boolean | undefined
        id: number | null
        is_remote_configuration: boolean
        is_used_in_replay_settings?: boolean | undefined
        key: string
        last_called_at?: string | null | undefined
        last_modified_by: UserBasicType | null
        name: string
        status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
        surveys: Survey[] | null
        tags: string[]
        updated_at: string | null
        usage_dashboard?: number | null | undefined
        user_access_level: AccessControlLevel
        version: number | null
    }) => {
        featureFlag: {
            _create_in_folder?: string | null | undefined
            active: boolean
            archived: boolean
            bucketing_identifier?: FeatureFlagBucketingIdentifier | null | undefined
            can_edit: boolean
            created_at: string | null
            created_by: UserBasicType | null
            deleted: boolean
            ensure_experience_continuity: boolean
            evaluation_contexts: string[]
            evaluation_runtime: FeatureFlagEvaluationRuntime
            experiment_set: number[] | null
            experiment_set_metadata:
                | {
                      id: number
                      is_running: boolean
                      name: string
                  }[]
                | null
            features: MinimalEarlyAccessFeatureType[] | null
            filters: FeatureFlagFilters
            has_encrypted_payloads: boolean
            has_enriched_analytics?: boolean | undefined
            id: number | null
            is_remote_configuration: boolean
            is_used_in_replay_settings?: boolean | undefined
            key: string
            last_called_at?: string | null | undefined
            last_modified_by: UserBasicType | null
            name: string
            status: 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'STALE' | 'UNKNOWN'
            surveys: Survey[] | null
            tags: string[]
            updated_at: string | null
            usage_dashboard?: number | null | undefined
            user_access_level: AccessControlLevel
            version: number | null
        }
    }
    submitFeatureFlagWithValidation: (featureFlag: Partial<FeatureFlagType>) => {
        featureFlag: Partial<FeatureFlagType>
    }
    toggleFeatureFlagActive: (active: boolean) => {
        active: boolean
    }
    toggleProjectFlagActive: (
        teamId: number,
        flagId: number,
        active: boolean
    ) => {
        active: boolean
        flagId: number
        teamId: number
    }
    touchFeatureFlagField: (key: string) => {
        key: string
    }
    updateFeatureFlagActive: (active: boolean) => boolean
    updateFeatureFlagActiveFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    updateFeatureFlagActiveSuccess: (
        featureFlagActiveUpdate: FeatureFlagType,
        payload?: boolean
    ) => {
        featureFlagActiveUpdate: FeatureFlagType
        payload?: boolean
    }
    updateFeatureFlagArchived: ({
        archived,
        via,
    }: {
        archived: boolean
        /** Telemetry source; only meaningful (and only captured) when archiving, not unarchiving. */
        via?: FeatureFlagArchivedSource
    }) => {
        archived: boolean
        via?: FeatureFlagArchivedSource
    }
    updateFeatureFlagArchivedFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    updateFeatureFlagArchivedSuccess: (
        featureFlagActiveUpdate: FeatureFlagType,
        payload?: {
            archived: boolean
            via?: FeatureFlagArchivedSource
        }
    ) => {
        featureFlagActiveUpdate: FeatureFlagType
        payload?: {
            archived: boolean
            via?: FeatureFlagArchivedSource
        }
    }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface featureFlagLogicMeta {
    key: number | 'link' | 'new'
    sharedListeners: {
        checkDependentFlagsAndConfirm: (
            payload: {
                onConfirm: () => void
                onDisableAndArchive?: (() => void) | undefined
                originalFlag: FeatureFlagType | null
                requireStatusConfirmation?: boolean | undefined
                updatedFlag: Partial<FeatureFlagType>
            },
            breakpoint: BreakPointFunction,
            action: {
                type: string
                payload: {
                    onConfirm: () => void
                    onDisableAndArchive?: (() => void) | undefined
                    originalFlag: FeatureFlagType | null
                    requireStatusConfirmation?: boolean | undefined
                    updatedFlag: Partial<FeatureFlagType>
                }
            },
            previousState: any
        ) => void | Promise<void>
        showDependentFlagsConfirmation: (
            payload: {
                dependentFlags: DependentFlag[]
                isBeingDisabled?: boolean | undefined
                onConfirm: () => void
                onDisableAndArchive?: (() => void) | undefined
                originalFlag: FeatureFlagType | null
                requireStatusConfirmation?: boolean | undefined
                updatedFlag: Partial<FeatureFlagType>
            },
            breakpoint: BreakPointFunction,
            action: {
                type: string
                payload: {
                    dependentFlags: DependentFlag[]
                    isBeingDisabled?: boolean | undefined
                    onConfirm: () => void
                    onDisableAndArchive?: (() => void) | undefined
                    originalFlag: FeatureFlagType | null
                    requireStatusConfirmation?: boolean | undefined
                    updatedFlag: Partial<FeatureFlagType>
                }
            },
            previousState: any
        ) => void | Promise<void>
    }
    __keaTypeGenInternalSelectorTypes: {
        props: (arg: any) => any
        availableTabs: (featureFlag: FeatureFlagType, props: any) => FeatureFlagsTab[]
        activeTab: (selectedTab: FeatureFlagsTab, availableTabs: FeatureFlagsTab[]) => FeatureFlagsTab
        hasUnsavedChanges: (featureFlag: FeatureFlagType, originalFeatureFlag: FeatureFlagType | null) => boolean
        isFormDirty: (
            originalFeatureFlag: FeatureFlagType | null,
            hasUnsavedChanges: boolean,
            featureFlagChanged: boolean
        ) => boolean
        multivariateEnabled: (featureFlag: FeatureFlagType) => boolean
        flagType: (featureFlag: FeatureFlagType) => 'boolean' | 'multivariate' | 'remote_config'
        flagTypeString: (
            featureFlag: FeatureFlagType
        ) =>
            | 'Multiple variants with rollout percentages (A/B/n test)'
            | 'Release toggle (boolean)'
            | 'Remote configuration (single payload)'
        roleBasedAccessEnabled: (
            hasAvailableFeature: (feature: AvailableFeature, currentUsage?: number | undefined) => boolean // userLogic
        ) => boolean
        variants: (featureFlag: FeatureFlagType) => MultivariateFlagVariant[]
        nonEmptyVariants: (variants: MultivariateFlagVariant[]) => MultivariateFlagVariant[]
        aggregationTargetName: (
            featureFlag: FeatureFlagType,
            aggregationLabel: (groupTypeIndex: number | null | undefined, deferToUserWording?: boolean) => Noun // groupsModel
        ) => string
        breadcrumbs: (featureFlag: FeatureFlagType) => Breadcrumb[]
        projectTreeRef: (arg: number | 'link' | 'new') => ProjectTreeRef
        sidePanelContext: (featureFlag: FeatureFlagType) => SidePanelSceneContext | null
        recordingFilterForFlag: (featureFlag: FeatureFlagType) => Partial<RecordingUniversalFilters>
        hasEarlyAccessFeatures: (featureFlag: FeatureFlagType) => boolean
        earlyAccessFeaturesList: (featureFlag: FeatureFlagType) => MinimalEarlyAccessFeatureType[]
        featureFlagKey: (featureFlag: FeatureFlagType) => string
        canCreateEarlyAccessFeature: (featureFlag: FeatureFlagType, variants: MultivariateFlagVariant[]) => boolean
        hasSurveys: (featureFlag: FeatureFlagType) => boolean | null
        hasEncryptedPayloadBeenSaved: (featureFlag: FeatureFlagType, props: any) => boolean | undefined
        hasExperiment: (featureFlag: FeatureFlagType) => boolean | null
        isDraftExperiment: (experiment: any) => boolean
        properties: (featureFlag: FeatureFlagType) => AnyPropertyFilter[]
        variantErrors: (variants: MultivariateFlagVariant[]) => VariantError[]
        repeatsValue: (
            isRecurring: boolean,
            cronExpression: string | null,
            recurrenceInterval: RecurrenceInterval | null
        ) => RecurrenceInterval | 'cron' | 'none'
        cronPreview: (cronExpression: string | null) => string | null
        customPairEnableCronPreview: (customPairEnableCron: string) => string | null
        customPairDisableCronPreview: (customPairDisableCron: string) => string | null
        canCreatePairedSchedule: (
            schedulePreset: PairedPresetKey | null,
            customPairEnableCron: string,
            customPairDisableCron: string,
            customPairEnableCronPreview: string | null,
            customPairDisableCronPreview: string | null
        ) => boolean
        activeRecurringSchedules: (scheduledChanges: ScheduledChangeType[]) => ScheduledChangeType[]
        pausedRecurringSchedules: (scheduledChanges: ScheduledChangeType[]) => ScheduledChangeType[]
        upcomingOneTimeSchedules: (scheduledChanges: ScheduledChangeType[]) => ScheduledChangeType[]
        completedSchedules: (scheduledChanges: ScheduledChangeType[]) => ScheduledChangeType[]
        activeSchedules: (
            activeRecurringSchedules: ScheduledChangeType[],
            pausedRecurringSchedules: ScheduledChangeType[],
            upcomingOneTimeSchedules: ScheduledChangeType[]
        ) => ScheduledChangeType[]
        scheduleTimelineOccurrences: (
            scheduledChanges: ScheduledChangeType[],
            featureFlag: FeatureFlagType
        ) => ScheduleOccurrence[]
        scheduleFormCollapsible: (activeSchedules: ScheduledChangeType[]) => boolean
        scheduleFormState: (
            scheduleFormManuallyExpanded: boolean | null,
            scheduleFormCollapsible: boolean,
            scheduledChangesLoading: boolean,
            scheduledChangesLoaded: boolean
        ) => ScheduleFormState
        emailDomain: (user: UserType | null) => string
        templates: (emailDomain: string) => Array<{
            description: string
            getValues: (flag: FeatureFlagType) => Partial<FeatureFlagType>
            id: string
            name: string
        }>
    }
}

export type featureFlagLogicType = MakeLogicType<
    featureFlagLogicValues,
    featureFlagLogicActions,
    FeatureFlagLogicProps,
    featureFlagLogicMeta
>

export const featureFlagLogic = kea<featureFlagLogicType>([
    path(['scenes', 'feature-flags', 'featureFlagLogic']),
    props({} as FeatureFlagLogicProps),
    key(({ id }) => id ?? 'unknown'),
    connect(() => ({
        values: [
            teamLogic,
            ['currentTeam', 'currentTeamId'],
            projectLogic,
            ['currentProjectId'],
            groupsModel,
            ['aggregationLabel'],
            userLogic,
            ['hasAvailableFeature', 'user'],
            organizationLogic,
            ['currentOrganization', 'currentOrganizationId'],
            enabledFeaturesLogic,
            ['featureFlags as enabledFeatures'],
            defaultEvaluationContextsLogic,
            ['defaultEvaluationContexts'],
            defaultReleaseConditionsLogic,
            ['defaultReleaseConditions'],
        ],
        actions: [
            featureFlagsLogic,
            ['updateFlag', 'deleteFlag'],
            sidePanelStateLogic,
            ['closeSidePanel'],
            teamLogic,
            ['addProductIntent'],
            defaultEvaluationContextsLogic,
            ['loadDefaultEvaluationContexts'],
            defaultReleaseConditionsLogic,
            ['loadDefaultReleaseConditions'],
        ],
    })),
    actions({
        setFeatureFlag: (featureFlag: FeatureFlagType) => ({ featureFlag }),
        // Re-establishes the saved-state baseline the unsaved-changes guard diffs against.
        // Only dispatch with server-authoritative state, so in-progress edits stay dirty.
        setOriginalFeatureFlag: (featureFlag: FeatureFlagType | null) => ({ featureFlag }),
        setFeatureFlagFilters: (filters: FeatureFlagType['filters'], errors: any) => ({ filters, errors }),
        setSelectedTab: (tab: FeatureFlagsTab) => ({ tab }),
        setFeatureFlagMissing: true,
        deleteFeatureFlag: (featureFlag: Partial<FeatureFlagType>) => ({ featureFlag }),
        restoreFeatureFlag: (featureFlag: Partial<FeatureFlagType>) => ({ featureFlag }),
        setRemoteConfigEnabled: (enabled: boolean) => ({ enabled }),
        resetEncryptedPayload: () => ({}),
        setMultivariateEnabled: (enabled: boolean) => ({ enabled }),
        setMultivariateOptions: (multivariateOptions: MultivariateFlagOptions | null) => ({ multivariateOptions }),
        addVariant: true,
        duplicateVariant: (index: number) => ({ index }),
        removeVariant: (index: number) => ({ index }),
        moveVariantUp: (index: number) => ({ index }),
        moveVariantDown: (index: number) => ({ index }),
        reorderVariants: (fromIndex: number, toIndex: number) => ({ fromIndex, toIndex }),
        editFeatureFlag: (editing: boolean, options?: { expandAdvanced?: boolean }) => ({
            editing,
            expandAdvanced: options?.expandAdvanced ?? false,
        }),
        distributeVariantsEqually: true,
        enrichUsageDashboard: true,
        setCopyDestinationProject: (id: number | null) => ({ id }),
        setCopySchedule: (copySchedule: boolean) => ({ copySchedule }),
        setDisableCopiedFlag: (disableCopiedFlag: boolean) => ({ disableCopiedFlag }),
        setCopyDependencies: (copyDependencies: boolean) => ({ copyDependencies }),
        loadCopyDependencyRequirements: true,
        loadCopyDependencyRequirementsSuccess: (
            copyDependencyRequirements: CopyFlagsDependencyRequirementsResponseApi | null
        ) => ({ copyDependencyRequirements }),
        loadCopyDependencyRequirementsFailure: (error: string, errorObject?: unknown) => ({ error, errorObject }),
        setScheduleDateMarker: (dateMarker: any) => ({ dateMarker }),
        setScheduleFormExpanded: (expanded: boolean) => ({ expanded }),
        resetScheduleFormExpanded: true,
        setSchedulePayload: (
            filters: FeatureFlagType['filters'] | null,
            active: FeatureFlagType['active'] | null,
            errors?: any,
            variants?: MultivariateFlagVariant[] | null,
            payloads?: Record<string, any> | null
        ) => ({ filters, active, errors, variants, payloads }),
        setScheduledChangeOperation: (changeType: ScheduledChangeOperationType) => ({ changeType }),
        setIsRecurring: (isRecurring: boolean) => ({ isRecurring }),
        setRecurrenceInterval: (interval: RecurrenceInterval | null) => ({ interval }),
        setCronExpression: (cronExpression: string | null) => ({ cronExpression }),
        setRepeatsValue: (value: RecurrenceInterval | 'none' | 'cron') => ({ value }),
        setEndDate: (endDate: Dayjs | null) => ({ endDate }),
        stopRecurringScheduledChange: (scheduledChangeId: number) => ({ scheduledChangeId }),
        resumeRecurringScheduledChange: (scheduledChangeId: number) => ({ scheduledChangeId }),
        setSchedulePreset: (preset: PairedPresetKey | null) => ({ preset }),
        setCustomPairCron: (which: 'enable' | 'disable', expression: string) => ({ which, expression }),
        createPairedSchedule: true,
        setAccessDeniedToFeatureFlag: true,
        toggleFeatureFlagActive: (active: boolean) => ({ active }),
        toggleProjectFlagActive: (teamId: number, flagId: number, active: boolean) => ({ teamId, flagId, active }),
        projectFlagActiveUpdated: (teamId: number, flagId: number, active: boolean) => ({ teamId, flagId, active }),
        projectFlagActiveUpdateFailed: (teamId: number, flagId: number) => ({ teamId, flagId }),
        submitFeatureFlagWithValidation: (featureFlag: Partial<FeatureFlagType>) => ({ featureFlag }),
        setBucketingIdentifier: (bucketingIdentifier: FeatureFlagBucketingIdentifier | null) => ({
            bucketingIdentifier,
        }),
        showDependentFlagsConfirmation: (payload: {
            originalFlag: FeatureFlagType | null
            updatedFlag: Partial<FeatureFlagType>
            onConfirm: () => void
            dependentFlags: DependentFlag[]
            isBeingDisabled?: boolean
            requireStatusConfirmation?: boolean
            onDisableAndArchive?: () => void
        }) => payload,
        saveDescriptionInline: (name: string) => ({ name }),
        saveTagsInline: (tags: string[]) => ({ tags }),
        // V2 form UI actions
        setShowImplementation: (show: boolean) => ({ show }),
        setOpenVariants: (openVariants: string[]) => ({ openVariants }),
        setPayloadExpanded: (expanded: boolean) => ({ expanded }),
        setTemplateExpanded: (expanded: boolean) => ({ expanded }),
        applyUrlTemplate: (templateId: string) => ({ templateId }),
        applyTemplate: (templateId: string) => ({ templateId }),
        setFlagIntent: (intent: FlagIntent | null) => ({ intent }),
        applyUrlIntent: true,
        applyScheduleDefaultsFromFlag: true,
    }),
    forms(({ actions, values }) => ({
        featureFlag: {
            defaults: {
                ...NEW_FLAG,
                ensure_experience_continuity: values.currentTeam?.flags_persistence_default || false,
            },
            errors: ({ key, filters, is_remote_configuration }) => {
                const rolloutSumError = validateVariantRolloutSum(filters?.multivariate?.variants)
                return {
                    key: validateFeatureFlagKey(key),
                    filters: {
                        multivariate: {
                            variants: filters?.multivariate?.variants?.map(
                                ({ key: variantKey }: MultivariateFlagVariant) => ({
                                    key: validateFeatureFlagVariantKey(variantKey),
                                    // One string on the array key (the usual form) can't say which
                                    // panels to expand, so the set-level error fans out per index.
                                    rollout_percentage: rolloutSumError,
                                })
                            ),
                        },
                        groups: values.propertySelectErrors as DeepPartialMap<
                            FeatureFlagGroupType,
                            ValidationErrorType
                        >[],
                        payloads: {
                            true: validatePayloadRequired(is_remote_configuration, filters?.payloads?.['true']),
                        } as any,
                        // Forced any cast necessary to prevent Kea's typechecking from raising "Type instantiation
                        // is excessively deep and possibly infinite" error
                    },
                }
            },
            submit: async () => {
                // Validation/save uses reducer state in submitFeatureFlagWithValidation; kea-forms can omit nested updates from setFeatureFlagFilters.
                await actions.submitFeatureFlagWithValidation({} as Partial<FeatureFlagType>)
            },
        },
    })),
    reducers({
        originalFeatureFlag: [
            null as FeatureFlagType | null,
            {
                // Baseline the saved server state on load. NOT on every setFeatureFlag: a
                // mid-edit setFeatureFlag (tag save, active/archive sync, cache reconcile) would
                // otherwise re-baseline to the already-edited working copy, making the
                // unsaved-changes guard read clean and silently discard release-condition edits on
                // navigation. Server-authoritative re-baselines flow through setOriginalFeatureFlag.
                loadFeatureFlagSuccess: (_, { featureFlag }) => toFeatureFlagBaseline(featureFlag),
                setOriginalFeatureFlag: (_, { featureFlag }) => featureFlag,
            },
        ],
        featureFlag: [
            { ...NEW_FLAG } as FeatureFlagType,
            {
                setFeatureFlag: (_, { featureFlag }) => {
                    return featureFlag
                },
                setFeatureFlagFilters: (state, { filters }) => {
                    if (!state) {
                        return state
                    }
                    return {
                        ...state,
                        filters: {
                            ...filters,
                            // Preserve current payloads: this action only carries release-condition changes;
                            // the child component's payloads snapshot is always stale.
                            payloads: state.filters.payloads,
                        },
                    }
                },
                setMultivariateOptions: (state, { multivariateOptions }) => {
                    if (!state) {
                        return state
                    }
                    const variantsSet = new Set(multivariateOptions?.variants.map((variant) => variant.key))
                    const groups = state.filters.groups.map((group) =>
                        !group.variant || variantsSet.has(group.variant) ? group : { ...group, variant: null }
                    )
                    const oldPayloads = state.filters.payloads ?? {}
                    const payloads: Record<string, JsonType> = {}
                    for (const variantKey of Object.keys(oldPayloads)) {
                        if (variantsSet.has(variantKey)) {
                            payloads[variantKey] = oldPayloads[variantKey]
                        }
                    }
                    return {
                        ...state,
                        filters: { ...state.filters, groups, payloads, multivariate: multivariateOptions },
                    }
                },
                setRemoteConfigEnabled: (state, { enabled }) => {
                    if (!state) {
                        return state
                    }

                    return {
                        ...state,
                        is_remote_configuration: enabled,
                    }
                },
                setBucketingIdentifier: (state, { bucketingIdentifier }) => {
                    if (!state) {
                        return state
                    }

                    return {
                        ...state,
                        bucketing_identifier: bucketingIdentifier,
                    }
                },
                resetEncryptedPayload: (state) => {
                    if (!state) {
                        return state
                    }

                    return {
                        ...state,
                        filters: {
                            ...state.filters,
                            payloads: { true: '' },
                        },
                        has_encrypted_payloads: false,
                    }
                },
                addVariant: (state) => {
                    if (!state) {
                        return state
                    }
                    const variants = [...(state.filters.multivariate?.variants || [])]
                    return {
                        ...state,
                        filters: {
                            ...state.filters,
                            multivariate: {
                                ...state.filters.multivariate,
                                variants: [...variants, NEW_VARIANT],
                            },
                        },
                    }
                },
                removeVariant: (state, { index }) => {
                    if (!state) {
                        return state
                    }
                    const variants = [...(state.filters.multivariate?.variants || [])]
                    variants.splice(index, 1)

                    const currentPayloads = { ...state.filters.payloads }
                    const newPayloads: Record<number, any> = {}

                    // TRICKY: In addition to modifying the variant array, we also need to shift the payload indices
                    // because the variant array is being modified and we need to make sure that the payloads object
                    // stays in sync with the variant array.
                    Object.keys(currentPayloads).forEach((key) => {
                        const payloadIndex = parseInt(key)
                        if (payloadIndex > index) {
                            newPayloads[payloadIndex - 1] = currentPayloads[payloadIndex]
                        } else if (payloadIndex < index) {
                            newPayloads[payloadIndex] = currentPayloads[payloadIndex]
                        }
                    })

                    return {
                        ...state,
                        filters: {
                            ...state.filters,
                            multivariate: {
                                ...state.filters.multivariate,
                                variants,
                            },
                            payloads: newPayloads,
                        },
                    }
                },
                moveVariantUp: (state, { index }) => {
                    if (!state || index <= 0) {
                        return state
                    }
                    const variants = state.filters.multivariate?.variants || []
                    if (index >= variants.length) {
                        return state
                    }
                    return reorderVariantState(state, variants, index, index - 1)
                },
                moveVariantDown: (state, { index }) => {
                    if (!state) {
                        return state
                    }
                    const variants = state.filters.multivariate?.variants || []
                    if (index < 0 || index >= variants.length - 1) {
                        return state
                    }
                    return reorderVariantState(state, variants, index, index + 1)
                },
                reorderVariants: (state, { fromIndex, toIndex }) => {
                    if (!state) {
                        return state
                    }
                    const variants = state.filters.multivariate?.variants || []
                    if (
                        fromIndex < 0 ||
                        fromIndex >= variants.length ||
                        toIndex < 0 ||
                        toIndex >= variants.length ||
                        fromIndex === toIndex
                    ) {
                        return state
                    }
                    return reorderVariantState(state, variants, fromIndex, toIndex)
                },
                distributeVariantsEqually: (state) => {
                    // Adjust the variants to be as evenly distributed as possible,
                    // taking integer rounding into account
                    if (!state) {
                        return state
                    }
                    const variants = [...(state.filters.multivariate?.variants || [])]
                    const numVariants = variants.length
                    if (numVariants > 0 && numVariants <= 100) {
                        const percentageRounded = Math.round(100 / numVariants)
                        const totalRounded = percentageRounded * numVariants
                        const delta = totalRounded - 100
                        variants.forEach((variant, index) => {
                            variants[index] = { ...variant, rollout_percentage: percentageRounded }
                        })
                        // Apply the rounding error to the last index
                        variants[numVariants - 1] = {
                            ...variants[numVariants - 1],
                            rollout_percentage: percentageRounded - delta,
                        }
                    }
                    return {
                        ...state,
                        filters: {
                            ...state.filters,
                            multivariate: {
                                ...state.filters.multivariate,
                                variants,
                            },
                        },
                    }
                },
                createEarlyAccessFeatureSuccess: (state, { newEarlyAccessFeature }) => {
                    if (!state) {
                        return state
                    }
                    return {
                        ...state,
                        features: [
                            ...(state.features || []),
                            {
                                id: newEarlyAccessFeature.id,
                                name: newEarlyAccessFeature.name,
                                description: newEarlyAccessFeature.description,
                                stage: newEarlyAccessFeature.stage,
                                documentationUrl: newEarlyAccessFeature.documentation_url,
                                flagKey: newEarlyAccessFeature.feature_flag?.key ?? null,
                                payload: newEarlyAccessFeature.payload,
                            },
                        ],
                    }
                },
                createSurveySuccess: (state, { newSurvey }) => {
                    if (!state) {
                        return state
                    }
                    return {
                        ...state,
                        surveys: [...(state.surveys || []), newSurvey],
                    }
                },
            },
        ],
        accessDeniedToFeatureFlag: [false, { setAccessDeniedToFeatureFlag: () => true }],
        propertySelectErrors: [
            null as any,
            {
                setFeatureFlagFilters: (_, { errors }) => {
                    return errors
                },
            },
        ],
        selectedTab: [
            FeatureFlagsTab.OVERVIEW as FeatureFlagsTab,
            {
                setSelectedTab: (_, { tab }) => tab,
            },
        ],
        featureFlagMissing: [false, { setFeatureFlagMissing: () => true }],
        isEditingFlag: [
            false,
            {
                editFeatureFlag: (_, { editing }) => editing,
            },
        ],
        expandAdvancedOnEdit: [
            false,
            {
                editFeatureFlag: (_, { expandAdvanced }) => expandAdvanced,
            },
        ],
        copyDestinationProject: [
            null as number | null,
            {
                setCopyDestinationProject: (_, { id }) => id,
            },
        ],
        projectFlagsToggling: [
            {} as Record<string, boolean>,
            {
                toggleProjectFlagActive: (state, { teamId, flagId }) => ({
                    ...state,
                    [flagToggleKey(teamId, flagId)]: true,
                }),
                projectFlagActiveUpdated: (state, { teamId, flagId }) => {
                    const { [flagToggleKey(teamId, flagId)]: _, ...rest } = state
                    return rest
                },
                projectFlagActiveUpdateFailed: (state, { teamId, flagId }) => {
                    const { [flagToggleKey(teamId, flagId)]: _, ...rest } = state
                    return rest
                },
            },
        ],
        copySchedule: [
            false as boolean,
            {
                setCopySchedule: (_, { copySchedule }) => copySchedule,
            },
        ],
        disableCopiedFlag: [
            false as boolean,
            {
                setDisableCopiedFlag: (_, { disableCopiedFlag }) => disableCopiedFlag,
            },
        ],
        copyDependencies: [
            false as boolean,
            {
                setCopyDependencies: (_, { copyDependencies }) => copyDependencies,
                loadCopyDependencyRequirementsSuccess: (state, { copyDependencyRequirements }) =>
                    copyDependencyRequirements?.can_copy_dependencies ? state : false,
                loadCopyDependencyRequirementsFailure: () => false,
                setCopyDestinationProject: () => false,
                loadFeatureFlagSuccess: () => false,
                setFeatureFlag: () => false,
                copyFlagSuccess: () => false,
            },
        ],
        copyDependencyRequirements: [
            null as CopyFlagsDependencyRequirementsResponseApi | null,
            {
                loadCopyDependencyRequirements: () => null,
                loadCopyDependencyRequirementsSuccess: (_, { copyDependencyRequirements }) =>
                    copyDependencyRequirements,
                loadCopyDependencyRequirementsFailure: () => COPY_DEPENDENCY_REQUIREMENTS_UNAVAILABLE,
                setCopyDestinationProject: () => null,
                loadFeatureFlagSuccess: () => null,
                setFeatureFlag: () => null,
            },
        ],
        copyDependencyRequirementsLoading: [
            false,
            {
                loadCopyDependencyRequirements: () => true,
                loadCopyDependencyRequirementsSuccess: () => false,
                loadCopyDependencyRequirementsFailure: () => false,
            },
        ],
        scheduleDateMarker: [
            null as any,
            {
                setScheduleDateMarker: (_, { dateMarker }) => dateMarker,
            },
        ],
        // Null until the user opens or closes the form; the default is derived from
        // whether the flag already has active schedules (see scheduleFormState).
        scheduleFormManuallyExpanded: [
            null as boolean | null,
            {
                setScheduleFormExpanded: (_, { expanded }) => expanded,
                // A create adds to the plan, so the form returns to the default that the plan
                // implies. Without this the form stays open for the rest of the mount, and the
                // "Schedule a change" button stays hidden behind it.
                createScheduledChangeSuccess: () => null,
                resetScheduleFormExpanded: () => null,
            },
        ],
        // Distinguishes the first load from refetches, so the schedule header only
        // shows a skeleton once per mount instead of on every reload after a mutation.
        scheduledChangesLoaded: [
            false,
            {
                loadScheduledChangesSuccess: () => true,
                loadScheduledChangesFailure: () => true,
            },
        ],
        schedulePayload: [
            {
                filters: { ...NEW_FLAG.filters },
                active: NEW_FLAG.active,
                variants: undefined,
                payloads: undefined,
            } as ScheduleFlagPayload,
            {
                setSchedulePayload: (state, { filters, active, variants, payloads }) => {
                    return {
                        filters: filters === null ? state.filters : filters,
                        active: active === null ? state.active : active,
                        variants: variants === null ? state.variants : variants,
                        payloads: payloads === null ? state.payloads : payloads,
                    }
                },
            },
        ],
        schedulePayloadErrors: [
            null as any,
            {
                setSchedulePayload: (state, { errors }) => {
                    return errors === null || errors === undefined ? state : errors
                },
            },
        ],
        scheduledChangeOperation: [
            ScheduledChangeOperationType.AddReleaseCondition as ScheduledChangeOperationType,
            {
                setScheduledChangeOperation: (_, { changeType }) => changeType,
            },
        ],
        isRecurring: [
            false,
            {
                setIsRecurring: (_, { isRecurring }) => isRecurring,
                // Reset when switching to AddReleaseCondition (recurring not supported for that operation)
                setScheduledChangeOperation: (state, { changeType }) =>
                    changeType === ScheduledChangeOperationType.AddReleaseCondition ? false : state,
            },
        ],
        recurrenceInterval: [
            null as RecurrenceInterval | null,
            {
                setRecurrenceInterval: (_, { interval }) => interval,
                // Reset when switching to AddReleaseCondition (recurring not supported for that operation)
                setScheduledChangeOperation: (state, { changeType }) =>
                    changeType === ScheduledChangeOperationType.AddReleaseCondition ? null : state,
            },
        ],
        cronExpression: [
            null as string | null,
            {
                setCronExpression: (_, { cronExpression }) => cronExpression,
                setScheduledChangeOperation: (state, { changeType }) =>
                    changeType === ScheduledChangeOperationType.AddReleaseCondition ? null : state,
            },
        ],
        endDate: [
            null as Dayjs | null,
            {
                setEndDate: (_, { endDate }) => endDate,
                // Reset when switching to AddReleaseCondition (recurring not supported for that operation)
                setScheduledChangeOperation: (state, { changeType }) =>
                    changeType === ScheduledChangeOperationType.AddReleaseCondition ? null : state,
            },
        ],
        // Paired schedule preset state
        schedulePreset: [
            null as PairedPresetKey | null,
            {
                setSchedulePreset: (_, { preset }) => preset,
                // Reset preset when switching operations or after successful creation
                setScheduledChangeOperation: () => null,
                createScheduledChangeSuccess: () => null,
            },
        ],
        customPairEnableCron: [
            '' as string,
            {
                setCustomPairCron: (state, { which, expression }) => (which === 'enable' ? expression : state),
                setSchedulePreset: () => '',
            },
        ],
        customPairDisableCron: [
            '' as string,
            {
                setCustomPairCron: (state, { which, expression }) => (which === 'disable' ? expression : state),
                setSchedulePreset: () => '',
            },
        ],
        // V2 form UI state
        showImplementation: [
            false,
            {
                setShowImplementation: (_, { show }) => show,
            },
        ],
        openVariants: [
            [] as string[],
            {
                setOpenVariants: (_, { openVariants }) => openVariants,
                moveVariantUp: (state, { index }) => {
                    // Remap openVariants when variants are reordered
                    return remapOpenVariantsAfterReorder(state, index, index - 1)
                },
                moveVariantDown: (state, { index }) => {
                    // Remap openVariants when variants are reordered
                    return remapOpenVariantsAfterReorder(state, index, index + 1)
                },
                reorderVariants: (state, { fromIndex, toIndex }) => {
                    // Remap openVariants when variants are reordered
                    return remapOpenVariantsAfterReorder(state, fromIndex, toIndex)
                },
            },
        ],
        payloadExpanded: [
            false,
            {
                setPayloadExpanded: (_, { expanded }) => expanded,
                loadFeatureFlagSuccess: (_, { featureFlag }) => !!featureFlag?.filters?.payloads?.['true'],
            },
        ],
        templateExpanded: [
            true,
            {
                setTemplateExpanded: (_, { expanded }) => expanded,
                // Collapse when a template is applied from URL
                applyUrlTemplate: () => false,
                // Reset to open when loading a new flag
                loadFeatureFlag: () => true,
            },
        ],
        urlTemplateApplied: [
            false,
            {
                applyUrlTemplate: () => true,
                loadFeatureFlag: () => false,
            },
        ],
        urlIntentApplied: [
            false,
            {
                applyUrlIntent: () => true,
                loadFeatureFlag: () => false,
            },
        ],
        // Unlike urlTemplateApplied/urlIntentApplied, this does not reset on loadFeatureFlag:
        // it corrects the schedule form's default exactly once, the first time the real flag
        // loads. Resetting it on every load would let a later reload (e.g. clicking Edit)
        // reapply the default and wipe a scheduled change the user is still drafting.
        scheduleDefaultsAppliedFromFlag: [
            false,
            {
                applyScheduleDefaultsFromFlag: () => true,
            },
        ],
        flagIntent: [
            null as FlagIntent | null,
            {
                setFlagIntent: (_, { intent }) => intent,
                loadFeatureFlag: () => null,
            },
        ],
    }),
    sharedListeners(({ values, actions }) => ({
        checkDependentFlagsAndConfirm: async (payload: {
            originalFlag: FeatureFlagType | null
            updatedFlag: Partial<FeatureFlagType>
            onConfirm: () => void
            requireStatusConfirmation?: boolean
            onDisableAndArchive?: () => void
        }) => {
            const {
                originalFlag,
                updatedFlag,
                onConfirm,
                requireStatusConfirmation = false,
                onDisableAndArchive,
            } = payload
            const isBeingDisabled = !!updatedFlag.id && originalFlag?.active === true && updatedFlag.active === false

            let dependentFlagsForConfirmation: DependentFlag[] = []
            if (isBeingDisabled) {
                // check whether or not this flag is depended on by other flags
                // if it is, we're going to display a warning dialog
                if (values.dependentFlagsLoading) {
                    await Promise.race([
                        new Promise<void>((resolve) => {
                            const poll = (): unknown =>
                                values.dependentFlagsLoading ? setTimeout(poll, 50) : resolve()
                            poll()
                        }),
                        new Promise<void>((resolve) => setTimeout(resolve, FLAG_DEPENDENCY_TIMEOUT_MS)),
                    ])
                }
                dependentFlagsForConfirmation = values.dependentFlags
            }

            actions.showDependentFlagsConfirmation({
                originalFlag,
                updatedFlag,
                onConfirm,
                isBeingDisabled,
                dependentFlags: dependentFlagsForConfirmation,
                requireStatusConfirmation,
                onDisableAndArchive,
            })
        },
        showDependentFlagsConfirmation: (payload: {
            originalFlag: FeatureFlagType | null
            updatedFlag: Partial<FeatureFlagType>
            onConfirm: () => void
            dependentFlags: DependentFlag[]
            isBeingDisabled?: boolean
            requireStatusConfirmation?: boolean
            onDisableAndArchive?: () => void
        }) => {
            const {
                originalFlag,
                updatedFlag,
                onConfirm,
                dependentFlags,
                isBeingDisabled = false,
                requireStatusConfirmation = false,
                onDisableAndArchive,
            } = payload

            const featureFlagConfirmationEnabled = !!values.currentTeam?.feature_flag_confirmation_enabled
            let customConfirmationMessage: string | undefined
            if (featureFlagConfirmationEnabled) {
                customConfirmationMessage = values.currentTeam?.feature_flag_confirmation_message
            }

            const shouldDisplayConfirmation = featureFlagConfirmationEnabled || dependentFlags.length > 0

            const confirmationShown = checkFeatureFlagConfirmation(
                originalFlag,
                updatedFlag as FeatureFlagType,
                shouldDisplayConfirmation,
                customConfirmationMessage,
                featureFlagConfirmationEnabled,
                onConfirm,
                dependentFlags,
                isBeingDisabled,
                requireStatusConfirmation,
                onDisableAndArchive
            )

            // If no confirmation was shown, proceed immediately
            if (!confirmationShown) {
                onConfirm()
            }
        },
    })),
    loaders(({ values, props, actions }) => ({
        featureFlag: {
            loadFeatureFlag: async () => {
                const sourceId = router.values.searchParams.sourceId

                if (props.id === 'new' && sourceId) {
                    // Used when "duplicating a feature flag". This populates the form with the source flag's data.
                    const sourceFlag = await api.featureFlags.get(sourceId)
                    // But first, remove fields that we don't want to duplicate
                    const {
                        id,
                        created_at,
                        key,
                        deleted,
                        active,
                        created_by,
                        experiment_set,
                        features,
                        surveys,
                        can_edit,
                        user_access_level,
                        status,
                        last_modified_by,
                        ...flagToKeep
                    } = sourceFlag

                    // Remove sourceId from URL
                    router.actions.replace(router.values.location.pathname)

                    const duplicatedFlag = {
                        ...NEW_FLAG,
                        ...flagToKeep,
                        key: '',
                    } as FeatureFlagType

                    return variantKeyToIndexFeatureFlagPayloads(duplicatedFlag)
                }

                if (props.id && props.id !== 'new' && props.id !== 'link') {
                    try {
                        // Get the flag first to check if it has an experiment
                        const retrievedFlag: FeatureFlagType = await api.featureFlags.get(props.id)

                        // If there's an experiment, load it concurrently before returning to prevent UI flicker
                        if (retrievedFlag.experiment_set && retrievedFlag.experiment_set.length > 0) {
                            try {
                                const experiment = await api.experiments.get(retrievedFlag.experiment_set[0])
                                actions.loadExperimentSuccess(experiment)
                            } catch (error) {
                                // If experiment load fails, don't block the flag from loading
                                console.warn('Failed to load experiment:', error)
                            }
                        }

                        return variantKeyToIndexFeatureFlagPayloads(retrievedFlag)
                    } catch (e: any) {
                        if (isAccessDeniedError(e)) {
                            actions.setAccessDeniedToFeatureFlag()
                        } else {
                            actions.setFeatureFlagMissing()
                        }
                        throw e
                    }
                }
                // For new flags, load default evaluation contexts and set default tags
                if (props.id === 'new') {
                    const flagType = router.values.searchParams.type as FlagType | undefined

                    // Only load and apply default evaluation contexts if BOTH conditions are met:
                    // 1. The feature flag is enabled globally
                    // 2. The team has enabled default evaluation contexts
                    const isFeatureEnabled = values.enabledFeatures[FEATURE_FLAGS.DEFAULT_EVALUATION_ENVIRONMENTS]
                    const isTeamEnabled = values.currentTeam?.default_evaluation_contexts_enabled

                    let baseFlagConfig: typeof NEW_FLAG = {
                        ...NEW_FLAG,
                        ensure_experience_continuity: values.currentTeam?.flags_persistence_default ?? false,
                    }

                    if (flagType !== 'remote_config') {
                        // Use cached value if already loaded; fetch directly if not yet available
                        // to avoid a race where defaultReleaseConditionsLogic's async load hasn't
                        // completed before loadFeatureFlag reads values.defaultReleaseConditions.
                        const conditionsConfig = await resolveDefaultReleaseConditions(
                            values.defaultReleaseConditions,
                            values.currentTeam?.id
                        )
                        if (conditionsConfig?.enabled && conditionsConfig.default_groups?.length > 0) {
                            baseFlagConfig = {
                                ...baseFlagConfig,
                                filters: {
                                    ...baseFlagConfig.filters,
                                    groups: conditionsConfig.default_groups,
                                    aggregation_group_type_index: uniformAggregationGroupTypeIndex(
                                        conditionsConfig.default_groups
                                    ),
                                },
                            }
                        }
                    }

                    // Apply type-specific configuration
                    if (flagType === 'multivariate') {
                        baseFlagConfig = {
                            ...baseFlagConfig,
                            filters: {
                                ...baseFlagConfig.filters,
                                multivariate: {
                                    variants: [
                                        { key: 'control', name: '', rollout_percentage: 50 },
                                        { key: 'test', name: '', rollout_percentage: 50 },
                                    ],
                                },
                            },
                        }
                    } else if (flagType === 'remote_config') {
                        baseFlagConfig = {
                            ...baseFlagConfig,
                            is_remote_configuration: true,
                            filters: {
                                ...baseFlagConfig.filters,
                                groups: [{ properties: [], rollout_percentage: 100, variant: null }],
                            },
                        }
                    }

                    if (isFeatureEnabled && isTeamEnabled) {
                        try {
                            actions.loadDefaultEvaluationContexts()
                        } catch (error) {
                            // If loading default evaluation contexts fails, continue with empty tags
                            console.warn('Failed to load default evaluation contexts:', error)
                        }
                        const defaultEnvs = values.defaultEvaluationContexts
                        const defaultContexts = defaultEnvs?.default_evaluation_contexts || []

                        return {
                            ...baseFlagConfig,
                            evaluation_contexts: defaultContexts.map((ctx) => ctx.name),
                        }
                    }

                    // If either condition is false, return flag without default tags
                    return baseFlagConfig
                }

                return {
                    ...NEW_FLAG,
                    ensure_experience_continuity: values.currentTeam?.flags_persistence_default ?? false,
                }
            },
            saveFeatureFlag: async (updatedFlag: Partial<FeatureFlagType>) => {
                // Destructure all fields we want to exclude or handle specially
                const flag = cleanFlag(updatedFlag)
                const preparedFlag = indexToVariantKeyFeatureFlagPayloads(flag)

                try {
                    let savedFlag: FeatureFlagType
                    if (!updatedFlag.id) {
                        // Creating a new flag
                        savedFlag = await api.create(
                            `api/projects/${values.currentProjectId}/feature_flags`,
                            preparedFlag
                        )
                        actions.addProductIntent({
                            product_type: ProductKey.FEATURE_FLAGS,
                            intent_context: ProductIntentContext.FEATURE_FLAG_CREATED,
                        })
                    } else {
                        // Updating an existing flag - include version in preparedFlag
                        const cachedFlag = featureFlagsLogic
                            .findMounted()
                            ?.values.featureFlags.results.find((flag) => flag.id === props.id)

                        // If we've got a cached flag and the filters have changed, we've updated the release conditions
                        if (cachedFlag && !objectsEqual(cachedFlag?.filters, values.featureFlag.filters)) {
                            globalSetupLogic
                                .findMounted()
                                ?.actions.markTaskAsCompleted(SetupTaskId.UpdateFeatureFlagReleaseConditions)
                        }

                        savedFlag = await api.update(
                            `api/projects/${values.currentProjectId}/feature_flags/${updatedFlag.id}`,
                            {
                                ...preparedFlag,
                                original_flag: values.originalFeatureFlag,
                            }
                        )
                    }
                    savedFlag.id && refreshTreeItem('feature_flag', String(savedFlag.id))
                    return variantKeyToIndexFeatureFlagPayloads(savedFlag)
                } catch (error: any) {
                    if (error.code === 'behavioral_cohort_found' || error.code === 'cohort_does_not_exist') {
                        eventUsageLogic.actions.reportFailedToCreateFeatureFlagWithCohort(error.code, error.detail)
                    } else if (isAccessDeniedError(error)) {
                        // Mirror the load path's access-denied handling instead of the generic
                        // "Save feature flag failed: ..." toast. The global loaders handler
                        // suppresses its toast for permission_denied, so this is the only message.
                        lemonToast.error(
                            error.detail ||
                                "You don't have permission to edit this feature flag. Contact your administrator to request editing rights."
                        )
                    }
                    // Duplicate-key (`unique`/`key`) is toasted in the saveFeatureFlagFailure listener so
                    // the throw runs immediately and the form doesn't stay skeletoned during the lookup.
                    throw error
                }
            },
            saveSidebarExperimentFeatureFlag: async (updatedFlag: Partial<FeatureFlagType>) => {
                const flag = cleanFlag(updatedFlag)

                const preparedFlag = indexToVariantKeyFeatureFlagPayloads(flag)

                try {
                    let savedFlag: FeatureFlagType
                    if (!updatedFlag.id) {
                        // Creating a new flag
                        savedFlag = await api.create(
                            `api/projects/${values.currentProjectId}/feature_flags`,
                            preparedFlag
                        )
                    } else {
                        savedFlag = await api.update(
                            `api/projects/${values.currentProjectId}/feature_flags/${updatedFlag.id}`,
                            {
                                ...preparedFlag,
                                original_flag: values.originalFeatureFlag,
                            }
                        )
                    }
                    savedFlag.id && refreshTreeItem('feature_flag', String(savedFlag.id))

                    return variantKeyToIndexFeatureFlagPayloads(savedFlag)
                } catch (error: any) {
                    if (error.code === 'behavioral_cohort_found' || error.code === 'cohort_does_not_exist') {
                        eventUsageLogic.actions.reportFailedToCreateFeatureFlagWithCohort(error.code, error.detail)
                    }
                    throw error
                }
            },
        },
        // Separate loader for toggling active state - has its own loading state so it doesn't show skeleton
        featureFlagActiveUpdate: [
            null as FeatureFlagType | null,
            {
                updateFeatureFlagActive: async (active: boolean) => {
                    if (!values.featureFlag.id) {
                        throw new Error('Cannot toggle active state of unsaved flag')
                    }
                    const savedFlag = await api.update(
                        `api/projects/${values.currentProjectId}/feature_flags/${values.featureFlag.id}`,
                        { active }
                    )
                    savedFlag.id && refreshTreeItem('feature_flag', String(savedFlag.id))
                    return variantKeyToIndexFeatureFlagPayloads(savedFlag)
                },
                // Shares the featureFlagActiveUpdate loader key (and its loading/success state)
                updateFeatureFlagArchived: async ({
                    archived,
                    via,
                }: {
                    archived: boolean
                    /** Telemetry source; only meaningful (and only captured) when archiving, not unarchiving. */
                    via?: FeatureFlagArchivedSource
                }) => {
                    if (!values.featureFlag.id) {
                        throw new Error('Cannot archive an unsaved flag')
                    }
                    // Archiving also disables the flag — the backend rejects archived+enabled flags
                    const savedFlag = await api.update(
                        `api/projects/${values.currentProjectId}/feature_flags/${values.featureFlag.id}`,
                        archived ? { archived: true, active: false } : { archived: false }
                    )
                    savedFlag.id && refreshTreeItem('feature_flag', String(savedFlag.id))
                    if (archived && via) {
                        reportFeatureFlagArchived(via)
                    }
                    return variantKeyToIndexFeatureFlagPayloads(savedFlag)
                },
            },
        ],
        // Silent background refresh used when the overview paints instantly from the list
        // cache on mount. Has its own loading key so it never triggers the page skeleton,
        // while reconciling the flag (notably `active`) with the server — otherwise a stale
        // cached `active` can make the toggle and its confirmation dialog contradict the
        // flag's real state.
        featureFlagRefresh: [
            null as FeatureFlagType | null,
            {
                refreshFeatureFlag: async () => {
                    if (!props.id || props.id === 'new' || props.id === 'link') {
                        return null
                    }
                    try {
                        const retrievedFlag: FeatureFlagType = await api.featureFlags.get(props.id)
                        return variantKeyToIndexFeatureFlagPayloads(retrievedFlag)
                    } catch {
                        // Swallow errors — this is a silent background reconciliation, so a
                        // transient failure shouldn't surface a toast or get reported.
                        return null
                    }
                },
            },
        ],
        relatedInsights: [
            [] as QueryBasedInsightModel[],
            {
                loadRelatedInsights: async () => {
                    if (props.id && props.id !== 'new' && values.featureFlag.key) {
                        const response = await api.get<PaginatedResponse<InsightModel>>(
                            `api/environments/${values.currentProjectId}/insights/?feature_flag=${values.featureFlag.key}&order=-created_at`
                        )
                        return response.results.map((legacyInsight) => getQueryBasedInsightModel(legacyInsight))
                    }
                    return []
                },
            },
        ],
        // used to generate a new early access feature
        // but all subsequent operations after generation should occur via the earlyAccessFeatureLogic
        newEarlyAccessFeature: [
            null as EarlyAccessFeatureType | null,
            {
                createEarlyAccessFeature: async () => {
                    const newEarlyAccessFeature = {
                        ...NEW_EARLY_ACCESS_FEATURE,
                        name: `Early access: ${values.featureFlag.key}`,
                        feature_flag_id: values.featureFlag.id,
                    }
                    return await api.earlyAccessFeatures.create(newEarlyAccessFeature as NewEarlyAccessFeatureType)
                },
            },
        ],
        // used to generate a new survey
        // but all subsequent operations after generation should occur via the surveyLogic
        newSurvey: [
            null as Survey | null,
            {
                createSurvey: async () => {
                    const newSurvey = {
                        ...NEW_SURVEY,
                        name: `Survey: ${values.featureFlag.key}`,
                        linked_flag_id: values.featureFlag.id,
                        questions: [
                            {
                                type: SurveyQuestionType.Open,
                                question: `What do you think of ${values.featureFlag.key}?`,
                            },
                        ],
                    }
                    const response = await api.surveys.create(newSurvey as NewSurvey)
                    actions.addProductIntent({
                        product_type: ProductKey.SURVEYS,
                        intent_context: ProductIntentContext.SURVEY_CREATED,
                        metadata: {
                            survey_id: response.id,
                            source: SURVEY_CREATED_SOURCE.FEATURE_FLAGS,
                        },
                    })
                    return response
                },
            },
        ],
        newCohort: [
            null as CohortType | null,
            {
                createStaticCohort: async () => {
                    if (props.id && props.id !== 'new' && props.id !== 'link') {
                        return (await api.featureFlags.createStaticCohort(props.id)).cohort
                    }
                    return null
                },
            },
        ],
        projectsWithCurrentFlag: {
            __default: [] as OrganizationFeatureFlag[],
            loadProjectsWithCurrentFlag: async () => {
                const orgId = values.currentOrganizationId
                const flagKey = values.featureFlag.key

                const organizationFeatureFlags = await api.organizationFeatureFlags.get(orgId, flagKey)
                const teamIdsInCurrentProject =
                    values.currentOrganization?.teams
                        .filter((t) => t.project_id === values.currentProjectId)
                        .map((t) => t.id) || []

                // Put current project first. We need teamIdsInCurrentProject here, because as of Feb 2025,
                // FeatureFlag only has `team_id`, but not `project_id`
                return organizationFeatureFlags.sort((a, b) => {
                    if (a.team_id !== null && teamIdsInCurrentProject.includes(a.team_id)) {
                        return -1
                    }
                    if (b.team_id !== null && teamIdsInCurrentProject.includes(b.team_id)) {
                        return 1
                    }
                    return 0
                })
            },
        },
        featureFlagCopy: {
            copyFlag: async () => {
                const orgId = values.currentOrganizationId
                const featureFlagKey = values.featureFlag.key
                const { copyDependencies, copyDestinationProject, currentProjectId, copySchedule, disableCopiedFlag } =
                    values

                if (orgId && currentProjectId && copyDestinationProject) {
                    return await featureFlagsCopyFlagsCreate(String(orgId), {
                        feature_flag_key: featureFlagKey,
                        from_project: currentProjectId,
                        target_project_ids: [copyDestinationProject],
                        copy_schedule: copySchedule,
                        disable_copied_flag: disableCopiedFlag,
                        copy_dependencies: copyDependencies,
                    })
                }
            },
        },
        scheduledChanges: {
            __default: [] as ScheduledChangeType[],
            loadScheduledChanges: async () => {
                const { currentProjectId } = values
                if (currentProjectId) {
                    const response = await api.featureFlags.getScheduledChanges(currentProjectId, values.featureFlag.id)
                    return response.results || []
                }
            },
        },
        scheduledChange: {
            __default: {} as ScheduledChangeType,
            createScheduledChange: async () => {
                const { scheduledChangeOperation, scheduleDateMarker, currentProjectId, schedulePayload } = values

                const fields: Record<ScheduledChangeOperationType, keyof ScheduleFlagPayload | 'variants'> = {
                    [ScheduledChangeOperationType.UpdateStatus]: 'active',
                    [ScheduledChangeOperationType.AddReleaseCondition]: 'filters',
                    [ScheduledChangeOperationType.UpdateVariants]: 'variants',
                }

                if (currentProjectId && scheduledChangeOperation) {
                    let payloadValue: any
                    if (scheduledChangeOperation === ScheduledChangeOperationType.UpdateVariants) {
                        const preparedPayload = convertIndexBasedPayloadsToVariantKeys(
                            schedulePayload.variants,
                            schedulePayload.payloads
                        )
                        payloadValue = {
                            variants: schedulePayload.variants || [],
                            payloads: preparedPayload || {},
                        }
                    } else {
                        payloadValue = schedulePayload[fields[scheduledChangeOperation]]
                    }

                    const timezone = values.currentTeam?.timezone || 'UTC'
                    const data = {
                        record_id: values.featureFlag.id,
                        model_name: 'FeatureFlag',
                        payload: {
                            operation: scheduledChangeOperation,
                            value: payloadValue,
                        },
                        // The calendar emits a browser-local Dayjs; reinterpret the wall clock
                        // in the project's timezone so everyone sees the same scheduled moment.
                        scheduled_at: scheduleDateToProjectTzISO(scheduleDateMarker, timezone),
                        is_recurring: values.isRecurring,
                        recurrence_interval: values.recurrenceInterval,
                        cron_expression: values.cronExpression,
                        // Use end-of-day in project timezone to ensure consistent behavior
                        // across all users in the project
                        end_date: values.endDate ? values.endDate.tz(timezone, true).endOf('day').toISOString() : null,
                    }

                    return await api.featureFlags.createScheduledChange(currentProjectId, data)
                }
            },
            deleteScheduledChange: async (scheduledChangeId) => {
                const { currentProjectId } = values
                if (currentProjectId) {
                    return await api.featureFlags.deleteScheduledChange(currentProjectId, scheduledChangeId)
                }
            },
        },
        flagStatus: [
            null as FeatureFlagStatusResponse | null,
            {
                loadFeatureFlagStatus: () => {
                    const { currentProjectId } = values
                    if (currentProjectId && props.id && props.id !== 'new' && props.id !== 'link') {
                        return api.featureFlags.getStatus(currentProjectId, props.id)
                    }
                    return null
                },
            },
        ],
        experiment: {
            loadExperiment: async () => {
                if (values.featureFlag.experiment_set && values.featureFlag.experiment_set.length > 0) {
                    return await api.experiments.get(values.featureFlag.experiment_set[0])
                }
                return null
            },
        },
        dependentFlags: [
            [] as DependentFlag[],
            {
                loadDependentFlags: async () => {
                    const { currentProjectId } = values
                    if (currentProjectId && props.id && props.id !== 'new' && props.id !== 'link') {
                        return await api.get(
                            `api/projects/${currentProjectId}/feature_flags/${props.id}/dependent_flags/`
                        )
                    }
                    return []
                },
            },
        ],
    })),
    // Extends the projectsWithCurrentFlag loader's reducer. Must stay after loaders(); do NOT merge
    // into the reducers() block above — it runs before the loader defines projectsWithCurrentFlag,
    // so the extension would be silently dropped.
    reducers({
        projectsWithCurrentFlag: {
            projectFlagActiveUpdated: (state, { teamId, flagId, active }) =>
                state.map((p) => (p.team_id === teamId && p.flag_id === flagId ? { ...p, active } : p)),
        },
    }),
    listeners(({ actions, values, props, sharedListeners }) => ({
        loadCopyDependencyRequirements: async (_, breakpoint): Promise<void> => {
            const { copyDestinationProject, currentOrganizationId, currentProjectId, featureFlag } = values

            if (
                !currentOrganizationId ||
                !currentProjectId ||
                !copyDestinationProject ||
                !featureFlag.key ||
                !hasDirectFlagDependency(featureFlag)
            ) {
                actions.loadCopyDependencyRequirementsSuccess(null)
                return
            }

            const requestedFeatureFlagKey = featureFlag.key
            const hasRequestContextChanged = (): boolean =>
                values.currentOrganizationId !== currentOrganizationId ||
                values.currentProjectId !== currentProjectId ||
                values.copyDestinationProject !== copyDestinationProject ||
                values.featureFlag.key !== requestedFeatureFlagKey

            try {
                await breakpoint(300)
                if (hasRequestContextChanged()) {
                    actions.loadCopyDependencyRequirementsSuccess(values.copyDependencyRequirements)
                    return
                }

                const copyDependencyRequirements = await featureFlagsCopyFlagsDependencyRequirementsCreate(
                    String(currentOrganizationId),
                    {
                        feature_flag_key: requestedFeatureFlagKey,
                        from_project: currentProjectId,
                        target_project_ids: [copyDestinationProject],
                    }
                )
                await breakpoint()
                actions.loadCopyDependencyRequirementsSuccess(
                    hasRequestContextChanged() ? values.copyDependencyRequirements : copyDependencyRequirements
                )
            } catch (error) {
                await breakpoint()
                if (hasRequestContextChanged()) {
                    actions.loadCopyDependencyRequirementsSuccess(values.copyDependencyRequirements)
                    return
                }

                actions.loadCopyDependencyRequirementsFailure(
                    error instanceof Error ? error.message : String(error),
                    error
                )
            }
        },
        setCopyDestinationProject: () => {
            actions.loadCopyDependencyRequirements()
        },
        setFeatureFlag: () => {
            if (values.copyDestinationProject) {
                actions.loadCopyDependencyRequirements()
            }
        },
        setCronExpression: ({ cronExpression }) => {
            if (!cronExpression) {
                return
            }
            // Only compute next run for valid 5-field cron expressions
            const fields = cronExpression.trim().split(/\s+/)
            if (fields.length !== 5) {
                return
            }
            try {
                const timezone = values.currentTeam?.timezone || 'UTC'
                // scheduleDateMarker is a browser-local Dayjs whose wall clock matches the
                // project timezone. Reinterpret it in the project timezone before passing to
                // cron-parser so the cron fields (e.g. "0 9") are evaluated in the project's
                // timezone rather than the browser's.
                const baseDate = values.scheduleDateMarker?.tz(timezone, true).toDate() ?? new Date()
                const interval = CronExpressionParser.parse(cronExpression, {
                    currentDate: baseDate,
                    tz: timezone,
                })
                const nextDate = interval.next().toDate()
                actions.setScheduleDateMarker(scheduleDateFromStoredISO(nextDate.toISOString(), timezone))
            } catch {
                // Invalid expression — don't update the date picker
            }
        },
        setRepeatsValue: ({ value }) => {
            if (value === 'none') {
                actions.setIsRecurring(false)
                actions.setRecurrenceInterval(null)
                actions.setCronExpression(null)
                actions.setEndDate(null)
            } else if (value === 'cron') {
                actions.setIsRecurring(true)
                actions.setRecurrenceInterval(null)
                actions.setCronExpression(values.cronExpression ?? '')
            } else {
                actions.setIsRecurring(true)
                actions.setRecurrenceInterval(value)
                actions.setCronExpression(null)
            }
        },
        setSchedulePreset: ({ preset: rawPreset }) => {
            const preset = rawPreset as PairedPresetKey | null
            if (!preset) {
                return
            }
            // Selecting any preset implies recurring cron mode
            actions.setIsRecurring(true)
            actions.setRecurrenceInterval(null)
            if (preset !== 'custom_pair') {
                const def = PAIRED_PRESETS[preset]
                // Snap the date picker to the next enable-cron occurrence
                actions.setCronExpression(def.enableCron)
            }
        },
        createPairedSchedule: async () => {
            const resetScheduleForm = (): void => {
                actions.resetScheduleFormExpanded()
                actions.setSchedulePreset(null)
                actions.setScheduleDateMarker(null)
                actions.setIsRecurring(false)
                actions.setRecurrenceInterval(null)
                actions.setCronExpression(null)
                actions.setEndDate(null)
                actions.loadScheduledChanges()
            }

            const { customPairEnableCron, customPairDisableCron, currentProjectId } = values
            const schedulePreset = values.schedulePreset as PairedPresetKey | null
            if (!currentProjectId || !schedulePreset) {
                return
            }

            let enableCron: string
            let disableCron: string

            if (schedulePreset === 'custom_pair') {
                enableCron = (customPairEnableCron as string).trim()
                disableCron = (customPairDisableCron as string).trim()
            } else {
                const def = PAIRED_PRESETS[schedulePreset]
                enableCron = def.enableCron
                disableCron = def.disableCron
            }

            const timezone = values.currentTeam?.timezone || 'UTC'
            const basePayload = {
                record_id: values.featureFlag.id,
                model_name: 'FeatureFlag',
                is_recurring: true,
                recurrence_interval: null,
                end_date: values.endDate ? values.endDate.tz(timezone, true).endOf('day').toISOString() : null,
            }

            // Compute scheduled_at from the enable cron's next run, evaluated in project timezone.
            let enableScheduledAt: string
            try {
                const interval = CronExpressionParser.parse(enableCron, { currentDate: new Date(), tz: timezone })
                enableScheduledAt = interval.next().toDate().toISOString()
            } catch {
                lemonToast.error('Invalid enable cron expression')
                return
            }

            let disableScheduledAt: string
            try {
                const interval = CronExpressionParser.parse(disableCron, { currentDate: new Date(), tz: timezone })
                disableScheduledAt = interval.next().toDate().toISOString()
            } catch {
                lemonToast.error('Invalid disable cron expression')
                return
            }

            // Create the enable schedule first
            let enableSchedule: ScheduledChangeType
            try {
                enableSchedule = await api.featureFlags.createScheduledChange(currentProjectId, {
                    ...basePayload,
                    payload: { operation: ScheduledChangeOperationType.UpdateStatus, value: true },
                    cron_expression: enableCron,
                    scheduled_at: enableScheduledAt,
                })
            } catch {
                lemonToast.error('Failed to create the enable schedule')
                return
            }

            // Create the disable schedule
            let disableSchedule: ScheduledChangeType
            try {
                disableSchedule = await api.featureFlags.createScheduledChange(currentProjectId, {
                    ...basePayload,
                    payload: { operation: ScheduledChangeOperationType.UpdateStatus, value: false },
                    cron_expression: disableCron,
                    scheduled_at: disableScheduledAt,
                })
            } catch {
                lemonToast.warning(
                    'The enable schedule was created, but the disable schedule failed. ' +
                        'You may want to create it manually or delete the enable schedule.'
                )
                resetScheduleForm()
                return
            }

            // Both succeeded
            const pairIsPendingApproval = [enableSchedule, disableSchedule].some(
                (schedule) => schedule?.change_request?.state === ScheduledChangeRequestState.Pending
            )
            if (pairIsPendingApproval) {
                lemonToast.success(
                    'Paired schedules created - pending approval. Schedules that are not approved before their scheduled time will be skipped.'
                )
            } else {
                lemonToast.success('Paired schedules created')
            }
            resetScheduleForm()
            eventUsageLogic.actions.reportFeatureFlagScheduleSuccess()
        },
        showDependentFlagsConfirmation: sharedListeners.showDependentFlagsConfirmation,
        enrichUsageDashboard: async (_, breakpoint) => {
            if (props.id) {
                await breakpoint(1000) // in ms
                await api.create(
                    `api/projects/${values.currentProjectId}/feature_flags/${props.id}/enrich_usage_dashboard`
                )
            }
        },
        submitFeatureFlagFailure: async () => {
            // Collapsed LemonCollapse panels don't render their children, so any inline error
            // and its `.Field--error` scroll target won't exist in the DOM until the panel is open.
            const formErrors = values.featureFlagErrors as DeepPartialMap<FeatureFlagType, ValidationErrorType>
            const filtersErrors = formErrors?.filters as any
            const variantErrorsList = filtersErrors?.multivariate?.variants as
                | Array<{ key?: string; rollout_percentage?: string } | undefined>
                | undefined
            const variantKeysWithErrors =
                variantErrorsList
                    ?.map((err, index) => (err?.key || err?.rollout_percentage ? `variant-${index}` : null))
                    .filter((key): key is string => key !== null) ?? []
            if (variantKeysWithErrors.length) {
                actions.setOpenVariants(Array.from(new Set([...values.openVariants, ...variantKeysWithErrors])))
            }
            if (filtersErrors?.payloads?.true && !values.payloadExpanded) {
                actions.setPayloadExpanded(true)
            }
            // Yield so React flushes the expand-actions re-render before scrollToFormError schedules
            // its requestAnimationFrame callback — otherwise on browsers/scheduler combinations where
            // the render lands after RAF, `.Field--error` isn't in the DOM yet and the fallback toast
            // fires instead of scrolling to the error.
            await Promise.resolve()
            scrollToFormError({
                fallbackErrorMessage: 'This flag has validation errors. Please review the highlighted fields above.',
            })
        },
        updateFeatureFlagActiveFailure: ({ errorObject }) => {
            if (values.featureFlag.id && handleApprovalRequired(errorObject, 'feature_flag', values.featureFlag.id)) {
                return
            }

            // For non-approval errors, let the global error handler show the toast to avoid duplicates
        },
        saveFeatureFlagSuccess: ({ featureFlag }) => {
            lemonToast.success('Feature flag saved')
            actions.setFeatureFlag(featureFlag)
            // Whole flag just persisted — the baseline is now the saved state, so the form reads clean.
            actions.setOriginalFeatureFlag(toFeatureFlagBaseline(featureFlag))
            actions.updateFlag(featureFlag)
            if (featureFlag.id && isOnFeatureFlagPage(props.id)) {
                router.actions.replace(urls.featureFlag(featureFlag.id))
            }
            actions.editFeatureFlag(false)

            const isCreate = props.id === 'new'
            const rolloutPercent = featureFlag.filters?.groups?.[0]?.rollout_percentage ?? null
            const flagKey = featureFlag.key || featureFlag.name || 'this-flag'
            const derivedPrompt = isCreate
                ? rolloutPercent != null
                    ? `Create a feature flag called ${flagKey} rolled out to ${rolloutPercent}% of users`
                    : `Create a feature flag called ${flagKey}`
                : rolloutPercent != null
                  ? `Bump rollout for ${flagKey} to ${rolloutPercent}%`
                  : `Update the ${flagKey} flag`
            tryShowMCPHint(isCreate ? 'feature_flags.create' : 'feature_flags.update', { derivedPrompt })

            // Collect all completed setup tasks
            const completedTasks: SetupTaskId[] = [SetupTaskId.CreateFeatureFlag]

            if (featureFlag.filters?.payloads && Object.keys(featureFlag.filters.payloads).length > 0) {
                completedTasks.push(SetupTaskId.SetUpFlagPayloads)
            }

            if (featureFlag.filters?.multivariate) {
                completedTasks.push(SetupTaskId.CreateMultivariateFlag)
            }

            if (featureFlag.evaluation_runtime && featureFlag.evaluation_runtime !== FeatureFlagEvaluationRuntime.ALL) {
                completedTasks.push(SetupTaskId.SetUpFlagEvaluationRuntimes)
            }

            // Set all completed tasks at once to avoid conflicts
            globalSetupLogic.findMounted()?.actions.markTaskAsCompleted(completedTasks)
        },
        saveFeatureFlagFailure: async ({ errorObject }) => {
            if (values.featureFlag.id && handleApprovalRequired(errorObject, 'feature_flag', values.featureFlag.id)) {
                if (isOnFeatureFlagPage(props.id)) {
                    // Redirect to detail page so user can see the CR banner
                    router.actions.replace(urls.featureFlag(values.featureFlag.id))
                    actions.editFeatureFlag(false)
                }
                return
            }

            if (errorObject?.code !== 'unique' || errorObject?.attr !== 'key') {
                return
            }
            const message = `Save feature flag failed: ${errorObject.detail}`
            const key = values.featureFlag.key
            if (!key) {
                lemonToast.error(message)
                return
            }
            // The backend rejects on an exact key match, so pick the exact match out of the
            // case-insensitive list rather than trusting its newest-first ordering.
            const existing = await featureFlagsList(String(values.currentProjectId), { key }).catch(() => null)
            const existingFlagId = existing?.results?.find((flag) => flag.key === key)?.id ?? null
            if (existingFlagId) {
                lemonToast.error(message, {
                    button: {
                        label: 'View existing flag',
                        action: () => {
                            window.open(urls.featureFlag(existingFlagId), '_blank')
                        },
                    },
                })
            } else {
                lemonToast.error(message)
            }
        },
        updateFeatureFlagActiveSuccess: ({ featureFlagActiveUpdate }) => {
            if (featureFlagActiveUpdate) {
                lemonToast.success(`Feature flag ${featureFlagActiveUpdate.active ? 'enabled' : 'disabled'}`)
                // Only active/version were persisted, so fold just those onto the working copy and
                // the baseline. Taking the whole server flag would drop any in-progress edit and
                // re-baseline over it, leaving the guard clean.
                const persisted = { active: featureFlagActiveUpdate.active, version: featureFlagActiveUpdate.version }
                actions.setFeatureFlag({ ...values.featureFlag, ...persisted })
                if (values.originalFeatureFlag) {
                    actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, ...persisted })
                } else {
                    actions.setOriginalFeatureFlag(toFeatureFlagBaseline(featureFlagActiveUpdate))
                }
                actions.updateFlag(featureFlagActiveUpdate)
            }
        },
        toggleProjectFlagActive: async ({ teamId, flagId, active }) => {
            const updatedFlag = await updateFlagActiveInProject({ teamId, flagId, active })
            if (!updatedFlag) {
                actions.projectFlagActiveUpdateFailed(teamId, flagId)
                return
            }
            const newActive = updatedFlag.active ?? active
            actions.projectFlagActiveUpdated(teamId, flagId, newActive)
            // Keep the flag page and the flags list in sync when the toggled row is this page's flag.
            // Flag ids are globally unique, so the id match alone identifies the page's flag even
            // when it lives in a sibling environment of the current project.
            if (flagId === values.featureFlag.id) {
                const syncedFlag = {
                    ...values.featureFlag,
                    active: newActive,
                    version: updatedFlag.version ?? values.featureFlag.version,
                }
                actions.setFeatureFlag(syncedFlag)
                // Only active/version were persisted — fold them onto the baseline rather than the
                // working copy, so any in-progress edits stay dirty instead of being swallowed.
                if (values.originalFeatureFlag) {
                    actions.setOriginalFeatureFlag({
                        ...values.originalFeatureFlag,
                        active: newActive,
                        version: syncedFlag.version,
                    })
                }
                actions.updateFlag(syncedFlag)
                refreshTreeItem('feature_flag', String(flagId))
            }
        },
        refreshFeatureFlagSuccess: ({ featureFlagRefresh }) => {
            // Reconcile the cache-painted flag with the freshly fetched server state, and keep
            // the list cache in sync so the two views agree.
            if (featureFlagRefresh) {
                if (values.originalFeatureFlag) {
                    // This refresh exists to correct a stale cached `active`, and it lands while the
                    // page is already interactive (its own loader key means no skeleton). Replacing
                    // the whole flag here would discard an edit made during the request and
                    // re-baseline over it, so the guard would read clean and lose it silently.
                    const persisted = {
                        active: featureFlagRefresh.active,
                        archived: featureFlagRefresh.archived,
                        version: featureFlagRefresh.version,
                    }
                    actions.setFeatureFlag({ ...values.featureFlag, ...persisted })
                    actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, ...persisted })
                } else {
                    actions.setFeatureFlag(featureFlagRefresh)
                    actions.setOriginalFeatureFlag(toFeatureFlagBaseline(featureFlagRefresh))
                }
                actions.updateFlag(featureFlagRefresh)
            }
        },
        updateFeatureFlagArchivedSuccess: ({ featureFlagActiveUpdate }) => {
            if (featureFlagActiveUpdate) {
                lemonToast.success(`Feature flag ${featureFlagActiveUpdate.archived ? 'archived' : 'unarchived'}`)
                // Archiving also disables the flag, so archived/active/version are the persisted
                // fields. Fold only those, for the same reason as the active toggle above.
                const persisted = {
                    archived: featureFlagActiveUpdate.archived,
                    active: featureFlagActiveUpdate.active,
                    version: featureFlagActiveUpdate.version,
                }
                actions.setFeatureFlag({ ...values.featureFlag, ...persisted })
                if (values.originalFeatureFlag) {
                    actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, ...persisted })
                } else {
                    actions.setOriginalFeatureFlag(toFeatureFlagBaseline(featureFlagActiveUpdate))
                }
                actions.updateFlag(featureFlagActiveUpdate)
            }
        },
        updateFeatureFlagArchivedFailure: ({ errorObject }) => {
            // Archiving an enabled flag also disables it, which can trip the approval gate (409).
            // Surface the change-request flow instead of silently doing nothing.
            if (values.featureFlag.id && handleApprovalRequired(errorObject, 'feature_flag', values.featureFlag.id)) {
                return
            }
            // For non-approval errors, let the global error handler show the toast to avoid duplicates
        },
        saveSidebarExperimentFeatureFlagSuccess: ({ featureFlag }) => {
            lemonToast.success('Release conditions updated')
            actions.updateFlag(featureFlag)
            actions.editFeatureFlag(false)
            actions.closeSidePanel()

            const currentPath = router.values.currentLocation.pathname
            const experimentId = currentPath.split('/').pop()

            if (experimentId) {
                eventUsageLogic.actions.reportExperimentReleaseConditionsUpdated(parseInt(experimentId))
                experimentLogic({ experimentId: parseInt(experimentId) }).actions.loadExperiment()
            }
        },
        deleteFeatureFlag: async ({ featureFlag }) => {
            await deleteWithUndo({
                endpoint: `projects/${values.currentProjectId}/feature_flags`,
                object: { name: featureFlag.key, id: featureFlag.id },
                callback: (undo) => {
                    featureFlag.id && actions.deleteFlag(featureFlag.id)
                    if (undo) {
                        refreshTreeItem('feature_flag', String(featureFlag.id))
                    } else {
                        deleteFromTree('feature_flag', String(featureFlag.id))
                    }
                    // Load latest change so a backwards navigation shows the flag as deleted
                    actions.loadFeatureFlag()
                    router.actions.push(urls.featureFlags())
                },
            })
        },
        restoreFeatureFlag: async ({ featureFlag }) => {
            await deleteWithUndo({
                endpoint: `projects/${values.currentProjectId}/feature_flags`,
                object: { name: featureFlag.key, id: featureFlag.id },
                undo: true,
                callback: (undo) => {
                    if (undo) {
                        deleteFromTree('feature_flag', String(featureFlag.id))
                    } else {
                        refreshTreeItem('feature_flag', String(featureFlag.id))
                    }
                    actions.loadFeatureFlag()
                },
            })
        },
        setMultivariateEnabled: async ({ enabled }) => {
            if (enabled) {
                actions.setMultivariateOptions(EMPTY_MULTIVARIATE_OPTIONS)
            } else {
                actions.setMultivariateOptions(null)
            }
        },
        loadFeatureFlagSuccess: async ({ featureFlag }) => {
            // A ?tab=schedule deep link selects the tab before this load finishes, so the
            // schedule form's default was computed against the NEW_FLAG placeholder. Correct
            // it once against the loaded flag; only on the first load, so a later reload (e.g.
            // clicking Edit) does not overwrite a scheduled change the user is still drafting.
            if (
                featureFlag &&
                values.selectedTab === FeatureFlagsTab.SCHEDULE &&
                !values.scheduleDefaultsAppliedFromFlag
            ) {
                actions.setSchedulePayload(NEW_FLAG.filters, !featureFlag.active, {}, null, null)
                // An unsaved flag has no id to scope the request to, and the scheduled-changes
                // endpoint drops an empty record_id filter and returns every flag's scheduled
                // changes for the project instead of none
                if (featureFlag.id) {
                    actions.loadScheduledChanges()
                }
                actions.applyScheduleDefaultsFromFlag()
            }
            if (values.copyDestinationProject) {
                actions.loadCopyDependencyRequirements()
            }
            actions.loadRelatedInsights()
            actions.loadDependentFlags()
            // Experiment is now loaded inline during loadFeatureFlag, not here

            // Auto-apply template from URL param on first load
            const templateId = router.values.searchParams.template as string | undefined
            if (templateId && featureFlag && !values.urlTemplateApplied) {
                actions.applyTemplate(templateId)
            }

            // Apply intent from URL param (when no template — with template, intent is applied after)
            if (!templateId && featureFlag) {
                maybeApplyUrlIntent(values, actions)
            }
        },
        applyTemplate: async ({ templateId }, breakpoint) => {
            const template = values.templates.find((t) => t.id === templateId)
            if (!template || !values.featureFlag) {
                return
            }
            const templateValues = template.getValues(values.featureFlag)

            const defaultConfig = await resolveDefaultReleaseConditions(
                values.defaultReleaseConditions,
                values.currentTeam?.id
            )
            // Bail if the logic unmounted or applyTemplate was re-invoked while release conditions
            // were loading — otherwise the reads below hit a store path that no longer exists and kea throws.
            breakpoint()
            const defaultGroups =
                defaultConfig?.enabled && defaultConfig.default_groups?.length > 0 ? defaultConfig.default_groups : []
            const templateGroups = templateValues.filters?.groups ?? []
            const mergedGroups = defaultGroups.length > 0 ? [...defaultGroups, ...templateGroups] : templateGroups

            const leavingRemoteConfigEncrypted =
                values.featureFlag.is_remote_configuration === true &&
                templateValues.is_remote_configuration === false &&
                values.featureFlag.has_encrypted_payloads === true

            actions.setFeatureFlag({
                ...values.featureFlag,
                ...templateValues,
                filters: {
                    ...values.featureFlag.filters,
                    ...templateValues.filters,
                    groups: mergedGroups,
                },
            } as FeatureFlagType)

            if (leavingRemoteConfigEncrypted) {
                // Leaving remote config: the backend invariant requires
                // has_encrypted_payloads=true only on remote config flags,
                // and the prior ciphertext is no longer valid.
                actions.resetEncryptedPayload()
            }

            actions.setTemplateExpanded(false)
            actions.applyUrlTemplate(templateId)

            // Apply intent after template so intent presets are not overwritten
            maybeApplyUrlIntent(values, actions)
        },
        copyFlagSuccess: ({ featureFlagCopy }) => {
            if (featureFlagCopy?.success.length) {
                const operation = values.projectsWithCurrentFlag.find(
                    (p) => Number(p.team_id) === values.copyDestinationProject
                )
                    ? 'updated'
                    : 'copied'
                const copiedDependencyCount = featureFlagCopy.success.reduce(
                    (count, flag) => count + (flag.copied_dependency_keys?.length ?? 0),
                    0
                )
                lemonToast.success(
                    copiedDependencyCount
                        ? `Feature flag ${operation} successfully with ${copiedDependencyCount} dependenc${copiedDependencyCount === 1 ? 'y' : 'ies'}!`
                        : `Feature flag ${operation} successfully!`
                )
                eventUsageLogic.actions.reportFeatureFlagCopySuccess()

                // Surface any warnings the copy returned (e.g. a flag dependency dropped because it
                // doesn't exist in the target, or scheduled changes that failed to copy).
                const warnings = featureFlagCopy.success.flatMap((flag) => [
                    ...(flag.flag_dependency_warnings ?? []),
                    ...(flag.schedule_copy_warning ? [flag.schedule_copy_warning] : []),
                    ...(flag.dependency_copy_warnings ?? []),
                ])
                warnings.forEach((warning) => lemonToast.warning(warning))
            } else {
                // This flow copies to a single target project, so at most one failure entry comes back.
                const failure = featureFlagCopy?.failed[0]
                if (failure?.approval_pending) {
                    const projectName = values.currentOrganization?.teams.find(
                        (team) => team.id === (failure.project_id ?? values.copyDestinationProject)
                    )?.name
                    lemonToast.warning(
                        `A change request was created for ${
                            projectName ?? 'the destination project'
                        }; the copy will apply once approved.`
                    )
                    eventUsageLogic.actions.reportFeatureFlagCopyFailure(failure.error_message ?? 'Approval pending')
                } else {
                    const errorMessage =
                        failure?.error_message ?? stringifyWithBigInts(featureFlagCopy?.failed ?? featureFlagCopy)
                    lemonToast.error(`Error while copying feature flag: ${errorMessage}`)
                    eventUsageLogic.actions.reportFeatureFlagCopyFailure(errorMessage)
                }
            }

            actions.loadProjectsWithCurrentFlag()
            actions.setCopyDestinationProject(null)
            actions.setCopySchedule(false)
            actions.setDisableCopiedFlag(false)
            actions.setCopyDependencies(false)
        },
        copyFlagFailure: () => {
            if (values.copyDependencies && values.copyDestinationProject) {
                actions.loadCopyDependencyRequirements()
            }
        },
        createStaticCohortSuccess: ({ newCohort }) => {
            if (newCohort) {
                lemonToast.success('Static cohort created successfully', {
                    button: {
                        label: 'View cohort',
                        action: () => router.actions.push(urls.cohort(newCohort.id)),
                    },
                })
            }
        },
        createSurveySuccess: ({ newSurvey }) => {
            if (newSurvey) {
                lemonToast.success('Survey created successfully', {
                    button: {
                        label: 'View survey',
                        action: () => router.actions.push(urls.survey(newSurvey.id)),
                    },
                })
            }
        },
        createScheduledChangeSuccess: ({ scheduledChange }) => {
            if (scheduledChange) {
                if (scheduledChange.change_request?.state === ScheduledChangeRequestState.Pending) {
                    lemonToast.success(
                        'Change scheduled - pending approval. It will be skipped if not approved before the scheduled time.'
                    )
                } else {
                    lemonToast.success('Change scheduled successfully')
                }
                actions.setScheduleDateMarker(null)
                actions.setSchedulePayload(NEW_FLAG.filters, NEW_FLAG.active, {}, null, null)
                actions.setIsRecurring(false)
                actions.setRecurrenceInterval(null)
                actions.setCronExpression(null)
                actions.setEndDate(null)
                actions.loadScheduledChanges()
                eventUsageLogic.actions.reportFeatureFlagScheduleSuccess()
            }
        },
        setScheduledChangeOperation: ({ changeType }) => {
            // Reset payload when operation changes, defaulting to sensible values per operation type
            if (changeType === ScheduledChangeOperationType.UpdateVariants && values.featureFlag?.id) {
                const flagWithKeyBasedPayloads = indexToVariantKeyFeatureFlagPayloads(values.featureFlag)
                const flagWithIndexBasedPayloads = variantKeyToIndexFeatureFlagPayloads(
                    flagWithKeyBasedPayloads as FeatureFlagType
                )
                const currentVariants = values.featureFlag.filters.multivariate?.variants || []
                const indexBasedPayloads = flagWithIndexBasedPayloads.filters.payloads || {}

                const filtersWithPayloads = {
                    ...NEW_FLAG.filters,
                    payloads: indexBasedPayloads,
                }
                actions.setSchedulePayload(
                    filtersWithPayloads,
                    NEW_FLAG.active,
                    {},
                    currentVariants,
                    indexBasedPayloads
                )
            } else if (changeType === ScheduledChangeOperationType.UpdateStatus) {
                // Default to the opposite of the current flag state since the user
                // most likely wants to toggle it
                const oppositeActive = !values.featureFlag.active
                actions.setSchedulePayload(NEW_FLAG.filters, oppositeActive, {}, null, null)
            } else {
                actions.setSchedulePayload(NEW_FLAG.filters, NEW_FLAG.active, {}, null, null)
            }
        },
        setSelectedTab: ({ tab }) => {
            // Reset payload when opening schedule tab. The default operation is UpdateStatus,
            // so default active to the opposite of the current flag state.
            if (tab === FeatureFlagsTab.SCHEDULE) {
                const oppositeActive = !values.featureFlag.active
                actions.setSchedulePayload(NEW_FLAG.filters, oppositeActive, {}, null, null)
                // An unsaved flag has no id to scope the request to, and the scheduled-changes
                // endpoint drops an empty record_id filter and returns every flag's scheduled
                // changes for the project instead of none
                if (values.featureFlag.id) {
                    actions.loadScheduledChanges()
                }
            }
        },
        createScheduledChangeFailure: ({ error }) => {
            eventUsageLogic.actions.reportFeatureFlagScheduleFailure({ error })
        },
        deleteScheduledChangeSuccess: ({ scheduledChange }) => {
            if (scheduledChange) {
                lemonToast.success('Change has been deleted')
                actions.loadScheduledChanges()
            }
        },
        stopRecurringScheduledChange: async ({ scheduledChangeId }) => {
            const { currentProjectId } = values
            if (currentProjectId) {
                try {
                    await api.featureFlags.updateScheduledChange(currentProjectId, scheduledChangeId, {
                        is_recurring: false,
                    })
                    lemonToast.success('Recurring schedule has been paused')
                    actions.loadScheduledChanges()
                } catch {
                    lemonToast.error('Failed to pause recurring schedule')
                }
            }
        },
        resumeRecurringScheduledChange: async ({ scheduledChangeId }) => {
            const { currentProjectId } = values
            if (currentProjectId) {
                try {
                    await api.featureFlags.updateScheduledChange(currentProjectId, scheduledChangeId, {
                        is_recurring: true,
                    })
                    lemonToast.success('Recurring schedule has been resumed')
                    actions.loadScheduledChanges()
                } catch {
                    lemonToast.error('Failed to resume recurring schedule')
                }
            }
        },
        setRemoteConfigEnabled: ({ enabled }) => {
            if (enabled) {
                actions.setFeatureFlagFilters(
                    {
                        ...values.featureFlag.filters,
                        groups: [
                            {
                                variant: null,
                                properties: [],
                                rollout_percentage: 100,
                            },
                        ],
                    },
                    {}
                )
            } else if (values.featureFlag.has_encrypted_payloads) {
                // Leaving remote config: the backend invariant requires
                // has_encrypted_payloads=true only on remote config flags,
                // and the prior ciphertext is no longer valid.
                actions.resetEncryptedPayload()
            }
        },
        saveDescriptionInline: async ({ name }) => {
            const flag = values.featureFlag
            if (!flag.id || name === flag.name) {
                return
            }
            try {
                const savedFlag = await api.update(`api/projects/${values.currentProjectId}/feature_flags/${flag.id}`, {
                    name,
                })
                actions.setFeatureFlag({ ...flag, name: savedFlag.name })
                if (values.originalFeatureFlag) {
                    actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, name: savedFlag.name })
                }
                actions.updateFlag({ ...flag, name: savedFlag.name })
                lemonToast.success('Description saved')
            } catch {
                lemonToast.error('Failed to save description')
            }
        },
        saveTagsInline: async ({ tags }, breakpoint) => {
            const flag = values.featureFlag
            if (!flag.id) {
                return
            }
            // Optimistic update applies immediately on every call so the chips reflect the
            // user's intent without waiting for the API.
            const previousTags = flag.tags
            actions.setFeatureFlag({ ...flag, tags })
            // Tags are the only field being saved here — track them on the baseline directly so a
            // concurrent release-condition edit isn't folded into it and silently marked as saved.
            const baselineForTags = values.originalFeatureFlag
            if (baselineForTags) {
                actions.setOriginalFeatureFlag({ ...baselineForTags, tags })
            }
            actions.updateFlag({ ...flag, tags })

            // Debounce — rapid changes (e.g. quickly removing several chips) collapse into a
            // single API call with the final tag set. Without this, overlapping requests
            // can land out-of-order and stomp the latest local state when their responses
            // resolve.
            await breakpoint(250)

            try {
                const savedFlag = await api.update(`api/projects/${values.currentProjectId}/feature_flags/${flag.id}`, {
                    tags,
                })
                // If the listener has been invoked again since this await started, bail out
                // — the newer call owns reconciliation.
                breakpoint()

                // Reconcile with server only if the *set* of tags differs (e.g. server-side
                // normalization added/removed a tag). Avoid blindly overwriting — the
                // server may return tags in a different order which would re-shuffle chips.
                const localSet = new Set(tags)
                const serverTags = savedFlag.tags ?? []
                const serverSet = new Set(serverTags)
                const setsEqual = localSet.size === serverSet.size && tags.every((t) => serverSet.has(t))
                if (!setsEqual) {
                    actions.setFeatureFlag({ ...flag, tags: serverTags })
                    if (values.originalFeatureFlag) {
                        actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, tags: serverTags })
                    }
                    actions.updateFlag({ ...flag, tags: serverTags })
                }
            } catch (error: any) {
                // Re-throw breakpoint cancellation so kea swallows it silently.
                if (error?.isBreakpoint) {
                    throw error
                }
                actions.setFeatureFlag({ ...flag, tags: previousTags })
                if (values.originalFeatureFlag) {
                    actions.setOriginalFeatureFlag({ ...values.originalFeatureFlag, tags: previousTags })
                }
                actions.updateFlag({ ...flag, tags: previousTags })
                lemonToast.error('Failed to save tags')
            }
        },
        editFeatureFlag: async ({ editing }) => {
            if (editing) {
                actions.loadFeatureFlag()
            }
        },
        submitFeatureFlagWithValidation: async (_payload, breakpoint, action, previousState) => {
            const featureFlag = values.featureFlag
            const originalFlag = values.originalFeatureFlag
            const keyChanged = originalFlag && featureFlag.id && originalFlag.key !== featureFlag.key

            if (keyChanged) {
                const confirmed = await new Promise<boolean>((resolve) => {
                    LemonDialog.open({
                        title: 'Change flag key?',
                        description: createElement(
                            'span',
                            null,
                            'Renaming this key will break any existing code that references it (e.g. ',
                            createElement(
                                'code',
                                { className: 'text-xs bg-fill-secondary rounded px-1 py-0.5' },
                                `getFeatureFlag('${originalFlag.key}')`
                            ),
                            '). Make sure to update all SDK calls and integrations.'
                        ),
                        primaryButton: {
                            children: 'Change key',
                            status: 'danger',
                            onClick: () => resolve(true),
                        },
                        secondaryButton: {
                            children: 'Cancel',
                        },
                        onAfterClose: () => resolve(false),
                    })
                })
                if (!confirmed) {
                    return
                }
            }

            await sharedListeners.checkDependentFlagsAndConfirm(
                {
                    originalFlag,
                    updatedFlag: featureFlag,
                    onConfirm: () => {
                        if (featureFlag.id) {
                            actions.saveFeatureFlag(featureFlag)
                        } else {
                            actions.saveFeatureFlag({ ...featureFlag, _create_in_folder: 'Unfiled/Feature Flags' })
                        }
                    },
                },
                breakpoint,
                action as any,
                previousState
            )
        },
        toggleFeatureFlagActive: async ({ active }, breakpoint, action, previousState) => {
            const updatedFlag = { ...values.featureFlag, active }
            await sharedListeners.checkDependentFlagsAndConfirm(
                {
                    originalFlag: values.originalFeatureFlag,
                    updatedFlag,
                    onConfirm: () => {
                        actions.updateFeatureFlagActive(active)
                    },
                    requireStatusConfirmation: true,
                    onDisableAndArchive: () => {
                        actions.updateFeatureFlagArchived({ archived: true, via: 'disable-confirmation' })
                    },
                },
                breakpoint,
                action as any,
                previousState
            )
        },
    })),
    selectors({
        props: [() => [(_, props) => props], (props) => props],
        // Which tabs the flag offers; FeatureFlag.tsx renders exactly this set
        availableTabs: [
            (s) => [s.featureFlag, s.props],
            (featureFlag: FeatureFlagType, props: FeatureFlagLogicProps): FeatureFlagsTab[] => {
                const tabs = [FeatureFlagsTab.OVERVIEW]
                if (props.id) {
                    tabs.push(FeatureFlagsTab.USAGE, FeatureFlagsTab.PROJECTS, FeatureFlagsTab.SCHEDULE)
                }
                if (featureFlag.id) {
                    tabs.push(FeatureFlagsTab.HISTORY)
                }
                if (featureFlag.can_edit) {
                    tabs.push(FeatureFlagsTab.PERMISSIONS)
                }
                tabs.push(FeatureFlagsTab.FEEDBACK, FeatureFlagsTab.EXPERIMENTS)
                if (props.id) {
                    tabs.push(FeatureFlagsTab.TESTING)
                }
                return tabs
            },
        ],
        // Clamped in a selector rather than in urlToAction so it re-derives when the flag
        // loads (a deep-linked tab can arrive before `can_edit` is known)
        activeTab: [
            (s) => [s.selectedTab, s.availableTabs],
            (selectedTab: FeatureFlagsTab, availableTabs: FeatureFlagsTab[]): FeatureFlagsTab =>
                availableTabs.includes(selectedTab) ? selectedTab : FeatureFlagsTab.OVERVIEW,
        ],
        hasUnsavedChanges: [
            (s) => [s.featureFlag, s.originalFeatureFlag],
            (featureFlag: FeatureFlagType, originalFeatureFlag: FeatureFlagType | null): boolean => {
                if (!originalFeatureFlag) {
                    // New flag — compare against form defaults via featureFlagChanged instead
                    return false
                }
                // Same transform as the baseline, so both sides of the diff stay in step by
                // construction rather than by keeping two copies of it in sync.
                return !objectsEqual(toFeatureFlagBaseline(featureFlag), originalFeatureFlag)
            },
        ],
        isFormDirty: [
            (s) => [s.originalFeatureFlag, s.hasUnsavedChanges, s.featureFlagChanged],
            (
                originalFeatureFlag: FeatureFlagType | null,
                hasUnsavedChanges: boolean,
                featureFlagChanged: boolean
            ): boolean =>
                // Existing flags compare against server state; new flags fall back to the
                // form-defaults check from kea-forms (NEW_FLAG would otherwise always read dirty).
                originalFeatureFlag ? hasUnsavedChanges : featureFlagChanged,
        ],
        multivariateEnabled: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => !!featureFlag?.filters.multivariate,
        ],
        flagType: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) =>
                featureFlag?.is_remote_configuration
                    ? 'remote_config'
                    : featureFlag?.filters.multivariate
                      ? 'multivariate'
                      : 'boolean',
        ],
        flagTypeString: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) =>
                featureFlag?.is_remote_configuration
                    ? 'Remote configuration (single payload)'
                    : featureFlag?.filters.multivariate
                      ? 'Multiple variants with rollout percentages (A/B/n test)'
                      : 'Release toggle (boolean)',
        ],
        roleBasedAccessEnabled: [
            (s) => [s.hasAvailableFeature],
            (hasAvailableFeature: (feature: AvailableFeature, currentUsage?: number | undefined) => boolean) =>
                hasAvailableFeature(AvailableFeature.ROLE_BASED_ACCESS),
        ],
        variants: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => featureFlag?.filters.multivariate?.variants || [],
        ],
        nonEmptyVariants: [
            (s) => [s.variants],
            (variants: MultivariateFlagVariant[]) => variants.filter(({ key }) => !!key),
        ],
        aggregationTargetName: [
            (s) => [s.featureFlag, s.aggregationLabel],
            (
                featureFlag: FeatureFlagType,
                aggregationLabel: (
                    groupTypeIndex: number | null | undefined,
                    deferToUserWording?: boolean
                ) => import('~/models/groupsModel').Noun
            ): string => {
                if (featureFlag && featureFlag.filters.aggregation_group_type_index != null) {
                    return aggregationLabel(featureFlag.filters.aggregation_group_type_index).plural
                }
                return 'users'
            },
        ],
        breadcrumbs: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType): Breadcrumb[] => [
                {
                    key: Scene.FeatureFlags,
                    name: 'Feature Flags',
                    path: urls.featureFlags(),
                    iconType: 'feature_flag',
                },
                {
                    key: [Scene.FeatureFlag, featureFlag.id || 'unknown'],
                    name: featureFlag.key || (!featureFlag.id ? 'New feature flag' : 'Unnamed'),
                    iconType: featureFlag.active ? 'feature_flag' : 'feature_flag_off',
                },
            ],
        ],
        projectTreeRef: [
            () => [(_, props: FeatureFlagLogicProps) => props.id],
            (id: number | 'link' | 'new'): ProjectTreeRef => ({
                type: 'feature_flag',
                ref: id === 'link' || id === 'new' ? null : String(id),
            }),
        ],

        [SIDE_PANEL_CONTEXT_KEY]: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType): SidePanelSceneContext | null => {
                return featureFlag?.id
                    ? {
                          activity_scope: ActivityScope.FEATURE_FLAG,
                          activity_item_id: `${featureFlag.id}`,
                          access_control_resource: 'feature_flag',
                          access_control_resource_id: `${featureFlag.id}`,
                      }
                    : null
            },
        ],
        recordingFilterForFlag: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType): Partial<RecordingUniversalFilters> => {
                const flagKey = featureFlag?.key
                if (!flagKey) {
                    return {}
                }

                return getRecordingFilterForFlagVariant(flagKey, null, featureFlag.has_enriched_analytics)
            },
        ],
        hasEarlyAccessFeatures: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return (featureFlag?.features?.length || 0) > 0
            },
        ],
        earlyAccessFeaturesList: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return featureFlag?.features || []
            },
        ],
        featureFlagKey: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return featureFlag.key
            },
        ],
        canCreateEarlyAccessFeature: [
            (s) => [s.featureFlag, s.variants],
            (featureFlag: FeatureFlagType, variants: MultivariateFlagVariant[]) => {
                return featureFlag && featureFlag.filters.aggregation_group_type_index == null && variants.length === 0
            },
        ],
        hasSurveys: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return featureFlag?.surveys && featureFlag.surveys.length > 0
            },
        ],
        hasEncryptedPayloadBeenSaved: [
            (s) => [s.featureFlag, s.props],
            (featureFlag: FeatureFlagType, props) => {
                if (!featureFlag.has_encrypted_payloads) {
                    return false
                }
                const savedFlag = featureFlagsLogic
                    .findMounted()
                    ?.values.featureFlags.results.find((flag) => flag.id === props.id)
                return savedFlag?.has_encrypted_payloads
            },
        ],
        hasExperiment: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return featureFlag?.experiment_set && featureFlag.experiment_set.length > 0
            },
        ],
        isDraftExperiment: [
            (s) => [s.experiment],
            (experiment) => {
                // Treat as launched experiment if not yet loaded.
                if (!experiment) {
                    return false
                }
                return !experiment?.start_date
            },
        ],
        properties: [
            (s) => [s.featureFlag],
            (featureFlag: FeatureFlagType) => {
                return featureFlag?.filters?.groups?.flatMap((g) => g.properties ?? []) ?? []
            },
        ],
        variantErrors: [
            (s) => [s.variants],
            (variants: MultivariateFlagVariant[]) => {
                const errors: VariantError[] = variants.map(({ key: variantKey }: MultivariateFlagVariant) => ({
                    key: validateFeatureFlagVariantKey(variantKey),
                }))
                return errors
            },
        ],
        repeatsValue: [
            (s) => [s.isRecurring, s.cronExpression, s.recurrenceInterval],
            (
                isRecurring: boolean,
                cronExpression: string | null,
                recurrenceInterval: RecurrenceInterval | null
            ): RecurrenceInterval | 'none' | 'cron' =>
                isRecurring ? (cronExpression !== null ? 'cron' : (recurrenceInterval ?? 'none')) : 'none',
        ],
        cronPreview: [
            (s) => [s.cronExpression],
            (cronExpression: string | null): string | null => describeCron(cronExpression),
        ],
        customPairEnableCronPreview: [
            (s) => [s.customPairEnableCron],
            (cron: string): string | null => describeCron(cron),
        ],
        customPairDisableCronPreview: [
            (s) => [s.customPairDisableCron],
            (cron: string): string | null => describeCron(cron),
        ],
        canCreatePairedSchedule: [
            (s) => [
                s.schedulePreset,
                s.customPairEnableCron,
                s.customPairDisableCron,
                s.customPairEnableCronPreview,
                s.customPairDisableCronPreview,
            ],
            (
                preset: PairedPresetKey | null,
                enableCron: string,
                disableCron: string,
                enablePreview: string | null,
                disablePreview: string | null
            ): boolean => {
                if (!preset) {
                    return false
                }
                if (preset === 'custom_pair') {
                    return (
                        !!enableCron &&
                        !!disableCron &&
                        enablePreview !== 'Invalid cron expression' &&
                        disablePreview !== 'Invalid cron expression'
                    )
                }
                return true
            },
        ],
        activeRecurringSchedules: [
            (s) => [s.scheduledChanges],
            (scheduledChanges: ScheduledChangeType[]) =>
                scheduledChanges.filter((sc) => sc.is_recurring && !sc.executed_at),
        ],
        pausedRecurringSchedules: [
            (s) => [s.scheduledChanges],
            (scheduledChanges: ScheduledChangeType[]) =>
                scheduledChanges.filter((sc) => isSchedulePaused(sc) && !sc.executed_at),
        ],
        upcomingOneTimeSchedules: [
            (s) => [s.scheduledChanges],
            (scheduledChanges: ScheduledChangeType[]) =>
                scheduledChanges.filter(
                    (sc) =>
                        !sc.is_recurring &&
                        !sc.recurrence_interval &&
                        !sc.cron_expression &&
                        !sc.executed_at &&
                        !isScheduleDeniedApproval(sc)
                ),
        ],
        completedSchedules: [
            (s) => [s.scheduledChanges],
            (scheduledChanges: ScheduledChangeType[]) =>
                scheduledChanges.filter((sc) => !!sc.executed_at || isScheduleDeniedApproval(sc)).sort(byExecutedAt),
        ],
        activeSchedules: [
            (s) => [s.activeRecurringSchedules, s.pausedRecurringSchedules, s.upcomingOneTimeSchedules],
            // Interleave all schedule types so the upcoming list reads soonest first.
            (
                activeRecurring: ScheduledChangeType[],
                pausedRecurring: ScheduledChangeType[],
                upcomingOneTime: ScheduledChangeType[]
            ) => [...activeRecurring, ...pausedRecurring, ...upcomingOneTime].sort(byScheduledAt),
        ],
        scheduleTimelineOccurrences: [
            // Raw scheduled changes, not activeSchedules: the expansion owns occurrence
            // eligibility (executed, paused, denied) so its filters stay live and tested.
            (s) => [s.scheduledChanges, s.featureFlag],
            (scheduledChanges: ScheduledChangeType[], featureFlag: FeatureFlagType): ScheduleOccurrence[] =>
                expandScheduleOccurrences(scheduledChanges, featureFlag, dayjs()),
        ],
        // The form can collapse only when there is a plan to read; the close button uses this too.
        scheduleFormCollapsible: [
            (s) => [s.activeSchedules],
            (activeSchedules: ScheduledChangeType[]): boolean => activeSchedules.length > 0,
        ],
        scheduleFormState: [
            (s) => [
                s.scheduleFormManuallyExpanded,
                s.scheduleFormCollapsible,
                s.scheduledChangesLoading,
                s.scheduledChangesLoaded,
            ],
            (
                scheduleFormManuallyExpanded: boolean | null,
                scheduleFormCollapsible: boolean,
                scheduledChangesLoading: boolean,
                scheduledChangesLoaded: boolean
            ): ScheduleFormState => {
                if (scheduleFormManuallyExpanded !== null) {
                    // A manual collapse holds only while a plan remains to read. When the last
                    // schedule goes, the form must open again, because the empty state tells the
                    // user to use the form above it.
                    return scheduleFormManuallyExpanded || !scheduleFormCollapsible ? 'expanded' : 'collapsed'
                }
                if (scheduledChangesLoading && !scheduledChangesLoaded) {
                    return 'loading'
                }
                return scheduleFormCollapsible ? 'collapsed' : 'expanded'
            },
        ],
        emailDomain: [
            (s) => [s.user],
            (user: null | import('~/types').UserType) => user?.email?.split('@')[1] || 'example.com',
        ],
        templates: [
            (s) => [s.emailDomain],
            (
                emailDomain: string
            ): Array<{
                id: string
                name: string
                description: string
                getValues: (flag: FeatureFlagType) => Partial<FeatureFlagType>
            }> => [
                {
                    id: 'simple',
                    name: TEMPLATE_NAMES.simple,
                    description: 'On/off for all users',
                    getValues: (flag) => ({
                        key: 'my-feature',
                        is_remote_configuration: false,
                        filters: {
                            ...flag.filters,
                            multivariate: null,
                            groups: [{ properties: [], rollout_percentage: 0, variant: null }],
                        },
                    }),
                },
                {
                    id: 'targeted',
                    name: TEMPLATE_NAMES.targeted,
                    description: 'Release to specific users',
                    getValues: (flag) => ({
                        key: 'targeted-release',
                        is_remote_configuration: false,
                        filters: {
                            ...flag.filters,
                            multivariate: null,
                            groups: [
                                {
                                    properties: [
                                        {
                                            key: 'email',
                                            type: PropertyFilterType.Person,
                                            value: `@${emailDomain}`,
                                            operator: PropertyOperator.IContains,
                                        },
                                    ],
                                    rollout_percentage: 0,
                                    variant: null,
                                },
                            ],
                        },
                    }),
                },
                {
                    id: 'multivariate',
                    name: TEMPLATE_NAMES.multivariate,
                    description: 'Multiple variants',
                    getValues: (flag) => ({
                        key: 'multivariate-flag',
                        is_remote_configuration: false,
                        filters: {
                            ...flag.filters,
                            multivariate: {
                                variants: [
                                    { key: 'control', rollout_percentage: 50 },
                                    { key: 'test', rollout_percentage: 50 },
                                ],
                            },
                            groups: [{ properties: [], rollout_percentage: 0, variant: null }],
                        },
                    }),
                },
                {
                    id: 'targeted-multivariate',
                    name: TEMPLATE_NAMES['targeted-multivariate'],
                    description: 'Variants for specific users',
                    getValues: (flag) => ({
                        key: 'targeted-multivariate',
                        is_remote_configuration: false,
                        filters: {
                            ...flag.filters,
                            multivariate: {
                                variants: [
                                    { key: 'control', rollout_percentage: 50 },
                                    { key: 'test', rollout_percentage: 50 },
                                ],
                            },
                            groups: [
                                {
                                    properties: [
                                        {
                                            key: 'email',
                                            type: PropertyFilterType.Person,
                                            value: `@${emailDomain}`,
                                            operator: PropertyOperator.IContains,
                                        },
                                    ],
                                    rollout_percentage: 0,
                                    variant: null,
                                },
                            ],
                        },
                    }),
                },
            ],
        ],
    }),
    trackedActionToUrl(({ props, values }) => ({
        setSelectedTab: () => {
            // The logic outlives the scene in places (e.g. the flag is embedded elsewhere),
            // so only rewrite the URL while we're actually on this flag's page
            if (!isOnFeatureFlagPage(props.id)) {
                return
            }

            // The URL carries selectedTab (the requested tab), not the clamped activeTab, so the
            // write round-trips with what urlToAction reads and never depends on availableTabs,
            // which is provisional until the flag loads. A deep link to a tab the user cannot see
            // yet (e.g. permissions before `can_edit` is known) stays in the URL this way.
            const searchParams = { ...router.values.searchParams }
            if (values.selectedTab === FeatureFlagsTab.OVERVIEW) {
                delete searchParams[TAB_SEARCH_PARAM]
            } else {
                searchParams[TAB_SEARCH_PARAM] = values.selectedTab
            }
            // `activity` deep-links to one activity item, which only exists on the history tab
            if (values.selectedTab !== FeatureFlagsTab.HISTORY) {
                delete searchParams[ACTIVITY_SEARCH_PARAM]
            }

            return [router.values.location.pathname, searchParams, router.values.hashParams, { replace: true }]
        },
    })),
    urlToAction(({ actions, props, values }) => ({
        [urls.featureFlag(props.id ?? 'new')]: (_, searchParams, ___, { method, initial }) => {
            // Don't disturb in-progress edits when a same-pathname PUSH slips through
            // (e.g. the beforeUnload prompt was shown and cancelled, but the route still
            // reaches this handler). This must run before `editFeatureFlag` is dispatched,
            // because its listener calls `loadFeatureFlag()` whenever `editing === true` —
            // which would wipe the form on any re-push carrying `?edit=true`.
            // The `initial` mount must still run so first-load setup happens.
            if (method === 'PUSH' && values.isFormDirty) {
                return
            }

            // Set editing state on initial mount or PUSH navigation
            if (method === 'PUSH' || initial) {
                actions.editFeatureFlag(searchParams.edit === true || searchParams.edit === 'true')
            }
            // If the URL was pushed (user clicked on a link), reset the scene's data.
            // This avoids resetting form fields if you click back/forward.

            // The URL is the source of truth for the selected tab, so `?tab=usage` deep-links
            // and survives a reload. `?activity=` still implies the history tab.
            const tabFromUrl = searchParams[TAB_SEARCH_PARAM]
            const targetTab = isFeatureFlagsTab(tabFromUrl)
                ? tabFromUrl
                : searchParams[ACTIVITY_SEARCH_PARAM] != null
                  ? FeatureFlagsTab.HISTORY
                  : FeatureFlagsTab.OVERVIEW
            if (targetTab !== values.selectedTab) {
                actions.setSelectedTab(targetTab)
            }

            if (method === 'PUSH') {
                if (props.id) {
                    // When there is sourceId, we load the feature flag (for duplicating)
                    if (props.id === 'new' && searchParams.sourceId != null) {
                        actions.loadFeatureFlag()
                        return
                    }
                    // When there is type, we load the feature flag (for pre-selecting flag type)
                    if (props.id === 'new' && searchParams.type != null) {
                        actions.loadFeatureFlag()
                        return
                    }
                    // When there is template, we load the feature flag (for applying template)
                    if (props.id === 'new' && searchParams.template != null) {
                        actions.loadFeatureFlag()
                        return
                    }
                    // When there is intent, we load the feature flag (for applying intent presets)
                    if (props.id === 'new' && searchParams.intent != null) {
                        actions.loadFeatureFlag()
                        return
                    }
                    // When pushing to `/new` and the feature flag already has default tags loaded, do not load the flag again
                    if (props.id === 'new' && values.featureFlag.id == null && values.featureFlag.tags?.length > 0) {
                        return
                    }
                    actions.loadFeatureFlag()
                } else {
                    actions.resetFeatureFlag()
                }
            }
        },
    })),

    beforeUnload((logic) => ({
        enabled: (newLocation?: CombinedLocation) => {
            if (!logic.values.isFormDirty) {
                return false
            }

            // Ignore in-page URL updates such as opening the side panel
            if (newLocation && newLocation.pathname === router.values.location.pathname) {
                return false
            }

            return true
        },
        message: 'Leave feature flag?\nChanges you made will be discarded.',
        onConfirm: () => {
            logic.actions.resetFeatureFlag((logic.values.originalFeatureFlag as any) ?? undefined)
        },
    })),

    afterMount(({ props, actions }) => {
        if (
            props.id === 'new' &&
            (router.values.searchParams.sourceId ||
                router.values.searchParams.type ||
                router.values.searchParams.template ||
                router.values.searchParams.intent)
        ) {
            actions.loadFeatureFlag()
            return
        }

        const foundFlag = featureFlagsLogic
            .findMounted()
            ?.values.featureFlags.results.find((flag) => flag.id === props.id)
        if (foundFlag) {
            const formatPayloadsWithFlag = variantKeyToIndexFeatureFlagPayloads(foundFlag)
            actions.setFeatureFlag(formatPayloadsWithFlag)
            // The cache paint is the initial load for a list-navigated flag, so seed the baseline.
            actions.setOriginalFeatureFlag(toFeatureFlagBaseline(formatPayloadsWithFlag))
            actions.loadRelatedInsights()
            actions.loadFeatureFlagStatus()
            actions.loadDependentFlags()
            // Paint instantly from the list cache above, then silently reconcile with the
            // server: the cached `active` can be stale (toggled elsewhere since the list
            // loaded), which otherwise leaves the overview toggle and its confirmation
            // dialog reflecting the wrong state.
            actions.refreshFeatureFlag()
        } else if (props.id !== 'new') {
            actions.loadFeatureFlag()
            actions.loadFeatureFlagStatus()
        } else if (props.id === 'new') {
            // Load default evaluation contexts for new flags
            actions.loadFeatureFlag()
        }
    }),
])
