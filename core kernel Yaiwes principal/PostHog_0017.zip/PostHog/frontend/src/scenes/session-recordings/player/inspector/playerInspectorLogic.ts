import { deepEqual as equal } from 'fast-equals'
import FuseClass from 'fuse.js'
import {
    MakeLogicType,
    actions,
    connect,
    events,
    kea,
    key,
    listeners,
    path,
    props,
    propsChanged,
    reducers,
    selectors,
} from 'kea'
import { loaders } from 'kea-loaders'
import {
    EventType as RRWebEventType,
    customEvent,
    eventWithTime,
    fullSnapshotEvent,
    pluginEvent,
} from 'posthog-js/rrweb-types'

import api from 'lib/api'
import { TaxonomicFilterGroupType } from 'lib/components/TaxonomicFilter/types'
import { FEATURE_FLAGS } from 'lib/constants'
import { Dayjs, dayjs } from 'lib/dayjs'
import { featureFlagLogic } from 'lib/logic/featureFlagLogic'
import { ceilMsToClosestSecond } from 'lib/utils/durations'
import { eventToDescription } from 'lib/utils/events'
import { createFuse } from 'lib/utils/fuseSearch'
import { isString } from 'lib/utils/guards'
import { humanizeBytes } from 'lib/utils/numbers'
import { toParams } from 'lib/utils/url'
import { getText } from 'scenes/comments/Comment'
import {
    InspectorListItemPerformance,
    performanceEventDataLogic,
} from 'scenes/session-recordings/apm/performanceEventDataLogic'
import {
    filterInspectorListItems,
    itemToMiniFilter,
} from 'scenes/session-recordings/player/inspector/inspectorListFiltering'
import { MiniFilterKey, miniFiltersLogic } from 'scenes/session-recordings/player/inspector/miniFiltersLogic'
import {
    MatchingEventsMatchType,
    convertUniversalFiltersToRecordingsQuery,
} from 'scenes/session-recordings/playlist/sessionRecordingsPlaylistLogic'
import { sessionRecordingEventUsageLogic } from 'scenes/session-recordings/sessionRecordingEventUsageLogic'

import { LogMessage, RecordingsQuery } from '~/queries/schema/schema-general'
import { getCoreFilterDefinition } from '~/taxonomy/helpers'
import {
    CommentType,
    MatchedRecordingEvent,
    PerformanceEvent,
    RRWebRecordingConsoleLogPayload,
    RecordingConsoleLogV2,
    RecordingEventType,
} from '~/types'

import type { ExperimentSessionContextItemApi } from '../../../../../../products/experiments/frontend/generated/api.schemas'
import type { FeatureFlagsSet } from '../../../../lib/logic/featureFlagLogic'
import type { RecordingSegment, SessionPlayerData, SessionRecordingType } from '../../../../types'
import { sessionRecordingExperimentContextLogic } from '../player-meta/sessionRecordingExperimentContextLogic'
import { sessionRecordingDataCoordinatorLogic } from '../sessionRecordingDataCoordinatorLogic'
import {
    DoctorDiagnostics,
    SessionRecordingPlayerLogicProps,
    sessionRecordingPlayerLogic,
} from '../sessionRecordingPlayerLogic'
import type { SharedListMiniFilter } from './miniFiltersLogic'
import { playerInspectorLogsLogic } from './playerInspectorLogsLogic'

const CONSOLE_LOG_PLUGIN_NAME = 'rrweb/console@1'

const MAX_SEEKBAR_ITEMS = 100

export const IMAGE_WEB_EXTENSIONS = [
    'png',
    'jpg',
    'jpeg',
    'gif',
    'tif',
    'tiff',
    'gif',
    'svg',
    'webp',
    'bmp',
    'ico',
    'cur',
]

// Helping kea-typegen navigate the exported default class for Fuse
export interface Fuse extends FuseClass<InspectorListItem> {}

export type RecordingComment = {
    id: string
    notebookShortId: string
    notebookTitle: string
    comment: string
    timeInRecording: number
}

const _filterableItemTypes = ['events', 'console', 'network', 'comment', 'doctor', 'logs'] as const
const _itemTypes = [
    ..._filterableItemTypes,
    'performance',
    'offline-status',
    'browser-visibility',
    'inactivity',
    'inspector-summary',
    'app-state',
    'session-change',
    'experiment-variant',
    'metric-event',
] as const

export type InspectorListItemType = (typeof _itemTypes)[number]
export type FilterableInspectorListItemTypes = (typeof _filterableItemTypes)[number]

export type InspectorListItemBase = {
    timestamp: Dayjs
    timeInRecording: number
    search: string
    highlightColor?: 'danger' | 'warning' | 'primary'
    windowId?: number
    windowNumber?: number | '?' | undefined
    type: InspectorListItemType
    key: string
}

export type InspectorListItemEvent = InspectorListItemBase & {
    type: 'events'
    data: RecordingEventType
}

export type InspectorListItemInactivity = InspectorListItemBase & {
    type: 'inactivity'
    durationMs: number
}

export type InspectorListItemNotebookComment = InspectorListItemBase & {
    type: 'comment'
    source: 'notebook'
    data: RecordingComment
}

export type InspectorListItemComment = InspectorListItemBase & {
    type: 'comment'
    source: 'comment'
    data: CommentType
}

export type InspectorListItemConsole = InspectorListItemBase & {
    type: 'console'
    data: RecordingConsoleLogV2
}

export type InspectorListOfflineStatusChange = InspectorListItemBase & {
    type: 'offline-status'
    offline: boolean
}

export type InspectorListBrowserVisibility = InspectorListItemBase & {
    type: 'browser-visibility'
    status: 'hidden' | 'visible'
}

interface SessionChangePayload {
    nextSessionId?: string
    previousSessionId?: string
    changeReason?: { noSessionId: boolean; activityTimeout: boolean; sessionPastMaximumLength: boolean }
}

export type InspectorListSessionChange = InspectorListItemBase & {
    type: 'session-change'
    tag: '$session_starting' | '$session_ending'
    data: SessionChangePayload
}

export type InspectorListItemDoctor = InspectorListItemBase & {
    type: 'doctor'
    tag: string
    data?: Record<string, any>
}

export type InspectorListItemAppState = InspectorListItemBase & {
    type: 'app-state'
    action: string
    stateEvent?: Record<string, any>
}

export type InspectorListItemLog = InspectorListItemBase & {
    type: 'logs'
    data: LogMessage
}

export type InspectorListItemSummary = InspectorListItemBase & {
    type: 'inspector-summary'
    clickCount: number | null
    keypressCount: number | null
    errorCount: number | null
}

export type InspectorListItemExperimentVariant = InspectorListItemBase & {
    type: 'experiment-variant'
    data: {
        // Synthesized client-side from the experiments session_context endpoint response
        // (first_exposure_timestamp) — there is no backend event for this item, so it is
        // not part of the loaded event stream. `id` keeps the same keying contract as
        // event/comment items in the seekbar.
        id: string
        experimentId: number
        experimentName: string
        flagKey: string
        variant: string
        multipleVariants: boolean
        variantsSeen: string[]
    }
}

export type InspectorListItemMetricEvent = InspectorListItemBase & {
    type: 'metric-event'
    data: {
        // Synthesized client-side from the experiments session_context endpoint response
        // (metrics_in_session[].first_timestamp) — like the exposure marker, there is no backend
        // event for this item. One marker per metric, at its first occurrence in the session.
        // `id` keeps the same keying contract as event/comment items in the seekbar.
        id: string
        experimentId: number
        experimentName: string
        metricName: string
        eventCount: number
    }
}

export type InspectorListItem =
    | InspectorListItemEvent
    | InspectorListItemConsole
    | InspectorListItemPerformance
    | InspectorListOfflineStatusChange
    | InspectorListItemDoctor
    | InspectorListBrowserVisibility
    | InspectorListItemComment
    | InspectorListItemNotebookComment
    | InspectorListItemSummary
    | InspectorListItemInactivity
    | InspectorListItemAppState
    | InspectorListSessionChange
    | InspectorListItemLog
    | InspectorListItemExperimentVariant
    | InspectorListItemMetricEvent

export interface PlayerInspectorLogicProps extends SessionRecordingPlayerLogicProps {
    matchingEventsMatchType?: MatchingEventsMatchType
}

/** Merges adjacent inactivity items into one with a combined duration. */
function mergeAdjacentInactivity(items: InspectorListItem[]): InspectorListItem[] {
    return items.reduce((acc, item) => {
        const previousItem = acc[acc.length - 1]
        if (item.type === 'inactivity' && previousItem?.type === 'inactivity') {
            acc[acc.length - 1] = { ...previousItem, durationMs: previousItem.durationMs + item.durationMs }
            return acc
        }
        acc.push(item)
        return acc
    }, [] as InspectorListItem[])
}

export type DisplayGroup = { indices: number[] }

function canGroup(current: InspectorListItem, next: InspectorListItem): boolean {
    if (current.type !== next.type || current.highlightColor !== next.highlightColor) {
        return false
    }
    switch (current.type) {
        case 'events':
            return next.type === 'events' && current.data.event === next.data.event && current.search === next.search
        case 'console':
            return next.type === 'console' && current.data.content === next.data.content
        default:
            return false
    }
}

/** Groups adjacent identical events and console logs into display rows. */
export function computeDisplayGroups(items: InspectorListItem[], groupSimilar: boolean): DisplayGroup[] {
    const groups: DisplayGroup[] = []

    for (let i = 0; i < items.length; i++) {
        if (groupSimilar && groups.length > 0) {
            const lastGroup = groups[groups.length - 1]
            if (canGroup(items[lastGroup.indices[0]], items[i])) {
                lastGroup.indices.push(i)
                continue
            }
        }

        groups.push({ indices: [i] })
    }

    return groups
}

function _isCustomSnapshot(x: unknown): x is customEvent {
    // rrweb types `data.tag` as a required string, but captured snapshots reach us without it,
    // and every consumer below reads the tag as one
    return (x as customEvent).type === 5 && isString((x as customEvent).data?.tag)
}

function _isPluginSnapshot(x: unknown): x is pluginEvent {
    return (x as pluginEvent).type === 6
}

function isFullSnapshotEvent(x: unknown): x is fullSnapshotEvent {
    return (x as fullSnapshotEvent).type === 2
}

function snapshotDescription(snapshot: eventWithTime): string {
    const snapshotTypeName = RRWebEventType[snapshot.type]
    let suffix = ''
    if (_isCustomSnapshot(snapshot)) {
        suffix = ': ' + (snapshot as customEvent).data.tag
    }
    if (_isPluginSnapshot(snapshot)) {
        suffix = ': ' + (snapshot as pluginEvent).data.plugin
    }
    return snapshotTypeName + suffix
}

function timeRelativeToStart(
    thingWithTime:
        | eventWithTime
        | PerformanceEvent
        | RecordingConsoleLogV2
        | RecordingEventType
        | { timestamp: string }
        | { timestamp: number },
    start: Dayjs | null
): {
    timeInRecording: number
    timestamp: dayjs.Dayjs
} {
    const timestamp = dayjs(thingWithTime.timestamp)
    const timeInRecording = timestamp.valueOf() - (start?.valueOf() ?? 0)
    return { timestamp, timeInRecording }
}

function niceify(tag: string): string {
    return tag.replace(/\$/g, '').replace(/_/g, ' ')
}

function estimateSize(snapshot: unknown): number {
    return new Blob([JSON.stringify(snapshot || '')]).size
}

function getPayloadFor(customEvent: customEvent, tag: string): Record<string, any> {
    if (tag === '$posthog_config') {
        return (customEvent.data.payload as any)?.config as Record<string, any>
    }

    if (tag === '$session_options') {
        return {
            ...((customEvent.data.payload as any)?.sessionRecordingOptions as Record<string, any>),
            activePlugins: (customEvent.data.payload as any)?.activePlugins,
        }
    }

    return customEvent.data.payload as Record<string, any>
}

function notebookCommentTimestamp(
    timeInRecording: number,
    start: Dayjs | null
): {
    timeInRecording: number
    timestamp: dayjs.Dayjs | undefined
} {
    const timestamp = start?.add(timeInRecording, 'ms')
    return { timestamp, timeInRecording }
}

function commentTimestamp(
    commentTime: Dayjs,
    start: Dayjs | null
): {
    timeInRecording: number
    timestamp: dayjs.Dayjs | undefined
} {
    return { timestamp: commentTime, timeInRecording: commentTime.valueOf() - (start?.valueOf() ?? 0) }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface playerInspectorLogicValues {
    featureFlags: FeatureFlagsSet // featureFlagLogic
    groupRepeatedItems: boolean // miniFiltersLogic
    miniFilters: SharedListMiniFilter[] // miniFiltersLogic
    miniFiltersByKey: {
        [key: string]: SharedListMiniFilter
    } // miniFiltersLogic
    miniFiltersForTypeByKey: (tab: FilterableInspectorListItemTypes) => {
        [key: string]: SharedListMiniFilter
    } // miniFiltersLogic
    searchQuery: string // miniFiltersLogic
    showOnlyMatching: boolean // miniFiltersLogic
    allPerformanceEvents: PerformanceEvent[] // performanceEventDataLogic
    logs: LogMessage[] // playerInspectorLogsLogic
    logsHasMore: boolean // playerInspectorLogsLogic
    logsInitialLoadRequested: boolean // playerInspectorLogsLogic
    logsLoadError: boolean // playerInspectorLogsLogic
    logsLoading: boolean // playerInspectorLogsLogic
    logsNextCursor: string | undefined // playerInspectorLogsLogic
    readyToLoadLogs: boolean // playerInspectorLogsLogic
    durationMs: number // sessionRecordingDataCoordinatorLogic
    end: Dayjs | null // sessionRecordingDataCoordinatorLogic
    segments: RecordingSegment[] // sessionRecordingDataCoordinatorLogic
    sessionComments: CommentType[] // sessionRecordingDataCoordinatorLogic
    sessionCommentsLoading: boolean // sessionRecordingDataCoordinatorLogic
    sessionEventsData: RecordingEventType[] | null // sessionRecordingDataCoordinatorLogic
    sessionEventsDataLoading: boolean // sessionRecordingDataCoordinatorLogic
    sessionNotebookComments: any // sessionRecordingDataCoordinatorLogic
    sessionPlayerData: SessionPlayerData // sessionRecordingDataCoordinatorLogic
    sessionPlayerMetaData: SessionRecordingType | null // sessionRecordingDataCoordinatorLogic
    sessionPlayerMetaDataLoading: boolean // sessionRecordingDataCoordinatorLogic
    snapshotsLoading: boolean // sessionRecordingDataCoordinatorLogic
    start: Dayjs | null // sessionRecordingDataCoordinatorLogic
    trackedWindow: number | null // sessionRecordingDataCoordinatorLogic
    uuidToIndex: Record<string, number> // sessionRecordingDataCoordinatorLogic
    windowIdForTimestamp: (timestamp: number) => number | undefined // sessionRecordingDataCoordinatorLogic
    windowIds: number[] // sessionRecordingDataCoordinatorLogic
    experimentItems: ExperimentSessionContextItemApi[] // sessionRecordingExperimentContextLogic
    currentPlayerTime: number // sessionRecordingPlayerLogic
    currentTimestamp: number | undefined // sessionRecordingPlayerLogic
    doctorDiagnostics: DoctorDiagnostics | null // sessionRecordingPlayerLogic
    skipToFirstMatchingEvent: boolean // sessionRecordingPlayerLogic
    allContextItems: InspectorListItem[]
    allItems: {
        items: InspectorListItem[]
        itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
        itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
    }
    allItemsByItemType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
    allItemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
    allItemsList: InspectorListItem[]
    allowMatchingEventsFilter: boolean
    collapseInspectorItems: boolean
    commentItems: InspectorListItemComment[]
    displayGroups: DisplayGroup[]
    expandedItems: number[]
    experimentVariantItems: InspectorListItemExperimentVariant[]
    filteredItems: InspectorListItem[]
    fuse: Fuse
    hasEventsToDisplay: boolean
    hasSkippedToFirstMatchingEvent: boolean
    inspectorDataState: Record<FilterableInspectorListItemTypes, 'empty' | 'loading' | 'ready'>
    isLoading: boolean
    isReady: boolean
    items: InspectorListItem[]
    matchingEvents: MatchedRecordingEvent[] | null
    matchingEventsLoading: boolean
    metricEventItems: InspectorListItemMetricEvent[]
    notebookCommentItems: InspectorListItemNotebookComment[]
    playbackIndicatorIndex: number
    playbackIndicatorIndexStop: number
    processedSnapshotData: {
        appStateItems: InspectorListItemAppState[]
        browserVisibilityChanges: InspectorListBrowserVisibility[]
        consoleItems: InspectorListItemConsole[]
        contextItems: InspectorListItem[]
        doctorEvents: InspectorListItemDoctor[]
        offlineStatusChanges: InspectorListOfflineStatusChange[]
        rawConsoleLogs: RecordingConsoleLogV2[]
    }
    runtimeDoctorEvents: InspectorListItemDoctor[]
    seekbarItems: (
        | InspectorListItemComment
        | InspectorListItemEvent
        | InspectorListItemExperimentVariant
        | InspectorListItemMetricEvent
    )[]
    syncScrollPaused: boolean
    windowNumberForID: (windowId: number | undefined) => number | '?' | undefined
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface playerInspectorLogicActions {
    setMiniFilter: (
        key: string,
        enabled: boolean
    ) => {
        enabled: boolean
        key: string
    } // miniFiltersLogic
    setSearchQuery: (search: string) => {
        search: string
    } // miniFiltersLogic
    loadLogs: () => any // playerInspectorLogsLogic
    loadMoreLogs: () => any // playerInspectorLogsLogic
    markLogsInitialLoadRequested: () => {
        value: true
    } // playerInspectorLogsLogic
    loadEventsSuccess: (
        sessionEventsData: RecordingEventType[] | null,
        payload?:
            | {
                  value: true
              }
            | undefined
    ) => {
        payload?: {
            value: true
        }
        sessionEventsData: RecordingEventType[] | null
    } // sessionRecordingDataCoordinatorLogic
    loadFullEventData: (event: RecordingEventType | RecordingEventType[]) => {
        event: RecordingEventType | RecordingEventType[]
    } // sessionRecordingDataCoordinatorLogic
    loadRecordingMetaSuccess: (
        sessionPlayerMetaData: SessionRecordingType | null,
        payload?:
            | {
                  value: true
              }
            | undefined
    ) => {
        payload?: {
            value: true
        }
        sessionPlayerMetaData: SessionRecordingType | null
    } // sessionRecordingDataCoordinatorLogic
    registerWindowId: (uuid: string) => {
        uuid: string
    } // sessionRecordingDataCoordinatorLogic
    setTrackedWindow: (windowId: number | null) => {
        windowId: number | null
    } // sessionRecordingDataCoordinatorLogic
    reportRecordingInspectorItemExpanded: (
        tab:
            | 'app-state'
            | 'browser-visibility'
            | 'comment'
            | 'console'
            | 'doctor'
            | 'events'
            | 'experiment-variant'
            | 'inactivity'
            | 'inspector-summary'
            | 'logs'
            | 'metric-event'
            | 'network'
            | 'offline-status'
            | 'performance'
            | 'session-change',
        index: number
    ) => {
        index: number
        tab:
            | 'app-state'
            | 'browser-visibility'
            | 'comment'
            | 'console'
            | 'doctor'
            | 'events'
            | 'experiment-variant'
            | 'inactivity'
            | 'inspector-summary'
            | 'logs'
            | 'metric-event'
            | 'network'
            | 'offline-status'
            | 'performance'
            | 'session-change'
    } // sessionRecordingEventUsageLogic
    seekToTime: (
        timeInMilliseconds: number,
        forcePlay?: boolean | undefined
    ) => {
        forcePlay: boolean
        timeInMilliseconds: number
    } // sessionRecordingPlayerLogic
    setSkipToFirstMatchingEvent: (skipToFirstMatchingEvent: boolean) => {
        skipToFirstMatchingEvent: boolean
    } // sessionRecordingPlayerLogic
    setSkippingToMatchingEvent: (isSkippingToMatchingEvent: boolean) => {
        isSkippingToMatchingEvent: boolean
    } // sessionRecordingPlayerLogic
    startScrub: () => {
        value: true
    } // sessionRecordingPlayerLogic
    loadMatchingEvents: () => any
    loadMatchingEventsFailure: (
        error: string,
        errorObject?: any
    ) => {
        error: string
        errorObject?: any
    }
    loadMatchingEventsSuccess: (
        matchingEvents: MatchedRecordingEvent[] | null,
        payload?: any
    ) => {
        matchingEvents: MatchedRecordingEvent[] | null
        payload?: any
    }
    markSkippedToFirstMatchingEvent: () => {
        value: true
    }
    setItemExpanded: (
        index: number,
        expanded: boolean
    ) => {
        expanded: boolean
        index: number
    }
    setSyncScrollPaused: (paused: boolean) => {
        paused: boolean
    }
    trySkipToFirstMatchingEvent: () => {
        value: true
    }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface playerInspectorLogicMeta {
    key: string
    __keaTypeGenInternalSelectorTypes: {
        allowMatchingEventsFilter: (miniFilters: SharedListMiniFilter[]) => boolean
        windowNumberForID: (windowIds: number[]) => (windowId: number | undefined) => number | '?' | undefined
        collapseInspectorItems: (featureFlags: FeatureFlagsSet) => boolean
        processedSnapshotData: (
            start: Dayjs | null,
            sessionPlayerData: SessionPlayerData,
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            collapseInspectorItems: boolean
        ) => {
            appStateItems: InspectorListItemAppState[]
            browserVisibilityChanges: InspectorListBrowserVisibility[]
            consoleItems: InspectorListItemConsole[]
            contextItems: InspectorListItem[]
            doctorEvents: InspectorListItemDoctor[]
            offlineStatusChanges: InspectorListOfflineStatusChange[]
            rawConsoleLogs: RecordingConsoleLogV2[]
        }
        notebookCommentItems: (
            sessionNotebookComments: any,
            windowIdForTimestamp: (timestamp: number) => number | undefined, // sessionRecordingDataCoordinatorLogic
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            start: Dayjs | null
        ) => InspectorListItemNotebookComment[]
        commentItems: (
            sessionComments: CommentType[],
            windowIdForTimestamp: (timestamp: number) => number | undefined, // sessionRecordingDataCoordinatorLogic
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            start: Dayjs | null
        ) => InspectorListItemComment[]
        experimentVariantItems: (
            experimentItems: ExperimentSessionContextItemApi[],
            windowIdForTimestamp: (timestamp: number) => number | undefined, // sessionRecordingDataCoordinatorLogic
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            start: Dayjs | null
        ) => InspectorListItemExperimentVariant[]
        metricEventItems: (
            experimentItems: ExperimentSessionContextItemApi[],
            windowIdForTimestamp: (timestamp: number) => number | undefined, // sessionRecordingDataCoordinatorLogic
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            start: Dayjs | null
        ) => InspectorListItemMetricEvent[]
        runtimeDoctorEvents: (
            start: Dayjs | null,
            doctorDiagnostics: DoctorDiagnostics | null
        ) => InspectorListItemDoctor[]
        allContextItems: (
            start: Dayjs | null,
            processedSnapshotData: {
                appStateItems: InspectorListItemAppState[]
                browserVisibilityChanges: InspectorListBrowserVisibility[]
                consoleItems: InspectorListItemConsole[]
                contextItems: InspectorListItem[]
                doctorEvents: InspectorListItemDoctor[]
                offlineStatusChanges: InspectorListOfflineStatusChange[]
                rawConsoleLogs: RecordingConsoleLogV2[]
            },
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            sessionPlayerMetaData: SessionRecordingType | null,
            segments: import('@common/replay-shared/src').RecordingSegment[],
            runtimeDoctorEvents: InspectorListItemDoctor[],
            experimentVariantItems: InspectorListItemExperimentVariant[],
            metricEventItems: InspectorListItemMetricEvent[]
        ) => InspectorListItem[]
        allItems: (
            start: Dayjs | null,
            allPerformanceEvents: PerformanceEvent[],
            processedSnapshotData: {
                appStateItems: InspectorListItemAppState[]
                browserVisibilityChanges: InspectorListBrowserVisibility[]
                consoleItems: InspectorListItemConsole[]
                contextItems: InspectorListItem[]
                doctorEvents: InspectorListItemDoctor[]
                offlineStatusChanges: InspectorListOfflineStatusChange[]
                rawConsoleLogs: RecordingConsoleLogV2[]
            },
            sessionEventsData: RecordingEventType[] | null,
            matchingEvents: MatchedRecordingEvent[] | null,
            windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
            allContextItems: InspectorListItem[],
            commentItems: InspectorListItemComment[],
            notebookCommentItems: InspectorListItemNotebookComment[],
            sessionPlayerData: SessionPlayerData,
            miniFiltersByKey: {
                [key: string]: SharedListMiniFilter
            },
            uuidToIndex: Record<string, number>,
            logs: LogMessage[]
        ) => {
            items: InspectorListItem[]
            itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
            itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
        }
        filteredItems: (
            allItems: {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            },
            miniFiltersByKey: {
                [key: string]: SharedListMiniFilter
            },
            showOnlyMatching: boolean,
            allowMatchingEventsFilter: boolean,
            trackedWindow: number | null,
            hasEventsToDisplay: boolean
        ) => InspectorListItem[]
        seekbarItems: (
            allItems: {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            },
            miniFiltersByKey: {
                [key: string]: SharedListMiniFilter
            },
            showOnlyMatching: boolean,
            allowMatchingEventsFilter: boolean,
            trackedWindow: number | null,
            hasEventsToDisplay: boolean
        ) => (
            | InspectorListItemComment
            | InspectorListItemEvent
            | InspectorListItemExperimentVariant
            | InspectorListItemMetricEvent
        )[]
        inspectorDataState: (
            sessionEventsDataLoading: boolean,
            sessionPlayerMetaDataLoading: boolean,
            snapshotsLoading: boolean,
            sessionEventsData: RecordingEventType[] | null,
            processedSnapshotData: {
                appStateItems: InspectorListItemAppState[]
                browserVisibilityChanges: InspectorListBrowserVisibility[]
                consoleItems: InspectorListItemConsole[]
                contextItems: InspectorListItem[]
                doctorEvents: InspectorListItemDoctor[]
                offlineStatusChanges: InspectorListOfflineStatusChange[]
                rawConsoleLogs: RecordingConsoleLogV2[]
            },
            allPerformanceEvents: PerformanceEvent[],
            sessionComments: CommentType[],
            sessionCommentsLoading: boolean,
            logsLoading: boolean,
            logs: LogMessage[]
        ) => Record<FilterableInspectorListItemTypes, 'empty' | 'loading' | 'ready'>
        isLoading: (
            inspectorDataState: Record<
                'comment' | 'console' | 'doctor' | 'events' | 'logs' | 'network',
                'empty' | 'loading' | 'ready'
            >
        ) => boolean
        isReady: (
            inspectorDataState: Record<
                'comment' | 'console' | 'doctor' | 'events' | 'logs' | 'network',
                'empty' | 'loading' | 'ready'
            >
        ) => boolean
        playbackIndicatorIndex: (
            currentPlayerTime: number,
            items: InspectorListItem[],
            displayGroups: DisplayGroup[]
        ) => number
        playbackIndicatorIndexStop: (playbackIndicatorIndex: number, displayGroups: DisplayGroup[]) => number
        fuse: (filteredItems: InspectorListItem[]) => Fuse
        items: (filteredItems: InspectorListItem[], fuse: Fuse, searchQuery: string) => InspectorListItem[]
        displayGroups: (
            items: InspectorListItem[],
            groupRepeatedItems: boolean,
            collapseInspectorItems: boolean
        ) => DisplayGroup[]
        allItemsList: (allItems: {
            items: InspectorListItem[]
            itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
            itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
        }) => InspectorListItem[]
        allItemsByMiniFilterKey: (allItems: {
            items: InspectorListItem[]
            itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
            itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
        }) => Record<MiniFilterKey, InspectorListItem[]>
        allItemsByItemType: (allItems: {
            items: InspectorListItem[]
            itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
            itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
        }) => Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
        hasEventsToDisplay: (
            allItemsByItemType: Record<
                'comment' | 'console' | 'context' | 'doctor' | 'events' | 'logs' | 'network',
                InspectorListItem[]
            >
        ) => boolean
    }
}

export type playerInspectorLogicType = MakeLogicType<
    playerInspectorLogicValues,
    playerInspectorLogicActions,
    PlayerInspectorLogicProps,
    playerInspectorLogicMeta
>

export const playerInspectorLogic = kea<playerInspectorLogicType>([
    path((key) => ['scenes', 'session-recordings', 'player', 'playerInspectorLogic', key]),
    props({} as PlayerInspectorLogicProps),
    key((props: PlayerInspectorLogicProps) => `${props.playerKey}-${props.sessionRecordingId}`),
    connect((props: PlayerInspectorLogicProps) => ({
        actions: [
            miniFiltersLogic,
            ['setMiniFilter', 'setSearchQuery'],
            sessionRecordingEventUsageLogic,
            ['reportRecordingInspectorItemExpanded'],
            sessionRecordingDataCoordinatorLogic(props),
            [
                'loadFullEventData',
                'setTrackedWindow',
                'registerWindowId',
                'loadEventsSuccess',
                'loadRecordingMetaSuccess',
            ],
            sessionRecordingPlayerLogic(props),
            ['seekToTime', 'setSkippingToMatchingEvent', 'setSkipToFirstMatchingEvent', 'startScrub'],
            playerInspectorLogsLogic(props),
            ['loadLogs', 'loadMoreLogs', 'markLogsInitialLoadRequested'],
        ],
        values: [
            miniFiltersLogic,
            [
                'showOnlyMatching',
                'groupRepeatedItems',
                'miniFiltersByKey',
                'searchQuery',
                'miniFiltersForTypeByKey',
                'miniFilters',
            ],
            sessionRecordingDataCoordinatorLogic(props),
            [
                'sessionPlayerData',
                'sessionPlayerMetaDataLoading',
                'snapshotsLoading',
                'sessionEventsData',
                'sessionEventsDataLoading',
                'windowIds',
                'start',
                'end',
                'durationMs',
                'sessionNotebookComments',
                'sessionComments',
                'sessionCommentsLoading',
                'windowIdForTimestamp',
                'sessionPlayerMetaData',
                'segments',
                'trackedWindow',
                'uuidToIndex',
            ],
            sessionRecordingPlayerLogic(props),
            ['currentPlayerTime', 'currentTimestamp', 'skipToFirstMatchingEvent', 'doctorDiagnostics'],
            performanceEventDataLogic({ key: props.playerKey, sessionRecordingId: props.sessionRecordingId }),
            ['allPerformanceEvents'],
            featureFlagLogic,
            ['featureFlags'],
            sessionRecordingExperimentContextLogic({ sessionRecordingId: props.sessionRecordingId }),
            ['experimentItems'],
            playerInspectorLogsLogic(props),
            [
                'logs',
                'logsLoading',
                'logsHasMore',
                'logsNextCursor',
                'logsLoadError',
                'logsInitialLoadRequested',
                'readyToLoadLogs',
            ],
        ],
    })),
    actions(() => ({
        setItemExpanded: (index: number, expanded: boolean) => ({ index, expanded }),
        setSyncScrollPaused: (paused: boolean) => ({ paused }),
        trySkipToFirstMatchingEvent: true,
        markSkippedToFirstMatchingEvent: true,
    })),
    reducers(() => ({
        expandedItems: [
            [] as number[],
            {
                setItemExpanded: (items, { index, expanded }) => {
                    return expanded ? [...items, index] : items.filter((item) => item !== index)
                },
                setMiniFilter: () => [],
                setSearchQuery: () => [],
                setTrackedWindow: () => [],
            },
        ],

        syncScrollPaused: [
            false,
            {
                setSyncScrollPaused: (_, { paused }) => paused,
                setItemExpanded: () => true,
            },
        ],
        // Once set, the auto-skip is consumed for this recording and never re-arms: matching
        // events can reload without user intent (playlist filters changing under an open
        // recording, e.g. an async session-id list resolving), and a reload-triggered reset
        // would yank the playhead mid-playback.
        hasSkippedToFirstMatchingEvent: [
            false,
            {
                markSkippedToFirstMatchingEvent: () => true,
                // A seek or scrub also consumes a pending auto-skip: the matching-events query
                // can resolve seconds into playback, and yanking the playhead after the viewer
                // has already navigated is worse than not skipping at all.
                seekToTime: () => true,
                startScrub: () => true,
            },
        ],
    })),
    loaders(({ props }) => ({
        matchingEvents: [
            [] as MatchedRecordingEvent[] | null,
            {
                loadMatchingEvents: async () => {
                    const matchingEventsMatchType = props.matchingEventsMatchType
                    const matchType = matchingEventsMatchType?.matchType
                    if (!matchingEventsMatchType || matchType === 'none' || matchType === 'name') {
                        return null
                    }

                    if (matchType === 'uuid') {
                        if (!matchingEventsMatchType?.matchedEvents) {
                            console.error('UUID matching events type must include its array of matched events')
                        }
                        return matchingEventsMatchType.matchedEvents
                    }

                    const filters = matchingEventsMatchType?.filters
                    if (!filters) {
                        throw new Error('Backend matching events type must include its filters')
                    }

                    const params: RecordingsQuery = {
                        ...convertUniversalFiltersToRecordingsQuery(filters),
                        session_ids: [props.sessionRecordingId],
                    }

                    const response = await api.recordings.getMatchingEvents(toParams(params))
                    return response.results
                },
            },
        ],
    })),
    selectors(({ props }) => ({
        allowMatchingEventsFilter: [
            (s) => [s.miniFilters],
            (
                miniFilters: import('scenes/session-recordings/player/inspector/miniFiltersLogic').SharedListMiniFilter[]
            ): boolean => {
                return (
                    miniFilters.some((mf) => mf.type === 'events' && mf.enabled) &&
                    props.matchingEventsMatchType?.matchType !== 'none'
                )
            },
        ],

        windowNumberForID: [
            (s) => [s.windowIds],
            (windowIds: number[]) => {
                // windowId is already 1-indexed from the registry
                return (windowId: number | undefined): number | '?' | undefined => {
                    if (windowIds.length <= 1) {
                        return undefined
                    }
                    if (windowId === undefined) {
                        return '?'
                    }
                    return windowId
                }
            },
        ],

        collapseInspectorItems: [
            (s) => [s.featureFlags],
            (featureFlags: import('lib/logic/featureFlagLogic').FeatureFlagsSet): boolean =>
                !!featureFlags[FEATURE_FLAGS.REPLAY_COLLAPSE_INSPECTOR_ITEMS],
        ],

        processedSnapshotData: [
            (s) => [s.start, s.sessionPlayerData, s.windowNumberForID, s.collapseInspectorItems],
            (
                start: Dayjs | null,
                sessionPlayerData: import('~/types').SessionPlayerData,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                collapseInspectorItems: boolean
            ): {
                offlineStatusChanges: InspectorListOfflineStatusChange[]
                browserVisibilityChanges: InspectorListBrowserVisibility[]
                doctorEvents: InspectorListItemDoctor[]
                consoleItems: InspectorListItemConsole[]
                appStateItems: InspectorListItemAppState[]
                contextItems: InspectorListItem[]
                rawConsoleLogs: RecordingConsoleLogV2[]
            } => {
                const offlineStatusChanges: InspectorListOfflineStatusChange[] = []
                const browserVisibilityChanges: InspectorListBrowserVisibility[] = []
                const doctorEvents: InspectorListItemDoctor[] = []
                const consoleLogs: RecordingConsoleLogV2[] = []
                const consoleItems: InspectorListItemConsole[] = []
                const appStateItems: InspectorListItemAppState[] = []
                const snapshotCounts: Record<string, Record<string, number>> = {}
                const consoleLogSeenCache = new Set<string>()
                const sessionChangeItems: InspectorListSessionChange[] = []

                // Single pass through all snapshots
                Object.entries(sessionPlayerData.snapshotsByWindowId).forEach(([windowIdStr, snapshots]) => {
                    const windowId = Number(windowIdStr)
                    if (!snapshotCounts[windowId]) {
                        snapshotCounts[windowId] = {}
                    }

                    ;(snapshots as eventWithTime[]).forEach((snapshot: eventWithTime) => {
                        // Track snapshot counts for doctor events
                        const description = snapshotDescription(snapshot)
                        snapshotCounts[windowId][description] = (snapshotCounts[windowId][description] || 0) + 1

                        // Process custom events (type 5)
                        if (_isCustomSnapshot(snapshot)) {
                            const customEvent = snapshot as customEvent
                            const tag = customEvent.data.tag
                            const { timestamp, timeInRecording } = timeRelativeToStart(snapshot, start || dayjs())

                            // Offline status changes
                            if (['browser offline', 'browser online'].includes(tag)) {
                                offlineStatusChanges.push({
                                    type: 'offline-status',
                                    offline: tag === 'browser offline',
                                    timestamp: timestamp,
                                    timeInRecording: timeInRecording,
                                    search: tag,
                                    windowId: windowId,
                                    windowNumber: windowNumberForID(windowId),
                                    highlightColor: 'warning',
                                    key: `${timestamp.valueOf()}-offline-status-${tag}`,
                                } satisfies InspectorListOfflineStatusChange)
                            }

                            if (['$session_ending', '$session_starting'].includes(tag)) {
                                const item: InspectorListSessionChange = {
                                    type: 'session-change',
                                    timestamp: timestamp,
                                    timeInRecording: timeInRecording,
                                    search: tag,
                                    tag: tag as '$session_starting' | '$session_ending',
                                    data: customEvent.data.payload as SessionChangePayload,
                                    windowId: windowId,
                                    windowNumber: windowNumberForID(windowId),
                                    key: `${timestamp.valueOf()}-session-change-${tag}`,
                                }
                                sessionChangeItems.push(item)
                            }

                            // Browser visibility changes
                            if (['window hidden', 'window visible'].includes(tag)) {
                                browserVisibilityChanges.push({
                                    type: 'browser-visibility',
                                    status: tag === 'window hidden' ? 'hidden' : 'visible',
                                    timestamp: timestamp,
                                    timeInRecording: timeInRecording,
                                    search: tag,
                                    windowId: windowId,
                                    windowNumber: windowNumberForID(windowId),
                                    highlightColor: 'warning',
                                    key: `${timestamp.valueOf()}-browser-visibility-${tag}`,
                                } satisfies InspectorListBrowserVisibility)
                            }

                            // App state items
                            if (tag === 'app-state') {
                                const payload = customEvent.data.payload as {
                                    title: string
                                    stateEvent: Record<string, any>
                                }
                                const actionTitle = payload?.title as string
                                const stateEvent = payload?.stateEvent as Record<string, any>
                                if (actionTitle && stateEvent) {
                                    appStateItems.push({
                                        type: 'app-state',
                                        timestamp,
                                        timeInRecording,
                                        action: actionTitle,
                                        search: actionTitle,
                                        windowId: windowId,
                                        windowNumber: windowNumberForID(windowId),
                                        stateEvent,
                                        key: `${timestamp.valueOf()}-app-state-${actionTitle}`,
                                    })
                                }
                            }

                            // Doctor events (other custom events)
                            if (
                                start &&
                                ![
                                    '$pageview',
                                    'window hidden',
                                    'browser offline',
                                    'browser online',
                                    'window visible',
                                    'app-state',
                                ].includes(tag)
                            ) {
                                doctorEvents.push({
                                    type: 'doctor',
                                    timestamp,
                                    timeInRecording,
                                    tag: niceify(tag),
                                    search: niceify(tag),
                                    windowId: windowId,
                                    windowNumber: windowNumberForID(windowId),
                                    data: getPayloadFor(customEvent, tag),
                                    key: `${timestamp.valueOf()}-doctor-${tag}`,
                                })
                            }
                        }

                        // Process full snapshot events
                        if (isFullSnapshotEvent(snapshot) && start) {
                            const { timestamp, timeInRecording } = timeRelativeToStart(snapshot, start)
                            doctorEvents.push({
                                type: 'doctor',
                                timestamp,
                                timeInRecording,
                                tag: 'full snapshot event',
                                search: 'full snapshot event',
                                windowId: windowId,
                                windowNumber: windowNumberForID(windowId),
                                data: { snapshotSize: humanizeBytes(estimateSize(snapshot)) },
                                key: `${timestamp.valueOf()}-doctor-full-snapshot`,
                            })
                        }

                        // Process plugin snapshots (console logs)
                        if (_isPluginSnapshot(snapshot) && snapshot.data.plugin === CONSOLE_LOG_PLUGIN_NAME) {
                            const data = snapshot.data.payload as RRWebRecordingConsoleLogPayload | undefined
                            // A console log snapshot without a payload has nothing to show. Skip it so one
                            // malformed event does not take down the whole player.
                            if (!data) {
                                return
                            }
                            const { level, payload, trace } = data
                            const lines = (Array.isArray(payload) ? payload : [payload]).filter((x) => !!x) as string[]
                            const content = lines.join('\n')
                            const cacheKey = `${snapshot.timestamp}::${content}`

                            if (!consoleLogSeenCache.has(cacheKey)) {
                                consoleLogSeenCache.add(cacheKey)

                                const collapseConsole = !collapseInspectorItems
                                const lastLogLine = consoleLogs[consoleLogs.length - 1]
                                if (collapseConsole && lastLogLine?.content === content) {
                                    if (lastLogLine.count === undefined) {
                                        lastLogLine.count = 1
                                    } else {
                                        lastLogLine.count += 1
                                    }
                                } else {
                                    const consoleLog = {
                                        timestamp: snapshot.timestamp,
                                        windowId: windowId,
                                        windowNumber: windowNumberForID(windowId),
                                        content,
                                        lines,
                                        level,
                                        trace,
                                        count: 1,
                                    }
                                    consoleLogs.push(consoleLog)

                                    // Also create the inspector list item
                                    const { timestamp: itemTimestamp, timeInRecording } = timeRelativeToStart(
                                        consoleLog,
                                        start || dayjs()
                                    )
                                    consoleItems.push({
                                        type: 'console',
                                        timestamp: itemTimestamp,
                                        timeInRecording,
                                        search: content,
                                        data: consoleLog,
                                        highlightColor:
                                            level === 'error' ? 'danger' : level === 'warn' ? 'warning' : undefined,
                                        windowId: windowId,
                                        windowNumber: windowNumberForID(windowId),
                                        key: `${itemTimestamp.valueOf()}-console-${level}-${consoleLogs.length - 1}`,
                                    })
                                }
                            }
                        }
                    })
                })

                // Add the snapshot counts summary to doctor events
                if (start) {
                    doctorEvents.push({
                        type: 'doctor',
                        timestamp: start,
                        timeInRecording: 0,
                        tag: 'count of snapshot types by window',
                        search: 'count of snapshot types by window',
                        data: snapshotCounts,
                        key: `${start.valueOf()}-doctor-snapshot-counts`,
                    })
                }

                const contextItems: InspectorListItem[] = [
                    ...offlineStatusChanges,
                    ...browserVisibilityChanges,
                    ...doctorEvents,
                    ...sessionChangeItems,
                ]

                return {
                    offlineStatusChanges,
                    browserVisibilityChanges,
                    doctorEvents,
                    consoleItems,
                    appStateItems,
                    contextItems,
                    rawConsoleLogs: consoleLogs,
                }
            },
            { resultEqualityCheck: equal },
        ],

        notebookCommentItems: [
            (s) => [s.sessionNotebookComments, s.windowIdForTimestamp, s.windowNumberForID, s.start],
            (
                sessionNotebookComments,
                windowIdForTimestamp: (timestamp: number) => number | undefined,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                start: Dayjs | null
            ): InspectorListItemNotebookComment[] => {
                const items: InspectorListItemNotebookComment[] = []
                for (const comment of sessionNotebookComments || []) {
                    const { timestamp, timeInRecording } = notebookCommentTimestamp(comment.timeInRecording, start)
                    if (timestamp) {
                        items.push({
                            highlightColor: 'primary',
                            type: 'comment',
                            source: 'notebook',
                            timeInRecording: timeInRecording,
                            timestamp: timestamp,
                            search: comment.comment,
                            data: comment,
                            windowId: windowIdForTimestamp(timestamp.valueOf()),
                            windowNumber: windowNumberForID(windowIdForTimestamp(timestamp.valueOf())),
                            key: `notebook-comment-${comment.id}`,
                        })
                    }
                }
                return items
            },
            {
                resultEqualityCheck: equal,
            },
        ],

        commentItems: [
            (s) => [s.sessionComments, s.windowIdForTimestamp, s.windowNumberForID, s.start],
            (
                sessionComments: CommentType[],
                windowIdForTimestamp: (timestamp: number) => number | undefined,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                start: Dayjs | null
            ): InspectorListItemComment[] => {
                const items: InspectorListItemComment[] = []
                for (const comment of sessionComments || []) {
                    if (!comment.item_context?.time_in_recording) {
                        continue
                    }

                    const { timestamp, timeInRecording } = commentTimestamp(
                        dayjs(comment.item_context.time_in_recording),
                        start
                    )
                    if (timestamp) {
                        const item: InspectorListItemComment = {
                            timestamp,
                            timeInRecording,
                            type: 'comment',
                            source: 'comment',
                            highlightColor: 'primary',
                            windowId: windowIdForTimestamp(timestamp.valueOf()),
                            windowNumber: windowNumberForID(windowIdForTimestamp(timestamp.valueOf())),
                            data: comment,
                            search: getText(comment),
                            key: `comment-${comment.id}`,
                        }
                        items.push(item)
                    }
                }
                return items
            },
            { resultEqualityCheck: equal },
        ],

        experimentVariantItems: [
            (s) => [s.experimentItems, s.windowIdForTimestamp, s.windowNumberForID, s.start],
            (
                experimentItems: import('products/experiments/frontend/generated/api.schemas').ExperimentSessionContextItemApi[],
                windowIdForTimestamp: (timestamp: number) => number | undefined,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                start: Dayjs | null
            ): InspectorListItemExperimentVariant[] => {
                const items: InspectorListItemExperimentVariant[] = []
                for (const item of experimentItems || []) {
                    // Without an exposure event in this session there is no in-session moment
                    // to mark — the variant is only known from stamped flag properties.
                    if (!item.first_exposure_timestamp) {
                        continue
                    }
                    const { timestamp, timeInRecording } = timeRelativeToStart(
                        { timestamp: item.first_exposure_timestamp },
                        start
                    )
                    items.push({
                        type: 'experiment-variant',
                        timestamp,
                        timeInRecording,
                        search: `experiment variant ${item.experiment_name} ${item.variant}`,
                        windowId: windowIdForTimestamp(timestamp.valueOf()),
                        windowNumber: windowNumberForID(windowIdForTimestamp(timestamp.valueOf())),
                        data: {
                            id: `experiment-variant-${item.experiment_id}`,
                            experimentId: item.experiment_id,
                            experimentName: item.experiment_name,
                            flagKey: item.flag_key,
                            variant: item.variant,
                            multipleVariants: item.multiple_variants,
                            variantsSeen: item.variants_seen,
                        },
                        key: `experiment-variant-${item.experiment_id}`,
                    })
                }
                return items
            },
            { resultEqualityCheck: equal },
        ],

        metricEventItems: [
            (s) => [s.experimentItems, s.windowIdForTimestamp, s.windowNumberForID, s.start],
            (
                experimentItems: import('products/experiments/frontend/generated/api.schemas').ExperimentSessionContextItemApi[],
                windowIdForTimestamp: (timestamp: number) => number | undefined,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                start: Dayjs | null
            ): InspectorListItemMetricEvent[] => {
                const items: InspectorListItemMetricEvent[] = []
                for (const item of experimentItems || []) {
                    // One marker per metric the session hit, at its first occurrence — the direct
                    // mirror of the exposure marker (which marks the first exposure moment).
                    for (const hit of item.metrics_in_session || []) {
                        const { timestamp, timeInRecording } = timeRelativeToStart(
                            { timestamp: hit.first_timestamp },
                            start
                        )
                        items.push({
                            type: 'metric-event',
                            timestamp,
                            timeInRecording,
                            search: `metric ${item.experiment_name} ${hit.metric_name}`,
                            windowId: windowIdForTimestamp(timestamp.valueOf()),
                            windowNumber: windowNumberForID(windowIdForTimestamp(timestamp.valueOf())),
                            data: {
                                id: `metric-event-${item.experiment_id}-${hit.metric_uuid}`,
                                experimentId: item.experiment_id,
                                experimentName: item.experiment_name,
                                metricName: hit.metric_name,
                                eventCount: hit.event_count,
                            },
                            key: `metric-event-${item.experiment_id}-${hit.metric_uuid}`,
                        })
                    }
                }
                return items
            },
            { resultEqualityCheck: equal },
        ],

        runtimeDoctorEvents: [
            (s) => [s.start, s.doctorDiagnostics],
            (start: Dayjs | null, doctorDiagnostics: DoctorDiagnostics | null): InspectorListItemDoctor[] => {
                if (!start) {
                    return []
                }

                const items: InspectorListItemDoctor[] = []

                if (doctorDiagnostics && doctorDiagnostics.assetErrorTotal > 0) {
                    items.push({
                        type: 'doctor',
                        timestamp: start,
                        timeInRecording: 0,
                        tag: `asset errors (${doctorDiagnostics.assetErrorTotal} total)`,
                        search: `asset errors ${doctorDiagnostics.assetErrorTypeNames}`,
                        data: doctorDiagnostics.assetErrors,
                        highlightColor: 'warning',
                        key: 'doctor-asset-errors',
                    })
                }

                const warningCount = doctorDiagnostics?.rrwebWarningCount ?? 0
                if (doctorDiagnostics && warningCount > 0) {
                    const summary = doctorDiagnostics.rrwebWarningSummary ?? {}
                    items.push({
                        type: 'doctor',
                        timestamp: start,
                        timeInRecording: 0,
                        tag: `rrweb warnings (${warningCount})`,
                        search: 'rrweb warnings',
                        data: Object.keys(summary).length > 0 ? summary : { total: warningCount },
                        highlightColor: 'warning',
                        key: 'doctor-rrweb-warnings',
                    })
                }

                return items
            },
            { resultEqualityCheck: equal },
        ],

        allContextItems: [
            (s) => [
                s.start,
                s.processedSnapshotData,
                s.windowNumberForID,
                s.sessionPlayerMetaData,
                s.segments,
                s.runtimeDoctorEvents,
                s.experimentVariantItems,
                s.metricEventItems,
            ],
            (
                start: Dayjs | null,
                processedSnapshotData: {
                    appStateItems: InspectorListItemAppState[]
                    browserVisibilityChanges: InspectorListBrowserVisibility[]
                    consoleItems: InspectorListItemConsole[]
                    contextItems: InspectorListItem[]
                    doctorEvents: InspectorListItemDoctor[]
                    offlineStatusChanges: InspectorListOfflineStatusChange[]
                    rawConsoleLogs: RecordingConsoleLogV2[]
                },
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                sessionPlayerMetaData: null | import('~/types').SessionRecordingType,
                segments: import('~/types').RecordingSegment[],
                runtimeDoctorEvents: InspectorListItemDoctor[],
                experimentVariantItems: InspectorListItemExperimentVariant[],
                metricEventItems: InspectorListItemMetricEvent[]
            ) => {
                const items: InspectorListItem[] = []

                segments
                    .filter((segment) => segment.kind === 'gap')
                    .filter((segment) => segment.durationMs > 15000)
                    .map((segment) => {
                        const { timestamp, timeInRecording } = timeRelativeToStart(
                            { timestamp: segment.startTimestamp },
                            start
                        )
                        items.push({
                            type: 'inactivity',
                            durationMs: segment.durationMs,
                            windowId: segment.windowId,
                            windowNumber: windowNumberForID(segment.windowId),
                            timestamp,
                            timeInRecording,
                            search: 'inactiv',
                            key: `inactivity-${segment.startTimestamp}`,
                        })
                    })

                // Add all pre-processed context items
                // NOTE: not `items.push(...array)` — spreading an unbounded array into a call
                // blows the argument stack (RangeError) on very large recordings
                for (const item of processedSnapshotData?.contextItems || []) {
                    items.push(item)
                }

                // Add runtime doctor events (asset errors, rrweb warnings)
                for (const item of runtimeDoctorEvents) {
                    items.push(item)
                }

                // Add experiment first-exposure markers
                for (const item of experimentVariantItems) {
                    items.push(item)
                }

                // Add experiment metric first-hit markers
                for (const item of metricEventItems) {
                    items.push(item)
                }

                // now we've calculated everything else,
                // we always start with a context row
                // that lets us show a little summary
                if (start) {
                    items.push({
                        type: 'inspector-summary',
                        timestamp: start,
                        timeInRecording: 0,
                        search: '',
                        clickCount: sessionPlayerMetaData?.click_count || null,
                        keypressCount: sessionPlayerMetaData?.keypress_count || null,
                        errorCount: 0,
                        key: `inspector-summary-${start.valueOf()}`,
                    })
                }

                // NOTE: Native JS sorting is relatively slow here - be careful changing this
                items.sort((a, b) => (a.timestamp.valueOf() > b.timestamp.valueOf() ? 1 : -1))

                return items
            },
            { resultEqualityCheck: equal },
        ],

        allItems: [
            (s) => [
                s.start,
                s.allPerformanceEvents,
                s.processedSnapshotData,
                s.sessionEventsData,
                s.matchingEvents,
                s.windowNumberForID,
                s.allContextItems,
                s.commentItems,
                s.notebookCommentItems,
                s.sessionPlayerData,
                s.miniFiltersByKey,
                s.uuidToIndex,
                s.logs,
            ],
            (
                start: Dayjs | null,
                performanceEvents: PerformanceEvent[],
                processedSnapshotData: {
                    appStateItems: InspectorListItemAppState[]
                    browserVisibilityChanges: InspectorListBrowserVisibility[]
                    consoleItems: InspectorListItemConsole[]
                    contextItems: InspectorListItem[]
                    doctorEvents: InspectorListItemDoctor[]
                    offlineStatusChanges: InspectorListOfflineStatusChange[]
                    rawConsoleLogs: RecordingConsoleLogV2[]
                },
                eventsData: RecordingEventType[] | null,
                matchingEvents: MatchedRecordingEvent[] | null,
                windowNumberForID: (windowId: number | undefined) => number | '?' | undefined,
                allContextItems: InspectorListItem[],
                commentItems: InspectorListItemComment[],
                notebookCommentItems: InspectorListItemNotebookComment[],
                sessionPlayerData: import('~/types').SessionPlayerData,
                miniFiltersByKey: {
                    [key: string]: import('scenes/session-recordings/player/inspector/miniFiltersLogic').SharedListMiniFilter
                },
                uuidToIndex: Record<string, number>,
                logs: LogMessage[]
            ): {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            } => {
                // Create a local copy of the window ID map for synchronous lookups
                // New window IDs discovered here will be registered via listener
                const localUuidToIndex: Record<string, number> = { ...uuidToIndex }
                const getOrRegisterWindowId = (uuid: string): number => {
                    if (uuid in localUuidToIndex) {
                        return localUuidToIndex[uuid]
                    }
                    const index = Object.keys(localUuidToIndex).length + 1
                    localUuidToIndex[uuid] = index
                    return index
                }

                // Pre-compute categorizations during item creation
                const items: InspectorListItem[] = []
                const itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]> = {
                    'events-posthog': [],
                    'events-custom': [],
                    'events-pageview': [],
                    'events-autocapture': [],
                    'events-exceptions': [],
                    'console-info': [],
                    'console-warn': [],
                    'console-error': [],
                    'console-app-state': [],
                    'performance-fetch': [],
                    'performance-document': [],
                    'performance-assets-js': [],
                    'performance-assets-css': [],
                    'performance-assets-img': [],
                    'performance-other': [],
                    comment: [],
                    doctor: [],
                    'logs-info': [],
                    'logs-warn': [],
                    'logs-error': [],
                }
                const itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]> = {
                    ['events']: [],
                    ['console']: [],
                    ['network']: [],
                    ['doctor']: [],
                    ['comment']: [],
                    ['logs']: [],
                    context: [],
                }
                let summaryItem: InspectorListItemSummary | undefined

                // Helper function to add item and categorize it
                const addItem = (item: InspectorListItem): void => {
                    items.push(item)

                    // Categorize by mini-filter
                    const miniFilter = itemToMiniFilter(item, miniFiltersByKey)
                    if (miniFilter) {
                        itemsByMiniFilterKey[miniFilter.key].push(item)
                    }

                    // Categorize by type
                    const itemType = ['events', 'console', 'network', 'doctor', 'comment', 'logs'].includes(
                        item.type as FilterableInspectorListItemTypes
                    )
                        ? (item.type as FilterableInspectorListItemTypes | 'context')
                        : 'context'
                    itemsByType[itemType].push(item)
                }

                // PERFORMANCE EVENTS
                const performanceEventsArr = performanceEvents || []
                for (const event of performanceEventsArr) {
                    const responseStatus = event.response_status || null

                    if (event.entry_type === 'paint') {
                        // We don't include paint events as they are covered in the navigation events
                        continue
                    }

                    const { timestamp, timeInRecording } = timeRelativeToStart(event, start)
                    const windowId = event.window_id ? getOrRegisterWindowId(event.window_id) : undefined
                    addItem({
                        type: 'network',
                        timestamp,
                        timeInRecording,
                        search: event.name || '',
                        data: event,
                        highlightColor: (responseStatus || 0) >= 400 ? 'danger' : undefined,
                        windowId,
                        windowNumber: windowNumberForID(windowId),
                        key: `performance-${event.uuid ?? event.name ?? 'unknown'}-${timestamp.valueOf()}`,
                    })
                }

                // CONSOLE LOGS (already processed)
                for (const consoleItem of processedSnapshotData?.consoleItems || []) {
                    addItem(consoleItem)
                }

                let errorCount = 0
                for (const event of eventsData || []) {
                    // A malformed or missing event row must not crash the whole inspector list.
                    if (!event) {
                        continue
                    }

                    let isMatchingEvent = false

                    if (event.event === '$exception') {
                        errorCount += 1
                    }

                    if (matchingEvents?.length) {
                        isMatchingEvent = !!matchingEvents.find(
                            (x: MatchedRecordingEvent) => x.uuid === String(event.id)
                        )
                    } else if (props.matchingEventsMatchType?.matchType === 'name') {
                        isMatchingEvent = props.matchingEventsMatchType?.eventNames?.includes(event.event)
                    }

                    const search = `${
                        getCoreFilterDefinition(event.event, TaxonomicFilterGroupType.Events)?.label ??
                        event.event ??
                        ''
                    } ${eventToDescription(event)}`.replace(/['"]+/g, '')

                    const { timestamp, timeInRecording } = timeRelativeToStart(event, start)
                    const rawWindowId = event.properties?.$window_id
                    const windowId = rawWindowId ? getOrRegisterWindowId(rawWindowId) : undefined
                    addItem({
                        type: 'events',
                        timestamp,
                        timeInRecording,
                        search: search,
                        data: {
                            ...event,
                            distinct_id: sessionPlayerData.person?.distinct_ids?.[0] || event.distinct_id,
                        },
                        highlightColor: isMatchingEvent
                            ? 'primary'
                            : event.event === '$exception'
                              ? 'danger'
                              : undefined,
                        windowId,
                        windowNumber: windowNumberForID(windowId),
                        key: `event-${event.id}`,
                    })
                }

                for (const event of allContextItems || []) {
                    if (event.type === 'inspector-summary') {
                        summaryItem = event as InspectorListItemSummary
                        summaryItem.errorCount = errorCount
                    } else {
                        addItem(event)
                    }
                }

                for (const comment of commentItems || []) {
                    addItem(comment)
                }

                for (const notebookComment of notebookCommentItems || []) {
                    addItem(notebookComment)
                }

                for (const stateLogItem of processedSnapshotData?.appStateItems || []) {
                    addItem(stateLogItem)
                }

                for (const logEntry of logs || []) {
                    const logTimestamp = dayjs(logEntry.timestamp)
                    if (!logTimestamp.isValid()) {
                        continue
                    }
                    const timeInRecording = logTimestamp.valueOf() - (start?.valueOf() || 0)
                    const level = logEntry.level || 'info'
                    addItem({
                        type: 'logs',
                        timestamp: logTimestamp,
                        timeInRecording,
                        search: logEntry.body || '',
                        data: logEntry,
                        highlightColor:
                            level === 'error' || level === 'fatal'
                                ? 'danger'
                                : level === 'warn'
                                  ? 'warning'
                                  : undefined,
                        key: `log-${logEntry.uuid}`,
                    } satisfies InspectorListItemLog)
                }

                // NOTE: Native JS sorting is relatively slow here - be careful changing this
                items.sort((a, b) => (a.timestamp.valueOf() > b.timestamp.valueOf() ? 1 : -1))

                // Add summary item at the beginning if it exists
                if (summaryItem) {
                    items.unshift(summaryItem)
                    if (items.length > 1) {
                        items[0].windowNumber = items[1]?.windowNumber
                        items[0].windowId = items[1]?.windowId
                    }
                }

                return {
                    items,
                    itemsByMiniFilterKey,
                    itemsByType,
                }
            },
            { resultEqualityCheck: equal },
        ],

        filteredItems: [
            (s) => [
                s.allItems,
                s.miniFiltersByKey,
                s.showOnlyMatching,
                s.allowMatchingEventsFilter,
                s.trackedWindow,
                s.hasEventsToDisplay,
            ],
            (
                allItemsData: {
                    items: InspectorListItem[]
                    itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                    itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
                },
                miniFiltersByKey: {
                    [key: string]: import('scenes/session-recordings/player/inspector/miniFiltersLogic').SharedListMiniFilter
                },
                showOnlyMatching: boolean,
                allowMatchingEventsFilter: boolean,
                trackedWindow: number | null,
                hasEventsToDisplay: boolean
            ): InspectorListItem[] => {
                const filteredItems = filterInspectorListItems({
                    allItems: allItemsData.items,
                    miniFiltersByKey,
                    allowMatchingEventsFilter,
                    showOnlyMatching,
                    trackedWindow,
                    hasEventsToDisplay,
                })

                return mergeAdjacentInactivity(filteredItems)
            },
            { resultEqualityCheck: equal },
        ],

        seekbarItems: [
            (s) => [
                s.allItems,
                s.miniFiltersByKey,
                s.showOnlyMatching,
                s.allowMatchingEventsFilter,
                s.trackedWindow,
                s.hasEventsToDisplay,
            ],
            (
                allItemsData: {
                    items: InspectorListItem[]
                    itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                    itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
                },
                miniFiltersByKey: {
                    [key: string]: import('scenes/session-recordings/player/inspector/miniFiltersLogic').SharedListMiniFilter
                },
                showOnlyMatching: boolean,
                allowMatchingEventsFilter: boolean,
                trackedWindow: number | null,
                hasEventsToDisplay: boolean
            ): (
                | InspectorListItemEvent
                | InspectorListItemComment
                | InspectorListItemExperimentVariant
                | InspectorListItemMetricEvent
            )[] => {
                // Pre-filter to only events, comments and experiment markers, avoiding the full filterInspectorListItems call
                const eventAndCommentItems: (
                    | InspectorListItemEvent
                    | InspectorListItemComment
                    | InspectorListItemExperimentVariant
                    | InspectorListItemMetricEvent
                )[] = []

                for (const item of allItemsData.items) {
                    // Only process events, comments and experiment markers
                    if (
                        item.type !== 'events' &&
                        item.type !== 'comment' &&
                        item.type !== 'experiment-variant' &&
                        item.type !== 'metric-event'
                    ) {
                        continue
                    }

                    // Skip events if there are no events to display
                    if (item.type === 'events' && !hasEventsToDisplay) {
                        continue
                    }

                    // Apply tracking window filter early
                    if (trackedWindow && item.windowId !== trackedWindow) {
                        continue
                    }

                    // Type assertion since we've already checked the type
                    const typedItem = item as
                        | InspectorListItemEvent
                        | InspectorListItemComment
                        | InspectorListItemExperimentVariant
                        | InspectorListItemMetricEvent

                    // Apply event-specific filters
                    if (item.type === 'events') {
                        // Skip if matching events filter is active and item doesn't match
                        if (allowMatchingEventsFilter && showOnlyMatching && item.highlightColor !== 'primary') {
                            continue
                        }

                        // Apply mini-filters for events
                        const eventKey = `events-${item.data.event}` as keyof typeof miniFiltersByKey
                        const eventFilter = miniFiltersByKey[eventKey] || miniFiltersByKey['events-custom']
                        if (eventFilter && !eventFilter.enabled) {
                            continue
                        }
                    } else if (item.type === 'comment') {
                        // Apply mini-filters for comments
                        const commentFilter = miniFiltersByKey['comment']
                        if (commentFilter && !commentFilter.enabled) {
                            continue
                        }
                    }

                    eventAndCommentItems.push(typedItem)
                }

                // If we have too many items, apply priority filtering and sampling
                if (eventAndCommentItems.length > MAX_SEEKBAR_ITEMS) {
                    // First pass: keep only high-priority items
                    let priorityItems = eventAndCommentItems.filter((item) => {
                        const isPrimary = item.highlightColor === 'primary'
                        const isPageView = item.type === 'events' && item.data.event === '$pageview'
                        const isComment = item.type === 'comment'
                        const isExperimentVariant = item.type === 'experiment-variant'
                        const isMetricEvent = item.type === 'metric-event'
                        return isPrimary || isPageView || isComment || isExperimentVariant || isMetricEvent
                    })

                    // If still too many, sample them
                    if (priorityItems.length > MAX_SEEKBAR_ITEMS) {
                        const step = Math.ceil(priorityItems.length / MAX_SEEKBAR_ITEMS)
                        priorityItems = priorityItems.filter((_, i) => i % step === 0)
                    }

                    return priorityItems
                }

                return eventAndCommentItems
            },
            { resultEqualityCheck: equal },
        ],

        inspectorDataState: [
            (s) => [
                s.sessionEventsDataLoading,
                s.sessionPlayerMetaDataLoading,
                s.snapshotsLoading,
                s.sessionEventsData,
                s.processedSnapshotData,
                s.allPerformanceEvents,
                s.sessionComments,
                s.sessionCommentsLoading,
                s.logsLoading,
                s.logs,
            ],
            (
                sessionEventsDataLoading: boolean,
                sessionPlayerMetaDataLoading: boolean,
                snapshotsLoading: boolean,
                events: RecordingEventType[] | null,
                processedSnapshotData: {
                    offlineStatusChanges: InspectorListOfflineStatusChange[]
                    browserVisibilityChanges: InspectorListBrowserVisibility[]
                    doctorEvents: InspectorListItemDoctor[]
                    consoleLogs: RecordingConsoleLogV2[]
                    appStateItems: InspectorListItemAppState[]
                } | null,
                performanceEvents: PerformanceEvent[] | null,
                sessionComments: CommentType[] | null,
                sessionCommentsLoading: boolean,
                logsLoading: boolean,
                logs: LogMessage[]
            ): Record<FilterableInspectorListItemTypes, 'loading' | 'ready' | 'empty'> => {
                const dataForEventsState = sessionEventsDataLoading ? 'loading' : events?.length ? 'ready' : 'empty'
                const dataForConsoleState =
                    sessionPlayerMetaDataLoading || snapshotsLoading || !processedSnapshotData
                        ? 'loading'
                        : processedSnapshotData?.consoleLogs?.length
                          ? 'ready'
                          : 'empty'
                const dataForNetworkState =
                    sessionPlayerMetaDataLoading || snapshotsLoading || !performanceEvents
                        ? 'loading'
                        : performanceEvents.length
                          ? 'ready'
                          : 'empty'
                const dataForDoctorState =
                    sessionPlayerMetaDataLoading || snapshotsLoading || !processedSnapshotData
                        ? 'loading'
                        : processedSnapshotData?.doctorEvents?.length
                          ? 'ready'
                          : 'empty'

                // TODO include notebook comments here?
                const dataForCommentState = sessionCommentsLoading
                    ? 'loading'
                    : sessionComments?.length
                      ? 'ready'
                      : 'empty'

                const dataForLogsState = logsLoading ? 'loading' : logs?.length ? 'ready' : 'empty'

                return {
                    ['events']: dataForEventsState,
                    ['console']: dataForConsoleState,
                    ['network']: dataForNetworkState,
                    ['comment']: dataForCommentState,
                    ['doctor']: dataForDoctorState,
                    ['logs']: dataForLogsState,
                }
            },
        ],

        isLoading: [
            (s) => [s.inspectorDataState],
            (inspectorDataState: Record<FilterableInspectorListItemTypes, 'empty' | 'loading' | 'ready'>): boolean =>
                Object.values(inspectorDataState).some((state) => state === 'loading'),
        ],

        isReady: [
            (s) => [s.inspectorDataState],
            (inspectorDataState: Record<FilterableInspectorListItemTypes, 'empty' | 'loading' | 'ready'>): boolean =>
                Object.values(inspectorDataState).every((state) => state === 'ready'),
        ],

        playbackIndicatorIndex: [
            (s) => [s.currentPlayerTime, s.items, s.displayGroups],
            (playerTime: number, items: InspectorListItem[], displayGroups: DisplayGroup[]): number => {
                if (!playerTime) {
                    return 0
                }
                const timeSeconds = Math.floor(playerTime / 1000)
                return displayGroups.findIndex(
                    (g) => Math.floor(items[g.indices[0]].timeInRecording / 1000) >= timeSeconds
                )
            },
        ],

        playbackIndicatorIndexStop: [
            (s) => [s.playbackIndicatorIndex, s.displayGroups],
            (playbackIndicatorIndex: number, displayGroups: DisplayGroup[]): number =>
                (displayGroups.length + playbackIndicatorIndex) % displayGroups.length,
        ],

        fuse: [
            (s) => [s.filteredItems],
            (filteredItems: InspectorListItem[]): Fuse =>
                createFuse<InspectorListItem>(filteredItems, {
                    keys: ['search'],
                    findAllMatches: true,
                    ignoreLocation: true,
                    shouldSort: false,
                    useExtendedSearch: true,
                }),
        ],

        items: [
            (s) => [s.filteredItems, s.fuse, s.searchQuery],
            (filteredItems: InspectorListItem[], fuse: Fuse, searchQuery: string): InspectorListItem[] => {
                if (searchQuery === '') {
                    return filteredItems
                }
                return fuse.search(searchQuery).map((x) => x.item)
            },
            { resultEqualityCheck: equal },
        ],

        displayGroups: [
            (s) => [s.items, s.groupRepeatedItems, s.collapseInspectorItems],
            (
                items: InspectorListItem[],
                groupRepeatedItems: boolean,
                collapseInspectorItems: boolean
            ): DisplayGroup[] => {
                if (!collapseInspectorItems) {
                    return items.map((_, i) => ({ indices: [i] }))
                }
                return computeDisplayGroups(items, groupRepeatedItems)
            },
            { resultEqualityCheck: equal },
        ],

        allItemsList: [
            (s) => [s.allItems],
            (allItemsData: {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            }): InspectorListItem[] => allItemsData.items,
        ],

        /**
         * All items by mini-filter key, not filtered items, so that we can count the unfiltered sets
         */
        allItemsByMiniFilterKey: [
            (s) => [s.allItems],
            (allItemsData: {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            }): Record<MiniFilterKey, InspectorListItem[]> => allItemsData.itemsByMiniFilterKey,
        ],

        /**
         * All items by item type, not filtered items, so that we can count the unfiltered sets
         */
        allItemsByItemType: [
            (s) => [s.allItems],
            (allItemsData: {
                items: InspectorListItem[]
                itemsByMiniFilterKey: Record<MiniFilterKey, InspectorListItem[]>
                itemsByType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>
            }): Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]> => allItemsData.itemsByType,
        ],

        hasEventsToDisplay: [
            (s) => [s.allItemsByItemType],
            (allItemsByItemType: Record<FilterableInspectorListItemTypes | 'context', InspectorListItem[]>): boolean =>
                allItemsByItemType['events']?.length > 0,
        ],
    })),
    listeners(({ values, actions, cache }) => ({
        setItemExpanded: ({ index, expanded }) => {
            if (expanded) {
                const group = values.displayGroups[index]
                const item = values.items[group.indices[0]]
                actions.reportRecordingInspectorItemExpanded(item.type, index)

                if (item.type === 'events') {
                    const eventsToLoad = group.indices.map((i) => (values.items[i] as InspectorListItemEvent).data)
                    actions.loadFullEventData(eventsToLoad)
                }
            }
        },
        loadEventsSuccess: () => {
            // Register any window IDs from events that aren't already in the registry
            const events = values.sessionEventsData || []
            for (const event of events) {
                const windowId = event.properties?.$window_id
                if (windowId && !(windowId in values.uuidToIndex)) {
                    actions.registerWindowId(windowId)
                }
            }

            if (!values.logsInitialLoadRequested && values.readyToLoadLogs) {
                actions.markLogsInitialLoadRequested()
                actions.loadLogs()
            }
        },
        loadMatchingEventsSuccess: () => {
            actions.trySkipToFirstMatchingEvent()
        },
        loadRecordingMetaSuccess: () => {
            actions.trySkipToFirstMatchingEvent()
        },
        setSkipToFirstMatchingEvent: async ({ skipToFirstMatchingEvent }, breakpoint) => {
            if (!skipToFirstMatchingEvent) {
                return
            }
            // In playlist embeds the flag is armed by initializePlayerFromStart, which only runs
            // once snapshots start syncing — usually after both matching events and meta have
            // loaded, so without this trigger the skip never fires. The arming is also dispatched
            // before the player's initial timestamp exists (which the skip requires) and no later
            // trigger is guaranteed, so defer past that synchronous init chain rather than firing
            // inline.
            await breakpoint(1)
            actions.trySkipToFirstMatchingEvent()
        },
        trySkipToFirstMatchingEvent: () => {
            if (
                !values.skipToFirstMatchingEvent ||
                values.hasSkippedToFirstMatchingEvent ||
                !values.start ||
                !values.matchingEvents?.length ||
                // seekToTime no-ops until the player has an initial timestamp — bail without
                // consuming the skip so a later trigger retries once the player is ready
                values.currentTimestamp == null
            ) {
                return
            }

            const earliestMatchingEvent = values.matchingEvents.reduce((previous, current) =>
                previous.timestamp < current.timestamp ? previous : current
            )
            const { timestamp, timeInRecording } = timeRelativeToStart(earliestMatchingEvent, values.start)
            // The matching-events query has slack around the recording window, so the earliest
            // match can fall past the playable range — seeking there would pin the player to its
            // final frame and immediately trigger end-reached (auto-advancing playlists). The
            // verdict is terminal for this recording: consume the flag so a matching-events
            // reload can't fire the skip mid-playback.
            if (values.end && timestamp.isAfter(values.end)) {
                actions.markSkippedToFirstMatchingEvent()
                return
            }
            const seekTime = Math.max(0, ceilMsToClosestSecond(timeInRecording) - 1000)

            actions.markSkippedToFirstMatchingEvent()
            if (seekTime > 1000) {
                actions.setSkippingToMatchingEvent(true)
                cache.disposables.add(() => {
                    const timerId = setTimeout(() => actions.setSkippingToMatchingEvent(false), 1500)
                    return () => clearTimeout(timerId)
                }, 'skippingToMatchingEvent')
            }

            actions.seekToTime(seekTime)
        },
    })),
    events(({ actions }) => ({
        afterMount: () => {
            actions.loadMatchingEvents()
        },
    })),
    propsChanged(({ actions, props }, oldProps) => {
        if (!equal(props.matchingEventsMatchType, oldProps.matchingEventsMatchType)) {
            actions.loadMatchingEvents()
        }
    }),
])
