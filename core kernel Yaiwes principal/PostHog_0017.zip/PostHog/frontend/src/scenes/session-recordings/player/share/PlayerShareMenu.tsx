import { useActions, useValues } from 'kea'

import { IconExternal, IconGlobe, IconShare, IconShield } from '@posthog/icons'
import { LemonButton, LemonMenu } from '@posthog/lemon-ui'

import { getAccessControlDisabledReason } from 'lib/utils/accessControlUtils'
import { newInternalTab } from 'lib/utils/newInternalTab'
import { sessionPlayerModalLogic } from 'scenes/session-recordings/player/modal/sessionPlayerModalLogic'
import { sessionRecordingPlayerLogic } from 'scenes/session-recordings/player/sessionRecordingPlayerLogic'
import { openPlayerShareDialog } from 'scenes/session-recordings/player/share/PlayerShare'
import { PlayerShareLogicProps } from 'scenes/session-recordings/player/share/playerShareLogic'
import { urls } from 'scenes/urls'

import { AccessControlLevel, AccessControlResourceType } from '~/types'

export function PlayerShareMenu(): JSX.Element {
    const { sessionRecordingId, logicProps } = useValues(sessionRecordingPlayerLogic)
    const { setPause, setIsFullScreen } = useActions(sessionRecordingPlayerLogic)
    const { closeSessionPlayer } = useActions(sessionPlayerModalLogic())
    const sharingDisabledReason = getAccessControlDisabledReason(
        AccessControlResourceType.SharingConfiguration,
        AccessControlLevel.Viewer
    )

    const getCurrentPlayerTime = (): number => {
        // NOTE: We pull this value at call time as otherwise it would trigger re-renders if pulled from the hook
        const playerTime = sessionRecordingPlayerLogic.findMounted(logicProps)?.values.currentPlayerTime || 0
        return Math.floor(playerTime / 1000)
    }

    const onShare = (shareType: PlayerShareLogicProps['shareType']): void => {
        setPause()
        setIsFullScreen(false)
        openPlayerShareDialog({
            seconds: getCurrentPlayerTime(),
            id: sessionRecordingId,
            shareType,
        })
    }

    const onOpenInNewTab = (): void => {
        if (!sessionRecordingId) {
            return
        }
        setPause()
        setIsFullScreen(false)
        closeSessionPlayer()
        newInternalTab(urls.replaySingle(sessionRecordingId))
    }

    const onOpenInBrowserTab = (): void => {
        if (!sessionRecordingId) {
            return
        }
        const path = urls.replaySingle(sessionRecordingId)
        const timestamp = getCurrentPlayerTime()
        const separator = path.includes('?') ? '&' : '?'
        const fullUrl = `${window.location.origin}${path}${timestamp ? `${separator}t=${timestamp}` : ''}`
        window.open(fullUrl, '_blank', 'noopener,noreferrer')
    }

    return (
        <LemonMenu
            items={[
                {
                    label: 'Open in new tab',
                    icon: <IconExternal />,
                    onClick: onOpenInNewTab,
                    disabledReason: !sessionRecordingId ? 'Recording not loaded yet' : undefined,
                    'data-attr': 'open-in-new-tab',
                },
                {
                    label: 'Open in new browser tab',
                    icon: <IconExternal />,
                    onClick: onOpenInBrowserTab,
                    disabledReason: !sessionRecordingId ? 'Recording not loaded yet' : undefined,
                    'data-attr': 'open-in-browser-tab',
                },
                {
                    label: 'Share private link',
                    icon: <IconShield />,
                    onClick: () => onShare('private'),
                    'data-attr': 'share-private-link',
                },
                {
                    label: 'Share public link',
                    icon: <IconGlobe />,
                    onClick: () => onShare('public'),
                    disabledReason: sharingDisabledReason ?? undefined,
                    'data-attr': 'share-public-link',
                },
            ]}
            buttonSize="xsmall"
        >
            <LemonButton size="xsmall" icon={<IconShare />} data-attr="session-recording-share-button">
                Share
            </LemonButton>
        </LemonMenu>
    )
}
