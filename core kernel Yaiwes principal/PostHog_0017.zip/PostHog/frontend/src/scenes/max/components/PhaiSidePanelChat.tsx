import { useMountedLogic } from 'kea'

import { SidePanelRunner } from 'products/posthog_ai/frontend/api/runner'

import { phaiSidePanelComposerSeedLogic } from '../phaiSidePanelComposerSeedLogic'

// The client-side key for the embedded `taskTrackerSceneLogic` (and paired `runnerPanelLogic`) instance
// this panel binds — stable so the panel keeps the same in-flight run across re-renders of its host.
export const MAX_SIDE_PANEL_ID = 'max-side-panel'

/**
 * The new posthog_ai side-panel experience: task-based, built on the `products/posthog_ai/frontend` runner
 * surface (composer -> pending thread -> live run) rather than Max's conversation logics
 * (`maxThreadLogic`/`askMax`/the conversations API). The legacy conversation chat remains behind the
 * `effectivePhaiView` toggle (see `maxGlobalLogic`). `scenes/max` hosts this only until the Max scene is
 * replaced outright by the posthog_ai product surface.
 */
export function PhaiSidePanelChat(): JSX.Element {
    // Bridges the legacy `initialMaxPrompt` side-panel option into this panel's new composer (see the logic).
    useMountedLogic(phaiSidePanelComposerSeedLogic({ panelId: MAX_SIDE_PANEL_ID }))

    return (
        // `flex-1 min-h-0`, NOT `h-full`: the side panel hosts this inside a ScrollArea whose content
        // grows with its children (`min-height: auto`), so a percentage height resolves against the
        // grown box — the runner then inflates to its full thread height and its internal scrollers
        // never engage (and `overscroll-contain` on the thread swallows wheel events entirely).
        // Taking remaining flex space instead (zero min-content contribution) keeps the panel clamped
        // to the viewport so the thread/history scroll internally as designed.
        <div className="flex flex-col flex-1 min-h-0">
            <SidePanelRunner panelId={MAX_SIDE_PANEL_ID} />
        </div>
    )
}
