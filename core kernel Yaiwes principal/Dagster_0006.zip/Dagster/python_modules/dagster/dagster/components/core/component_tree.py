import importlib
import logging
from collections.abc import Callable, Iterable
from contextlib import contextmanager
from functools import cached_property
from pathlib import Path
from types import ModuleType
from typing import Any, overload
from unittest import mock

from dagster_shared import check
from dagster_shared.record import IHaveNew, record
from dagster_shared.utils import safe_is_subclass
from dagster_shared.utils.config import (
    discover_config_file,
    get_canonical_defs_module_name,
    load_toml_as_dict,
)
from typing_extensions import Self, TypeVar

from dagster._core.definitions.definitions_class import Definitions
from dagster._core.definitions.definitions_load_context import DefinitionsLoadContext
from dagster._core.errors import DagsterError
from dagster.components.component.component import Component
from dagster.components.core.component_tree_state import ComponentTreeStateTracker
from dagster.components.core.context import ComponentDeclLoadContext, ComponentLoadContext
from dagster.components.core.decl import (
    AppManagedComponentDecl,
    AppManagedDefinitionsDecl,
    ComponentDecl,
    ComponentLoaderDecl,
    ComponentRootDecl,
    PythonFileDecl,
    YamlDecl,
    build_filesystem_component_decl_from_context,
)
from dagster.components.core.defs_module import (
    AppManagedDefinitionsLoc,
    ComponentLoc,
    ComponentPath,
    ComponentRootLoc,
    CompositeYamlComponent,
    PythonFileComponent,
    ResolvableToComponentLoc,
    ResolvableToComponentPath,
)
from dagster.components.resolved.context import ResolutionContext
from dagster.components.utils import get_path_from_module

PLUGIN_COMPONENT_TYPES_JSON_METADATA_KEY = "plugin_component_types_json"

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=Component)
TComponent = TypeVar("TComponent", bound=Component)


@record
class ComponentWithContext:
    component: Component
    component_decl: ComponentDecl


class ComponentTreeException(Exception):
    pass


@record(
    checked=False,  # cant handle ModuleType
)
class ComponentTree(IHaveNew):
    """The hierarchy of Component instances defined in the project.

    Manages and caches the component loading process, including finding component declarations
    to build the initial declaration tree, loading these Components, and eventually building the
    Definitions.
    """

    defs_module: ModuleType
    project_root: Path
    terminate_autoloading_on_keyword_files: bool | None = None
    # Project-config-derived code location name (see ``for_project``). Used as a fallback
    # for app-managed component discovery when the loading harness does not report the
    # authoritative location name on the ``DefinitionsLoadContext`` -- see
    # ``_resolve_app_managed_location_name``.
    code_location_name: str | None = None

    @cached_property
    def state_tracker(self) -> ComponentTreeStateTracker:
        return ComponentTreeStateTracker(self.defs_module_path)

    def _resolve_to_loc(self, path_or_loc: ResolvableToComponentLoc) -> ComponentLoc:
        """Resolve a path-like or ComponentLoc value to a ComponentLoc."""
        if isinstance(path_or_loc, ComponentLoc):
            return path_or_loc
        return ComponentPath.from_resolvable(self.defs_module_path, path_or_loc)

    @contextmanager
    def augment_component_tree_exception(
        self, loc: ResolvableToComponentLoc, msg_for_key: Callable[[str], str]
    ):
        try:
            yield
        except Exception as e:
            resolved_loc = self._resolve_to_loc(loc)
            if not isinstance(e, ComponentTreeException):
                display_key = resolved_loc.get_display_key(self.defs_module_path)
                match_path = resolved_loc if isinstance(resolved_loc, ComponentPath) else None
                raise ComponentTreeException(
                    f"{msg_for_key(display_key)}:\n{self.to_string_representation(include_load_and_build_status=True, match_path=match_path)}"
                ) from e
            raise

    @property
    def defs_module_name(self) -> str:
        return self.defs_module.__name__

    @property
    def defs_module_path(self) -> Path:
        return get_path_from_module(self.defs_module)

    @staticmethod
    def for_test() -> "ComponentTree":
        return TestComponentTree.for_test()

    @staticmethod
    def from_module(
        defs_module: ModuleType,
        project_root: Path,
    ) -> "ComponentTree":
        """Convenience method for creating a ComponentTree from a module.

        Args:
            defs_module: The defs module of the project, typically the `defs` directory.
            project_root: The root of the project.

        Returns:
            A ComponentTree.
        """
        return ComponentTree(
            defs_module=defs_module,
            project_root=project_root,
        )

    @classmethod
    def for_project(cls, path_within_project: Path) -> Self:
        """Using the provided path, find the nearest parent python project and load the
        ComponentTree using its configuration.

        Args:
            path_within_project (Path): A path within a Dagster project.

        Returns:
            ComponentTree: The ComponentTree for the project.
        """
        root_config_path = discover_config_file(path_within_project)
        if not root_config_path:
            raise DagsterError(
                f"Could not find config file (pyproject.toml/dg.toml) in {path_within_project} or any parent of."
            )

        project_root = root_config_path.parent

        # Use shared utility to get defs module configuration
        toml_config = load_toml_as_dict(root_config_path)

        if root_config_path and root_config_path.stem == "dg":
            project = toml_config.get("project", {})
        else:
            project = toml_config.get("tool", {}).get("dg", {}).get("project", {})

        root_module_name = project.get("root_module")
        defs_module_name = project.get("defs_module")
        check.invariant(
            defs_module_name or root_module_name,
            f"Either defs_module or root_module must be set in the project config {root_config_path}",
        )
        defs_module_name = get_canonical_defs_module_name(defs_module_name, root_module_name)

        defs_module = importlib.import_module(defs_module_name)

        code_location_name = project.get("code_location_name") or project_root.name

        return cls(
            defs_module=defs_module,
            project_root=project_root,
            code_location_name=code_location_name,
        )

    @property
    def decl_load_context(self) -> ComponentDeclLoadContext:
        if self.state_tracker.get_cache_data(ComponentRootLoc()).decl_load_context is None:
            self.state_tracker.set_cache_data(
                ComponentRootLoc(),
                decl_load_context=ComponentDeclLoadContext(
                    component_loc=ComponentRootLoc(),
                    project_root=self.project_root,
                    defs_module_path=self.defs_module_path,
                    defs_module_name=self.defs_module_name,
                    resolution_context=ResolutionContext.default(),
                    terminate_autoloading_on_keyword_files=False,
                    component_tree=self,
                ),
            )
        return check.not_none(
            self.state_tracker.get_cache_data(ComponentRootLoc()).decl_load_context
        )

    @property
    def load_context(self) -> ComponentLoadContext:
        if self.state_tracker.get_cache_data(ComponentRootLoc()).load_context is None:
            self.state_tracker.set_cache_data(
                ComponentRootLoc(),
                load_context=ComponentLoadContext.from_decl_load_context(
                    self.decl_load_context, self.find_root_decl()
                ),
            )
        return check.not_none(self.state_tracker.get_cache_data(ComponentRootLoc()).load_context)

    def load_root_component(self) -> Component:
        return self.load_structural_component_at_loc(ComponentRootLoc())

    def _resolve_app_managed_location_name(
        self, load_context: DefinitionsLoadContext
    ) -> str | None:
        """Resolves the code location name used for app-managed component discovery.

        The name reported by the loading harness on the ``DefinitionsLoadContext`` (the
        gRPC server's ``--location-name``, or the origin of an in-process load) is
        authoritative: it is the name the rest of the system refers to this location by,
        and in particular the name app-managed component state keys were written under.
        The project-config-derived ``code_location_name`` on this tree is only consulted
        when no harness-reported name is available (e.g. ``dg`` CLI invocations that load
        the project outside of any workspace).
        """
        ambient_name = load_context.code_location_name
        if ambient_name is not None:
            if self.code_location_name is not None and self.code_location_name != ambient_name:
                logger.warning(
                    f"The code location name {self.code_location_name!r} configured on this"
                    f" project does not match the name {ambient_name!r} this code location is"
                    f" registered under. App-managed components will be discovered using"
                    f" {ambient_name!r}. Update `code_location_name` under [tool.dg.project]"
                    " (or remove it) to silence this warning."
                )
            return ambient_name
        return self.code_location_name

    def find_root_decl(self) -> ComponentRootDecl:
        """Returns the unified root of the component tree.

        Constructs a fresh ComponentRootDecl whose flat ``decls`` list is
        the (cached) filesystem decl followed by an optional
        ``AppManagedDefinitionsDecl`` aggregating the app-managed components
        discovered in storage. The aggregate is rebuilt on every call so
        newly-added or removed UI components are picked up; the
        individual ``AppManagedComponentDecl`` children are cached per-id so
        unchanged components don't get rebuilt.
        """
        from dagster.components.component.app_managed_state import APP_MANAGED_COMPONENTS_KEY_PREFIX

        decls: list[ComponentDecl] = [self._get_filesystem_decl()]
        load_context = DefinitionsLoadContext.get()
        location_name = self._resolve_app_managed_location_name(load_context)
        if location_name is not None:
            decls.append(self._build_app_managed_definitions_decl(location_name))
        elif load_context.state_keys_with_prefix(APP_MANAGED_COMPONENTS_KEY_PREFIX):
            logger.warning(
                "App-managed component state exists for this deployment, but no code location"
                " name is available on this load, so no app-managed components will be loaded."
                " This can happen when definitions are loaded through the deprecated"
                " `load_defs` entry point -- load through `load_from_defs_folder` (or set"
                " `code_location_name` under [tool.dg.project]) so app-managed components can"
                " be associated with this location."
            )
        return ComponentRootDecl(
            context=self.decl_load_context,
            loc=ComponentRootLoc(),
            decls=decls,
        )

    def _get_filesystem_decl(self) -> ComponentDecl:
        loc = ComponentPath.from_path(self.defs_module_path)
        context = self.decl_load_context.for_component_loc(loc)
        if self.state_tracker.get_cache_data(loc).component_decl is None:
            filesystem_decl = build_filesystem_component_decl_from_context(context)
            self.state_tracker.set_cache_data(loc, component_decl=filesystem_decl)

        return check.not_none(self.state_tracker.get_cache_data(loc).component_decl)

    def _build_app_managed_definitions_decl(
        self, code_location_name: str
    ) -> AppManagedDefinitionsDecl:
        """Build the ``AppManagedDefinitionsDecl`` wrapper for this code location.

        Discovery is sourced from the pinned ``DefinitionsLoadContext`` rather
        than the live ``DefsStateStorage`` listing — that way a load pinned to
        a specific snapshot (RECONSTRUCTION in a run worker, or an explicit
        ReloadCodeWithState pin) sees exactly the components captured in the
        snapshot, not whatever is currently latest in storage. The actual
        per-component entries are *not* fetched here — each
        ``AppManagedComponentDecl`` lazily downloads its entry on first access (see
        ``AppManagedComponentDecl.entry``), so building the tree is metadata-only.

        Each child ``AppManagedComponentDecl`` is cached at its own
        ``AppManagedDefinitionsLoc(instance_key=id)`` and registered against its
        own state key, so an edit to a single component invalidates only
        that child's decl and cascades up via existing dependency
        tracking. The wrapper itself is reconstructed fresh because
        adding/removing a component changes the list of children — we
        rely on a fresh listing to observe those changes rather than
        caching the wrapper.
        """
        from dagster.components.component.app_managed_state import (
            get_app_managed_component_state_key,
            get_app_managed_prefix,
        )

        prefix = get_app_managed_prefix(code_location_name)
        component_ids = [
            k[len(prefix) :] for k in DefinitionsLoadContext.get().state_keys_with_prefix(prefix)
        ]

        children: list[AppManagedComponentDecl] = []
        for component_id in component_ids:
            child_loc = AppManagedDefinitionsLoc(instance_key=component_id)
            cached = self.state_tracker.get_cache_data(child_loc).component_decl
            if cached is None:
                child_ctx = self.decl_load_context.for_component_loc(child_loc)
                cached = AppManagedComponentDecl(
                    context=child_ctx,
                    loc=child_loc,
                    location_name=code_location_name,
                    component_id=component_id,
                )
                self.state_tracker.set_cache_data(child_loc, component_decl=cached)

                state_key = get_app_managed_component_state_key(code_location_name, component_id)
                self.state_tracker.mark_component_defs_state_key(child_loc, state_key)

            children.append(check.inst(cached, AppManagedComponentDecl))

        ui_loc = AppManagedDefinitionsLoc()
        ctx = self.decl_load_context.for_component_loc(ui_loc)
        return AppManagedDefinitionsDecl(
            context=ctx,
            loc=ui_loc,
            location_name=code_location_name,
            children=children,
        )

    def build_defs_at_path(self, loc: ResolvableToComponentLoc) -> Definitions:
        """Builds definitions from the given defs subdirectory or component loc.

        Args:
            loc: ComponentLoc or path to build definitions from. If a filesystem
                path and relative, resolves relative to the defs root.

        Returns:
            Definitions: The definitions loaded from the given loc.
        """
        defs = self._build_defs_at_loc(loc)
        if defs is None:
            raise Exception(f"No definitions found for loc {loc}")
        return defs

    def build_defs(self, loc: ResolvableToComponentLoc | None = None) -> Definitions:
        """Builds definitions from the given defs subdirectory, or all defs modules if no
        loc is provided.

        Args:
            loc: ComponentLoc or path to build definitions from.  If ``None``,
                builds definitions for the entire project (filesystem + library)
                by building defs at the ``ComponentRootLoc``.

        Returns:
            Definitions: The definitions loaded from the given loc.
        """
        if loc is None:
            return self.build_defs_at_path(ComponentRootLoc())
        else:
            return self.build_defs_at_path(loc)

    def reload_with_state(self, changed_state_keys: Iterable[str]) -> Definitions:
        """Invalidates the cached data for a set of state keys, then rebuilds the Definitions object."""
        for key in changed_state_keys:
            self.state_tracker.invalidate_by_defs_state_key(key)
        self.state_tracker.invalidate_loc(ComponentRootLoc())
        return self.build_defs()

    def find_decl_at_path(self, defs_path: ResolvableToComponentPath) -> ComponentDecl:
        """Loads a component declaration from the given path.

        Args:
            defs_path: Path to the component declaration to load. If relative, resolves relative to the defs root.

        Returns:
            ComponentDecl: The component declaration loaded from the given path.
        """
        resolved_path = ComponentPath.from_resolvable(self.defs_module_path, defs_path)
        decl = self._component_decl_tree().get(resolved_path)
        if decl is None:
            raise Exception(f"No component decl found for path {defs_path}")
        return decl

    def mark_component_load_dependency(self, from_loc: ComponentLoc, to_loc: ComponentLoc) -> None:
        """Marks a dependency between the component at `from_loc` and the component at `to_loc`.

        Args:
            from_loc: The loc of the component that depends on the component at `to_loc`.
            to_loc: The loc of the component that the component at `from_loc` depends on.
        """
        self.state_tracker.mark_component_load_dependency(from_loc, to_loc)

    def mark_component_defs_dependency(self, from_loc: ComponentLoc, to_loc: ComponentLoc) -> None:
        """Marks a dependency between the component at `from_loc` on the defs of
        the component at `to_loc`.

        Args:
            from_loc: The loc of the component that depends on the defs of the component at `to_loc`.
            to_loc: The loc of the component that the component at `from_loc` depends on.
        """
        self.state_tracker.mark_component_defs_dependency(from_loc, to_loc)

    def mark_component_defs_state_key(self, loc: ComponentLoc, defs_state_key: str) -> None:
        """Marks a defs state key for the component at `loc`.

        Args:
            loc: The loc of the component to mark the state key for.
            defs_state_key: The state key to mark.
        """
        self.state_tracker.mark_component_defs_state_key(loc, defs_state_key)

    @overload
    def load_component(self, defs_path: ResolvableToComponentLoc) -> Component: ...
    @overload
    def load_component(self, defs_path: ResolvableToComponentLoc, expected_type: type[T]) -> T: ...

    def load_component(
        self, defs_path: ResolvableToComponentLoc, expected_type: type[T] | None = None
    ) -> Any:
        """Loads a component from the given path.

        Args:
            defs_path: Path to the component to load. If relative, resolves relative to the defs root.

        Returns:
            Component: The component loaded from the given path.
        """
        component = self.load_structural_component_at_loc(defs_path)
        if (
            isinstance(component, (CompositeYamlComponent, PythonFileComponent))
            and len(component.components) == 1
        ):
            component = (
                component.components[0]
                if isinstance(component, CompositeYamlComponent)
                else next(iter(component.components.values()))
            )
        if expected_type and not isinstance(component, expected_type):
            raise Exception(f"Component at path {defs_path} is not of type {expected_type}")

        return component

    def _component_decl_tree(self) -> dict[ComponentLoc, ComponentDecl]:
        """Constructs or returns the full component declaration tree from cache."""
        root_decl = self.find_root_decl()
        return dict(root_decl.iterate_loc_component_decl_pairs())

    def _component_and_context_at_loc(
        self, loc: ResolvableToComponentLoc
    ) -> tuple[Component, ComponentDecl] | None:
        resolved_loc = self._resolve_to_loc(loc)
        if self.state_tracker.get_cache_data(resolved_loc).component is None:
            with self.augment_component_tree_exception(
                resolved_loc,
                lambda key: f"Error while loading component {key}",
            ):
                self._load_component_at_loc(resolved_loc)
        cache_data = self.state_tracker.get_cache_data(resolved_loc)
        if cache_data.component is None or cache_data.component_decl is None:
            return None
        return (cache_data.component, cache_data.component_decl)

    def _load_component_at_loc(self, resolved_loc: ComponentLoc) -> None:
        component_decl = self.state_tracker.get_cache_data(
            resolved_loc
        ).component_decl or self._component_decl_tree().get(resolved_loc)
        if component_decl:
            self.state_tracker.set_cache_data(
                resolved_loc,
                component=component_decl._load_component(),  # noqa: SLF001
                component_decl=component_decl,
            )

    def _build_defs_at_loc(self, loc: ResolvableToComponentLoc) -> Definitions | None:
        resolved_loc = self._resolve_to_loc(loc)
        cached_data = self.state_tracker.get_cache_data(resolved_loc)
        if cached_data.defs:
            return cached_data.defs

        with self.augment_component_tree_exception(
            resolved_loc,
            lambda key: f"Error while building definitions for {key}",
        ):
            return self._build_defs_inner(resolved_loc)

    def _build_defs_inner(self, resolved_loc: ComponentLoc) -> Definitions | None:
        component_info = self._component_and_context_at_loc(resolved_loc)
        if component_info is None:
            return None

        component, component_decl = component_info
        clc = ComponentLoadContext.from_decl_load_context(component_decl.context, component_decl)

        defs = component.build_defs(clc)
        self.state_tracker.set_cache_data(resolved_loc, defs=defs)
        return defs

    def load_structural_component_at_loc(self, loc: ResolvableToComponentLoc) -> Component:
        """Loads a component from the given loc, does not resolve e.g. CompositeYamlComponent to an underlying
        component type.

        Args:
            loc: ComponentLoc or path to load. If a filesystem path and relative, resolves relative to the defs root.

        Returns:
            Component: The component loaded from the given loc.
        """
        component_with_context = self._component_and_context_at_loc(loc)
        if component_with_context is None:
            raise Exception(f"No component found for loc {loc}")
        return component_with_context[0]

    def get_all_components(
        self,
        of_type: type[TComponent],
    ) -> list[TComponent]:
        """Get all components from this context that are instance of the specified type.
        Avoids loading components that are not of the specified type. Includes both
        file-based (``ComponentPath``) and UI-defined (``UIDefinitionsLoc``) instances.
        """
        return [
            check.inst(self.load_component(loc), of_type)
            for loc, decl in self._component_decl_tree().items()
            if safe_is_subclass(decl.component_type, of_type)
        ]

    def _has_loaded_component_at_loc(self, loc: ResolvableToComponentLoc) -> bool:
        resolved_loc = self._resolve_to_loc(loc)
        return self.state_tracker.get_cache_data(resolved_loc).component is not None

    def _has_built_defs_at_loc(self, loc: ResolvableToComponentLoc) -> bool:
        resolved_loc = self._resolve_to_loc(loc)
        return self.state_tracker.get_cache_data(resolved_loc).defs is not None

    def is_fully_loaded(self) -> bool:
        return self._has_loaded_component_at_loc(self.defs_module_path)

    def has_built_all_defs(self) -> bool:
        return self._has_built_defs_at_loc(self.defs_module_path)

    def _add_string_representation(
        self,
        lines: list[str],
        decl: ComponentDecl,
        prefix: str,
        include_load_and_build_status: bool = False,
        hide_plain_defs: bool = False,
        match_path: ComponentPath | None = None,
    ) -> None:
        decls = list(decl.iterate_child_component_decls())

        # For non-filesystem decls (e.g. ComponentRootDecl), skip rendering
        # this node but still recurse into filesystem children.
        if not isinstance(decl.loc, ComponentPath):
            for child_decl in decls:
                self._add_string_representation(
                    lines,
                    child_decl,
                    prefix,
                    include_load_and_build_status,
                    hide_plain_defs,
                    match_path,
                )
            return

        parent_path = decl.loc.file_path

        total = len(decls)
        for idx, child_decl in enumerate(decls):
            # Skip non-filesystem child decls
            if not isinstance(child_decl.loc, ComponentPath):
                continue

            if isinstance(child_decl, PythonFileDecl) and not child_decl.decls and hide_plain_defs:
                continue

            file_path = child_decl.loc.file_path.relative_to(parent_path)

            component_type_name = None
            if isinstance(child_decl, ComponentLoaderDecl):
                name = str(child_decl.loc.instance_key)
            elif isinstance(child_decl, YamlDecl):
                file_path = file_path / "defs.yaml"
                component_type_name = child_decl.component_type.__name__

                if child_decl.loc.instance_key is not None and len(decls) > 1:
                    name = f"{file_path}[{child_decl.loc.instance_key}]"
                else:
                    name = str(file_path)
            else:
                name = str(file_path)

            connector = "└── " if idx == total - 1 else "├── "
            out_txt = f"{prefix}{connector}{name}"

            if component_type_name:
                out_txt += f" ({component_type_name})"

            is_error = (
                match_path
                and child_decl.loc.file_path.as_posix() == match_path.file_path.as_posix()
                and child_decl.loc.instance_key == match_path.instance_key
            )
            if include_load_and_build_status:
                if is_error:
                    out_txt = f"{out_txt} (error)"
                elif self._has_built_defs_at_loc(child_decl.loc):
                    out_txt = f"{out_txt} (built)"
                elif self._has_loaded_component_at_loc(child_decl.loc):
                    out_txt = f"{out_txt} (loaded)"

            lines.append(out_txt)

            if is_error:
                lines.append(f"{prefix}{' ' * len(connector)}{'^' * len(name)}")

            extension = "    " if idx == total - 1 else "│   "
            self._add_string_representation(
                lines,
                child_decl,
                prefix + extension,
                include_load_and_build_status,
                hide_plain_defs,
                match_path,
            )

        if (
            hide_plain_defs
            and len(decls) > 0
            and all(
                isinstance(child_decl, PythonFileDecl) and not child_decl.decls
                for child_decl in decls
            )
        ):
            lines.append(f"{prefix}└── ...")

    def to_string_representation(
        self,
        include_load_and_build_status: bool = False,
        hide_plain_defs: bool = False,
        match_path: ComponentPath | None = None,
    ) -> str:
        """Returns a string representation of the component tree.

        Args:
            include_load_and_build_status: Whether to include the load and build status of the components.
            hide_plain_defs: Whether to hide any plain Dagster defs, which are not components, e.g. Python files without components.
        """
        lines = []
        self._add_string_representation(
            lines,
            self.find_root_decl(),
            "",
            include_load_and_build_status,
            hide_plain_defs,
            match_path,
        )
        return "\n".join(lines)


class TestComponentTree(ComponentTree):
    """Variant of ComponentTree that is used for testing purposes. Mocks out the
    definitions module name and path.
    """

    @staticmethod
    def for_test() -> "TestComponentTree":
        """Convenience method for creating a ComponentTree for testing purposes."""
        return TestComponentTree(
            defs_module=mock.Mock(),
            project_root=Path.cwd(),
        )

    @property
    def defs_module_name(self) -> str:
        return "test"

    @property
    def defs_module_path(self) -> Path:
        return Path.cwd()

    @property
    def decl_load_context(self):
        return ComponentDeclLoadContext(
            component_loc=ComponentPath.from_path(self.defs_module_path),
            project_root=self.project_root,
            defs_module_path=self.defs_module_path,
            defs_module_name=self.defs_module_name,
            resolution_context=ResolutionContext.default(),
            terminate_autoloading_on_keyword_files=True,
            component_tree=self,
        )

    @property
    def load_context(self):
        component_decl = mock.Mock()
        component_decl.iterate_child_component_decls = mock.Mock(return_value=[])
        return ComponentLoadContext.from_decl_load_context(self.decl_load_context, component_decl)


class LegacyAutoloadingComponentTree(ComponentTree):
    """ComponentTree variant which terminates autoloading of defs on the keyword
    files `definitions.py` and `component.py`. This should only be used for legacy
    test and load_defs codepaths.
    """

    @property
    def decl_load_context(self):
        return ComponentDeclLoadContext(
            component_loc=ComponentRootLoc(),
            project_root=self.project_root,
            defs_module_path=self.defs_module_path,
            defs_module_name=self.defs_module_name,
            resolution_context=ResolutionContext.default(),
            terminate_autoloading_on_keyword_files=True,
            component_tree=self,
        )

    @staticmethod
    def from_module(
        defs_module: ModuleType,
        project_root: Path,
    ) -> "ComponentTree":
        """Convenience method for creating a ComponentTree from a module.

        Args:
            defs_module: The defs module of the project, typically the `defs` directory.
            project_root: The root of the project.

        Returns:
            A ComponentTree.
        """
        return LegacyAutoloadingComponentTree(
            defs_module=defs_module,
            project_root=project_root,
        )
