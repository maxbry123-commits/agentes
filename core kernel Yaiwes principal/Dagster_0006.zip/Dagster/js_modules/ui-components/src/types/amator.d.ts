declare module 'amator';
