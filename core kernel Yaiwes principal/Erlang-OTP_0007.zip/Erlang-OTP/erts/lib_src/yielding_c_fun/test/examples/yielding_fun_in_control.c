#include <stdio.h>
#include <stdlib.h>

#define YCF_YIELD()

int sub_fun(char x){
  YCF_YIELD();
  x = x + 1; /* x == 1*/
  return (x == 10 ? 0 : 1);
}


int fun(char x){
  if(sub_fun(0)){
    printf("hej\n");
  }
  if(0) printf("NO");
  else if(sub_fun(0)){
    printf("hej 2\n");
  }
  if(sub_fun(10)){
    printf("hej 3\n");
  } else {
    printf("HEJ\n");
  }
  while(sub_fun(9)){
    printf("hoo\n");
  }
  do{
    printf("haa\n");
  }while(sub_fun(9));
  return x;
}

void* allocator(size_t size, void* context){
  (void)context;
  return malloc(size);
}

void freer(void* data, void* context){
  (void)context;
  free(data);
}

int main( int argc, const char* argv[] )
{
#ifdef YCF_YIELD_CODE_GENERATED
  void* wb = NULL;
  long nr_of_reductions = 1;
#endif
  int ret = 0;
#ifdef YCF_YIELD_CODE_GENERATED
  do{
    ret = fun_ycf_gen_yielding(&nr_of_reductions,&wb,NULL,allocator,freer,NULL,0,NULL,1);
    if(wb != NULL){
      printf("TRAPPED\n");
    }
  }while(wb != NULL);
  if(wb != NULL){
    free(wb);
  }
#else
  fun(1);
#endif
  printf("RETURNED %d\n", ret);
  return 0;
}

