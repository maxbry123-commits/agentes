---
summary: "Adds Mistral model provider support to OpenClaw."
read_when:
  - You are installing, configuring, or auditing the mistral plugin
title: "Mistral plugin"
---

# Mistral plugin

Adds Mistral model provider support to OpenClaw.

## Distribution

- Package: `@openclaw/mistral-provider`
- Install route: npm; ClawHub: `clawhub:@openclaw/mistral-provider`

## Surface

providers: `mistral`; contracts: `embeddingProviders`, `mediaUnderstandingProviders`, `realtimeTranscriptionProviders`

## Related docs

- [mistral](/providers/mistral)
