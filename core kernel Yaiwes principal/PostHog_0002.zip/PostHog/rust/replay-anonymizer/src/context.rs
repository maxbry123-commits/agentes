//! Per-message scrub context: the allow lists plus a blur memo.
//!
//! Within one Kafka message the same image often recurs thousands of times (a canvas redrawing one
//! sprite, a repeated background). Blurring is pure in its input, so we memoize it per message and
//! collapse that fan-out to a single decode+blur — mirroring the TS `blurCache` (also scoped to one
//! message). Scope is one `anonymize_message` call; the map is dropped when it returns.

use std::cell::{Cell, RefCell};
use std::collections::{BTreeMap, HashMap};

use anyhow::{bail, Result};
use serde::Serialize;

use crate::allow_lists::AllowLists;
use crate::assets::PLACEHOLDER_SRC;
use crate::blur::{blank_image_data_uri, blur_image_data_uri, pixelate_raw_rgba};
use crate::collect::{
    collectable_data_uri_bytes, is_image_ref, CollectedImage, ImageCollection, ImageCollector,
};
use crate::images::{ImageFallback, ImagePolicy, ImageQueue};
use crate::timings::PhaseTimings;
use crate::url_collect::{CollectedUrl, UrlCollection, UrlCollector};

/// Cumulative decompressed-bytes budget across all cv payloads in one message: the per-payload
/// `compression::MAX_DECOMPRESSED_BYTES` cap bounds each field, this bounds their sum so many high-ratio
/// fields can't decompress gigabytes serially. Real messages total under 10 MB.
const CV_MESSAGE_DECOMPRESSION_BUDGET: usize = 256 * 1024 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) enum ImageSource {
    CssProperty(&'static str),
    HtmlAttribute(&'static str),
}

#[derive(Debug, Clone, Serialize, PartialEq)]
pub struct ImageSourceCount {
    pub source: &'static str,
    pub property: &'static str,
    pub kind: &'static str,
    pub count: u32,
}

/// Scrub context: the allow lists, the cv decompression budget, the blur memo, the image scrub
/// policy (inline blur, or deferred onto the shared worker pool), and the optional collection lane.
pub struct Ctx<'a> {
    pub allow: &'a AllowLists,
    pub cv_budget: Cell<usize>,
    // key: the original data URI (data-image blur), or `raw:{w}x{h}:{base64}` (raw RGBA pixelate).
    // value: the replacement — a content ref (collection lane), a blurred data URI — or `None`
    // when neither could be produced (caller falls back to a blank pixel).
    blur_cache: RefCell<HashMap<String, Option<String>>>,
    timings: Option<&'a PhaseTimings>,
    image_policy: ImagePolicy,
    images: ImageQueue,
    // `Some` routes collectable images to the scrub lane instead of the blur (inline or pooled).
    collector: Option<RefCell<ImageCollector>>,
    // `Some` routes remote image URLs to the fetch lane and emits refs beside the media placeholder.
    url_collector: Option<RefCell<UrlCollector>>,
    image_source_counts: RefCell<BTreeMap<(ImageSource, &'static str), u32>>,
    // Whether a well-formed ref already present in the *input* is left alone. Off unless the
    // caller vouches for the input's provenance; see `preserving_image_refs`.
    preserve_image_refs: bool,
}

impl<'a> Ctx<'a> {
    pub fn new(allow: &'a AllowLists) -> Self {
        Self::with_options(allow, None, ImagePolicy::Inline, None)
    }

    pub fn with_timings(allow: &'a AllowLists, timings: Option<&'a PhaseTimings>) -> Self {
        Self::with_options(allow, timings, ImagePolicy::Inline, None)
    }

    pub fn with_image_collection(
        allow: &'a AllowLists,
        image_collection: Option<ImageCollection>,
    ) -> Self {
        Self::with_options(allow, None, ImagePolicy::Inline, image_collection)
    }

    // pub(crate): the token-patch barriers live only in the kafka snapshot pipeline, so a
    // caller-built Parallel Ctx on the other entry points would emit unresolved tokens.
    pub(crate) fn with_options(
        allow: &'a AllowLists,
        timings: Option<&'a PhaseTimings>,
        image_policy: ImagePolicy,
        image_collection: Option<ImageCollection>,
    ) -> Self {
        Self {
            allow,
            cv_budget: Cell::new(CV_MESSAGE_DECOMPRESSION_BUDGET),
            blur_cache: RefCell::new(HashMap::new()),
            timings,
            image_policy,
            images: ImageQueue::default(),
            collector: image_collection.map(|c| RefCell::new(ImageCollector::new(c))),
            url_collector: None,
            image_source_counts: RefCell::new(BTreeMap::new()),
            preserve_image_refs: false,
        }
    }

    /// Leave well-formed image refs already present in the input alone instead of scrubbing them.
    ///
    /// Off by default, and it must stay off for anything scrubbing untrusted capture input: the
    /// ref format is not a secret, so a page could set a media attribute to a forged one and have
    /// it copied into output unscrubbed. Enable it only where the input is known to be this
    /// anonymizer's own mirrored output being re-scrubbed — there a ref is a join key whose bytes
    /// were already scrubbed out of band, and re-scrubbing it destroys the only route back to them.
    pub fn preserving_image_refs(mut self) -> Self {
        self.preserve_image_refs = true;
        self
    }

    /// Whether an input-side ref may skip scrubbing (see [`Self::preserving_image_refs`]).
    pub(crate) fn keeps_image_refs(&self) -> bool {
        self.preserve_image_refs
    }

    /// Scrub one image data URI: the collection lane's content ref when it takes the image (no blur
    /// work at all — the original bytes ride back to the caller for the out-of-band scrub), else
    /// per the policy — the blurred URI (inline), or a token the patch pass later replaces
    /// (parallel). Failures resolve to `fallback` either way. A message that exhausts the
    /// queued-bytes budget degrades to inline for the remainder — bounded memory, identical output.
    pub(crate) fn scrub_image(&self, original: &str, fallback: ImageFallback) -> String {
        if let Some(collected) = self.collect_image(original) {
            return collected;
        }
        if self.image_policy == ImagePolicy::Parallel {
            if let Some(token) = self.images.submit(
                original,
                fallback,
                true,
                crate::images::MAX_QUEUED_URI_BYTES,
            ) {
                return token;
            }
        }
        match (self.blur_data_uri(original), fallback) {
            (Some(blurred), _) => blurred,
            (None, ImageFallback::Blank) => blank_image_data_uri(),
            (None, ImageFallback::Placeholder) => PLACEHOLDER_SRC.to_string(),
        }
    }

    pub(crate) fn scrub_image_from(
        &self,
        original: &str,
        fallback: ImageFallback,
        source: ImageSource,
    ) -> String {
        let scrubbed = self.scrub_image(original, fallback);
        if is_image_ref(&scrubbed) {
            self.record_image_source(source, "inline");
        }
        scrubbed
    }

    pub(crate) fn has_pending_images(&self) -> bool {
        self.images.has_pending()
    }

    /// Replace any outstanding image tokens in serialized output, waiting for their jobs. Must run
    /// wherever bytes become immutable: before a cv payload compresses, and on the final lines.
    /// Worker-side blur time lands in the timings sink here, as jobs are claimed.
    pub(crate) fn patch_pending_images(&self, buf: Vec<u8>) -> Vec<u8> {
        let out = self.images.patch(buf);
        if let Some(t) = self.timings {
            self.images.drain_blur_time_into(t);
        }
        out
    }

    fn timed<T>(&self, op: &'static str, f: impl FnOnce() -> T) -> T {
        match self.timings {
            Some(t) => t.time_op(op, f),
            None => f(),
        }
    }

    /// Route remote image URLs to the fetch lane. Off unless set, exactly like image collection.
    /// The media source keeps its placeholder either way.
    pub fn collecting_urls(mut self, url_collection: Option<UrlCollection>) -> Self {
        self.url_collector = url_collection.map(|c| RefCell::new(UrlCollector::new(c)));
        self
    }

    /// The fetch lane's ref for a remote image URL.
    ///
    /// `None` when collection is off, when the URL is not fetchable, or when the per-message cap
    /// is reached. The caller writes the placeholder regardless and stashes a returned ref beside
    /// it.
    pub(crate) fn collect_url(&self, original: &str) -> Option<String> {
        let collector = self.url_collector.as_ref()?;
        collector.borrow_mut().collect(original)
    }

    pub(crate) fn collect_url_from(&self, original: &str, source: ImageSource) -> Option<String> {
        let reference = self.collect_url(original)?;
        self.record_image_source(source, "url");
        Some(reference)
    }

    fn record_image_source(&self, source: ImageSource, kind: &'static str) {
        let mut counts = self.image_source_counts.borrow_mut();
        let count = counts.entry((source, kind)).or_default();
        *count = count.saturating_add(1);
    }

    pub fn take_image_source_counts(&self) -> Vec<ImageSourceCount> {
        let counts = std::mem::take(&mut *self.image_source_counts.borrow_mut());
        counts
            .into_iter()
            .map(|((source, kind), count)| {
                let (source, property) = match source {
                    ImageSource::CssProperty(property) => ("css", property),
                    ImageSource::HtmlAttribute(property) => ("html", property),
                };
                ImageSourceCount {
                    source,
                    property,
                    kind,
                    count,
                }
            })
            .collect()
    }

    /// Drain the collected URLs (hash-sorted). Empty when URL collection was off.
    ///
    /// Takes the collector rather than `self`, because the caller drains the images afterwards and
    /// that call consumes the context. A second call therefore returns nothing, which is why this
    /// is not named `into_`.
    /// Counts by reason for the URLs the collector refused. Read before [`Self::take_collected_urls`],
    /// which takes the collector.
    pub fn take_url_declines(&self) -> Vec<(String, u32)> {
        match self.url_collector.as_ref() {
            Some(collector) => collector.borrow().into_declines(),
            None => Vec::new(),
        }
    }

    pub fn take_collected_urls(&mut self) -> Vec<CollectedUrl> {
        match self.url_collector.take() {
            Some(collector) => collector.into_inner().into_urls(),
            None => Vec::new(),
        }
    }

    /// Drain the collected images (hash-sorted). Empty when collection was off.
    pub fn into_collected_images(self) -> Vec<CollectedImage> {
        match self.collector {
            Some(collector) => collector.into_inner().into_images(),
            None => Vec::new(),
        }
    }

    /// Restore the full cv decompression budget. The budget bounds one message; per-line callers
    /// ([`crate::event::anonymize_line_with_ctx`]) reset it each call so a long session file
    /// cannot exhaust it, while the blur memo keeps spanning the whole `Ctx`.
    pub fn reset_cv_budget(&self) {
        self.cv_budget.set(CV_MESSAGE_DECOMPRESSION_BUDGET);
    }

    /// The only budgeted cv decompression path — cv code must not call the [`crate::compression`]
    /// codecs directly. Magic-byte dispatch (gzip or zstd, unknown fails closed) lives in
    /// [`crate::compression::decompress_by_magic`]; this layers the cumulative budget on top.
    pub fn decompress_cv(&self, raw: &[u8]) -> Result<Vec<u8>> {
        let out = self.timed("cv", || crate::compression::decompress_by_magic(raw))?;
        match self.cv_budget.get().checked_sub(out.len()) {
            Some(rest) => self.cv_budget.set(rest),
            None => bail!("message exceeds the cumulative cv decompression budget"),
        }
        Ok(out)
    }

    // Borrow discipline: never hold a `blur_cache` borrow across the blur call — the compute runs
    // borrow-free, so a future blur helper that re-entered `Ctx` still couldn't double-borrow-panic.

    /// Blur a data-image URI inline, memoized on the URI. `None` → caller falls back to a
    /// blank/placeholder.
    pub fn blur_data_uri(&self, original: &str) -> Option<String> {
        if let Some(hit) = self.blur_cache.borrow().get(original) {
            return hit.clone();
        }
        let result = self.timed("blur", || blur_image_data_uri(original));
        self.blur_cache
            .borrow_mut()
            .insert(original.to_string(), result.clone());
        result
    }

    /// The collection lane's ref for a data URI, or `None` (collection off, non-collectable URI,
    /// or a cap hit) — the caller then blurs per the policy as before. Refs are memoized in the
    /// blur cache so a sprite recurring thousands of times hashes once.
    fn collect_image(&self, original: &str) -> Option<String> {
        let collector = self.collector.as_ref()?;
        if let Some(Some(hit)) = self.blur_cache.borrow().get(original) {
            return Some(hit.clone());
        }
        let bytes = collectable_data_uri_bytes(original)?;
        let collected = collector.borrow_mut().collect(bytes)?;
        self.blur_cache
            .borrow_mut()
            .insert(original.to_string(), Some(collected.clone()));
        Some(collected)
    }

    /// Pixelate raw RGBA pixels, memoized on dimensions + bytes.
    pub fn pixelate_raw(&self, rgba_base64: &str, width: u32, height: u32) -> Option<String> {
        let key = format!("raw:{width}x{height}:{rgba_base64}");
        if let Some(hit) = self.blur_cache.borrow().get(&key) {
            return hit.clone();
        }
        let result = self.timed("blur", || pixelate_raw_rgba(rgba_base64, width, height));
        self.blur_cache.borrow_mut().insert(key, result.clone());
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testkit::png_data_uri;

    #[test]
    fn decompress_cv_dispatches_on_magic_and_budgets_both_codecs() {
        let allow = AllowLists::new(Vec::<String>::new(), Vec::<String>::new());
        let payload = b"x".repeat(1000);
        let gz = crate::compression::gzip(&payload).unwrap();
        let zs = crate::compression::compress_cv(&payload).unwrap();
        for compressed in [&gz, &zs] {
            let ctx = Ctx::new(&allow);
            assert_eq!(ctx.decompress_cv(compressed).unwrap(), payload);

            let ctx = Ctx::new(&allow);
            ctx.cv_budget.set(10);
            let err = ctx.decompress_cv(compressed).unwrap_err().to_string();
            assert!(err.contains("budget"), "got: {err}");
        }
    }

    #[test]
    fn decompress_cv_fails_closed_on_unknown_magic() {
        let allow = AllowLists::new(Vec::<String>::new(), Vec::<String>::new());
        let ctx = Ctx::new(&allow);
        assert!(ctx
            .decompress_cv(b"plainly not a compressed stream")
            .is_err());
        assert!(ctx.decompress_cv(b"").is_err());
    }

    #[test]
    fn blur_memo_is_stable_and_keyed_per_image() {
        let allow = AllowLists::new(Vec::<String>::new(), Vec::<String>::new());
        let ctx = Ctx::new(&allow);
        let a = png_data_uri(100, 50, [10, 20, 30, 255]);
        let b = png_data_uri(40, 40, [200, 100, 50, 255]);
        // Same input → same result twice (a cache hit must not return something different).
        assert_eq!(ctx.blur_data_uri(&a), ctx.blur_data_uri(&a));
        // Distinct inputs → distinct results (guards against a cache-key collision serving A's blur for B).
        assert_ne!(ctx.blur_data_uri(&a), ctx.blur_data_uri(&b));
    }
}
