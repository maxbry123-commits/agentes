mod data_types;
mod error;
mod symbol_data;
mod utils;

// Error
pub use error::Error as SymbolDataError;

// The core data type
pub use symbol_data::read_as as read_symbol_data;
pub use symbol_data::read_as_with_byte_count as read_symbol_data_with_byte_count;
pub use symbol_data::write as write_symbol_data;
pub use symbol_data::write_uncompressed as write_symbol_data_uncompressed;

// Javascript
pub use data_types::sourcemap::SourceAndMap;

// Hermes
pub use data_types::hermesmap::HermesMap;

// Proguard
pub use data_types::proguard::ProguardMapping;

// Apple dSYM
pub use data_types::dsym::AppleDsym;

// Native (ELF) debug info
pub use data_types::elf::ElfDebugInfo;
