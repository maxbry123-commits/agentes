#!/bin/bash

set -exo pipefail

# Python dependencies
pip3 install --no-cache-dir \
    "llamafactory==0.9.3" \
    "deepspeed==0.16.9" \
    "wandb==0.23.1" \
    "tensorboard==2.20.0" \
    "mlflow==3.4.0" \
    "bitsandbytes==0.47.0" \
    "autoawq==0.2.9" \
    "liger-kernel==0.6.2"
