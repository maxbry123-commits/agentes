#!/bin/bash

set -euxo pipefail

# Python dependencies
pip3 install --no-cache-dir \
    "fastapi==0.115.12" \
    "langchain==1.0.5" \
    "langchain-mcp-adapters==0.1.12" \
    "langchain-openai==1.0.2" \
    "langgraph==1.0.3" \
    "openai==2.7.2" \
    "uvicorn==0.38.0" \
    "httpx==0.27.1" \
    "mcp==1.22.0"
