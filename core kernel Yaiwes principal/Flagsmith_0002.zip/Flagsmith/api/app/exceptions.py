class ImproperlyConfiguredError(RuntimeError):
    pass
