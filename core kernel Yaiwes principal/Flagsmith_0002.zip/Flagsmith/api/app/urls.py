import importlib

from common.core.urls import urlpatterns as core_urlpatterns
from django.conf import settings
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.generic.base import TemplateView
from oauth2_provider import views as oauth2_views

from oauth2_metadata.views import (
    DynamicClientRegistrationView,
    OAuthAuthorizeView,
    authorization_server_metadata,
)
from users.views import password_reset_redirect

from . import views

urlpatterns = [
    *core_urlpatterns,
    path("processor/", include("task_processor.urls")),
    path(
        ".well-known/oauth-authorization-server",
        authorization_server_metadata,
        name="oauth-authorization-server-metadata",
    ),
]

if not settings.TASK_PROCESSOR_MODE:
    urlpatterns += [
        re_path(
            r"^api/v1/", include("api.urls.deprecated", namespace="api-deprecated")
        ),
        re_path(r"^api/v1/", include("api.urls.v1", namespace="api-v1")),
        re_path(r"^api/v2/", include("api.urls.v2", namespace="api-v2")),
        re_path(
            r"^api/experiments/",
            include("api.urls.experiments", namespace="api-experiments"),
        ),
        re_path(
            r"^api/__future__/", include("api.urls.future", namespace="api-future")
        ),
        re_path(r"^admin/", admin.site.urls),
        re_path(
            r"^sales-dashboard/",
            include("sales_dashboard.urls", namespace="sales_dashboard"),
        ),
        # this url is used to generate email content for the password reset workflow
        re_path(
            r"^password-reset/confirm/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,"
            r"13}-[0-9A-Za-z]{1,20})/$",
            password_reset_redirect,
            name="password_reset_confirm",
        ),
        re_path(
            r"^config/project-overrides",
            views.project_overrides,
            name="project_overrides",
        ),
        path(
            "robots.txt",
            TemplateView.as_view(template_name="robots.txt", content_type="text/plain"),
        ),
        path(
            "api/v1/oauth/authorize/",
            OAuthAuthorizeView.as_view(),
            name="oauth-authorize",
        ),
        path(
            "o/register/",
            DynamicClientRegistrationView.as_view(),
            name="oauth2-dcr-register",
        ),
        path(
            "o/",
            include(
                (
                    [
                        path("token/", oauth2_views.TokenView.as_view(), name="token"),
                        path(
                            "revoke_token/",
                            oauth2_views.RevokeTokenView.as_view(),
                            name="revoke-token",
                        ),
                        path(
                            "introspect/",
                            oauth2_views.IntrospectTokenView.as_view(),
                            name="introspect",
                        ),
                    ],
                    "oauth2_provider",
                )
            ),
        ),
    ]

if settings.DEBUG:  # pragma: no cover
    urlpatterns = [
        re_path(r"^__debug__/", include("debug_toolbar.urls")),
    ] + urlpatterns

if settings.SAML_INSTALLED:  # pragma: no cover
    from saml.views import SamlConfigurationViewSet

    from organisations.subscriptions.constants import SubscriptionPlanFamily
    from organisations.subscriptions.permissions import require_minimum_plan

    scale_up_permission = require_minimum_plan(SubscriptionPlanFamily.SCALE_UP)
    SamlConfigurationViewSet.permission_classes = [
        *SamlConfigurationViewSet.permission_classes,
        scale_up_permission,
    ]

    urlpatterns += [
        path("api/v1/auth/saml/", include("saml.urls")),
    ]

if settings.SCIM_INSTALLED:  # pragma: no cover
    urlpatterns += [
        path("api/v1/scim/v2/", include("django_scim.urls")),
        path(
            "api/v1/organisations/<int:organisation_pk>/scim/",
            include("scim.urls"),
        ),
    ]

if settings.WORKFLOWS_LOGIC_INSTALLED:  # pragma: no cover
    workflow_views = importlib.import_module("workflows_logic.views")
    urlpatterns += [
        path("api/v1/features/workflows/", include("workflows_logic.urls")),
        path(
            "api/v1/environments/<str:environment_api_key>/create-change-request/",
            workflow_views.create_change_request,
            name="create-change-request",
        ),
        path(
            "api/v1/environments/<str:environment_api_key>/list-change-requests/",
            workflow_views.list_change_requests,
            name="list-change-requests",
        ),
    ]


if settings.SERVE_FE_ASSETS:  # pragma: no cover
    # add route to serve FE assets for any unrecognised paths
    urlpatterns.append(re_path(r"^.*$", views.index, name="index"))
