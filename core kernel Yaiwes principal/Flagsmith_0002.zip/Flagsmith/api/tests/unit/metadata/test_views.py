import json
from itertools import chain

import pytest
from django.contrib.contenttypes.models import ContentType
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient

from metadata.models import (
    MetadataField,
    MetadataModelField,
    MetadataModelFieldRequirement,
)
from metadata.views import SUPPORTED_REQUIREMENTS_MAPPING  # type: ignore[attr-defined]
from organisations.models import Organisation
from projects.models import Project, UserProjectPermission
from users.models import FFAdminUser


def test_create_metadata_field__valid_data__returns_201(admin_client, organisation):  # type: ignore[no-untyped-def]
    # Given
    url = reverse("api-v1:metadata:metadata-fields-list")
    field_name = "some_id"
    field_type = "int"

    data = {"name": field_name, "type": field_type, "organisation": organisation.id}

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["id"]
    assert response.json()["name"] == field_name
    assert response.json()["type"] == field_type
    assert response.json()["organisation"] == organisation.id


def test_delete_metadata_field__existing_field__returns_204(  # type: ignore[no-untyped-def]
    admin_client, a_metadata_field
):
    # Given
    url = reverse("api-v1:metadata:metadata-fields-detail", args=[a_metadata_field.id])

    # When
    response = admin_client.delete(url, content_type="application/json")

    # Then
    assert response.status_code == status.HTTP_204_NO_CONTENT


def test_update_metadata_field__valid_data__returns_200(  # type: ignore[no-untyped-def]
    admin_client, a_metadata_field, organisation
):
    # Given
    url = reverse("api-v1:metadata:metadata-fields-detail", args=[a_metadata_field.id])

    new_field_type = "bool"
    new_field_name = "new_field_name"

    data = {
        "name": new_field_name,
        "type": new_field_type,
        "organisation": organisation.id,
    }

    # When
    response = admin_client.put(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["name"] == new_field_name
    assert response.json()["type"] == new_field_type


def test_list_metadata_fields__with_organisation_filter__returns_fields(  # type: ignore[no-untyped-def]
    admin_client, a_metadata_field
):
    # Given
    base_url = reverse("api-v1:metadata:metadata-fields-list")

    url = f"{base_url}?organisation={a_metadata_field.organisation.id}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()["results"]) == 1
    assert response.json()["results"][0]["id"] == a_metadata_field.id


def test_list_metadata_fields__without_organisation_filter__returns_400(  # type: ignore[no-untyped-def]
    admin_client, a_metadata_field
):
    # Given
    url = reverse("api-v1:metadata:metadata-fields-list")

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_400_BAD_REQUEST


def test_retrieve_metadata_field__existing_field__returns_200(  # type: ignore[no-untyped-def]
    admin_client, a_metadata_field
):
    # Given
    url = reverse("api-v1:metadata:metadata-fields-detail", args=[a_metadata_field.id])

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["id"] == a_metadata_field.id


def test_create_metadata_field__non_org_admin__returns_403(  # type: ignore[no-untyped-def]
    staff_client: APIClient,
    organisation: Organisation,
):
    # Given
    url = reverse("api-v1:metadata:metadata-fields-list")
    field_name = "some_id"
    field_type = "int"

    data = {"name": field_name, "type": field_type, "organisation": organisation.id}

    # When
    response = staff_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_403_FORBIDDEN


def test_list_model_metadata_fields__multiple_fields__returns_all(  # type: ignore[no-untyped-def]
    required_a_environment_metadata_field,
    optional_b_environment_metadata_field,
    admin_client,
    organisation,
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()["results"]) == 2


def test_list_model_metadata_fields__content_type_filter__returns_matching_only(  # type: ignore[no-untyped-def]
    required_a_environment_metadata_field,
    optional_b_environment_metadata_field,
    admin_client,
    project,
    a_metadata_field,
    organisation,
):
    # Given - a project metadata field
    project_content_type = ContentType.objects.get_for_model(project)
    a_metadata_project_field = MetadataModelField.objects.create(
        field=a_metadata_field,
        content_type=project_content_type,
    )

    base_url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    url = f"{base_url}?content_type={project_content_type.id}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()["results"]) == 1
    assert response.json()["results"][0]["id"] == a_metadata_project_field.id


def test_delete_model_metadata_field__existing_field__returns_204(  # type: ignore[no-untyped-def]
    environment,
    admin_client,
    a_metadata_field,
    required_a_environment_metadata_field,
    organisation,
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, required_a_environment_metadata_field.id],
    )
    # When
    response = admin_client.delete(url)

    # Then
    assert response.status_code == status.HTTP_204_NO_CONTENT


def test_delete_model_metadata_field__other_organisation__returns_404(  # type: ignore[no-untyped-def]
    environment,
    admin_client,
    a_metadata_field,
    required_a_environment_metadata_field,
    environment_metadata_field_different_org,
    organisation,
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, environment_metadata_field_different_org.id],
    )
    # When
    response = admin_client.delete(url)

    # Then
    assert response.status_code == status.HTTP_404_NOT_FOUND


def test_update_model_metadata_field__valid_data__returns_200(  # type: ignore[no-untyped-def]
    environment,
    admin_client,
    a_metadata_field,
    required_a_environment_metadata_field,
    organisation,
    environment_content_type,
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, required_a_environment_metadata_field.id],
    )
    data = {
        "field": a_metadata_field.id,
        "is_required_for": [],
        "model_name": "environment",
        "content_type": environment_content_type.id,
    }

    # When
    response = admin_client.put(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["field"] == a_metadata_field.id
    assert response.json()["id"] == required_a_environment_metadata_field.id
    assert response.json()["is_required_for"] == []
    assert (
        MetadataModelFieldRequirement.objects.filter(
            model_field=required_a_environment_metadata_field
        ).count()
        == 0
    )


def test_update_model_metadata_field__other_organisation__returns_404(  # type: ignore[no-untyped-def]
    environment, admin_client, environment_metadata_field_different_org, organisation
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, environment_metadata_field_different_org.id],
    )
    data = {
        "field": environment_metadata_field_different_org.field.id,
        "is_required": False,
    }

    # When
    response = admin_client.put(url, data=data)

    # Then
    assert response.status_code == status.HTTP_404_NOT_FOUND


def test_create_model_metadata_field__environment_content_type__returns_201(
    admin_client: APIClient,
    a_metadata_field: MetadataField,
    organisation: Organisation,
    project_content_type: ContentType,
    environment_content_type: ContentType,
    project: Project,
) -> None:
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    data = {
        "field": a_metadata_field.id,
        "is_required_for": [
            {"content_type": project_content_type.id, "object_id": project.id}
        ],
        "content_type": environment_content_type.id,
    }

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )
    # Then
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["field"] == a_metadata_field.id
    assert response.json()["is_required_for"][0] == {
        "content_type": project_content_type.id,
        "object_id": project.id,
    }


def test_create_model_metadata_field__feature_content_type__returns_201(
    admin_client: APIClient,
    a_metadata_field: MetadataField,
    organisation: Organisation,
    project_content_type: ContentType,
    feature_content_type: ContentType,
    project: Project,
) -> None:
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    data = {
        "field": a_metadata_field.id,
        "is_required_for": [
            {"content_type": project_content_type.id, "object_id": project.id}
        ],
        "content_type": feature_content_type.id,
    }

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )
    # Then
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["field"] == a_metadata_field.id
    assert response.json()["is_required_for"][0] == {
        "content_type": project_content_type.id,
        "object_id": project.id,
    }


def test_create_model_metadata_field__segment_content_type__returns_201(
    admin_client: APIClient,
    a_metadata_field: MetadataField,
    organisation: Organisation,
    project_content_type: ContentType,
    segment_content_type: ContentType,
    project: Project,
) -> None:
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    data = {
        "field": a_metadata_field.id,
        "is_required_for": [
            {"content_type": project_content_type.id, "object_id": project.id}
        ],
        "content_type": segment_content_type.id,
    }

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )
    # Then
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["field"] == a_metadata_field.id
    assert response.json()["is_required_for"][0] == {
        "content_type": project_content_type.id,
        "object_id": project.id,
    }


def test_create_model_metadata_field__field_from_other_organisation__returns_403(  # type: ignore[no-untyped-def]
    admin_client, environment_metadata_field_different_org, organisation, project
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    project_content_type = ContentType.objects.get_for_model(project)
    data = {
        "field": environment_metadata_field_different_org.field.id,
        "is_required": True,
        "content_type": project_content_type.id,
    }

    # When
    response = admin_client.post(url, data=data)

    # Then
    assert response.status_code == status.HTTP_403_FORBIDDEN


def test_get_supported_content_types__valid_request__returns_supported_models(  # type: ignore[no-untyped-def]
    admin_client: APIClient, organisation: Organisation
):
    # Given
    url = reverse(
        "api-v1:organisations:metadata-model-fields-supported-content-types",
        args=[organisation.id],
    )

    supported_models = list(
        chain.from_iterable(
            (key, *value) for key, value in SUPPORTED_REQUIREMENTS_MAPPING.items()
        )
    )

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK

    response_models = set(content_type["model"] for content_type in response.json())

    for model in response_models:
        assert model in supported_models


def test_get_supported_required_for_models__environment_model__returns_expected_models(  # type: ignore[no-untyped-def]
    admin_client, organisation
):
    # Given
    base_url = reverse(
        "api-v1:organisations:metadata-model-fields-supported-required-for-models",
        args=[organisation.id],
    )
    url = f"{base_url}?model_name=environment"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()) == 2
    assert response.json()[0]["model"] == "organisation"
    assert response.json()[1]["model"] == "project"


def test_create_metadata_field__with_project__returns_201(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
) -> None:
    # Given
    url = reverse("api-v1:metadata:metadata-fields-list")
    data = {
        "name": "project_field",
        "type": "str",
        "organisation": organisation.id,
        "project": project.id,
    }

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["project"] == project.id
    assert response.json()["organisation"] == organisation.id


def test_create_metadata_field__project_from_different_org__returns_400(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
) -> None:
    # Given
    other_org = Organisation.objects.create(name="Other Org")
    other_project = Project.objects.create(name="Other Project", organisation=other_org)
    url = reverse("api-v1:metadata:metadata-fields-list")
    data = {
        "name": "bad_field",
        "type": "str",
        "organisation": organisation.id,
        "project": other_project.id,
    }

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_400_BAD_REQUEST


def test_create_metadata_field__project_admin__returns_201(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
) -> None:
    # Given
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)

    url = reverse("api-v1:metadata:metadata-fields-list")
    data = {
        "name": "project_admin_field",
        "type": "str",
        "organisation": organisation.id,
        "project": project.id,
    }

    # When
    response = staff_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_201_CREATED


def test_list_metadata_fields__organisation_filter__returns_org_level_only(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
) -> None:
    # Given
    org_field = MetadataField.objects.create(
        name="org_field", type="str", organisation=organisation
    )
    MetadataField.objects.create(
        name="proj_a_field", type="str", organisation=organisation, project=project
    )
    MetadataField.objects.create(
        name="proj_b_field", type="str", organisation=organisation, project=project_b
    )
    base_url = reverse("api-v1:metadata:metadata-fields-list")
    url = f"{base_url}?organisation={organisation.id}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert returned_ids == {org_field.id}


def test_list_metadata_fields__field_with_model_fields__returns_nested_model_fields(
    admin_client: APIClient,
    organisation: Organisation,
    environment_content_type: ContentType,
    project_content_type: ContentType,
    project: Project,
) -> None:
    # Given
    field = MetadataField.objects.create(
        name="my_field", type="str", organisation=organisation
    )
    model_field = MetadataModelField.objects.create(
        field=field, content_type=environment_content_type
    )
    MetadataModelFieldRequirement.objects.create(
        content_type=project_content_type,
        object_id=project.id,
        model_field=model_field,
    )
    base_url = reverse("api-v1:metadata:metadata-fields-list")
    url = f"{base_url}?organisation={organisation.id}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    results = response.json()["results"]
    assert len(results) == 1
    assert results[0]["model_fields"] == [
        {
            "id": model_field.id,
            "content_type": environment_content_type.id,
            "is_required_for": [
                {
                    "content_type": project_content_type.id,
                    "object_id": project.id,
                }
            ],
        }
    ]


def test_list_project_metadata_fields__project_filter__returns_project_fields_only(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
) -> None:
    # Given
    MetadataField.objects.create(
        name="org_field", type="str", organisation=organisation
    )
    project_field = MetadataField.objects.create(
        name="proj_a_field", type="str", organisation=organisation, project=project
    )
    MetadataField.objects.create(
        name="proj_b_field", type="str", organisation=organisation, project=project_b
    )
    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert returned_ids == {project_field.id}


def test_list_project_metadata_fields__include_organisation__returns_both(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
) -> None:
    # Given
    org_field = MetadataField.objects.create(
        name="org_field", type="str", organisation=organisation
    )
    project_field = MetadataField.objects.create(
        name="project_field", type="str", organisation=organisation, project=project
    )
    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?include_organisation=true")

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert org_field.id in returned_ids
    assert project_field.id in returned_ids


def test_list_project_metadata_fields__include_organisation__project_overrides_org(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
) -> None:
    # Given
    org_field = MetadataField.objects.create(
        name="shared_name", type="str", organisation=organisation
    )
    project_field = MetadataField.objects.create(
        name="shared_name", type="int", organisation=organisation, project=project
    )
    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?include_organisation=true")

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert project_field.id in returned_ids
    assert org_field.id not in returned_ids


def test_list_project_metadata_fields__include_organisation__excludes_other_project_fields(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
) -> None:
    # Given
    project_a_field = MetadataField.objects.create(
        name="proj_a_field", type="str", organisation=organisation, project=project
    )
    MetadataField.objects.create(
        name="proj_b_field", type="str", organisation=organisation, project=project_b
    )
    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?include_organisation=true")

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert project_a_field.id in returned_ids
    assert all(r["project"] in (project.id, None) for r in response.json()["results"])


@pytest.mark.parametrize(
    "existing_project_attr, new_project_attr, expected_status",
    [
        (None, None, status.HTTP_400_BAD_REQUEST),
        ("project", "project", status.HTTP_400_BAD_REQUEST),
        ("project", "project_b", status.HTTP_201_CREATED),
        (None, "project", status.HTTP_201_CREATED),
    ],
    ids=[
        "duplicate_org_level",
        "duplicate_project_level",
        "same_name_different_projects",
        "same_name_org_and_project_level",
    ],
)
def test_create_metadata_field__uniqueness_constraint__returns_expected_status(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
    existing_project_attr: str | None,
    new_project_attr: str | None,
    expected_status: int,
    request: pytest.FixtureRequest,
) -> None:
    # Given
    existing_project = (
        request.getfixturevalue(existing_project_attr)
        if existing_project_attr
        else None
    )
    MetadataField.objects.create(
        name="the_field",
        type="str",
        organisation=organisation,
        project=existing_project,
    )

    new_project = (
        request.getfixturevalue(new_project_attr) if new_project_attr else None
    )
    url = reverse("api-v1:metadata:metadata-fields-list")
    data: dict[str, object] = {
        "name": "the_field",
        "type": "str",
        "organisation": organisation.id,
    }
    if new_project is not None:
        data["project"] = new_project.id

    # When
    response = admin_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == expected_status


def test_list_project_metadata_fields__page_size__returns_all(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
) -> None:
    # Given - create 15 fields to exceed the default page size of 10
    fields = []
    for i in range(15):
        field = MetadataField.objects.create(
            name=f"field_{i}", type="str", organisation=organisation, project=project
        )
        MetadataModelField.objects.create(
            field=field, content_type=feature_content_type
        )
        fields.append(field)

    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?page_size=100")

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.json()["results"]) == 15


@pytest.mark.parametrize(
    "entity",
    ["feature", "segment", "environment"],
)
def test_list_project_metadata_fields__entity_filter__returns_matching_only(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
    segment_content_type: ContentType,
    environment_content_type: ContentType,
    entity: str,
) -> None:
    # Given
    content_types = {
        "feature": feature_content_type,
        "segment": segment_content_type,
        "environment": environment_content_type,
    }

    created_fields: dict[str, MetadataField] = {}
    for name, ct in content_types.items():
        field = MetadataField.objects.create(
            name=f"{name}_only_field",
            type="str",
            organisation=organisation,
            project=project,
        )
        MetadataModelField.objects.create(field=field, content_type=ct)
        created_fields[name] = field

    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?entity={entity}")

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert returned_ids == {created_fields[entity].id}


def test_list_project_metadata_fields__entity_filter__includes_multi_entity_fields(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
    segment_content_type: ContentType,
    environment_content_type: ContentType,
) -> None:
    # Given - a field assigned to all three entities
    all_entities_field = MetadataField.objects.create(
        name="all_entities_field",
        type="str",
        organisation=organisation,
        project=project,
    )
    for ct in [feature_content_type, segment_content_type, environment_content_type]:
        MetadataModelField.objects.create(field=all_entities_field, content_type=ct)

    # And a field assigned only to feature
    feature_only_field = MetadataField.objects.create(
        name="feature_only_field",
        type="str",
        organisation=organisation,
        project=project,
    )
    MetadataModelField.objects.create(
        field=feature_only_field, content_type=feature_content_type
    )

    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When - filtering by segment
    response = admin_client.get(f"{url}?entity=segment")

    # Then - only the all_entities_field is returned
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert returned_ids == {all_entities_field.id}


def test_list_project_metadata_fields__entity_filter_with_include_organisation__returns_both(
    admin_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
    segment_content_type: ContentType,
) -> None:
    # Given - an org-level field for feature
    org_field = MetadataField.objects.create(
        name="org_feature_field", type="str", organisation=organisation
    )
    MetadataModelField.objects.create(
        field=org_field, content_type=feature_content_type
    )

    # And a project-level field for feature
    project_field = MetadataField.objects.create(
        name="project_feature_field",
        type="str",
        organisation=organisation,
        project=project,
    )
    MetadataModelField.objects.create(
        field=project_field, content_type=feature_content_type
    )

    # And a project-level field for segment (should be excluded)
    segment_field = MetadataField.objects.create(
        name="project_segment_field",
        type="str",
        organisation=organisation,
        project=project,
    )
    MetadataModelField.objects.create(
        field=segment_field, content_type=segment_content_type
    )

    url = reverse("api-v1:projects:project-metadata-fields-list", args=[project.id])

    # When
    response = admin_client.get(f"{url}?include_organisation=true&entity=feature")

    # Then
    assert response.status_code == status.HTTP_200_OK
    returned_ids = {r["id"] for r in response.json()["results"]}
    assert returned_ids == {org_field.id, project_field.id}


@pytest.mark.parametrize(
    "field_project_attr, action, expected_status",
    [
        ("project", "put", status.HTTP_200_OK),
        ("project", "delete", status.HTTP_204_NO_CONTENT),
        (None, "put", status.HTTP_403_FORBIDDEN),
        (None, "delete", status.HTTP_403_FORBIDDEN),
        ("project_b", "put", status.HTTP_403_FORBIDDEN),
        ("project_b", "delete", status.HTTP_403_FORBIDDEN),
    ],
)
def test_modify_metadata_field__project_admin__permission_check(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
    field_project_attr: str | None,
    action: str,
    expected_status: int,
    request: pytest.FixtureRequest,
) -> None:
    # Given
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)
    field_project = (
        request.getfixturevalue(field_project_attr) if field_project_attr else None
    )
    field = MetadataField.objects.create(
        name="the_field", type="str", organisation=organisation, project=field_project
    )
    url = reverse("api-v1:metadata:metadata-fields-detail", args=[field.id])

    # When
    if action == "put":
        data = {
            "name": "the_field_updated",
            "type": "str",
            "organisation": organisation.id,
            **({"project": field_project.id} if field_project else {}),
        }
        response = staff_client.put(
            url, data=json.dumps(data), content_type="application/json"
        )
    else:
        response = staff_client.delete(url)

    # Then
    assert response.status_code == expected_status


def test_create_model_metadata_field__project_admin__returns_201(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
) -> None:
    # Given - a project-scoped MetadataField and a user who is project admin (not org admin)
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)
    project_field = MetadataField.objects.create(
        name="proj_field",
        type="int",
        organisation=organisation,
        project=project,
    )
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    data = {
        "field": project_field.id,
        "content_type": feature_content_type.id,
        "is_required_for": [],
    }

    # When
    response = staff_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then - project admin should be allowed to bind a project-scoped field
    assert response.status_code == status.HTTP_201_CREATED
    assert response.json()["field"] == project_field.id


def test_create_model_metadata_field__project_admin_org_scoped_field__returns_403(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
    feature_content_type: ContentType,
) -> None:
    # Given - an org-scoped MetadataField (project=None) and a user who is project admin only
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)
    org_field = MetadataField.objects.create(
        name="org_field",
        type="int",
        organisation=organisation,
    )
    url = reverse(
        "api-v1:organisations:metadata-model-fields-list", args=[organisation.id]
    )
    data = {
        "field": org_field.id,
        "content_type": feature_content_type.id,
        "is_required_for": [],
    }

    # When
    response = staff_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then - project admin must not be able to bind org-scoped fields
    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.parametrize(
    "field_project_attr, expected_status",
    [
        ("project", status.HTTP_200_OK),
        (None, status.HTTP_403_FORBIDDEN),
        ("project_b", status.HTTP_403_FORBIDDEN),
    ],
    ids=[
        "own_project_field_allowed",
        "org_scoped_field_denied",
        "other_project_field_denied",
    ],
)
def test_update_model_metadata_field__project_admin__returns_expected_status(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
    feature_content_type: ContentType,
    field_project_attr: str | None,
    expected_status: int,
    request: pytest.FixtureRequest,
) -> None:
    # Given - a project admin for `project`, and a MetadataModelField whose parent
    # MetadataField belongs to one of: `project`, `project_b`, or the org (None)
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)
    field_project = (
        request.getfixturevalue(field_project_attr) if field_project_attr else None
    )
    field = MetadataField.objects.create(
        name="model_field", type="int", organisation=organisation, project=field_project
    )
    model_field = MetadataModelField.objects.create(
        field=field, content_type=feature_content_type
    )
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, model_field.id],
    )
    data = {
        "field": field.id,
        "content_type": feature_content_type.id,
        "is_required_for": [],
    }

    # When
    response = staff_client.put(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == expected_status


@pytest.mark.parametrize(
    "field_project_attr, expected_status",
    [
        ("project", status.HTTP_204_NO_CONTENT),
        (None, status.HTTP_403_FORBIDDEN),
        ("project_b", status.HTTP_403_FORBIDDEN),
    ],
    ids=[
        "own_project_field_allowed",
        "org_scoped_field_denied",
        "other_project_field_denied",
    ],
)
def test_delete_model_metadata_field__project_admin__returns_expected_status(
    staff_user: FFAdminUser,
    staff_client: APIClient,
    organisation: Organisation,
    project: Project,
    project_b: Project,
    feature_content_type: ContentType,
    field_project_attr: str | None,
    expected_status: int,
    request: pytest.FixtureRequest,
) -> None:
    # Given - a project admin for `project`, and a MetadataModelField whose parent
    # MetadataField belongs to one of: `project`, `project_b`, or the org (None)
    UserProjectPermission.objects.create(user=staff_user, project=project, admin=True)
    field_project = (
        request.getfixturevalue(field_project_attr) if field_project_attr else None
    )
    field = MetadataField.objects.create(
        name="model_field", type="int", organisation=organisation, project=field_project
    )
    model_field = MetadataModelField.objects.create(
        field=field, content_type=feature_content_type
    )
    url = reverse(
        "api-v1:organisations:metadata-model-fields-detail",
        args=[organisation.id, model_field.id],
    )

    # When
    response = staff_client.delete(url)

    # Then
    assert response.status_code == expected_status
