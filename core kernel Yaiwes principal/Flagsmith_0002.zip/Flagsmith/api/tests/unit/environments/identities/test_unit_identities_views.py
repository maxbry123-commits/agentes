import json
import urllib
from typing import Any
from unittest import mock

import pytest
from common.environments.permissions import (
    MANAGE_IDENTITIES,
    VIEW_IDENTITIES,
)
from django.test import override_settings
from django.urls import reverse
from flag_engine.segments.constants import PERCENTAGE_SPLIT
from pytest_django import DjangoAssertNumQueries
from pytest_mock import MockerFixture
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.test import APIClient

from core.constants import (
    FLAGSMITH_UPDATED_AT_HEADER,
    SDK_ENVIRONMENT_KEY_HEADER,
    STRING,
)
from environments.identities import views
from environments.identities.models import Identity
from environments.identities.traits.models import Trait
from environments.models import Environment, EnvironmentAPIKey
from environments.permissions.models import UserEnvironmentPermission
from environments.permissions.permissions import NestedEnvironmentPermissions
from features.models import Feature, FeatureSegment, FeatureState
from integrations.amplitude.models import AmplitudeConfiguration
from organisations.models import Organisation
from permissions.models import PermissionModel
from projects.models import Project, UserProjectPermission
from segments.models import Condition, Segment, SegmentRule


def test_identity_detail__valid_identity__returns_identity_data(
    environment: Environment,
    identity: Identity,
    admin_client: APIClient,
) -> None:
    # Given
    url = reverse(
        "api-v1:environments:environment-identities-detail",
        args=[environment.api_key, identity.id],
    )

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.data["environment"] == environment.id
    assert response.data["id"] == identity.id
    assert response.data["identifier"] == identity.identifier


def test_identity_featurestate_create__valid_feature__returns_created(
    feature: Feature,
    admin_client: APIClient,
    identity: Identity,
) -> None:
    # Given
    url = reverse(
        "api-v1:environments:identity-featurestates-list",
        args=[identity.environment.api_key, identity.id],
    )

    # When
    response = admin_client.post(
        url,
        data=json.dumps({"feature": feature.id, "enabled": True}),
        content_type="application/json",
    )

    # Then
    identity_features = identity.identity_features
    assert response.status_code == status.HTTP_201_CREATED
    assert response.data["feature"] == feature.id
    assert response.data["identity"] == identity.id
    assert identity_features.count() == 1


def test_identity_featurestate_create__duplicate_feature__returns_400(
    feature: Feature,
    admin_client: APIClient,
    identity: Identity,
) -> None:
    # Given
    url = reverse(
        "api-v1:environments:identity-featurestates-list",
        args=[identity.environment.api_key, identity.id],
    )

    # When
    initial_response = admin_client.post(
        url,
        data=json.dumps({"feature": feature.id, "enabled": True}),
        content_type="application/json",
    )
    second_response = admin_client.post(
        url,
        data=json.dumps({"feature": feature.id, "enabled": True}),
        content_type="application/json",
    )

    # Then
    assert initial_response.status_code == status.HTTP_201_CREATED
    assert second_response.status_code == status.HTTP_400_BAD_REQUEST
    identity_feature = identity.identity_features
    assert identity_feature.count() == 1


def test_identity_featurestate_update__toggle_enabled__updates_state(
    feature: Feature,
    admin_client: APIClient,
    identity: Identity,
    environment: Environment,
) -> None:
    # Given
    feature_state = FeatureState.objects.create(
        feature=feature,
        identity=identity,
        enabled=False,
        environment=environment,
    )

    url = reverse(
        "api-v1:environments:identity-featurestates-detail",
        args=[environment.api_key, identity.id, feature_state.id],
    )
    # When
    response = admin_client.put(
        url,
        data=json.dumps({"enabled": True}),
        content_type="application/json",
    )
    feature_state.refresh_from_db()

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert feature_state.enabled


def test_identity_featurestate_delete__existing_override__removes_override(
    admin_client: APIClient,
    feature: Feature,
    project: Project,
    identity: Identity,
    environment: Environment,
) -> None:
    # Given
    feature2 = Feature.objects.create(name="feature2", project=project)
    identity_feature1 = FeatureState.objects.create(
        feature=feature,
        identity=identity,
        enabled=False,
        environment=environment,
    )
    FeatureState.objects.create(
        feature=feature2,
        identity=identity,
        enabled=True,
        environment=environment,
    )

    url = reverse(
        "api-v1:environments:identity-featurestates-detail",
        args=[environment.api_key, identity.id, identity_feature1.id],
    )

    # When
    admin_client.delete(url, content_type="application/json")

    # Then
    identity_features = FeatureState.objects.filter(identity=identity)
    assert identity_features.count() == 1


def test_identity_list__search_by_identifier__returns_matching_identity(
    admin_client: APIClient,
    identity: Identity,
    environment: Environment,
) -> None:
    # Given
    base_url = reverse(
        "api-v1:environments:environment-identities-list",
        args=[environment.api_key],
    )
    url = f"{base_url}?q={identity.identifier}"

    # Identity for non-inclusion.
    Identity.objects.create(identifier="identifier2", environment=environment)

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK

    # Only identity matching search appears.
    assert response.data["count"] == 1
    assert response.data["results"][0]["identifier"] == identity.identifier


def test_identity_list__search_with_exact_match__returns_only_exact(
    environment: Environment,
    admin_client: APIClient,
) -> None:
    # Given
    # Note that the idenifiers all have the number 1, but only the
    # exact match will be returned due to the quotes in the query.
    identity_to_return = Identity.objects.create(
        identifier="1", environment=environment
    )
    Identity.objects.create(identifier="12", environment=environment)
    Identity.objects.create(identifier="121", environment=environment)
    base_url = reverse(
        "api-v1:environments:environment-identities-list",
        args=[environment.api_key],
    )
    path_encoded = urllib.parse.urlencode({"q": '"1"'})
    url = f"{base_url}?{path_encoded}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK

    # Only identity matching search appears
    assert response.data["count"] == 1
    assert response.data["results"][0]["id"] == identity_to_return.id


def test_identity_list__search_uppercase__returns_case_insensitive_match(
    identity: Identity,
    environment: Environment,
    admin_client: APIClient,
) -> None:
    # Given
    base_url = reverse(
        "api-v1:environments:environment-identities-list",
        args=[environment.api_key],
    )
    assert identity.identifier != identity.identifier.upper()
    url = f"{base_url}?q={identity.identifier.upper()}"

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK

    # and - identity matching search appears
    assert response.data["count"] == 1


def test_identity_list__search_no_match__returns_empty(
    environment: Environment,
    admin_client: APIClient,
) -> None:
    # Given
    base_url = reverse(
        "api-v1:environments:environment-identities-list",
        args=[environment.api_key],
    )
    url = "%s?q=%s" % (base_url, "some invalid search string")

    # When
    response = admin_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.data["count"] == 0


def test_identity_list__search_with_pagination__returns_second_page(
    environment: Environment,
    admin_client: APIClient,
) -> None:
    # Given
    for i in range(12):
        identifier = f"user.{i}"
        Identity.objects.create(identifier=identifier, environment=environment)
    base_url = reverse(
        "api-v1:environments:environment-identities-list",
        args=[environment.api_key],
    )
    url = f"{base_url}?q=user&page_size=10"

    response1 = admin_client.get(url)
    second_page = response1.data["next"]

    # When
    response2 = admin_client.get(second_page)

    # Then
    assert response2.status_code == status.HTTP_200_OK
    assert response2.data["results"]


def test_identity_delete__existing_identity__removes_identity(
    environment: Environment,
    admin_client: APIClient,
    identity: Identity,
) -> None:
    # Given
    url = reverse(
        "api-v1:environments:environment-identities-detail",
        args=[environment.api_key, identity.id],
    )

    # When
    response = admin_client.delete(url)

    # Then
    assert response.status_code == status.HTTP_204_NO_CONTENT
    assert not Identity.objects.filter(id=identity.id).exists()


def test_sdk_identities_get__no_feature_specified__returns_all_flags(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    Feature.objects.create(project=environment.project, name="Test Feature 1")
    Feature.objects.create(project=environment.project, name="Test Feature 2")

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data["flags"]) == 2


def test_sdk_identities_get__cached_responses__returns_correct_flags_per_environment(
    environment: Environment,
    feature: Feature,
    django_assert_num_queries: DjangoAssertNumQueries,
    use_local_mem_cache_for_cache_middleware: None,
    project_two_feature: Feature,
    project_two_environment: Environment,
) -> None:
    # Given
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=some-identifier"

    # Create clients for two separate environments
    environment_one_client = APIClient(
        headers={SDK_ENVIRONMENT_KEY_HEADER: environment.api_key}
    )
    project_two_environment_client = APIClient(
        headers={SDK_ENVIRONMENT_KEY_HEADER: project_two_environment.api_key}
    )

    # Fetch flags for both environments once to warm the cache
    environment_one_response = environment_one_client.get(url)
    assert environment_one_response.status_code == status.HTTP_200_OK

    project_two_environment_response = project_two_environment_client.get(url)
    assert project_two_environment_response.status_code == status.HTTP_200_OK

    #  When
    with django_assert_num_queries(0):
        for _ in range(10):
            environment_one_response = environment_one_client.get(url)
            assert environment_one_response.status_code == status.HTTP_200_OK

            project_two_environment_response = project_two_environment_client.get(url)
            assert project_two_environment_response.status_code == status.HTTP_200_OK

            # Then
            # Each response must return the correct feature for its environment
            assert (
                environment_one_response.json()["flags"][0]["feature"]["id"]
                == feature.id
            )
            assert (
                project_two_environment_response.json()["flags"][0]["feature"]["id"]
                == project_two_feature.id
            )


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__amplitude_configured__calls_amplitude_identify(
    mock_amplitude_wrapper: mock.MagicMock,
    environment: Environment,
    identity: Identity,
    api_client: APIClient,
) -> None:
    # Given
    # amplitude configuration for environment
    AmplitudeConfiguration.objects.create(api_key="abc-123", environment=environment)
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    Feature.objects.create(project=environment.project, name="Test Feature 1")
    Feature.objects.create(project=environment.project, name="Test Feature 2")

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert len(response.data["flags"]) == 2

    # and amplitude identify users should be called
    mock_amplitude_wrapper.assert_called()


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__identity_with_trait__returns_traits(
    mock_amplitude_wrapper: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
) -> None:
    # Given
    trait = Trait.objects.create(
        identity=identity,
        trait_key="trait_key",
        value_type=STRING,
        string_value="trait_value",
    )
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier

    # When
    response = api_client.get(url)

    # Then
    assert response.data["traits"] is not None
    assert response.data["traits"][0].get("trait_value") == trait.get_trait_value()  # type: ignore[no-untyped-call]

    # and amplitude identify users should not be called
    mock_amplitude_wrapper.assert_not_called()


def test_sdk_identities_get__feature_specified__returns_single_flag(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    feature_1 = Feature.objects.create(
        project=environment.project, name="Test Feature 1"
    )
    Feature.objects.create(project=environment.project, name="Test Feature 2")

    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    base_url = reverse("api-v1:sdk-identities")
    url = f"{base_url}?identifier={identity.identifier}&feature={feature_1.name}"

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.data["feature"]["name"] == feature_1.name


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__identity_in_segment__returns_segment_override(
    mock_amplitude_wrapper: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    segment: Segment,
) -> None:
    # Given
    trait_key = "trait_key"
    trait_value = "trait_value"
    Trait.objects.create(
        identity=identity,
        trait_key=trait_key,
        value_type=STRING,
        string_value=trait_value,
    )
    segment_rule = SegmentRule.objects.create(
        segment=segment, type=SegmentRule.ALL_RULE
    )
    Condition.objects.create(
        operator="EQUAL", property=trait_key, value=trait_value, rule=segment_rule
    )
    Feature.objects.create(project=environment.project, name="Test Feature 1")
    feature_2 = Feature.objects.create(
        project=environment.project, name="Test Feature 2"
    )

    feature_segment = FeatureSegment.objects.create(
        segment=segment,
        feature=feature_2,
        environment=environment,
        priority=1,
    )
    FeatureState.objects.create(
        feature=feature_2,
        feature_segment=feature_segment,
        environment=environment,
        enabled=True,
    )
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.data["flags"][1]["enabled"] is True

    # and amplitude identify users should not be called
    mock_amplitude_wrapper.assert_not_called()


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__identity_in_segment_with_feature__returns_segment_override(
    mock_amplitude_wrapper: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    segment: Segment,
) -> None:
    # Given
    trait_key = "trait_key"
    trait_value = "trait_value"
    Trait.objects.create(
        identity=identity,
        trait_key=trait_key,
        value_type=STRING,
        string_value=trait_value,
    )
    segment_rule = SegmentRule.objects.create(
        segment=segment, type=SegmentRule.ALL_RULE
    )
    Condition.objects.create(
        operator="EQUAL", property=trait_key, value=trait_value, rule=segment_rule
    )
    feature_1 = Feature.objects.create(
        project=environment.project, name="Test Feature 1"
    )
    Feature.objects.create(project=environment.project, name="Test Feature 2")

    feature_segment = FeatureSegment.objects.create(
        segment=segment,
        feature=feature_1,
        environment=environment,
        priority=1,
    )
    FeatureState.objects.create(
        feature_segment=feature_segment,
        feature=feature_1,
        environment=environment,
        enabled=True,
    )
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    base_url = reverse("api-v1:sdk-identities")
    url = f"{base_url}?identifier={identity.identifier}&feature={feature_1.name}"

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.data["enabled"] is True

    # and amplitude identify users should not be called
    mock_amplitude_wrapper.assert_not_called()


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__percentage_split_identity_included__returns_enabled(
    mock_amplitude_wrapper: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    segment: Segment,
    feature: Feature,
) -> None:
    # Given
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier

    segment_rule = SegmentRule.objects.create(
        segment=segment, type=SegmentRule.ALL_RULE
    )

    Condition.objects.create(
        operator=PERCENTAGE_SPLIT,
        value=100,
        rule=segment_rule,
    )
    feature_segment = FeatureSegment.objects.create(
        segment=segment,
        feature=feature,
        environment=environment,
        priority=1,
    )
    FeatureState.objects.create(
        feature_segment=feature_segment,
        feature=feature,
        environment=environment,
        enabled=True,
    )

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.get(url)

    # Then
    for flag in response.json()["flags"]:
        if flag["feature"]["name"] == feature.name:
            assert flag["enabled"]

    # and amplitude identify users should not be called
    mock_amplitude_wrapper.assert_not_called()


@mock.patch("integrations.amplitude.amplitude.AmplitudeWrapper.identify_user_async")
def test_sdk_identities_get__percentage_split_identity_excluded__returns_default(
    mock_amplitude_wrapper: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    segment: Segment,
    feature: Feature,
) -> None:
    # Given
    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier

    segment_rule = SegmentRule.objects.create(
        segment=segment, type=SegmentRule.ALL_RULE
    )

    Condition.objects.create(
        operator=PERCENTAGE_SPLIT,
        value=0,
        rule=segment_rule,
    )
    feature_segment = FeatureSegment.objects.create(
        segment=segment,
        feature=feature,
        environment=environment,
        priority=1,
    )
    FeatureState.objects.create(
        feature_segment=feature_segment,
        feature=feature,
        environment=environment,
        enabled=True,
    )

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.get(url)

    # Then
    assert not response.json().get("flags")[0].get("enabled")

    # and amplitude identify users should not be called
    mock_amplitude_wrapper.assert_not_called()


def test_sdk_identities_post__null_trait_value__returns_ok(
    environment: Environment,
    api_client: APIClient,
    identity: Identity,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": "new_identity",
        "traits": [
            {"trait_key": "trait_that_does_not_exists", "trait_value": None},
        ],
    }

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert identity.identity_traits.count() == 0


def test_sdk_identities_post__trait_value_none__deletes_trait(  # type: ignore[no-untyped-def]
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
):
    # Given
    url = reverse("api-v1:sdk-identities")
    trait_1 = Trait.objects.create(
        identity=identity,
        trait_key="trait_key_1",
        value_type=STRING,
        string_value="trait_value",
    )
    trait_2 = Trait.objects.create(
        identity=identity,
        trait_key="trait_key_2",
        value_type=STRING,
        string_value="trait_value",
    )

    data = {
        "identifier": identity.identifier,
        "traits": [
            {"trait_key": trait_1.trait_key, "trait_value": None},
            {"trait_key": "trait_that_does_not_exists", "trait_value": None},
        ],
    }

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert identity.identity_traits.count() == 1
    assert identity.identity_traits.filter(trait_key=trait_2.trait_key).exists()


def test_sdk_identities_post__with_traits__persists_traits(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
    feature: Feature,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")

    # A payload for an identity with 2 traits.
    data = {
        "identifier": identity.identifier,
        "traits": [
            {"trait_key": "my_trait", "trait_value": 123},
            {"trait_key": "my_other_trait", "trait_value": "a value"},
        ],
    }

    # When
    # We identify that user by posting the above payload.
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    # We get everything we expect in the response.
    response_json = response.json()
    assert response_json["flags"]
    assert response_json["traits"]
    assert identity.identity_traits.count() == 2


def test_sdk_identities_post__persistence_disabled__does_not_persist_traits(
    organisation: Organisation,
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
    feature: Feature,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")

    # an organisation configured to not persist traits
    organisation.persist_trait_data = False
    organisation.save()

    # and a payload for an identity with 2 traits
    data = {
        "identifier": identity.identifier,
        "traits": [
            {"trait_key": "my_trait", "trait_value": 123},
            {"trait_key": "my_other_trait", "trait_value": "a value"},
        ],
    }

    # When
    # we identify that user by posting the above payload
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    # we get everything we expect in the response
    response_json = response.json()
    assert response_json["flags"]
    assert response_json["traits"]

    # and the traits ARE NOT persisted
    assert identity.identity_traits.count() == 0


@override_settings(EDGE_API_URL="http://localhost")
@mock.patch("environments.identities.views.forward_identity_request")
def test_sdk_identities_post__dynamo_enabled__forwards_request(
    mocked_forward_identity_request: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    project: Project,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")

    project.enable_dynamo_db = True
    project.save()

    data = {
        "identifier": identity.identifier,
        "traits": [
            {"trait_key": "my_trait", "trait_value": 123},
            {"trait_key": "my_other_trait", "trait_value": "a value"},
        ],
    }

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    api_client.post(url, data=json.dumps(data), content_type="application/json")

    # Then
    args, kwargs = mocked_forward_identity_request.delay.call_args_list[0]
    assert args == ()
    assert kwargs["args"][0] == "POST"
    assert kwargs["args"][1].get("X-Environment-Key") == environment.api_key
    assert kwargs["args"][2] == environment.project.id

    assert kwargs["kwargs"]["request_data"] == data


@override_settings(EDGE_API_URL="http://localhost")
@mock.patch("environments.identities.views.forward_identity_request")
def test_sdk_identities_get__dynamo_enabled__forwards_request(
    mocked_forward_identity_request: mock.MagicMock,
    identity: Identity,
    api_client: APIClient,
    environment: Environment,
    project: Project,
) -> None:
    # Given
    project.enable_dynamo_db = True
    project.save()

    base_url = reverse("api-v1:sdk-identities")
    url = base_url + "?identifier=" + identity.identifier

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    api_client.get(url)

    # Then
    args, kwargs = mocked_forward_identity_request.delay.call_args_list[0]
    assert args == ()
    assert kwargs["args"][0] == "GET"
    assert kwargs["args"][1].get("X-Environment-Key") == environment.api_key
    assert kwargs["args"][2] == project.id

    assert kwargs["kwargs"]["query_params"] == {"identifier": identity.identifier}


def test_sdk_identities_post__client_traits_disabled__returns_empty_traits(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": "foo", "trait_value": "bar"}],
    }

    environment.allow_client_traits = False
    environment.save()

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert Trait.objects.count() == 0
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["traits"] == []
    assert response.json()["identifier"] == identity.identifier


def test_sdk_identities_post__client_traits_disabled_server_key__persists_traits(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
    feature: Feature,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")
    trait_key, trait_value = "foo", "bar"
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": trait_key, "trait_value": trait_value}],
    }

    environment_api_key = EnvironmentAPIKey.objects.create(environment=environment)

    environment.allow_client_traits = False
    environment.save()
    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment_api_key.key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK

    assert Trait.objects.count() == 1
    trait = Trait.objects.first()
    assert trait.trait_key == trait_key  # type: ignore[union-attr]
    assert trait.trait_value == trait_value  # type: ignore[union-attr]


def test_sdk_identities_post__valid_request__includes_updated_at_header(
    identity: Identity,
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": "foo", "trait_value": "bar"}],
    }

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.headers[FLAGSMITH_UPDATED_AT_HEADER] == str(
        environment.updated_at.timestamp()
    )


def test_sdk_identities_get__valid_request__includes_updated_at_header(
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    url = "%s?identifier=identifier" % reverse("api-v1:sdk-identities")

    # When
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.headers[FLAGSMITH_UPDATED_AT_HEADER] == str(
        environment.updated_at.timestamp()
    )


def test_sdk_identities_get__hide_sensitive_data_with_feature__returns_nulled_fields(  # type: ignore[no-untyped-def]
    environment, feature, identity, api_client
):
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    environment.hide_sensitive_data = True
    environment.save()
    base_url = reverse("api-v1:sdk-identities")
    url = f"{base_url}?identifier={identity.identifier}&feature={feature.name}"
    feature_sensitive_fields = [
        "created_date",
        "description",
        "initial_value",
        "default_enabled",
    ]
    fs_sensitive_fields = ["id", "environment", "identity", "feature_segment"]

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    flag = response.json()

    # Check that the sensitive fields are None
    for field in fs_sensitive_fields:
        assert flag[field] is None

    for field in feature_sensitive_fields:
        assert flag["feature"][field] is None


def test_sdk_identities_get__hide_sensitive_data__returns_nulled_fields(  # type: ignore[no-untyped-def]
    environment, feature, identity, api_client
):
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    environment.hide_sensitive_data = True
    environment.save()
    base_url = reverse("api-v1:sdk-identities")
    url = f"{base_url}?identifier={identity.identifier}"
    feature_sensitive_fields = [
        "created_date",
        "description",
        "initial_value",
        "default_enabled",
    ]
    fs_sensitive_fields = ["id", "environment", "identity", "feature_segment"]

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK

    # Check that the scalar sensitive fields are None
    for flag in response.json()["flags"]:
        for field in fs_sensitive_fields:
            assert flag[field] is None

        for field in feature_sensitive_fields:
            assert flag["feature"][field] is None

    assert response.json()["traits"] == []


def test_get_identities__transient__no_persistence(
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    identifier = "transient"
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    url = reverse("api-v1:sdk-identities") + f"?identifier={identifier}&transient=true"

    # When
    response = api_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert not Identity.objects.filter(identifier=identifier).count()


def test_sdk_identities_post__hide_sensitive_data__returns_nulled_fields(  # type: ignore[no-untyped-def]
    environment, feature, identity, api_client
):
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    environment.hide_sensitive_data = True
    environment.save()
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": "foo", "trait_value": "bar"}],
    }
    feature_sensitive_fields = [
        "created_date",
        "description",
        "initial_value",
        "default_enabled",
    ]
    fs_sensitive_fields = ["id", "environment", "identity", "feature_segment"]

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK

    # Check that the scalar sensitive fields are None
    for flag in response.json()["flags"]:
        for field in fs_sensitive_fields:
            assert flag[field] is None

        for field in feature_sensitive_fields:
            assert flag["feature"][field] is None

    assert response.json()["traits"] == []


def test_post_identities__server_key_only_feature__return_expected(
    environment: Environment,
    feature: Feature,
    identity: Identity,
    api_client: APIClient,
) -> None:
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    feature.is_server_key_only = True
    feature.save()

    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": "foo", "trait_value": "bar"}],
    }

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert not response.json()["flags"]


def test_sdk_identities_post__server_key_only_feature_with_server_key__returns_flag(
    environment_api_key: EnvironmentAPIKey,
    feature: Feature,
    identity: Identity,
    api_client: APIClient,
) -> None:
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment_api_key.key)
    feature.is_server_key_only = True
    feature.save()

    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "traits": [{"trait_key": "foo", "trait_value": "bar"}],
    }

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.json()["flags"]


@pytest.mark.parametrize(
    "identity_data",
    [
        pytest.param(
            {"identifier": "transient", "transient": True},
            id="new-identifier-transient-true",
        ),
        pytest.param({"identifier": ""}, id="blank-identifier"),
        pytest.param({"identifier": None}, id="null-identifier"),
        pytest.param({}, id="missing_identifier"),
    ],
)
def test_post_identities__transient__no_persistence(
    environment: Environment,
    api_client: APIClient,
    identity_data: dict[str, Any],
) -> None:
    # Given
    trait_key = "trait_key"

    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    url = reverse("api-v1:sdk-identities")
    data = {
        **identity_data,
        "traits": [{"trait_key": trait_key, "trait_value": "bar"}],
    }

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert not Identity.objects.exists()
    assert not Trait.objects.filter(trait_key=trait_key).exists()


@pytest.mark.parametrize(
    "trait_transiency_data",
    [
        pytest.param({"transient": True}, id="trait-transient-true"),
        pytest.param({"transient": False}, id="trait-transient-false"),
        pytest.param({}, id="trait-default"),
    ],
)
def test_sdk_identities_post__existing_identity_transient__does_not_persist(
    environment: Environment,
    identity: Identity,
    trait: Trait,
    identity_featurestate: FeatureState,
    api_client: APIClient,
    trait_transiency_data: dict[str, Any],
) -> None:
    # Given
    feature_state_value = "identity override"
    identity_featurestate.feature_state_value.string_value = feature_state_value
    identity_featurestate.feature_state_value.save()

    trait_key = "trait_key"

    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identity.identifier,
        "transient": True,
        "traits": [
            {"trait_key": trait_key, "trait_value": "bar", **trait_transiency_data}
        ],
    }

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    response_json = response.json()

    # identity overrides are correctly loaded
    assert response_json["flags"][0]["feature_state_value"] == feature_state_value

    # previously persisted traits not provided in the request
    # are not marked as transient in the response
    assert response_json["traits"][0]["trait_key"] == trait.trait_key
    assert not response_json["traits"][0].get("transient")

    # every trait provided in the request for a transient identity
    # is marked as transient
    assert response_json["traits"][1]["trait_key"] == trait_key
    assert response_json["traits"][1]["transient"]

    assert (
        persisted_trait := Trait.objects.filter(
            identity=identity, trait_key=trait.trait_key
        ).first()
    )
    assert persisted_trait.trait_value == trait.trait_value
    assert not Trait.objects.filter(identity=identity, trait_key=trait_key).exists()


def test_post_identities__transient_traits__no_persistence(
    environment: Environment,
    api_client: APIClient,
) -> None:
    # Given
    identifier = "transient"
    transient_trait_key = "trait_key"
    non_transient_trait_key = "other"

    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    url = reverse("api-v1:sdk-identities")
    data = {
        "identifier": identifier,
        "traits": [
            {"trait_key": transient_trait_key, "trait_value": "bar", "transient": True},
            {"trait_key": non_transient_trait_key, "trait_value": "value"},
        ],
    }

    # When
    response = api_client.post(
        url, data=json.dumps(data), content_type="application/json"
    )

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert Identity.objects.filter(identifier=identifier).exists()
    assert Trait.objects.filter(trait_key=non_transient_trait_key).exists()
    assert not Trait.objects.filter(trait_key=transient_trait_key).exists()


def test_identity_detail__user_with_view_identities_permission__returns_ok(
    environment: Environment,
    identity: Identity,
    staff_client: APIClient,
    view_environment_permission: PermissionModel,
    view_identities_permission: PermissionModel,
    view_project_permission: PermissionModel,
    user_environment_permission: UserEnvironmentPermission,
    user_project_permission: UserProjectPermission,
) -> None:
    # Given

    user_environment_permission.permissions.add(
        view_environment_permission, view_identities_permission
    )
    user_project_permission.permissions.add(view_project_permission)

    url = reverse(
        "api-v1:environments:environment-identities-detail",
        args=(environment.api_key, identity.id),
    )

    # When
    response = staff_client.get(url)

    # Then
    assert response.status_code == status.HTTP_200_OK


def test_identity_list__user_without_view_identities_permission__returns_403(
    environment: Environment,
    identity: Identity,
    staff_client: APIClient,
    view_environment_permission: PermissionModel,
    manage_identities_permission: PermissionModel,
    view_project_permission: PermissionModel,
    user_environment_permission: UserEnvironmentPermission,
    user_project_permission: UserProjectPermission,
) -> None:
    # Given

    user_environment_permission.permissions.add(view_environment_permission)
    user_project_permission.permissions.add(view_project_permission)

    url = reverse(
        "api-v1:environments:environment-identities-list",
        args=(environment.api_key,),
    )

    # When
    response = staff_client.get(url)

    # Then
    assert response.status_code == status.HTTP_403_FORBIDDEN


def test_identity_view_set__get_permissions__returns_expected_permissions():  # type: ignore[no-untyped-def]
    # Given
    view_set = views.IdentityViewSet()

    # When
    permissions = view_set.get_permissions()  # type: ignore[no-untyped-call]

    # Then
    assert isinstance(permissions[0], IsAuthenticated)
    assert isinstance(permissions[1], NestedEnvironmentPermissions)

    assert permissions[1].action_permission_map == {
        "list": VIEW_IDENTITIES,
        "retrieve": VIEW_IDENTITIES,
        "create": MANAGE_IDENTITIES,
        "update": MANAGE_IDENTITIES,
        "partial_update": MANAGE_IDENTITIES,
        "destroy": MANAGE_IDENTITIES,
    }


# NOTE: DEPRECATED
@pytest.mark.parametrize(
    ["use_replica", "is_new_identity", "num_queries"],
    [
        pytest.param(False, True, 12, id="default_database,new_identity"),
        pytest.param(False, False, 7, id="default_database,existing_identity"),
        pytest.param(True, True, 12, id="replica_database,new_identity"),
        pytest.param(True, False, 9, id="replica_database,existing_identity"),
    ],
)
def test_SDKIdentitiesDeprecated__given_identifier__retrieves_identity(
    api_client: APIClient,
    django_assert_num_queries: DjangoAssertNumQueries,
    environment: Environment,
    feature_state: FeatureState,
    identity: Identity,
    is_new_identity: bool,
    mocker: MockerFixture,
    num_queries: int,
    trait: Trait,
    use_replica: bool,
) -> None:
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    mocker.patch.object(views, "is_database_replica_setup", return_value=use_replica)
    identifier = "jamesbond" if is_new_identity else identity.identifier

    # When
    with django_assert_num_queries(num_queries):
        response = api_client.get(f"/api/v1/identities/{identifier}/")

    # Then
    assert response.status_code == status.HTTP_200_OK
    assert response.json() == {
        "flags": [mocker.ANY],
        "segments": [],
        "traits": [mocker.ANY] * (not is_new_identity),
    }


@pytest.mark.parametrize(
    ["use_replica", "is_new_identity", "is_transient", "num_queries"],
    [
        pytest.param(False, True, False, 10, id="default_db,new_identity"),
        pytest.param(False, False, False, 6, id="default_db,old_identity"),
        pytest.param(True, True, False, 10, id="replica_db,new_identity"),
        pytest.param(True, False, False, 8, id="replica_db,old_identity"),
        pytest.param(False, True, True, 4, id="default_db,new_identity,transient"),
        pytest.param(False, False, True, 4, id="default_db,old_identity,transient"),
        pytest.param(True, True, True, 4, id="replica_db,new_identity,transient"),
        pytest.param(True, False, True, 4, id="replica_db,old_identity,transient"),
    ],
)
def test_sdk_identities_get__given_identifier__retrieves_feature_states(
    api_client: APIClient,
    django_assert_num_queries: DjangoAssertNumQueries,
    environment: Environment,
    feature_state: FeatureState,
    identity: Identity,
    is_new_identity: bool,
    is_transient: bool,
    mocker: MockerFixture,
    num_queries: int,
    trait: Trait,
    use_replica: bool,
) -> None:
    # Given
    api_client.credentials(HTTP_X_ENVIRONMENT_KEY=environment.api_key)
    mocker.patch.object(views, "is_database_replica_setup", return_value=use_replica)
    identifier = "jamesbond" if is_new_identity else identity.identifier

    # When
    with django_assert_num_queries(num_queries):
        transient = "&transient=true" if is_transient else ""
        response = api_client.get(
            f"/api/v1/identities/?identifier={identifier}{transient}"
        )

    # Then
    assert response.status_code == status.HTTP_200_OK
