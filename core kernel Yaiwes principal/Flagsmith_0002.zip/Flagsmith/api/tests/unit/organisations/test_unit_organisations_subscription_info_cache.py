from datetime import timedelta

import pytest
from django.utils import timezone
from pytest_django.fixtures import SettingsWrapper
from pytest_mock import MockerFixture
from task_processor.task_run_method import TaskRunMethod

from organisations.chargebee.metadata import ChargebeeObjMetadata
from organisations.models import (
    Organisation,
    OrganisationSubscriptionInformationCache,
    Subscription,
)
from organisations.subscription_info_cache import update_caches
from organisations.subscriptions.constants import SubscriptionCacheEntity


@pytest.mark.freeze_time("2023-01-19T09:09:47.325132+00:00")
def test_update_caches__with_usage_data__populates_cache_correctly(  # type: ignore[no-untyped-def]
    mocker, organisation, chargebee_subscription, settings
):
    # Given
    settings.CHARGEBEE_API_KEY = "api-key"
    settings.INFLUXDB_TOKEN = "token"
    settings.TASK_RUN_METHOD = TaskRunMethod.SYNCHRONOUSLY

    now = timezone.now()
    day_1 = now - timedelta(days=1)
    day_7 = now - timedelta(days=7)
    day_30 = now - timedelta(days=30)
    organisation_usage = {
        day_1: 25123,
        day_7: 182957,
        day_30: 804564,
    }
    mocked_get_top_organisations = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations"
    )
    mocked_get_top_organisations.side_effect = lambda t, _: {
        organisation.id: organisation_usage[t]
    }

    chargebee_metadata = ChargebeeObjMetadata(seats=15, api_calls=1000000)
    mocked_get_subscription_metadata = mocker.patch(
        "organisations.subscription_info_cache.get_subscription_metadata_from_id"
    )
    mocked_get_subscription_metadata.return_value = chargebee_metadata

    # When
    update_caches(SubscriptionCacheEntity.API_USAGE, SubscriptionCacheEntity.CHARGEBEE)

    # Then
    assert (
        organisation.subscription_information_cache.api_calls_24h
        == organisation_usage[day_1]
    )
    assert (
        organisation.subscription_information_cache.api_calls_7d
        == organisation_usage[day_7]
    )
    assert (
        organisation.subscription_information_cache.api_calls_30d
        == organisation_usage[day_30]
    )
    assert (
        organisation.subscription_information_cache.allowed_seats
        == chargebee_metadata.seats
    )
    assert (
        organisation.subscription_information_cache.allowed_30d_api_calls
        == chargebee_metadata.api_calls
    )

    mocked_get_subscription_metadata.assert_called_once_with(
        chargebee_subscription.subscription_id
    )

    assert mocked_get_top_organisations.call_count == 3
    assert [call[0] for call in mocked_get_top_organisations.call_args_list] == [
        (day_30, ""),
        (day_7, ""),
        (day_1, "100"),
    ]


def test_update_caches__no_usage_data__resets_cache_to_zero(
    mocker: MockerFixture,
    organisation: Organisation,
    chargebee_subscription: Subscription,
    settings: SettingsWrapper,
) -> None:
    # Given
    settings.CHARGEBEE_API_KEY = "api-key"
    settings.INFLUXDB_TOKEN = "token"
    settings.TASK_RUN_METHOD = TaskRunMethod.SYNCHRONOUSLY

    OrganisationSubscriptionInformationCache.objects.create(
        organisation=organisation,
        api_calls_24h=1,
        api_calls_7d=1,
        api_calls_30d=1,
    )

    mocked_get_top_organisations = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations"
    )
    mocked_get_top_organisations.return_value = {}

    chargebee_metadata = ChargebeeObjMetadata(seats=15, api_calls=1000000)
    mocked_get_subscription_metadata = mocker.patch(
        "organisations.subscription_info_cache.get_subscription_metadata_from_id"
    )
    mocked_get_subscription_metadata.return_value = chargebee_metadata

    # When
    update_caches(SubscriptionCacheEntity.API_USAGE, SubscriptionCacheEntity.CHARGEBEE)

    # Then
    organisation.refresh_from_db()
    assert organisation.subscription_information_cache.api_calls_24h == 0
    assert organisation.subscription_information_cache.api_calls_7d == 0
    assert organisation.subscription_information_cache.api_calls_30d == 0


@pytest.mark.freeze_time("2023-01-19T09:09:47.325132+00:00")
def test_update_caches__postgres_analytics__populates_cache_correctly(
    mocker: MockerFixture,
    organisation: Organisation,
    settings: SettingsWrapper,
) -> None:
    # Given
    settings.USE_POSTGRES_FOR_ANALYTICS = True
    settings.INFLUXDB_TOKEN = None

    now = timezone.now()
    day_1 = now - timedelta(hours=24)
    day_7 = now - timedelta(days=7)
    day_30 = now - timedelta(days=30)
    organisation_usage = {
        day_1: 25123,
        day_7: 182957,
        day_30: 804564,
    }
    mock_get_top_organisations_from_local_db = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations_from_local_db",
        side_effect=lambda t: {organisation.id: organisation_usage[t]},
    )
    mock_get_top_organisations = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations"
    )

    # When
    update_caches(SubscriptionCacheEntity.API_USAGE)

    # Then
    organisation.refresh_from_db()
    assert (
        organisation.subscription_information_cache.api_calls_24h
        == organisation_usage[day_1]
    )
    assert (
        organisation.subscription_information_cache.api_calls_7d
        == organisation_usage[day_7]
    )
    assert (
        organisation.subscription_information_cache.api_calls_30d
        == organisation_usage[day_30]
    )
    assert mock_get_top_organisations_from_local_db.call_count == 3
    assert mock_get_top_organisations.call_count == 0


def test_update_caches__postgres_and_influx_configured__prefers_postgres(
    mocker: MockerFixture,
    organisation: Organisation,
    settings: SettingsWrapper,
) -> None:
    # Given
    settings.USE_POSTGRES_FOR_ANALYTICS = True
    settings.INFLUXDB_TOKEN = "token"

    mocked_get_top_organisations_from_local_db = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations_from_local_db",
        return_value={organisation.id: 42},
    )
    mock_get_top_organisations = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations"
    )

    # When
    update_caches(SubscriptionCacheEntity.API_USAGE)

    # Then
    assert mocked_get_top_organisations_from_local_db.call_count == 3
    assert mock_get_top_organisations.call_count == 0


def test_update_caches__no_analytics_source_configured__skips_api_usage_update(
    mocker: MockerFixture,
    organisation: Organisation,
    settings: SettingsWrapper,
) -> None:
    # Given
    settings.USE_POSTGRES_FOR_ANALYTICS = False
    settings.INFLUXDB_TOKEN = ""

    OrganisationSubscriptionInformationCache.objects.create(
        organisation=organisation,
        api_calls_24h=100,
        api_calls_7d=700,
        api_calls_30d=3000,
    )

    mock_get_top_organisations_from_local_db = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations_from_local_db",
    )
    mock_get_top_organisations = mocker.patch(
        "organisations.subscription_info_cache.get_top_organisations",
    )

    # When
    update_caches(SubscriptionCacheEntity.API_USAGE)

    # Then — neither analytics source was queried
    assert mock_get_top_organisations_from_local_db.call_count == 0
    assert mock_get_top_organisations.call_count == 0

    # And the existing cache values are preserved (not zeroed out)
    organisation.subscription_information_cache.refresh_from_db()
    assert organisation.subscription_information_cache.api_calls_24h == 100
    assert organisation.subscription_information_cache.api_calls_7d == 700
    assert organisation.subscription_information_cache.api_calls_30d == 3000
