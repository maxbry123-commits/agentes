class EnvironmentHeaderNotPresentError(Exception):
    pass
