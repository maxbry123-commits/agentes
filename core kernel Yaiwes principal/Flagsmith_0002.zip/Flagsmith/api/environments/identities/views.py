import typing
from collections import namedtuple

from common.core.utils import is_database_replica_setup, using_database_replica
from common.environments.permissions import (
    MANAGE_IDENTITIES,
    VIEW_IDENTITIES,
)
from django.conf import settings
from django.db.models import Q
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_headers
from drf_spectacular.utils import extend_schema
from flagsmith_schemas import api as api_schemas
from rest_framework import status, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from app.pagination import CustomPagination
from core.constants import FLAGSMITH_UPDATED_AT_HEADER, SDK_ENVIRONMENT_KEY_HEADER
from core.request_origin import RequestOrigin
from edge_api.identities.tasks import forward_identity_request
from environments.identities.models import Identity
from environments.identities.serializers import (
    IdentitySerializer,
    SDKIdentitiesQuerySerializer,
)
from environments.identities.services import replace_identity_environment
from environments.models import Environment
from environments.permissions.permissions import NestedEnvironmentPermissions
from environments.sdk.serializers import (
    IdentifyWithTraitsSerializer,
    IdentitySerializerWithTraitsAndSegments,
)
from features.serializers import SDKIdentityFeatureStateSerializer
from integrations.integration import identify_integrations
from util.views import SDKAPIView


class IdentityViewSet(viewsets.ModelViewSet):  # type: ignore[type-arg]
    serializer_class = IdentitySerializer
    pagination_class = CustomPagination

    def get_queryset(self):  # type: ignore[no-untyped-def]
        if getattr(self, "swagger_fake_view", False):
            return Identity.objects.none()

        environment = self.get_environment_from_request()  # type: ignore[no-untyped-call]
        queryset = Identity.objects.filter(environment=environment)

        search_query = self.request.query_params.get("q")
        if search_query:
            if search_query.startswith('"') and search_query.endswith('"'):
                # Quoted searches should do an exact match just like Google
                queryset = queryset.filter(
                    identifier__exact=search_query.replace('"', "")
                )
            else:
                # Otherwise do a fuzzy search
                queryset = queryset.filter(identifier__icontains=search_query)

        # change the default order by to avoid performance issues with pagination
        # when environments have small number (<page_size) of records
        queryset = queryset.order_by("created_date")

        return queryset

    def get_permissions(self):  # type: ignore[no-untyped-def]
        return [
            IsAuthenticated(),
            NestedEnvironmentPermissions(
                action_permission_map={
                    "list": VIEW_IDENTITIES,
                    "retrieve": VIEW_IDENTITIES,
                    "create": MANAGE_IDENTITIES,
                    "update": MANAGE_IDENTITIES,
                    "partial_update": MANAGE_IDENTITIES,
                    "destroy": MANAGE_IDENTITIES,
                },
            ),
        ]

    def get_environment_from_request(self):  # type: ignore[no-untyped-def]
        """
        Get environment object from URL parameters in request.
        """
        return Environment.objects.get(api_key=self.kwargs["environment_api_key"])

    def perform_create(self, serializer):  # type: ignore[no-untyped-def]
        environment = self.get_environment_from_request()  # type: ignore[no-untyped-call]
        serializer.save(environment=environment)

    def perform_update(self, serializer):  # type: ignore[no-untyped-def]
        environment = self.get_environment_from_request()  # type: ignore[no-untyped-call]
        serializer.save(environment=environment)


class SDKIdentitiesDeprecated(SDKAPIView):
    """
    THIS ENDPOINT IS DEPRECATED. Please use `/identities/?identifier=<identifier>` instead.
    """

    # API to handle /api/v1/identities/ endpoint to return Flags and Traits for user Identity
    # if Identity does not exist it will create one, otherwise will fetch existing

    serializer_class = IdentifyWithTraitsSerializer
    throttle_classes = []

    schema = None

    # identifier is in a path parameter
    def get(self, request, identifier, *args, **kwargs):  # type: ignore[no-untyped-def]
        # if we have identifier fetch, or create if does not exist
        identity, is_new_identity = Identity.objects.get_or_create_for_sdk(
            identifier=identifier,
            environment=request.environment,
        )

        # New identities may take a while to replicate — otherwise use a replica
        if not is_new_identity and is_database_replica_setup():
            identity = (
                using_database_replica(Identity.objects)
                .with_traits()
                .get(id=identity.id)
            )
            replace_identity_environment(identity, request.environment)

        traits_data = identity.get_all_user_traits()  # type: ignore[no-untyped-call]

        # We need object type to pass into our IdentitySerializerTraitFlags
        IdentityFlagsWithTraitsAndSegments = namedtuple(  # type: ignore[name-match]
            "IdentityTraitFlagsSegments", ("flags", "traits", "segments")
        )
        identity_flags_traits_segments = IdentityFlagsWithTraitsAndSegments(
            flags=identity.get_all_feature_states(),
            traits=traits_data,
            segments=identity.get_segments(),
        )

        serializer = IdentitySerializerWithTraitsAndSegments(
            identity_flags_traits_segments
        )

        return Response(serializer.data, status=status.HTTP_200_OK)


@extend_schema(tags=["sdk"])
class SDKIdentities(SDKAPIView):
    serializer_class = IdentifyWithTraitsSerializer
    pagination_class = None  # set here to ensure documentation is correct
    throttle_classes = []

    @extend_schema(
        responses={200: api_schemas.V1IdentitiesResponse},
        parameters=[SDKIdentitiesQuerySerializer],
        operation_id="sdk_v1_get_identities",
    )
    @method_decorator(vary_on_headers(SDK_ENVIRONMENT_KEY_HEADER))
    @method_decorator(
        cache_page(
            timeout=settings.GET_IDENTITIES_ENDPOINT_CACHE_SECONDS,
            cache=settings.GET_IDENTITIES_ENDPOINT_CACHE_NAME,
        )
    )
    def get(self, request):  # type: ignore[no-untyped-def]
        """
        Retrieve the flags and traits for an identity.
        """
        identifier = request.query_params.get("identifier")
        if not identifier:
            return Response(
                {"detail": "Missing identifier"}
            )  # TODO: add 400 status - will this break the clients?

        if request.query_params.get("transient"):
            identity = Identity(
                created_date=timezone.now(),
                identifier=identifier,
                environment=request.environment,
            )
            is_new_identity = True
        else:
            identity, is_new_identity = Identity.objects.get_or_create_for_sdk(
                identifier=identifier,
                environment=request.environment,
            )

        # New identities may take a while to replicate — otherwise use a replica
        if not is_new_identity and is_database_replica_setup():
            identity = (
                using_database_replica(Identity.objects)
                .with_traits()
                .get(id=identity.id)
            )
            replace_identity_environment(identity, request.environment)

        self.identity = identity

        if settings.EDGE_API_URL and request.environment.project.enable_dynamo_db:
            forward_identity_request.delay(
                args=(
                    request.method,
                    dict(request.headers),
                    request.environment.project.id,
                ),
                kwargs={"query_params": request.GET.dict()},
            )

        # Note that we send the environment updated_at value here since it covers most use cases
        # in which an identity will need updated flags. It will not cover identity overrides or
        # adding traits to the identity (which adds / removes them to / from segments).
        # TODO: handle identity overrides.
        headers = {
            FLAGSMITH_UPDATED_AT_HEADER: request.environment.updated_at.timestamp()
        }

        feature_name = request.query_params.get("feature")
        if feature_name:
            response = self._get_single_feature_state_response(
                identity, feature_name, headers=headers
            )
        else:
            response = self._get_all_feature_states_for_user_response(
                identity, headers=headers
            )

        return response

    def get_serializer_context(self):  # type: ignore[no-untyped-def]
        context = super(SDKIdentities, self).get_serializer_context()
        if hasattr(self.request, "environment"):
            # only set it if the request has the attribute to ensure that the
            # documentation works correctly still
            context["environment"] = self.request.environment
            if getattr(self, "identity", None):
                context["identity"] = self.identity
        context["feature_states_additional_filters"] = self._get_additional_filters()
        return context

    @extend_schema(
        request=api_schemas.V1IdentitiesRequest,
        responses={200: api_schemas.V1IdentitiesResponse},
        operation_id="sdk_v1_post_identities",
    )
    def post(self, request):  # type: ignore[no-untyped-def]
        """
        Identify a user, set their traits, and retrieve their flags.
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        self.identity = instance.get("identity")

        if settings.EDGE_API_URL and request.environment.project.enable_dynamo_db:
            forward_identity_request.delay(
                args=(
                    request.method,
                    dict(request.headers),
                    request.environment.project.id,
                ),
                kwargs={"request_data": request.data},
            )

        # we need to serialize the response again to ensure that the
        # trait values are serialized correctly
        response_serializer = IdentifyWithTraitsSerializer(
            instance=instance,
            context=self.get_serializer_context(),  # type: ignore[no-untyped-call]
        )
        return Response(
            response_serializer.data,
            headers={
                FLAGSMITH_UPDATED_AT_HEADER: request.environment.updated_at.timestamp()
            },
        )

    def _get_additional_filters(self) -> Q | None:
        if self.request.originated_from is RequestOrigin.CLIENT:
            return Q(feature__is_server_key_only=False)
        return None

    def _get_single_feature_state_response(
        self,
        identity: Identity,
        feature_name: str,
        headers: dict[str, typing.Any],
    ) -> Response:
        context = self.get_serializer_context()  # type: ignore[no-untyped-call]

        for feature_state in identity.get_all_feature_states(
            additional_filters=self._get_additional_filters(),
        ):
            if feature_state.feature.name == feature_name:
                serializer = SDKIdentityFeatureStateSerializer(
                    feature_state, context=context
                )
                return Response(
                    data=serializer.data, status=status.HTTP_200_OK, headers=headers
                )

        return Response(
            {"detail": "Given feature not found"},
            status=status.HTTP_404_NOT_FOUND,
            headers=headers,
        )

    def _get_all_feature_states_for_user_response(  # type: ignore[no-untyped-def]
        self,
        identity: Identity,
        headers: dict[str, typing.Any],
    ):
        """
        Get all feature states for an identity

        :param identity: Identity model to return feature states for
        :return: Response containing lists of both serialized flags and traits
        """
        all_feature_states = identity.get_all_feature_states(
            additional_filters=self._get_additional_filters(),
        )
        serializer_class = self.get_serializer_class()
        serializer = serializer_class(
            {
                "flags": all_feature_states,
                "identifier": identity.identifier,
                "traits": identity.identity_traits.all() if identity.id else [],
            },
            context=self.get_serializer_context(),  # type: ignore[no-untyped-call]
        )

        identify_integrations(identity, all_feature_states)  # type: ignore[no-untyped-call]

        return Response(
            data=serializer.data, status=status.HTTP_200_OK, headers=headers
        )
