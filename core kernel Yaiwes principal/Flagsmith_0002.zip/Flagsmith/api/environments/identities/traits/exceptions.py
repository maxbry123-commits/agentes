class TraitPersistenceError(Exception):
    pass
