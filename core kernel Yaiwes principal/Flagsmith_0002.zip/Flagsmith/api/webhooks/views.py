import requests
from drf_spectacular.utils import extend_schema
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response

from webhooks.webhooks import WebhookType

from .permissions import TriggerSampleWebhookPermission
from .serializers import (
    TestWebhookErrorResponseSerializer,
    TestWebhookSerializer,
    TestWebhookSuccessResponseSerializer,
)
from .webhooks import send_test_request_to_webhook


class WebhookViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated, TriggerSampleWebhookPermission]

    @extend_schema(
        request=TestWebhookSerializer,
        responses={
            200: TestWebhookSuccessResponseSerializer(),
            400: TestWebhookErrorResponseSerializer(),
        },
    )
    @action(
        detail=False,
        url_path="test",
        methods=["POST"],
    )
    def test(self, request: Request) -> Response:
        serializer = TestWebhookSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data
        secret = data.get("secret")
        webhook_url = data["webhook_url"]
        scope_type = data.get("scope", {}).get("type")
        try:
            webhook_type = (
                WebhookType.ORGANISATION
                if scope_type == "organisation"
                else WebhookType.ENVIRONMENT
            )
            response = send_test_request_to_webhook(webhook_url, secret, webhook_type)
            if not response.ok:
                return Response(
                    {
                        "detail": "Webhook returned error status",
                        "body": f"Webhook returned HTTP {response.status_code}.",
                        "status": response.status_code,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
            return Response(
                {
                    "detail": "Webhook test successful",
                    "status": response.status_code,
                },
                status=status.HTTP_200_OK,
            )
        except requests.exceptions.RequestException:
            return Response(
                {
                    "detail": "Could not connect to webhook URL",
                    "body": "Please check the URL, and ensure it is valid and accessible from the server.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
