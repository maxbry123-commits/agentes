class WebhookSendError(Exception):
    pass
