class InvalidInviteError(BaseException):
    pass
