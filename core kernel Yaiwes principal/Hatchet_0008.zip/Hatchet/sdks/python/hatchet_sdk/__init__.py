# ruff: noqa: E402

import os

# Must be set before grpc is imported anywhere — the C extension reads this at load
# time and won't re-read it after. Disable by default; opt in via env var for
# setups that genuinely need fork support (e.g. Gunicorn prefork).
_fork_env = os.environ.get("HATCHET_CLIENT_GRPC_ENABLE_FORK_SUPPORT", "false").lower()
_grpc_fork = _fork_env in ("true", "1", "yes")
os.environ.setdefault("GRPC_ENABLE_FORK_SUPPORT", "true" if _grpc_fork else "false")
if _grpc_fork:
    os.environ.setdefault("GRPC_POLL_STRATEGY", "poll")

from hatchet_sdk.clients.admin import (
    RunStatus,
)
from hatchet_sdk.clients.listeners.run_event_listener import (
    RunEventListener,
    StepRunEventType,
    WorkflowRunEventType,
)

# import models into sdk package
from hatchet_sdk.clients.rest.models.accept_invite_request import AcceptInviteRequest
from hatchet_sdk.clients.rest.models.api_error import APIError
from hatchet_sdk.clients.rest.models.api_errors import APIErrors
from hatchet_sdk.clients.rest.models.api_meta import APIMeta
from hatchet_sdk.clients.rest.models.api_meta_auth import APIMetaAuth
from hatchet_sdk.clients.rest.models.api_meta_integration import APIMetaIntegration
from hatchet_sdk.clients.rest.models.api_resource_meta import APIResourceMeta
from hatchet_sdk.clients.rest.models.api_token import APIToken
from hatchet_sdk.clients.rest.models.create_api_token_request import (
    CreateAPITokenRequest,
)
from hatchet_sdk.clients.rest.models.create_api_token_response import (
    CreateAPITokenResponse,
)
from hatchet_sdk.clients.rest.models.create_pull_request_from_step_run import (
    CreatePullRequestFromStepRun,
)
from hatchet_sdk.clients.rest.models.create_tenant_invite_request import (
    CreateTenantInviteRequest,
)
from hatchet_sdk.clients.rest.models.create_tenant_request import CreateTenantRequest
from hatchet_sdk.clients.rest.models.event import Event
from hatchet_sdk.clients.rest.models.event_data import EventData
from hatchet_sdk.clients.rest.models.event_key_list import EventKeyList
from hatchet_sdk.clients.rest.models.event_list import EventList
from hatchet_sdk.clients.rest.models.event_order_by_direction import (
    EventOrderByDirection,
)
from hatchet_sdk.clients.rest.models.event_order_by_field import EventOrderByField
from hatchet_sdk.clients.rest.models.event_workflow_run_summary import (
    EventWorkflowRunSummary,
)
from hatchet_sdk.clients.rest.models.get_step_run_diff_response import (
    GetStepRunDiffResponse,
)
from hatchet_sdk.clients.rest.models.job import Job
from hatchet_sdk.clients.rest.models.job_run import JobRun
from hatchet_sdk.clients.rest.models.job_run_status import JobRunStatus
from hatchet_sdk.clients.rest.models.list_api_tokens_response import (
    ListAPITokensResponse,
)
from hatchet_sdk.clients.rest.models.list_pull_requests_response import (
    ListPullRequestsResponse,
)
from hatchet_sdk.clients.rest.models.log_line import LogLine
from hatchet_sdk.clients.rest.models.log_line_level import LogLineLevel
from hatchet_sdk.clients.rest.models.log_line_list import LogLineList
from hatchet_sdk.clients.rest.models.log_line_order_by_direction import (
    LogLineOrderByDirection,
)
from hatchet_sdk.clients.rest.models.log_line_order_by_field import LogLineOrderByField
from hatchet_sdk.clients.rest.models.pagination_response import PaginationResponse
from hatchet_sdk.clients.rest.models.pull_request import PullRequest
from hatchet_sdk.clients.rest.models.pull_request_state import PullRequestState
from hatchet_sdk.clients.rest.models.reject_invite_request import RejectInviteRequest
from hatchet_sdk.clients.rest.models.replay_event_request import ReplayEventRequest
from hatchet_sdk.clients.rest.models.rerun_step_run_request import RerunStepRunRequest
from hatchet_sdk.clients.rest.models.step_run import StepRun
from hatchet_sdk.clients.rest.models.step_run_diff import StepRunDiff
from hatchet_sdk.clients.rest.models.step_run_status import StepRunStatus
from hatchet_sdk.clients.rest.models.tenant import Tenant
from hatchet_sdk.clients.rest.models.tenant_invite import TenantInvite
from hatchet_sdk.clients.rest.models.tenant_invite_list import TenantInviteList
from hatchet_sdk.clients.rest.models.tenant_list import TenantList
from hatchet_sdk.clients.rest.models.tenant_member import TenantMember
from hatchet_sdk.clients.rest.models.tenant_member_list import TenantMemberList
from hatchet_sdk.clients.rest.models.tenant_member_role import TenantMemberRole
from hatchet_sdk.clients.rest.models.trigger_workflow_run_request import (
    TriggerWorkflowRunRequest,
)
from hatchet_sdk.clients.rest.models.update_tenant_invite_request import (
    UpdateTenantInviteRequest,
)
from hatchet_sdk.clients.rest.models.user import User
from hatchet_sdk.clients.rest.models.user_login_request import UserLoginRequest
from hatchet_sdk.clients.rest.models.user_register_request import UserRegisterRequest
from hatchet_sdk.clients.rest.models.user_tenant_memberships_list import (
    UserTenantMembershipsList,
)
from hatchet_sdk.clients.rest.models.user_tenant_public import UserTenantPublic
from hatchet_sdk.clients.rest.models.v1_task_status import V1TaskStatus
from hatchet_sdk.clients.rest.models.v1_webhook_hmac_algorithm import (
    V1WebhookHMACAlgorithm,
)
from hatchet_sdk.clients.rest.models.v1_webhook_hmac_encoding import (
    V1WebhookHMACEncoding,
)
from hatchet_sdk.clients.rest.models.v1_webhook_source_name import V1WebhookSourceName
from hatchet_sdk.clients.rest.models.worker_list import WorkerList
from hatchet_sdk.clients.rest.models.workflow import Workflow
from hatchet_sdk.clients.rest.models.workflow_list import WorkflowList
from hatchet_sdk.clients.rest.models.workflow_run import WorkflowRun
from hatchet_sdk.clients.rest.models.workflow_run_list import WorkflowRunList
from hatchet_sdk.clients.rest.models.workflow_run_status import WorkflowRunStatus
from hatchet_sdk.clients.rest.models.workflow_run_triggered_by import (
    WorkflowRunTriggeredBy,
)
from hatchet_sdk.clients.rest.models.workflow_tag import WorkflowTag
from hatchet_sdk.clients.rest.models.workflow_trigger_cron_ref import (
    WorkflowTriggerCronRef,
)
from hatchet_sdk.clients.rest.models.workflow_trigger_event_ref import (
    WorkflowTriggerEventRef,
)
from hatchet_sdk.clients.rest.models.workflow_triggers import WorkflowTriggers
from hatchet_sdk.clients.rest.models.workflow_version import WorkflowVersion
from hatchet_sdk.clients.rest.models.workflow_version_definition import (
    WorkflowVersionDefinition,
)
from hatchet_sdk.clients.rest.models.workflow_version_meta import WorkflowVersionMeta
from hatchet_sdk.conditions import (
    Condition,
    OrGroup,
    ParentCondition,
    SleepCondition,
    UserEventCondition,
    or_,
)
from hatchet_sdk.config import (
    ClientConfig,
    ClientTLSConfig,
    EmbeddedHatchetConfig,
    HealthcheckConfig,
    OpenTelemetryConfig,
    TenacityConfig,
)
from hatchet_sdk.context.context import Context, DurableContext
from hatchet_sdk.context.worker_context import WorkerContext
from hatchet_sdk.contracts.workflows_pb2 import CreateWorkflowVersionOpts
from hatchet_sdk.exceptions import (
    BulkTriggerIdempotencyCollisionError,
    DedupeViolationError,
    EvictionNotSupportedError,
    FailedTaskRunExceptionGroup,
    IdempotencyCollisionError,
    NonDeterminismError,
    NonRetryableException,
    TaskRunError,
)
from hatchet_sdk.features.cel import CELEvaluationResult, CELFailure, CELSuccess
from hatchet_sdk.features.runs import BulkCancelReplayOpts, RunFilter
from hatchet_sdk.hatchet import Hatchet
from hatchet_sdk.runnables.eviction import EvictionPolicy
from hatchet_sdk.runnables.task import Depends, Task
from hatchet_sdk.runnables.types import (
    DefaultFilter,
    EmptyModel,
    TaskDefaults,
    WorkflowConfig,
)
from hatchet_sdk.runnables.workflow import TaskRunRef
from hatchet_sdk.serde import is_in_hatchet_serialization_context
from hatchet_sdk.types.concurrency import (
    ConcurrencyExpression,
    ConcurrencyLimitStrategy,
)
from hatchet_sdk.types.idempotency import (
    StatusBasedIdempotencyConfig,
    TTLBasedIdempotencyConfig,
)
from hatchet_sdk.types.labels import (
    DesiredWorkerLabel,
    WorkerLabel,
    WorkerLabelComparator,
)
from hatchet_sdk.types.priority import Priority
from hatchet_sdk.types.rate_limit import RateLimit, RateLimitDuration
from hatchet_sdk.types.slot_types import SlotType
from hatchet_sdk.types.sticky import StickyStrategy
from hatchet_sdk.types.trigger import (
    BulkPushEventOptions,
    BulkPushEventWithMetadata,
    PushEventOptions,
    ScheduleTriggerWorkflowOptions,
    TriggerWorkflowOptions,
    WorkflowRunTriggerConfig,
)
from hatchet_sdk.utils.opentelemetry import OTelAttribute
from hatchet_sdk.utils.serde import remove_null_unicode_character
from hatchet_sdk.worker.worker import Worker, WorkerStartOptions, WorkerStatus
from hatchet_sdk.workflow_run import WorkflowRunRef

__all__ = [
    "APIError",
    "APIErrors",
    "APIMeta",
    "APIMetaAuth",
    "APIMetaIntegration",
    "APIResourceMeta",
    "APIToken",
    "AcceptInviteRequest",
    "BulkCancelReplayOpts",
    "BulkPushEventOptions",
    "BulkPushEventWithMetadata",
    "BulkTriggerIdempotencyCollisionError",
    "CELEvaluationResult",
    "CELFailure",
    "CELSuccess",
    "ClientConfig",
    "ClientTLSConfig",
    "ConcurrencyExpression",
    "ConcurrencyLimitStrategy",
    "Condition",
    "Context",
    "CreateAPITokenRequest",
    "CreateAPITokenResponse",
    "CreatePullRequestFromStepRun",
    "CreateTenantInviteRequest",
    "CreateTenantRequest",
    "CreateWorkflowVersionOpts",
    "DedupeViolationError",
    "DefaultFilter",
    "Depends",
    "DesiredWorkerLabel",
    "DurableContext",
    "EmbeddedHatchetConfig",
    "EmptyModel",
    "Event",
    "EventData",
    "EventKeyList",
    "EventList",
    "EventOrderByDirection",
    "EventOrderByField",
    "EventWorkflowRunSummary",
    "EvictionNotSupportedError",
    "EvictionPolicy",
    "FailedTaskRunExceptionGroup",
    "GetStepRunDiffResponse",
    "GithubAppInstallation",
    "GithubBranch",
    "GithubRepo",
    "Hatchet",
    "HealthcheckConfig",
    "IdempotencyCollisionError",
    "Job",
    "JobRun",
    "JobRunStatus",
    "LinkGithubRepositoryRequest",
    "ListAPITokensResponse",
    "ListGithubAppInstallationsResponse",
    "ListPullRequestsResponse",
    "LogLine",
    "LogLineLevel",
    "LogLineList",
    "LogLineOrderByDirection",
    "LogLineOrderByField",
    "NonDeterminismError",
    "NonRetryableException",
    "OTelAttribute",
    "OpenTelemetryConfig",
    "OrGroup",
    "PaginationResponse",
    "ParentCondition",
    "Priority",
    "PullRequest",
    "PullRequestState",
    "PushEventOptions",
    "RateLimit",
    "RateLimitDuration",
    "RegisterDurableEventRequest",
    "RejectInviteRequest",
    "ReplayEventRequest",
    "RerunStepRunRequest",
    "RunEventListener",
    "RunFilter",
    "RunStatus",
    "ScheduleTriggerWorkflowOptions",
    "ScheduleTriggerWorkflowOptions",
    "SleepCondition",
    "SlotType",
    "StatusBasedIdempotencyConfig",
    "StepRun",
    "StepRunDiff",
    "StepRunEventType",
    "StepRunStatus",
    "StickyStrategy",
    "TTLBasedIdempotencyConfig",
    "Task",
    "TaskDefaults",
    "TaskRunError",
    "TaskRunRef",
    "TenacityConfig",
    "Tenant",
    "TenantInvite",
    "TenantInviteList",
    "TenantList",
    "TenantMember",
    "TenantMemberList",
    "TenantMemberRole",
    "TriggerWorkflowOptions",
    "TriggerWorkflowOptions",
    "TriggerWorkflowRunRequest",
    "UpdateTenantInviteRequest",
    "User",
    "UserEventCondition",
    "UserLoginRequest",
    "UserRegisterRequest",
    "UserTenantMembershipsList",
    "UserTenantPublic",
    "V1TaskStatus",
    "V1WebhookHMACAlgorithm",
    "V1WebhookHMACEncoding",
    "V1WebhookSourceName",
    "Worker",
    "Worker",
    "WorkerContext",
    "WorkerLabel",
    "WorkerLabelComparator",
    "WorkerList",
    "WorkerStartOptions",
    "WorkerStatus",
    "Workflow",
    "Workflow",
    "WorkflowConfig",
    "WorkflowDeploymentConfig",
    "WorkflowList",
    "WorkflowRun",
    "WorkflowRunEventType",
    "WorkflowRunList",
    "WorkflowRunRef",
    "WorkflowRunStatus",
    "WorkflowRunTriggerConfig",
    "WorkflowRunTriggeredBy",
    "WorkflowTag",
    "WorkflowTriggerCronRef",
    "WorkflowTriggerEventRef",
    "WorkflowTriggers",
    "WorkflowVersion",
    "WorkflowVersionDefinition",
    "WorkflowVersionMeta",
    "is_in_hatchet_serialization_context",
    "or_",
    "remove_null_unicode_character",
    "workflow",
]
