import type {
  PromptManifest,
  QueueManifest,
  SkillManifest,
  SkillMetadata,
  TaskManifest,
  WebhookManifest,
  WebhookMetadata,
  WorkerManifest,
} from "../schemas/index.js";
import {
  type PromptMetadataWithFunctions,
  type TaskMetadataWithFunctions,
  type TaskSchema,
} from "../types/index.js";
import type { ResourceCatalog } from "./catalog.js";

export class NoopResourceCatalog implements ResourceCatalog {
  registerTaskMetadata(task: TaskMetadataWithFunctions): void {
    // noop
  }

  setCurrentFileContext(filePath: string, entryPoint: string): void {
    // noop
  }

  clearCurrentFileContext(): void {
    // noop
  }

  updateTaskMetadata(id: string, updates: Partial<TaskMetadataWithFunctions>): void {
    // noop
  }

  listTaskManifests(): Array<TaskManifest> {
    return [];
  }

  listTaskIdCollisions(): Array<{ id: string; filePaths: string[] }> {
    return [];
  }

  getTaskManifest(id: string): TaskManifest | undefined {
    return undefined;
  }

  getTask(id: string): TaskMetadataWithFunctions | undefined {
    return undefined;
  }

  getTaskSchema(id: string): TaskSchema | undefined {
    return undefined;
  }

  taskExists(id: string): boolean {
    return false;
  }

  disable() {
    // noop
  }

  registerWorkerManifest(workerManifest: WorkerManifest): void {
    // noop
  }

  registerQueueMetadata(queue: QueueManifest): void {
    // noop
  }

  listQueueManifests(): Array<QueueManifest> {
    return [];
  }

  registerPromptMetadata(prompt: PromptMetadataWithFunctions): void {
    // noop
  }

  listPromptManifests(): Array<PromptManifest> {
    return [];
  }

  getPrompt(id: string): PromptMetadataWithFunctions | undefined {
    return undefined;
  }

  getPromptSchema(id: string): TaskSchema | undefined {
    return undefined;
  }

  registerSkillMetadata(skill: SkillMetadata): void {
    // noop
  }

  listSkillManifests(): Array<SkillManifest> {
    return [];
  }

  getSkillManifest(id: string): SkillManifest | undefined {
    return undefined;
  }

  registerWebhookMetadata(webhook: WebhookMetadata): void {
    // noop
  }
  listWebhookManifests(): Array<WebhookManifest> {
    return [];
  }
  getWebhookManifest(id: string): WebhookManifest | undefined {
    return undefined;
  }
  listWebhookIdCollisions(): Array<{ id: string; filePaths: string[] }> {
    return [];
  }
  registerDeclaredSessionWebhook(id: string): void {
    // noop
  }
  markSessionWebhookClaimed(id: string): void {
    // noop
  }
  listUnclaimedSessionWebhooks(): Array<string> {
    return [];
  }
}
