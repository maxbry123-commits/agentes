import type { Instrumentation } from "@opentelemetry/instrumentation";
import type { SpanExporter } from "@opentelemetry/sdk-trace-base";
import type { MetricReader, PushMetricExporter } from "@opentelemetry/sdk-metrics";
import type { BuildExtension } from "./build/extensions.js";
import type {
  AnyOnFailureHookFunction,
  AnyOnInitHookFunction,
  AnyOnStartHookFunction,
  AnyOnSuccessHookFunction,
  ConfigRuntime,
  RetryOptions,
} from "./index.js";
import type { LogLevel } from "./logger/taskLogger.js";
import type { MachinePresetName } from "./schemas/common.js";
import type { LogRecordExporter } from "@opentelemetry/sdk-logs";
import type { Resource } from "@opentelemetry/resources";

export type CompatibilityFlag = "run_engine_v2";

export type CompatibilityFlagFeatures = {
  [key in CompatibilityFlag]: boolean;
};

type ProcessKeepAlive =
  | boolean
  | {
      enabled: boolean;
      /**
       * The maximum number of executions per process. If the process has run more than this number of times, it will be killed.
       *
       * @default 50
       */
      maxExecutionsPerProcess?: number;

      /**
       * The maximum number of processes to keep alive in dev.
       *
       * @default 25
       */
      devMaxPoolSize?: number;
    };

export type TriggerConfig = {
  /**
   * @default "node"
   */
  runtime?: ConfigRuntime;

  /**
   * Specify the project ref for your trigger.dev tasks. This is the project ref that you get when you create a new project in the trigger.dev dashboard.
   */
  project: string;

  /**
   * Specify the directories that contain your trigger.dev tasks. This is useful if you have multiple directories that contain tasks.
   *
   * We automatically detect directories named `trigger` to be task directories. You can override this behavior by specifying the directories here.
   *
   * @see @see https://trigger.dev/docs/config/config-file#dirs
   */
  dirs?: string[];

  /**
   * Specify glob patterns to ignore when detecting task files. By default we ignore:
   *
   * - *.test.ts
   * - *.spec.ts
   * - *.test.mts
   * - *.spec.mts
   * - *.test.cts
   * - *.spec.cts
   * - *.test.js
   * - *.spec.js
   * - *.test.mjs
   * - *.spec.mjs
   * - *.test.cjs
   * - *.spec.cjs
   *
   */
  ignorePatterns?: string[];

  /**
   * Instrumentations to use for OpenTelemetry. This is useful if you want to add custom instrumentations to your tasks.
   *
   * @see https://trigger.dev/docs/config/config-file#instrumentations
   *
   * @deprecated Use the `telemetry.instrumentations` option instead.
   */
  instrumentations?: Array<Instrumentation>;

  telemetry?: {
    /**
     * Instrumentations to use for OpenTelemetry. This is useful if you want to add custom instrumentations to your tasks.
     *
     * @see https://trigger.dev/docs/config/config-file#instrumentations
     */
    instrumentations?: Array<Instrumentation>;

    /**
     * Exporters to use for OpenTelemetry. This is useful if you want to add custom exporters to your tasks.
     *
     * @see https://trigger.dev/docs/config/config-file#exporters
     */
    exporters?: Array<SpanExporter>;

    /**
     * Log exporters to use for OpenTelemetry. This is useful if you want to add custom log exporters to your tasks.
     *
     * @see https://trigger.dev/docs/config/config-file#exporters
     */
    logExporters?: Array<LogRecordExporter>;

    /**
     * Metric exporters to use for OpenTelemetry. This is useful if you want to export metrics to external services.
     * Each exporter is automatically wrapped in a PeriodicExportingMetricReader.
     *
     * For more control over the reader configuration, use `metricReaders` instead.
     */
    metricExporters?: Array<PushMetricExporter>;

    /**
     * Metric readers for OpenTelemetry. Add custom metric readers to export
     * metrics to external services alongside the default Trigger.dev exporter.
     */
    metricReaders?: Array<MetricReader>;

    /**
     * Resource to use for OpenTelemetry. This is useful if you want to add custom resources to your tasks.
     *
     * @see https://trigger.dev/docs/config/config-file#resource
     */
    resource?: Resource;
  };

  /**
   * Specify a custom path to your tsconfig file. This is useful if you have a custom tsconfig file that you want to use.
   */
  tsconfig?: string;

  /**
   * Specify the global retry options for your tasks. You can override this on a per-task basis.
   *
   * @see https://trigger.dev/docs/tasks/overview#retry-options
   */
  retries?: {
    enabledInDev?: boolean;
    default?: RetryOptions;
  };
  compatibilityFlags?: Array<CompatibilityFlag>;

  /**
   * The default machine preset to use for your deployed trigger.dev tasks. You can override this on a per-task basis.
   * @default "small-1x"
   *
   * @see https://trigger.dev/docs/machines
   */
  machine?: MachinePresetName;

  /**
   * Set the log level for the logger. Defaults to "info", so you will see "log", "info", "warn", and "error" messages, but not "debug" messages.
   *
   * We automatically set the logLevel to "debug" during test runs
   *
   * @default "info"
   */
  logLevel?: LogLevel;

  /**
   * The maximum duration in compute-time seconds that a task run is allowed to run. If the task run exceeds this duration, it will be stopped.
   *
   * Minimum value is 5 seconds
   *
   * Setting this value will effect all tasks in the project.
   *
   * @see https://trigger.dev/docs/tasks/overview#maxduration-option
   */
  maxDuration: number;

  /**
   * Set a default time-to-live (TTL) for all task runs in the project. If a run is not executed within this time, it will be removed from the queue and never execute.
   *
   * This can be a string like "1h" (1 hour), "30m" (30 minutes), "1d" (1 day), or a number of seconds.
   *
   * You can override this on a per-task basis by setting the `ttl` option on the task definition, or per-trigger by setting the `ttl` option when triggering.
   *
   * @example
   *
   * ```ts
   * export default defineConfig({
   *   project: "my-project",
   *   maxDuration: 3600,
   *   ttl: "1h",
   * });
   * ```
   */
  ttl?: string | number;

  /**
   * Enable console logging while running the dev CLI. This will print out logs from console.log, console.warn, and console.error. By default all logs are sent to the trigger.dev backend, and not logged to the console.
   */
  enableConsoleLogging?: boolean;

  /**
   * Disable the console interceptor. This will prevent logs from being sent to the trigger.dev backend.
   */
  disableConsoleInterceptor?: boolean;

  build?: {
    /**
     * Add custom conditions to the esbuild build. For example, if you are importing `ai/rsc`, you'll need to add "react-server" condition.
     *
     * By default we add the following conditions:
     *
     * - "trigger.dev"
     * - "module"
     * - "node"
     */
    conditions?: string[];

    /**
     * Add custom build extensions to the build process.
     *
     * @see https://trigger.dev/docs/config/config-file#extensions
     */
    extensions?: BuildExtension[];

    /**
     * External dependencies to exclude from the bundle. This is useful if you want to keep some dependencies as external, and not bundle them with your code.
     *
     * @see https://trigger.dev/docs/config/config-file#external
     */
    external?: string[];

    /**
     * This still works but use `autoDetectExternal` instead.
     *
     * @deprecated (use autoDetectExternal instead)
     */
    experimental_autoDetectExternal?: boolean;

    /**
     * Automatically detect dependencies that shouldn't be bundled and mark them as external. For example, native modules.
     *
     * Turn this off if you are having issues and want to manually specify all `external` dependencies.
     *
     * @default true
     */
    autoDetectExternal?: boolean;

    /**
     * This still works but use `keepNames` instead.
     *
     * @deprecated (use keepNames instead)
     */
    experimental_keepNames?: boolean;

    /* Set to false to minify the original names of functions and classes in the bundle.
     * This can make bundles smaller at the cost of compatibility with frameworks that rely on function/class/variable names.
     *
     * @link https://esbuild.github.io/api/#keep-names
     *
     * @default true
     */
    keepNames?: boolean;

    /**
     * This still works but use `minify` instead.
     *
     * @deprecated (use minify instead)
     */
    experimental_minify?: boolean;

    /**
     * **WARNING: This is an experimental feature and might be removed in a future version.**
     *
     * "Minification is not safe for 100% of all JavaScript code" - esbuild docs
     *
     * Minify the generated code to help decrease bundle size. This may break stuff.
     *
     * @link https://esbuild.github.io/api/#minify
     *
     * @default false
     */
    minify?: boolean;

    jsx?: {
      /**
       * @default "React.createElement"
       */
      factory?: string;
      /**
       * @default "React.Fragment"
       */
      fragment?: string;

      /**
       * @default true
       * @description Set the esbuild jsx option to automatic. Set this to false if you aren't using React.
       * @see https://esbuild.github.io/api/#jsx
       */
      automatic?: boolean;
    };
  };

  deploy?: {
    env?: Record<string, string>;
  };

  /**
   * This still works but use `processKeepAlive` instead.
   *
   * @deprecated (use processKeepAlive instead)
   */
  experimental_processKeepAlive?: ProcessKeepAlive;

  /**
   * @default false
   * @description Keep the process alive after the task has finished running so the next task doesn't have to wait for the process to start up again.
   *
   * Note that the process could be killed at any time, and we don't make any guarantees about the process being alive for a certain amount of time
   */
  processKeepAlive?: ProcessKeepAlive;

  /**
   * @default true
   * @description If set to true when running the dev CLI, the current working directory will be set to where the command is run from.
   *
   * Setting this to `false` will set the current working directory to the build directory.
   * This more closely matches the behavior of the CLI when running in production and is highly recommended.
   *
   * This impacts the value of process.cwd() in your task code.
   */
  legacyDevProcessCwdBehaviour?: boolean;

  /**
   * @deprecated Use `dirs` instead
   */
  triggerDirectories?: string[];

  /**
   * @deprecated Use the `additionalPackages` extension instead.
   */
  additionalPackages?: string[];

  /**
   * @deprecated Use the `additionalFiles` extension instead.
   */
  additionalFiles?: string[];

  /**
   * @deprecated Dependencies are now bundled by default. If you want to exclude some dependencies from the bundle, use the `build.external` option.
   */
  dependenciesToBundle?: Array<string | RegExp>;

  /**
   * @deprecated Use `tsconfig` instead.
   */
  tsconfigPath?: string;

  /**
   * CA Cert file to be added to NODE_EXTRA_CA_CERT environment variable, useful in use with self signed cert in the trigger.dev environment.
   *
   * @example "./certs/ca.crt"
   * Note: must start with "./" and be relative to the project root.
   *
   */
  extraCACerts?: string;

  /**
   * Run before a task is executed, for all tasks. This is useful for setting up any global state that is needed for all tasks.
   *
   * @deprecated, please use tasks.init instead
   */
  init?: AnyOnInitHookFunction;

  /**
   * onSuccess is called after the run function has successfully completed.
   *
   * @deprecated, please use tasks.onSuccess instead
   */
  onSuccess?: AnyOnSuccessHookFunction;

  /**
   * onFailure is called after a task run has failed (meaning the run function threw an error and won't be retried anymore)
   *
   * @deprecated, please use tasks.onFailure instead
   */
  onFailure?: AnyOnFailureHookFunction;

  /**
   * onStart is called the first time a task is executed in a run (not before every retry)
   *
   * @deprecated, please use tasks.onStart instead
   */
  onStart?: AnyOnStartHookFunction;

  /**
   * @deprecated Use a custom build extension to add post install commands
   */
  postInstall?: string;
};
