use std::net::SocketAddr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use personhog_proto::personhog::{
    service::v1::person_hog_service_server::{PersonHogService, PersonHogServiceServer},
    types::v1::*,
};
use sqlx::PgPool;
use tokio::net::TcpListener;
use tonic::{Code, Request, Response, Status};

use property_defs_rs::{
    batch_ingestion::process_batch,
    group_type_resolver::GroupTypeResolver,
    types::{GroupType, PropertyParentType, Update},
    update_cache::Cache,
};

// process_batch beats a lifecycle heartbeat as chunk writes complete. Tests don't run
// the lifecycle monitor, so report_healthy() is just an atomic store on this handle.
fn test_lifecycle_handle() -> lifecycle::Handle {
    let mut manager = lifecycle::Manager::builder("test").build();
    manager.register("consumer", lifecycle::ComponentOptions::new())
}

// -- mock server --------------------------------------------------------

struct MockPersonHogService {
    mappings_by_team: Vec<GroupTypeMappingsByKey>,
    /// Number of calls that should fail before succeeding. usize::MAX = always fail.
    fail_remaining: AtomicUsize,
    fail_code: Code,
    /// The first N successful calls return no mappings, simulating a GroupTypeMapping that
    /// hasn't yet reached the eventual read replica; later calls return `mappings_by_team`.
    empty_first_calls: usize,
    call_count: Arc<AtomicUsize>,
}

impl MockPersonHogService {
    fn with_mappings(mappings_by_team: Vec<GroupTypeMappingsByKey>) -> Self {
        Self {
            mappings_by_team,
            fail_remaining: AtomicUsize::new(0),
            fail_code: Code::Internal,
            empty_first_calls: 0,
            call_count: Arc::new(AtomicUsize::new(0)),
        }
    }

    fn with_mappings_counted(
        mappings_by_team: Vec<GroupTypeMappingsByKey>,
        call_count: Arc<AtomicUsize>,
    ) -> Self {
        Self {
            mappings_by_team,
            fail_remaining: AtomicUsize::new(0),
            fail_code: Code::Internal,
            empty_first_calls: 0,
            call_count,
        }
    }

    fn failing() -> Self {
        Self {
            mappings_by_team: vec![],
            fail_remaining: AtomicUsize::new(usize::MAX),
            fail_code: Code::InvalidArgument,
            empty_first_calls: 0,
            call_count: Arc::new(AtomicUsize::new(0)),
        }
    }

    fn transient_then_ok(
        mappings_by_team: Vec<GroupTypeMappingsByKey>,
        fail_count: usize,
        fail_code: Code,
        call_count: Arc<AtomicUsize>,
    ) -> Self {
        Self {
            mappings_by_team,
            fail_remaining: AtomicUsize::new(fail_count),
            fail_code,
            empty_first_calls: 0,
            call_count,
        }
    }

    fn always_failing(fail_code: Code, call_count: Arc<AtomicUsize>) -> Self {
        Self {
            mappings_by_team: vec![],
            fail_remaining: AtomicUsize::new(usize::MAX),
            fail_code,
            empty_first_calls: 0,
            call_count,
        }
    }

    /// The first `empty_first_calls` lookups resolve to nothing (a miss); later lookups return
    /// `mappings_by_team`. Models a newly created group type only becoming visible after an
    /// initial window, which is exactly the transient miss that used to poison the cache.
    fn resolves_after_empty_calls(
        mappings_by_team: Vec<GroupTypeMappingsByKey>,
        empty_first_calls: usize,
        call_count: Arc<AtomicUsize>,
    ) -> Self {
        Self {
            mappings_by_team,
            fail_remaining: AtomicUsize::new(0),
            fail_code: Code::Internal,
            empty_first_calls,
            call_count,
        }
    }
}

#[tonic::async_trait]
impl PersonHogService for MockPersonHogService {
    async fn fence_person(
        &self,
        _req: Request<personhog_proto::personhog::types::v1::FencePersonRequest>,
    ) -> Result<Response<personhog_proto::personhog::types::v1::FencePersonResponse>, Status> {
        Err(Status::unimplemented("not exercised by this mock"))
    }

    async fn release_fence(
        &self,
        _req: Request<personhog_proto::personhog::types::v1::ReleaseFenceRequest>,
    ) -> Result<Response<personhog_proto::personhog::types::v1::ReleaseFenceResponse>, Status> {
        Err(Status::unimplemented("not exercised by this mock"))
    }

    async fn fold_person_document(
        &self,
        _req: Request<personhog_proto::personhog::types::v1::FoldPersonDocumentRequest>,
    ) -> Result<Response<personhog_proto::personhog::types::v1::FoldPersonDocumentResponse>, Status>
    {
        Err(Status::unimplemented("not exercised by this mock"))
    }

    async fn get_group_type_mappings_by_team_ids(
        &self,
        _req: Request<GetGroupTypeMappingsByTeamIdsRequest>,
    ) -> Result<Response<GroupTypeMappingsBatchResponse>, Status> {
        let this_call = self.call_count.fetch_add(1, Ordering::SeqCst) + 1;

        // Decrement fail_remaining; if it was > 0 before the decrement, fail this call.
        // Uses saturating to avoid wrapping usize::MAX (always-fail case).
        let prev = self
            .fail_remaining
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |n| {
                Some(n.saturating_sub(1))
            })
            .unwrap();
        if prev > 0 {
            return Err(Status::new(self.fail_code, "mock failure"));
        }

        // Simulate the mapping only becoming visible after `empty_first_calls` lookups.
        let results = if this_call <= self.empty_first_calls {
            vec![]
        } else {
            self.mappings_by_team.clone()
        };

        Ok(Response::new(GroupTypeMappingsBatchResponse { results }))
    }

    // -- stubs for the rest of the trait (never called) ------------------

    async fn get_person(
        &self,
        _: Request<GetPersonRequest>,
    ) -> Result<Response<GetPersonResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_persons(
        &self,
        _: Request<GetPersonsRequest>,
    ) -> Result<Response<PersonsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_person_by_uuid(
        &self,
        _: Request<GetPersonByUuidRequest>,
    ) -> Result<Response<GetPersonResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_persons_by_uuids(
        &self,
        _: Request<GetPersonsByUuidsRequest>,
    ) -> Result<Response<PersonsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_person_by_distinct_id(
        &self,
        _: Request<GetPersonByDistinctIdRequest>,
    ) -> Result<Response<GetPersonResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_persons_by_distinct_ids_in_team(
        &self,
        _: Request<GetPersonsByDistinctIdsInTeamRequest>,
    ) -> Result<Response<PersonsByDistinctIdsInTeamResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_persons_by_distinct_ids(
        &self,
        _: Request<GetPersonsByDistinctIdsRequest>,
    ) -> Result<Response<PersonsByDistinctIdsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_distinct_ids_for_person(
        &self,
        _: Request<GetDistinctIdsForPersonRequest>,
    ) -> Result<Response<GetDistinctIdsForPersonResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_distinct_ids_for_persons(
        &self,
        _: Request<GetDistinctIdsForPersonsRequest>,
    ) -> Result<Response<GetDistinctIdsForPersonsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_hash_key_override_context(
        &self,
        _: Request<GetHashKeyOverrideContextRequest>,
    ) -> Result<Response<GetHashKeyOverrideContextResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn upsert_hash_key_overrides(
        &self,
        _: Request<UpsertHashKeyOverridesRequest>,
    ) -> Result<Response<UpsertHashKeyOverridesResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_hash_key_overrides_by_teams(
        &self,
        _: Request<DeleteHashKeyOverridesByTeamsRequest>,
    ) -> Result<Response<DeleteHashKeyOverridesByTeamsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn check_cohort_membership(
        &self,
        _: Request<CheckCohortMembershipRequest>,
    ) -> Result<Response<CohortMembershipResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn count_cohort_members(
        &self,
        _: Request<CountCohortMembersRequest>,
    ) -> Result<Response<CountCohortMembersResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_cohort_member(
        &self,
        _: Request<DeleteCohortMemberRequest>,
    ) -> Result<Response<DeleteCohortMemberResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_cohort_members_bulk(
        &self,
        _: Request<DeleteCohortMembersBulkRequest>,
    ) -> Result<Response<DeleteCohortMembersBulkResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn insert_cohort_members(
        &self,
        _: Request<InsertCohortMembersRequest>,
    ) -> Result<Response<InsertCohortMembersResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn list_cohort_member_ids(
        &self,
        _: Request<ListCohortMemberIdsRequest>,
    ) -> Result<Response<ListCohortMemberIdsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_group(
        &self,
        _: Request<GetGroupRequest>,
    ) -> Result<Response<GetGroupResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_groups(
        &self,
        _: Request<GetGroupsRequest>,
    ) -> Result<Response<GroupsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_groups_batch(
        &self,
        _: Request<GetGroupsBatchRequest>,
    ) -> Result<Response<GetGroupsBatchResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn list_groups(
        &self,
        _: Request<ListGroupsRequest>,
    ) -> Result<Response<ListGroupsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_group_type_mappings_by_team_id(
        &self,
        _: Request<GetGroupTypeMappingsByTeamIdRequest>,
    ) -> Result<Response<GroupTypeMappingsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_group_type_mappings_by_project_id(
        &self,
        _: Request<GetGroupTypeMappingsByProjectIdRequest>,
    ) -> Result<Response<GroupTypeMappingsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_group_type_mappings_by_project_ids(
        &self,
        _: Request<GetGroupTypeMappingsByProjectIdsRequest>,
    ) -> Result<Response<GroupTypeMappingsBatchResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn update_person_properties(
        &self,
        _: Request<UpdatePersonPropertiesRequest>,
    ) -> Result<Response<UpdatePersonPropertiesResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_persons(
        &self,
        _: Request<DeletePersonsRequest>,
    ) -> Result<Response<DeletePersonsResponse>, Status> {
        Err(Status::unimplemented(""))
    }

    async fn delete_persons_batch_for_team(
        &self,
        _: Request<DeletePersonsBatchForTeamRequest>,
    ) -> Result<Response<DeletePersonsBatchForTeamResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn get_group_type_mapping_by_dashboard_id(
        &self,
        _: Request<GetGroupTypeMappingByDashboardIdRequest>,
    ) -> Result<Response<GetGroupTypeMappingByDashboardIdResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn count_group_type_mappings(
        &self,
        _: Request<CountGroupTypeMappingsRequest>,
    ) -> Result<Response<CountGroupTypeMappingsResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn create_group(
        &self,
        _: Request<CreateGroupRequest>,
    ) -> Result<Response<CreateGroupResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn update_group(
        &self,
        _: Request<UpdateGroupRequest>,
    ) -> Result<Response<UpdateGroupResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_groups_batch_for_team(
        &self,
        _: Request<DeleteGroupsBatchForTeamRequest>,
    ) -> Result<Response<DeleteGroupsBatchForTeamResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn update_group_type_mapping(
        &self,
        _: Request<UpdateGroupTypeMappingRequest>,
    ) -> Result<Response<UpdateGroupTypeMappingResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_group_type_mapping(
        &self,
        _: Request<DeleteGroupTypeMappingRequest>,
    ) -> Result<Response<DeleteGroupTypeMappingResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn delete_group_type_mappings_batch_for_team(
        &self,
        _: Request<DeleteGroupTypeMappingsBatchForTeamRequest>,
    ) -> Result<Response<DeleteGroupTypeMappingsBatchForTeamResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn split_person(
        &self,
        _: Request<SplitPersonRequest>,
    ) -> Result<Response<SplitPersonResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn set_person_distinct_id_version_floor(
        &self,
        _: Request<SetPersonDistinctIdVersionFloorRequest>,
    ) -> Result<Response<SetPersonDistinctIdVersionFloorResponse>, Status> {
        Err(Status::unimplemented(""))
    }
    async fn set_person_version_floor(
        &self,
        _: Request<SetPersonVersionFloorRequest>,
    ) -> Result<Response<SetPersonVersionFloorResponse>, Status> {
        Err(Status::unimplemented(""))
    }
}

// -- helpers ------------------------------------------------------------

async fn start_mock_server(service: MockPersonHogService) -> SocketAddr {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    tokio::spawn(async move {
        tonic::transport::Server::builder()
            .add_service(PersonHogServiceServer::new(service))
            .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(listener))
            .await
            .unwrap();
    });
    tokio::time::sleep(std::time::Duration::from_millis(10)).await;
    addr
}

fn make_config(addr: &str) -> property_defs_rs::config::Config {
    // Set env vars exactly once to avoid data races across concurrent test cases.
    static INIT_ENV: std::sync::Once = std::sync::Once::new();
    INIT_ENV.call_once(|| {
        std::env::set_var("KAFKA__BOOTSTRAP_SERVERS", "localhost:9092");
        std::env::set_var("KAFKA__TOPIC", "test_topic");
    });
    let mut config = property_defs_rs::config::Config::init_with_defaults().unwrap();
    config.personhog_addr = addr.to_string();
    config.personhog_timeout_ms = 5000;
    config.personhog_max_retries = 2;
    config.personhog_initial_backoff_ms = 1;
    config.personhog_max_backoff_ms = 10;
    config.skip_reads = false;
    config
}

fn make_group_update(team_id: i32, group_name: &str) -> Update {
    Update::Property(property_defs_rs::types::PropertyDefinition {
        team_id,
        project_id: team_id as i64,
        name: format!("prop_{group_name}"),
        is_numerical: false,
        property_type: None,
        event_type: PropertyParentType::Group,
        group_type_index: Some(GroupType::Unresolved(group_name.to_string())),
    })
}

fn get_resolved_index(update: &Update) -> Option<i32> {
    match update {
        Update::Property(p) => match &p.group_type_index {
            Some(GroupType::Resolved(_, idx)) => Some(*idx),
            _ => None,
        },
        _ => None,
    }
}

// -- tests --------------------------------------------------------------

#[tokio::test]
async fn test_personhog_resolves_group_types() {
    let mock = MockPersonHogService::with_mappings(vec![GroupTypeMappingsByKey {
        key: 1,
        mappings: vec![
            GroupTypeMapping {
                id: 1,
                team_id: 1,
                project_id: 1,
                group_type: "organization".to_string(),
                group_type_index: 0,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            },
            GroupTypeMapping {
                id: 2,
                team_id: 1,
                project_id: 1,
                group_type: "company".to_string(),
                group_type_index: 1,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            },
        ],
    }]);

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![
        make_group_update(1, "organization"),
        make_group_update(1, "company"),
    ];

    resolver.resolve(&mut updates).await.unwrap();

    assert_eq!(get_resolved_index(&updates[0]), Some(0));
    assert_eq!(get_resolved_index(&updates[1]), Some(1));
}

#[tokio::test]
async fn test_personhog_resolves_multiple_teams() {
    let mock = MockPersonHogService::with_mappings(vec![
        GroupTypeMappingsByKey {
            key: 10,
            mappings: vec![GroupTypeMapping {
                id: 1,
                team_id: 10,
                project_id: 10,
                group_type: "workspace".to_string(),
                group_type_index: 0,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            }],
        },
        GroupTypeMappingsByKey {
            key: 20,
            mappings: vec![GroupTypeMapping {
                id: 2,
                team_id: 20,
                project_id: 20,
                group_type: "workspace".to_string(),
                group_type_index: 2,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            }],
        },
    ]);

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![
        make_group_update(10, "workspace"),
        make_group_update(20, "workspace"),
    ];

    resolver.resolve(&mut updates).await.unwrap();

    assert_eq!(get_resolved_index(&updates[0]), Some(0));
    assert_eq!(get_resolved_index(&updates[1]), Some(2));
}

#[tokio::test]
async fn test_personhog_unresolved_group_type_preserved_not_cleared() {
    // On a resolution miss we must keep the Unresolved(name) form rather than clearing to
    // None: batch_ingestion drops it either way, but preserving the name keeps the shared
    // dedup-cache key recoverable so the dropped entry can be evicted and retried, instead
    // of the entry poisoning the cache and permanently blocking the def.
    let mock = MockPersonHogService::with_mappings(vec![GroupTypeMappingsByKey {
        key: 1,
        mappings: vec![],
    }]);

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "nonexistent")];

    resolver.resolve(&mut updates).await.unwrap();

    match &updates[0] {
        Update::Property(p) => assert_eq!(
            p.group_type_index,
            Some(GroupType::Unresolved("nonexistent".to_string()))
        ),
        _ => panic!("expected Property update"),
    }
}

#[tokio::test]
async fn test_negative_cache_skips_personhog_within_ttl() {
    // A miss is cached for the TTL window so repeated unresolvable keys don't re-hit personhog.
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::with_mappings_counted(
        vec![GroupTypeMappingsByKey {
            key: 1,
            mappings: vec![],
        }],
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}")); // default TTL is 30s
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "nonexistent")];
    resolver.resolve(&mut updates).await.unwrap();
    assert_eq!(call_count.load(Ordering::SeqCst), 1);

    // Second resolve of the same key is served from the negative cache: no personhog call,
    // and the update is still left Unresolved so it gets dropped + evicted downstream.
    let mut updates2 = vec![make_group_update(1, "nonexistent")];
    resolver.resolve(&mut updates2).await.unwrap();
    assert_eq!(call_count.load(Ordering::SeqCst), 1);
    match &updates2[0] {
        Update::Property(p) => assert_eq!(
            p.group_type_index,
            Some(GroupType::Unresolved("nonexistent".to_string()))
        ),
        _ => panic!("expected Property update"),
    }
}

#[tokio::test]
async fn test_negative_cache_reattempts_after_ttl_expiry() {
    // With TTL=0 the negative entry is immediately expired, so a subsequent event re-attempts
    // resolution via personhog (this is what lets a legitimate new group resolve once its
    // mapping lands).
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::with_mappings_counted(
        vec![GroupTypeMappingsByKey {
            key: 1,
            mappings: vec![],
        }],
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let mut config = make_config(&format!("http://{addr}"));
    config.group_type_negative_ttl_secs = 0;
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "nonexistent")];
    resolver.resolve(&mut updates).await.unwrap();
    assert_eq!(call_count.load(Ordering::SeqCst), 1);

    let mut updates2 = vec![make_group_update(1, "nonexistent")];
    resolver.resolve(&mut updates2).await.unwrap();
    assert_eq!(call_count.load(Ordering::SeqCst), 2);
}

#[tokio::test]
async fn test_personhog_failure_returns_error() {
    let mock = MockPersonHogService::failing();
    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];

    let result = resolver.resolve(&mut updates).await;
    assert!(result.is_err());
}

#[tokio::test]
async fn test_personhog_caches_resolved_types() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::with_mappings_counted(
        vec![GroupTypeMappingsByKey {
            key: 1,
            mappings: vec![GroupTypeMapping {
                id: 1,
                team_id: 1,
                project_id: 1,
                group_type: "organization".to_string(),
                group_type_index: 3,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            }],
        }],
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    // First call populates the cache
    let mut updates = vec![make_group_update(1, "organization")];
    resolver.resolve(&mut updates).await.unwrap();
    assert_eq!(get_resolved_index(&updates[0]), Some(3));
    assert_eq!(call_count.load(Ordering::SeqCst), 1);

    // Second call should resolve from cache — server must not be contacted again
    let mut updates2 = vec![make_group_update(1, "organization")];
    resolver.resolve(&mut updates2).await.unwrap();
    assert_eq!(get_resolved_index(&updates2[0]), Some(3));
    assert_eq!(call_count.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn test_no_personhog_client_returns_error() {
    // Empty addr = no personhog client created
    let config = make_config("");
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    let result = resolver.resolve(&mut updates).await;

    assert!(result.is_err());
}

// -- retry tests --------------------------------------------------------

fn org_mapping() -> Vec<GroupTypeMappingsByKey> {
    vec![GroupTypeMappingsByKey {
        key: 1,
        mappings: vec![GroupTypeMapping {
            id: 1,
            team_id: 1,
            project_id: 1,
            group_type: "organization".to_string(),
            group_type_index: 0,
            name_singular: None,
            name_plural: None,
            default_columns: None,
            detail_dashboard_id: None,
            created_at: None,
        }],
    }]
}

#[tokio::test]
async fn test_retries_transient_error_then_succeeds() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::transient_then_ok(
        org_mapping(),
        2,
        Code::Unavailable,
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    resolver.resolve(&mut updates).await.unwrap();

    assert_eq!(get_resolved_index(&updates[0]), Some(0));
    // 2 transient failures + 1 success = 3 total calls
    assert_eq!(call_count.load(Ordering::SeqCst), 3);
}

#[tokio::test]
async fn test_retries_deadline_exceeded_then_succeeds() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::transient_then_ok(
        org_mapping(),
        1,
        Code::DeadlineExceeded,
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    resolver.resolve(&mut updates).await.unwrap();

    assert_eq!(get_resolved_index(&updates[0]), Some(0));
    assert_eq!(call_count.load(Ordering::SeqCst), 2);
}

#[tokio::test]
async fn test_does_not_retry_non_retryable_error() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::always_failing(Code::InvalidArgument, call_count.clone());

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    let result = resolver.resolve(&mut updates).await;

    assert!(result.is_err());
    // Non-retryable error: only 1 attempt, no retries
    assert_eq!(call_count.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn test_exhausts_retries_on_persistent_transient_error() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::always_failing(Code::Unavailable, call_count.clone());

    let addr = start_mock_server(mock).await;
    let config = make_config(&format!("http://{addr}"));
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    let result = resolver.resolve(&mut updates).await;

    assert!(result.is_err());
    // 1 initial + 2 retries = 3 total attempts (max_retries=2)
    assert_eq!(call_count.load(Ordering::SeqCst), 3);
}

#[tokio::test]
async fn test_no_retries_when_max_retries_is_zero() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let mock = MockPersonHogService::always_failing(Code::Unavailable, call_count.clone());

    let addr = start_mock_server(mock).await;
    let mut config = make_config(&format!("http://{addr}"));
    config.personhog_max_retries = 0;
    let resolver = GroupTypeResolver::new(&config);

    let mut updates = vec![make_group_update(1, "organization")];
    let result = resolver.resolve(&mut updates).await;

    assert!(result.is_err());
    assert_eq!(call_count.load(Ordering::SeqCst), 1);
}

// -- end-to-end test ----------------------------------------------------

fn group_type_of(update: &Update) -> Option<GroupType> {
    match update {
        Update::Property(p) => p.group_type_index.clone(),
        _ => None,
    }
}

async fn group_prop_def_count(db: &PgPool) -> i64 {
    // type = 3 is PropertyParentType::Group. Query text matches the existing cached entry.
    sqlx::query_scalar!(r#"SELECT count(*) from posthog_propertydefinition WHERE type = 3"#)
        .fetch_one(db)
        .await
        .unwrap()
        .unwrap_or(0)
}

// Walks the full production loop end to end for a $groupidentify group property whose group type
// isn't yet resolvable (its GroupTypeMapping hasn't reached the eventual read replica):
//
//   round 1 (poison + evict): producer caches the Unresolved key, resolver misses, the batch
//     drops the def AND evicts the poisoned cache key so a retry is possible.
//   round 2 (recover + persist): the mapping has "landed", the producer re-forwards the def (it's
//     no longer filtered by the cache), the resolver resolves it, and the batch persists it.
//
// This is the regression guard the isolated resolver/batch unit tests don't provide: it ties the
// resolver miss, the shared-cache eviction, the negative cache, and the Postgres write together,
// so a future refactor that quietly reintroduces the cache-poisoning bug fails here.
#[sqlx::test(migrations = "./tests/test_migrations")]
async fn test_end_to_end_poisoned_group_def_recovers_and_persists(db: PgPool) {
    const TEAM: i32 = 111;

    let call_count = Arc::new(AtomicUsize::new(0));
    // First personhog lookup returns no mapping (the miss that poisons); the second returns the
    // now-visible mapping at index 5.
    let mock = MockPersonHogService::resolves_after_empty_calls(
        vec![GroupTypeMappingsByKey {
            key: TEAM as i64,
            mappings: vec![GroupTypeMapping {
                id: 1,
                team_id: TEAM as i64,
                project_id: TEAM as i64,
                group_type: "Organization".to_string(),
                group_type_index: 5,
                name_singular: None,
                name_plural: None,
                default_columns: None,
                detail_dashboard_id: None,
                created_at: None,
            }],
        }],
        1,
        call_count.clone(),
    );

    let addr = start_mock_server(mock).await;
    let mut config = make_config(&format!("http://{addr}"));
    // TTL 0 makes round 1's negative-cache entry immediately stale, so round 2 re-drives personhog.
    // This is the deterministic stand-in for "the TTL lapsed" between the two sparse events.
    config.group_type_negative_ttl_secs = 0;

    let resolver = GroupTypeResolver::new(&config);
    let cache: Arc<Cache> = Arc::new(Cache::new(
        config.eventdefs_cache_capacity,
        config.eventprops_cache_capacity,
        config.propdefs_cache_capacity,
    ));

    // The producer inserts the Unresolved form into the shared dedup cache before resolution runs.
    let unresolved_key = make_group_update(TEAM, "Organization");

    // ---- round 1: poison, then evict ----
    let mut round1 = vec![make_group_update(TEAM, "Organization")];
    assert!(!cache.contains_key(&unresolved_key), "cache starts empty");
    cache.insert(unresolved_key.clone());

    resolver.resolve(&mut round1).await.unwrap();
    // Miss: the group type is preserved as Unresolved (not cleared to None).
    assert_eq!(
        group_type_of(&round1[0]),
        Some(GroupType::Unresolved("Organization".to_string()))
    );

    process_batch(
        &config,
        cache.clone(),
        &db,
        round1,
        &test_lifecycle_handle(),
    )
    .await;

    assert_eq!(
        group_prop_def_count(&db).await,
        0,
        "an unresolved group def must not be written"
    );
    assert!(
        !cache.contains_key(&unresolved_key),
        "the poisoned key must be evicted so a later event can retry"
    );
    assert_eq!(call_count.load(Ordering::SeqCst), 1);

    // ---- round 2: mapping landed -> retry resolves and persists ----
    let mut round2 = vec![make_group_update(TEAM, "Organization")];
    // The producer no longer filters it (the key was evicted), so it re-forwards.
    assert!(!cache.contains_key(&round2[0]));
    cache.insert(round2[0].clone());

    resolver.resolve(&mut round2).await.unwrap();
    // The negative entry has expired (TTL 0), so personhog is re-driven and now resolves to 5.
    assert_eq!(get_resolved_index(&round2[0]), Some(5));

    process_batch(
        &config,
        cache.clone(),
        &db,
        round2,
        &test_lifecycle_handle(),
    )
    .await;

    assert_eq!(
        group_prop_def_count(&db).await,
        1,
        "the def must persist once its group type resolves"
    );
    let persisted_index: Option<i16> = sqlx::query_scalar!(
        r#"SELECT group_type_index FROM posthog_propertydefinition WHERE type = 3"#
    )
    .fetch_one(&db)
    .await
    .unwrap();
    assert_eq!(persisted_index, Some(5));
    assert_eq!(
        call_count.load(Ordering::SeqCst),
        2,
        "round 2 must re-drive personhog after the TTL lapse"
    );
    // The (Unresolved) dedup key remains cached from round 2, so an identical later event is
    // deduped rather than reprocessed.
    assert!(cache.contains_key(&unresolved_key));
}
