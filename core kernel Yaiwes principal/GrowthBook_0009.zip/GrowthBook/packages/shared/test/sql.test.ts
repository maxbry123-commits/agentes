import {
  buildMinimalOrCondition,
  decodeSQLResults,
  encodeSQLResults,
  ensureLimit,
  isMultiStatementSQL,
  isReadOnlySQL,
  usesBackslashStringEscapes,
} from "../src/sql";

describe("ensureLimit", () => {
  describe("already has LIMIT and OFFSET clauses", () => {
    it("should replace existing LIMIT and OFFSET clauses", () => {
      const sql = "SELECT * FROM users LIMIT 50 OFFSET 20";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
    it("should not change the SQL if the limit is greater than or equal to existing limit", () => {
      const sql = "SELECT * FROM users LIMIT 10 OFFSET 20";
      const result = ensureLimit(sql, 15);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
    it("should handle semicolon at the end with LIMIT and OFFSET", () => {
      const sql = "SELECT * FROM users LIMIT 50 OFFSET 20;";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
    it("should handle lowercase limit/offset keywords", () => {
      const sql = "SELECT * FROM users limit 50 offset 20";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
  });
  describe("has OFFSET clause only", () => {
    it("should replace OFFSET with LIMIT and OFFSET", () => {
      const sql = "SELECT * FROM users OFFSET 20";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
    it("should handle semicolon at the end with OFFSET", () => {
      const sql = "SELECT * FROM users OFFSET 20;";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
    it("should handle lowercase offset keyword", () => {
      const sql = "SELECT * FROM users offset 20";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10 OFFSET 20");
    });
  });
  describe("has 2-number LIMIT clause", () => {
    it("should replace existing LIMIT with two numbers", () => {
      const sql = "SELECT * FROM users LIMIT 20, 50";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 20, 10");
    });
    it("should not change the SQL if the limit is greater than or equal to existing limit", () => {
      const sql = "SELECT * FROM users LIMIT 20, 10";
      const result = ensureLimit(sql, 15);
      expect(result).toBe("SELECT * FROM users LIMIT 20, 10");
    });
    it("should handle semicolon at the end with two numbers", () => {
      const sql = "SELECT * FROM users LIMIT 20, 50;";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 20, 10");
    });
    it("should handle lowercase limit keyword with two numbers", () => {
      const sql = "SELECT * FROM users limit 20, 50";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 20, 10");
    });
  });
  describe("has 1-number LIMIT clause only", () => {
    it("should replace existing LIMIT clause", () => {
      const sql = "SELECT * FROM users LIMIT 50";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10");
    });
    it("should not change the SQL if the limit is greater than or equal to existing limit", () => {
      const sql = "SELECT * FROM users LIMIT 10";
      const result = ensureLimit(sql, 15);
      expect(result).toBe("SELECT * FROM users LIMIT 10");
    });
    it("should handle semicolon at the end with LIMIT", () => {
      const sql = "SELECT * FROM users LIMIT 50;";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10");
    });
    it("should handle lowercase limit keyword", () => {
      const sql = "SELECT * FROM users limit 50";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10");
    });
  });

  describe("no LIMIT or OFFSET clauses", () => {
    it("should append LIMIT at the end", () => {
      const sql = "SELECT * FROM users";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users\nLIMIT 10");
    });
    it("should handle semicolon at the end without LIMIT or OFFSET", () => {
      const sql = "SELECT * FROM users;";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users\nLIMIT 10");
    });
  });

  describe("edge cases", () => {
    it("should handle complex case with subquery that has LIMIT", () => {
      const sql = "SELECT * FROM (SELECT * FROM users LIMIT 50) AS subquery";
      const result = ensureLimit(sql, 10);
      expect(result).toBe(
        "SELECT * FROM (SELECT * FROM users LIMIT 50) AS subquery\nLIMIT 10",
      );
    });
    it("should handle WHERE clause with deceptive LIMIT in string", () => {
      const sql = "SELECT * FROM users WHERE test = 'LIMIT 5'";
      const result = ensureLimit(sql, 10);
      expect(result).toBe(
        "SELECT * FROM users WHERE test = 'LIMIT 5'\nLIMIT 10",
      );
    });
    it("should handle SQL with single-line comments", () => {
      const sql = "SELECT * FROM users -- something";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users -- something\nLIMIT 10");
    });
    it("should handle SQL with multi-line comments", () => {
      const sql = "SELECT * FROM users /* LIMIT 5 \n*/";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users /* LIMIT 5 \n*/\nLIMIT 10");
    });
    // TODO: properly parse comments and ignore them when looking for keywords
    it.skip("should handle comments in the middle of LIMIT", () => {
      const sql = "SELECT * FROM users LI/*\ntest\n*/MIT/* LIMIT 5 */ 5";
      const result = ensureLimit(sql, 10);
      expect(result).toBe(
        "SELECT * FROM users LI/*\ntest\n*/MIT/* LIMIT 5 */ 5",
      );
    });
    // TODO: properly parse comments to remove trailing semicolons
    it.skip("should handle comments and semicolons at end", () => {
      const sql = "SELECT * FROM users; -- testing\n";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users -- testing\nLIMIT 10");
    });
    // TODO: properly parse comments to ignore LIMIT in comments
    it.skip("should handle SQL with single-line comments with deceptive LIMIT", () => {
      const sql = "SELECT * FROM users -- LIMIT 5";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users -- LIMIT 5\nLIMIT 10");
    });
    // TODO: Handle complex expressions in LIMIT clause
    it.skip("should handle complex expressions in LIMIT clause", () => {
      const sql = "SELECT * FROM users LIMIT abs(-10) + 5";
      const result = ensureLimit(sql, 10);
      expect(result).toBe("SELECT * FROM users LIMIT 10");
    });
  });
});

describe("isReadOnlySQL", () => {
  it("should return true for simple SELECT queries", () => {
    const sql = "SELECT * FROM users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });

  it("should return false for INSERT queries", () => {
    const sql = "INSERT INTO users (name) VALUES ('John')";
    expect(isReadOnlySQL(sql)).toBe(false);
  });

  it("should return false for UPDATE queries", () => {
    const sql = "UPDATE users SET name = 'Jane' WHERE id = 1";
    expect(isReadOnlySQL(sql)).toBe(false);
  });

  it("should return false for DELETE queries", () => {
    const sql = "DELETE FROM users WHERE id = 1";
    expect(isReadOnlySQL(sql)).toBe(false);
  });

  it("should return true for complex SELECT queries with joins", () => {
    const sql =
      "SELECT u.name, o.amount FROM users u JOIN orders o ON u.id = o.user_id";
    expect(isReadOnlySQL(sql)).toBe(true);
  });

  it("should return true for SELECT with subqueries", () => {
    const sql = "SELECT * FROM (SELECT * FROM users) AS subquery";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should return false for DDL statements like CREATE TABLE", () => {
    const sql = "CREATE TABLE new_table (id INT, name VARCHAR(100))";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("should allow CTEs", () => {
    const sql = `
      WITH recent_users AS (
        SELECT * FROM users WHERE created_at > NOW() - INTERVAL '30 days'
      )
      SELECT * FROM recent_users WHERE active = true;
    `;
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should return true for select queries with comments", () => {
    const sql = "-- INSERT INTO users\nSELECT * FROM users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });

  it("should return true for select queries with block comments", () => {
    const sql = "/* INSERT INTO users */SELECT * FROM users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should return false for write queries with comments", () => {
    const sql =
      "-- SELECT * from users\nINSERT INTO users (name) VALUES ('John')";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("should not allow insert from select", () => {
    const sql = "INSERT INTO users SELECT * FROM new_users";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("should allow explain queries", () => {
    const sql = "EXPLAIN SELECT * FROM users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should allow show queries", () => {
    const sql = "SHOW TABLES";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should allow describe queries", () => {
    const sql = "DESCRIBE users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should allow desc queries", () => {
    const sql = "DESC users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should ignore whitespace at the start", () => {
    const sql = "  \n\t\n--test\n \nUPDATE users";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("should ignore whitespace at the start for readonly queries", () => {
    const sql = "  \n\t\n--test\n \nSELECT * from users";
    expect(isReadOnlySQL(sql)).toBe(true);
  });
  it("should return false for unknown starting keywords", () => {
    const sql = "UNKNOWN * FROM users";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("handles line comment inside block comment", () => {
    const sql = "/* Outer comment -- */ DROP TABLE users;\nSELECT * FROM users";
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("handles block comment inside line comment", () => {
    const sql = `-- /*\nDROP TABLE users\n-- */ SELECT 1`;
    expect(isReadOnlySQL(sql)).toBe(false);
  });
  it("cannot be tricked by nested comments and an IN clause", () => {
    const sql = `-- /*\nDELETE FROM users WHERE id NOT IN (--*/\nSELECT 1)`;
    expect(isReadOnlySQL(sql)).toBe(false);
  });
});
describe("isMultiStatementSQL", () => {
  it("should return true for multiple statements", () => {
    const sql = "SELECT * FROM users; SELECT * FROM orders;";
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });

  it("should return false for single statement", () => {
    const sql = "SELECT * FROM users;";
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });

  it("should ignore comments when counting statements", () => {
    const sql = `
      -- This is a comment; Select 1;
      SELECT * FROM users; /* Another comment; SELECT 1; */
    `;
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });

  it("should handle statements without semicolons", () => {
    const sql = "SELECT * FROM users";
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });

  it("should handle complex multi-statement SQL", () => {
    const sql = `
      WITH recent_orders AS (
        SELECT * FROM orders WHERE created_at > NOW() - INTERVAL '7 days'
      )
      SELECT * FROM recent_orders WHERE amount > 100;
    `;
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
  it("should ignore semicolons within simple strings", () => {
    const sql = "SELECT 'This is a test; still in string' AS test_col;";
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
  it("should handle CTAS statements", () => {
    const sql = "CREATE TABLE new_table AS SELECT * FROM users";
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
  it("is not tricked by quotes and block comments", () => {
    const sql = `SELECT '/*'; DROP TABLE users; SELECT '*/';`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by quotes and line comments", () => {
    const sql = `SELECT '--'; DROP TABLE users`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by backslash escaped strings", () => {
    const sql = `SELECT 'It\\'s a test'; DROP TABLE users; SELECT '1';`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by fake escaped backslashes", () => {
    const sql = `SELECT 'This is a backslash: \\\\'; DROP TABLE users; SELECT '1';`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by single quotes that are escaped by doubling the quotes", () => {
    const sql = `SELECT 'It''s a test'; DROP TABLE users; SELECT '1';`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });

  it("is not tricked by double quotes and block comments", () => {
    const sql = `SELECT "/*"; DROP TABLE users; SELECT "*/";`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by double quotes and line comments", () => {
    const sql = `SELECT "--"; DROP TABLE users`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by backslash escaped double quoted strings", () => {
    const sql = `SELECT "It\\'s a test"; DROP TABLE users; SELECT "1";`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by fake escaped backslashes in double quoted strings", () => {
    const sql = `SELECT "This is a backslash: \\\\"; DROP TABLE users; SELECT "1";`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by single quotes that are escaped by doubling the double quotes", () => {
    const sql = `SELECT "It''s a test"; DROP TABLE users; SELECT "1";`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });

  it("is not tricked by backtick quotes and block comments", () => {
    const sql = `SELECT \`/*\`; DROP TABLE users; SELECT \`*/\`;`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by backtick quotes and line comments", () => {
    const sql = `SELECT \`--\`; DROP TABLE users`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("is not tricked by doubled backticks", () => {
    const sql = `SELECT \`It\`\`s a test\`; DROP TABLE users; SELECT \`1\`;`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("allows parse errors as long as there are no semicolons", () => {
    const sql = `SELECT 'It\\'`;
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
  it("allows parse errors as long as there is only a trailing semicolon", () => {
    const sql = `SELECT 'It\\'; `;
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
  it("blocks all internal semicolons when there is a parse error", () => {
    const sql = `SELECT 'It\\'; DROP TABLE users`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
});

describe("isMultiStatementSQL — dialect-aware backslash escaping", () => {
  it("allows a backslash string literal on a non-backslash dialect (the reported bug)", () => {
    const sql = `SELECT * FROM t WHERE id LIKE 'a\\_b' ESCAPE '\\'`;
    expect(isMultiStatementSQL(sql, false)).toBe(false);
  });
  it("allows multi-line  query with a ';' in a comment and a backslash ESCAPE literal", () => {
    const sql = `-- Dimension: Country (by user_id); Fact Table: Sessions (by user_id)
WITH __rawExperiment AS (
  SELECT timestamp, experiment_id, user_id
  FROM "fake-database".sessions
  WHERE timestamp >= timestamp '2026-05-26 19:00:00'
    AND experiment_id LIKE replace('my-experiment-id-here', '_', '\\_') ESCAPE '\\'
)
SELECT timestamp, user_id FROM __rawExperiment;`;
    expect(isMultiStatementSQL(sql, false)).toBe(false);
  });
  it("still blocks a real statement separator on a non-backslash dialect", () => {
    expect(isMultiStatementSQL(`SELECT 1; DROP TABLE users`, false)).toBe(true);
  });
  it("blocks an injection hidden behind a backslash literal on a non-backslash dialect", () => {
    const sql = `SELECT 1 WHERE x = '\\'; DROP TABLE t; --'`;
    expect(isMultiStatementSQL(sql, false)).toBe(true);
  });
  it("blocks a real statement separator when a -- sits inside a string and the query ends mid-string", () => {
    const sql = `SELECT '--'; DROP TABLE users; SELECT 'unterminated`;
    expect(isMultiStatementSQL(sql, false)).toBe(true);
  });
  it("blocks a backslash-escaped-quote injection on a backslash dialect", () => {
    const sql = `SELECT 'It\\'s a test'; DROP TABLE users`;
    expect(isMultiStatementSQL(sql, true)).toBe(true);
  });
  it("allows a benign single statement with a backslash escape on a backslash dialect", () => {
    const sql = `SELECT 'a\\nb' AS c`;
    expect(isMultiStatementSQL(sql, true)).toBe(false);
  });
});

describe("usesBackslashStringEscapes", () => {
  it("is false for ANSI doubled-quote escaping (Trino, Athena, Postgres, MSSQL, Vertica)", () => {
    const escapeStringLiteral = (v: string) => v.replace(/'/g, "''");
    expect(usesBackslashStringEscapes({ escapeStringLiteral })).toBe(false);
  });
  it("is true when backslashes are doubled (MySQL, Snowflake, Redshift, ClickHouse)", () => {
    const escapeStringLiteral = (v: string) =>
      v.replace(/\\/g, "\\\\").replace(/'/g, "''");
    expect(usesBackslashStringEscapes({ escapeStringLiteral })).toBe(true);
  });
  it("is true when quotes/backslashes are backslash-prefixed (BigQuery, Databricks)", () => {
    const escapeStringLiteral = (v: string) => v.replace(/(['\\])/g, "\\$1");
    expect(usesBackslashStringEscapes({ escapeStringLiteral })).toBe(true);
  });
});

describe("buildMinimalOrCondition", () => {
  it("returns empty string for empty input", () => {
    expect(buildMinimalOrCondition([])).toBe("");
  });

  it("returns empty string when a group has no filters (matches everything)", () => {
    expect(buildMinimalOrCondition([["A"], []])).toBe("");
  });

  it("returns empty string when a group has only null filters", () => {
    expect(buildMinimalOrCondition([["A"], [null, null]])).toBe("");
  });

  it("returns single condition for one metric with one filter", () => {
    expect(buildMinimalOrCondition([["color='blue'"]])).toBe("color='blue'");
  });

  it("ANDs multiple filters within a single metric", () => {
    expect(buildMinimalOrCondition([["color='blue'", "shape='circle'"]])).toBe(
      "(color='blue' AND shape='circle')",
    );
  });

  it("ORs independent metric filter groups", () => {
    expect(
      buildMinimalOrCondition([["color='blue'"], ["shape='circle'"]]),
    ).toBe("(color='blue'\nOR\nshape='circle')");
  });

  it("removes a metric subsumed by a less restrictive metric", () => {
    // Metric 1: color='blue' AND shape='circle'
    // Metric 2: color='blue'
    // Metric 2 is less restrictive, so metric 1 is redundant
    expect(
      buildMinimalOrCondition([
        ["color='blue'", "shape='circle'"],
        ["color='blue'"],
      ]),
    ).toBe("color='blue'");
  });

  it("removes a metric subsumed by a less restrictive metric (reversed order)", () => {
    expect(
      buildMinimalOrCondition([
        ["color='blue'"],
        ["color='blue'", "shape='circle'"],
      ]),
    ).toBe("color='blue'");
  });

  it("removes multiple subsumed metrics", () => {
    // Metric 1: A AND B
    // Metric 2: A AND C
    // Metric 3: A (subsumes both 1 and 2)
    expect(buildMinimalOrCondition([["A", "B"], ["A", "C"], ["A"]])).toBe("A");
  });

  it("deduplicates identical metric groups", () => {
    expect(
      buildMinimalOrCondition([
        ["color='blue'", "shape='circle'"],
        ["color='blue'", "shape='circle'"],
      ]),
    ).toBe("(color='blue' AND shape='circle')");
  });

  it("deduplicates identical groups regardless of filter order", () => {
    expect(
      buildMinimalOrCondition([
        ["shape='circle'", "color='blue'"],
        ["color='blue'", "shape='circle'"],
      ]),
    ).toBe("(shape='circle' AND color='blue')");
  });

  it("handles mix of subsumed, independent, and null filters", () => {
    // Metric 1: A AND B (subsumed by metric 3)
    // Metric 2: C AND D (independent)
    // Metric 3: A (less restrictive)
    expect(buildMinimalOrCondition([["A", "B"], ["C", "D"], ["A"]])).toBe(
      "((C AND D)\nOR\nA)",
    );
  });

  it("ignores null filters within groups", () => {
    expect(buildMinimalOrCondition([["A", null, "B"], ["A"]])).toBe("A");
  });

  it("deduplicates filters within a group", () => {
    expect(buildMinimalOrCondition([["A", "A", "B"]])).toBe("(A AND B)");
  });

  it("handles transitive subsumption correctly", () => {
    // Group 0: {A, B} — subsumed by group 2
    // Group 1: {A, B, C} — subsumed by group 0, and transitively by group 2
    // Group 2: {A}
    expect(buildMinimalOrCondition([["A", "B"], ["A", "B", "C"], ["A"]])).toBe(
      "A",
    );
  });

  it("handles transitive subsumption correctly with different filters", () => {
    // Group 0: {A, C} — subsumed by group 1
    // Group 1: {A, B, C} — subsumed by group 0
    expect(
      buildMinimalOrCondition([
        ["A", "C"],
        ["A", "B", "C"],
      ]),
    ).toBe("(A AND C)");
  });

  it("keeps non-overlapping groups intact", () => {
    expect(buildMinimalOrCondition([["A"], ["B"], ["C"]])).toBe(
      "(A\nOR\nB\nOR\nC)",
    );
  });

  it("keeps overlapping but non-subset groups", () => {
    // {A, B} and {B, C} share condition B but neither is a subset of the other
    expect(
      buildMinimalOrCondition([
        ["A", "B"],
        ["B", "C"],
      ]),
    ).toBe("((A AND B)\nOR\n(B AND C))");
  });

  it("dominates a group that is a superset of multiple independent minimals", () => {
    // {A, B} and {C, D} are independent minimals
    // {A, B, C, D} is a superset of both — should be removed
    expect(
      buildMinimalOrCondition([
        ["A", "B"],
        ["C", "D"],
        ["A", "B", "C", "D"],
      ]),
    ).toBe("((A AND B)\nOR\n(C AND D))");
  });

  it("keeps a partial-overlap chain where no group dominates another", () => {
    // {A, B}, {B, C}, {C, D} — each pair overlaps but none is a subset
    expect(
      buildMinimalOrCondition([
        ["A", "B"],
        ["B", "C"],
        ["C", "D"],
      ]),
    ).toBe("((A AND B)\nOR\n(B AND C)\nOR\n(C AND D))");
  });

  it("collapses many duplicates of the same group to one", () => {
    expect(
      buildMinimalOrCondition([
        ["A", "B"],
        ["A", "B"],
        ["A", "B"],
        ["A", "B"],
      ]),
    ).toBe("(A AND B)");
  });
});

describe("encodeSQLResults", () => {
  it("should encode and decode SQL results correctly", () => {
    const results = [
      { id: 1, name: "Alice", age: 30 },
      { id: 2, name: "Bob", age: 25 },
      { id: 3, name: "Charlie", age: 35 },
    ];

    const encoded = encodeSQLResults(results);
    expect(encoded).toEqual([
      {
        numRows: 3,
        data: {
          id: [1, 2, 3],
          name: ["Alice", "Bob", "Charlie"],
          age: [30, 25, 35],
        },
      },
    ]);

    const decoded = decodeSQLResults(encoded);
    expect(decoded).toEqual(results);
  });

  it("should chunk results", () => {
    const results = [
      { id: 1, name: "Alice", age: 30 },
      { id: 2, name: "Bob", age: 25 },
      { id: 3, name: "Charlie", age: 35 },
    ];

    const encoded = encodeSQLResults(results, 50);
    expect(encoded).toEqual([
      {
        numRows: 2,
        data: {
          id: [1, 2],
          name: ["Alice", "Bob"],
          age: [30, 25],
        },
      },
      {
        numRows: 1,
        data: {
          id: [3],
          name: ["Charlie"],
          age: [35],
        },
      },
    ]);

    const decoded = decodeSQLResults(encoded);
    expect(decoded).toEqual(results);
  });

  it("preserves columns that are missing from the first row", () => {
    const results = [
      { id: 1, name: "Alice" },
      { id: 2, name: "Bob", grid: [1, 2, 3] },
    ];

    const encoded = encodeSQLResults(results);
    expect(encoded).toEqual([
      {
        numRows: 2,
        data: {
          id: [1, 2],
          name: ["Alice", "Bob"],
          grid: [null, [1, 2, 3]],
        },
      },
    ]);

    const decoded = decodeSQLResults(encoded);
    expect(decoded).toEqual([
      { id: 1, name: "Alice", grid: null },
      { id: 2, name: "Bob", grid: [1, 2, 3] },
    ]);
  });
});
