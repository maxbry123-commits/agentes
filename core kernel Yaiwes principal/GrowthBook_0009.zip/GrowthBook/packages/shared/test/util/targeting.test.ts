import {
  getTargetingProjectIds,
  getAttributeScopeProjectIds,
  getExperimentAttributeScopeProjectIds,
  entityTargetsProject,
  resolveTargetingProjectIds,
  normalizeTargetingProjects,
  normalizeTargetingInUpdates,
  getTargetingReviewMode,
  getGoverningReviewProjects,
  featureRequiresReview,
} from "shared/util";
import { FeatureInterface } from "shared/types/feature";
import { OrganizationSettings } from "shared/types/organization";

describe("targeting scope helpers", () => {
  describe("getTargetingProjectIds", () => {
    it("returns the primary project deduped with targeting projects", () => {
      expect(
        getTargetingProjectIds({
          project: "p1",
          targetingProjects: ["p2", "p3", "p1"],
        }),
      ).toEqual(["p1", "p2", "p3"]);
    });

    it('returns [""] for a project-less entity', () => {
      expect(getTargetingProjectIds({})).toEqual([""]);
    });

    it("returns null (all projects) when targetingAllProjects is set", () => {
      expect(
        getTargetingProjectIds({
          project: "p1",
          targetingAllProjects: true,
          targetingProjects: ["p2"],
        }),
      ).toBeNull();
    });
  });

  describe("entityTargetsProject", () => {
    const entity = { project: "p1", targetingProjects: ["p2"] };
    it("matches the primary project", () => {
      expect(entityTargetsProject(entity, "p1")).toBe(true);
    });
    it("matches a targeting project", () => {
      expect(entityTargetsProject(entity, "p2")).toBe(true);
    });
    it("does not match an unrelated project", () => {
      expect(entityTargetsProject(entity, "p3")).toBe(false);
    });
    it("matches any project when targetingAllProjects is set", () => {
      expect(
        entityTargetsProject(
          { project: "p1", targetingAllProjects: true },
          "px",
        ),
      ).toBe(true);
    });
  });

  describe("getAttributeScopeProjectIds", () => {
    it("returns primary + targeting projects deduped", () => {
      expect(
        getAttributeScopeProjectIds({
          project: "p1",
          targetingProjects: ["p2", "p1"],
        }),
      ).toEqual(["p1", "p2"]);
    });

    it("returns null when the entity targets all projects", () => {
      expect(
        getAttributeScopeProjectIds({
          project: "p1",
          targetingAllProjects: true,
        }),
      ).toBeNull();
    });

    it("returns null for an entity with no primary project", () => {
      expect(getAttributeScopeProjectIds({ targetingProjects: ["p2"] })).toBe(
        null,
      );
    });

    it("unions staged targeting projects with current ones", () => {
      expect(
        getAttributeScopeProjectIds(
          { project: "p1", targetingProjects: ["p2"] },
          { targetingProjects: ["p3"] },
        ),
      ).toEqual(["p1", "p2", "p3"]);
    });

    it("keeps both primaries across a staged project move", () => {
      expect(
        getAttributeScopeProjectIds({ project: "p1" }, { project: "p4" }),
      ).toEqual(["p1", "p4"]);
    });

    it("returns null when the staged state targets all projects", () => {
      expect(
        getAttributeScopeProjectIds(
          { project: "p1" },
          { targetingAllProjects: true },
        ),
      ).toBeNull();
    });

    it("returns null when staged moves the entity to no project", () => {
      expect(
        getAttributeScopeProjectIds({ project: "p1" }, { project: "" }),
      ).toBeNull();
    });

    it("ignores an empty staged object", () => {
      expect(getAttributeScopeProjectIds({ project: "p1" }, {})).toEqual([
        "p1",
      ]);
    });
  });

  describe("getExperimentAttributeScopeProjectIds", () => {
    it("returns the experiment project with no linked features", () => {
      expect(
        getExperimentAttributeScopeProjectIds({ project: "p1" }, []),
      ).toEqual(["p1"]);
    });

    it("unions linked feature scopes with the experiment project", () => {
      expect(
        getExperimentAttributeScopeProjectIds({ project: "p1" }, [
          ["p2", "p3"],
          ["p1", "p4"],
        ]),
      ).toEqual(["p1", "p2", "p3", "p4"]);
    });

    it("returns null when any linked feature is unscoped", () => {
      expect(
        getExperimentAttributeScopeProjectIds({ project: "p1" }, [
          ["p2"],
          null,
        ]),
      ).toBeNull();
    });

    it("returns null for a project-less experiment", () => {
      expect(getExperimentAttributeScopeProjectIds({}, [["p2"]])).toBeNull();
    });
  });

  describe("resolveTargetingProjectIds", () => {
    const allProjectIds = ["p1", "p2", "p3", "p4"];

    it("returns the primary plus targeting projects, deduped", () => {
      expect(
        resolveTargetingProjectIds(
          { project: "p1", targetingProjects: ["p2", "p1"] },
          allProjectIds,
        ),
      ).toEqual(["p1", "p2"]);
    });

    it("enumerates all org projects when targetingAllProjects is set", () => {
      expect(
        resolveTargetingProjectIds(
          { project: "p1", targetingAllProjects: true },
          allProjectIds,
        ),
      ).toEqual(allProjectIds);
    });

    it("drops the empty primary for a project-less entity", () => {
      expect(
        resolveTargetingProjectIds(
          { targetingProjects: ["p2"] },
          allProjectIds,
        ),
      ).toEqual(["p2"]);
    });

    it("returns an empty array for an unscoped entity", () => {
      expect(resolveTargetingProjectIds({}, allProjectIds)).toEqual([]);
    });
  });

  describe("normalizeTargetingProjects", () => {
    it("drops the primary, blanks, and dupes from the list", () => {
      expect(
        normalizeTargetingProjects({
          project: "p1",
          targetingProjects: ["p1", "", "p2", "p2", "p3"],
        }),
      ).toEqual({
        targetingAllProjects: false,
        targetingProjects: ["p2", "p3"],
      });
    });

    it("clears the list when visible in all projects", () => {
      expect(
        normalizeTargetingProjects({
          project: "p1",
          targetingAllProjects: true,
          targetingProjects: ["p2"],
        }),
      ).toEqual({ targetingAllProjects: true, targetingProjects: [] });
    });
  });

  describe("getTargetingReviewMode", () => {
    it("defaults to strict with no rules", () => {
      expect(getTargetingReviewMode(undefined, "p2")).toBe("strict");
      expect(getTargetingReviewMode([], "p2")).toBe("strict");
    });
    it("uses the all-projects rule when no specific rule matches", () => {
      expect(
        getTargetingReviewMode([{ projects: [], mode: "loose" }], "p2"),
      ).toBe("loose");
    });
    it("prefers a project-specific rule over the all-projects rule", () => {
      expect(
        getTargetingReviewMode(
          [
            { projects: [], mode: "loose" },
            { projects: ["p2"], mode: "strict" },
          ],
          "p2",
        ),
      ).toBe("strict");
    });
    it("defaults to strict when a specific rule matches a different project", () => {
      expect(
        getTargetingReviewMode([{ projects: ["p2"], mode: "loose" }], "p3"),
      ).toBe("strict");
    });
  });

  describe("getGoverningReviewProjects", () => {
    it("includes the primary plus all strict targeting projects by default", () => {
      expect(getGoverningReviewProjects("p1", ["p2", "p3"], undefined)).toEqual(
        ["p1", "p2", "p3"],
      );
    });
    it("excludes targeting projects marked loose", () => {
      expect(
        getGoverningReviewProjects(
          "p1",
          ["p2", "p3"],
          [{ projects: ["p2"], mode: "loose" }],
        ),
      ).toEqual(["p1", "p3"]);
    });
    it("keeps only the primary when the org-wide rule is loose", () => {
      expect(
        getGoverningReviewProjects(
          "p1",
          ["p2", "p3"],
          [{ projects: [], mode: "loose" }],
        ),
      ).toEqual(["p1"]);
    });
  });

  describe("featureRequiresReview with targetingAllProjects", () => {
    const feature = (over: Partial<FeatureInterface>): FeatureInterface =>
      ({ project: "p1", ...over }) as unknown as FeatureInterface;
    const settings = (
      requireReviews: unknown,
      targetingReviewMode?: unknown,
    ): OrganizationSettings =>
      ({
        requireReviews,
        targetingReviewMode,
      }) as unknown as OrganizationSettings;
    const rule = (projects: string[]) => ({
      requireReviewOn: true,
      projects,
      environments: [],
    });

    it("requires review when an all-projects feature reaches a strict project that requires it", () => {
      // p1 (primary) has no requirement; p2 does, and strict is the default
      expect(
        featureRequiresReview(
          feature({ targetingAllProjects: true }),
          ["production"],
          true,
          settings([rule(["p2"])]),
        ),
      ).toBe(true);
    });

    it("does not require review when the only requiring project is loose-mode", () => {
      expect(
        featureRequiresReview(
          feature({ targetingAllProjects: true }),
          ["production"],
          true,
          settings([rule(["p2"])], [{ projects: ["p2"], mode: "loose" }]),
        ),
      ).toBe(false);
    });

    it("still requires review via an org-wide rule (matches the primary)", () => {
      expect(
        featureRequiresReview(
          feature({ targetingAllProjects: true }),
          ["production"],
          true,
          settings([rule([])]),
        ),
      ).toBe(true);
    });

    it("does not require review for an all-projects feature when no project requires it", () => {
      expect(
        featureRequiresReview(
          feature({ targetingAllProjects: true }),
          ["production"],
          true,
          settings([]),
        ),
      ).toBe(false);
    });

    it("a specific-targeting feature is unaffected (only its own projects govern)", () => {
      // targets p2 → p2's rule applies
      expect(
        featureRequiresReview(
          feature({ targetingProjects: ["p2"] }),
          ["production"],
          true,
          settings([rule(["p2"])]),
        ),
      ).toBe(true);
      // targets p2 → a rule for p3 does not apply
      expect(
        featureRequiresReview(
          feature({ targetingProjects: ["p2"] }),
          ["production"],
          true,
          settings([rule(["p3"])]),
        ),
      ).toBe(false);
    });
  });

  describe("normalizeTargetingInUpdates", () => {
    it("strips the current primary from an update's targeting list", () => {
      const updates: {
        targetingProjects?: string[];
        project?: string;
      } = { targetingProjects: ["p1", "p2"] };
      normalizeTargetingInUpdates(updates, { project: "p1" });
      expect(updates.targetingProjects).toEqual(["p2"]);
    });
    it("uses the update's new project when the project is changing", () => {
      const updates: {
        targetingProjects?: string[];
        project?: string;
      } = { project: "p2", targetingProjects: ["p1", "p2"] };
      normalizeTargetingInUpdates(updates, { project: "p1" });
      expect(updates.targetingProjects).toEqual(["p1"]);
    });
    it("is a no-op when no targeting fields are present", () => {
      const updates: { project?: string; targetingProjects?: string[] } = {
        project: "p2",
      };
      normalizeTargetingInUpdates(updates, { project: "p1" });
      expect(updates).toEqual({ project: "p2" });
    });
    it("clears the list when the update sets targetingAllProjects", () => {
      const updates: {
        targetingAllProjects?: boolean;
        targetingProjects?: string[];
      } = { targetingAllProjects: true, targetingProjects: ["p2"] };
      normalizeTargetingInUpdates(updates, { project: "p1" });
      expect(updates).toEqual({
        targetingAllProjects: true,
        targetingProjects: [],
      });
    });
    it("clears a stale stored list when a partial update only sets targetingAllProjects", () => {
      const updates: {
        targetingAllProjects?: boolean;
        targetingProjects?: string[];
      } = { targetingAllProjects: true };
      normalizeTargetingInUpdates(updates, {
        project: "p1",
        targetingProjects: ["p2", "p3"],
      });
      expect(updates).toEqual({
        targetingAllProjects: true,
        targetingProjects: [],
      });
    });
  });
});
