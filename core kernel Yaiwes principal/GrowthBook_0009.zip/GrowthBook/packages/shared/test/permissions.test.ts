import { NO_ENVIRONMENT_BINDING } from "shared/permissions";
import { OrganizationInterface } from "shared/types/organization";
import {
  roleToPermissionMap,
  Permissions,
  getEffectiveRolesForProject,
} from "../permissions";

describe("Role permissions", () => {
  const testOrg: OrganizationInterface = {
    id: "org_sktwi1id9l7z9xkjb",
    name: "Test Org",
    ownerEmail: "test@test.com",
    url: "https://test.com",
    dateCreated: new Date(),
    invites: [],
    members: [],
    settings: {
      environments: [{ id: "production", description: "" }],
    },
  };

  function getPermissions(role: string) {
    return new Permissions({
      global: {
        permissions: roleToPermissionMap(role, testOrg),
        limitAccessByEnvironment: false,
        environments: [],
      },
      projects: {},
    });
  }

  const project = "";
  const projects = [];
  const projectResource = { project: "" };
  const projectsResource = { projects: [], type: undefined };
  const environmentsResource = { projects: [], id: "" };
  const envs = ["production"];
  const sdkConnection = { projects: [], environment: "" };
  const updates = {};
  const event = { containsSecrets: false, projects: [] };
  const secretEvent = { containsSecrets: true, projects: [] };

  it("has correct permissions for noaccess", () => {
    const p = getPermissions("noaccess");
    expect(p.canAddComment(projects)).toBe(false);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(false);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(false);
    expect(p.canCreateAttribute(projectsResource)).toBe(false);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(false);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(false);
    expect(p.canCreateFactMetric(projectsResource)).toBe(false);
    expect(p.canCreateFactTable(projectsResource)).toBe(false);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canCreateIdea(projectResource)).toBe(false);
    expect(p.canCreateMetric(projectsResource)).toBe(false);
    expect(p.canCreateNamespace()).toBe(false);
    expect(p.canCreatePresentation()).toBe(false);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(false);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(false);
    expect(p.canCreateSegment(projectsResource)).toBe(false);
    expect(p.canCreateVisualChange(projectResource)).toBe(false);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(false);
    expect(p.canDeleteAttribute(projectsResource)).toBe(false);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(false);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(false);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(false);
    expect(p.canDeleteFactTable(projectsResource)).toBe(false);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(false);
    expect(p.canDeleteMetric(projectsResource)).toBe(false);
    expect(p.canDeleteNamespace()).toBe(false);
    expect(p.canDeletePresentation()).toBe(false);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(false);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(false);
    expect(p.canDeleteSegment(projectsResource)).toBe(false);
    expect(p.canDeleteTag()).toBe(false);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(false);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      false,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(false);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunFactQueries(projectsResource)).toBe(false);
    expect(p.canRunHealthQueries(projectsResource)).toBe(false);
    expect(p.canRunMetricQueries(projectsResource)).toBe(false);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(false);
    expect(p.canRunTestQueries(projectsResource)).toBe(false);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(false);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(false);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(false);
    expect(p.canUpdateDimension()).toBe(false);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(false);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(false);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateNamespace()).toBe(false);
    expect(p.canUpdatePresentation()).toBe(false);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(false);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(false);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(false);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(false);
    expect(p.canUpdateVisualChange(projectResource)).toBe(false);
    expect(p.canViewAttributeModal()).toBe(false);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(false);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(false);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(false);
    expect(p.canViewFeatureModal()).toBe(false);
    expect(p.canViewIdeaModal()).toBe(false);
    expect(p.canViewReportModal()).toBe(false);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(false);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(false);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(false);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(false);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(false);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(false);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(false);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(false);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(false);
    expect(p.canReadSingleProjectResource(project)).toBe(false);
    expect(p.canReadMultiProjectResource(projects)).toBe(false);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for readonly", () => {
    const p = getPermissions("readonly");
    expect(p.canAddComment(projects)).toBe(false);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(false);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(false);
    expect(p.canCreateAttribute(projectsResource)).toBe(false);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(false);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(false);
    expect(p.canCreateFactMetric(projectsResource)).toBe(false);
    expect(p.canCreateFactTable(projectsResource)).toBe(false);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canCreateIdea(projectResource)).toBe(false);
    expect(p.canCreateMetric(projectsResource)).toBe(false);
    expect(p.canCreateNamespace()).toBe(false);
    expect(p.canCreatePresentation()).toBe(false);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(false);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(false);
    expect(p.canCreateSegment(projectsResource)).toBe(false);
    expect(p.canCreateVisualChange(projectResource)).toBe(false);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(false);
    expect(p.canDeleteAttribute(projectsResource)).toBe(false);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(false);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(false);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(false);
    expect(p.canDeleteFactTable(projectsResource)).toBe(false);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(false);
    expect(p.canDeleteMetric(projectsResource)).toBe(false);
    expect(p.canDeleteNamespace()).toBe(false);
    expect(p.canDeletePresentation()).toBe(false);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(false);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(false);
    expect(p.canDeleteSegment(projectsResource)).toBe(false);
    expect(p.canDeleteTag()).toBe(false);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(false);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      false,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(false);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunFactQueries(projectsResource)).toBe(false);
    expect(p.canRunHealthQueries(projectsResource)).toBe(false);
    expect(p.canRunMetricQueries(projectsResource)).toBe(false);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(false);
    expect(p.canRunTestQueries(projectsResource)).toBe(false);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(false);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(false);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(false);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(false);
    expect(p.canUpdateDimension()).toBe(false);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(false);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(false);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateNamespace()).toBe(false);
    expect(p.canUpdatePresentation()).toBe(false);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(false);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(false);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(false);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(false);
    expect(p.canViewAttributeModal()).toBe(false);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(false);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(false);
    expect(p.canViewFeatureModal()).toBe(false);
    expect(p.canViewIdeaModal()).toBe(false);
    expect(p.canViewReportModal()).toBe(false);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(false);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(false);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(false);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(false);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(false);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(false);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(false);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(false);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(false);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for visualEditor", () => {
    const p = getPermissions("visualEditor");
    expect(p.canAddComment(projects)).toBe(false);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(false);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(false);
    expect(p.canCreateAttribute(projectsResource)).toBe(false);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(false);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(false);
    expect(p.canCreateFactMetric(projectsResource)).toBe(false);
    expect(p.canCreateFactTable(projectsResource)).toBe(false);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canCreateIdea(projectResource)).toBe(false);
    expect(p.canCreateMetric(projectsResource)).toBe(false);
    expect(p.canCreateNamespace()).toBe(false);
    expect(p.canCreatePresentation()).toBe(false);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(false);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(false);
    expect(p.canCreateSegment(projectsResource)).toBe(false);
    expect(p.canCreateVisualChange(projectResource)).toBe(true);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(false);
    expect(p.canDeleteAttribute(projectsResource)).toBe(false);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(false);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(false);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(false);
    expect(p.canDeleteFactTable(projectsResource)).toBe(false);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(false);
    expect(p.canDeleteMetric(projectsResource)).toBe(false);
    expect(p.canDeleteNamespace()).toBe(false);
    expect(p.canDeletePresentation()).toBe(false);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(false);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(false);
    expect(p.canDeleteSegment(projectsResource)).toBe(false);
    expect(p.canDeleteTag()).toBe(false);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(false);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      false,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(false);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunFactQueries(projectsResource)).toBe(false);
    expect(p.canRunHealthQueries(projectsResource)).toBe(false);
    expect(p.canRunMetricQueries(projectsResource)).toBe(false);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(false);
    expect(p.canRunTestQueries(projectsResource)).toBe(false);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(false);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(false);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(false);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(false);
    expect(p.canUpdateDimension()).toBe(false);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(false);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(false);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateNamespace()).toBe(false);
    expect(p.canUpdatePresentation()).toBe(false);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(false);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(false);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(false);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(true);
    expect(p.canViewAttributeModal()).toBe(false);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(false);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(false);
    expect(p.canViewFeatureModal()).toBe(false);
    expect(p.canViewIdeaModal()).toBe(false);
    expect(p.canViewReportModal()).toBe(false);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(false);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(false);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(false);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(false);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(false);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(false);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(false);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(false);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(false);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for collaborator", () => {
    const p = getPermissions("collaborator");
    expect(p.canAddComment(projects)).toBe(true);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(false);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(false);
    expect(p.canCreateAttribute(projectsResource)).toBe(false);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(false);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(false);
    expect(p.canCreateFactMetric(projectsResource)).toBe(false);
    expect(p.canCreateFactTable(projectsResource)).toBe(false);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canCreateIdea(projectResource)).toBe(true);
    expect(p.canCreateMetric(projectsResource)).toBe(false);
    expect(p.canCreateNamespace()).toBe(false);
    expect(p.canCreatePresentation()).toBe(true);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(false);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(false);
    expect(p.canCreateSegment(projectsResource)).toBe(false);
    expect(p.canCreateVisualChange(projectResource)).toBe(false);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(false);
    expect(p.canDeleteAttribute(projectsResource)).toBe(false);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(false);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(false);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(false);
    expect(p.canDeleteFactTable(projectsResource)).toBe(false);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(true);
    expect(p.canDeleteMetric(projectsResource)).toBe(false);
    expect(p.canDeleteNamespace()).toBe(false);
    expect(p.canDeletePresentation()).toBe(true);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(false);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(false);
    expect(p.canDeleteSegment(projectsResource)).toBe(false);
    expect(p.canDeleteTag()).toBe(false);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(false);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      false,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(false);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunFactQueries(projectsResource)).toBe(false);
    expect(p.canRunHealthQueries(projectsResource)).toBe(false);
    expect(p.canRunMetricQueries(projectsResource)).toBe(false);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(false);
    expect(p.canRunTestQueries(projectsResource)).toBe(false);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(false);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(false);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(false);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(false);
    expect(p.canUpdateDimension()).toBe(false);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(false);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(true);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateNamespace()).toBe(false);
    expect(p.canUpdatePresentation()).toBe(true);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(false);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(false);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(false);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(false);
    expect(p.canViewAttributeModal()).toBe(false);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(false);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(false);
    expect(p.canViewFeatureModal()).toBe(false);
    expect(p.canViewIdeaModal()).toBe(true);
    expect(p.canViewReportModal()).toBe(false);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(false);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(false);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(false);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(false);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(false);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(false);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(false);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(false);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(false);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for engineer", () => {
    const p = getPermissions("engineer");
    expect(p.canAddComment(projects)).toBe(true);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(true);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(true);
    expect(p.canCreateAttribute(projectsResource)).toBe(true);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(false);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(false);
    expect(p.canCreateFactMetric(projectsResource)).toBe(false);
    expect(p.canCreateFactTable(projectsResource)).toBe(false);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canCreateIdea(projectResource)).toBe(true);
    expect(p.canCreateMetric(projectsResource)).toBe(false);
    expect(p.canCreateNamespace()).toBe(true);
    expect(p.canCreatePresentation()).toBe(true);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(false);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(true);
    expect(p.canCreateSegment(projectsResource)).toBe(false);
    expect(p.canCreateVisualChange(projectResource)).toBe(true);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(true);
    expect(p.canDeleteAttribute(projectsResource)).toBe(true);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(false);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(false);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(false);
    expect(p.canDeleteFactTable(projectsResource)).toBe(false);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(true);
    expect(p.canDeleteMetric(projectsResource)).toBe(false);
    expect(p.canDeleteNamespace()).toBe(true);
    expect(p.canDeletePresentation()).toBe(true);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(false);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(true);
    expect(p.canDeleteSegment(projectsResource)).toBe(false);
    expect(p.canDeleteTag()).toBe(true);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(true);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      true,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(true);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunFactQueries(projectsResource)).toBe(false);
    expect(p.canRunHealthQueries(projectsResource)).toBe(false);
    expect(p.canRunMetricQueries(projectsResource)).toBe(false);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(false);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(false);
    expect(p.canRunTestQueries(projectsResource)).toBe(false);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(false);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(true);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(true);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(false);
    expect(p.canUpdateDimension()).toBe(false);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(false);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(true);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(false);
    expect(p.canUpdateNamespace()).toBe(true);
    expect(p.canUpdatePresentation()).toBe(true);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(false);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(true);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(true);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(false);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(true);
    expect(p.canViewAttributeModal()).toBe(true);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(false);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(false);
    expect(p.canViewFeatureModal()).toBe(true);
    expect(p.canViewIdeaModal()).toBe(true);
    expect(p.canViewReportModal()).toBe(false);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(false);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(false);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(true);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(true);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(true);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(true);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(true);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(true);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(true);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for analyst", () => {
    const p = getPermissions("analyst");
    expect(p.canAddComment(projects)).toBe(true);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(true);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(false);
    expect(p.canCreateAttribute(projectsResource)).toBe(false);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(true);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(true);
    expect(p.canCreateFactMetric(projectsResource)).toBe(true);
    expect(p.canCreateFactTable(projectsResource)).toBe(true);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canCreateIdea(projectResource)).toBe(true);
    expect(p.canCreateMetric(projectsResource)).toBe(true);
    expect(p.canCreateNamespace()).toBe(false);
    expect(p.canCreatePresentation()).toBe(true);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(true);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(false);
    expect(p.canCreateSegment(projectsResource)).toBe(true);
    expect(p.canCreateVisualChange(projectResource)).toBe(true);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(false);
    expect(p.canDeleteAttribute(projectsResource)).toBe(false);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(true);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(true);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(true);
    expect(p.canDeleteFactTable(projectsResource)).toBe(true);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      false,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(true);
    expect(p.canDeleteMetric(projectsResource)).toBe(true);
    expect(p.canDeleteNamespace()).toBe(false);
    expect(p.canDeletePresentation()).toBe(true);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(true);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(false);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(false);
    expect(p.canDeleteSegment(projectsResource)).toBe(true);
    expect(p.canDeleteTag()).toBe(true);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(false);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      false,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(false);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunFactQueries(projectsResource)).toBe(true);
    expect(p.canRunHealthQueries(projectsResource)).toBe(true);
    expect(p.canRunMetricQueries(projectsResource)).toBe(true);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(true);
    expect(p.canRunTestQueries(projectsResource)).toBe(true);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(true);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(false);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(false);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(true);
    expect(p.canUpdateDimension()).toBe(true);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(true);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(true);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(false);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(true);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateNamespace()).toBe(false);
    expect(p.canUpdatePresentation()).toBe(true);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(true);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(false);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(true);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(true);
    expect(p.canViewAttributeModal()).toBe(false);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(true);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(true);
    expect(p.canViewFeatureModal()).toBe(false);
    expect(p.canViewIdeaModal()).toBe(true);
    expect(p.canViewReportModal()).toBe(true);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(true);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(true);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(false);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(false);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(false);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(false);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(false);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(false);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(false);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for experimenter", () => {
    const p = getPermissions("experimenter");
    expect(p.canAddComment(projects)).toBe(true);
    expect(
      ["feature", "config", "constant"].some((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(false);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(false);
    expect(p.canCreateAndUpdateTag()).toBe(true);
    expect(p.canCreateApiKey()).toBe(false);
    expect(p.canCreateArchetype(projectsResource)).toBe(true);
    expect(p.canCreateAttribute(projectsResource)).toBe(true);
    expect(p.canCreateDataSource(projectsResource)).toBe(false);
    expect(p.canCreateDimension()).toBe(true);
    expect(p.canCreateEventWebhook()).toBe(false);
    expect(p.canCreateExperiment(projectResource)).toBe(true);
    expect(p.canCreateFactMetric(projectsResource)).toBe(true);
    expect(p.canCreateFactTable(projectsResource)).toBe(true);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canCreateIdea(projectResource)).toBe(true);
    expect(p.canCreateMetric(projectsResource)).toBe(true);
    expect(p.canCreateNamespace()).toBe(true);
    expect(p.canCreatePresentation()).toBe(true);
    expect(p.canCreateProjects()).toBe(false);
    expect(p.canCreateReport(projectResource)).toBe(true);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(true);
    expect(p.canCreateSegment(projectsResource)).toBe(true);
    expect(p.canCreateVisualChange(projectResource)).toBe(true);
    expect(p.canDeleteApiKey()).toBe(false);
    expect(p.canDeleteArchetype(projectsResource)).toBe(true);
    expect(p.canDeleteAttribute(projectsResource)).toBe(true);
    expect(p.canDeleteDataSource(projectsResource)).toBe(false);
    expect(p.canDeleteDimension()).toBe(true);
    expect(p.canDeleteEventWebhook()).toBe(false);
    expect(p.canDeleteExperiment(projectResource)).toBe(true);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(true);
    expect(p.canDeleteFactTable(projectsResource)).toBe(true);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(true);
    expect(p.canDeleteMetric(projectsResource)).toBe(true);
    expect(p.canDeleteNamespace()).toBe(true);
    expect(p.canDeletePresentation()).toBe(true);
    expect(p.canDeleteProject(project)).toBe(false);
    expect(p.canDeleteReport(projectResource)).toBe(true);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(true);
    expect(p.canDeleteSegment(projectsResource)).toBe(true);
    expect(p.canDeleteTag()).toBe(true);
    expect(p.canManageBilling()).toBe(false);
    expect(p.canViewUsage()).toBe(false);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canManageIntegrations()).toBe(false);
    expect(p.canManageNorthStarMetric()).toBe(false);
    expect(p.canManageOrgSettings()).toBe(false);
    expect(p.canManageTeam()).toBe(false);
    expect(p.canPublishFeature(projectResource, envs)).toBe(true);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      true,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(true);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunFactQueries(projectsResource)).toBe(true);
    expect(p.canRunHealthQueries(projectsResource)).toBe(true);
    expect(p.canRunMetricQueries(projectsResource)).toBe(true);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(true);
    expect(p.canRunTestQueries(projectsResource)).toBe(true);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(true);
    expect(p.canSuperDeleteReport()).toBe(false);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(true);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(true);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(false);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(true);
    expect(p.canUpdateDimension()).toBe(true);
    expect(p.canUpdateEventWebhook()).toBe(false);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(true);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(true);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(true);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateNamespace()).toBe(true);
    expect(p.canUpdatePresentation()).toBe(true);
    expect(p.canUpdateProject(project)).toBe(false);
    expect(p.canUpdateReport(projectResource)).toBe(true);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(true);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(true);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(true);
    expect(p.canManageSomeProjects()).toBe(false);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(true);
    expect(p.canViewAttributeModal()).toBe(true);
    expect(p.canViewCreateDataSourceModal()).toBe(false);
    expect(p.canViewCreateFactTableModal()).toBe(true);
    expect(p.canViewEventWebhook()).toBe(false);
    expect(p.canViewAuditLogs()).toBe(false);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(false);
    expect(p.canViewExperimentModal()).toBe(true);
    expect(p.canViewFeatureModal()).toBe(true);
    expect(p.canViewIdeaModal()).toBe(true);
    expect(p.canViewReportModal()).toBe(true);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(true);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(true);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(true);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(true);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(true);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(true);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(true);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(true);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(true);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(false);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(false);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(false);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(false);
  });

  it("has correct permissions for admin", () => {
    const p = getPermissions("admin");
    expect(p.canAddComment(projects)).toBe(true);
    expect(
      ["feature", "config", "constant"].every((m) =>
        p.canBypassFlagApprovalChecks(
          projectResource,
          m as "feature" | "config" | "constant",
        ),
      ),
    ).toBe(true);
    expect(p.canBypassSavedGroupApprovalChecks(projectResource)).toBe(true);
    expect(p.canCreateAndUpdateTag()).toBe(true);
    expect(p.canCreateApiKey()).toBe(true);
    expect(p.canCreateArchetype(projectsResource)).toBe(true);
    expect(p.canCreateAttribute(projectsResource)).toBe(true);
    expect(p.canCreateDataSource(projectsResource)).toBe(true);
    expect(p.canCreateDimension()).toBe(true);
    expect(p.canCreateEventWebhook()).toBe(true);
    expect(p.canCreateExperiment(projectResource)).toBe(true);
    expect(p.canCreateFactMetric(projectsResource)).toBe(true);
    expect(p.canCreateFactTable(projectsResource)).toBe(true);
    expect(p.canCreateFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canCreateIdea(projectResource)).toBe(true);
    expect(p.canCreateMetric(projectsResource)).toBe(true);
    expect(p.canCreateNamespace()).toBe(true);
    expect(p.canCreatePresentation()).toBe(true);
    expect(p.canCreateProjects()).toBe(true);
    expect(p.canCreateReport(projectResource)).toBe(true);
    expect(p.canCreateSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canCreateSavedGroup(projectsResource)).toBe(true);
    expect(p.canCreateSegment(projectsResource)).toBe(true);
    expect(p.canCreateVisualChange(projectResource)).toBe(true);
    expect(p.canDeleteApiKey()).toBe(true);
    expect(p.canDeleteArchetype(projectsResource)).toBe(true);
    expect(p.canDeleteAttribute(projectsResource)).toBe(true);
    expect(p.canDeleteDataSource(projectsResource)).toBe(true);
    expect(p.canDeleteDimension()).toBe(true);
    expect(p.canDeleteEventWebhook()).toBe(true);
    expect(p.canDeleteExperiment(projectResource)).toBe(true);
    expect(p.canDeleteFactMetric(projectsResource)).toBe(true);
    expect(p.canDeleteFactTable(projectsResource)).toBe(true);
    expect(p.canDeleteFeature(projectResource, NO_ENVIRONMENT_BINDING)).toBe(
      true,
    );
    expect(p.canDeleteIdea(projectResource)).toBe(true);
    expect(p.canDeleteMetric(projectsResource)).toBe(true);
    expect(p.canDeleteNamespace()).toBe(true);
    expect(p.canDeletePresentation()).toBe(true);
    expect(p.canDeleteProject(project)).toBe(true);
    expect(p.canDeleteReport(projectResource)).toBe(true);
    expect(p.canDeleteSDKWebhook(sdkConnection)).toBe(true);
    expect(p.canDeleteSavedGroup(projectsResource)).toBe(true);
    expect(p.canDeleteSegment(projectsResource)).toBe(true);
    expect(p.canDeleteTag()).toBe(true);
    expect(p.canManageBilling()).toBe(true);
    expect(p.canViewUsage()).toBe(true);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canManageIntegrations()).toBe(true);
    expect(p.canManageNorthStarMetric()).toBe(true);
    expect(p.canManageOrgSettings()).toBe(true);
    expect(p.canManageTeam()).toBe(true);
    expect(p.canPublishFeature(projectResource, envs)).toBe(true);
    expect(p.canReviewFeatureDrafts(projectResource, { scope: "any" })).toBe(
      true,
    );
    expect(p.canRunExperiment(projectResource, envs)).toBe(true);
    expect(p.canRunExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunFactQueries(projectsResource)).toBe(true);
    expect(p.canRunHealthQueries(projectsResource)).toBe(true);
    expect(p.canRunMetricQueries(projectsResource)).toBe(true);
    expect(p.canRunPastExperimentQueries(projectsResource)).toBe(true);
    expect(p.canRunSchemaQueries(projectsResource)).toBe(true);
    expect(p.canRunTestQueries(projectsResource)).toBe(true);
    expect(p.canRunSqlExplorerQueries(projectsResource)).toBe(true);
    expect(p.canSuperDeleteReport()).toBe(true);
    expect(p.canUpdateArchetype(projectsResource, updates)).toBe(true);
    expect(p.canUpdateAttribute(projectsResource, updates)).toBe(true);
    expect(p.canUpdateDataSourceParams(projectsResource)).toBe(true);
    expect(p.canUpdateDataSourceSettings(projectsResource)).toBe(true);
    expect(p.canUpdateDimension()).toBe(true);
    expect(p.canUpdateEventWebhook()).toBe(true);
    expect(p.canUpdateExperiment(projectResource, updates)).toBe(true);
    expect(p.canUpdateFactMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateFactTable(projectsResource, updates)).toBe(true);
    expect(p.canEditFeatureDrafts(projectResource)).toBe(true);
    expect(p.canUpdateIdea(projectResource, updates)).toBe(true);
    expect(p.canUpdateMetric(projectsResource, updates)).toBe(true);
    expect(p.canUpdateNamespace()).toBe(true);
    expect(p.canUpdatePresentation()).toBe(true);
    expect(p.canUpdateProject(project)).toBe(true);
    expect(p.canUpdateReport(projectResource)).toBe(true);
    expect(p.canUpdateSDKWebhook(sdkConnection)).toBe(true);
    expect(
      p.canRevisionAction(
        "saved-group",
        "draft",
        projectsResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(true);
    expect(p.canUpdateSegment(projectsResource, updates)).toBe(true);
    expect(p.canManageSomeProjects()).toBe(true);
    expect(p.canViewProjectsPage()).toBe(true);
    expect(p.canUpdateVisualChange(projectResource)).toBe(true);
    expect(p.canViewAttributeModal()).toBe(true);
    expect(p.canViewCreateDataSourceModal()).toBe(true);
    expect(p.canViewCreateFactTableModal()).toBe(true);
    expect(p.canViewEventWebhook()).toBe(true);
    expect(p.canViewAuditLogs()).toBe(true);
    expect(p.canViewEvent(event)).toBe(true);
    expect(p.canViewEvent(secretEvent)).toBe(true);
    expect(p.canViewExperimentModal()).toBe(true);
    expect(p.canViewFeatureModal()).toBe(true);
    expect(p.canViewIdeaModal()).toBe(true);
    expect(p.canViewReportModal()).toBe(true);
    expect(p.canCreateAndUpdateFactFilter(projectsResource)).toBe(true);
    expect(p.canDeleteFactFilter(projectsResource)).toBe(true);
    expect(p.canCreateEnvironment(environmentsResource)).toBe(true);
    expect(p.canUpdateEnvironment(environmentsResource, updates)).toBe(true);
    expect(p.canDeleteEnvironment(environmentsResource)).toBe(true);
    expect(p.canViewCreateSDKConnectionModal(project)).toBe(true);
    expect(p.canCreateSDKConnection(sdkConnection)).toBe(true);
    expect(p.canUpdateSDKConnection(sdkConnection, updates)).toBe(true);
    expect(p.canDeleteSDKConnection(sdkConnection)).toBe(true);
    expect(p.canReadSingleProjectResource(project)).toBe(true);
    expect(p.canReadMultiProjectResource(projects)).toBe(true);
    expect(p.canManageLegacySDKWebhooks()).toBe(true);
    expect(p.canCreateOfficialResources(projectsResource)).toBe(true);
    expect(
      p.canUpdateOfficialResources(projectsResource, projectsResource),
    ).toBe(true);
    expect(p.canDeleteOfficialResources(projectsResource)).toBe(true);
  });
});

describe("canManageFeatureCustomHooks", () => {
  const testOrg: OrganizationInterface = {
    id: "org_sktwi1id9l7z9xkjb",
    name: "Test Org",
    ownerEmail: "test@test.com",
    url: "https://test.com",
    dateCreated: new Date(),
    invites: [],
    members: [],
    settings: {
      environments: [{ id: "production", description: "" }],
    },
  };

  function getPermissions(role: string) {
    return new Permissions({
      global: {
        permissions: roleToPermissionMap(role, testOrg),
        limitAccessByEnvironment: false,
        environments: [],
      },
      projects: {},
    });
  }

  const featureResource = { project: "" };

  it("lets admins manage feature hooks (they have manageFeatures)", () => {
    expect(
      getPermissions("admin").canManageFeatureCustomHooks(
        featureResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(true);
  });

  it("lets feature editors manage feature hooks", () => {
    // engineer has manageFeatures
    expect(
      getPermissions("engineer").canManageFeatureCustomHooks(
        featureResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(true);
  });

  it("does not let users without feature edit access manage hooks", () => {
    expect(
      getPermissions("readonly").canManageFeatureCustomHooks(
        featureResource,
        NO_ENVIRONMENT_BINDING,
      ),
    ).toBe(false);
  });
});

describe("canManageExperimentCustomHooks", () => {
  const testOrg: OrganizationInterface = {
    id: "org_sktwi1id9l7z9xkjb",
    name: "Test Org",
    ownerEmail: "test@test.com",
    url: "https://test.com",
    dateCreated: new Date(),
    invites: [],
    members: [],
    settings: {
      environments: [{ id: "production", description: "" }],
    },
  };

  function getPermissions(role: string) {
    return new Permissions({
      global: {
        permissions: roleToPermissionMap(role, testOrg),
        limitAccessByEnvironment: false,
        environments: [],
      },
      projects: {},
    });
  }

  const experimentResource = { project: "" };

  it("lets admins manage experiment hooks", () => {
    expect(
      getPermissions("admin").canManageExperimentCustomHooks(
        experimentResource,
      ),
    ).toBe(true);
  });

  it("lets experiment editors manage experiment hooks", () => {
    expect(
      getPermissions("experimenter").canManageExperimentCustomHooks(
        experimentResource,
      ),
    ).toBe(true);
  });

  it("does not let users without experiment edit access manage hooks", () => {
    expect(
      getPermissions("readonly").canManageExperimentCustomHooks(
        experimentResource,
      ),
    ).toBe(false);
  });
});

describe("getEffectiveRolesForProject", () => {
  // These cases are about which roles apply and from where; the env fields each
  // rule carries are covered separately below.
  const roleSources = (
    ...args: Parameters<typeof getEffectiveRolesForProject>
  ) =>
    getEffectiveRolesForProject(...args).map(
      ({ role, sourceType, sourceName }) => ({ role, sourceType, sourceName }),
    );

  const team = (
    id: string,
    name: string,
    role: string,
    projectRoles: {
      project: string;
      role: string;
      limitAccessByEnvironment: boolean;
      environments: string[];
    }[] = [],
  ) => ({ id, name, role, projectRoles });

  it("returns just the member's global role when they have no project role and no teams", () => {
    expect(roleSources({ role: "engineer" }, "prj_1", [])).toEqual([
      { role: "engineer", sourceType: "user", sourceName: "user" },
    ]);
  });

  it("uses the member's own project role over their global role", () => {
    expect(
      roleSources(
        {
          role: "engineer",
          projectRoles: [
            {
              project: "prj_1",
              role: "analyst",
              limitAccessByEnvironment: false,
              environments: [],
            },
          ],
        },
        "prj_1",
        [],
      ),
    ).toEqual([{ role: "analyst", sourceType: "user", sourceName: "user" }]);
  });

  it("does not let a team's global role leak past the member's explicit project role", () => {
    const result = roleSources(
      {
        role: "readonly",
        projectRoles: [
          {
            project: "prj_1",
            role: "noaccess",
            limitAccessByEnvironment: false,
            environments: [],
          },
        ],
        teams: ["team_1"],
      },
      "prj_1",
      [team("team_1", "Readers", "readonly")],
    );
    // The team has no explicit project role, so only the explicit project role applies.
    expect(result).toEqual([
      { role: "noaccess", sourceType: "user", sourceName: "user" },
    ]);
  });

  it("unions explicit project roles from the member and their teams", () => {
    const result = roleSources(
      {
        role: "readonly",
        projectRoles: [
          {
            project: "prj_1",
            role: "noaccess",
            limitAccessByEnvironment: false,
            environments: [],
          },
        ],
        teams: ["team_1"],
      },
      "prj_1",
      [
        team("team_1", "Engineers", "noaccess", [
          {
            project: "prj_1",
            role: "engineer",
            limitAccessByEnvironment: false,
            environments: [],
          },
        ]),
      ],
    );
    expect(result).toEqual([
      { role: "noaccess", sourceType: "user", sourceName: "user" },
      { role: "engineer", sourceType: "team", sourceName: "Engineers" },
    ]);
  });

  it("falls back to global roles (user + teams) when no explicit project role applies", () => {
    const result = roleSources(
      { role: "readonly", teams: ["team_1"] },
      "prj_1",
      [team("team_1", "Engineers", "engineer")],
    );
    expect(result).toEqual([
      { role: "readonly", sourceType: "user", sourceName: "user" },
      { role: "engineer", sourceType: "team", sourceName: "Engineers" },
    ]);
  });

  it("drops the member's global role when only a team has an explicit project role", () => {
    const result = roleSources({ role: "admin", teams: ["team_1"] }, "prj_1", [
      team("team_1", "Restricted", "readonly", [
        {
          project: "prj_1",
          role: "noaccess",
          limitAccessByEnvironment: false,
          environments: [],
        },
      ]),
    ]);
    expect(result).toEqual([
      { role: "noaccess", sourceType: "team", sourceName: "Restricted" },
    ]);
  });

  it("resolves global roles (user + teams) when project is null", () => {
    const result = roleSources(
      {
        role: "readonly",
        projectRoles: [
          {
            project: "prj_1",
            role: "engineer",
            limitAccessByEnvironment: false,
            environments: [],
          },
        ],
        teams: ["team_1"],
      },
      null,
      [team("team_1", "Admins", "admin")],
    );
    expect(result).toEqual([
      { role: "readonly", sourceType: "user", sourceName: "user" },
      { role: "admin", sourceType: "team", sourceName: "Admins" },
    ]);
  });

  it("counts a member's additional rules alongside their base role", () => {
    expect(
      roleSources(
        {
          role: "qa_reviewer",
          additionalRoles: [{ role: "qa_publisher" }],
        },
        null,
        [],
      ),
    ).toEqual([
      { role: "qa_reviewer", sourceType: "user", sourceName: "user" },
      { role: "qa_publisher", sourceType: "user", sourceName: "user" },
    ]);
  });

  it("counts a team's additional rules", () => {
    const result = roleSources({ role: "readonly", teams: ["team_1"] }, null, [
      {
        ...team("team_1", "Reviewers", "collaborator"),
        additionalRoles: [{ role: "qa_reviewer" }],
      },
    ]);
    expect(result).toEqual([
      { role: "readonly", sourceType: "user", sourceName: "user" },
      { role: "collaborator", sourceType: "team", sourceName: "Reviewers" },
      { role: "qa_reviewer", sourceType: "team", sourceName: "Reviewers" },
    ]);
  });

  // A project entry replaces the global one wholesale, so global additional
  // rules must not leak past it — only the override's own do.
  it("drops global additional rules when a project role applies", () => {
    expect(
      roleSources(
        {
          role: "engineer",
          additionalRoles: [{ role: "qa_publisher" }],
          projectRoles: [
            {
              project: "prj_1",
              role: "analyst",
              limitAccessByEnvironment: false,
              environments: [],
              additionalRoles: [{ role: "qa_reviewer" }],
            },
          ],
        },
        "prj_1",
        [],
      ),
    ).toEqual([
      { role: "analyst", sourceType: "user", sourceName: "user" },
      { role: "qa_reviewer", sourceType: "user", sourceName: "user" },
    ]);
  });

  it("carries each rule's own environment restriction, not a shared one", () => {
    expect(
      getEffectiveRolesForProject(
        {
          role: "qa_reviewer",
          limitAccessByEnvironment: true,
          environments: ["dev"],
          additionalRoles: [
            {
              role: "qa_publisher",
              limitAccessByEnvironment: true,
              environments: ["production"],
            },
          ],
        },
        null,
        [],
      ),
    ).toEqual([
      {
        role: "qa_reviewer",
        sourceType: "user",
        sourceName: "user",
        limitAccessByEnvironment: true,
        environments: ["dev"],
      },
      {
        role: "qa_publisher",
        sourceType: "user",
        sourceName: "user",
        limitAccessByEnvironment: true,
        environments: ["production"],
      },
    ]);
  });

  it("carries the restriction on a team's additional rule", () => {
    expect(
      getEffectiveRolesForProject(
        { role: "noaccess", teams: ["team_1"] },
        null,
        [
          {
            id: "team_1",
            name: "Drafters",
            role: "qa_drafter",
            limitAccessByEnvironment: false,
            environments: [],
            additionalRoles: [
              {
                role: "qa_publisher",
                limitAccessByEnvironment: true,
                environments: ["production"],
              },
            ],
          },
        ],
      ),
    ).toEqual([
      {
        role: "noaccess",
        sourceType: "user",
        sourceName: "user",
        limitAccessByEnvironment: false,
        environments: [],
      },
      {
        role: "qa_drafter",
        sourceType: "team",
        sourceName: "Drafters",
        limitAccessByEnvironment: false,
        environments: [],
      },
      {
        role: "qa_publisher",
        sourceType: "team",
        sourceName: "Drafters",
        limitAccessByEnvironment: true,
        environments: ["production"],
      },
    ]);
  });

  it("takes the project role's restriction over the global one", () => {
    expect(
      getEffectiveRolesForProject(
        {
          role: "engineer",
          limitAccessByEnvironment: true,
          environments: ["dev"],
          projectRoles: [
            {
              project: "prj_1",
              role: "engineer",
              limitAccessByEnvironment: true,
              environments: ["staging"],
            },
          ],
        },
        "prj_1",
        [],
      ),
    ).toEqual([
      {
        role: "engineer",
        sourceType: "user",
        sourceName: "user",
        limitAccessByEnvironment: true,
        environments: ["staging"],
      },
    ]);
  });
});

describe("canManageFactTableVirtualColumn", () => {
  const testOrg: OrganizationInterface = {
    id: "org_sktwi1id9l7z9xkjb",
    name: "Test Org",
    ownerEmail: "test@test.com",
    url: "https://test.com",
    dateCreated: new Date(),
    invites: [],
    members: [],
    settings: {
      environments: [{ id: "production", description: "" }],
    },
  };

  function getPermissions(role: string) {
    return new Permissions({
      global: {
        permissions: roleToPermissionMap(role, testOrg),
        limitAccessByEnvironment: false,
        environments: [],
      },
      projects: {},
    });
  }

  const unmanaged = { projects: [], managedBy: "" as const };
  const managed = { projects: [], managedBy: "api" as const };

  it("allows fact table managers on an unmanaged fact table", () => {
    expect(
      getPermissions("analyst").canManageFactTableVirtualColumn(unmanaged),
    ).toBe(true);
    expect(
      getPermissions("admin").canManageFactTableVirtualColumn(unmanaged),
    ).toBe(true);
  });

  it("blocks users without official-resource access on a managed fact table", () => {
    // A virtual column carries raw SQL, so it must not be a way around the
    // official-resources gate that protects a managed fact table's own SQL.
    for (const role of ["analyst", "experimenter"]) {
      const p = getPermissions(role);
      expect(p.canUpdateFactTable(managed, { sql: "SELECT 1" })).toBe(false);
      expect(p.canManageFactTableVirtualColumn(managed)).toBe(false);
    }
  });

  it("still allows admins on a managed fact table", () => {
    expect(
      getPermissions("admin").canManageFactTableVirtualColumn(managed),
    ).toBe(true);
  });

  it("blocks users without manageFactTables entirely", () => {
    expect(
      getPermissions("readonly").canManageFactTableVirtualColumn(unmanaged),
    ).toBe(false);
  });
});
