import { z } from "zod";
import {
  paginationQueryFields,
  skipPaginationQueryField,
  apiPaginationFieldsValidator,
  ignoreWarningsBodyField,
  bypassApprovalPublishBodyField,
  publishBypassedGatesField,
  revisionScheduleResponseFields,
} from "./shared";
import { apiSavedGroupValidator } from "./saved-group";
import {
  jsonPatchOperationValidator,
  reviewDecision,
  revisionStatus,
  activityLogEntryValidator,
  reviewValidator,
} from "./revisions";
import { ownerInputField } from "./owner-field";
import { namedSchema } from "./openapi-helpers";

// ---- Shared param schemas ----

const savedGroupIdParams = z.object({ savedGroupId: z.string() });

/** Version param that also accepts the literal string "new" to auto-create a draft. */
export const savedGroupRevisionVersionParam = z.union([
  z.coerce.number().int(),
  z.literal("new"),
]);

const revisionParams = savedGroupIdParams.extend({
  version: savedGroupRevisionVersionParam,
});

const revisionParamsStrict = savedGroupIdParams.extend({
  version: z.coerce.number().int(),
});

// Optional metadata applied when an endpoint auto-creates a draft via
// `version: "new"`. Ignored when editing an existing revision.
const newDraftMetadataFields = {
  revisionTitle: z.string().optional(),
  revisionComment: z.string().optional(),
};

// ---- Shared response schemas ----

const booleanQueryField = z
  .union([
    z.literal("true"),
    z.literal("false"),
    z.literal("0"),
    z.literal("1"),
    z.boolean(),
  ])
  .optional();

const revisionStatusSchema = z.enum(revisionStatus);

// Combined status filter accepting individual statuses, "open", or comma-separated list
const revisionStatusQuery = z.string().refine(
  (val) => {
    if (!val) return true;
    const allowed = [...revisionStatus, "open"] as const;
    const parts = val
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    return parts.every((p) => (allowed as readonly string[]).includes(p));
  },
  {
    message: `status must be a comma-separated list of: ${[
      ...revisionStatus,
      "open",
    ].join(", ")}`,
  },
);

// API-facing review object — matches Review from shared/enterprise but
// serializes `dateCreated` as an ISO string instead of a `Date`.
const apiReviewValidator = namedSchema(
  "SavedGroupRevisionReview",
  reviewValidator
    .omit({ dateCreated: true })
    .extend({
      dateCreated: z.string().meta({ format: "date-time" }),
    })
    .strict(),
);

// API-facing activity log entry — matches ActivityLogEntry from shared/enterprise.
const apiActivityLogEntryValidator = namedSchema(
  "SavedGroupRevisionActivityLogEntry",
  activityLogEntryValidator
    .omit({ dateCreated: true })
    .extend({
      dateCreated: z.string().meta({ format: "date-time" }),
    })
    .strict(),
);

// API-facing revision projection. Hides the raw `target` shape used internally
// and surfaces the saved-group view directly. Mirrors how feature revisions
// expose their domain model in `apiFeatureRevisionValidator`.
export const apiSavedGroupRevisionValidator = namedSchema(
  "SavedGroupRevision",
  z
    .object({
      id: z.string(),
      version: z.number().int().optional(),
      title: z.string().optional(),
      status: revisionStatusSchema,
      authorId: z.string(),
      authorEmail: z.string().optional(),
      contributors: z.array(z.string()).optional(),
      revertedFrom: z.string().optional(),
      reviews: z.array(apiReviewValidator),
      activityLog: z.array(apiActivityLogEntryValidator),
      // Deferred-publish state, shared across every revisioned entity.
      ...revisionScheduleResponseFields,
      resolution: z
        .object({
          action: z.enum(["merged", "discarded"]),
          userId: z.string(),
          dateCreated: z.string().meta({ format: "date-time" }),
        })
        .strict()
        .optional(),
      dateCreated: z.string().meta({ format: "date-time" }),
      dateUpdated: z.string().meta({ format: "date-time" }),
      // Snapshot of the saved group at the time the revision was created.
      baseSavedGroup: apiSavedGroupValidator,
      // The saved group with this revision's proposed changes applied — i.e.
      // what the saved group would look like if the revision were merged
      // against its current snapshot. Useful for previewing changes without
      // having to interpret the raw JSON Patch ops.
      proposedSavedGroup: apiSavedGroupValidator,
      // Raw JSON Patch ops (RFC 6902). Most callers can ignore this and use
      // `baseSavedGroup` / `proposedSavedGroup`; provided as an escape hatch
      // for callers who want to inspect the deltas directly.
      proposedChanges: z.array(jsonPatchOperationValidator),
    })
    .strict(),
);

export type ApiSavedGroupRevision = z.infer<
  typeof apiSavedGroupRevisionValidator
>;

const revisionResponse = z.object({
  revision: apiSavedGroupRevisionValidator,
});

// Mirrors the shape of `Conflict` returned by checkMergeConflicts in
// shared/src/revisions/helpers.ts. The `*Value` fields are typed as `unknown`
// because conflicts can be on any saved-group field.
const mergeConflictSchema = z
  .object({
    field: z.string(),
    baseValue: z.unknown(),
    liveValue: z.unknown(),
    proposedValue: z.unknown(),
  })
  .strict();

// ---- Read endpoint validators ----

export const listSavedGroupRevisionsValidator = {
  method: "get" as const,
  path: "/saved-groups-revisions",
  operationId: "listSavedGroupRevisions",
  summary: "List saved-group revisions across the organization",
  description:
    "Returns a paginated list of revisions across all saved groups in the organization, sorted newest-first. Optionally filtered by saved group, status, author, or the calling user's involvement.",
  tags: ["saved-group-revisions"],
  paramsSchema: z.never(),
  bodySchema: z.never(),
  querySchema: z
    .object({
      ...paginationQueryFields,
      ...skipPaginationQueryField,
      savedGroupId: z
        .string()
        .optional()
        .describe(
          "Restrict results to revisions for a single saved group. When omitted, returns revisions across every saved group the caller can read.",
        ),
      status: revisionStatusQuery
        .optional()
        .describe(
          "Filter by revision status. Accepts a comma-separated list, or the literal `open` for non-merged/non-discarded revisions.",
        ),
      author: z.string().optional(),
      mine: booleanQueryField.describe(
        "If true, return only revisions authored by the calling user. Requires a user-scoped API key. Mutually exclusive with `author`.",
      ),
    })
    .strict(),
  responseSchema: z
    .object({
      revisions: z.array(apiSavedGroupRevisionValidator),
    })
    .extend(apiPaginationFieldsValidator.shape),
};

export const getSavedGroupRevisionsValidator = {
  method: "get" as const,
  path: "/saved-groups-revisions/:savedGroupId",
  operationId: "getSavedGroupRevisions",
  summary: "List revisions for a saved group",
  description:
    "Returns a paginated list of revisions for this saved group, sorted newest-first. Optionally filtered by status, author, or the calling user's involvement.",
  tags: ["saved-group-revisions"],
  paramsSchema: savedGroupIdParams,
  bodySchema: z.never(),
  querySchema: z
    .object({
      ...paginationQueryFields,
      ...skipPaginationQueryField,
      status: revisionStatusQuery
        .optional()
        .describe(
          "Filter by revision status. Accepts a comma-separated list, or the literal `open` for non-merged/non-discarded revisions.",
        ),
      author: z.string().optional(),
      mine: booleanQueryField.describe(
        "If true, return only revisions authored by the calling user. Requires a user-scoped API key. Mutually exclusive with `author`.",
      ),
    })
    .strict(),
  responseSchema: z
    .object({
      revisions: z.array(apiSavedGroupRevisionValidator),
    })
    .extend(apiPaginationFieldsValidator.shape),
  exampleRequest: { params: { savedGroupId: "grp_abc123" } },
};

export const getSavedGroupRevisionLatestValidator = {
  method: "get" as const,
  path: "/saved-groups-revisions/:savedGroupId/latest",
  operationId: "getSavedGroupRevisionLatest",
  summary: "Get the most recent active draft revision",
  description:
    "Returns the most recently updated open (non-merged, non-discarded) revision for the saved group. Returns 404 if there is no active draft. Pass `mine=true` to restrict to drafts authored by the calling user (requires a user-scoped API key).",
  tags: ["saved-group-revisions"],
  paramsSchema: savedGroupIdParams,
  bodySchema: z.never(),
  querySchema: z
    .object({
      mine: booleanQueryField.describe(
        "If true, return only the most recent active draft authored by the calling user. Requires a user-scoped API key.",
      ),
    })
    .strict(),
  responseSchema: revisionResponse,
  exampleRequest: { params: { savedGroupId: "grp_abc123" } },
};

export const getSavedGroupRevisionValidator = {
  method: "get" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version",
  operationId: "getSavedGroupRevision",
  summary: "Get a single saved group revision",
  description:
    "Returns the revision at the specified version for this saved group. Use `GET /saved-groups-revisions/{savedGroupId}/latest` for the most recent active draft.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z.never(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
  exampleRequest: { params: { savedGroupId: "grp_abc123", version: 3 } },
};

export const getSavedGroupRevisionMergeStatusValidator = {
  method: "get" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/merge-status",
  operationId: "getSavedGroupRevisionMergeStatus",
  summary: "Get merge status for a draft revision",
  description:
    "Runs a dry-run merge of the draft against the current live saved group and returns any conflicts. Use this before publishing to preview changes and detect conflicting edits.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z.never(),
  querySchema: z.never(),
  responseSchema: z
    .object({
      success: z.boolean(),
      hasConflicts: z.boolean(),
      conflicts: z.array(mergeConflictSchema),
      canAutoMerge: z.boolean(),
    })
    .strict(),
};

// ---- Lifecycle endpoint validators ----

export const postSavedGroupRevisionValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId",
  operationId: "postSavedGroupRevision",
  summary: "Create a draft revision",
  description:
    "Creates a new draft revision branched from the current live saved group. A saved group can have multiple concurrent drafts; use this to start an isolated line of edits.",
  tags: ["saved-group-revisions"],
  paramsSchema: savedGroupIdParams,
  bodySchema: z
    .object({
      title: z.string().optional(),
      comment: z.string().optional(),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionDiscardValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/discard",
  operationId: "postSavedGroupRevisionDiscard",
  summary: "Discard a draft revision",
  description:
    "Permanently discards a draft revision. Only open revisions (not merged or already-discarded) can be discarded.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      reason: z.string().optional(),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionPublishValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/publish",
  operationId: "postSavedGroupRevisionPublish",
  summary: "Publish a draft revision",
  description:
    "Publishes the draft and applies its changes to the live Saved Group. The caller needs Publish access in every assigned Project. When approval is required, the draft must be approved unless the caller has Bypass draft approvals access. If the organization requires rebasing, an out-of-date draft must be rebased first; an authorized caller can instead send `ignoreWarnings: true` to force-publish it. A 422 response lists every blocking gate and the available resolution.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      bypassApproval: bypassApprovalPublishBodyField,
      ignoreWarnings: ignoreWarningsBodyField,
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse.extend({
    bypassedGates: publishBypassedGatesField,
  }),
};

export const postSavedGroupRevisionRevertValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/revert",
  operationId: "postSavedGroupRevisionRevert",
  summary: "Revert the saved group to a prior revision",
  description:
    "Creates a new draft (or immediately publishes) whose content matches the specified historical revision. Defaults to creating a draft; when the org enables 'reverts bypass approval' it defaults to publishing immediately. Pass `strategy` to override.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      strategy: z
        .enum(["draft", "publish"])
        .optional()
        .describe(
          "Whether to stage the revert as a draft or publish it immediately. Defaults to `draft`, or to `publish` when the org enables 'reverts bypass approval'.",
        ),
      title: z.string().optional(),
      comment: z.string().optional(),
      // `ignoreWarnings` ALONE on every Saved Group body: the dependents guard
      // soft-warns and asks for this acknowledgment, and a strict body must
      // accept the retry. Saved Groups have no schema or validation hooks, so
      // the other override fields would document no-ops.
      ignoreWarnings: ignoreWarningsBodyField,
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse.extend({
    bypassedGates: publishBypassedGatesField,
  }),
};

export const postSavedGroupRevisionRebaseValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/rebase",
  operationId: "postSavedGroupRevisionRebase",
  summary: "Rebase a draft revision onto the current live saved group",
  description:
    "Updates the draft's base snapshot to the current live state, applying the draft's changes on top. Supply `conflictResolutions` to resolve any conflicting fields. Strategies are `overwrite` (use the draft's value), `discard` (keep the live value), or `union` (merge arrays — use only on `values`). Optimistic locking is not enforced by this endpoint; callers who need strict locking should call `merge-status` before and after.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      conflictResolutions: z
        .record(z.string(), z.enum(["overwrite", "discard", "union"]))
        .optional(),
      customValues: z
        .record(z.string(), z.array(z.unknown()))
        .optional()
        .describe(
          "Custom values to use for `union` strategy fields. Keyed by field name.",
        ),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

// ---- Approval endpoint validators ----

export const postSavedGroupRevisionRequestReviewValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/request-review",
  operationId: "postSavedGroupRevisionRequestReview",
  summary: "Request review for a draft revision",
  description:
    "Moves the draft from `draft` into `pending-review`. Notifies reviewers per the org's approval-flow settings.\n\nSet `autoPublishOnApproval` to `true` to publish the revision automatically the moment it is approved (GitHub auto-merge model). This requires the org to have auto-publish-on-approval enabled and the caller to have publish permission on the saved group; the auto-publish then executes with the caller's authority.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      autoPublishOnApproval: z.boolean().optional(),
      ignoreWarnings: ignoreWarningsBodyField,
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionSubmitReviewValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/submit-review",
  operationId: "postSavedGroupRevisionSubmitReview",
  summary: "Submit a review on a draft revision",
  description:
    "Submits an `approve`, `request-changes`, or `comment` review on the revision. Submitting `approve` or `request-changes` needs Review access. A `comment` is participation rather than a verdict, so it is also open to the Comments permission or draft authority on the entity. Authors and contributors cannot submit `approve` reviews on their own drafts when the org has `blockSelfApproval` enabled.\n\nWhen `decision` is `approve` and the revision has `autoPublishOnApproval` enabled, the revision is automatically published after approval. The response includes `autoPublished: true` when this happens. Pass `skipAutoPublish: true` to approve without triggering auto-publish.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      decision: z.enum(reviewDecision),
      comment: z.string().optional(),
      skipAutoPublish: z.boolean().optional(),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse.extend({
    autoPublished: z.boolean().optional(),
  }),
};

// ---- Field-edit endpoint validators ----

export const putSavedGroupRevisionMetadataValidator = {
  method: "put" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/metadata",
  operationId: "putSavedGroupRevisionMetadata",
  summary: "Update saved group metadata in a draft revision",
  description:
    'Stages metadata changes (name, owner, description, projects) on the draft. Pass `version: "new"` to auto-create a draft. The change is only applied to the live saved group when the revision is merged.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      name: z.string().optional(),
      owner: ownerInputField.optional(),
      description: z.string().optional(),
      projects: z.array(z.string()).optional(),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const putSavedGroupRevisionConditionValidator = {
  method: "put" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/condition",
  operationId: "putSavedGroupRevisionCondition",
  summary: "Update the condition of a condition saved group draft revision",
  description:
    'Stages a new JSON-encoded condition for the draft. Only valid for `condition` saved groups. Pass `version: "new"` to auto-create a draft.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      condition: z
        .string()
        .describe("The JSON-encoded condition for the saved group"),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const putSavedGroupRevisionValuesValidator = {
  method: "put" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/values",
  operationId: "putSavedGroupRevisionValues",
  summary: "Replace the values list in a list saved group draft revision",
  description:
    'Replaces the entire `values` array atomically. Only valid for `list` saved groups. For safe concurrent updates against a draft, prefer `POST .../items/add` and `POST .../items/remove`. Pass `version: "new"` to auto-create a draft.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      values: z.array(z.string()),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const putSavedGroupRevisionArchiveValidator = {
  method: "put" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/archive",
  operationId: "putSavedGroupRevisionArchive",
  summary: "Stage an archive/unarchive in a draft revision",
  description:
    'Stages an archive or unarchive on the draft. Pass `version: "new"` to auto-create a draft. Archived saved groups can be permanently deleted via `DELETE /saved-groups/{id}` once the archive is published.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      archived: z.boolean(),
      ignoreWarnings: ignoreWarningsBodyField,
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionItemsAddValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/items/add",
  operationId: "postSavedGroupRevisionItemsAdd",
  summary: "Append items to a list saved group draft revision",
  description:
    'Appends the provided items (deduplicated) to the draft\'s `values` array. Only valid for `list` saved groups. Pass `version: "new"` to auto-create a draft. Duplicate items are merged on top of any existing draft, so multiple successive add/remove calls accumulate.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      items: z.array(z.string()),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionItemsRemoveValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/items/remove",
  operationId: "postSavedGroupRevisionItemsRemove",
  summary: "Remove items from a list saved group draft revision",
  description:
    'Removes the provided items from the draft\'s `values` array. Only valid for `list` saved groups. Pass `version: "new"` to auto-create a draft.',
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParams,
  bodySchema: z
    .object({
      ...newDraftMetadataFields,
      items: z.array(z.string()),
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

// ---- Exported types for use in back-end handlers ----

export type SavedGroupRevisionApiShape = ApiSavedGroupRevision;
export type SavedGroupRevisionMetadataBody = z.infer<
  typeof putSavedGroupRevisionMetadataValidator.bodySchema
>;
export type SavedGroupRevisionConditionBody = z.infer<
  typeof putSavedGroupRevisionConditionValidator.bodySchema
>;
export type SavedGroupRevisionValuesBody = z.infer<
  typeof putSavedGroupRevisionValuesValidator.bodySchema
>;
export type SavedGroupRevisionArchiveBody = z.infer<
  typeof putSavedGroupRevisionArchiveValidator.bodySchema
>;
export type SavedGroupRevisionItemsBody = z.infer<
  typeof postSavedGroupRevisionItemsAddValidator.bodySchema
>;

export const postSavedGroupRevisionSchedulePublishValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/schedule-publish",
  operationId: "postSavedGroupRevisionSchedulePublish",
  summary: "Schedule (or cancel) a deferred publish",
  description:
    "Arms a revision to publish automatically at a future time. Pass `scheduledPublishAt` as an RFC3339 timestamp in the future to arm, or `null` to cancel a pending schedule. Requires the `scheduled-revisions` commercial feature and publish permission on the Saved Group. A draft that still requires approval must request review first (or be armed with `bypassApproval` by a caller who can bypass).",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z
    .object({
      // Accept RFC3339 numeric offsets for backward compatibility.
      scheduledPublishAt: z
        .union([z.iso.datetime({ offset: true }), z.null()])
        .describe(
          "When to publish, as an RFC3339 timestamp (e.g. `2026-01-31T09:00:00Z` or `2026-01-31T02:00:00-07:00`), or `null` to cancel a pending schedule.",
        ),
      lockEdits: z.boolean().optional(),
      lockOthers: z.boolean().optional(),
      bypassApproval: z.boolean().optional(),
      ignoreWarnings: ignoreWarningsBodyField,
    })
    .strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionReopenValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/reopen",
  operationId: "postSavedGroupRevisionReopen",
  summary: "Reopen a discarded revision",
  description:
    "Returns a previously discarded revision to `draft` status so it can be edited and published again. Only discarded revisions can be reopened.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z.object({}).strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionRecallReviewValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/recall-review",
  operationId: "postSavedGroupRevisionRecallReview",
  summary: "Recall a review request",
  description:
    "Pulls a revision in review (`pending-review`, `changes-requested`, or `approved`) back to `draft`, clearing existing reviews and disarming any auto-publish-on-approval.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z.object({}).strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};

export const postSavedGroupRevisionUndoReviewValidator = {
  method: "post" as const,
  path: "/saved-groups-revisions/:savedGroupId/:version/undo-review",
  operationId: "postSavedGroupRevisionUndoReview",
  summary: "Retract your own review verdict",
  description:
    "Retracts the calling user's own active `approve` or `request-changes` verdict, returning the revision to `pending-review`. Review comments stay in the log. Retracting a `request-changes` can leave the revision approved by someone else, in which case an armed auto-publish fires.",
  tags: ["saved-group-revisions"],
  paramsSchema: revisionParamsStrict,
  bodySchema: z.object({}).strict(),
  querySchema: z.never(),
  responseSchema: revisionResponse,
};
