import { FactMetricType } from "shared/types/fact-table";
import { EntityEvents } from "shared/types/audit";
import {
  ApprovalFlowConfigurations,
  LearningStatus,
} from "shared/types/organization";

// The object property that carries a JSON constant's `$extends` reference list.
// Single source of truth shared by the resolver (sdk-versioning/resolveConstants)
// and the reference detector (validators/constant) so they can't drift.
export const CONSTANT_EXTENDS_KEY = "$extends";

export const GB_SDK_ID_DEV = "sdk-UmQ03OkUDAu7Aox";
export const GB_SDK_ID_PROD = "sdk-ueFMOgZ2daLa0M";

export const DEFAULT_STATS_ENGINE = "bayesian" as const;
export const DEFAULT_METRIC_HISTOGRAM_BINS = 25;
export const DEFAULT_CONFIDENCE_LEVEL = 0.95;
export const DEFAULT_P_VALUE_THRESHOLD = 0.05;
export const DEFAULT_P_VALUE_CORRECTION = null;
export const DEFAULT_P_VALUE_THRESHOLD_FOR_COVARIATE_IMBALANCE = 0.001;
export const DEFAULT_GUARDRAIL_ALPHA = 0.05; //used for early stopping for safe
// Metric defaults
export const DEFAULT_METRIC_WINDOW = "conversion";
export const DEFAULT_FACT_METRIC_WINDOW = "";
export const DEFAULT_METRIC_WINDOW_DELAY_HOURS = 0;
export const DEFAULT_METRIC_WINDOW_HOURS = 72;
export const DEFAULT_METRIC_CAPPING = "";
export const DEFAULT_METRIC_CAPPING_VALUE = 0;
export const DEFAULT_WIN_RISK_THRESHOLD = 0.0025;
export const DEFAULT_LOSE_RISK_THRESHOLD = 0.0125;
export const DEFAULT_MAX_METRIC_SLICE_LEVELS = 20;

// Bayesian prior
export const DEFAULT_PROPER_PRIOR_STDDEV = 0.3;

export const DEFAULT_MAX_PERCENT_CHANGE = 0.5;
export const DEFAULT_MIN_PERCENT_CHANGE = 0.005;
export const DEFAULT_MIN_SAMPLE_SIZE = 150;
export const DEFAULT_TARGET_MDE = 0.1;

// Regression Adjustment (CUPED):
export const DEFAULT_REGRESSION_ADJUSTMENT_ENABLED = false;
export const DEFAULT_REGRESSION_ADJUSTMENT_DAYS = 14;

// Sequential Testing:
export const DEFAULT_SEQUENTIAL_TESTING_ENABLED = false;
export const DEFAULT_SEQUENTIAL_TESTING_TUNING_PARAMETER = 5000;

// Post-Stratification:
export const DEFAULT_POST_STRATIFICATION_ENABLED = true;

// Lookback Override:
export const DEFAULT_LOOKBACK_OVERRIDE_VALUE_UNIT = "days";
export const DEFAULT_LOOKBACK_OVERRIDE_VALUE_DAYS = 14;
export const DEFAULT_TOP_VALUES_LOOKBACK_VALUE = 14;
export const DEFAULT_TOP_VALUES_LOOKBACK_UNIT = "days";

// Query settings
export const DEFAULT_TEST_QUERY_DAYS = 30;
export const DEFAULT_USE_STICKY_BUCKETING = false;

// Dimension name constants:
export const EXPOSURE_DATE_DIMENSION_NAME = "dim_exposure_date";
export const BANDIT_SRM_DIMENSION_NAME = "gb_internal_bandit_srm";

/** SQL column prefix for contextual bandit attributes after bucketing. */
export const ATTR_CB_PREFIX = "attr_cb_";
/** SQL column prefix for first-exposure raw contextual bandit attributes (pre-bucketing). */
export const ATTR_CB_RAW_PREFIX = "attr_cb_raw_";
/** Bucket value for low-traffic / merged contextual bandit attribute slices. */
export const CONTEXTUAL_BANDIT_COMBINED_ATTRIBUTE_VALUE = "Combined";
export const AUTOMATIC_DIMENSION_OTHER_NAME = "__Other__";
export const NULL_ATTRIBUTE_VALUE = "__NULL_ATTRIBUTE";
export const NULL_DIMENSION_VALUE = "__NULL_DIMENSION";
export const NULL_VARIATION_VALUE = "__NULL_VARIATION";
export const NULL_DIMENSION_DISPLAY = "NULL (unset)";
export const PRECOMPUTED_DIMENSION_PREFIX = "precomputed:";
export const MAX_PRECOMPUTED_UNIT_DIMENSIONS = 3;

// Max length for entity description fields (features, experiments, metrics, etc.)
export const MAX_DESCRIPTION_LENGTH = 10000;
// Colors:
// export const variant_null = "#999";
// export const variant_0 = "#4f69ff";
// export const variant_1 = "#03d1ca";
// export const variant_2 = "#fd7e14";
// export const variant_3 = "#e83e8c";

export const GROWTHBOOK_SECURE_ATTRIBUTE_SALT = "eg8amUur5GunJXCfgjwB";

export const OWNER_JOB_TITLES = {
  engineer: "Engineer",
  dataScientist: "Data & Analytics",
  projectManager: "PM",
  marketer: "Marketer",
  designer: "Designer",
  other: "Other",
} as const;

export const USAGE_INTENTS = {
  featureFlags: "Feature Flags",
  experiments: "Experiments",
  productAnalytics: "Product Analytics",
} as const;

// Health
export const DEFAULT_MULTIPLE_EXPOSURES_ENOUGH_DATA_THRESHOLD = 10;
export const DEFAULT_MULTIPLE_EXPOSURES_THRESHOLD = 0.01;

export const DEFAULT_SRM_MINIMINUM_COUNT_PER_VARIATION = 8;
export const DEFAULT_SRM_BANDIT_MINIMINUM_COUNT_PER_VARIATION = 5;
export const DEFAULT_SRM_THRESHOLD = 0.001;

export const DEFAULT_DECISION_FRAMEWORK_ENABLED = false;

// Default statuses for saved learnings (insights). Orgs can customize the
// list in General Settings → Experiment Settings. Status IDs are persisted
// on each saved learning, so they must remain stable across renames.
export const DEFAULT_LEARNING_STATUSES: LearningStatus[] = [
  { id: "emerging", label: "Emerging", color: "blue" },
  { id: "supported", label: "Supported", color: "amber" },
  { id: "confirmed", label: "Confirmed", color: "green" },
  { id: "rejected", label: "Rejected", color: "red" },
];

// Power
export const DEFAULT_EXPERIMENT_MIN_LENGTH_DAYS = 3;
export const DEFAULT_EXPERIMENT_MAX_LENGTH_DAYS = undefined; // undefined means no limit
export const FALLBACK_EXPERIMENT_MAX_LENGTH_DAYS = 180;

// Safe Rollout
export const SAFE_ROLLOUT_TRACKING_KEY_PREFIX = "srk_";

export const DEFAULT_REQUIRE_PROJECT_FOR_FEATURES = false;
export const DEFAULT_REQUIRE_PROJECT_FOR_SDK_CONNECTIONS = false;

export const DEFAULT_REVISION_CONFIGURATION: ApprovalFlowConfigurations = {
  savedGroups: [
    {
      required: false,
      requireMetadataReview: true,
    },
  ],
};

// Default configuration for Safe Rollout
export const SAFE_ROLLOUT_VARIATIONS = [
  {
    id: "0",
    name: "Control",
    weight: 0.5,
    index: 0,
  },
  {
    id: "1",
    name: "Rollout Value",
    weight: 0.5,
    index: 1,
  },
];

export const UNSUPPORTED_METRIC_EXPLORER_TYPES: readonly FactMetricType[] = [
  "quantile",
  "funnel",
] as const;

export const MANAGED_WAREHOUSE_EVENTS_FACT_TABLE_ID = "ch_events";

export const sdkLanguages = [
  "nocode-webflow",
  "nocode-wordpress",
  "nocode-shopify",
  "nocode-other",
  "javascript",
  "nodejs",
  "nextjs",
  "react",
  "php",
  "ruby",
  "python",
  "go",
  "java",
  "csharp",
  "android",
  "ios",
  "flutter",
  "elixir",
  "edge-cloudflare",
  "edge-fastly",
  "edge-lambda",
  "edge-other",
  "rust",
  "roku",
  "other",
] as const;

export const statsEngines = ["bayesian", "frequentist"] as const;

export const attributeDataTypes = [
  "boolean",
  "string",
  "number",
  "secureString",
  "enum",
  "string[]",
  "number[]",
  "secureString[]",
] as const;

// Runtime allow-list for discussion parents. Kept here (rather than only as a
// type) so request handlers can validate an incoming parentType.
export const DISCUSSION_PARENT_TYPES = [
  "experiment",
  "idea",
  "metric",
  "feature",
  "learning",
] as const;

// for audits
export const entityEvents = {
  agreement: ["create", "update", "delete"],
  approvalFlow: ["create", "update", "delete"],
  revision: ["create", "update", "delete"],
  aiPrompt: ["create", "update", "delete"],
  aiCredential: ["create", "update", "delete"],
  attribute: ["create", "update", "delete"],
  experiment: [
    "create",
    "update",
    "start",
    "phase",
    "phase",
    "stop",
    "status",
    "archive",
    "unarchive",
    "delete",
    "results",
    "analysis",
    "screenshot",
    "screenshot",
    "refresh",
    "launchChecklist.updated",
    "phase.delete",
    "screenshot.delete",
    "screenshot.create",
  ],
  project: ["create", "update", "delete"],
  environment: ["create", "update", "delete"],
  feature: [
    "create",
    // "revision.publish" and "revision.revert" are intentionally absent here:
    // those lifecycle actions reuse the top-level "feature.publish" / "feature.revert"
    // audit events below rather than emitting a separate revision.* entry.
    "publish",
    "revert",
    "update",
    "toggle",
    "archive",
    "delete",
    "revision.create",
    "revision.update",
    "revision.requestReview",
    "revision.approve",
    "revision.requestChanges",
    "revision.comment",
    "revision.discard",
    "revision.reopen",
    "revision.rebase",
  ],
  featureRevisionLog: ["create", "update", "delete"],
  urlRedirect: ["create", "update", "delete"],
  metric: ["autocreate", "create", "update", "delete", "analysis"],
  metricAnalysis: ["create", "update", "delete"],
  metricGroup: ["create", "delete", "update"],
  populationData: ["create", "delete", "update"],
  datasource: ["create", "update", "delete", "import"],
  comment: ["create", "update", "delete"],
  "sdk-connection": ["create", "update", "delete"],
  user: ["create", "update", "delete", "invite"],
  organization: ["create", "update", "delete", "disable", "enable"],
  apiKey: ["create", "update", "delete", "disable", "enable"],
  oauthAuthCode: ["create", "update", "delete"],
  oauthGrant: ["create", "update", "delete"],
  oauthRefreshToken: ["create", "update", "delete"],
  installation: ["update"],
  savedGroup: ["created", "deleted", "updated"],
  constant: ["created", "updated", "deleted"],
  config: ["created", "updated", "deleted"],
  segment: ["create", "delete", "update"],
  archetype: ["created", "deleted", "updated"],
  team: ["create", "delete", "update"],
  vercelNativeIntegration: ["create", "update", "delete"],
  factTable: ["autocreate", "create", "update", "delete"],
  customField: ["create", "update", "delete"],
  experimentTemplate: ["create", "update", "delete"],
  safeRollout: ["create", "update", "delete"],
  decisionCriteria: ["create", "update", "delete"],
  execReport: ["create", "update", "delete"],
  holdout: ["create", "update", "delete"],
  savedQuery: ["create", "update", "delete"],
  dashboard: ["create", "update", "delete"],
  dashboardTemplate: ["create", "update", "delete"],
  incrementalRefresh: ["create", "update", "delete"],
  vector: ["create", "update", "delete"],
  customHook: ["create", "update", "delete", "revert"],
  ssoConnection: ["create", "update", "delete"],
  sqlResultChunk: ["create", "update", "delete"],
  rampSchedule: [
    "create",
    "update",
    "delete",
    "step-approved",
    "approval-bypassed",
    "start-approved",
  ],
  rampScheduleTemplate: ["create", "update", "delete"],
  learning: ["create", "update", "delete"],
  contextualBandit: ["create", "update", "delete", "start", "stop"],
  eventForwarderConfig: ["create", "update", "delete", "teardownFailure"],
} as const;

export const entityTypes = Object.keys(entityEvents) as [keyof EntityEvents];

export const WEBHOOK_CONSECUTIVE_FAILURES_THRESHOLD = 10;
