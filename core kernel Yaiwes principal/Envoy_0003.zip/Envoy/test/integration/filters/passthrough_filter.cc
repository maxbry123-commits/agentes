#include "envoy/registry/registry.h"
#include "envoy/server/filter_config.h"

#include "source/extensions/filters/http/common/pass_through_filter.h"

#include "test/extensions/filters/http/common/empty_http_filter_config.h"
#include "test/integration/filters/common.h"
#include "test/integration/filters/test_filters.pb.h"

namespace Envoy {

// Registers the passthrough filter for use in test.
class TestPassThroughFilter : public Http::PassThroughFilter {
public:
  constexpr static char name[] = "passthrough-filter";
};

constexpr char TestPassThroughFilter::name[];
static Registry::RegisterFactory<
    UniqueSimpleFilterConfig<TestPassThroughFilter,
                             test::integration::filters::PassthroughFilterConfig>,
    Server::Configuration::NamedHttpFilterConfigFactory>
    register_;
static Registry::RegisterFactory<
    UniqueSimpleFilterConfig<TestPassThroughFilter,
                             test::integration::filters::PassthroughFilterConfig>,
    Server::Configuration::UpstreamHttpFilterConfigFactory>
    register_upstream_;

} // namespace Envoy
