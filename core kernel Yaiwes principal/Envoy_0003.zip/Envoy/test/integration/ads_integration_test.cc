#include "envoy/config/bootstrap/v3/bootstrap.pb.h"
#include "envoy/config/cluster/v3/cluster.pb.h"
#include "envoy/config/core/v3/base.pb.h"
#include "envoy/config/endpoint/v3/endpoint.pb.h"
#include "envoy/config/listener/v3/listener.pb.h"
#include "envoy/config/route/v3/route.pb.h"
#include "envoy/config/route/v3/route_components.pb.h"
#include "envoy/grpc/status.h"

#include "source/common/config/protobuf_link_hacks.h"
#include "source/common/protobuf/protobuf.h"
#include "source/common/protobuf/utility.h"
#include "source/common/tls/server_context_config_impl.h"
#include "source/common/tls/server_ssl_socket.h"
#include "source/common/version/version.h"

#include "test/common/grpc/grpc_client_integration.h"
#include "test/config/v2_link_hacks.h"
#include "test/integration/ads_integration.h"
#include "test/integration/http_integration.h"
#include "test/integration/utility.h"
#include "test/test_common/network_utility.h"
#include "test/test_common/resources.h"
#include "test/test_common/utility.h"

#include "gtest/gtest.h"

using testing::AssertionResult;
using testing::Eq;
using testing::Ge;

namespace Envoy {

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsIntegrationTest,
                         ADS_INTEGRATION_PARAMS, AdsIntegrationTest::protocolTestParamsToString);

// Validate basic config delivery and upgrade.
TEST_P(AdsIntegrationTest, Basic) {
  initialize();
  testBasicFlow();
}

// Basic CDS/EDS update that warms and makes active a single cluster.
TEST_P(AdsIntegrationTest, BasicClusterInitialWarming) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url, {buildCluster("cluster_0")}, {buildCluster("cluster_0")}, {}, "1");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(1));
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(0));
}

// Basic CDS/EDS update that warms and makes active a single cluster.
TEST_P(AdsIntegrationTest, BasicClusterInitialWarmingWithResourceWrapper) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url, {buildCluster("cluster_0")}, {buildCluster("cluster_0")}, {}, "1",
      {{"test", Protobuf::Any()}});
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(1));
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1", {{"test", Protobuf::Any()}});

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(0));
}

// Tests that the Envoy xDS client can handle updates to a subset of the subscribed resources from
// an xDS server without removing the resources not included in the DiscoveryResponse from the xDS
// server.
TEST_P(AdsIntegrationTest, UpdateToSubsetOfResources) {
  initialize();
  registerTestServerPorts({});
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();

  auto cluster_0 = buildCluster("cluster_0");
  auto cluster_1 = buildCluster("cluster_1");
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {cluster_0, cluster_1},
                                                             {cluster_0, cluster_1}, {}, "1");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(2));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(1));
  test_server_->waitForGauge("cluster.cluster_1.warming_state", Eq(1));
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {cluster_0.name(), cluster_1.name()},
                                      {cluster_0.name(), cluster_1.name()}, {}));
  auto cla_0 = buildClusterLoadAssignment(cluster_0.name());
  auto cla_1 = buildClusterLoadAssignment(cluster_1.name());
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {cla_0, cla_1}, {cla_0, cla_1}, {}, "1");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(4));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(0));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(0));

  // Send an update for one of the ClusterLoadAssignments only.
  cla_0.mutable_endpoints(0)->mutable_lb_endpoints(0)->mutable_load_balancing_weight()->set_value(
      2);
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(eds_type_url, {cla_0},
                                                                            {cla_0}, {}, "2");

  // Verify that getting an update for only one of the ClusterLoadAssignment resources does not
  // delete the other. We use cluster membership health as a proxy for this.
  test_server_->waitForCounter("cluster.cluster_0.update_success", Eq(2));
  test_server_->waitForCounter("cluster.cluster_1.update_success", Eq(1));
  test_server_->waitForGauge("cluster.cluster_0.membership_healthy", Eq(1));
  test_server_->waitForGauge("cluster.cluster_1.membership_healthy", Eq(1));
}

// Update the only warming cluster. Verify that the new cluster is still warming and the cluster
// manager as a whole is not initialized.
TEST_P(AdsIntegrationTest, ClusterInitializationUpdateTheOnlyWarmingCluster) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url, {buildCluster("cluster_0")}, {buildCluster("cluster_0")}, {}, "1");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));
  // Update lb policy to MAGLEV so that cluster update is not skipped due to the same hash.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url, {buildCluster("cluster_0", envoy::config::cluster::v3::Cluster::MAGLEV)},
      {buildCluster("cluster_0", envoy::config::cluster::v3::Cluster::MAGLEV)}, {}, "2");
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));
}

// Primary cluster is warming during cluster initialization. Update the cluster with immediate ready
// config and verify that all the clusters are initialized.
TEST_P(AdsIntegrationTest, TestPrimaryClusterWarmClusterInitialization) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  auto loopback = Network::Test::getLoopbackAddressString(ipVersion());
  addFakeUpstream(Http::CodecType::HTTP2);
  auto port = fake_upstreams_.back()->localAddress()->ip()->port();

  // This cluster will be blocked since endpoint name cannot be resolved.
  auto warming_cluster = ConfigHelper::buildStaticCluster("fake_cluster", port, loopback);
  // Below endpoint accepts request but never return. The health check hangs 1 hour which covers the
  // test running.
  auto blocking_health_check = TestUtility::parseYaml<envoy::config::core::v3::HealthCheck>(R"EOF(
      timeout: 3600s
      interval: 3600s
      unhealthy_threshold: 2
      healthy_threshold: 2
      tcp_health_check:
        send:
          text: '01'
        receive:
          - text: '02'
          )EOF");
  *warming_cluster.add_health_checks() = blocking_health_check;

  // Active cluster has the same name with warming cluster but has no blocking health check.
  auto active_cluster = ConfigHelper::buildStaticCluster("fake_cluster", port, loopback);

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {warming_cluster},
                                                             {warming_cluster}, {}, "1");

  FakeRawConnectionPtr fake_upstream_connection;
  ASSERT_TRUE(fake_upstreams_.back()->waitForRawConnection(fake_upstream_connection));

  // fake_cluster is in warming.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Ge(1));

  // Now replace the warming cluster by the config which will turn ready immediately.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {active_cluster},
                                                             {active_cluster}, {}, "2");

  // All clusters are ready.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));
}

// Two cluster warming, update one of them. Verify that the clusters are eventually initialized.
TEST_P(AdsIntegrationTest, ClusterInitializationUpdateOneOfThe2Warming) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url,
      {ConfigHelper::buildStaticCluster("primary_cluster", 8000, "127.0.0.1"),
       buildCluster("cluster_0"), buildCluster("cluster_1")},
      {ConfigHelper::buildStaticCluster("primary_cluster", 8000, "127.0.0.1"),
       buildCluster("cluster_0"), buildCluster("cluster_1")},
      {}, "1");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(2));

  // Update lb policy to MAGLEV so that cluster update is not skipped due to the same hash.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      cds_type_url,
      {ConfigHelper::buildStaticCluster("primary_cluster", 8000, "127.0.0.1"),
       buildCluster("cluster_0", envoy::config::cluster::v3::Cluster::MAGLEV),
       buildCluster("cluster_1")},
      {ConfigHelper::buildStaticCluster("primary_cluster", 8000, "127.0.0.1"),
       buildCluster("cluster_0", envoy::config::cluster::v3::Cluster::MAGLEV),
       buildCluster("cluster_1")},
      {}, "2");
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {"cluster_0", "cluster_1"},
                                      {"cluster_0", "cluster_1"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url,
      {buildClusterLoadAssignment("cluster_0"), buildClusterLoadAssignment("cluster_1")},
      {buildClusterLoadAssignment("cluster_0"), buildClusterLoadAssignment("cluster_1")}, {}, "1");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(4));
}

// Verify that Delta SDS Removals don't result in a NACK.
TEST_P(AdsIntegrationTest, DeltaSdsRemovals) {
  // SOTW delivery doesn't track individual resources, so only
  // run this test for delta xDS.
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Delta &&
      sotw_or_delta_ != Grpc::SotwOrDelta::UnifiedDelta) {
    GTEST_SKIP_("This test is for delta only");
  }
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto sds_type_url =
      Config::getTypeUrl<envoy::extensions::transport_sockets::tls::v3::Secret>();
  const auto lds_type_url = Config::getTypeUrl<envoy::config::listener::v3::Listener>();

  // First get the cluster sent to the test proxy
  envoy::config::core::v3::TransportSocket sds_transport_socket;
  TestUtility::loadFromYaml(R"EOF(
      name: envoy.transport_sockets.tls
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext
        common_tls_context:
          validation_context_sds_secret_config:
            name: validation_context
            sds_config:
              initial_fetch_timeout: 5s
              ads: {}
  )EOF",
                            sds_transport_socket);
  auto cluster = ConfigHelper::buildStaticCluster("cluster", 8000, "127.0.0.1");
  *cluster.mutable_transport_socket() = sds_transport_socket;
  cluster.set_name("cluster_0");

  // Initial * Delta ADS subscription.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(cds_type_url, {}, {}));
  sendDeltaDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {cluster}, {}, "1");

  // The cluster needs this secret, so it's going to request it.
  EXPECT_TRUE(
      compareDeltaDiscoveryRequest(sds_type_url, {"validation_context"}, {}, {}, {}, false));

  // Cluster should start off warming as the secret is being requested.
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(1));

  // Ack the original CDS sub.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(cds_type_url, {}, {}, {}, {}, false));

  // Before we send the secret, we'll send a delta removal to make sure we don't get a NACK.
  sendDeltaDiscoveryResponse<envoy::extensions::transport_sockets::tls::v3::Secret>(
      sds_type_url, {}, {"validation_context"}, "1");

  // The cluster shouldn't be warming anymore since the server signaled
  // that the requested resource doesn't exist.
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(0));

  // Ack the original LDS subscription.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(lds_type_url, {}, {}, {}, {}, false));

  // Ack the removal itself.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(sds_type_url, {}, {}, {}, {}, false));

  envoy::extensions::transport_sockets::tls::v3::Secret validation_context;
  TestUtility::loadFromYaml(fmt::format(R"EOF(
    name: validation_context
    validation_context:
      trusted_ca:
        filename: {}
  )EOF",
                                        TestEnvironment::runfilesPath(
                                            "test/config/integration/certs/upstreamcacert.pem")),
                            validation_context);

  // Now actually send the secret.
  sendDeltaDiscoveryResponse<envoy::extensions::transport_sockets::tls::v3::Secret>(
      sds_type_url, {validation_context}, {}, "2");

  // Ack the secret we just sent.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(sds_type_url, {}, {}, {}, {}, false));

  // Remove the cluster that owns the secret.
  sendDeltaDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {"cluster_0"},
                                                                  "1");
  // Follow that up with a secret removal.
  sendDeltaDiscoveryResponse<envoy::extensions::transport_sockets::tls::v3::Secret>(
      sds_type_url, {}, {"validation_context"}, "3");
  test_server_->waitForCounter("cluster_manager.cluster_removed", Eq(1));
  // Ack the CDS removal.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(cds_type_url, {}, {}, {}, {}, false));
  // Should be an ACK, not a NACK since the SDS removal is ignored.
  EXPECT_TRUE(compareDeltaDiscoveryRequest(sds_type_url, {}, {}, {}, {}, false));
}

// Make sure two clusters sharing same secret are both kept warming before secret
// arrives. Verify that the clusters are eventually initialized.
// This is a regression test of #11120.
TEST_P(AdsIntegrationTest, ClusterSharingSecretWarming) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto sds_type_url =
      Config::getTypeUrl<envoy::extensions::transport_sockets::tls::v3::Secret>();

  envoy::config::core::v3::TransportSocket sds_transport_socket;
  TestUtility::loadFromYaml(R"EOF(
      name: envoy.transport_sockets.tls
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext
        common_tls_context:
          validation_context_sds_secret_config:
            name: validation_context
            sds_config:
              ads: {}
  )EOF",
                            sds_transport_socket);
  auto cluster_template = ConfigHelper::buildStaticCluster("cluster", 8000, "127.0.0.1");
  *cluster_template.mutable_transport_socket() = sds_transport_socket;

  auto cluster_0 = cluster_template;
  cluster_0.set_name("cluster_0");
  auto cluster_1 = cluster_template;
  cluster_1.set_name("cluster_1");

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {cluster_0, cluster_1},
                                                             {cluster_0, cluster_1}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(sds_type_url, "", {"validation_context"},
                                      {"validation_context"}, {}));
  test_server_->waitForGauge("cluster_manager.warming_clusters", Ge(2));
  test_server_->waitForGauge("cluster.cluster_0.warming_state", Eq(1));
  test_server_->waitForGauge("cluster.cluster_1.warming_state", Eq(1));

  envoy::extensions::transport_sockets::tls::v3::Secret validation_context;
  TestUtility::loadFromYaml(fmt::format(R"EOF(
    name: validation_context
    validation_context:
      trusted_ca:
        filename: {}
  )EOF",
                                        TestEnvironment::runfilesPath(
                                            "test/config/integration/certs/upstreamcacert.pem")),
                            validation_context);

  sendDiscoveryResponse<envoy::extensions::transport_sockets::tls::v3::Secret>(
      sds_type_url, {validation_context}, {validation_context}, {}, "1");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
}

// Make sure two clusters with different secrets send only a single SDS request.
// This is a regression test of #21518.
TEST_P(AdsIntegrationTest, SecretsPausedDuringCDS) {
  initialize();
  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto sds_type_url =
      Config::getTypeUrl<envoy::extensions::transport_sockets::tls::v3::Secret>();

  std::vector<envoy::config::cluster::v3::Cluster> clusters;
  for (int i = 0; i < 2; ++i) {
    envoy::config::core::v3::TransportSocket sds_transport_socket;
    TestUtility::loadFromYaml(fmt::format(R"EOF(
        name: envoy.transport_sockets.tls
        typed_config:
          "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.UpstreamTlsContext
          common_tls_context:
            validation_context_sds_secret_config:
              name: validation_context_{}
              sds_config:
                ads: {{}}
    )EOF",
                                          i),
                              sds_transport_socket);
    auto cluster = ConfigHelper::buildStaticCluster("cluster", 8000, "127.0.0.1");
    cluster.set_name(absl::StrCat("cluster_", i));
    *cluster.mutable_transport_socket() = sds_transport_socket;
    clusters.push_back(std::move(cluster));
  }

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, clusters, clusters, {},
                                                             "1");

  // Expect a single request containing the 2 SDS resources.
  EXPECT_TRUE(compareDiscoveryRequest(sds_type_url, "",
                                      {"validation_context_0", "validation_context_1"},
                                      {"validation_context_0", "validation_context_1"}, {}));
  test_server_->waitForGauge("cluster_manager.warming_clusters", Ge(2));

  std::vector<envoy::extensions::transport_sockets::tls::v3::Secret> validation_contexts;
  for (int i = 0; i < 2; ++i) {
    envoy::extensions::transport_sockets::tls::v3::Secret validation_context;
    TestUtility::loadFromYaml(
        fmt::format(
            R"EOF(
      name: validation_context_{}
      validation_context:
        trusted_ca:
          filename: {}
    )EOF",
            i, TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcacert.pem")),
        validation_context);
    validation_contexts.push_back(std::move(validation_context));
  }

  sendDiscoveryResponse<envoy::extensions::transport_sockets::tls::v3::Secret>(
      sds_type_url, validation_contexts, validation_contexts, {}, "1");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
}

// Validate basic config delivery and upgrade with RateLimiting.
TEST_P(AdsIntegrationTest, BasicWithRateLimiting) {
  initializeAds(true);
  testBasicFlow();
}

// Validate that we can recover from failures.
TEST_P(AdsIntegrationTest, Failure) {
  initialize();

  // Send initial configuration, failing each xDS once (via a type mismatch), validate we can
  // process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().Cluster, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, false,
                                      Grpc::Status::WellKnownGrpcStatus::Internal,
                                      fmt::format("does not match the message-wide type URL {}",
                                                  Config::TestTypeUrl::get().Cluster)));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildCluster("cluster_0")},
      {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {"cluster_0"},
                              {}, {}, false, Grpc::Status::WellKnownGrpcStatus::Internal,
                              fmt::format("does not match the message-wide type URL {}",
                                          Config::TestTypeUrl::get().ClusterLoadAssignment)));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().Listener, {buildRouteConfig("listener_0", "route_config_0")},
      {buildRouteConfig("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}, false,
                                      Grpc::Status::WellKnownGrpcStatus::Internal,
                                      fmt::format("does not match the message-wide type URL {}",
                                                  Config::TestTypeUrl::get().Listener)));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().RouteConfiguration, {buildListener("route_config_0", "cluster_0")},
      {buildListener("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {}, {}, false,
                                      Grpc::Status::WellKnownGrpcStatus::Internal,
                                      fmt::format("does not match the message-wide type URL {}",
                                                  Config::TestTypeUrl::get().RouteConfiguration)));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));

  makeSingleRequest();
}

// Regression test for https://github.com/envoyproxy/envoy/issues/9682.
TEST_P(AdsIntegrationTest, ResendNodeOnStreamReset) {
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  // A second CDS request should be sent so that the node is cleared in the cached request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  xds_stream_->finishGrpcStream(Grpc::Status::Internal);
  AssertionResult result = xds_connection_->waitForNewStream(*dispatcher_, xds_stream_);
  RELEASE_ASSERT(result, result.message());
  xds_stream_->startGrpcStream();

  // In SotW cluster_0 will be in the resource_names, but in delta-xDS
  // resource_names_subscribe and resource_names_unsubscribe must be empty for
  // a wildcard request (cluster_0 will appear in initial_resource_versions).
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {"cluster_0"}, {},
                                      {}, true));
}

// Verifies that upon stream reconnection:
// - Non-wildcard requests contain all known resources.
// - Wildcard requests contain all known resources in SotW, but no resources in delta-xDS.
// Regression test for https://github.com/envoyproxy/envoy/issues/16063.
TEST_P(AdsIntegrationTest, ResourceNamesOnStreamReset) {
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  // A second CDS request should be sent so that the node is cleared in the cached request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  // The LDS request, which returns no resources in the DiscoveryResponse.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(Config::TestTypeUrl::get().Listener,
                                                               {}, {}, {}, "1");

  xds_stream_->finishGrpcStream(Grpc::Status::Internal);
  AssertionResult result = xds_connection_->waitForNewStream(*dispatcher_, xds_stream_);
  RELEASE_ASSERT(result, result.message());
  xds_stream_->startGrpcStream();

  // Each of these DiscoveryRequests after the stream reset should include the last version number
  // received from the DiscoveryResponses.

  // In SotW cluster_0 will be in the resource_names, but in delta-xDS
  // resource_names_subscribe and resource_names_unsubscribe must be empty for
  // a wildcard request (cluster_0 will appear in initial_resource_versions).
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {"cluster_0"}, {},
                                      {}, true));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
}

// Validate that the request with duplicate listeners is rejected.
TEST_P(AdsIntegrationTest, DuplicateWarmingListeners) {
  initialize();

  // Send initial configuration, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));

  // Send duplicate listeners and validate that the update is rejected.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("duplicae_listener", "route_config_0"),
       buildListener("duplicae_listener", "route_config_0")},
      {buildListener("duplicae_listener", "route_config_0"),
       buildListener("duplicae_listener", "route_config_0")},
      {}, "1");
  test_server_->waitForCounter("listener_manager.lds.update_rejected", Ge(1));
}

// Validate that the use of V2 transport version is rejected by default.
TEST_P(AdsIntegrationTest, DEPRECATED_FEATURE_TEST(RejectV2TransportConfigByDefault)) {
  initialize();

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  auto cluster = buildCluster("cluster_0");
  auto* api_config_source =
      cluster.mutable_eds_cluster_config()->mutable_eds_config()->mutable_api_config_source();
  api_config_source->set_api_type(envoy::config::core::v3::ApiConfigSource::GRPC);
  api_config_source->set_transport_api_version(envoy::config::core::v3::V2);
  envoy::config::core::v3::GrpcService* grpc_service = api_config_source->add_grpc_services();
  setGrpcService(*grpc_service, "ads_cluster", xds_upstream_->localAddress());
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {cluster}, {cluster}, {}, "1");
  test_server_->waitForCounter("cluster_manager.cds.update_rejected", Ge(1));
}

// Regression test for the use-after-free crash when processing RDS update (#3953).
TEST_P(AdsIntegrationTest, RdsAfterLdsWithNoRdsChanges) {
  initialize();

  // Send initial configuration.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));

  // Validate that we can process a request.
  makeSingleRequest();

  // Update existing LDS (change stat_prefix).
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("listener_0", "route_config_0", "rds_crash")},
      {buildListener("listener_0", "route_config_0", "rds_crash")}, {}, "2");
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));

  // Update existing RDS (no changes).
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "2");

  // Validate that we can process a request again
  makeSingleRequest();
}

// Regression test for #11877, validate behavior of EDS updates when a cluster is updated and
// an active cluster is replaced by a newer cluster undergoing warming.
TEST_P(AdsIntegrationTest, CdsEdsReplacementWarming) {
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildTlsCluster("cluster_0")},
      {buildTlsCluster("cluster_0")}, {}, "2");
  // Inconsistent SotW and delta behaviors for warming, see
  // https://github.com/envoyproxy/envoy/issues/11477#issuecomment-657855029.
  // TODO (dmitri-d) this should be remove when legacy mux implementations have been removed.
  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw) {
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"cluster_0"}, {}, {}));
  }
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildTlsClusterLoadAssignment("cluster_0")}, {buildTlsClusterLoadAssignment("cluster_0")},
      {}, "2");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "2", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "2",
                                      {"cluster_0"}, {}, {}));
}

// Validate that an update to a Cluster that doesn't receive updated ClusterLoadAssignment
// uses the previous (cached) cluster load assignment.
TEST_P(AdsIntegrationTest, CdsKeepEdsAfterWarmingFailure) {
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  envoy::config::cluster::v3::Cluster cluster = buildCluster("cluster_0");
  // Set a small EDS subscription expiration.
  cluster.mutable_eds_cluster_config()
      ->mutable_eds_config()
      ->mutable_initial_fetch_timeout()
      ->set_nanos(100 * 1000 * 1000);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {cluster}, {cluster}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Update a cluster's field (connect_timeout) so the cluster in Envoy will be explicitly updated.
  cluster.mutable_connect_timeout()->set_seconds(7);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {cluster}, {cluster}, {}, "2");
  // Inconsistent SotW and delta behaviors for warming, see
  // https://github.com/envoyproxy/envoy/issues/11477#issuecomment-657855029.
  // TODO (dmitri-d) this should be remove when legacy mux implementations have been removed.
  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw) {
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"cluster_0"}, {}, {}));
  }

  // Avoid sending an EDS update, and wait for EDS update timeout (that results in
  // a cluster update without resources).
  test_server_->waitForCounter("cluster.cluster_0.init_fetch_timeout", Ge(1));
  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw) {
    // Expect another EDS request after the previous one wasn't answered and timed out.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"cluster_0"}, {}, {}));
  }
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "2", {}, {}, {}));

  // Envoy uses the cached resource.
  test_server_->waitForCounter("cluster.cluster_0.assignment_use_cached", Ge(1));
  // A single message should be successfully sent to the upstream.
  makeSingleRequest();
}

TEST_P(AdsIntegrationTest, CdsKeepEdsDropOverloadAfterWarmingFailure) {
  // This test should be kept after the runtime guard is deprecated
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  envoy::config::cluster::v3::Cluster cluster = buildCluster("cluster_0");
  // Set a small EDS subscription expiration.
  cluster.mutable_eds_cluster_config()
      ->mutable_eds_config()
      ->mutable_initial_fetch_timeout()
      ->set_nanos(100 * 1000 * 1000);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {cluster}, {cluster}, {}, "1");

  auto cluster_load_assignment = buildClusterLoadAssignment("cluster_0");
  auto* policy = cluster_load_assignment.mutable_policy();
  auto* drop_overload = policy->add_drop_overloads();
  drop_overload->set_category("lb_drop_overload");
  // Set drop_overload to drop everything.
  drop_overload->mutable_drop_percentage()->set_numerator(100);
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {cluster_load_assignment},
      {cluster_load_assignment}, {}, "1");

  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  // Send a HTTP request and verify it is dropped with unconditional_drop_overload.
  makeSingleRequestWithDropOverload();

  // Update a cluster's field (connect_timeout) so the cluster in Envoy will be explicitly updated.
  cluster.mutable_connect_timeout()->set_seconds(7);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {cluster}, {cluster}, {}, "2");
  // Avoid sending an EDS update, and wait for EDS update timeout (that results in
  // a cluster update without resources).
  test_server_->waitForCounter("cluster.cluster_0.init_fetch_timeout", Ge(1));
  // Envoy uses the cached resource.
  test_server_->waitForCounter("cluster.cluster_0.assignment_use_cached", Ge(1));
  // Send a HTTP request again and verify it is dropped with unconditional_drop_overload.
  makeSingleRequestWithDropOverload();
}

// Validate that an update to 2 Clusters that have the same ClusterLoadAssignment, and
// that don't receive updated ClusterLoadAssignment use the previous (cached) cluster
// load assignment.
TEST_P(AdsIntegrationTest, DoubleClustersCachedLoadAssignment) {
  initialize();
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  envoy::config::cluster::v3::Cluster cluster0 = buildCluster("cluster_0");
  envoy::config::cluster::v3::Cluster cluster1 = buildCluster("cluster_1");
  // Set a small EDS subscription expiration.
  cluster0.mutable_eds_cluster_config()
      ->mutable_eds_config()
      ->mutable_initial_fetch_timeout()
      ->set_nanos(100 * 1000 * 1000);
  cluster1.mutable_eds_cluster_config()
      ->mutable_eds_config()
      ->mutable_initial_fetch_timeout()
      ->set_nanos(100 * 1000 * 1000);
  // Set the EDS service of cluster0 and cluster1 to be the same.
  cluster0.mutable_eds_cluster_config()->set_service_name("same_eds");
  cluster1.mutable_eds_cluster_config()->set_service_name("same_eds");
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {cluster0, cluster1}, {cluster0, cluster1}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"same_eds"}, {"same_eds"}, {}));
  auto cla_0 = buildClusterLoadAssignment("same_eds");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {cla_0}, {cla_0}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"same_eds"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Update a field of the clusters (connect_timeout) so the clusters in Envoy will be explicitly
  // updated.
  cluster0.mutable_connect_timeout()->set_seconds(7);
  cluster1.mutable_connect_timeout()->set_seconds(7);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {cluster0, cluster1}, {cluster0, cluster1}, {}, "2");
  // Inconsistent SotW and delta behaviors for warming, see
  // https://github.com/envoyproxy/envoy/issues/11477#issuecomment-657855029.
  // TODO (dmitri-d) this should be remove when legacy mux implementations have been removed.
  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw) {
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"same_eds"}, {}, {}));
  }

  // Avoid sending an EDS update, and wait for EDS update timeout (that results in
  // a cluster update without resources).
  test_server_->waitForCounter("cluster.cluster_0.init_fetch_timeout", Ge(1));

  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw) {
    // Expect another EDS request after the previous one wasn't answered and timed out.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"same_eds"}, {}, {}));
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                        {"same_eds"}, {}, {}));
  }
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "2", {}, {}, {}));

  // Envoy uses the cached resource.
  test_server_->waitForCounter("cluster.cluster_0.assignment_use_cached", Ge(1));
  // A single message should be successfully sent to the upstream.
  makeSingleRequest();

  // Now send an EDS update.
  cla_0.mutable_policy()->mutable_overprovisioning_factor()->set_value(141);
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {cla_0}, {cla_0}, {}, "2");

  // Wait for ingesting the update.
  test_server_->waitForCounter("cluster.cluster_0.update_success", Eq(2));

  // A single message should be successfully sent to the upstream.
  makeSingleRequest();
}

// Validate that the request with duplicate clusters in the initial request during server init is
// rejected.
TEST_P(AdsIntegrationTest, DuplicateInitialClusters) {
  initialize();

  // Send initial configuration, failing each xDS once (via a type mismatch), validate we can
  // process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster,
      {buildCluster("duplicate_cluster"), buildCluster("duplicate_cluster")},
      {buildCluster("duplicate_cluster"), buildCluster("duplicate_cluster")}, {}, "1");

  test_server_->waitForCounter("cluster_manager.cds.update_rejected", Ge(1));
}

// Validate that the request with duplicate clusters in the subsequent requests (warming clusters)
// is rejected.
TEST_P(AdsIntegrationTest, DuplicateWarmingClusters) {
  initialize();

  // Send initial configuration, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Send duplicate warming clusters and validate that the update is rejected.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster,
      {buildCluster("duplicate_cluster"), buildCluster("duplicate_cluster")},
      {buildCluster("duplicate_cluster"), buildCluster("duplicate_cluster")}, {}, "2");
  test_server_->waitForCounter("cluster_manager.cds.update_rejected", Ge(1));
}

// Verify CDS is paused during cluster warming.
TEST_P(AdsIntegrationTest, CdsPausedDuringWarming) {
  initialize();

  // Send initial configuration, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));

  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Send the first warming cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("warming_cluster_1")},
      {buildCluster("warming_cluster_1")}, {"cluster_0"}, "2");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));
  test_server_->waitForGauge("cluster.warming_cluster_1.warming_state", Eq(1));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_1"}, {"warming_cluster_1"}, {"cluster_0"}));

  // Send the second warming cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster,
      {buildCluster("warming_cluster_1"), buildCluster("warming_cluster_2")},
      {buildCluster("warming_cluster_1"), buildCluster("warming_cluster_2")}, {}, "3");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(2));
  test_server_->waitForGauge("cluster.warming_cluster_2.warming_state", Eq(1));

  // We would've got a Cluster discovery request with version 2 here, had the CDS not been paused.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_2", "warming_cluster_1"},
                                      {"warming_cluster_2"}, {}));

  // Finish warming the clusters.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("warming_cluster_1"),
       buildClusterLoadAssignment("warming_cluster_2")},
      {buildClusterLoadAssignment("warming_cluster_1"),
       buildClusterLoadAssignment("warming_cluster_2")},
      {"cluster_0"}, "2");

  // Validate that clusters are warmed.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster.warming_cluster_1.warming_state", Eq(0));
  test_server_->waitForGauge("cluster.warming_cluster_2.warming_state", Eq(0));

  // CDS is resumed and EDS response was acknowledged.
  // TODO (dmitri-d) remove the conditional when legacy mux implementations are removed.
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Sotw) {
    // Envoy will ACK both Cluster messages. Since they arrived while CDS was paused, they aren't
    // sent until CDS is unpaused. Since version 3 has already arrived by the time the version 2
    // ACK goes out, they're both acknowledging version 3.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "3", {}, {}, {}));
  }
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "3", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "2",
                                      {"warming_cluster_2", "warming_cluster_1"}, {}, {}));
}

TEST_P(AdsIntegrationTest, RemoveWarmingCluster) {
  initialize();

  // Send initial configuration, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));

  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Send the first warming cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("warming_cluster_1")},
      {buildCluster("warming_cluster_1")}, {"cluster_0"}, "2");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_1"}, {"warming_cluster_1"}, {"cluster_0"}));

  // Send the second warming cluster and remove the first cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("warming_cluster_2")},
                                                             {buildCluster("warming_cluster_2")},
                                                             // Delta: remove warming_cluster_1.
                                                             {"warming_cluster_1"}, "3");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));
  // We would've got a Cluster discovery request with version 2 here, had the CDS not been paused.

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_2"}, {"warming_cluster_2"},
                                      {"warming_cluster_1"}));

  // Finish warming the clusters. Note that the first warming cluster is not included in the
  // response.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("warming_cluster_2")},
      {buildClusterLoadAssignment("warming_cluster_2")}, {"cluster_0"}, "2");

  // Validate that all clusters are warmed.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Eq(3));

  // CDS is resumed and EDS response was acknowledged.
  // TODO (dmitri-d) remove the conditional when legacy mux implementations are removed.
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Sotw) {
    // Envoy will ACK both Cluster messages. Since they arrived while CDS was paused, they aren't
    // sent until CDS is unpaused. Since version 3 has already arrived by the time the version 2
    // ACK goes out, they're both acknowledging version 3.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "3", {}, {}, {}));
  }
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "3", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "2",
                                      {"warming_cluster_2"}, {}, {}));
}
// Validate that warming listeners are removed when left out of SOTW update.
TEST_P(AdsIntegrationTest, RemoveWarmingListener) {
  initialize();

  // Send initial configuration to start workers, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));

  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Send a listener without its route, so it will be added as warming.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("listener_0", "route_config_0"),
       buildListener("warming_listener_1", "nonexistent_route")},
      {buildListener("warming_listener_1", "nonexistent_route")}, {}, "2");
  test_server_->waitForGauge("listener_manager.total_listeners_warming", Eq(1));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"nonexistent_route", "route_config_0"},
                                      {"nonexistent_route"}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "2", {}, {}, {}));

  // Send a request removing the warming listener.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {"warming_listener_1"}, "3");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {"nonexistent_route"}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "3", {}, {}, {}));

  // The warming listener should be successfully removed.
  test_server_->waitForCounter("listener_manager.listener_removed", Eq(1));
  test_server_->waitForGauge("listener_manager.total_listeners_warming", Eq(0));
}

// Verify cluster warming is finished only on named EDS response.
TEST_P(AdsIntegrationTest, ClusterWarmingOnNamedResponse) {
  initialize();

  // Send initial configuration, validate we can process a request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));

  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  makeSingleRequest();

  // Send the first warming cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("warming_cluster_1")},
      {buildCluster("warming_cluster_1")}, {"cluster_0"}, "2");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_1"}, {"warming_cluster_1"}, {"cluster_0"}));

  // Send the second warming cluster.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster,
      {buildCluster("warming_cluster_1"), buildCluster("warming_cluster_2")},
      {buildCluster("warming_cluster_1"), buildCluster("warming_cluster_2")}, {}, "3");
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(2));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"warming_cluster_2", "warming_cluster_1"},
                                      {"warming_cluster_2"}, {}));

  // Finish warming the first cluster.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("warming_cluster_1")},
      {buildClusterLoadAssignment("warming_cluster_1")}, {}, "2");

  // Envoy will not finish warming of the second cluster because of the missing load assignments
  // i,e. no named EDS response.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  // Disconnect and reconnect the stream.
  xds_stream_->finishGrpcStream(Grpc::Status::Internal);

  AssertionResult result = xds_connection_->waitForNewStream(*dispatcher_, xds_stream_);
  RELEASE_ASSERT(result, result.message());
  xds_stream_->startGrpcStream();

  // Envoy will not finish warming of the second cluster because of the missing load assignments
  // i,e. no named EDS response even after disconnect and reconnect.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  // Finish warming the second cluster.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("warming_cluster_2")},
      {buildClusterLoadAssignment("warming_cluster_2")}, {}, "3");

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
}

// This test validates two cases.
// 1. Verify Listener warming is finished only on named RDS response for new routes.
// 2. Verify Listener does not get in to warming state for existing routes.
TEST_P(AdsIntegrationTest, ListenerWarmingOnNamedResponse) {
  initialize();

  // Send initial configuration.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));

  // Validate that we can process a request.
  makeSingleRequest();

  // Update existing listener - update stat prefix, use the same route name.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("cluster_1")}, {buildCluster("cluster_1")},
      {"cluster_0"}, "2");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_1")},
      {buildClusterLoadAssignment("cluster_1")}, {"cluster_0"}, "2");
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("listener_0", "route_config_0", "rds_test")},
      {buildListener("listener_0", "route_config_0", "rds_test")}, {}, "2");

  // Validate that listener is updated correctly and does not get in to warming state.
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));
  test_server_->waitForGauge("listener_manager.total_listeners_warming", Eq(0));

  // Update listener with a new route.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("listener_0", "route_config_1", "rds_test")},
      {buildListener("listener_0", "route_config_1", "rds_test")}, {}, "2");

  // Validate that the listener gets in to warming state waiting for RDS.
  test_server_->waitForGauge("listener_manager.total_listeners_warming", Eq(1));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));

  // Send the new route and validate that listener finishes warming.
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_1", "cluster_1")},
      {buildRouteConfig("route_config_1", "cluster_1")}, {}, "2");
  test_server_->waitForGauge("listener_manager.total_listeners_warming", Eq(0));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(3));
}

// Regression test for the use-after-free crash when processing RDS update (#3953).
TEST_P(AdsIntegrationTest, RdsAfterLdsWithRdsChange) {
  initialize();

  // Send initial configuration.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));

  // Validate that we can process a request.
  makeSingleRequest();

  // Update existing LDS (change stat_prefix).
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("cluster_1")}, {buildCluster("cluster_1")},
      {"cluster_0"}, "2");
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_1")},
      {buildClusterLoadAssignment("cluster_1")}, {"cluster_0"}, "2");
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener,
      {buildListener("listener_0", "route_config_0", "rds_crash")},
      {buildListener("listener_0", "route_config_0", "rds_crash")}, {}, "2");
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));

  // Update existing RDS (migrate traffic to cluster_1).
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_1")},
      {buildRouteConfig("route_config_0", "cluster_1")}, {}, "2");

  // Validate that we can process a request after RDS update
  test_server_->waitForCounter("http.ads_test.rds.route_config_0.config_reload", Ge(2));
  makeSingleRequest();
}

// Regression test for the use-after-free crash when a listener awaiting an RDS update is destroyed
// (#6116).
TEST_P(AdsIntegrationTest, RdsAfterLdsInvalidated) {

  initialize();

  // STEP 1: Initial setup
  // ---------------------

  // Initial request for any cluster, respond with cluster_0 version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  // Initial request for load assignment for cluster_0, respond with version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  // Request for updates to cluster_0 version 1, no response
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  // Initial request for any listener, respond with listener_0 version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  // Request for updates to load assignment version 1, no response
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));

  // Initial request for route_config_0 (referenced by listener_0), respond with version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "cluster_0")},
      {buildRouteConfig("route_config_0", "cluster_0")}, {}, "1");

  // Wait for initial listener to be created successfully. Any subsequent listeners will then use
  // the dynamic InitManager (see ListenerImpl::initManager).
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));

  // STEP 2: Listener with dynamic InitManager
  // -----------------------------------------

  // Request for updates to listener_0 version 1, respond with version 2. Under the hood, this
  // registers RdsRouteConfigSubscription's init target with the new ListenerImpl instance.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_1")},
      {buildListener("listener_0", "route_config_1")}, {}, "2");

  // Request for updates to route_config_0 version 1, and initial request for route_config_1
  // (referenced by listener_0), don't respond yet!
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_0"}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {"route_config_1", "route_config_0"}, {"route_config_1"},
                                      {}));

  // STEP 3: "New listener, who dis?"
  // --------------------------------

  // Request for updates to listener_0 version 2, respond with version 3 (updated stats prefix).
  // This should blow away the previous ListenerImpl instance, which is still waiting for
  // route_config_1...
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "2", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_1", "omg")},
      {buildListener("listener_0", "route_config_1", "omg")}, {}, "3");

  // Respond to prior request for route_config_1. Under the hood, this invokes
  // RdsRouteConfigSubscription::runInitializeCallbackIfAny, which references the defunct
  // ListenerImpl instance. We should not crash in this event!
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_1", "cluster_0")},
      {buildRouteConfig("route_config_1", "cluster_0")}, {"route_config_0"}, "1");

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));
}

class AdsFailIntegrationTest : public AdsDeltaSotwIntegrationSubStateParamTest,
                               public HttpIntegrationTest {
public:
  AdsFailIntegrationTest()
      : HttpIntegrationTest(
            Http::CodecType::HTTP2, ipVersion(),
            ConfigHelper::adsBootstrap((sotwOrDelta() == Grpc::SotwOrDelta::Sotw) ||
                                               (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw)
                                           ? "GRPC"
                                           : "DELTA_GRPC")) {
    config_helper_.addRuntimeOverride("envoy.reloadable_features.unified_mux",
                                      (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw ||
                                       sotwOrDelta() == Grpc::SotwOrDelta::UnifiedDelta)
                                          ? "true"
                                          : "false");
    create_xds_upstream_ = true;
    use_lds_ = false;
    sotw_or_delta_ = sotwOrDelta();
  }

  void TearDown() override { cleanUpXdsConnection(); }

  void initialize() override {
    config_helper_.addConfigModifier([this](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* grpc_service =
          bootstrap.mutable_dynamic_resources()->mutable_ads_config()->add_grpc_services();
      setGrpcService(*grpc_service, "ads_cluster", xds_upstream_->localAddress());
      auto* ads_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_cluster->MergeFrom(bootstrap.static_resources().clusters()[0]);
      ads_cluster->set_name("ads_cluster");
    });
    setUpstreamProtocol(Http::CodecType::HTTP2);
    HttpIntegrationTest::initialize();
  }
};

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsFailIntegrationTest,
                         ADS_INTEGRATION_PARAMS,
                         AdsFailIntegrationTest::protocolTestParamsToString);

// Validate that we don't crash on failed ADS stream.
TEST_P(AdsFailIntegrationTest, ConnectDisconnect) {
  initialize();
  createXdsConnection();
  ASSERT_TRUE(xds_connection_->waitForNewStream(*dispatcher_, xds_stream_));
  xds_stream_->startGrpcStream();
  xds_stream_->finishGrpcStream(Grpc::Status::Internal);
}

class AdsConfigIntegrationTest : public AdsDeltaSotwIntegrationSubStateParamTest,
                                 public HttpIntegrationTest {
public:
  AdsConfigIntegrationTest()
      : HttpIntegrationTest(
            Http::CodecType::HTTP2, ipVersion(),
            ConfigHelper::adsBootstrap((sotwOrDelta() == Grpc::SotwOrDelta::Sotw) ||
                                               (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw)
                                           ? "GRPC"
                                           : "DELTA_GRPC")) {
    config_helper_.addRuntimeOverride("envoy.reloadable_features.unified_mux",
                                      (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw ||
                                       sotwOrDelta() == Grpc::SotwOrDelta::UnifiedDelta)
                                          ? "true"
                                          : "false");
    create_xds_upstream_ = true;
    use_lds_ = false;
    sotw_or_delta_ = sotwOrDelta();
  }

  void TearDown() override { cleanUpXdsConnection(); }

  void initialize() override {
    config_helper_.addConfigModifier([this](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* grpc_service =
          bootstrap.mutable_dynamic_resources()->mutable_ads_config()->add_grpc_services();
      setGrpcService(*grpc_service, "ads_cluster", xds_upstream_->localAddress());
      auto* ads_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_cluster->MergeFrom(bootstrap.static_resources().clusters()[0]);
      ads_cluster->set_name("ads_cluster");

      // Add EDS static Cluster that uses ADS as config Source.
      auto* ads_eds_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_eds_cluster->set_name("ads_eds_cluster");
      ads_eds_cluster->set_type(envoy::config::cluster::v3::Cluster::EDS);
      auto* eds_cluster_config = ads_eds_cluster->mutable_eds_cluster_config();
      auto* eds_config = eds_cluster_config->mutable_eds_config();
      eds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);
      eds_config->mutable_ads();
    });
    setUpstreamProtocol(Http::CodecType::HTTP2);
    HttpIntegrationTest::initialize();
  }
};

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsConfigIntegrationTest,
                         ADS_INTEGRATION_PARAMS,
                         AdsConfigIntegrationTest::protocolTestParamsToString);

// This is s regression validating that we don't crash on EDS static Cluster that uses ADS.
TEST_P(AdsConfigIntegrationTest, EdsClusterWithAdsConfigSource) {
  initialize();
  createXdsConnection();
  ASSERT_TRUE(xds_connection_->waitForNewStream(*dispatcher_, xds_stream_));
  xds_stream_->startGrpcStream();
  xds_stream_->finishGrpcStream(Grpc::Status::Ok);
}

// Validates that the initial xDS request batches all resources referred to in static config
TEST_P(AdsIntegrationTest, XdsBatching) {
  config_helper_.addConfigModifier([this](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
    bootstrap.mutable_dynamic_resources()->clear_cds_config();
    bootstrap.mutable_dynamic_resources()->clear_lds_config();

    auto static_resources = bootstrap.mutable_static_resources();
    static_resources->add_clusters()->MergeFrom(buildCluster("eds_cluster"));
    static_resources->add_clusters()->MergeFrom(buildCluster("eds_cluster2"));

    static_resources->add_listeners()->MergeFrom(buildListener("rds_listener", "route_config"));
    static_resources->add_listeners()->MergeFrom(buildListener("rds_listener2", "route_config2"));
  });

  on_server_init_function_ = [this]() {
    createXdsConnection();
    ASSERT_TRUE(xds_connection_->waitForNewStream(*dispatcher_, xds_stream_));
    xds_stream_->startGrpcStream();

    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                        {"eds_cluster2", "eds_cluster"},
                                        {"eds_cluster2", "eds_cluster"}, {}, true));
    sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
        Config::TestTypeUrl::get().ClusterLoadAssignment,
        {buildClusterLoadAssignment("eds_cluster"), buildClusterLoadAssignment("eds_cluster2")},
        {buildClusterLoadAssignment("eds_cluster"), buildClusterLoadAssignment("eds_cluster2")}, {},
        "1");

    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                        {"route_config2", "route_config"},
                                        {"route_config2", "route_config"}, {}));
    sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
        Config::TestTypeUrl::get().RouteConfiguration,
        {buildRouteConfig("route_config2", "eds_cluster2"),
         buildRouteConfig("route_config", "dummy_cluster")},
        {buildRouteConfig("route_config2", "eds_cluster2"),
         buildRouteConfig("route_config", "dummy_cluster")},
        {}, "1");
  };

  initialize();
}

// Validates that listeners can be removed before server start.
TEST_P(AdsIntegrationTest, ListenerDrainBeforeServerStart) {
  initialize();

  // Initial request for cluster, response for cluster_0.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  // Initial request for load assignment for cluster_0, respond with version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  // Request for updates to cluster_0 version 1, no response
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  // Initial request for any listener, respond with listener_0 version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "1");

  // Request for updates to load assignment version 1, no response
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}));

  // Initial request for route_config_0 (referenced by listener_0), respond with version 1
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {"route_config_0"}, {"route_config_0"}, {}));

  test_server_->waitForGauge("listener_manager.total_listeners_active", Ge(1));
  // Before server is started, even though listeners are added to active list
  // we mark them as "warming" in config dump since they're not initialized yet.
  ASSERT_EQ(getListenersConfigDump().dynamic_listeners().size(), 1);
  EXPECT_TRUE(getListenersConfigDump().dynamic_listeners(0).has_warming_state());

  // Remove listener.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(Config::TestTypeUrl::get().Listener,
                                                               {}, {}, {"listener_0"}, "2");
  test_server_->waitForGauge("listener_manager.total_listeners_active", Eq(0));
}

// Validate that Node message is well formed.
TEST_P(AdsIntegrationTest, NodeMessage) {
  initialize();
  envoy::service::discovery::v3::DiscoveryRequest sotw_request;
  envoy::service::discovery::v3::DeltaDiscoveryRequest delta_request;
  const envoy::config::core::v3::Node* node = nullptr;
  if (sotw_or_delta_ == Grpc::SotwOrDelta::Sotw ||
      sotw_or_delta_ == Grpc::SotwOrDelta::UnifiedSotw) {
    EXPECT_TRUE(xds_stream_->waitForGrpcMessage(*dispatcher_, sotw_request));
    EXPECT_TRUE(sotw_request.has_node());
    node = &sotw_request.node();
  } else {
    EXPECT_TRUE(xds_stream_->waitForGrpcMessage(*dispatcher_, delta_request));
    EXPECT_TRUE(delta_request.has_node());
    node = &delta_request.node();
  }
  envoy::config::core::v3::BuildVersion build_version_msg;
  build_version_msg.MergeFrom(node->user_agent_build_version());
  EXPECT_THAT(build_version_msg, ProtoEq(VersionInfo::buildVersion()));
  EXPECT_GE(node->extensions().size(), 0);
  EXPECT_EQ(0, node->client_features().size());
  xds_stream_->finishGrpcStream(Grpc::Status::Ok);
}

TEST_P(AdsIntegrationTest, SetNodeAlways) {
  config_helper_.addConfigModifier([](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
    auto* ads_config = bootstrap.mutable_dynamic_resources()->mutable_ads_config();
    ads_config->set_set_node_on_first_message_only(false);
  });
  initialize();

  // Check that the node is sent in each request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}, true));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}, true));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}, true));
};

// Check if EDS cluster defined in file is loaded before ADS request and used as xDS server
class AdsClusterFromFileIntegrationTest : public AdsDeltaSotwIntegrationSubStateParamTest,
                                          public HttpIntegrationTest {
public:
  AdsClusterFromFileIntegrationTest()
      : HttpIntegrationTest(
            Http::CodecType::HTTP2, ipVersion(),
            ConfigHelper::adsBootstrap((sotwOrDelta() == Grpc::SotwOrDelta::Sotw) ||
                                               (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw)
                                           ? "GRPC"
                                           : "DELTA_GRPC")) {
    config_helper_.addRuntimeOverride("envoy.reloadable_features.unified_mux",
                                      (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw ||
                                       sotwOrDelta() == Grpc::SotwOrDelta::UnifiedDelta)
                                          ? "true"
                                          : "false");
    create_xds_upstream_ = true;
    use_lds_ = false;
    sotw_or_delta_ = sotwOrDelta();
  }

  void TearDown() override { cleanUpXdsConnection(); }

  void initialize() override {
    config_helper_.addConfigModifier([this](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* grpc_service =
          bootstrap.mutable_dynamic_resources()->mutable_ads_config()->add_grpc_services();
      setGrpcService(*grpc_service, "ads_cluster", xds_upstream_->localAddress());
      // Define ADS cluster
      auto* ads_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_cluster->set_name("ads_cluster");
      ConfigHelper::setHttp2(*ads_cluster);
      ads_cluster->set_type(envoy::config::cluster::v3::Cluster::EDS);
      auto* ads_cluster_config = ads_cluster->mutable_eds_cluster_config();
      auto* ads_cluster_eds_config = ads_cluster_config->mutable_eds_config();
      // Define port of ADS cluster
      TestEnvironment::PortMap port_map_;
      port_map_["upstream_0"] = xds_upstream_->localAddress()->ip()->port();
      // Path to EDS for ads_cluster
      const std::string eds_path = TestEnvironment::temporaryFileSubstitute(
          "test/config/integration/server_xds.eds.ads_cluster.yaml", port_map_, version_);
      ads_cluster_eds_config->mutable_path_config_source()->set_path(eds_path);
      ads_cluster_eds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);

      // Add EDS static Cluster that uses ADS as config Source.
      auto* ads_eds_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_eds_cluster->set_name("ads_eds_cluster");
      ads_eds_cluster->set_type(envoy::config::cluster::v3::Cluster::EDS);
      auto* eds_cluster_config = ads_eds_cluster->mutable_eds_cluster_config();
      auto* eds_config = eds_cluster_config->mutable_eds_config();
      eds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);
      eds_config->mutable_ads();
    });
    setUpstreamProtocol(Http::CodecType::HTTP2);
    HttpIntegrationTest::initialize();
  }

  envoy::config::endpoint::v3::ClusterLoadAssignment
  buildClusterLoadAssignment(const std::string& name) {
    return TestUtility::parseYaml<envoy::config::endpoint::v3::ClusterLoadAssignment>(
        fmt::format(R"EOF(
      cluster_name: {}
      endpoints:
      - lb_endpoints:
        - endpoint:
            address:
              socket_address:
                address: {}
                port_value: {}
    )EOF",
                    name, Network::Test::getLoopbackAddressString(ipVersion()),
                    fake_upstreams_[0]->localAddress()->ip()->port()));
  }
};

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsClusterFromFileIntegrationTest,
                         ADS_INTEGRATION_PARAMS,
                         AdsClusterFromFileIntegrationTest::protocolTestParamsToString);

// Validate if ADS cluster defined as EDS will be loaded from file and connection with ADS cluster
// will be established.
TEST_P(AdsClusterFromFileIntegrationTest, BasicTestWidsAdsEndpointLoadedFromFile) {
  initialize();
  createXdsConnection();
  ASSERT_TRUE(xds_connection_->waitForNewStream(*dispatcher_, xds_stream_));
  xds_stream_->startGrpcStream();

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"ads_eds_cluster"}, {"ads_eds_cluster"}, {}, true));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("ads_eds_cluster")},
      {buildClusterLoadAssignment("ads_eds_cluster")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"ads_eds_cluster"}, {}, {}));
}

class AdsIntegrationTestWithRtds : public AdsIntegrationTest {
public:
  void initialize() override {
    config_helper_.addConfigModifier([](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* layered_runtime = bootstrap.mutable_layered_runtime();
      auto* layer = layered_runtime->add_layers();
      layer->set_name("foobar");
      auto* rtds_layer = layer->mutable_rtds_layer();
      rtds_layer->set_name("ads_rtds_layer");
      auto* rtds_config = rtds_layer->mutable_rtds_config();
      rtds_config->mutable_ads();
      rtds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);

      auto* ads_config = bootstrap.mutable_dynamic_resources()->mutable_ads_config();
      ads_config->set_set_node_on_first_message_only(true);
    });
    AdsIntegrationTest::initialize();
  }

  void testBasicFlow() {
    // Test that runtime discovery request comes first and cluster discovery request comes after
    // runtime was loaded.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Runtime, "", {"ads_rtds_layer"},
                                        {"ads_rtds_layer"}, {}, true));
    auto some_rtds_layer = TestUtility::parseYaml<envoy::service::runtime::v3::Runtime>(R"EOF(
      name: ads_rtds_layer
      layer:
        foo: bar
        baz: meh
    )EOF");
    sendDiscoveryResponse<envoy::service::runtime::v3::Runtime>(
        Config::TestTypeUrl::get().Runtime, {some_rtds_layer}, {some_rtds_layer}, {}, "1");

    test_server_->waitForCounter("runtime.load_success", Ge(1));
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}));
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Runtime, "1", {"ads_rtds_layer"},
                                        {}, {}));
  }
};

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsIntegrationTestWithRtds,
                         ADS_INTEGRATION_PARAMS,
                         AdsIntegrationTestWithRtds::protocolTestParamsToString);

TEST_P(AdsIntegrationTestWithRtds, Basic) {
  initialize();
  testBasicFlow();
}

class AdsIntegrationTestWithRtdsAndSecondaryClusters : public AdsIntegrationTestWithRtds {
public:
  void initialize() override {
    config_helper_.addConfigModifier([](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      // Add secondary cluster to the list of static resources.
      auto* eds_cluster = bootstrap.mutable_static_resources()->add_clusters();
      eds_cluster->set_name("eds_cluster");
      eds_cluster->set_type(envoy::config::cluster::v3::Cluster::EDS);
      auto* eds_cluster_config = eds_cluster->mutable_eds_cluster_config();
      eds_cluster_config->mutable_eds_config()->mutable_ads();
      eds_cluster_config->mutable_eds_config()->set_resource_api_version(
          envoy::config::core::v3::ApiVersion::V3);
    });
    AdsIntegrationTestWithRtds::initialize();
  }

  void testBasicFlow() {
    // Test that runtime discovery request comes first followed by the cluster load assignment
    // discovery request for secondary cluster and then CDS discovery request.
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Runtime, "", {"ads_rtds_layer"},
                                        {"ads_rtds_layer"}, {}, true));
    auto some_rtds_layer = TestUtility::parseYaml<envoy::service::runtime::v3::Runtime>(R"EOF(
      name: ads_rtds_layer
      layer:
        foo: bar
        baz: meh
    )EOF");
    sendDiscoveryResponse<envoy::service::runtime::v3::Runtime>(
        Config::TestTypeUrl::get().Runtime, {some_rtds_layer}, {some_rtds_layer}, {}, "1");

    test_server_->waitForCounter("runtime.load_success", Ge(1));
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                        {"eds_cluster"}, {"eds_cluster"}, {}, false));
    sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
        Config::TestTypeUrl::get().ClusterLoadAssignment,
        {buildClusterLoadAssignment("eds_cluster")}, {buildClusterLoadAssignment("eds_cluster")},
        {}, "1");

    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Runtime, "1", {"ads_rtds_layer"},
                                        {}, {}, false));
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, false));
    sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
        Config::TestTypeUrl::get().Cluster, {buildCluster("cluster_0")},
        {buildCluster("cluster_0")}, {}, "1");
  }
};

INSTANTIATE_TEST_SUITE_P(
    IpVersionsClientTypeDeltaWildcard, AdsIntegrationTestWithRtdsAndSecondaryClusters,
    ADS_INTEGRATION_PARAMS,
    AdsIntegrationTestWithRtdsAndSecondaryClusters::protocolTestParamsToString);

TEST_P(AdsIntegrationTestWithRtdsAndSecondaryClusters, Basic) {
  initialize();
  testBasicFlow();
}

// Node is present on a dynamic context parameter update.
TEST_P(AdsIntegrationTest, ContextParameterUpdate) {
  initialize();

  // Check that the node is sent in each request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}, false));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}, false));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}, false));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}, false));

  // Set a Cluster DCP.
  test_server_->setDynamicContextParam(Config::TestTypeUrl::get().Cluster, "foo", "bar");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}, true));
  EXPECT_EQ(
      "bar",
      last_node_.dynamic_parameters().at(Config::TestTypeUrl::get().Cluster).params().at("foo"));

  // Modify Cluster DCP.
  test_server_->setDynamicContextParam(Config::TestTypeUrl::get().Cluster, "foo", "baz");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}, true));
  EXPECT_EQ(
      "baz",
      last_node_.dynamic_parameters().at(Config::TestTypeUrl::get().Cluster).params().at("foo"));

  // Modify CLA DCP (some other resource type URL).
  test_server_->setDynamicContextParam(Config::TestTypeUrl::get().ClusterLoadAssignment, "foo",
                                       "b");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1",
                                      {"cluster_0"}, {}, {}, true));
  EXPECT_EQ("b", last_node_.dynamic_parameters()
                     .at(Config::TestTypeUrl::get().ClusterLoadAssignment)
                     .params()
                     .at("foo"));
  EXPECT_EQ(
      "baz",
      last_node_.dynamic_parameters().at(Config::TestTypeUrl::get().Cluster).params().at("foo"));

  // Clear Cluster DCP.
  test_server_->unsetDynamicContextParam(Config::TestTypeUrl::get().Cluster, "foo");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}, true));
  EXPECT_EQ(
      0,
      last_node_.dynamic_parameters().at(Config::TestTypeUrl::get().Cluster).params().count("foo"));
}

class XdsTpAdsIntegrationTest : public AdsIntegrationTest {
public:
  void initialize() override {
    const bool is_sotw = isSotw();
    config_helper_.addConfigModifier([is_sotw](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      bootstrap.add_node_context_params("id");
      bootstrap.add_node_context_params("cluster");
      bootstrap.mutable_dynamic_resources()->set_cds_resources_locator(
          "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/*");
      auto* cds_config = bootstrap.mutable_dynamic_resources()->mutable_cds_config();
      cds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);
      cds_config->mutable_api_config_source()->set_api_type(
          is_sotw ? envoy::config::core::v3::ApiConfigSource::AGGREGATED_GRPC
                  : envoy::config::core::v3::ApiConfigSource::AGGREGATED_DELTA_GRPC);
      cds_config->mutable_api_config_source()->set_transport_api_version(
          envoy::config::core::v3::V3);
      bootstrap.mutable_dynamic_resources()->set_lds_resources_locator(
          "xdstp://test/envoy.config.listener.v3.Listener/foo-listener/*");
      auto* lds_config = bootstrap.mutable_dynamic_resources()->mutable_lds_config();
      lds_config->set_resource_api_version(envoy::config::core::v3::ApiVersion::V3);
      lds_config->mutable_api_config_source()->set_api_type(
          is_sotw ? envoy::config::core::v3::ApiConfigSource::AGGREGATED_GRPC
                  : envoy::config::core::v3::ApiConfigSource::AGGREGATED_DELTA_GRPC);
      lds_config->mutable_api_config_source()->set_transport_api_version(
          envoy::config::core::v3::V3);
      auto* ads_config = bootstrap.mutable_dynamic_resources()->mutable_ads_config();
      ads_config->set_set_node_on_first_message_only(true);
    });
    AdsIntegrationTest::initialize();
  }
};

INSTANTIATE_TEST_SUITE_P(
    IpVersionsClientTypeDeltaWildcard, XdsTpAdsIntegrationTest,
    testing::Combine(testing::ValuesIn(TestEnvironment::getIpVersionsForTest()),
                     // There should be no variation across clients.
                     testing::Values(Grpc::ClientType::EnvoyGrpc),
                     testing::Values(Grpc::SotwOrDelta::Sotw, Grpc::SotwOrDelta::UnifiedSotw,
                                     Grpc::SotwOrDelta::Delta, Grpc::SotwOrDelta::UnifiedDelta)),
    XdsTpAdsIntegrationTest::protocolTestParamsToString);

TEST_P(XdsTpAdsIntegrationTest, Basic) {
  initialize();
  // Basic CDS/EDS xDS initialization (CDS via xdstp:// glob collection).
  const std::string cluster_wildcard = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name";
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {cluster_wildcard},
                                      {cluster_wildcard}, {}, /*expect_node=*/true));
  const std::string cluster_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                   "baz?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster_resource = buildCluster(cluster_name);
  const std::string endpoints_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/baz";
  cluster_resource.mutable_eds_cluster_config()->set_service_name(endpoints_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {cluster_resource}, {cluster_resource}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {endpoints_name}, {endpoints_name}, {}));

  const auto cluster_load_assignments = {buildClusterLoadAssignment(endpoints_name)};
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, cluster_load_assignments,
      cluster_load_assignments, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  const std::string listener_wildcard =
      "xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
      "*?xds.node.cluster=cluster_name&xds.node.id=node_name";
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {listener_wildcard},
                                      {listener_wildcard}, {}));
  const std::string route_name_0 =
      "xdstp://test/envoy.config.route.v3.RouteConfiguration/route_config_0";
  const std::string route_name_1 =
      "xdstp://test/envoy.config.route.v3.RouteConfiguration/route_config_1";
  const auto listeners = {
      buildListener("xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                    "bar?xds.node.cluster=cluster_name&xds.node.id=node_name",
                    route_name_0),
      // Ignore resource in impostor namespace.
      buildListener("xdstp://test/envoy.config.listener.v3.Listener/impostor/"
                    "bar?xds.node.cluster=cluster_name&xds.node.id=node_name",
                    route_name_0),
      // Ignore non-matching context params.
      buildListener("xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                    "baz?xds.node.cluster=cluster_name&xds.node.id=other_name",
                    route_name_0),
  };
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(Config::TestTypeUrl::get().Listener,
                                                               listeners, listeners, {}, "1");
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "",
                                      {route_name_0}, {route_name_0}, {}));
  const auto route_config = buildRouteConfig(route_name_0, cluster_name);
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {route_config}, {route_config}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1", {}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Eq(1));
  makeSingleRequest();

  // Add a second listener in the foo namespace.
  const auto baz_listener =
      buildListener("xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                    "baz?xds.node.cluster=cluster_name&xds.node.id=node_name",
                    route_name_1);
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {baz_listener}, {baz_listener}, {}, "2");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1",
                                      {route_name_1}, {route_name_1}, {}));
  const auto second_route_config = buildRouteConfig(route_name_1, cluster_name);
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {second_route_config}, {second_route_config},
      {}, "2");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "2", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "2", {}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Eq(2));
  makeSingleRequest();

  // Updates only apply to the Delta protocol, not SotW.
  const std::string bar_listener = "xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                                   "bar?xds.node.cluster=cluster_name&xds.node.id=node_name";

  if (isSotw()) {
    // In SotW, removal consists of sending the other listeners, except for the one to be removed.
    sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
        Config::TestTypeUrl::get().Listener, {baz_listener}, {}, {}, "3");
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "3", {}, {}, {}));
    test_server_->waitForCounter("listener_manager.listener_removed", Eq(1));
    makeSingleRequest();
  } else {
    // Update bar listener in the foo namespace.
    sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
        Config::TestTypeUrl::get().Listener, {}, {buildListener(bar_listener, route_name_1)}, {},
        "3");
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "3", {}, {}, {}));
    test_server_->waitForCounter("listener_manager.listener_in_place_updated", Eq(1));
    makeSingleRequest();

    // Remove bar listener from the foo namespace.
    sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
        Config::TestTypeUrl::get().Listener, {}, {}, {bar_listener}, "3");
    EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "4", {}, {}, {}));
    test_server_->waitForCounter("listener_manager.listener_removed", Eq(1));
    makeSingleRequest();
  }
}

// Basic CDS/EDS/LEDS update that warms and makes active a single cluster.
TEST_P(XdsTpAdsIntegrationTest, BasicWithLeds) {
  if (isSotw()) {
    // LEDS only works with the Delta protocol.
    return;
  }

  initialize();

  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();
  const auto leds_type_url = Config::getTypeUrl<envoy::config::endpoint::v3::LbEndpoint>();

  // Receive CDS request, and send a cluster with EDS.
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {},
                                      {"xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                                      {}, true));
  const std::string cluster_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                   "baz?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster_resource = buildCluster(cluster_name);
  const std::string endpoints_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/baz";
  cluster_resource.mutable_eds_cluster_config()->set_service_name(endpoints_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster_resource},
                                                             {}, "1");

  // Receive EDS request, and send ClusterLoadAssignment with one locality, that uses LEDS.
  const auto leds_resource_prefix =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints/";
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {}, {endpoints_name}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints_name, absl::StrCat(leds_resource_prefix, "*"))},
      {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  // Receive LEDS request, and send 2 endpoints.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix, "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));
  const auto endpoint1_name = absl::StrCat(leds_resource_prefix, "endpoint_0",
                                           "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name = absl::StrCat(leds_resource_prefix, "endpoint_1",
                                           "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(
      Config::TestTypeUrl::get().LbEndpoint,
      {buildLbEndpointResource(endpoint1_name, "2"), buildLbEndpointResource(endpoint2_name, "2")},
      {});

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "1", {}, {}, {}));

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {},
                              {"xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                               "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                              {}));

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "2", {}, {}, {}));
}

// CDS/EDS/LEDS update that warms and makes active a single cluster. While
// waiting for LEDS a new EDS update arrives.
TEST_P(XdsTpAdsIntegrationTest, LedsClusterWarmingUpdatingEds) {
  if (isSotw()) {
    // LEDS only works with the Delta protocol.
    return;
  }

  initialize();

  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();
  const auto leds_type_url = Config::getTypeUrl<envoy::config::endpoint::v3::LbEndpoint>();

  // Receive CDS request, and send a cluster with EDS.
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {},
                                      {"xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                                      {}, true));
  const std::string cluster_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                   "baz?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster_resource = buildCluster(cluster_name);
  const std::string endpoints_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/baz";
  cluster_resource.mutable_eds_cluster_config()->set_service_name(endpoints_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster_resource},
                                                             {}, "1");

  // Receive EDS request, and send ClusterLoadAssignment with one locality, that uses LEDS.
  const auto leds_resource_prefix_foo =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints/";
  const auto leds_resource_prefix_bar =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/bar-endpoints/";
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {}, {endpoints_name}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints_name,
                                          absl::StrCat(leds_resource_prefix_foo, "*"))},
      {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  // Receive LEDS request, and send an updated EDS response.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix_foo,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints_name,
                                          absl::StrCat(leds_resource_prefix_bar, "*"))},
      {}, "2");
  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "1", {}, {}, {}));

  // Send the old LEDS response, and ensure it is rejected.
  const auto endpoint1_name_foo =
      absl::StrCat(leds_resource_prefix_foo, "endpoint_0",
                   "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name_foo =
      absl::StrCat(leds_resource_prefix_foo, "endpoint_1",
                   "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(Config::TestTypeUrl::get().LbEndpoint,
                                              {buildLbEndpointResource(endpoint1_name_foo, "2"),
                                               buildLbEndpointResource(endpoint2_name_foo, "2")},
                                              {});

  // Receive the new LEDS request and EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix_bar,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {absl::StrCat(leds_resource_prefix_foo,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")}));
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "2", {}, {}, {}));

  // Send the new LEDS response
  const auto endpoint1_name_bar =
      absl::StrCat(leds_resource_prefix_bar, "endpoint_0",
                   "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name_bar =
      absl::StrCat(leds_resource_prefix_bar, "endpoint_1",
                   "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(Config::TestTypeUrl::get().LbEndpoint,
                                              {buildLbEndpointResource(endpoint1_name_bar, "3"),
                                               buildLbEndpointResource(endpoint2_name_bar, "3")},
                                              {});

  // The cluster should be warmed up.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "3", {}, {}, {}));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {},
                              {"xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                               "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                              {}));

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "2", {}, {}, {}));
}

// CDS/EDS/LEDS update that warms and makes active a single cluster. While
// waiting for LEDS a new CDS update arrives.
TEST_P(XdsTpAdsIntegrationTest, LedsClusterWarmingUpdatingCds) {
  if (isSotw()) {
    // LEDS only works with the Delta protocol.
    return;
  }

  initialize();

  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();
  const auto leds_type_url = Config::getTypeUrl<envoy::config::endpoint::v3::LbEndpoint>();

  // Receive CDS request, and send a cluster with EDS.
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {},
                                      {"xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                                      {}, true));
  const std::string cluster1_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                    "cluster1?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster1_resource = buildCluster(cluster1_name);
  const std::string endpoints1_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/cluster1";
  cluster1_resource.mutable_eds_cluster_config()->set_service_name(endpoints1_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster1_resource},
                                                             {}, "1");

  // Receive EDS request, and send ClusterLoadAssignment with one locality, that uses LEDS.
  const auto leds_resource_prefix1 =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints1/";
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {}, {endpoints1_name}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints1_name,
                                          absl::StrCat(leds_resource_prefix1, "*"))},
      {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  // Receive LEDS request, and send an updated CDS response (removing previous
  // cluster and adding a new one).
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix1,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));
  const std::string cluster2_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                    "cluster2?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster2_resource = buildCluster(cluster2_name);
  const std::string endpoints2_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/cluster2";
  cluster2_resource.mutable_eds_cluster_config()->set_service_name(endpoints2_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster2_resource},
                                                             {cluster1_name}, "2");

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "1", {}, {}, {}));

  // Send the old LEDS response.
  const auto endpoint1_name_cluster1 = absl::StrCat(
      leds_resource_prefix1, "endpoint_0", "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name_cluster1 = absl::StrCat(
      leds_resource_prefix1, "endpoint_1", "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(
      Config::TestTypeUrl::get().LbEndpoint,
      {buildLbEndpointResource(endpoint1_name_cluster1, "2"),
       buildLbEndpointResource(endpoint2_name_cluster1, "2")},
      {});

  // Receive EDS request, and send ClusterLoadAssignment with one locality, that uses LEDS.
  const auto leds_resource_prefix2 =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints2/";
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {}, {endpoints2_name}, {endpoints1_name}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints2_name,
                                          absl::StrCat(leds_resource_prefix2, "*"))},
      {}, "2");

  // The server should remove interest in the old LEDS.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {}, {},
      {absl::StrCat(leds_resource_prefix1,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")}));

  // Receive CDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "2", {}, {}, {}));

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "2", {}, {}, {}));

  // Receive the new LEDS request and EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix2,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "2", {}, {}, {}));

  // Send 2 endpoints using LEDS.
  const auto endpoint1_name_cluster2 = absl::StrCat(
      leds_resource_prefix2, "endpoint_0", "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name_cluster2 = absl::StrCat(
      leds_resource_prefix2, "endpoint_1", "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(
      Config::TestTypeUrl::get().LbEndpoint,
      {buildLbEndpointResource(endpoint1_name_cluster2, "2"),
       buildLbEndpointResource(endpoint2_name_cluster2, "2")},
      {});

  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Ge(2));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {},
                              {"xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                               "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                              {}));

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "2", {}, {}, {}));
}

// Timeout on LEDS update activates the cluster.
TEST_P(XdsTpAdsIntegrationTest, LedsTimeout) {
  if (isSotw()) {
    // LEDS only works with the Delta protocol.
    return;
  }

  initialize();

  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();
  const auto leds_type_url = Config::getTypeUrl<envoy::config::endpoint::v3::LbEndpoint>();

  // Receive CDS request, and send a cluster with EDS.
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {},
                                      {"xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                                      {}, true));
  const std::string cluster_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                   "baz?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster_resource = buildCluster(cluster_name);
  const std::string endpoints_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/baz";
  cluster_resource.mutable_eds_cluster_config()->set_service_name(endpoints_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster_resource},
                                                             {}, "1");

  // Receive EDS request, and send ClusterLoadAssignment with one locality, that uses LEDS.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {}, {endpoints_name}, {}));
  const auto leds_resource_prefix =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints/";

  auto cla_with_leds =
      buildClusterLoadAssignmentWithLeds(endpoints_name, absl::StrCat(leds_resource_prefix, "*"));
  // Set a short timeout for the initial fetch.
  cla_with_leds.mutable_endpoints(0)
      ->mutable_leds_cluster_locality_config()
      ->mutable_leds_config()
      ->mutable_initial_fetch_timeout()
      ->set_nanos(100 * 1000 * 1000);
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {}, {cla_with_leds}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "1", {}, {}, {}));
  // Receive LEDS request, and wait for the initial fetch timeout.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix, "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));

  // The cluster should be warming. Wait until initial fetch timeout.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(1));

  test_server_->waitForCounter(
      "cluster.xdstp_test/envoy.config.cluster.v3.Cluster/foo-cluster/"
      "baz?xds.node.cluster=cluster_name&xds.node.id=node_name.leds.init_fetch_timeout",
      Eq(1));

  // After timeout the cluster should be active, not warming.
  test_server_->waitForGauge("cluster_manager.warming_clusters", Eq(0));
  test_server_->waitForGauge("cluster_manager.active_clusters", Eq(3));

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "1", {}, {}, {}));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {},
                              {"xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                               "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                              {}));
}

// Modifying a cluster to alternate use of EDS with and without LEDS.
TEST_P(XdsTpAdsIntegrationTest, EdsAlternatingLedsUsage) {
  if (isSotw()) {
    // LEDS only works with the Delta protocol.
    return;
  }

  initialize();

  const auto cds_type_url = Config::getTypeUrl<envoy::config::cluster::v3::Cluster>();
  const auto eds_type_url =
      Config::getTypeUrl<envoy::config::endpoint::v3::ClusterLoadAssignment>();
  const auto leds_type_url = Config::getTypeUrl<envoy::config::endpoint::v3::LbEndpoint>();

  // Receive CDS request, and send a cluster with EDS.
  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {},
                                      {"xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                       "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                                      {}, true));
  const std::string cluster_name = "xdstp://test/envoy.config.cluster.v3.Cluster/foo-cluster/"
                                   "baz?xds.node.cluster=cluster_name&xds.node.id=node_name";
  auto cluster_resource = buildCluster(cluster_name);
  const std::string endpoints_name =
      "xdstp://test/envoy.config.endpoint.v3.ClusterLoadAssignment/foo-cluster/baz";
  cluster_resource.mutable_eds_cluster_config()->set_service_name(endpoints_name);
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(cds_type_url, {}, {cluster_resource},
                                                             {}, "1");

  // Receive EDS request, and send ClusterLoadAssignment with one locality,
  // that doesn't use LEDS.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {},
                                      {endpoints_name}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {},
      {buildClusterLoadAssignment(endpoints_name)}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "1", {}, {}, {}));

  // LDS/RDS xDS initialization (LDS via xdstp:// glob collection)
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {},
                              {"xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                               "*?xds.node.cluster=cluster_name&xds.node.id=node_name"},
                              {}));
  const std::string route_name_0 =
      "xdstp://test/envoy.config.route.v3.RouteConfiguration/route_config_0";
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {},
      {buildListener("xdstp://test/envoy.config.listener.v3.Listener/foo-listener/"
                     "bar?xds.node.cluster=cluster_name&xds.node.id=node_name",
                     route_name_0)},
      {}, "1");

  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "1", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {},
                                      {route_name_0}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {},
      {buildRouteConfig(route_name_0, cluster_name)}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "1", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "1", {}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Eq(1));
  makeSingleRequest();

  // Send a new EDS update that uses LEDS.
  const auto leds_resource_prefix =
      "xdstp://test/envoy.config.endpoint.v3.LbEndpoint/foo-endpoints/";
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {},
      {buildClusterLoadAssignmentWithLeds(endpoints_name, absl::StrCat(leds_resource_prefix, "*"))},
      {}, "2");

  // Receive LEDS request.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {},
      {absl::StrCat(leds_resource_prefix, "*?xds.node.cluster=cluster_name&xds.node.id=node_name")},
      {}));

  // Make sure that traffic can still be sent to the endpoint (still using the
  // EDS without LEDS).
  makeSingleRequest();

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "2", {}, {}, {}));

  // Send LEDS response with 2 endpoints.
  const auto endpoint1_name = absl::StrCat(leds_resource_prefix, "endpoint_0",
                                           "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  const auto endpoint2_name = absl::StrCat(leds_resource_prefix, "endpoint_1",
                                           "?xds.node.cluster=cluster_name&xds.node.id=node_name");
  sendExplicitResourcesDeltaDiscoveryResponse(
      Config::TestTypeUrl::get().LbEndpoint,
      {buildLbEndpointResource(endpoint1_name, "1"), buildLbEndpointResource(endpoint2_name, "1")},
      {});

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "1", {}, {}, {}));

  // Make sure that traffic can still be sent to the endpoint (now using the
  // EDS with LEDS).
  makeSingleRequest();

  // Send a new EDS update that doesn't use LEDS.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {},
      {buildClusterLoadAssignment(endpoints_name)}, {}, "3");

  // The server should remove interest in the old LEDS.
  EXPECT_TRUE(compareDiscoveryRequest(
      leds_type_url, "", {}, {},
      {absl::StrCat(leds_resource_prefix,
                    "*?xds.node.cluster=cluster_name&xds.node.id=node_name")}));

  // Receive the EDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "3", {}, {}, {}));

  // Remove the LEDS endpoints.
  sendExplicitResourcesDeltaDiscoveryResponse(Config::TestTypeUrl::get().LbEndpoint, {},
                                              {endpoint1_name, endpoint2_name});

  // Receive the LEDS ack.
  EXPECT_TRUE(compareDiscoveryRequest(leds_type_url, "3", {}, {}, {}));

  // Make sure that traffic can still be sent to the endpoint (now using the
  // EDS without LEDS).
  makeSingleRequest();
}

// Make sure two listeners send only a single SRDS request.
TEST_P(AdsIntegrationTest, SrdsPausedDuringLds) {
  initialize();
  const auto lds_type_url = Config::TestTypeUrl::get().Listener;
  const auto cds_type_url = Config::TestTypeUrl::get().Cluster;
  const auto eds_type_url = Config::TestTypeUrl::get().ClusterLoadAssignment;
  const auto srds_type_url = Config::TestTypeUrl::get().ScopedRouteConfiguration;
  const auto rds_type_url = Config::TestTypeUrl::get().RouteConfiguration;

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster,
                                                             {buildCluster("cluster_0")},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "", {"cluster_0"}, {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      eds_type_url, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(cds_type_url, "1", {}, {}, {}));

  std::vector<envoy::config::listener::v3::Listener> listeners;
  const std::string hcm = R"EOF(
        filters:
        - name: http
          typed_config:
            "@type": type.googleapis.com/envoy.extensions.filters.network.http_connection_manager.v3.HttpConnectionManager
            codec_type: HTTP2
            stat_prefix: ads_test
            scoped_routes:
              name: scoped_routes
              scope_key_builder:
                fragments:
                - header_value_extractor:
                    name: X-Route-Selector
                    element_separator: ","
                    element:
                      separator: =
                      key: vip
              rds_config_source:
                ads: {}
              scoped_rds:
                scoped_rds_config_source:
                  ads: {}
            http_filters:
            - name: envoy.filters.http.router
              typed_config:
                "@type": type.googleapis.com/envoy.extensions.filters.http.router.v3.Router
    )EOF";
  for (int i = 0; i < 2; ++i) {
    auto listener = ConfigHelper::buildBaseListener(
        "listener", Network::Test::getLoopbackAddressString(ipVersion()), hcm);
    listener.set_name(absl::StrCat("listener_", i));
    listeners.push_back(std::move(listener));
  }

  EXPECT_TRUE(compareDiscoveryRequest(lds_type_url, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(lds_type_url, listeners, listeners,
                                                               {}, "1");

  test_server_->waitForCounter("listener_manager.listener_added", Eq(2));

  EXPECT_TRUE(compareDiscoveryRequest(eds_type_url, "1", {}, {}, {}));

  // Expect a single request for SRDS resources.
  EXPECT_TRUE(compareDiscoveryRequest(srds_type_url, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(lds_type_url, "1", {}, {}, {}));

  std::vector<envoy::config::route::v3::ScopedRouteConfiguration> scoped_route_configs;
  for (int i = 0; i < 2; ++i) {
    envoy::config::route::v3::ScopedRouteConfiguration scoped_route;
    TestUtility::loadFromYaml(fmt::format(
                                  R"EOF(
        name: scoped_route_{}
        route_configuration_name: route_{}
        key:
          fragments:
          - string_key: ip_{}
      )EOF",
                                  i, i, i),
                              scoped_route);
    scoped_route_configs.push_back(scoped_route);
  }

  sendDiscoveryResponse<envoy::config::route::v3::ScopedRouteConfiguration>(
      srds_type_url, scoped_route_configs, scoped_route_configs, {}, "1");

  EXPECT_TRUE(compareDiscoveryRequest(rds_type_url, "", {"route_0", "route_1"},
                                      {"route_0", "route_1"}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(srds_type_url, "1", {}, {}, {}));

  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      rds_type_url,
      {buildRouteConfig("route_0", "cluster_0"), buildRouteConfig("route_1", "cluster_0")},
      {buildRouteConfig("route_0", "cluster_0"), buildRouteConfig("route_1", "cluster_0")}, {},
      "1");

  EXPECT_TRUE(compareDiscoveryRequest(rds_type_url, "1", {"route_0", "route_1"}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Eq(2));
}

// ADS integration tests that exercise the ADS-replacement mechanism.
class AdsReplacementIntegrationTest : public AdsIntegrationTest {
public:
  AdsReplacementIntegrationTest() = default;

  void createXdsUpstream() override {
    // Create the first ADS upstream.
    AdsIntegrationTest::createXdsUpstream();
    // Create the second (replacement) ADS upstream.
    if (tls_xds_upstream_ == false) {
      addFakeUpstream(Http::CodecType::HTTP2);
    } else {
      envoy::extensions::transport_sockets::tls::v3::DownstreamTlsContext tls_context;
      auto* common_tls_context = tls_context.mutable_common_tls_context();
      common_tls_context->add_alpn_protocols(Http::Utility::AlpnNames::get().Http2);
      auto* tls_cert = common_tls_context->add_tls_certificates();
      tls_cert->mutable_certificate_chain()->set_filename(
          TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcert.pem"));
      tls_cert->mutable_private_key()->set_filename(
          TestEnvironment::runfilesPath("test/config/integration/certs/upstreamkey.pem"));
      auto cfg = *Extensions::TransportSockets::Tls::ServerContextConfigImpl::create(
          tls_context, factory_context_, {}, false);

      // upstream_stats_store_ was initialized by AdsIntegrationTest::createXdsUpstream().
      ASSERT(upstream_stats_store_ != nullptr);
      auto context = *Extensions::TransportSockets::Tls::ServerSslSocketFactory::create(
          std::move(cfg), context_manager_, *upstream_stats_store_->rootScope());
      addFakeUpstream(std::move(context), Http::CodecType::HTTP2, /*autonomous_upstream=*/false);
    }
    second_xds_upstream_ = fake_upstreams_.back().get();
  }

  // Initializes the replacement ADS stream.
  void initSecondAds() {
    AssertionResult result =
        second_xds_upstream_->waitForHttpConnection(*dispatcher_, second_xds_connection_);
    RELEASE_ASSERT(result, result.message());
    result = xds_connection_->waitForNewStream(*dispatcher_, second_xds_stream_);
    RELEASE_ASSERT(result, result.message());
    second_xds_stream_->startGrpcStream();
  }

  void initializeTwoAds() {
    config_helper_.addConfigModifier([this](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* ads_config = bootstrap.mutable_dynamic_resources()->mutable_ads_config();
      auto* grpc_service = ads_config->add_grpc_services();
      setGrpcService(*grpc_service, "ads_cluster", xds_upstream_->localAddress());
      auto* ads_cluster = bootstrap.mutable_static_resources()->add_clusters();
      ads_cluster->MergeFrom(bootstrap.static_resources().clusters()[0]);
      ads_cluster->set_name("ads_cluster");
      envoy::extensions::transport_sockets::tls::v3::UpstreamTlsContext context;
      auto* validation_context = context.mutable_common_tls_context()->mutable_validation_context();
      validation_context->mutable_trusted_ca()->set_filename(
          TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcacert.pem"));
      auto* san_matcher = validation_context->add_match_typed_subject_alt_names();
      san_matcher->mutable_matcher()->set_suffix("lyft.com");
      san_matcher->set_san_type(
          envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::DNS);
      if (clientType() == Grpc::ClientType::GoogleGrpc) {
        auto* google_grpc = grpc_service->mutable_google_grpc();
        auto* ssl_creds = google_grpc->mutable_channel_credentials()->mutable_ssl_credentials();
        ssl_creds->mutable_root_certs()->set_filename(
            TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcacert.pem"));
      }
      ads_cluster->mutable_transport_socket()->set_name("envoy.transport_sockets.tls");
      std::ignore =
          ads_cluster->mutable_transport_socket()->mutable_typed_config()->PackFrom(context);

      // Add the second ADS cluster (copy the ads_cluster and update its name).
      auto* second_ads_cluster = bootstrap.mutable_static_resources()->add_clusters();
      second_ads_cluster->MergeFrom(bootstrap.static_resources().clusters()[1]);
      second_ads_cluster->set_name("second_ads_cluster");
    });
    HttpIntegrationTest::initialize();
    if (xds_stream_ == nullptr) {
      createXdsConnection();
      AssertionResult result = xds_connection_->waitForNewStream(*dispatcher_, xds_stream_);
      RELEASE_ASSERT(result, result.message());
      xds_stream_->startGrpcStream();
    }
  }

  void cleanUpSecondXdsConnection() {
    // Cleanup the second xds connection if used.
    if (second_xds_connection_ != nullptr) {
      AssertionResult result = second_xds_connection_->close();
      RELEASE_ASSERT(result, result.message());
      result = second_xds_connection_->waitForDisconnect();
      RELEASE_ASSERT(result, result.message());
      second_xds_connection_.reset();
    }
  }

  void TearDown() override {
    cleanUpSecondXdsConnection();
    AdsIntegrationTest::TearDown();
  }

  // Second ADS stream.
  FakeUpstream* second_xds_upstream_{};
  FakeHttpConnectionPtr second_xds_connection_;
  FakeStreamPtr second_xds_stream_;
};

INSTANTIATE_TEST_SUITE_P(IpVersionsClientTypeDeltaWildcard, AdsReplacementIntegrationTest,
                         ADS_INTEGRATION_PARAMS,
                         AdsReplacementIntegrationTest::protocolTestParamsToString);

TEST_P(AdsReplacementIntegrationTest, ReplaceAdsConfig) {
  initializeTwoAds();

  // Check that the node is sent in each request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("cluster_0")}, {buildCluster("cluster_0")},
      {}, "original1");

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "",
                                      {"cluster_0"}, {"cluster_0"}, {}, false));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {buildClusterLoadAssignment("cluster_0")},
      {buildClusterLoadAssignment("cluster_0")}, {}, "original1");

  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "original1", {}, {}, {}, false));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}, false));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "original1",
                                      {"cluster_0"}, {}, {}, false));

  // Prepare the second ADS server config.
  envoy::config::core::v3::ApiConfigSource new_ads_config;
  new_ads_config.set_api_type((sotwOrDelta() == Grpc::SotwOrDelta::Sotw) ||
                                      (sotwOrDelta() == Grpc::SotwOrDelta::UnifiedSotw)
                                  ? envoy::config::core::v3::ApiConfigSource::GRPC
                                  : envoy::config::core::v3::ApiConfigSource::DELTA_GRPC);
  new_ads_config.set_set_node_on_first_message_only(true);
  auto* grpc_service = new_ads_config.add_grpc_services();
  if (clientType() == Grpc::ClientType::GoogleGrpc) {
    auto* google_grpc = grpc_service->mutable_google_grpc();
    auto* ssl_creds = google_grpc->mutable_channel_credentials()->mutable_ssl_credentials();
    ssl_creds->mutable_root_certs()->set_filename(
        TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcacert.pem"));
  }
  setGrpcService(*grpc_service, "second_ads_cluster", second_xds_upstream_->localAddress());

  // Replace the ADS config.
  test_server_->setAdsConfigSource(new_ads_config);

  // Expect a reset from the first xDS source.
  EXPECT_TRUE(xds_stream_->waitForReset());

  // Allow a connection to the second xDS source.
  AssertionResult result =
      second_xds_upstream_->waitForHttpConnection(*dispatcher_, second_xds_connection_);
  RELEASE_ASSERT(result, result.message());
  result = second_xds_connection_->waitForNewStream(*dispatcher_, second_xds_stream_);
  RELEASE_ASSERT(result, result.message());
  second_xds_stream_->startGrpcStream();

  const absl::flat_hash_map<std::string, std::string> cds_eds_initial_resource_versions_map{
      {"cluster_0", "original1"}};
  const absl::flat_hash_map<std::string, std::string> empty_initial_resource_versions_map;
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true,
                                      Grpc::Status::WellKnownGrpcStatus::Ok, "",
                                      second_xds_stream_.get(),
                                      makeOptRef(cds_eds_initial_resource_versions_map)));
  EXPECT_TRUE(compareDiscoveryRequest(
      Config::TestTypeUrl::get().ClusterLoadAssignment, "", {"cluster_0"}, {"cluster_0"}, {}, false,
      Grpc::Status::WellKnownGrpcStatus::Ok, "", second_xds_stream_.get(),
      makeOptRef(cds_eds_initial_resource_versions_map)));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}, false,
                                      Grpc::Status::WellKnownGrpcStatus::Ok, "",
                                      second_xds_stream_.get(),
                                      makeOptRef(empty_initial_resource_versions_map)));
  // Send a CDS response with new resources.
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(
      Config::TestTypeUrl::get().Cluster, {buildCluster("replaced_cluster")},
      {buildCluster("replaced_cluster")}, {}, "replaced1", {}, second_xds_stream_.get());

  // Wait for an updated EDS request.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "original1",
                                      {"replaced_cluster"}, {"replaced_cluster"}, {}, false,
                                      Grpc::Status::WellKnownGrpcStatus::Ok, "",
                                      second_xds_stream_.get()));
  // Send an EDS response.
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment,
      {buildClusterLoadAssignment("replaced_cluster")},
      {buildClusterLoadAssignment("replaced_cluster")}, {}, "replaced1", {},
      second_xds_stream_.get());

  // Wait for a CDS and EDS ACKs.
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "replaced1", {}, {}, {},
                                      false, Grpc::Status::WellKnownGrpcStatus::Ok, "",
                                      second_xds_stream_.get()));
  EXPECT_TRUE(compareDiscoveryRequest(
      Config::TestTypeUrl::get().ClusterLoadAssignment, "replaced1", {"replaced_cluster_1"}, {}, {},
      false, Grpc::Status::WellKnownGrpcStatus::Ok, "", second_xds_stream_.get()));

  // Continue with LDS and RDS, and send a request-response.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {buildListener("listener_0", "route_config_0")},
      {buildListener("listener_0", "route_config_0")}, {}, "replaced1", {},
      second_xds_stream_.get());
  EXPECT_TRUE(compareDiscoveryRequest(
      Config::TestTypeUrl::get().RouteConfiguration, "", {"route_config_0"}, {"route_config_0"}, {},
      false, Grpc::Status::WellKnownGrpcStatus::Ok, "", second_xds_stream_.get()));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration,
      {buildRouteConfig("route_config_0", "replaced_cluster")},
      {buildRouteConfig("route_config_0", "replaced_cluster")}, {}, "replaced1", {},
      second_xds_stream_.get());
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "replaced1", {}, {}, {},
                                      false, Grpc::Status::WellKnownGrpcStatus::Ok, "",
                                      second_xds_stream_.get()));
  EXPECT_TRUE(compareDiscoveryRequest(
      Config::TestTypeUrl::get().RouteConfiguration, "replaced1", {"route_config_0"}, {}, {}, false,
      Grpc::Status::WellKnownGrpcStatus::Ok, "", second_xds_stream_.get()));

  makeSingleRequest();
}

// Tests the following scenarios:
// - Multiple VHDS resources for the same route can be sent over ADS.
// - Removal of one listener doesn't impact another that references the same vhost over the same
// route config.
// - Removal of one vhost doesn't impact another vhost in the same route config.
// - Removal of a vhost from one route config doesn't impact the same vhost in another route config.
TEST_P(AdsIntegrationTest, MultipleVhdsOverAds) {
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Delta &&
      sotw_or_delta_ != Grpc::SotwOrDelta::UnifiedDelta) {
    GTEST_SKIP_("This test is for delta only");
  }
  initialize();

  // Send initial configuration that sets up 3 listeners with the following vhosts:
  // listener_0 -> route_config_0/foo
  // listener_0 -> route_config_0/bar
  // listener_1 -> route_config_0/foo
  // listener_1 -> route_config_0/bar
  // listener_2 -> route_config_1/foo
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster, {},
                                                             {
                                                                 buildCluster("cluster_0"),
                                                                 buildCluster("cluster_1"),
                                                             },
                                                             {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {},
                                      {"cluster_0", "cluster_1"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {},
      {buildClusterLoadAssignment("cluster_0"), buildClusterLoadAssignment("cluster_1")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {},
      {buildListener("listener_0", "route_config_0"),
       buildListener("listener_1", "route_config_0")},
      {}, "1");

  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {},
                                      {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {},
      {buildRouteConfigWithVhds("route_config_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {}, {}, {}));

  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {}, {buildListener("listener_2", "route_config_1")}, {},
      "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {},
                                      {"route_config_1"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {},
      {buildRouteConfigWithVhds("route_config_1")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {}, {}, {}));

  sendDiscoveryResponse<envoy::config::route::v3::VirtualHost>(
      Config::TestTypeUrl::get().VirtualHost, {},
      {buildVirtualHost("route_config_0/foo", "foo.com", "/foo", "cluster_0"),
       buildVirtualHost("route_config_0/bar", "bar.com", "/bar", "cluster_0"),
       buildVirtualHost("route_config_1/foo", "foo.com", "/foo", "cluster_1")},
      {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));

  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(3));

  auto foo_request_headers = Http::TestRequestHeaderMapImpl{
      {":method", "GET"}, {":path", "/foo"}, {":scheme", "http"}, {":authority", "foo.com"}};
  auto bar_request_headers = Http::TestRequestHeaderMapImpl{
      {":method", "GET"}, {":path", "/bar"}, {":scheme", "http"}, {":authority", "bar.com"}};
  registerTestServerPorts({"http0", "http1", "http2"});

  auto send_request_and_verify = [this](const std::string& port_name,
                                        const Http::TestRequestHeaderMapImpl& headers,
                                        bool verify_404 = false) {
    codec_client_ = makeHttpConnection(makeClientConnection((lookupPort(port_name))));
    if (verify_404) {
      auto response = codec_client_->makeHeaderOnlyRequest(headers);
      ASSERT_TRUE(response->waitForEndStream());
      EXPECT_EQ("404", response->headers().getStatusValue());
    } else {
      auto response = sendRequestAndWaitForResponse(headers, 0, default_response_headers_, 0, 0);
      checkSimpleRequestSuccess(0U, 0U, response.get());
    }
    cleanupUpstreamAndDownstream();
  };

  // Verify all vhosts across all listeners are correctly configured.
  send_request_and_verify("http0", foo_request_headers);
  send_request_and_verify("http0", bar_request_headers);
  send_request_and_verify("http1", foo_request_headers);
  send_request_and_verify("http1", bar_request_headers);
  send_request_and_verify("http2", foo_request_headers);

  // Verify that removing listener_0 doesn't impact listener_1 that also references
  // route_config_0/foo and route_config_0/bar.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(Config::TestTypeUrl::get().Listener,
                                                               {}, {}, {"listener_0"}, "1");
  send_request_and_verify("http1", foo_request_headers);
  send_request_and_verify("http1", bar_request_headers);

  // Verify that removing route_config_0/foo makes foo.com unreachable but bar.com is still
  // reachable from listener_1.
  sendDiscoveryResponse<envoy::config::route::v3::VirtualHost>(
      Config::TestTypeUrl::get().VirtualHost, {}, {}, {"route_config_0/foo"}, "1");

  test_server_->waitForCounter("http.ads_test.rds.vhds.route_config_0.config_reload", Ge(2));

  send_request_and_verify("http1", foo_request_headers, true);
  send_request_and_verify("http1", bar_request_headers);

  // Verify that listener_2 is unaffected and continues to work.
  send_request_and_verify("http2", foo_request_headers);
}

// Verifies that when two listeners are using the same route with VHDS resource and after one of the
// listeners is removed, the other listener continues to receive updates on that VHDS resource.
TEST_P(AdsIntegrationTest, VHDSUpdatesAfterListenerRemoval) {
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Delta &&
      sotw_or_delta_ != Grpc::SotwOrDelta::UnifiedDelta) {
    GTEST_SKIP_("This test is for delta only");
  }
  initialize();

  // Send initial configuration that sets up two listeners with the following vhosts:
  // listener_0 -> route_config_0/foo
  // listener_1 -> route_config_0/foo
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster, {},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {},
                                      {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {},
      {buildListener("listener_0", "route_config_0"),
       buildListener("listener_1", "route_config_0")},
      {}, "1");

  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {},
                                      {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {},
      {buildRouteConfigWithVhds("route_config_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {}, {}, {}));

  sendDiscoveryResponse<envoy::config::route::v3::VirtualHost>(
      Config::TestTypeUrl::get().VirtualHost, {},
      {buildVirtualHost("route_config_0/foo", "foo.com", "/foo", "cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));
  registerTestServerPorts({"http0", "http1"});

  auto send_request_and_verify = [this](const std::string& port_name,
                                        const Http::TestRequestHeaderMapImpl& headers,
                                        bool verify_404 = false) {
    codec_client_ = makeHttpConnection(makeClientConnection((lookupPort(port_name))));
    if (verify_404) {
      auto response = codec_client_->makeHeaderOnlyRequest(headers);
      ASSERT_TRUE(response->waitForEndStream());
      EXPECT_EQ("404", response->headers().getStatusValue());
    } else {
      auto response = sendRequestAndWaitForResponse(headers, 0, default_response_headers_, 0, 0);
      checkSimpleRequestSuccess(0U, 0U, response.get());
    }
    cleanupUpstreamAndDownstream();
  };

  send_request_and_verify("http0", Http::TestRequestHeaderMapImpl{{":method", "GET"},
                                                                  {":path", "/foo"},
                                                                  {":scheme", "http"},
                                                                  {":authority", "foo.com"}});
  send_request_and_verify("http1", Http::TestRequestHeaderMapImpl{{":method", "GET"},
                                                                  {":path", "/foo"},
                                                                  {":scheme", "http"},
                                                                  {":authority", "foo.com"}});
  codec_client_->close();

  // Remove listener_1 and verify that listener_0 continues to receive VHDS updates.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(Config::TestTypeUrl::get().Listener,
                                                               {}, {}, {"listener_1"}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  test_server_->waitForGauge("listener_manager.total_listeners_draining", Eq(0));

  // Verify that listener_0 still works.
  send_request_and_verify("http0", Http::TestRequestHeaderMapImpl{{":method", "GET"},
                                                                  {":path", "/foo"},
                                                                  {":scheme", "http"},
                                                                  {":authority", "foo.com"}});

  // Send VHDS update to change the domain and path to bar.com and verify that requests to foo.com
  // now fail while requests to bar.com pass.
  sendDiscoveryResponse<envoy::config::route::v3::VirtualHost>(
      Config::TestTypeUrl::get().VirtualHost, {},
      {buildVirtualHost("route_config_0/foo", "bar.com", "/bar", "cluster_0")}, {}, "2");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  send_request_and_verify(
      "http0",
      Http::TestRequestHeaderMapImpl{
          {":method", "GET"}, {":path", "/foo"}, {":scheme", "http"}, {":authority", "foo.com"}},
      true);
  send_request_and_verify("http0", Http::TestRequestHeaderMapImpl{{":method", "GET"},
                                                                  {":path", "/bar"},
                                                                  {":scheme", "http"},
                                                                  {":authority", "bar.com"}});
}

// Tests that when a new listener arrives referencing an existing route config, it doesn't request
// for new route config resources and instead uses the local copy.
TEST_P(AdsIntegrationTest, NewListenerUsesLocalRouteConfig) {
  if (sotw_or_delta_ != Grpc::SotwOrDelta::Delta &&
      sotw_or_delta_ != Grpc::SotwOrDelta::UnifiedDelta) {
    GTEST_SKIP_("This test is for delta only");
  }
  initialize();

  // Send initial configuration that sets up 1 listeners with the following vhosts:
  // listener_0 -> route_config_0/foo
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}, true));
  sendDiscoveryResponse<envoy::config::cluster::v3::Cluster>(Config::TestTypeUrl::get().Cluster, {},
                                                             {buildCluster("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {},
                                      {"cluster_0"}, {}));
  sendDiscoveryResponse<envoy::config::endpoint::v3::ClusterLoadAssignment>(
      Config::TestTypeUrl::get().ClusterLoadAssignment, {},
      {buildClusterLoadAssignment("cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Cluster, "", {}, {}, {}));

  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {}, {buildListener("listener_0", "route_config_0")}, {},
      "1");

  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().ClusterLoadAssignment, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {},
                                      {"route_config_0"}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::RouteConfiguration>(
      Config::TestTypeUrl::get().RouteConfiguration, {},
      {buildRouteConfigWithVhds("route_config_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  EXPECT_TRUE(
      compareDiscoveryRequest(Config::TestTypeUrl::get().RouteConfiguration, "", {}, {}, {}));
  sendDiscoveryResponse<envoy::config::route::v3::VirtualHost>(
      Config::TestTypeUrl::get().VirtualHost, {},
      {buildVirtualHost("route_config_0/foo", "foo.com", "/foo", "cluster_0")}, {}, "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().VirtualHost, "", {}, {}, {}));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(1));
  registerTestServerPorts({"http0"});
  codec_client_ = makeHttpConnection(makeClientConnection((lookupPort("http0"))));
  auto response = sendRequestAndWaitForResponse(
      Http::TestRequestHeaderMapImpl{
          {":method", "GET"}, {":path", "/foo"}, {":scheme", "http"}, {":authority", "foo.com"}},
      0, default_response_headers_, 0, 0);
  checkSimpleRequestSuccess(0U, 0U, response.get());
  cleanupUpstreamAndDownstream();

  // Create new listener (listener_1) using the same route config (route_config_0) that shouldn't
  // request for VHDS again and use the local copy.
  sendDiscoveryResponse<envoy::config::listener::v3::Listener>(
      Config::TestTypeUrl::get().Listener, {}, {buildListener("listener_1", "route_config_0")}, {},
      "1");
  EXPECT_TRUE(compareDiscoveryRequest(Config::TestTypeUrl::get().Listener, "", {}, {}, {}));
  test_server_->waitForCounter("listener_manager.listener_create_success", Ge(2));
  registerTestServerPorts({"http0", "http1"});
  codec_client_ = makeHttpConnection(makeClientConnection((lookupPort("http1"))));
  response = sendRequestAndWaitForResponse(
      Http::TestRequestHeaderMapImpl{
          {":method", "GET"}, {":path", "/foo"}, {":scheme", "http"}, {":authority", "foo.com"}},
      0, default_response_headers_, 0, 0);
  checkSimpleRequestSuccess(0U, 0U, response.get());
  cleanupUpstreamAndDownstream();
}

} // namespace Envoy
