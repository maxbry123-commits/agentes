#include <string>

#include "envoy/config/metrics/v3/stats.pb.h"
#include "envoy/stats/stats_macros.h"

#include "source/common/stats/isolated_store_impl.h"
#include "source/common/stats/null_counter.h"
#include "source/common/stats/null_gauge.h"
#include "source/common/stats/stats_matcher_impl.h"

#include "test/mocks/server/server_factory_context.h"

#include "absl/strings/str_cat.h"
#include "absl/strings/string_view.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"

namespace Envoy {
namespace Stats {

class StatsIsolatedStoreImplTest : public testing::Test {
protected:
  StatsIsolatedStoreImplTest()
      : store_(std::make_unique<IsolatedStoreImpl>(symbol_table_)), pool_(symbol_table_),
        scope_(store_->rootScope()) {}
  ~StatsIsolatedStoreImplTest() override {
    pool_.clear();
    scope_.reset();
    store_.reset();
    EXPECT_EQ(0, symbol_table_.numSymbols());
  }

  StatName makeStatName(absl::string_view name) { return pool_.add(name); }

  SymbolTableImpl symbol_table_;
  std::unique_ptr<IsolatedStoreImpl> store_;
  StatNamePool pool_;
  ScopeSharedPtr scope_;
};

TEST_F(StatsIsolatedStoreImplTest, All) {
  EXPECT_TRUE(store_->fixedTags().empty());
  ScopeSharedPtr scope1 = scope_->createScope("scope1.");
  Counter& c1 = scope_->counterFromString("c1");
  Counter& c2 = scope1->counterFromString("c2");
  EXPECT_EQ("c1", c1.name());
  EXPECT_EQ("scope1.c2", c2.name());
  EXPECT_EQ("c1", c1.tagExtractedName());
  EXPECT_EQ("scope1.c2", c2.tagExtractedName());
  EXPECT_EQ(0, c1.tags().size());
  EXPECT_EQ(0, c1.tags().size());
  CounterOptConstRef opt_counter = scope1->findCounter(c2.statName());
  ASSERT_TRUE(opt_counter);
  EXPECT_EQ(&c2, &opt_counter->get());
  StatName not_found = pool_.add("not_found");
  EXPECT_FALSE(scope1->findCounter(not_found));

  StatNameManagedStorage c1_name("c1", store_->symbolTable());
  c1.add(100);
  auto found_counter = scope_->findCounter(c1_name.statName());
  ASSERT_TRUE(found_counter.has_value());
  EXPECT_EQ(&c1, &found_counter->get());
  EXPECT_EQ(100, found_counter->get().value());
  c1.add(100);
  EXPECT_EQ(200, found_counter->get().value());

  Gauge& g1 = scope_->gaugeFromString("g1", Gauge::ImportMode::Accumulate);
  Gauge& g2 = scope1->gaugeFromString("g2", Gauge::ImportMode::Accumulate);
  EXPECT_EQ("g1", g1.name());
  EXPECT_EQ("scope1.g2", g2.name());
  EXPECT_EQ("g1", g1.tagExtractedName());
  EXPECT_EQ("scope1.g2", g2.tagExtractedName());
  EXPECT_EQ(0, g1.tags().size());
  EXPECT_EQ(0, g2.tags().size());
  GaugeOptConstRef opt_gauge = scope1->findGauge(g2.statName());
  ASSERT_TRUE(opt_gauge);
  EXPECT_EQ(&g2, &opt_gauge->get());
  EXPECT_FALSE(scope1->findGauge(not_found));
  // TODO(jmarantz): There may be a bug with
  // scope1->findGauge(h1.statName()), which finds the histogram added to
  // the store, which is arguably not in the scope. Investigate what the
  // behavior should be.

  StatNameManagedStorage g1_name("g1", store_->symbolTable());
  g1.set(100);
  auto found_gauge = scope_->findGauge(g1_name.statName());
  ASSERT_TRUE(found_gauge.has_value());
  EXPECT_EQ(&g1, &found_gauge->get());
  EXPECT_EQ(100, found_gauge->get().value());
  g1.set(0);
  EXPECT_EQ(0, found_gauge->get().value());

  Histogram& h1 = scope_->histogramFromString("h1", Stats::Histogram::Unit::Unspecified);
  EXPECT_TRUE(h1.used()); // hardcoded in impl to be true always.
  EXPECT_TRUE(h1.use_count() == 1);
  Histogram& h2 = scope1->histogramFromString("h2", Stats::Histogram::Unit::Unspecified);
  store_->deliverHistogramToSinks(h2, 0);
  EXPECT_EQ("h1", h1.name());
  EXPECT_EQ("scope1.h2", h2.name());
  EXPECT_EQ("h1", h1.tagExtractedName());
  EXPECT_EQ("scope1.h2", h2.tagExtractedName());
  EXPECT_EQ(0, h1.tags().size());
  EXPECT_EQ(0, h2.tags().size());
  h1.recordValue(200);
  h2.recordValue(200);
  HistogramOptConstRef opt_histogram = scope1->findHistogram(h2.statName());
  ASSERT_TRUE(opt_histogram);
  EXPECT_EQ(&h2, &opt_histogram->get());
  EXPECT_FALSE(scope1->findHistogram(not_found));
  // TODO(jmarantz): There may be a bug with
  // scope1->findHistogram(h1.statName()), which finds the histogram added to
  // the store, which is arguably not in the scope. Investigate what the
  // behavior should be.

  StatNameManagedStorage h1_name("h1", store_->symbolTable());
  auto found_histogram = scope_->findHistogram(h1_name.statName());
  ASSERT_TRUE(found_histogram.has_value());
  EXPECT_EQ(&h1, &found_histogram->get());

  ScopeSharedPtr scope2 = scope1->scopeFromStatName(makeStatName("foo."));
  EXPECT_EQ("scope1.foo.bar", scope2->counterFromString("bar").name());

  // Validate that we sanitize away bad characters in the stats prefix.
  ScopeSharedPtr scope3 = scope1->createScope(std::string("foo:\0:.", 7));
  EXPECT_EQ("scope1.foo___.bar", scope3->counterFromString("bar").name());

  EXPECT_EQ(4UL, store_->counters().size());
  EXPECT_EQ(2UL, store_->gauges().size());

  StatNameManagedStorage nonexistent_name("nonexistent", store_->symbolTable());
  EXPECT_EQ(scope_->findCounter(nonexistent_name.statName()), std::nullopt);
  EXPECT_EQ(scope_->findGauge(nonexistent_name.statName()), std::nullopt);
  EXPECT_EQ(scope_->findHistogram(nonexistent_name.statName()), std::nullopt);
}

TEST_F(StatsIsolatedStoreImplTest, CleanupCallback) {
  bool called = false;
  {
    IsolatedStoreImpl local_store(symbol_table_);
    ScopeSharedPtr scope1 = local_store.rootScope()->createScope("scope1.");
    scope1->setCleanupCallback([&called]() { called = true; });
  }
  EXPECT_TRUE(called);
}

TEST_F(StatsIsolatedStoreImplTest, PrefixIsStatName) {
  ScopeSharedPtr scope1 = scope_->createScope("scope1");
  ScopeSharedPtr scope2 = scope1->scopeFromStatName(makeStatName("scope2"));
  Counter& c1 = scope2->counterFromString("c1");
  EXPECT_EQ("scope1.scope2.c1", c1.name());
}

// When scopeFromStatName / createScope is called with name_tags but no explicit `tagged_name`, the
// joiner derives the child's flat prefix by appending the tag name/value pairs to the
// tag-extracted name. IsolatedScopeImpl does not retain the tags afterwards, so subsequent
// stats see no propagated tag metadata.
TEST_F(StatsIsolatedStoreImplTest, ScopeFromTagsWithoutExplicitTaggedName) {
  StatNameTagVector name_tags{{makeStatName("cluster_name"), makeStatName("foo")}};
  ScopeSharedPtr cluster_scope =
      scope_->scopeFromTaggedName(makeStatName("cluster"), StatNameTagSpan(name_tags), StatName());
  EXPECT_EQ("cluster.cluster_name.foo", symbol_table_.toString(cluster_scope->prefix()));

  Counter& c = cluster_scope->counterFromString("upstream_rq");
  EXPECT_EQ("cluster.cluster_name.foo.upstream_rq", c.name());
  EXPECT_EQ("cluster.cluster_name.foo.upstream_rq", c.tagExtractedName());
  EXPECT_EQ(0, c.tags().size());

  // Same behavior via the string-view createScope path.
  std::vector<TagStringView> sv_tags{{"cluster_name", "bar"}};
  ScopeSharedPtr bar_scope =
      scope_->createScopeWithTaggedName("cluster", sv_tags, /*tagged_name=*/"");
  EXPECT_EQ("cluster.cluster_name.bar", symbol_table_.toString(bar_scope->prefix()));
  EXPECT_EQ("cluster.cluster_name.bar.upstream_rq",
            bar_scope->counterFromString("upstream_rq").name());
}

TEST_F(StatsIsolatedStoreImplTest, AllWithSymbolTable) {
  ScopeSharedPtr scope1 = scope_->createScope("scope1.");
  Counter& c1 = scope_->counterFromStatName(makeStatName("c1"));
  Counter& c2 = scope1->counterFromStatName(makeStatName("c2"));
  EXPECT_EQ("c1", c1.name());
  EXPECT_EQ("scope1.c2", c2.name());
  EXPECT_EQ("c1", c1.tagExtractedName());
  EXPECT_EQ("scope1.c2", c2.tagExtractedName());
  EXPECT_EQ(0, c1.tags().size());
  EXPECT_EQ(0, c1.tags().size());

  Gauge& g1 = scope_->gaugeFromStatName(makeStatName("g1"), Gauge::ImportMode::Accumulate);
  Gauge& g2 = scope1->gaugeFromStatName(makeStatName("g2"), Gauge::ImportMode::Accumulate);
  EXPECT_EQ("g1", g1.name());
  EXPECT_EQ("scope1.g2", g2.name());
  EXPECT_EQ("g1", g1.tagExtractedName());
  EXPECT_EQ("scope1.g2", g2.tagExtractedName());
  EXPECT_EQ(0, g1.tags().size());
  EXPECT_EQ(0, g2.tags().size());

  TextReadout& b1 = scope_->textReadoutFromStatName(makeStatName("b1"));
  TextReadout& b2 = scope1->textReadoutFromStatName(makeStatName("b2"));
  EXPECT_NE(&b1, &b2);
  EXPECT_EQ("b1", b1.name());
  EXPECT_EQ("scope1.b2", b2.name());
  EXPECT_EQ("b1", b1.tagExtractedName());
  EXPECT_EQ("scope1.b2", b2.tagExtractedName());
  EXPECT_EQ(0, b1.tags().size());
  EXPECT_EQ(0, b2.tags().size());
  Histogram& h1 =
      scope_->histogramFromStatName(makeStatName("h1"), Stats::Histogram::Unit::Unspecified);
  Histogram& h2 =
      scope1->histogramFromStatName(makeStatName("h2"), Stats::Histogram::Unit::Unspecified);
  store_->deliverHistogramToSinks(h2, 0);
  EXPECT_EQ("h1", h1.name());
  EXPECT_EQ("scope1.h2", h2.name());
  EXPECT_EQ("h1", h1.tagExtractedName());
  EXPECT_EQ("scope1.h2", h2.tagExtractedName());
  EXPECT_EQ(0, h1.tags().size());
  EXPECT_EQ(0, h2.tags().size());
  h1.recordValue(200);
  h2.recordValue(200);

  ScopeSharedPtr scope2 = scope1->createScope("foo.");
  EXPECT_EQ("scope1.foo.bar", scope2->counterFromStatName(makeStatName("bar")).name());

  // Validate that we sanitize away bad characters in the stats prefix.
  ScopeSharedPtr scope3 = scope1->createScope(std::string("foo:\0:.", 7));
  EXPECT_EQ("scope1.foo___.bar", scope3->counterFromString("bar").name());

  EXPECT_EQ(4UL, store_->counters().size());
  EXPECT_EQ(2UL, store_->gauges().size());
  EXPECT_EQ(2UL, store_->textReadouts().size());
}

TEST_F(StatsIsolatedStoreImplTest, CounterWithTag) {
  StatNameTagVector tags{{makeStatName("tag1"), makeStatName("tag1Value")}};
  StatNameTagVector tags2{{makeStatName("tag1"), makeStatName("tag1Value2")}};
  StatName base = makeStatName("counter");
  Counter& c1 = scope_->counterFromTaggedName(base, StatNameTagSpan(tags), {});
  Counter& c2 = scope_->counterFromTaggedName(base, StatNameTagSpan(tags2), {});
  EXPECT_EQ("counter.tag1.tag1Value", c1.name());
  EXPECT_EQ("counter", c1.tagExtractedName());
  EXPECT_THAT(c1.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value"}));
  EXPECT_EQ("counter.tag1.tag1Value2", c2.name());
  EXPECT_EQ("counter", c2.tagExtractedName());
  EXPECT_THAT(c2.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value2"}));
  // Verify that counterFromTaggedName with the same params returns the existing stat object.
  EXPECT_EQ(&c1, &scope_->counterFromTaggedName(base, StatNameTagSpan(tags), {}));
}

TEST_F(StatsIsolatedStoreImplTest, GaugeWithTags) {
  StatNameTagVector tags{{makeStatName("tag1"), makeStatName("tag1Value")},
                         {makeStatName("tag2"), makeStatName("tag2Value")}};
  // tags2 being a subset of tags to ensure no collision in that case.
  StatNameTagVector tags2{{makeStatName("tag2"), makeStatName("tag2Value")}};
  StatName base = makeStatName("gauge");
  Gauge& g1 =
      scope_->gaugeFromTaggedName(base, StatNameTagSpan(tags), {}, Gauge::ImportMode::Accumulate);
  Gauge& g2 =
      scope_->gaugeFromTaggedName(base, StatNameTagSpan(tags2), {}, Gauge::ImportMode::Accumulate);
  EXPECT_EQ("gauge.tag1.tag1Value.tag2.tag2Value", g1.name());
  EXPECT_EQ("gauge", g1.tagExtractedName());
  EXPECT_THAT(g1.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value"}, Tag{"tag2", "tag2Value"}));
  EXPECT_EQ("gauge.tag2.tag2Value", g2.name());
  EXPECT_EQ("gauge", g2.tagExtractedName());
  EXPECT_THAT(g2.tags(), testing::ElementsAre(Tag{"tag2", "tag2Value"}));
  // Verify that gaugeFromTaggedName with the same params returns the existing stat object.
  EXPECT_EQ(&g1, &scope_->gaugeFromTaggedName(base, StatNameTagSpan(tags), {},
                                              Gauge::ImportMode::Accumulate));
}

TEST_F(StatsIsolatedStoreImplTest, TextReadoutWithTag) {
  StatNameTagVector tags{{makeStatName("tag1"), makeStatName("tag1Value")}};
  StatNameTagVector tags2{{makeStatName("tag1"), makeStatName("tag1Value2")}};
  StatName base = makeStatName("textreadout");
  TextReadout& b1 = scope_->textReadoutFromTaggedName(base, StatNameTagSpan(tags), {});
  TextReadout& b2 = scope_->textReadoutFromTaggedName(base, StatNameTagSpan(tags2), {});
  EXPECT_EQ("textreadout.tag1.tag1Value", b1.name());
  EXPECT_EQ("textreadout", b1.tagExtractedName());
  EXPECT_THAT(b1.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value"}));
  EXPECT_EQ("textreadout.tag1.tag1Value2", b2.name());
  EXPECT_EQ("textreadout", b2.tagExtractedName());
  EXPECT_THAT(b2.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value2"}));
  // Verify that textReadoutFromTaggedName with the same params returns the existing stat object.
  EXPECT_EQ(&b1, &scope_->textReadoutFromTaggedName(base, StatNameTagSpan(tags), {}));
}

TEST_F(StatsIsolatedStoreImplTest, HistogramWithTag) {
  StatNameTagVector tags{{makeStatName("tag1"), makeStatName("tag1Value")}};
  StatNameTagVector tags2{{makeStatName("tag1"), makeStatName("tag1Value2")}};
  StatName base = makeStatName("histogram");
  Histogram& h1 = scope_->histogramFromTaggedName(base, StatNameTagSpan(tags), {},
                                                  Stats::Histogram::Unit::Unspecified);
  Histogram& h2 = scope_->histogramFromTaggedName(base, StatNameTagSpan(tags2), {},
                                                  Stats::Histogram::Unit::Unspecified);
  EXPECT_EQ("histogram.tag1.tag1Value", h1.name());
  EXPECT_EQ("histogram", h1.tagExtractedName());
  EXPECT_THAT(h1.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value"}));
  EXPECT_EQ("histogram.tag1.tag1Value2", h2.name());
  EXPECT_EQ("histogram", h2.tagExtractedName());
  EXPECT_THAT(h2.tags(), testing::ElementsAre(Tag{"tag1", "tag1Value2"}));
  // Verify that histogramFromTaggedName with the same params returns the existing stat object.
  EXPECT_EQ(&h1, &scope_->histogramFromTaggedName(base, StatNameTagSpan(tags), {},
                                                  Stats::Histogram::Unit::Unspecified));
}

TEST_F(StatsIsolatedStoreImplTest, ConstSymtabAccessor) {
  ScopeSharedPtr scope = store_->createScope("scope.");
  const Scope& cscope = *scope;
  const SymbolTable& const_symbol_table = cscope.constSymbolTable();
  SymbolTable& symbol_table = scope->symbolTable();
  EXPECT_EQ(&const_symbol_table, &symbol_table);
}

TEST_F(StatsIsolatedStoreImplTest, LongStatName) {
  const std::string long_string(128, 'A');

  ScopeSharedPtr scope = store_->createScope("scope.");
  Counter& counter = scope->counterFromString(long_string);
  EXPECT_EQ(absl::StrCat("scope.", long_string), counter.name());
}

/**
 * Test stats macros. @see stats_macros.h
 */
#define ALL_TEST_STATS(COUNTER, GAUGE, HISTOGRAM, TEXT_READOUT, STATNAME)                          \
  COUNTER(test_counter)                                                                            \
  GAUGE(test_gauge, Accumulate)                                                                    \
  HISTOGRAM(test_histogram, Microseconds)                                                          \
  TEXT_READOUT(test_text_readout)                                                                  \
  STATNAME(prefix)

struct TestStats {
  ALL_TEST_STATS(GENERATE_COUNTER_STRUCT, GENERATE_GAUGE_STRUCT, GENERATE_HISTOGRAM_STRUCT,
                 GENERATE_TEXT_READOUT_STRUCT, GENERATE_STATNAME_STRUCT)
};

TEST_F(StatsIsolatedStoreImplTest, StatsMacros) {
  TestStats test_stats{
      ALL_TEST_STATS(POOL_COUNTER_PREFIX(*store_, "test."), POOL_GAUGE_PREFIX(*store_, "test."),
                     POOL_HISTOGRAM_PREFIX(*store_, "test."),
                     POOL_TEXT_READOUT_PREFIX(*store_, "test."), GENERATE_STATNAME_STRUCT)};

  Counter& counter = test_stats.test_counter_;
  EXPECT_EQ("test.test_counter", counter.name());

  Gauge& gauge = test_stats.test_gauge_;
  EXPECT_EQ("test.test_gauge", gauge.name());

  TextReadout& textReadout = test_stats.test_text_readout_;
  EXPECT_EQ("test.test_text_readout", textReadout.name());

  Histogram& histogram = test_stats.test_histogram_;
  EXPECT_EQ("test.test_histogram", histogram.name());
  EXPECT_EQ(Histogram::Unit::Microseconds, histogram.unit());
}

TEST_F(StatsIsolatedStoreImplTest, NullImplCoverage) {
  NullCounterImpl& c = store_->nullCounter();
  c.inc();
  EXPECT_EQ(0, c.value());
  c.add(1);
  c.reset();
  EXPECT_EQ(0, c.latch());
  EXPECT_FALSE(c.used());
  c.markUnused();
  EXPECT_FALSE(c.hidden());
  c.incRefCount();
  EXPECT_TRUE(c.decRefCount());
  EXPECT_EQ(0, c.use_count());

  NullGaugeImpl& g = store_->nullGauge();
  g.inc();
  EXPECT_EQ(0, g.value());
  g.add(1);
  g.dec();
  g.set(1);
  g.setParentValue(1);
  g.sub(0);
  EXPECT_EQ(Gauge::ImportMode::NeverImport, g.importMode());
  g.mergeImportMode(Gauge::ImportMode::Accumulate);
  EXPECT_FALSE(g.used());
  g.markUnused();
  EXPECT_FALSE(g.hidden());
  g.incRefCount();
  EXPECT_TRUE(g.decRefCount());
  EXPECT_EQ(0, g.use_count());

  NullTextReadoutImpl& t = store_->nullTextReadout();
  t.set("foo");
  EXPECT_EQ("", t.value());
  EXPECT_FALSE(t.used());
  t.markUnused();
  EXPECT_FALSE(t.hidden());
  t.incRefCount();
  EXPECT_TRUE(t.decRefCount());
  EXPECT_EQ(0, t.use_count());
}

TEST_F(StatsIsolatedStoreImplTest, StatNamesStruct) {
  MAKE_STAT_NAMES_STRUCT(StatNames, ALL_TEST_STATS);
  StatNames stat_names(store_->symbolTable());
  EXPECT_EQ("prefix", store_->symbolTable().toString(stat_names.prefix_));
  ScopeSharedPtr scope1 = store_->createScope("scope1.");
  ScopeSharedPtr scope2 = store_->createScope("scope2.");
  MAKE_STATS_STRUCT(Stats, StatNames, ALL_TEST_STATS);
  Stats stats1(stat_names, *scope1);
  EXPECT_EQ("scope1.test_counter", stats1.test_counter_.name());
  EXPECT_EQ("scope1.test_gauge", stats1.test_gauge_.name());
  EXPECT_EQ("scope1.test_histogram", stats1.test_histogram_.name());
  EXPECT_EQ("scope1.test_text_readout", stats1.test_text_readout_.name());
  Stats stats2(stat_names, *scope2, stat_names.prefix_);
  EXPECT_EQ("scope2.prefix.test_counter", stats2.test_counter_.name());
  EXPECT_EQ("scope2.prefix.test_gauge", stats2.test_gauge_.name());
  EXPECT_EQ("scope2.prefix.test_histogram", stats2.test_histogram_.name());
  EXPECT_EQ("scope2.prefix.test_text_readout", stats2.test_text_readout_.name());
}

TEST_F(StatsIsolatedStoreImplTest, SharedScopes) {
  std::vector<ConstScopeSharedPtr> scopes;

  // Verifies shared_ptr functionality by creating some scopes, iterating
  // through them from the store and saving them in a vector, dropping the
  // references, and then referencing the scopes, verifying their names.
  {
    ScopeSharedPtr scope1 = store_->createScope("scope1.");
    ScopeSharedPtr scope2 = store_->createScope("scope2.");
    store_->forEachScope(
        [](size_t) {}, [&scopes](const Scope& scope) { scopes.push_back(scope.getConstShared()); });
  }
  ASSERT_EQ(3, scopes.size());
  store_->symbolTable().sortByStatNames<ConstScopeSharedPtr>(
      scopes.begin(), scopes.end(),
      [](const ConstScopeSharedPtr& scope) -> StatName { return scope->prefix(); });
  EXPECT_EQ("", store_->symbolTable().toString(scopes[0]->prefix())); // default scope
  EXPECT_EQ("scope1", store_->symbolTable().toString(scopes[1]->prefix()));
  EXPECT_EQ("scope2", store_->symbolTable().toString(scopes[2]->prefix()));
}

class IsolatedStoreScopeMatcherTest : public testing::Test {
protected:
  IsolatedStoreScopeMatcherTest()
      : store_(std::make_unique<IsolatedStoreImpl>(symbol_table_)), pool_(symbol_table_),
        scope_(store_->rootScope()) {}
  ~IsolatedStoreScopeMatcherTest() override {
    pool_.clear();
    scope_.reset();
    store_.reset();
    EXPECT_EQ(0, symbol_table_.numSymbols());
  }

  // Builds a matcher that rejects stats whose full name starts with the given prefix.
  StatsMatcherSharedPtr makePrefixMatcher(absl::string_view prefix) {
    envoy::config::metrics::v3::StatsConfig cfg;
    cfg.mutable_stats_matcher()->mutable_exclusion_list()->add_patterns()->set_prefix(
        std::string(prefix));
    return std::make_shared<StatsMatcherImpl>(cfg, symbol_table_, context_);
  }

  SymbolTableImpl symbol_table_;
  NiceMock<Server::Configuration::MockServerFactoryContext> context_;
  std::unique_ptr<IsolatedStoreImpl> store_;
  StatNamePool pool_;
  ScopeSharedPtr scope_;
};

// Tests that a scope-level matcher rejects the appropriate stat types and accepts others.
TEST_F(IsolatedStoreScopeMatcherTest, ScopeMatcherRejectsAllStatTypes) {
  // Create a scope whose matcher rejects everything prefixed "scope.rejected.".
  ScopeSharedPtr my_scope =
      scope_->createScope("scope", false, {}, makePrefixMatcher("scope.rejected."));

  // Rejected counter returns null counter (empty name, value always 0).
  Counter& rejected_counter = my_scope->counterFromString("rejected.foo");
  EXPECT_EQ("", rejected_counter.name());
  rejected_counter.inc();
  EXPECT_EQ(0, rejected_counter.value());

  // Accepted counter is real.
  Counter& accepted_counter = my_scope->counterFromString("accepted.foo");
  EXPECT_EQ("scope.accepted.foo", accepted_counter.name());
  accepted_counter.inc();
  EXPECT_EQ(1, accepted_counter.value());

  // Rejected gauge returns null gauge.
  Gauge& rejected_gauge = my_scope->gaugeFromString("rejected.g", Gauge::ImportMode::Accumulate);
  EXPECT_EQ("", rejected_gauge.name());
  rejected_gauge.set(42);
  EXPECT_EQ(0, rejected_gauge.value());

  // Accepted gauge is real.
  Gauge& accepted_gauge = my_scope->gaugeFromString("accepted.g", Gauge::ImportMode::Accumulate);
  EXPECT_EQ("scope.accepted.g", accepted_gauge.name());

  // Rejected histogram returns null histogram (Unit::Null, used() == false).
  Histogram& rejected_histogram =
      my_scope->histogramFromString("rejected.h", Histogram::Unit::Unspecified);
  EXPECT_EQ(Histogram::Unit::Null, rejected_histogram.unit());
  EXPECT_FALSE(rejected_histogram.used());

  // Accepted histogram is real.
  Histogram& accepted_histogram =
      my_scope->histogramFromString("accepted.h", Histogram::Unit::Unspecified);
  EXPECT_EQ(Histogram::Unit::Unspecified, accepted_histogram.unit());

  // Rejected text readout returns null text readout (empty name, value always "").
  TextReadout& rejected_tr = my_scope->textReadoutFromString("rejected.tr");
  EXPECT_EQ("", rejected_tr.name());
  rejected_tr.set("hello");
  EXPECT_EQ("", rejected_tr.value());

  // Accepted text readout is real.
  TextReadout& accepted_tr = my_scope->textReadoutFromString("accepted.tr");
  EXPECT_EQ("scope.accepted.tr", accepted_tr.name());
}

// Tests that a scope without a matcher accepts all stats (no filtering).
TEST_F(IsolatedStoreScopeMatcherTest, ScopeWithNoMatcherAcceptsAll) {
  ScopeSharedPtr my_scope = scope_->createScope("scope");

  Counter& c = my_scope->counterFromString("foo");
  EXPECT_EQ("scope.foo", c.name());

  Gauge& g = my_scope->gaugeFromString("bar", Gauge::ImportMode::Accumulate);
  EXPECT_EQ("scope.bar", g.name());

  Histogram& h = my_scope->histogramFromString("baz", Histogram::Unit::Unspecified);
  EXPECT_EQ("scope.baz", h.name());

  TextReadout& tr = my_scope->textReadoutFromString("qux");
  EXPECT_EQ("scope.qux", tr.name());
}

// Tests that child scopes inherit the parent scope's matcher.
TEST_F(IsolatedStoreScopeMatcherTest, ChildScopeInheritsMatcher) {
  // Parent matcher rejects full names starting with "parent.child.".
  ScopeSharedPtr parent_scope =
      scope_->createScope("parent", false, {}, makePrefixMatcher("parent.child."));

  // Stats directly in parent are not rejected.
  Counter& parent_counter = parent_scope->counterFromString("direct");
  EXPECT_EQ("parent.direct", parent_counter.name());

  // Child created without an explicit matcher inherits parent's matcher.
  ScopeSharedPtr child_scope = parent_scope->createScope("child");

  // Stats in child (full name "parent.child.*") are rejected.
  Counter& child_rejected = child_scope->counterFromString("foo");
  EXPECT_EQ("", child_rejected.name());

  Gauge& child_gauge_rejected = child_scope->gaugeFromString("bar", Gauge::ImportMode::Accumulate);
  EXPECT_EQ("", child_gauge_rejected.name());

  Histogram& child_histogram_rejected =
      child_scope->histogramFromString("baz", Histogram::Unit::Unspecified);
  EXPECT_EQ(Histogram::Unit::Null, child_histogram_rejected.unit());

  TextReadout& child_tr_rejected = child_scope->textReadoutFromString("qux");
  EXPECT_EQ("", child_tr_rejected.name());
}

// Tests that an explicit matcher on a child scope overrides the inherited parent matcher.
TEST_F(IsolatedStoreScopeMatcherTest, ChildScopeOverridesMatcher) {
  // Parent rejects "parent.child.rejected_by_parent.".
  ScopeSharedPtr parent_scope = scope_->createScope(
      "parent", false, {}, makePrefixMatcher("parent.child.rejected_by_parent."));

  // Child gets its own matcher that rejects "parent.child.rejected_by_child." instead.
  ScopeSharedPtr child_scope = parent_scope->createScope(
      "child", false, {}, makePrefixMatcher("parent.child.rejected_by_child."));

  // "rejected_by_parent" prefix is NOT rejected — child's matcher replaced parent's.
  Counter& not_rejected = child_scope->counterFromString("rejected_by_parent.foo");
  EXPECT_EQ("parent.child.rejected_by_parent.foo", not_rejected.name());

  // "rejected_by_child" prefix IS rejected by the child's own matcher.
  Counter& rejected = child_scope->counterFromString("rejected_by_child.foo");
  EXPECT_EQ("", rejected.name());
}

// The explicit `tagged_name` controls the flat stat name while name_tags are still recorded;
// `name` yields the tag-extracted name.
TEST_F(StatsIsolatedStoreImplTest, CounterNameAndNameTags) {
  StatNameTagVector name_tags{{makeStatName("cluster_name"), makeStatName("foo")}};
  Counter& c =
      scope_->counterFromTaggedName(makeStatName("cluster.upstream_rq"), StatNameTagSpan(name_tags),
                                    makeStatName("cluster.foo.up"));
  EXPECT_EQ("cluster.foo.up", c.name());
  EXPECT_EQ("cluster.upstream_rq", c.tagExtractedName());
  ASSERT_EQ(1, c.tags().size());
  EXPECT_EQ("cluster_name", c.tags()[0].name_);
  EXPECT_EQ("foo", c.tags()[0].value_);
}

// Without an explicit tagged_name, the name_tags are appended to prefix+tag_extracted_name (legacy
// convention).
TEST_F(StatsIsolatedStoreImplTest, CounterTagsAppendedWithoutTaggedName) {
  StatNameTagVector name_tags{{makeStatName("cluster_name"), makeStatName("foo")}};
  Counter& c = scope_->counterFromTaggedName(makeStatName("upstream_rq"),
                                             StatNameTagSpan(name_tags), StatName());
  EXPECT_EQ("upstream_rq.cluster_name.foo", c.name());
  EXPECT_EQ("upstream_rq", c.tagExtractedName());
  ASSERT_EQ(1, c.tags().size());
}

// IsolatedScopeImpl does not retain scope-level tags. scopeFromStatName uses the joiner to derive
// the child's flat tagged_name (so the tag value still appears in the tagged_name when the caller
// asks for it), but the child scope itself carries no tag metadata: subsequent stats see no
// propagated tag.
TEST_F(StatsIsolatedStoreImplTest, ScopeTagsAreNotPropagated) {
  StatNameTagVector name_tags{{makeStatName("cluster_name"), makeStatName("foo")}};
  ScopeSharedPtr cluster_scope = scope_->scopeFromTaggedName(
      makeStatName("cluster"), StatNameTagSpan(name_tags), makeStatName("cluster.foo"));
  EXPECT_EQ("cluster.foo", symbol_table_.toString(cluster_scope->prefix()));

  Counter& c = cluster_scope->counterFromStatName(makeStatName("upstream_rq"));
  EXPECT_EQ("cluster.foo.upstream_rq", c.name());
  EXPECT_EQ("cluster.foo.upstream_rq", c.tagExtractedName());
  EXPECT_EQ(0, c.tags().size());

  // Per-stat name_tags still work: only the metric's own tag is attached.
  StatNameTagVector own{{makeStatName("method"), makeStatName("get")}};
  Counter& c2 =
      cluster_scope->counterFromTaggedName(makeStatName("rq"), StatNameTagSpan(own), StatName());
  EXPECT_EQ("cluster.foo.rq.method.get", c2.name());
  EXPECT_EQ("cluster.foo.rq", c2.tagExtractedName());
  ASSERT_EQ(1, c2.tags().size());
  EXPECT_EQ("method", c2.tags()[0].name_);
  EXPECT_EQ("get", c2.tags()[0].value_);
}

// The legacy createScope/counter APIs still work.
TEST_F(StatsIsolatedStoreImplTest, LegacyScopeApiStillWorks) {
  ScopeSharedPtr child = scope_->createScope("a.b");
  Counter& c = child->counterFromString("c");
  EXPECT_EQ("a.b.c", c.name());
  EXPECT_EQ("a.b.c", c.tagExtractedName());
  EXPECT_EQ(0, c.tags().size());
}

// The string_view createScope path uses the joiner to derive the child's flat tagged_name but drops
// the scope-level tags (none propagate to child stats).
TEST_F(StatsIsolatedStoreImplTest, CreateScopeWithTagStringViewsDropsScopeTags) {
  std::vector<TagStringView> name_tags{{"cluster_name", "foo"}};
  ScopeSharedPtr cluster_scope =
      scope_->createScopeWithTaggedName("cluster", name_tags, "cluster.foo");
  EXPECT_EQ("cluster.foo", symbol_table_.toString(cluster_scope->prefix()));

  Counter& c = cluster_scope->counterFromString("upstream_rq");
  EXPECT_EQ("cluster.foo.upstream_rq", c.name());
  EXPECT_EQ("cluster.foo.upstream_rq", c.tagExtractedName());
  EXPECT_EQ(0, c.tags().size());
}

TEST_F(StatsIsolatedStoreImplTest, CreateScopeWithTagStringViewsDropsScopeTags2) {
  std::vector<TagStringView> name_tags{{"cluster_name", "foo"}};
  ScopeSharedPtr cluster_scope =
      scope_->createScopeWithTaggedName("cluster", name_tags, /*tagged_name=*/"");
  EXPECT_EQ("cluster.cluster_name.foo", symbol_table_.toString(cluster_scope->prefix()));

  Counter& c = cluster_scope->counterFromString("upstream_rq");
  EXPECT_EQ("cluster.cluster_name.foo.upstream_rq", c.name());
  EXPECT_EQ("cluster.cluster_name.foo.upstream_rq", c.tagExtractedName());
  EXPECT_EQ(0, c.tags().size());
}

// The explicit tagged_name + name_tags combination works for histograms and text readouts too, not
// just counters/gauges.
TEST_F(StatsIsolatedStoreImplTest, HistogramAndTextReadoutNameAndNameTags) {
  StatNameTagVector name_tags{{makeStatName("cluster_name"), makeStatName("foo")}};
  Histogram& h = scope_->histogramFromTaggedName(
      makeStatName("cluster.rq_time"), StatNameTagSpan(name_tags),
      makeStatName("cluster.foo.rq_time"), Histogram::Unit::Unspecified);
  EXPECT_EQ("cluster.foo.rq_time", h.name());
  EXPECT_EQ("cluster.rq_time", h.tagExtractedName());
  ASSERT_EQ(1, h.tags().size());
  EXPECT_EQ("foo", h.tags()[0].value_);

  TextReadout& t =
      scope_->textReadoutFromTaggedName(makeStatName("cluster.version"), StatNameTagSpan(name_tags),
                                        makeStatName("cluster.foo.version"));
  EXPECT_EQ("cluster.foo.version", t.name());
  EXPECT_EQ("cluster.version", t.tagExtractedName());
  ASSERT_EQ(1, t.tags().size());
  EXPECT_EQ("foo", t.tags()[0].value_);
}

} // namespace Stats
} // namespace Envoy
