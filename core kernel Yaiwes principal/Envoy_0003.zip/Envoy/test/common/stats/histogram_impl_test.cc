#include "envoy/config/metrics/v3/stats.pb.h"

#include "source/common/stats/histogram_impl.h"

#include "test/mocks/server/server_factory_context.h"
#include "test/test_common/utility.h"

#include "gtest/gtest.h"

namespace Envoy {
namespace Stats {

class HistogramSettingsImplTest : public testing::Test {
public:
  void initialize() {
    envoy::config::metrics::v3::StatsConfig config;
    auto& bucket_settings = *config.mutable_histogram_bucket_settings();
    for (auto& item : buckets_configs_) {
      bucket_settings.Add(std::move(item));
    }
    settings_ = std::make_unique<HistogramSettingsImpl>(config, context_);
  }

  NiceMock<Server::Configuration::MockServerFactoryContext> context_;
  std::vector<envoy::config::metrics::v3::HistogramBucketSettings> buckets_configs_;
  std::unique_ptr<HistogramSettingsImpl> settings_;
};

// Test that a matching stat returns the configured buckets, and a non-matching
// stat returns the defaults.
TEST_F(HistogramSettingsImplTest, Basic) {
  envoy::config::metrics::v3::HistogramBucketSettings setting;
  setting.mutable_match()->set_prefix("a");
  setting.mutable_buckets()->Add(0.1);
  setting.mutable_buckets()->Add(2);
  buckets_configs_.push_back(setting);

  initialize();
  EXPECT_EQ(settings_->buckets("test"), settings_->defaultBuckets());
  EXPECT_EQ(settings_->buckets("abcd"), ConstSupportedBuckets({0.1, 2}));
}

// Test that buckets are correctly sorted.
TEST_F(HistogramSettingsImplTest, Sorted) {
  envoy::config::metrics::v3::HistogramBucketSettings setting;
  setting.mutable_match()->set_exact("a");
  setting.mutable_buckets()->Add(0.1);
  setting.mutable_buckets()->Add(2);
  setting.mutable_buckets()->Add(1); // Out-of-order
  buckets_configs_.push_back(setting);

  initialize();
  EXPECT_EQ(settings_->buckets("a"), ConstSupportedBuckets({0.1, 1, 2}));
}

// Test that only matching configurations are applied.
TEST_F(HistogramSettingsImplTest, Matching) {
  {
    envoy::config::metrics::v3::HistogramBucketSettings setting;
    setting.mutable_match()->set_prefix("a");
    setting.mutable_bins()->set_value(5);
    buckets_configs_.push_back(setting);
  }
  {
    envoy::config::metrics::v3::HistogramBucketSettings setting;
    setting.mutable_match()->set_prefix("a");
    setting.mutable_buckets()->Add(1);
    setting.mutable_buckets()->Add(2);
    buckets_configs_.push_back(setting);
  }

  {
    envoy::config::metrics::v3::HistogramBucketSettings setting;
    setting.mutable_match()->set_prefix("b");
    setting.mutable_buckets()->Add(3);
    setting.mutable_buckets()->Add(4);
    buckets_configs_.push_back(setting);
  }

  initialize();
  EXPECT_EQ(settings_->buckets("abcd"), ConstSupportedBuckets({1, 2}));
  EXPECT_EQ(settings_->buckets("bcde"), ConstSupportedBuckets({3, 4}));
  EXPECT_EQ(settings_->bins("ab"), 5);
  EXPECT_EQ(settings_->bins("ba"), std::nullopt);
}

// Test that earlier configs take precedence over later configs when both match.
TEST_F(HistogramSettingsImplTest, Priority) {
  {
    envoy::config::metrics::v3::HistogramBucketSettings setting;
    setting.mutable_match()->set_prefix("a");
    setting.mutable_buckets()->Add(1);
    setting.mutable_buckets()->Add(2);
    setting.mutable_bins()->set_value(1);
    buckets_configs_.push_back(setting);
  }

  {
    envoy::config::metrics::v3::HistogramBucketSettings setting;
    setting.mutable_match()->set_prefix("ab");
    setting.mutable_buckets()->Add(3);
    setting.mutable_buckets()->Add(4);
    setting.mutable_bins()->set_value(2);
    buckets_configs_.push_back(setting);
  }

  initialize();
  EXPECT_EQ(settings_->buckets("abcd"), ConstSupportedBuckets({1, 2}));
  EXPECT_EQ(settings_->bins("abcd"), 1);
}

TEST_F(HistogramSettingsImplTest, ScaledPercent) {
  envoy::config::metrics::v3::HistogramBucketSettings setting;
  setting.mutable_match()->set_prefix("a");
  setting.mutable_buckets()->Add(0.1);
  setting.mutable_buckets()->Add(2);
  buckets_configs_.push_back(setting);

  initialize();
  EXPECT_EQ(settings_->buckets("test"), settings_->defaultBuckets());
  EXPECT_EQ(settings_->buckets("abcd"), ConstSupportedBuckets({0.1, 2}));
}

} // namespace Stats
} // namespace Envoy
