#include <atomic>
#include <thread>

#include "source/common/event/timer_impl.h"
#include "source/common/shared_pool/shared_pool.h"

#include "test/mocks/event/mocks.h"
#include "test/test_common/thread_factory_for_test.h"
#include "test/test_common/utility.h"

#include "absl/synchronization/notification.h"
#include "gtest/gtest.h"

namespace Envoy {
namespace SharedPool {

namespace {
struct Counted {
  explicit Counted(int v) : v_(v) { ++live; }
  Counted(const Counted& o) : v_(o.v_) { ++live; }
  Counted(Counted&& o) noexcept : v_(o.v_) { ++live; }
  ~Counted() { --live; }
  bool operator==(const Counted& o) const { return v_ == o.v_; }
  int v_;
  inline static std::atomic<int> live{0};
};
struct CountedHash {
  size_t operator()(const Counted& c) const { return static_cast<size_t>(c.v_); }
};
} // namespace

class SharedPoolTest : public testing::Test {
protected:
  SharedPoolTest()
      : api_(Api::createApiForTest()), dispatcher_(api_->allocateDispatcher("test_thread")) {
    dispatcher_thread_ = api_->threadFactory().createThread([this]() {
      // Must create a keepalive timer to keep the dispatcher from exiting.
      std::chrono::milliseconds time_interval(500);
      keepalive_timer_ = dispatcher_->createTimer(
          [this, time_interval]() { keepalive_timer_->enableTimer(time_interval); });
      keepalive_timer_->enableTimer(time_interval);
      dispatcher_->run(Event::Dispatcher::RunType::Block);
    });
  }

  template <typename T> void deleteObject(std::shared_ptr<ObjectSharedPool<T>> pool, T* ptr) {
    pool->deleteObject(ptr);
  }

  ~SharedPoolTest() override {
    dispatcher_->exit();
    dispatcher_thread_->join();
  }

  void deferredDeleteSharedPoolOnMainThread(std::shared_ptr<ObjectSharedPool<int>>& pool) {
    absl::Notification go;
    dispatcher_->post([&pool, &go]() {
      pool.reset();
      go.Notify();
    });
    go.WaitForNotification();
  }

  void createObjectSharedPool(std::shared_ptr<ObjectSharedPool<int>>& pool) {
    absl::Notification go;
    dispatcher_->post([&pool, &go, this]() {
      pool = std::make_shared<ObjectSharedPool<int>>(*dispatcher_);
      go.Notify();
    });
    go.WaitForNotification();
  }

  void getObjectFromObjectSharedPool(std::shared_ptr<ObjectSharedPool<int>>& pool,
                                     std::shared_ptr<int>& o, int value) {
    absl::Notification go;
    dispatcher_->post([&pool, &o, &go, value]() {
      o = pool->getObject(value);
      go.Notify();
    });
    go.WaitForNotification();
  }

  Api::ApiPtr api_;
  Event::DispatcherPtr dispatcher_;
  Thread::ThreadPtr dispatcher_thread_;
  Event::TimerPtr keepalive_timer_;
  absl::Notification go_;
};

TEST_F(SharedPoolTest, Basic) {
  Event::MockDispatcher dispatcher;
  auto pool = std::make_shared<ObjectSharedPool<int>>(dispatcher);
  {
    auto o = pool->getObject(4);
    auto o1 = pool->getObject(4);
    ASSERT_EQ(1, pool->poolSize());

    auto o2 = pool->getObject(5);
    ASSERT_EQ(o.get(), o1.get());
    ASSERT_EQ(2, pool->poolSize());
    ASSERT_TRUE(o.get() != o2.get());
  }

  ASSERT_EQ(0, pool->poolSize());
}

TEST_F(SharedPoolTest, NonThreadSafeForGetObjectDeathTest) {
  std::shared_ptr<ObjectSharedPool<int>> pool;
  createObjectSharedPool(pool);
  EXPECT_DEBUG_DEATH(pool->getObject(4), ".*");
}

TEST_F(SharedPoolTest, ThreadSafeForDeleteObject) {
  std::shared_ptr<ObjectSharedPool<int>> pool;
  {
    // same thread
    int* an_int = new int(4);
    createObjectSharedPool(pool);
    dispatcher_->post([&pool, this, &an_int]() {
      deleteObject(pool, an_int);
      go_.Notify();
    });
    go_.WaitForNotification();
  }

  {
    // different threads
    int* an_int = new int(4);
    createObjectSharedPool(pool);
    Thread::ThreadFactory& thread_factory = Thread::threadFactoryForTest();
    auto thread =
        thread_factory.createThread([this, &pool, &an_int]() { deleteObject(pool, an_int); });
    thread->join();
  }
}

TEST_F(SharedPoolTest, NonThreadSafeForPoolSizeDeathTest) {
  std::shared_ptr<ObjectSharedPool<int>> pool;
  createObjectSharedPool(pool);
  EXPECT_DEBUG_DEATH(pool->poolSize(), ".*");
}

TEST_F(SharedPoolTest, GetObjectAndDeleteObjectRaceForSameHashValue) {
  std::shared_ptr<ObjectSharedPool<int>> pool;
  std::shared_ptr<int> o1;
  createObjectSharedPool(pool);
  getObjectFromObjectSharedPool(pool, o1, 4);
  Thread::ThreadFactory& thread_factory = Thread::threadFactoryForTest();
  pool->sync().enable();
  pool->sync().waitOn(ObjectSharedPool<int>::DeleteObjectOnMainThread);
  auto thread = thread_factory.createThread([&o1]() {
    // simulation of shared objects destructing in other threads
    o1.reset(); // Blocks in thread synchronizer waiting on DeleteObjectOnMainThread
  });
  pool->sync().barrierOn(ObjectSharedPool<int>::DeleteObjectOnMainThread);
  // The deleteObject method has not been executed yet, when it is switched to the main thread and
  // called getObject again to get an object with the same hash value.
  std::shared_ptr<int> o2;
  getObjectFromObjectSharedPool(pool, o2, 4);
  pool->sync().signal(ObjectSharedPool<int>::DeleteObjectOnMainThread);
  thread->join();

  // deleteObject will to release older weak_ptr objects
  // Because the storage is actually a new weak_ptr and the reference count is not zero, it is not
  // deleted
  dispatcher_->post([&pool, this]() {
    EXPECT_EQ(1, pool->poolSize());
    go_.Notify();
  });
  go_.WaitForNotification();
  deferredDeleteSharedPoolOnMainThread(pool);
}

TEST_F(SharedPoolTest, RaceCondtionForGetObjectWithObjectDeleter) {
  std::shared_ptr<ObjectSharedPool<int>> pool;
  std::shared_ptr<int> o1;
  createObjectSharedPool(pool);
  getObjectFromObjectSharedPool(pool, o1, 4);
  Thread::ThreadFactory& thread_factory = Thread::threadFactoryForTest();
  pool->sync().enable();
  pool->sync().waitOn(ObjectSharedPool<int>::ObjectDeleterEntry);
  auto thread = thread_factory.createThread([&o1]() {
    // simulation of shared objects destructing in other threads
    o1.reset(); // Blocks in thread synchronizer waiting on ObjectDeleterEntry
  });
  pool->sync().barrierOn(ObjectSharedPool<int>::ObjectDeleterEntry);

  // Object is destructing, no memory has been released,
  // at this time the object obtained through getObject is newly created, not the old object,
  // so the object memory is released when the destruct is complete, and o2 is still valid.
  std::shared_ptr<int> o2;
  getObjectFromObjectSharedPool(pool, o2, 4);
  pool->sync().signal(ObjectSharedPool<int>::ObjectDeleterEntry);
  thread->join();
  EXPECT_EQ(4, *o2);
  deferredDeleteSharedPoolOnMainThread(pool);
}

TEST_F(SharedPoolTest, HashCollision) {
  Event::MockDispatcher dispatcher;
  struct MyHash {
    constexpr size_t operator()(int x) const { return x < 10 ? 0 : 1; }
  };

  auto pool = std::make_shared<ObjectSharedPool<int, MyHash>>(dispatcher);
  {
    // Verify that the hash function works as intended.
    static_assert(MyHash{}(4) == 0);
    static_assert(MyHash{}(3) == 0);
    static_assert(MyHash{}(15) == 1);
    static_assert(MyHash{}(12) == 1);

    // Instantiate objects that hash to the same value.
    auto o = pool->getObject(4);
    auto o1 = pool->getObject(3);

    // Verify that there are separate entries in the pool for objects with the
    // same hash value.
    EXPECT_EQ(2, pool->poolSize());

    EXPECT_EQ(*o, 4);
    EXPECT_EQ(*o1, 3);

    auto o2 = pool->getObject(15);
    auto o3 = pool->getObject(12);
    auto o4 = pool->getObject(3);
    auto o5 = pool->getObject(1);

    EXPECT_EQ(o4.get(), o1.get());
    EXPECT_EQ(*o2, 15);
    EXPECT_EQ(*o3, 12);
    EXPECT_EQ(*o4, 3);
    EXPECT_EQ(*o5, 1);

    EXPECT_EQ(5, pool->poolSize());
  }

  EXPECT_EQ(0, pool->poolSize());
}

TEST_F(SharedPoolTest, DispatcherTeardownDropsCrossThreadDeleteFreesObject) {
  ASSERT_EQ(0, Counted::live.load());

  testing::NiceMock<Event::MockDispatcher> dispatcher;
  std::vector<Event::PostCb> posted_cbs;
  EXPECT_CALL(dispatcher, post(testing::_)).WillRepeatedly(testing::Invoke([&](Event::PostCb cb) {
    posted_cbs.push_back(std::move(cb));
  }));

  auto pool = std::make_shared<ObjectSharedPool<Counted, CountedHash>>(dispatcher);
  auto obj = pool->getObject(Counted{7});
  ASSERT_EQ(1, Counted::live.load());
  ASSERT_TRUE(posted_cbs.empty());

  // Drop the last shared_ptr from a different thread, triggering the cross-thread delete path.
  Thread::ThreadFactory& thread_factory = Thread::threadFactoryForTest();
  auto thread = thread_factory.createThread([&]() { obj.reset(); });
  thread->join();

  // One callback should have been posted (the deferred delete).
  ASSERT_EQ(1u, posted_cbs.size());
  // The object is still alive — held by the captured unique_ptr inside the posted lambda.
  EXPECT_EQ(1, Counted::live.load());

  // Simulate dispatcher teardown: drop the queued callback without running it.
  // The captured unique_ptr destructor must free the object.
  posted_cbs.clear();

  // Regression assertion: prior to the fix, the raw T* was captured by value and the
  // callback destructor could not free it, causing a leak (live would still be 1).
  EXPECT_EQ(0, Counted::live.load());

  // Release the pool; the object is already destroyed, so this is a no-op for the counter.
  pool.reset();
  EXPECT_EQ(0, Counted::live.load());
}

} // namespace SharedPool
} // namespace Envoy
