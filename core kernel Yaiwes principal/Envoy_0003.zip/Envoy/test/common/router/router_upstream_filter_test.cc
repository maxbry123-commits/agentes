#include "envoy/extensions/filters/http/router/v3/router.pb.h"
#include "envoy/extensions/filters/http/upstream_codec/v3/upstream_codec.pb.h"
#include "envoy/extensions/filters/network/http_connection_manager/v3/http_connection_manager.pb.h"

#include "source/common/router/router.h"
#include "source/common/router/upstream_codec_filter.h"

#include "test/common/http/common.h"
#include "test/integration/filters/test_filters.pb.h"
#include "test/mocks/http/mocks.h"
#include "test/mocks/network/mocks.h"
#include "test/mocks/router/mocks.h"
#include "test/mocks/server/factory_context.h"
#include "test/test_common/test_runtime.h"
#include "test/test_common/utility.h"

#include "gmock/gmock.h"
#include "gtest/gtest.h"

using testing::_;
using testing::Invoke;
using testing::NiceMock;
using testing::Return;
using testing::ReturnRef;
namespace Envoy {
namespace Router {
namespace {

using envoy::extensions::filters::network::http_connection_manager::v3::HttpFilter;

class TestFilter : public Filter {
public:
  using Filter::Filter;

  // Filter
  RetryStatePtr createRetryState(const RetryPolicy&, Http::RequestHeaderMap&,
                                 const Upstream::ClusterInfo&,
                                 Server::Configuration::CommonFactoryContext&, Event::Dispatcher&,
                                 Upstream::ResourcePriority) override {
    EXPECT_EQ(nullptr, retry_state_);
    retry_state_ = new NiceMock<MockRetryState>();
    return RetryStatePtr{retry_state_};
  }

  const Network::Connection* downstreamConnection() const override {
    return &downstream_connection_;
  }

  NiceMock<Network::MockConnection> downstream_connection_;
  MockRetryState* retry_state_{};
};

class RouterUpstreamFilterTest : public testing::Test {
public:
  void init(std::vector<HttpFilter> upstream_filters) {
    envoy::extensions::filters::http::router::v3::Router router_proto;
    static const std::string cluster_name = "cluster_0";

    cluster_info_ = std::make_shared<NiceMock<Upstream::MockClusterInfo>>();
    ON_CALL(*cluster_info_, name()).WillByDefault(ReturnRef(cluster_name));
    ON_CALL(*cluster_info_, observabilityName()).WillByDefault(ReturnRef(cluster_name));
    callbacks_.stream_info_.upstream_cluster_info_ = cluster_info_;
    EXPECT_CALL(callbacks_.dispatcher_, deferredDelete_).Times(testing::AnyNumber());
    for (const auto& filter : upstream_filters) {
      *router_proto.add_upstream_http_filters() = filter;
    }

    Stats::StatNameManagedStorage prefix("prefix", context_.scope().symbolTable());
    config_ = *FilterConfig::create(prefix.statName(), context_,
                                    ShadowWriterPtr(new MockShadowWriter()), router_proto);
    router_ = std::make_shared<TestFilter>(config_, config_->default_stats_);
    router_->setDecoderFilterCallbacks(callbacks_);
    EXPECT_CALL(callbacks_.dispatcher_, pushTrackedObject(_)).Times(testing::AnyNumber());
    EXPECT_CALL(callbacks_.dispatcher_, popTrackedObject(_)).Times(testing::AnyNumber());

    upstream_locality_.set_zone("to_az");
    context_.server_factory_context_.cluster_manager_.initializeThreadLocalClusters(
        {"fake_cluster"});
    ON_CALL(
        *context_.server_factory_context_.cluster_manager_.thread_local_cluster_.conn_pool_.host_,
        address())
        .WillByDefault(Return(host_address_));
    ON_CALL(
        *context_.server_factory_context_.cluster_manager_.thread_local_cluster_.conn_pool_.host_,
        locality())
        .WillByDefault(ReturnRef(upstream_locality_));
    ON_CALL(context_.server_factory_context_.cluster_manager_.thread_local_cluster_, chooseHost(_))
        .WillByDefault(Invoke([this] {
          return Upstream::HostSelectionResponse{
              context_.server_factory_context_.cluster_manager_.thread_local_cluster_.lb_.host_};
        }));
    router_->downstream_connection_.stream_info_.downstream_connection_info_provider_
        ->setLocalAddress(host_address_);
    router_->downstream_connection_.stream_info_.downstream_connection_info_provider_
        ->setRemoteAddress(Network::Utility::parseInternetAddressAndPortNoThrow("1.2.3.4:80"));
  }

  Http::TestRequestHeaderMapImpl run() {
    NiceMock<Http::MockRequestEncoder> encoder;
    Http::ResponseDecoder* response_decoder = nullptr;

    EXPECT_CALL(context_.server_factory_context_.cluster_manager_.thread_local_cluster_.conn_pool_,
                newStream(_, _, _))
        .WillOnce(
            Invoke([&](Http::ResponseDecoder& decoder, Http::ConnectionPool::Callbacks& callbacks,
                       const Http::ConnectionPool::Instance::StreamOptions&)
                       -> Http::ConnectionPool::Cancellable* {
              response_decoder = &decoder;
              EXPECT_CALL(encoder.stream_, connectionInfoProvider())
                  .WillRepeatedly(ReturnRef(connection_info1_));
              callbacks.onPoolReady(encoder,
                                    context_.server_factory_context_.cluster_manager_
                                        .thread_local_cluster_.conn_pool_.host_,
                                    stream_info_, Http::Protocol::Http10);
              return nullptr;
            }));

    Http::TestRequestHeaderMapImpl headers;
    HttpTestUtility::addDefaultHeaders(headers);
    router_->decodeHeaders(headers, true);

    EXPECT_CALL(*router_->retry_state_, shouldRetryHeaders(_, _, _))
        .WillOnce(Return(RetryStatus::No));

    Http::ResponseHeaderMapPtr response_headers(new Http::TestResponseHeaderMapImpl());
    response_headers->setStatus(200);

    EXPECT_CALL(context_.server_factory_context_.cluster_manager_.thread_local_cluster_.conn_pool_
                    .host_->outlier_detector_,
                putResult(_, std::optional<uint64_t>(200)));
    // NOLINTNEXTLINE(clang-analyzer-core.CallAndMessage)
    response_decoder->decodeHeaders(std::move(response_headers), true);
    return headers;
  }

  NiceMock<Server::Configuration::MockFactoryContext> context_;

  envoy::config::core::v3::Locality upstream_locality_;
  Network::Address::InstanceConstSharedPtr host_address_{
      *Network::Utility::resolveUrl("tcp://10.0.0.5:9211")};
  Network::Address::InstanceConstSharedPtr upstream_local_address1_{
      *Network::Utility::resolveUrl("tcp://10.0.0.5:10211")};
  Network::ConnectionInfoSetterImpl connection_info1_{upstream_local_address1_,
                                                      upstream_local_address1_};

  NiceMock<Http::MockStreamDecoderFilterCallbacks> callbacks_;
  std::shared_ptr<FilterConfig> config_;
  std::shared_ptr<TestFilter> router_;
  std::shared_ptr<NiceMock<Upstream::MockClusterInfo>> cluster_info_;
  NiceMock<StreamInfo::MockStreamInfo> stream_info_;
};

TEST_F(RouterUpstreamFilterTest, UpstreamFilter) {
  HttpFilter add_header_filter;
  add_header_filter.set_name("add-header-filter");
  test::integration::filters::AddHeaderEmptyFilterConfig add_header_config;
  std::ignore = add_header_filter.mutable_typed_config()->PackFrom(add_header_config);

  HttpFilter codec_filter;
  codec_filter.set_name("envoy.filters.http.upstream_codec");
  envoy::extensions::filters::http::upstream_codec::v3::UpstreamCodec upstream_codec_config;
  std::ignore = codec_filter.mutable_typed_config()->PackFrom(upstream_codec_config);

  init({add_header_filter, codec_filter});
  auto headers = run();
  EXPECT_FALSE(headers.get(Http::LowerCaseString("x-header-to-add")).empty());
}

// Regression test for a use-after-free at teardown. A dynamic (ECDS) upstream HTTP filter causes
// FilterConfig to create a Filter::FilterConfigSubscription, which holds a raw reference to the
// filter config provider manager and dereferences it from its destructor. That manager is an
// *unpinned* singleton, so it survives only as long as something holds a strong reference to it:
// FilterConfig must be that holder for the providers it owns.
TEST_F(RouterUpstreamFilterTest, DynamicFilterKeepsConfigProviderManagerAlive) {
  HttpFilter dynamic_filter;
  dynamic_filter.set_name("dynamic-filter");
  auto* config_discovery = dynamic_filter.mutable_config_discovery();
  config_discovery->mutable_config_source()->mutable_ads();
  config_discovery->add_type_urls(
      "type.googleapis.com/test.integration.filters.AddHeaderEmptyFilterConfig");

  HttpFilter codec_filter;
  codec_filter.set_name("envoy.filters.http.upstream_codec");
  envoy::extensions::filters::http::upstream_codec::v3::UpstreamCodec upstream_codec_config;
  std::ignore = codec_filter.mutable_typed_config()->PackFrom(upstream_codec_config);

  init({dynamic_filter, codec_filter});
  ASSERT_NE(nullptr, config_);

  // Looking the singleton up again returns the live instance if one exists and creates a fresh one
  // otherwise. Binding it to a weak_ptr and letting the returned strong reference expire at the end
  // of the statement therefore reports whether `config_` is keeping the manager alive: without that
  // reference, the manager created during init() is already gone and every subscription it owns is
  // left holding a dangling reference.
  std::weak_ptr<Http::UpstreamFilterConfigProviderManager> manager =
      Http::FilterChainUtility::createSingletonUpstreamFilterConfigProviderManager(
          context_.server_factory_context_);
  EXPECT_FALSE(manager.expired());

  // Destroying the router config destroys the providers and their subscription, which writes
  // through that reference. The manager must still be alive at that point (this is where ASAN
  // reports the use-after-free without the fix) and may be released only afterwards.
  router_.reset();
  config_.reset();
  EXPECT_TRUE(manager.expired());
}
} // namespace
} // namespace Router
} // namespace Envoy
