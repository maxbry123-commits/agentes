#include <chrono>
#include <cstdint>
#include <string>
#include <vector>

#include "envoy/common/exception.h"
#include "envoy/config/core/v3/base.pb.h"
#include "envoy/stream_info/stream_info.h"

#include "source/common/common/utility.h"
#include "source/common/formatter/coalesce_formatter.h"
#include "source/common/formatter/http_specific_formatter.h"
#include "source/common/formatter/serializer.h"
#include "source/common/formatter/stream_info_formatter.h"
#include "source/common/formatter/substitution_format_utility.h"
#include "source/common/formatter/substitution_formatter.h"
#include "source/common/http/header_map_impl.h"
#include "source/common/json/json_loader.h"
#include "source/common/network/address_impl.h"
#include "source/common/protobuf/utility.h"
#include "source/common/router/string_accessor_impl.h"
#include "source/common/stream_info/stream_id_provider_impl.h"
#include "source/common/stream_info/stream_info_impl.h"

#include "test/common/formatter/command_extension.h"
#include "test/common/formatter/formatter_test_utility.h"
#include "test/mocks/api/mocks.h"
#include "test/mocks/http/mocks.h"
#include "test/mocks/network/mocks.h"
#include "test/mocks/ssl/mocks.h"
#include "test/mocks/stream_info/mocks.h"
#include "test/mocks/tracing/mocks.h"
#include "test/mocks/upstream/cluster_info.h"
#include "test/test_common/environment.h"
#include "test/test_common/printers.h"
#include "test/test_common/simulated_time_system.h"
#include "test/test_common/status_utility.h"
#include "test/test_common/struct_matchers.h"
#include "test/test_common/test_runtime.h"
#include "test/test_common/threadsafe_singleton_injector.h"
#include "test/test_common/utility.h"

#include "absl/status/status.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"

namespace Envoy {
namespace Formatter {
namespace {

using ::Envoy::StatusHelpers::IsOk;
using StatusHelpers::HasStatus;
using StatusHelpers::HasStatusCode;
using testing::AnyOf;
using testing::Const;
using testing::ContainsRegex;
using testing::HasSubstr;
using testing::Invoke;
using testing::NiceMock;
using testing::Not;
using testing::Return;
using testing::ReturnPointee;
using testing::ReturnRef;
using testing::StartsWith;
using testing::UnorderedElementsAre;

// Helper class to test StreamInfoFormatter.
class StreamInfoFormatter : public FormatterProvider {
public:
  // This constructor expects well formed format.
  StreamInfoFormatter(const std::string& command, const std::string& sub_command = "",
                      std::optional<size_t> max_length = std::nullopt) {
    DefaultBuiltInStreamInfoCommandParserFactory factory;
    auto parser = factory.createCommandParser();
    auto formatter_or = parser->parse(command, sub_command, max_length);
    ASSERT(formatter_or.ok(), std::string(formatter_or.status().message()));
    formatter_ = std::move(formatter_or).value();
    ASSERT(formatter_ != nullptr, fmt::format("Not supported command in StreamInfo: {}", command));
  }

  explicit StreamInfoFormatter(FormatterProviderPtr formatter) : formatter_(std::move(formatter)) {}

  // Factory method is for testing cases with malformed format.
  static absl::StatusOr<StreamInfoFormatter>
  create(const std::string& command, const std::string& sub_command = "",
         std::optional<size_t> max_length = std::nullopt) {
    DefaultBuiltInStreamInfoCommandParserFactory factory;
    auto parser = factory.createCommandParser();
    auto formatter = parser->parse(command, sub_command, max_length);
    RETURN_IF_NOT_OK(formatter.status());
    if (*formatter == nullptr) {
      return absl::InvalidArgumentError(
          fmt::format("Not supported command in StreamInfo: {}", command));
    }
    return StreamInfoFormatter(std::move(*formatter));
  }

  // FormatterProvider
  std::optional<std::string> format(const Context& context,
                                    const StreamInfo::StreamInfo& stream_info) const override {
    return formatter_->format(context, stream_info);
  }
  Protobuf::Value formatValue(const Context& context,
                              const StreamInfo::StreamInfo& stream_info) const override {
    return formatter_->formatValue(context, stream_info);
  }
  bool formatTo(std::string& sink, const Context& context,
                const StreamInfo::StreamInfo& stream_info) const override {
    return formatter_->formatTo(sink, context, stream_info);
  }
  void formatValueTo(ValueSink& sink, const Context& context,
                     const StreamInfo::StreamInfo& stream_info) const override {
    formatter_->formatValueTo(sink, context, stream_info);
  }

private:
  FormatterProviderPtr formatter_;
};

class TestSerializedUnknownFilterState : public StreamInfo::FilterState::Object {
public:
  ProtobufTypes::MessagePtr serializeAsProto() const override {
    auto any = std::make_unique<Protobuf::Any>();
    any->set_type_url("UnknownType");
    any->set_value("\xde\xad\xbe\xef");
    return any;
  }
};

class TestSerializedStructFilterState : public StreamInfo::FilterState::Object {
public:
  TestSerializedStructFilterState() : use_struct_(true) {
    (*struct_.mutable_fields())["inner_key"] = ValueUtil::stringValue("inner_value");
  }

  explicit TestSerializedStructFilterState(const Protobuf::Struct& s) : use_struct_(true) {
    struct_.CopyFrom(s);
  }

  explicit TestSerializedStructFilterState(std::chrono::seconds seconds) {
    duration_.set_seconds(seconds.count());
  }

  ProtobufTypes::MessagePtr serializeAsProto() const override {
    if (use_struct_) {
      auto s = std::make_unique<Protobuf::Struct>();
      s->CopyFrom(struct_);
      return s;
    }

    auto d = std::make_unique<Protobuf::Duration>();
    d->CopyFrom(duration_);
    return d;
  }

private:
  const bool use_struct_{false};
  Protobuf::Struct struct_;
  Protobuf::Duration duration_;
};

// Class used to test serializeAsString and serializeAsProto of FilterState
class TestSerializedStringFilterState : public StreamInfo::FilterState::Object {
public:
  TestSerializedStringFilterState(std::string str) : raw_string_(str) {}
  std::optional<std::string> serializeAsString() const override {
    return raw_string_ + " By PLAIN";
  }
  ProtobufTypes::MessagePtr serializeAsProto() const override {
    auto message = std::make_unique<Protobuf::StringValue>();
    message->set_value(raw_string_ + " By TYPED");
    return message;
  }
  bool hasFieldSupport() const override { return true; }
  FieldType getField(absl::string_view field_name) const override {
    if (field_name == "test_field") {
      return raw_string_;
    } else if (field_name == "test_num") {
      return 137;
    }
    return {};
  }

private:
  std::string raw_string_;
};

// Test tests multiple versions of variadic template method parseSubcommand
// extracting tokens.
TEST(SubstitutionFormatParser, commandParser) {
  std::vector<absl::string_view> tokens;
  absl::string_view token1;

  std::string command = "item1";
  SubstitutionFormatUtils::parseSubcommand(command, ':', token1);
  ASSERT_EQ(token1, "item1");

  absl::string_view token2;
  command = "item1:item2";
  SubstitutionFormatUtils::parseSubcommand(command, ':', token1, token2);
  ASSERT_EQ(token1, "item1");
  ASSERT_EQ(token2, "item2");

  // Three tokens.
  absl::string_view token3;
  command = "item1?item2?item3";
  SubstitutionFormatUtils::parseSubcommand(command, '?', token1, token2, token3);
  ASSERT_EQ(token1, "item1");
  ASSERT_EQ(token2, "item2");
  ASSERT_EQ(token3, "item3");

  // Command string has 4 tokens but 3 are expected.
  // The first 3 will be read, the fourth will be ignored.
  command = "item1?item2?item3?item4";
  SubstitutionFormatUtils::parseSubcommand(command, '?', token1, token2, token3);
  ASSERT_EQ(token1, "item1");
  ASSERT_EQ(token2, "item2");
  ASSERT_EQ(token3, "item3");

  // Command string has 2 tokens but 3 are expected.
  // The third extracted token should be empty.
  command = "item1?item2";
  token3 = {};
  SubstitutionFormatUtils::parseSubcommand(command, '?', token1, token2, token3);
  ASSERT_EQ(token1, "item1");
  ASSERT_EQ(token2, "item2");
  ASSERT_TRUE(token3.empty());

  // Command string has 4 tokens. Get first 2 into the strings
  // and remaining 2 into a vector of strings.
  command = "item1?item2?item3?item4";
  std::vector<absl::string_view> bucket;
  SubstitutionFormatUtils::parseSubcommand(command, '?', token1, token2, bucket);
  ASSERT_EQ(token1, "item1");
  ASSERT_EQ(token2, "item2");
  ASSERT_EQ(bucket.size(), 2);
  ASSERT_EQ(bucket.at(0), "item3");
  ASSERT_EQ(bucket.at(1), "item4");
}

TEST(SubstitutionFormatUtilsTest, protocolToString) {
  EXPECT_EQ("HTTP/1.0", SubstitutionFormatUtils::protocolToString(Http::Protocol::Http10).value());
  EXPECT_EQ("HTTP/1.1", SubstitutionFormatUtils::protocolToString(Http::Protocol::Http11).value());
  EXPECT_EQ("HTTP/2", SubstitutionFormatUtils::protocolToString(Http::Protocol::Http2).value());
  EXPECT_EQ(std::nullopt, SubstitutionFormatUtils::protocolToString({}));
}

TEST(SubstitutionFormatUtilsTest, protocolToStringOrDefault) {
  EXPECT_EQ("HTTP/1.0", SubstitutionFormatUtils::protocolToStringOrDefault(Http::Protocol::Http10));
  EXPECT_EQ("HTTP/1.1", SubstitutionFormatUtils::protocolToStringOrDefault(Http::Protocol::Http11));
  EXPECT_EQ("HTTP/2", SubstitutionFormatUtils::protocolToStringOrDefault(Http::Protocol::Http2));
  EXPECT_EQ("-", SubstitutionFormatUtils::protocolToStringOrDefault({}));
}

TEST(SubstitutionFormatUtilsTest, truncate) {
  std::string str;

  str = "abcd";
  SubstitutionFormatUtils::truncate(str, {});
  EXPECT_EQ("abcd", str);

  str = "abcd";
  SubstitutionFormatUtils::truncate(str, 0);
  EXPECT_EQ("", str);

  str = "abcd";
  SubstitutionFormatUtils::truncate(str, 2);
  EXPECT_EQ("ab", str);

  str = "abcd";
  SubstitutionFormatUtils::truncate(str, 100);
  EXPECT_EQ("abcd", str);
}

TEST(SubstitutionFormatUtilsTest, truncateStringView) {
  std::string str = "abcd";

  EXPECT_EQ("abcd", SubstitutionFormatUtils::truncateStringView(str, {}));
  EXPECT_EQ("", SubstitutionFormatUtils::truncateStringView(str, 0));
  EXPECT_EQ("ab", SubstitutionFormatUtils::truncateStringView(str, 2));
  EXPECT_EQ("abcd", SubstitutionFormatUtils::truncateStringView(str, 100));
}

TEST(SubstitutionFormatterTest, plainStringFormatter) {
  PlainStringFormatter formatter("plain");
  StreamInfo::MockStreamInfo stream_info;

  EXPECT_EQ("plain", formatForTest(formatter, {}, stream_info));
  EXPECT_THAT(formatValueForTest(formatter, {}, stream_info),
              ProtoEq(ValueUtil::stringValue("plain")));
}

TEST(SubstitutionFormatterTest, plainNumberFormatter) {
  PlainNumberFormatter formatter(400);
  StreamInfo::MockStreamInfo stream_info;

  EXPECT_EQ("400", formatForTest(formatter, {}, stream_info));
  EXPECT_THAT(formatValueForTest(formatter, {}, stream_info), ProtoEq(ValueUtil::numberValue(400)));
}

TEST(SubstitutionFormatterTest, inFlightDuration) {
  Event::SimulatedTimeSystem time_system;
  time_system.setSystemTime(std::chrono::milliseconds(0));
  StreamInfo::StreamInfoImpl stream_info{Http::Protocol::Http2, time_system, nullptr,
                                         StreamInfo::FilterState::LifeSpan::FilterChain};

  {
    time_system.setMonotonicTime(MonotonicTime(std::chrono::milliseconds(100)));
    StreamInfoFormatter duration_format("DURATION");
    EXPECT_EQ("100", formatForTest(duration_format, {}, stream_info));
  }

  {
    time_system.setMonotonicTime(MonotonicTime(std::chrono::milliseconds(200)));
    StreamInfoFormatter duration_format("DURATION");
    EXPECT_EQ("200", formatForTest(duration_format, {}, stream_info));

    time_system.setMonotonicTime(MonotonicTime(std::chrono::milliseconds(300)));
    EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(300.0)));
  }
}

TEST(SubstitutionFormatterTest, streamInfoFormatter) {
  EXPECT_THAT(StreamInfoFormatter::create("unknown_field"),
              HasStatusCode(absl::StatusCode::kInvalidArgument));

  // Used to replace the default one in the upstream info.
  auto mock_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();

  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  stream_info.upstreamInfo()->setUpstreamHost(mock_host);

  MockTimeSystem time_system;
  auto& upstream_timing = stream_info.upstream_info_->upstreamTiming();

  {
    StreamInfoFormatter request_duration_format("REQUEST_DURATION");
    EXPECT_EQ(std::nullopt, formatForTest(request_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(request_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter request_duration_format("REQUEST_DURATION");
    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(5000000))));
    stream_info.downstream_timing_.onLastDownstreamRxByteReceived(time_system);
    EXPECT_EQ("5", formatForTest(request_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(request_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(5.0)));
  }

  {
    StreamInfoFormatter request_tx_duration_format("REQUEST_TX_DURATION");
    EXPECT_EQ(std::nullopt, formatForTest(request_tx_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(request_tx_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter request_tx_duration_format("REQUEST_TX_DURATION");
    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(15000000))));
    upstream_timing.onLastUpstreamTxByteSent(time_system);
    EXPECT_EQ("15", formatForTest(request_tx_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(request_tx_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(15.0)));
  }

  {
    StreamInfoFormatter response_duration_format("RESPONSE_DURATION");
    EXPECT_EQ(std::nullopt, formatForTest(response_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter response_duration_format("RESPONSE_DURATION");
    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(10000000))));
    upstream_timing.onFirstUpstreamRxByteReceived(time_system);
    EXPECT_EQ("10", formatForTest(response_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(10.0)));
  }

  {
    StreamInfoFormatter ttlb_duration_format("RESPONSE_TX_DURATION");

    EXPECT_EQ(std::nullopt, formatForTest(ttlb_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(ttlb_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter ttlb_duration_format("RESPONSE_TX_DURATION");

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(25000000))));
    stream_info.downstream_timing_.onLastDownstreamTxByteSent(time_system);

    EXPECT_EQ("15", formatForTest(ttlb_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(ttlb_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(15.0)));
  }

  {
    StreamInfoFormatter handshake_duration_format("DOWNSTREAM_HANDSHAKE_DURATION");

    EXPECT_EQ(std::nullopt, formatForTest(handshake_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(handshake_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter handshake_duration_format("DOWNSTREAM_HANDSHAKE_DURATION");

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(25000000))));
    stream_info.downstream_timing_.onDownstreamHandshakeComplete(time_system);

    EXPECT_EQ("25", formatForTest(handshake_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(handshake_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(25.0)));
  }

  {
    StreamInfoFormatter roundtrip_duration_format("ROUNDTRIP_DURATION");

    EXPECT_EQ(std::nullopt, formatForTest(roundtrip_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(roundtrip_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter roundtrip_duration_format("ROUNDTRIP_DURATION");

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(25000000))));
    stream_info.downstream_timing_.onLastDownstreamAckReceived(time_system);

    EXPECT_EQ("25", formatForTest(roundtrip_duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(roundtrip_duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(25.0)));
  }

  {
    StreamInfoFormatter rtt_format("DOWNSTREAM_CX_RTT");

    // No round trip time set yet.
    EXPECT_EQ(std::nullopt, formatForTest(rtt_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(rtt_format, {}, stream_info), ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter rtt_format("DOWNSTREAM_CX_RTT");

    stream_info.downstream_connection_info_provider_->setRoundTripTime(
        std::chrono::milliseconds(42));

    EXPECT_EQ("42", formatForTest(rtt_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(rtt_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(42.0)));
  }

  {
    StreamInfoFormatter bytes_retransmitted_format("BYTES_RETRANSMITTED");
    EXPECT_CALL(stream_info, bytesRetransmitted()).WillRepeatedly(Return(1));
    EXPECT_EQ("1", formatForTest(bytes_retransmitted_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(bytes_retransmitted_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfoFormatter packets_retransmitted_format("PACKETS_RETRANSMITTED");
    EXPECT_CALL(stream_info, packetsRetransmitted()).WillRepeatedly(Return(1));
    EXPECT_EQ("1", formatForTest(packets_retransmitted_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(packets_retransmitted_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfoFormatter bytes_received_format("BYTES_RECEIVED");
    EXPECT_CALL(stream_info, bytesReceived()).WillRepeatedly(Return(1));
    EXPECT_EQ("1", formatForTest(bytes_received_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(bytes_received_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfoFormatter attempt_count_format("UPSTREAM_REQUEST_ATTEMPT_COUNT");
    std::optional<uint32_t> attempt_count{3};
    EXPECT_CALL(stream_info, attemptCount()).WillRepeatedly(Return(attempt_count));
    EXPECT_EQ("3", formatForTest(attempt_count_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(attempt_count_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(3.0)));
  }

  {
    StreamInfoFormatter attempt_count_format("UPSTREAM_REQUEST_ATTEMPT_COUNT");
    std::optional<uint32_t> attempt_count;
    EXPECT_CALL(stream_info, attemptCount()).WillRepeatedly(Return(attempt_count));
    EXPECT_EQ("0", formatForTest(attempt_count_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(attempt_count_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0.0)));
  }

  {
    StreamInfo::BytesMeterSharedPtr upstream_bytes_meter{
        std::make_shared<StreamInfo::BytesMeter>()};
    upstream_bytes_meter->addWireBytesReceived(1);
    StreamInfoFormatter wire_bytes_received_format("UPSTREAM_WIRE_BYTES_RECEIVED");
    EXPECT_CALL(stream_info, getUpstreamBytesMeter())
        .WillRepeatedly(ReturnRef(upstream_bytes_meter));
    EXPECT_EQ("1", formatForTest(wire_bytes_received_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(wire_bytes_received_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfoFormatter protocol_format("PROTOCOL");
    std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
    EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));
    EXPECT_EQ("HTTP/1.1", formatForTest(protocol_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(protocol_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("HTTP/1.1")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter protocol_format("UPSTREAM_PROTOCOL");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(protocol_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(protocol_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter protocol_format("UPSTREAM_PROTOCOL");
    EXPECT_EQ(std::nullopt, formatForTest(protocol_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(protocol_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter protocol_format("UPSTREAM_PROTOCOL");
    Http::Protocol protocol = Http::Protocol::Http2;
    stream_info.upstreamInfo()->setUpstreamProtocol(protocol);
    EXPECT_EQ("HTTP/2", formatForTest(protocol_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(protocol_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("HTTP/2")));
  }

  {
    StreamInfoFormatter response_format("RESPONSE_CODE");
    std::optional<uint32_t> response_code{200};
    EXPECT_CALL(stream_info, responseCode()).WillRepeatedly(Return(response_code));
    EXPECT_EQ("200", formatForTest(response_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(200.0)));
  }

  {
    StreamInfoFormatter response_code_format("RESPONSE_CODE");
    std::optional<uint32_t> response_code;
    EXPECT_CALL(stream_info, responseCode()).WillRepeatedly(Return(response_code));
    EXPECT_EQ("0", formatForTest(response_code_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_code_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0.0)));
  }

  {
    StreamInfoFormatter response_format("RESPONSE_CODE_DETAILS");
    std::optional<std::string> rc_details;
    EXPECT_CALL(stream_info, responseCodeDetails()).WillRepeatedly(ReturnRef(rc_details));
    EXPECT_EQ(std::nullopt, formatForTest(response_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter response_code_format("RESPONSE_CODE_DETAILS");
    std::optional<std::string> rc_details{"via_upstream"};
    EXPECT_CALL(stream_info, responseCodeDetails()).WillRepeatedly(ReturnRef(rc_details));
    EXPECT_EQ("via_upstream", formatForTest(response_code_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_code_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("via_upstream")));
  }

  {
    StreamInfoFormatter response_code_format("RESPONSE_CODE_DETAILS");
    std::optional<std::string> rc_details{"via upstream"};
    EXPECT_CALL(stream_info, responseCodeDetails()).WillRepeatedly(ReturnRef(rc_details));
    EXPECT_EQ("via_upstream", formatForTest(response_code_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_code_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("via_upstream")));
  }

  {
    StreamInfoFormatter response_code_format("RESPONSE_CODE_DETAILS", "ALLOW_WHITESPACES");
    std::optional<std::string> rc_details{"via upstream"};
    EXPECT_CALL(stream_info, responseCodeDetails()).WillRepeatedly(ReturnRef(rc_details));
    EXPECT_EQ("via upstream", formatForTest(response_code_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_code_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("via upstream")));
  }

  {
    StreamInfoFormatter termination_details_format("CONNECTION_TERMINATION_DETAILS");
    std::optional<std::string> details;
    EXPECT_CALL(stream_info, connectionTerminationDetails()).WillRepeatedly(ReturnRef(details));
    EXPECT_EQ(std::nullopt, formatForTest(termination_details_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(termination_details_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter termination_details_format("CONNECTION_TERMINATION_DETAILS");
    std::optional<std::string> details{"access_denied"};
    EXPECT_CALL(stream_info, connectionTerminationDetails()).WillRepeatedly(ReturnRef(details));
    EXPECT_EQ("access_denied", formatForTest(termination_details_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(termination_details_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("access_denied")));
  }

  {
    StreamInfoFormatter bytes_sent_format("BYTES_SENT");
    EXPECT_CALL(stream_info, bytesSent()).WillRepeatedly(Return(1));
    EXPECT_EQ("1", formatForTest(bytes_sent_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(bytes_sent_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfo::BytesMeterSharedPtr upstream_bytes_meter{
        std::make_shared<StreamInfo::BytesMeter>()};
    upstream_bytes_meter->addWireBytesSent(1);
    StreamInfoFormatter wire_bytes_sent_format("UPSTREAM_WIRE_BYTES_SENT");
    EXPECT_CALL(stream_info, getUpstreamBytesMeter())
        .WillRepeatedly(ReturnRef(upstream_bytes_meter));
    EXPECT_EQ("1", formatForTest(wire_bytes_sent_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(wire_bytes_sent_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(1.0)));
  }

  {
    StreamInfoFormatter duration_format("DURATION");
    std::optional<std::chrono::nanoseconds> dur = std::chrono::nanoseconds(15000000);
    EXPECT_CALL(stream_info, currentDuration()).WillRepeatedly(Return(dur));
    EXPECT_EQ("15", formatForTest(duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(15.0)));
  }

  {
    StreamInfoFormatter custom_flags_format("CUSTOM_FLAGS");
    stream_info.addCustomFlag("flag1");
    stream_info.addCustomFlag("flag2");
    EXPECT_EQ("flag1,flag2", formatForTest(custom_flags_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(custom_flags_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("flag1,flag2")));
  }

  {
    StreamInfoFormatter response_flags_format("RESPONSE_FLAGS");
    stream_info.setResponseFlag(StreamInfo::CoreResponseFlag::LocalReset);
    EXPECT_EQ("LR", formatForTest(response_flags_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_flags_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("LR")));
  }

  {
    StreamInfoFormatter response_flags_format("RESPONSE_FLAGS_LONG");
    stream_info.setResponseFlag(StreamInfo::CoreResponseFlag::LocalReset);
    EXPECT_EQ("LocalReset", formatForTest(response_flags_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(response_flags_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("LocalReset")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_ADDRESS");

    // Validate for IPv4 address
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.3", 18443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("127.1.2.3:18443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.1.2.3:18443")));

    // Validate for IPv6 address
    address =
        Network::Address::InstanceConstSharedPtr{new Network::Address::Ipv6Instance("::1", 19443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("[::1]:19443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("[::1]:19443")));

    // Validate for Pipe
    address =
        Network::Address::InstanceConstSharedPtr{*Network::Address::PipeInstance::create("/foo")};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("/foo", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("/foo")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_ADDRESS_WITHOUT_PORT");
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.0.0.3", 18443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("127.0.0.3", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.3")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_PORT");

    // Validate for IPv4 address
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.3", 18443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("18443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(18443)));

    // Validate for IPv6 address
    address =
        Network::Address::InstanceConstSharedPtr{new Network::Address::Ipv6Instance("::1", 19443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("19443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(19443)));

    // Validate for Pipe
    address =
        Network::Address::InstanceConstSharedPtr{*Network::Address::PipeInstance::create("/foo")};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);
    EXPECT_EQ("", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAME");

    // Hostname is used.
    mock_host->hostname_ = "upstream_host_xxx";
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));

    // Hostname is not used then the main address is used.
    mock_host->hostname_.clear();
    EXPECT_EQ("10.0.0.1:443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1:443")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAME_WITHOUT_PORT");

    // Hostname includes port.
    mock_host->hostname_ = "upstream_host_xxx:443";
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));

    // Hostname doesn't include port.
    mock_host->hostname_ = "upstream_host_xxx";
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));

    // Hostname is not used then the main address (only the ip) is used.
    mock_host->hostname_.clear();
    EXPECT_EQ("10.0.0.1", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1")));
  }

  // Test UPSTREAM_HOSTS_ATTEMPTED
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(nullptr));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    std::string hostname = "upstream_host_xxx";
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("10.0.0.1:443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1:443")));
  }

  // Test UPSTREAM_HOSTS_ATTEMPTED_WITHOUT_PORT
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(nullptr));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    std::string hostname = "upstream_host_xxx:443";
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("10.0.0.1", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1")));
  }

  // Test UPSTREAM_HOST_NAMES_ATTEMPTED
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    std::string empty_hostname;
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(empty_hostname));
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(nullptr));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    // Both hostname and address are empty, returns nullopt.
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    // Hostname is used.
    std::string hostname = "upstream_host_xxx";
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    // Hostname is not used then the main address is used.
    std::string empty_hostname;
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(empty_hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("10.0.0.1:443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1:443")));
  }

  // Test UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    std::string empty_hostname;
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(empty_hostname));
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(nullptr));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    // Both hostname and address are empty, returns nullopt.
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    // Hostname includes port.
    std::string hostname_with_port = "upstream_host_xxx:443";
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(hostname_with_port));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    // Hostname is used (no port).
    std::string hostname = "upstream_host_xxx";
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("upstream_host_xxx", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("upstream_host_xxx")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    EXPECT_CALL(*attempted_host, address()).WillRepeatedly(Return(address));

    // Hostname is not used then the main address (only the ip) is used.
    std::string empty_hostname;
    EXPECT_CALL(*attempted_host, hostname()).WillRepeatedly(ReturnRef(empty_hostname));
    upstream_info->addUpstreamHostAttempted(attempted_host);
    EXPECT_EQ("10.0.0.1", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1")));
  }

  // Tests with multiple valid attempted hosts
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host1 = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto attempted_host2 = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto address1 = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    auto address2 = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.2", 8080)};
    EXPECT_CALL(*attempted_host1, address()).WillRepeatedly(Return(address1));
    EXPECT_CALL(*attempted_host2, address()).WillRepeatedly(Return(address2));
    upstream_info->addUpstreamHostAttempted(attempted_host1);
    upstream_info->addUpstreamHostAttempted(attempted_host2);

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED");
      EXPECT_EQ("10.0.0.1:443,10.0.0.2:8080", formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1:443,10.0.0.2:8080")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED_WITHOUT_PORT");
      EXPECT_EQ("10.0.0.1,10.0.0.2", formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1,10.0.0.2")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED");
      EXPECT_EQ("10.0.0.1:443,10.0.0.2:8080", formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1:443,10.0.0.2:8080")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
      EXPECT_EQ("10.0.0.1,10.0.0.2", formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1,10.0.0.2")));
    }
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    auto attempted_host1 = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto attempted_host2 = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    auto attempted_host3 = std::make_shared<NiceMock<Upstream::MockHostDescription>>();
    std::string hostname1 = "host1.example.com";
    std::string hostname2 = "host2.example.com:8080";
    auto address1 = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.1", 443)};
    auto address2 = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.2", 8080)};
    auto address3 = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.3", 80)};
    EXPECT_CALL(*attempted_host1, hostname()).WillRepeatedly(ReturnRef(hostname1));
    EXPECT_CALL(*attempted_host1, address()).WillRepeatedly(Return(address1));
    EXPECT_CALL(*attempted_host2, hostname()).WillRepeatedly(ReturnRef(hostname2));
    EXPECT_CALL(*attempted_host2, address()).WillRepeatedly(Return(address2));
    EXPECT_CALL(*attempted_host3, address()).WillRepeatedly(Return(address3));
    upstream_info->addUpstreamHostAttempted(attempted_host1);
    upstream_info->addUpstreamHostAttempted(attempted_host2);
    upstream_info->addUpstreamHostAttempted(attempted_host3);

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED");
      EXPECT_EQ("10.0.0.1:443,10.0.0.2:8080,10.0.0.3:80",
                formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1:443,10.0.0.2:8080,10.0.0.3:80")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOSTS_ATTEMPTED_WITHOUT_PORT");
      EXPECT_EQ("10.0.0.1,10.0.0.2,10.0.0.3", formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("10.0.0.1,10.0.0.2,10.0.0.3")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED");
      EXPECT_EQ("host1.example.com,host2.example.com:8080,10.0.0.3:80",
                formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(
          formatValueForTest(upstream_format, {}, stream_info),
          ProtoEq(ValueUtil::stringValue("host1.example.com,host2.example.com:8080,10.0.0.3:80")));
    }

    {
      StreamInfoFormatter upstream_format("UPSTREAM_HOST_NAMES_ATTEMPTED_WITHOUT_PORT");
      EXPECT_EQ("host1.example.com,host2.example.com,10.0.0.3",
                formatForTest(upstream_format, {}, stream_info));
      EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                  ProtoEq(ValueUtil::stringValue("host1.example.com,host2.example.com,10.0.0.3")));
    }
  }

  // Test UPSTREAM_CONNECTION_IDS_ATTEMPTED
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);

    StreamInfoFormatter upstream_format("UPSTREAM_CONNECTION_IDS_ATTEMPTED");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto upstream_info = std::make_shared<StreamInfo::UpstreamInfoImpl>();
    stream_info.setUpstreamInfo(upstream_info);
    upstream_info->setUpstreamConnectionId(123);
    upstream_info->setUpstreamConnectionId(456);

    StreamInfoFormatter upstream_format("UPSTREAM_CONNECTION_IDS_ATTEMPTED");
    EXPECT_EQ("123,456", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("123,456")));
  }

  auto test_upstream_remote_address =
      Network::Address::InstanceConstSharedPtr{new Network::Address::Ipv4Instance("10.0.0.2", 80)};
  auto default_upstream_remote_address = stream_info.upstreamInfo()->upstreamRemoteAddress();

  {
    StreamInfoFormatter upstream_format("UPSTREAM_HOST");
    EXPECT_EQ("10.0.0.1:443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.1:443")));

    stream_info.upstreamInfo()->setUpstreamHost(nullptr);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));

    // Reset the state.
    stream_info.upstreamInfo()->setUpstreamHost(mock_host);
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_REMOTE_ADDRESS");

    // Has valid upstream remote address and it will be used as priority.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(test_upstream_remote_address);
    EXPECT_EQ("10.0.0.2:80", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.2:80")));

    // Upstream remote address is not available.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(nullptr);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));

    // Reset to default one.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(default_upstream_remote_address);
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_REMOTE_ADDRESS_WITHOUT_PORT");

    // Has valid upstream remote address and it will be used as priority.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(test_upstream_remote_address);
    EXPECT_EQ("10.0.0.2", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.2")));

    // Upstream remote address is not available.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(nullptr);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));

    // Reset to default one.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(default_upstream_remote_address);
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_REMOTE_ADDRESS_ENDPOINT_ID");
    auto internal_address =
        std::make_shared<Network::Address::EnvoyInternalInstance>("internal", "1234567890");
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(internal_address);
    EXPECT_EQ("1234567890", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("1234567890")));

    // Normal IP address does not have endpoint ID
    auto ip_address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.0.0.2", 80)};
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(ip_address);
    EXPECT_EQ("", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));

    // Reset to default one.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(default_upstream_remote_address);
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_REMOTE_PORT");

    // Has valid upstream remote address and it will be used as priority.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(test_upstream_remote_address);
    EXPECT_EQ("80", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(80)));

    // Upstream remote address is not available.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(nullptr);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));

    // Reset to default one.
    stream_info.upstreamInfo()->setUpstreamRemoteAddress(default_upstream_remote_address);
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_CLUSTER");
    const std::string observable_cluster_name = "observability_name";
    auto cluster_info_mock = std::make_shared<Upstream::MockClusterInfo>();
    stream_info.upstream_cluster_info_ = cluster_info_mock;
    EXPECT_CALL(*cluster_info_mock, observabilityName())
        .WillRepeatedly(ReturnRef(observable_cluster_name));
    EXPECT_EQ("observability_name", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("observability_name")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_CLUSTER");
    stream_info.upstream_cluster_info_ = nullptr;
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_CLUSTER_RAW");
    const std::string raw_cluster_name = "raw_name";
    auto cluster_info_mock = std::make_shared<Upstream::MockClusterInfo>();
    stream_info.upstream_cluster_info_ = cluster_info_mock;
    EXPECT_CALL(*cluster_info_mock, name()).WillRepeatedly(ReturnRef(raw_cluster_name));
    EXPECT_EQ("raw_name", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("raw_name")));
  }

  {
    StreamInfoFormatter upstream_format("UPSTREAM_CLUSTER_RAW");
    stream_info.upstream_cluster_info_ = nullptr;
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<Api::MockOsSysCalls> os_sys_calls;
    TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> os_calls(&os_sys_calls);
    EXPECT_CALL(os_sys_calls, gethostname(_, _))
        .WillOnce(
            Invoke([](char*, size_t) -> Api::SysCallIntResult { return {-1, ENAMETOOLONG}; }));

    StreamInfoFormatter upstream_format("HOSTNAME");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<Api::MockOsSysCalls> os_sys_calls;
    TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> os_calls(&os_sys_calls);
    EXPECT_CALL(os_sys_calls, gethostname(_, _))
        .WillOnce(Invoke([](char* name, size_t) -> Api::SysCallIntResult {
          StringUtil::strlcpy(name, "myhostname", 11);
          return {0, 0};
        }));

    StreamInfoFormatter upstream_format("HOSTNAME");
    EXPECT_EQ("myhostname", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("myhostname")));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_ADDRESS");
    EXPECT_EQ("127.0.0.2:0", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.2:0")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_LOCAL_ADDRESS");
    auto address = Network::Address::InstanceConstSharedPtr{new Network::Address::Ipv4Instance(
             "127.1.2.3", 6745)},
         original_address = stream_info.downstream_connection_info_provider_->localAddress();
    stream_info.downstream_connection_info_provider_->setLocalAddress(address);
    EXPECT_EQ("127.0.0.2:0", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.2:0")));
    stream_info.downstream_connection_info_provider_->setLocalAddress(original_address);
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_ADDRESS_WITHOUT_PORT");
    EXPECT_EQ("127.0.0.2", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.2")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_LOCAL_ADDRESS_WITHOUT_PORT");
    EXPECT_EQ("127.0.0.2", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.2")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_LOCAL_ADDRESS_WITHOUT_PORT");
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.3", 8900)};
    stream_info.downstream_connection_info_provider_->setLocalAddress(address);
    EXPECT_EQ("127.0.0.2", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.2")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_LOCAL_PORT");
    EXPECT_EQ("0", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info), ProtoEq(ValueUtil::numberValue(0)));
  }

  {
    StreamInfoFormatter downstream_local_port_format("DOWNSTREAM_LOCAL_PORT"),
        downstream_direct_downstream_local_port_format("DOWNSTREAM_DIRECT_LOCAL_PORT");

    // Validate for IPv4 address
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.3", 8443)};
    stream_info.downstream_connection_info_provider_->setLocalAddress(address);
    EXPECT_EQ("8443", formatForTest(downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(8443)));

    EXPECT_EQ("0", formatForTest(downstream_direct_downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_direct_downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0)));

    // Validate for IPv6 address
    address =
        Network::Address::InstanceConstSharedPtr{new Network::Address::Ipv6Instance("::1", 9443)};
    stream_info.downstream_connection_info_provider_->setLocalAddress(address);
    EXPECT_EQ("9443", formatForTest(downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(9443)));

    EXPECT_EQ("0", formatForTest(downstream_direct_downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_direct_downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0)));
    // Validate for Pipe
    address =
        Network::Address::InstanceConstSharedPtr{*Network::Address::PipeInstance::create("/foo")};
    stream_info.downstream_connection_info_provider_->setLocalAddress(address);
    EXPECT_EQ("", formatForTest(downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    EXPECT_EQ("0", formatForTest(downstream_direct_downstream_local_port_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_direct_downstream_local_port_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0)));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT");
    EXPECT_EQ("127.0.0.1", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.1")));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_REMOTE_ADDRESS");
    EXPECT_EQ("127.0.0.1:0", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.1:0")));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_REMOTE_PORT");
    EXPECT_EQ("0", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(0)));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_DIRECT_REMOTE_ADDRESS_WITHOUT_PORT");
    EXPECT_EQ("127.0.0.3", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.3")));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_DIRECT_REMOTE_ADDRESS");
    EXPECT_EQ("127.0.0.3:63443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.3:63443")));
  }

  {
    StreamInfoFormatter upstream_format("DOWNSTREAM_DIRECT_REMOTE_PORT");
    EXPECT_EQ("63443", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(63443)));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "24");
    EXPECT_EQ("127.0.0.0/24", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.0/24")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "16");
    EXPECT_EQ("127.0.0.0/16", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.0/16")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "32");
    EXPECT_EQ("127.0.0.1/32", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.1/32")));
  }

  {
    auto original_address = stream_info.downstreamAddressProvider().remoteAddress();
    auto masked_address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("10.1.10.23", 8080)};
    stream_info.downstream_connection_info_provider_->setRemoteAddress(masked_address);

    StreamInfoFormatter format("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "16");
    EXPECT_EQ("10.1.0.0/16", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.1.0.0/16")));

    stream_info.downstream_connection_info_provider_->setRemoteAddress(original_address);
  }

  {
    auto original_address = stream_info.downstreamAddressProvider().remoteAddress();
    auto ipv6_address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv6Instance("2001:db8:1234:5678::1", 8080)};
    stream_info.downstream_connection_info_provider_->setRemoteAddress(ipv6_address);

    StreamInfoFormatter format128("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "128");
    EXPECT_EQ("2001:db8:1234:5678::1/128", formatForTest(format128, {}, stream_info));

    StreamInfoFormatter format64("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "64");
    EXPECT_EQ("2001:db8:1234:5678::/64", formatForTest(format64, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format64, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("2001:db8:1234:5678::/64")));

    StreamInfoFormatter format48("DOWNSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "48");
    EXPECT_EQ("2001:db8:1234::/48", formatForTest(format48, {}, stream_info));

    stream_info.downstream_connection_info_provider_->setRemoteAddress(original_address);
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_REMOTE_ADDRESS_WITHOUT_PORT", "24");
    EXPECT_EQ("127.0.0.0/24", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.0/24")));
  }

  {
    StreamInfoFormatter format("DOWNSTREAM_DIRECT_REMOTE_ADDRESS_WITHOUT_PORT", "16");
    EXPECT_EQ("127.0.0.0/16", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.0/16")));
  }

  {
    if (stream_info.downstreamAddressProvider().localAddress() &&
        stream_info.downstreamAddressProvider().localAddress()->type() ==
            Network::Address::Type::Ip) {
      StreamInfoFormatter format("DOWNSTREAM_LOCAL_ADDRESS_WITHOUT_PORT", "24");
      auto result = formatForTest(format, {}, stream_info);
      if (result.has_value()) {
        EXPECT_THAT(result.value(), HasSubstr("/"));
      }
    }
  }

  {
    if (stream_info.downstreamAddressProvider().directLocalAddress() &&
        stream_info.downstreamAddressProvider().directLocalAddress()->type() ==
            Network::Address::Type::Ip) {
      StreamInfoFormatter format("DOWNSTREAM_DIRECT_LOCAL_ADDRESS_WITHOUT_PORT", "16");
      auto result = formatForTest(format, {}, stream_info);
      if (result.has_value()) {
        EXPECT_THAT(result.value(), AnyOf(HasSubstr("127.0.0.0/16"), HasSubstr("/")));
      }
    }
  }

  {
    StreamInfoFormatter format("UPSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "24");
    EXPECT_EQ("10.0.0.0/24", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.0/24")));
  }

  {
    StreamInfoFormatter format("UPSTREAM_REMOTE_ADDRESS_WITHOUT_PORT", "16");
    EXPECT_EQ("10.0.0.0/16", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("10.0.0.0/16")));
  }

  {
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.0.0.5", 8443)};
    stream_info.upstreamInfo()->setUpstreamLocalAddress(address);

    StreamInfoFormatter format("UPSTREAM_LOCAL_ADDRESS_WITHOUT_PORT", "24");
    EXPECT_EQ("127.0.0.0/24", formatForTest(format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("127.0.0.0/24")));
  }

  {
    StreamInfoFormatter downstream_format("DOWNSTREAM_LOCAL_ADDRESS_ENDPOINT_ID");
    auto internal_address =
        std::make_shared<Network::Address::EnvoyInternalInstance>("internal", "1234567890");
    stream_info.downstream_connection_info_provider_->setLocalAddress(internal_address);
    EXPECT_EQ("1234567890", formatForTest(downstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("1234567890")));

    // Normal IP address should not have endpoint ID
    auto ip_address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.3", 18443)};
    stream_info.downstream_connection_info_provider_->setLocalAddress(ip_address);
    EXPECT_EQ("", formatForTest(downstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter downstream_format("DOWNSTREAM_DIRECT_LOCAL_ADDRESS_ENDPOINT_ID");
    auto internal_address =
        std::make_shared<Network::Address::EnvoyInternalInstance>("internal", "1234567890");
    stream_info.downstream_connection_info_provider_->setDirectLocalAddressForTest(
        internal_address);
    EXPECT_EQ("1234567890", formatForTest(downstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("1234567890")));

    // Normal IP address should not have endpoint ID
    auto ip_address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.1.2.4", 18444)};
    stream_info.downstream_connection_info_provider_->setDirectLocalAddressForTest(ip_address);
    EXPECT_EQ("", formatForTest(downstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(downstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter upstream_format("CONNECTION_ID");
    uint64_t id = 123;
    stream_info.downstream_connection_info_provider_->setConnectionID(id);
    EXPECT_EQ("123", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(id)));
  }
  {
    StreamInfoFormatter upstream_format("UPSTREAM_CONNECTION_ID");
    uint64_t id = 1234;
    stream_info.upstreamInfo()->setUpstreamConnectionId(id);
    EXPECT_EQ("1234", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(id)));
  }
  {
    StreamInfoFormatter upstream_format("STREAM_ID");

    StreamInfo::StreamIdProviderImpl id_provider("ffffffff-0012-0110-00ff-0c00400600ff");
    EXPECT_CALL(stream_info, getStreamIdProvider())
        .WillRepeatedly(Return(makeOptRef<const StreamInfo::StreamIdProvider>(id_provider)));

    EXPECT_EQ("ffffffff-0012-0110-00ff-0c00400600ff",
              formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("ffffffff-0012-0110-00ff-0c00400600ff")));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string requested_server_name;
    stream_info.downstream_connection_info_provider_->setRequestedServerName(requested_server_name);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string requested_server_name = "outbound_.8080_._.example.com";
    stream_info.downstream_connection_info_provider_->setRequestedServerName(requested_server_name);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("outbound_.8080_._.example.com")));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string requested_server_name = "stub-server";
    stream_info.downstream_connection_info_provider_->setRequestedServerName(requested_server_name);
    EXPECT_EQ("stub-server", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("stub-server")));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string requested_server_name = "stub_server\n";
    stream_info.downstream_connection_info_provider_->setRequestedServerName(requested_server_name);
    EXPECT_EQ("invalid:stub_server_", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("invalid:stub_server_")));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string requested_server_name = "\e[0;34m\n$(echo -e $blue)end<script>alert()</script>";
    stream_info.downstream_connection_info_provider_->setRequestedServerName(requested_server_name);
    EXPECT_EQ("invalid:__0_34m___echo_-e__blue_end_script_alert____script_",
              formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(
                    "invalid:__0_34m___echo_-e__blue_end_script_alert____script_")));
  }

  {
    StreamInfoFormatter upstream_format("REQUESTED_SERVER_NAME");
    std::string invalid_utf8_string("prefix");
    invalid_utf8_string.append(1, char(0xc3));
    invalid_utf8_string.append(1, char(0xc7));
    invalid_utf8_string.append("valid_middle");
    invalid_utf8_string.append(1, char(0xc4));
    invalid_utf8_string.append("valid_suffix");
    stream_info.downstream_connection_info_provider_->setRequestedServerName(invalid_utf8_string);
    EXPECT_EQ("invalid:prefix__valid_middle_valid_suffix",
              formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("invalid:prefix__valid_middle_valid_suffix")));
  }

  {
    StreamInfoFormatter listener_format("DOWNSTREAM_TRANSPORT_FAILURE_REASON");
    std::string downstream_transport_failure_reason = "TLS error";
    stream_info.setDownstreamTransportFailureReason(downstream_transport_failure_reason);
    EXPECT_EQ("TLS_error", formatForTest(listener_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(listener_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("TLS_error")));
  }
  {
    StreamInfoFormatter listener_format("DOWNSTREAM_TRANSPORT_FAILURE_REASON");
    std::string downstream_transport_failure_reason;
    stream_info.setDownstreamTransportFailureReason(downstream_transport_failure_reason);
    EXPECT_EQ(std::nullopt, formatForTest(listener_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(listener_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    StreamInfoFormatter listener_format("DOWNSTREAM_LOCAL_CLOSE_REASON");
    std::string downstream_local_close_reason = "transport_socket_timeout";
    stream_info.setDownstreamLocalCloseReason(downstream_local_close_reason);
    EXPECT_EQ("transport_socket_timeout", formatForTest(listener_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(listener_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("transport_socket_timeout")));
  }
  {
    StreamInfoFormatter listener_format("DOWNSTREAM_LOCAL_CLOSE_REASON");
    std::string downstream_local_close_reason;
    stream_info.setDownstreamLocalCloseReason(downstream_local_close_reason);
    EXPECT_EQ(std::nullopt, formatForTest(listener_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(listener_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    StreamInfoFormatter upstream_format("UPSTREAM_TRANSPORT_FAILURE_REASON");
    std::string upstream_transport_failure_reason = "SSL error";
    stream_info.upstreamInfo()->setUpstreamTransportFailureReason(
        upstream_transport_failure_reason);
    EXPECT_EQ("SSL_error", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("SSL_error")));
  }
  {
    StreamInfoFormatter upstream_format("UPSTREAM_TRANSPORT_FAILURE_REASON");
    std::string upstream_transport_failure_reason;
    stream_info.upstreamInfo()->setUpstreamTransportFailureReason(
        upstream_transport_failure_reason);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    StreamInfoFormatter ds_close_type_format("DOWNSTREAM_DETECTED_CLOSE_TYPE");
    stream_info.setDownstreamDetectedCloseType(StreamInfo::DetectedCloseType::Normal);
    EXPECT_EQ("Normal", formatForTest(ds_close_type_format, {}, stream_info));
    stream_info.setDownstreamDetectedCloseType(StreamInfo::DetectedCloseType::LocalReset);
    EXPECT_EQ("LocalReset", formatForTest(ds_close_type_format, {}, stream_info));
    stream_info.setDownstreamDetectedCloseType(StreamInfo::DetectedCloseType::RemoteReset);
    EXPECT_EQ("RemoteReset", formatForTest(ds_close_type_format, {}, stream_info));
  }
  {
    StreamInfoFormatter us_close_type_format("UPSTREAM_DETECTED_CLOSE_TYPE");
    stream_info.upstreamInfo()->setUpstreamDetectedCloseType(StreamInfo::DetectedCloseType::Normal);
    EXPECT_EQ("Normal", formatForTest(us_close_type_format, {}, stream_info));
    stream_info.upstreamInfo()->setUpstreamDetectedCloseType(
        StreamInfo::DetectedCloseType::LocalReset);
    EXPECT_EQ("LocalReset", formatForTest(us_close_type_format, {}, stream_info));
    stream_info.upstreamInfo()->setUpstreamDetectedCloseType(
        StreamInfo::DetectedCloseType::RemoteReset);
    EXPECT_EQ("RemoteReset", formatForTest(us_close_type_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_CLOSE_REASON");
    stream_info.upstreamInfo()->setUpstreamLocalCloseReason("local_close_reason");
    EXPECT_EQ("local_close_reason", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("local_close_reason")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_CLOSE_REASON");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    StreamInfoFormatter upstream_connection_pool_callback_duration_format(
        "UPSTREAM_CONNECTION_POOL_READY_DURATION");
    EXPECT_EQ(std::nullopt,
              formatForTest(upstream_connection_pool_callback_duration_format, {}, stream_info));
    EXPECT_THAT(
        formatValueForTest(upstream_connection_pool_callback_duration_format, {}, stream_info),
        ProtoEq(ValueUtil::nullValue()));
  }

  {
    StreamInfoFormatter upstream_connection_pool_callback_duration_format(
        "UPSTREAM_CONNECTION_POOL_READY_DURATION");
    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(25000000))));
    upstream_timing.recordConnectionPoolCallbackLatency(
        MonotonicTime(std::chrono::nanoseconds(10000000)), time_system);

    EXPECT_EQ("15",
              formatForTest(upstream_connection_pool_callback_duration_format, {}, stream_info));
    EXPECT_THAT(
        formatValueForTest(upstream_connection_pool_callback_duration_format, {}, stream_info),
        ProtoEq(ValueUtil::numberValue(15.0)));
  }

  {
    EXPECT_THAT(
        StreamInfoFormatter::create("COMMON_DURATION"),
        HasStatus(absl::StatusCode::kInvalidArgument, "COMMON_DURATION requires parameters"));
  }

  {
    EXPECT_THAT(
        StreamInfoFormatter::create("COMMON_DURATION", "a"),
        HasStatus(absl::StatusCode::kInvalidArgument, "Invalid common duration configuration: a."));
  }

  {
    EXPECT_THAT(StreamInfoFormatter::create("COMMON_DURATION", "a:b:c:d"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "Invalid common duration configuration: a:b:c:d."));
  }

  {
    EXPECT_THAT(
        StreamInfoFormatter::create("COMMON_DURATION", "a:b:zs"),
        HasStatus(absl::StatusCode::kInvalidArgument, "Invalid common duration precision: zs."));
  }

  {
    std::vector<std::string> time_points{
        "DS_RX_BEG", "DS_RX_HDR_END", "DS_RX_END",         "US_CX_BEG", "US_CX_END",
        "US_HS_END", "US_TX_BEG",     "US_TX_END",         "US_RX_BEG", "US_RX_END",
        "DS_TX_BEG", "DS_TX_END",     "custom_time_point", "DS_HS_BEG", "DS_HS_END",
    };

    std::vector<std::string> precisions{"ms", "us", "ns"};

    // No time points set.
    {
      NiceMock<StreamInfo::MockStreamInfo> stream_info;
      MockTimeSystem time_system;
      for (size_t start_index = 0; start_index < time_points.size(); start_index++) {
        for (size_t end_index = 0; end_index < time_points.size(); end_index++) {
          for (auto& precision : precisions) {
            const std::string sub_command =
                absl::StrCat(time_points[start_index], ":", time_points[end_index], ":", precision);
            StreamInfoFormatter duration_format("COMMON_DURATION", sub_command);

            if (start_index == end_index && start_index == 0) {
              EXPECT_EQ("0", formatForTest(duration_format, {}, stream_info));
              EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                          ProtoEq(ValueUtil::numberValue(0)));
            } else {
              EXPECT_EQ(std::nullopt, formatForTest(duration_format, {}, stream_info));
              EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                          ProtoEq(ValueUtil::nullValue()));
            }
          }
        }
      }
    }

    {
      NiceMock<StreamInfo::MockStreamInfo> stream_info;
      MockTimeSystem time_system;

      // DS_RX_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(1000000))));
      stream_info.start_time_monotonic_ = time_system.monotonicTime();

      // DS_RX_HDR_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(2000000))));
      stream_info.downstream_timing_.onLastDownstreamHeaderRxByteReceived(time_system);

      // DS_RX_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(3000000))));
      stream_info.downstream_timing_.onLastDownstreamRxByteReceived(time_system);

      // US_CX_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(4000000))));
      stream_info.upstream_info_->upstreamTiming().upstream_connect_start_ =
          time_system.monotonicTime();

      // US_CX_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(5000000))));
      stream_info.upstream_info_->upstreamTiming().upstream_connect_complete_ =
          time_system.monotonicTime();

      // US_HS_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(6000000))));
      stream_info.upstream_info_->upstreamTiming().upstream_handshake_complete_ =
          time_system.monotonicTime();

      // US_TX_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(7000000))));
      stream_info.upstream_info_->upstreamTiming().first_upstream_tx_byte_sent_ =
          time_system.monotonicTime();

      // US_TX_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(8000000))));
      stream_info.upstream_info_->upstreamTiming().last_upstream_tx_byte_sent_ =
          time_system.monotonicTime();

      // US_RX_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(9000000))));
      stream_info.upstream_info_->upstreamTiming().first_upstream_rx_byte_received_ =
          time_system.monotonicTime();

      // US_RX_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(10000000))));
      stream_info.upstream_info_->upstreamTiming().last_upstream_rx_byte_received_ =
          time_system.monotonicTime();

      // DS_TX_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(11000000))));
      stream_info.downstream_timing_.onFirstDownstreamTxByteSent(time_system);

      // DS_TX_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(12000000))));
      stream_info.downstream_timing_.onLastDownstreamTxByteSent(time_system);

      // custom_time_point
      stream_info.downstream_timing_.setValue("custom_time_point",
                                              MonotonicTime(std::chrono::nanoseconds(13000000)));

      // DS_HS_BEG
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(14000000))));
      stream_info.downstream_timing_.onDownstreamHandshakeStart(time_system);

      // DS_HS_END
      EXPECT_CALL(time_system, monotonicTime)
          .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(15000000))));
      stream_info.downstream_timing_.onDownstreamHandshakeComplete(time_system);

      for (size_t start_index = 0; start_index < time_points.size(); start_index++) {
        for (size_t end_index = 0; end_index < time_points.size(); end_index++) {
          uint64_t precision_factor = 1;
          for (auto& precision : precisions) {
            auto current_factor = precision_factor;
            precision_factor *= 1000;

            const std::string sub_command =
                absl::StrCat(time_points[start_index], ":", time_points[end_index], ":", precision);

            StreamInfoFormatter duration_format("COMMON_DURATION", sub_command);

            if (start_index > end_index) {
              EXPECT_EQ(std::nullopt, formatForTest(duration_format, {}, stream_info));
              EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                          ProtoEq(ValueUtil::nullValue()));
              continue;
            } else {
              const auto diff = (end_index - start_index) * current_factor;
              EXPECT_EQ(std::to_string(diff), formatForTest(duration_format, {}, stream_info));
              EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                          ProtoEq(ValueUtil::numberValue(diff)));
            }
          }
        }
      }
    }
  }

  {
    // DS_CX_BEG resolves to the downstream connection begin and DS_CX_END to the connection end.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    MockTimeSystem time_system;

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(1000000))));
    stream_info.start_time_monotonic_ = time_system.monotonicTime();

    // DS_CX_END is unset until the downstream connection closes.
    StreamInfoFormatter unset_format("COMMON_DURATION", "DS_CX_BEG:DS_CX_END:us");
    EXPECT_EQ(std::nullopt, formatForTest(unset_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(unset_format, {}, stream_info), ProtoEq(ValueUtil::nullValue()));

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(4000000))));
    stream_info.downstream_timing_.onDownstreamConnectionEnd(time_system);

    StreamInfoFormatter duration_format("COMMON_DURATION", "DS_CX_BEG:DS_CX_END:us");
    EXPECT_EQ("3000", formatForTest(duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(3000)));
  }

  {
    // DS_CX_BEG uses the downstream connection begin time point when set, instead of the stream
    // start time, so the connection duration reflects the whole connection for HTTP.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    MockTimeSystem time_system;

    stream_info.start_time_monotonic_ = MonotonicTime(std::chrono::nanoseconds(1000000));
    stream_info.downstream_timing_.setDownstreamConnectionBegin(
        MonotonicTime(std::chrono::nanoseconds(500000)));

    EXPECT_CALL(time_system, monotonicTime)
        .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(4000000))));
    stream_info.downstream_timing_.onDownstreamConnectionEnd(time_system);

    StreamInfoFormatter duration_format("COMMON_DURATION", "DS_CX_BEG:DS_CX_END:us");
    EXPECT_EQ("3500", formatForTest(duration_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(duration_format, {}, stream_info),
                ProtoEq(ValueUtil::numberValue(3500)));
  }
}

TEST(SubstitutionFormatterTest, streamInfoFormatterWithSsl) {
  EXPECT_THAT(StreamInfoFormatter::create("unknown_field"),
              HasStatusCode(absl::StatusCode::kInvalidArgument));

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;

    auto filter_chain_info = std::make_shared<NiceMock<Network::MockFilterChainInfo>>();
    filter_chain_info->filter_chain_name_ = "mock_filter_chain_name";

    stream_info.downstream_connection_info_provider_->setFilterChainInfo(filter_chain_info);

    StreamInfoFormatter upstream_format("FILTER_CHAIN_NAME");

    EXPECT_EQ("mock_filter_chain_name", formatForTest(upstream_format, {}, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;

    auto listener_info = std::make_shared<NiceMock<Network::MockListenerInfo>>();
    ON_CALL(*listener_info, name()).WillByDefault(Return("mock_listener_name"));
    stream_info.downstream_connection_info_provider_->setListenerInfo(listener_info);

    StreamInfoFormatter upstream_format("LISTENER_NAME");

    EXPECT_EQ("mock_listener_name", formatForTest(upstream_format, {}, stream_info));
  }

  {
    // No listener info set: the operator yields std::nullopt.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setListenerInfo(nullptr);
    StreamInfoFormatter upstream_format("LISTENER_NAME");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
  }

  {
    // Empty listener name: the operator yields std::nullopt.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto listener_info = std::make_shared<NiceMock<Network::MockListenerInfo>>();
    ON_CALL(*listener_info, name()).WillByDefault(Return(""));
    stream_info.downstream_connection_info_provider_->setListenerInfo(listener_info);
    StreamInfoFormatter upstream_format("LISTENER_NAME");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("VIRTUAL_CLUSTER_NAME");
    std::string virtual_cluster_name = "authN";
    stream_info.setVirtualClusterName(virtual_cluster_name);
    EXPECT_EQ("authN", formatForTest(upstream_format, {}, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("VIRTUAL_CLUSTER_NAME");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
  }

  {
    // Use a local stream info for these tests as as setSslConnection can only be called once.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, uriSanPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, uriSanPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, uriSanPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_URI_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    // Use a local stream info for these tests as as setSslConnection can only be called once.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_DNS_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    // Use a local stream info for these tests as as setSslConnection can only be called once.
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, ipSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, ipSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ipSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_IP_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, emailSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, emailSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, emailSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_EMAIL_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, othernameSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, othernameSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, othernameSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_OTHERNAME_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, uriSanLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, uriSanLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, uriSanLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_URI_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_DNS_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, ipSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, ipSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ipSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_IP_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, emailSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, emailSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_EMAIL_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, emailSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_EMAIL_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, othernameSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, othernameSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("san1,san2", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_OTHERNAME_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, othernameSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_OTHERNAME_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string subject_local = "subject";
    EXPECT_CALL(*connection_info, subjectLocalCertificate())
        .WillRepeatedly(ReturnRef(subject_local));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("subject", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("subject")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, subjectLocalCertificate())
        .WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_LOCAL_SUBJECT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string subject_peer = "subject";
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(subject_peer));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("subject", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("subject")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_SESSION_ID");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string session_id = "deadbeef";
    EXPECT_CALL(*connection_info, sessionId()).WillRepeatedly(ReturnRef(session_id));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("deadbeef", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("deadbeef")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_SESSION_ID");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, sessionId()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_SESSION_ID");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_CIPHER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ciphersuiteString())
        .WillRepeatedly(Return("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384"));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",
              formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_GROUP");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsGroupString).WillRepeatedly(Return("X25519MLKEM768"));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("X25519MLKEM768", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_GROUP");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsGroupString).WillRepeatedly(Return(""));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_CIPHER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ciphersuiteString()).WillRepeatedly(Return(""));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_CIPHER");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_VERSION");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string tlsVersion = "TLSv1.2";
    EXPECT_CALL(*connection_info, tlsVersion()).WillRepeatedly(ReturnRef(tlsVersion));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("TLSv1.2", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("TLSv1.2")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_VERSION");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsVersion()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_TLS_VERSION");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_sha = "685a2db593d5f86d346cb1a297009c3b467ad77f1944aa799039a2fb3d531f3f";
    EXPECT_CALL(*connection_info, sha256PeerCertificateDigest())
        .WillRepeatedly(ReturnRef(expected_sha));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(expected_sha, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(expected_sha)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_sha;
    EXPECT_CALL(*connection_info, sha256PeerCertificateDigest())
        .WillRepeatedly(ReturnRef(expected_sha));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_256");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_1");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_sha = "685a2db593d5f86d346cb1a297009c3b467ad77f1944aa799039a2fb3d531f3f";
    EXPECT_CALL(*connection_info, sha1PeerCertificateDigest())
        .WillRepeatedly(ReturnRef(expected_sha));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(expected_sha, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(expected_sha)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_1");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_sha;
    EXPECT_CALL(*connection_info, sha1PeerCertificateDigest())
        .WillRepeatedly(ReturnRef(expected_sha));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_FINGERPRINT_1");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SERIAL");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string serial_number = "b8b5ecc898f2124a";
    EXPECT_CALL(*connection_info, serialNumberPeerCertificate())
        .WillRepeatedly(ReturnRef(serial_number));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("b8b5ecc898f2124a", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("b8b5ecc898f2124a")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SERIAL");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, serialNumberPeerCertificate())
        .WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SERIAL");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::vector<std::string> expected_shas{
        "685a2db593d5f86d346cb1a297009c3b467ad77f1944aa799039a2fb3d531f3f",
        "1af1dfa857bf1d8814fe1af8983c18080019922e557f15a8a"};
    auto joined_shas = absl::StrJoin(expected_shas, ",");
    EXPECT_CALL(*connection_info, sha256PeerCertificateChainDigests())
        .WillRepeatedly(Return(expected_shas));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(joined_shas, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(joined_shas)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::vector<std::string> expected_shas;
    EXPECT_CALL(*connection_info, sha256PeerCertificateChainDigests())
        .WillRepeatedly(Return(expected_shas));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_256");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_1");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::vector<std::string> expected_shas{
        "685a2db593d5f86d346cb1a297009c3b467ad77f1944aa799039a2fb3d531f3f",
        "1af1dfa857bf1d8814fe1af8983c18080019922e557f15a8a"};
    auto joined_shas = absl::StrJoin(expected_shas, ",");
    EXPECT_CALL(*connection_info, sha1PeerCertificateChainDigests())
        .WillRepeatedly(Return(expected_shas));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(joined_shas, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(joined_shas)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_1");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::vector<std::string> expected_shas;
    EXPECT_CALL(*connection_info, sha1PeerCertificateChainDigests())
        .WillRepeatedly(Return(expected_shas));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_FINGERPRINTS_1");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_SERIALS");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::vector<std::string> serial_numbers{"b8b5ecc898f2124a", "9bf18bd79b46589902639871"};
    auto joined_serials = absl::StrJoin(serial_numbers, ",");
    EXPECT_CALL(*connection_info, serialNumbersPeerCertificates())
        .WillRepeatedly(Return(serial_numbers));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(joined_serials, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(joined_serials)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_SERIALS");
    std::vector<std::string> empty_vec;
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, serialNumbersPeerCertificates())
        .WillRepeatedly(Return(empty_vec));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CHAIN_SERIALS");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string issuer_peer =
        "CN=Test CA,OU=Lyft Engineering,O=Lyft,L=San Francisco,ST=California,C=US";
    EXPECT_CALL(*connection_info, issuerPeerCertificate()).WillRepeatedly(ReturnRef(issuer_peer));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("CN=Test CA,OU=Lyft Engineering,O=Lyft,L=San Francisco,ST=California,C=US",
              formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, issuerPeerCertificate()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_FINGERPRINT_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string issuer_hash =
        "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890";
    EXPECT_CALL(*connection_info, sha256PeerCertificateIssuerDigest())
        .WillRepeatedly(ReturnRef(issuer_hash));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
              formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_FINGERPRINT_256");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, sha256PeerCertificateIssuerDigest())
        .WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_FINGERPRINT_256");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_SERIAL");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string issuer_serial = "0123456789ABCDEF";
    EXPECT_CALL(*connection_info, serialNumberPeerCertificateIssuer())
        .WillRepeatedly(ReturnRef(issuer_serial));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("0123456789ABCDEF", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_SERIAL");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, serialNumberPeerCertificateIssuer())
        .WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_ISSUER_SERIAL");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string subject_peer =
        "CN=Test Server,OU=Lyft Engineering,O=Lyft,L=San Francisco,ST=California,C=US";
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(subject_peer));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("CN=Test Server,OU=Lyft Engineering,O=Lyft,L=San Francisco,ST=California,C=US",
              formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_SUBJECT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CERT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_cert = "<some cert>";
    EXPECT_CALL(*connection_info, urlEncodedPemEncodedPeerCertificate())
        .WillRepeatedly(ReturnRef(expected_cert));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(expected_cert, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(expected_cert)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CERT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_cert = "";
    EXPECT_CALL(*connection_info, urlEncodedPemEncodedPeerCertificate())
        .WillRepeatedly(ReturnRef(expected_cert));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("DOWNSTREAM_PEER_CERT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_SESSION_ID");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_SESSION_ID");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_SESSION_ID");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string session_id = "deadbeef";
    EXPECT_CALL(*connection_info, sessionId()).WillRepeatedly(ReturnRef(session_id));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("deadbeef", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("deadbeef")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_SESSION_ID");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, sessionId()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_SERVER_NAME");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_SERVER_NAME");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_SERVER_NAME");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string sni = "example.com";
    EXPECT_CALL(*connection_info, sni()).WillRepeatedly(ReturnRef(sni));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("example.com", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("example.com")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_SERVER_NAME");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, sni()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_CIPHER");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_CIPHER");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_CIPHER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ciphersuiteString())
        .WillRepeatedly(Return("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384"));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",
              formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_CIPHER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ciphersuiteString()).WillRepeatedly(Return(""));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_GROUP");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_GROUP");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsGroupString).WillRepeatedly(Return("X25519MLKEM768"));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("X25519MLKEM768", formatForTest(upstream_format, {}, stream_info));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_GROUP");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsGroupString).WillRepeatedly(Return(""));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_VERSION");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_VERSION");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_VERSION");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string tlsVersion = "TLSv1.2";
    EXPECT_CALL(*connection_info, tlsVersion()).WillRepeatedly(ReturnRef(tlsVersion));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("TLSv1.2", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("TLSv1.2")));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_TLS_VERSION");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, tlsVersion()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_ISSUER");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));

    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_ISSUER");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_ISSUER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, issuerPeerCertificate()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_ISSUER");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::string issuer_peer =
        "CN=Test CA,OU=Lyft Engineering,O=Lyft,L=San Francisco,ST=California,C=US";
    EXPECT_CALL(*connection_info, issuerPeerCertificate()).WillRepeatedly(ReturnRef(issuer_peer));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(issuer_peer, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(issuer_peer)));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_CERT");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_CERT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_CERT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, urlEncodedPemEncodedPeerCertificate())
        .WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_CERT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string expected_cert = "<some cert>";
    EXPECT_CALL(*connection_info, urlEncodedPemEncodedPeerCertificate())
        .WillRepeatedly(ReturnRef(expected_cert));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(expected_cert, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(expected_cert)));
  }
  // Test that the upstream peer uri san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, uriSanPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that peer URI SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, uriSanPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty peer URI SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, uriSanPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null peer URI SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_URI_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that the upstream peer DNS san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that peer DNS SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty peer DNS SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, dnsSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null peer DNS SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_DNS_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that the upstream peer IP san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, ipSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that peer IP SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, ipSansPeerCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty peer IP SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ipSansPeerCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null peer IP SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_IP_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that the upstream local DNS san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that local DNS SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty local DNS SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_DNS_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, dnsSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null local DNS SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_DNS_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that the upstream local URI san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, uriSanLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that local URI SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, uriSanLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty local URI SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_URI_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, uriSanLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null local URI SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_URI_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that the upstream local IP san is returned by the formatter.
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san"};
    EXPECT_CALL(*connection_info, ipSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("san", formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san")));
  }
  // Test that local IP SAN delimiter is applied correctly
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    const std::vector<std::string> sans{"san1", "san2"};
    EXPECT_CALL(*connection_info, ipSansLocalCertificate()).WillRepeatedly(Return(sans));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue("san1,san2")));
  }
  // Test that an empty local IP SAN list returns a null value
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_IP_SAN");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, ipSansLocalCertificate())
        .WillRepeatedly(Return(std::vector<std::string>()));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Test that a null connection returns a null local IP SAN
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_LOCAL_IP_SAN");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_SUBJECT");
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_SUBJECT");
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(EMPTY_STRING));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    StreamInfoFormatter upstream_format("UPSTREAM_PEER_SUBJECT");
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    std::string subject = "subject";
    EXPECT_CALL(*connection_info, subjectPeerCertificate()).WillRepeatedly(ReturnRef(subject));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(subject, formatForTest(upstream_format, {}, stream_info));
    EXPECT_THAT(formatValueForTest(upstream_format, {}, stream_info),
                ProtoEq(ValueUtil::stringValue(subject)));
  }
}

TEST(SubstitutionFormatterTest, requestedServerNameFormatter) {
  Event::SimulatedTimeSystem time_system;
  time_system.setSystemTime(std::chrono::milliseconds(0));
  auto connection_info_provider = std::make_shared<Network::ConnectionInfoSetterImpl>(
      std::make_shared<Network::Address::Ipv4Instance>("80.80.80.80"), nullptr);
  connection_info_provider->setRequestedServerName("outbound_.8080_._.example.com");
  Http::TestRequestHeaderMapImpl request_header{{":authority", "fake-authority"},
                                                {"x-envoy-original-host", "fake-original-host"}};
  StreamInfo::StreamInfoImpl stream_info{Http::Protocol::Http2, time_system,
                                         connection_info_provider,
                                         StreamInfo::FilterState::LifeSpan::FilterChain};

  stream_info.setRequestHeaders(request_header);

  StreamInfo::StreamInfoImpl stream_info_no_requested_name{
      Http::Protocol::Http2, time_system, nullptr, StreamInfo::FilterState::LifeSpan::FilterChain};
  stream_info_no_requested_name.setRequestHeaders(request_header);

  Http::TestRequestHeaderMapImpl empty_request_header;
  StreamInfo::StreamInfoImpl stream_info_no_requested_name_no_headers{
      Http::Protocol::Http2, time_system, nullptr, StreamInfo::FilterState::LifeSpan::FilterChain};
  stream_info_no_requested_name_no_headers.setRequestHeaders(empty_request_header);

  {
    auto providers = *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ(std::nullopt, formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));

    EXPECT_THAT(formatValueForTest(*providers[0], {}, stream_info),
                ProtoEq(ValueUtil::stringValue("outbound_.8080_._.example.com")));
    EXPECT_THAT(formatValueForTest(*providers[0], {}, stream_info_no_requested_name),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(SNI_ONLY)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ(std::nullopt, formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(SNI_FIRST)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-original-host",
              formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers = *SubstitutionFormatParser::parse(
        absl::StrCat("%REQUESTED_SERVER_NAME(SNI_FIRST:ORIG_OR_HOST)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-original-host",
              formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(SNI_FIRST:HOST)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-authority", formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(SNI_FIRST:ORIG)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("outbound_.8080_._.example.com", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-original-host",
              formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(HOST_FIRST:HOST)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("fake-authority", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-authority", formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(HOST_FIRST:ORIG)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("fake-original-host", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-original-host",
              formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }

  {
    auto providers =
        *SubstitutionFormatParser::parse(absl::StrCat("%REQUESTED_SERVER_NAME(HOST_FIRST)%"));
    EXPECT_EQ(providers.size(), 1);
    EXPECT_EQ("fake-original-host", formatForTest(*providers[0], {}, stream_info));
    EXPECT_EQ("fake-original-host",
              formatForTest(*providers[0], {}, stream_info_no_requested_name));
    EXPECT_EQ(std::nullopt,
              formatForTest(*providers[0], {}, stream_info_no_requested_name_no_headers));
  }
}

TEST(SubstitutionFormatterTest, requestHeaderFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header{{":method", "PUT"}};
  Http::TestResponseTrailerMapImpl response_trailer{{":method", "POST"}, {"test-2", "test-2"}};
  std::string body;

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>());
    EXPECT_EQ("GET", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("GET")));
  }

  {
    RequestHeaderFormatter formatter(":path", ":method", std::optional<size_t>());
    EXPECT_EQ("/", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("/")));
  }

  {
    RequestHeaderFormatter formatter(":TEST", ":METHOD", std::optional<size_t>());
    EXPECT_EQ("GET", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("GET")));
  }

  {
    RequestHeaderFormatter formatter("does_not_exist", "", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>(2));
    EXPECT_EQ("GE", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("GE")));
  }
}

TEST(SubstitutionFormatterTest, QueryParameterFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/path?x=xxxxxx"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header);

  {
    QueryParameterFormatter formatter("x", std::optional<size_t>());
    EXPECT_EQ("xxxxxx", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("xxxxxx")));
  }

  {
    QueryParameterFormatter formatter("y", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    QueryParameterFormatter formatter("x", std::optional<size_t>(2));
    EXPECT_EQ("xx", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("xx")));
  }

  {
    // No request headers at all.
    Context empty_context;
    QueryParameterFormatter formatter("x", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, empty_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, empty_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    // A path without any query string.
    Http::TestRequestHeaderMapImpl no_query_header{{":method", "GET"}, {":path", "/path"}};
    Context no_query_context;
    no_query_context.setRequestHeaders(no_query_header);

    QueryParameterFormatter formatter("x", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, no_query_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, no_query_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
}

TEST(SubstitutionFormatterTest, QueryParametersFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{
      {":method", "GET"}, {":path", "/path?x=xxxxxx&y=yyyyy&z=zzz&encoded=%23"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header);

  {
    EXPECT_THAT(SubstitutionFormatParser::parse("%QUERY_PARAMS(A)%"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "Invalid QUERY_PARAMS option: 'A', only 'ORIG'/'DECODED' are allowed"));
  }

  {
    auto formatter = QueryParametersFormatter::create("", std::optional<size_t>()).value();
    EXPECT_EQ("x=xxxxxx&y=yyyyy&z=zzz&encoded=%23",
              formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xxxxxx&y=yyyyy&z=zzz&encoded=%23")));
  }

  {

    auto formatter = QueryParametersFormatter::create("ORIG", std::optional<size_t>()).value();
    EXPECT_EQ("x=xxxxxx&y=yyyyy&z=zzz&encoded=%23",
              formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xxxxxx&y=yyyyy&z=zzz&encoded=%23")));
  }

  {

    auto formatter = QueryParametersFormatter::create("DECODED", std::optional<size_t>()).value();
    EXPECT_EQ("x=xxxxxx&y=yyyyy&z=zzz&encoded=#",
              formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xxxxxx&y=yyyyy&z=zzz&encoded=#")));
  }

  {
    auto formatter = QueryParametersFormatter::create("", std::optional<size_t>(4)).value();
    EXPECT_EQ("x=xx", formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xx")));
  }

  {
    auto formatter = QueryParametersFormatter::create("ORIG", std::optional<size_t>(4)).value();
    EXPECT_EQ("x=xx", formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xx")));
  }

  {
    auto formatter = QueryParametersFormatter::create("DECODED", std::optional<size_t>(4)).value();
    EXPECT_EQ("x=xx", formatForTest(*formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("x=xx")));
  }

  {
    // No request headers at all.
    Context empty_context;
    auto formatter = QueryParametersFormatter::create("", std::optional<size_t>()).value();
    EXPECT_EQ(std::nullopt, formatForTest(*formatter, empty_context, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, empty_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    // A path without any query string.
    Http::TestRequestHeaderMapImpl no_query_header{{":method", "GET"}, {":path", "/path"}};
    Context no_query_context;
    no_query_context.setRequestHeaders(no_query_header);

    for (absl::string_view decoding : {"", "ORIG", "DECODED"}) {
      auto formatter = QueryParametersFormatter::create(decoding, std::optional<size_t>()).value();
      EXPECT_EQ(std::nullopt, formatForTest(*formatter, no_query_context, stream_info));
      EXPECT_THAT(formatValueForTest(*formatter, no_query_context, stream_info),
                  ProtoEq(ValueUtil::nullValue()));
    }
  }
}

TEST(SubstitutionFormatterTest, headersByteSizeFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header{{":method", "PUT"}};
  Http::TestResponseTrailerMapImpl response_trailer{{":method", "POST"}, {"test-2", "test-2"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    HeadersByteSizeFormatter formatter(HeadersByteSizeFormatter::HeaderType::RequestHeaders);
    EXPECT_EQ(formatForTest(formatter, formatter_context, stream_info), "16");
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(16)));
  }
  {
    HeadersByteSizeFormatter formatter(HeadersByteSizeFormatter::HeaderType::ResponseHeaders);
    EXPECT_EQ(formatForTest(formatter, formatter_context, stream_info), "10");
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(10)));
  }
  {
    HeadersByteSizeFormatter formatter(HeadersByteSizeFormatter::HeaderType::ResponseTrailers);
    EXPECT_EQ(formatForTest(formatter, formatter_context, stream_info), "23");
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(23)));
  }
}

TEST(SubstitutionFormatterTest, responseHeaderFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header{{":method", "PUT"}, {"test", "test"}};
  Http::TestResponseTrailerMapImpl response_trailer{{":method", "POST"}, {"test-2", "test-2"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    ResponseHeaderFormatter formatter(":method", "", std::optional<size_t>());
    EXPECT_EQ("PUT", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("PUT")));
  }

  {
    ResponseHeaderFormatter formatter("test", ":method", std::optional<size_t>());
    EXPECT_EQ("test", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("test")));
  }

  {
    ResponseHeaderFormatter formatter(":path", ":method", std::optional<size_t>());
    EXPECT_EQ("PUT", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("PUT")));
  }

  {
    ResponseHeaderFormatter formatter("does_not_exist", "", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    ResponseHeaderFormatter formatter(":method", "", std::optional<size_t>(2));
    EXPECT_EQ("PU", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("PU")));
  }
}

TEST(SubstitutionFormatterTest, responseTrailerFormatter) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header{{":method", "PUT"}, {"test", "test"}};
  Http::TestResponseTrailerMapImpl response_trailer{{":method", "POST"}, {"test-2", "test-2"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    ResponseTrailerFormatter formatter(":method", "", std::optional<size_t>());
    EXPECT_EQ("POST", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("POST")));
  }

  {
    ResponseTrailerFormatter formatter("test-2", ":method", std::optional<size_t>());
    EXPECT_EQ("test-2", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("test-2")));
  }

  {
    ResponseTrailerFormatter formatter(":path", ":method", std::optional<size_t>());
    EXPECT_EQ("POST", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("POST")));
  }

  {
    ResponseTrailerFormatter formatter("does_not_exist", "", std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    ResponseTrailerFormatter formatter(":method", "", std::optional<size_t>(2));
    EXPECT_EQ("PO", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("PO")));
  }
}

// Helper to exercise the FormatterProvider::formatValueTo() sink API. It owns the output buffer,
// the JSON serializer that writes into it and the single-use value sink itself.
class ValueSinkHelper {
public:
  ValueSink& sink() { return sink_; }

  // True if the formatter added a value to the sink.
  bool consumed() const { return sink_.consumed(); }

  // The JSON serialized value that the formatter wrote to the sink. Empty if the formatter left
  // the sink unmodified.
  const std::string& output() const { return buffer_; }

private:
  std::string buffer_;
  JsonStringSerializer serializer_{buffer_};
  ValueSink sink_{serializer_};
};

TEST(SubstitutionFormatterTest, ValueSinkAddValue) {
  {
    ValueSinkHelper helper;
    helper.sink().addNumber(static_cast<uint64_t>(18446744073709551615U));
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("18446744073709551615", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addNumber(static_cast<int64_t>(-42));
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("-42", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addNumber(1.5);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("1.5", helper.output());
  }

  // NaN is not representable in JSON and is serialized as null.
  {
    ValueSinkHelper helper;
    helper.sink().addNumber(std::nan(""));
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("null", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addString("foo\"bar");
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("foo\"bar")", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addBool(true);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("true", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addBool(false);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("false", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addNull();
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("null", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addValue(ValueUtil::numberValue(2));
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("2", helper.output());
  }

  // An explicit null proto value is serialized rather than skipped.
  {
    ValueSinkHelper helper;
    helper.sink().addValue(ValueUtil::nullValue());
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("null", helper.output());
  }

  {
    ValueSinkHelper helper;
    Protobuf::Struct struct_value;
    struct_value.mutable_fields()->insert({"foo", ValueUtil::stringValue("bar")});
    helper.sink().addValue(struct_value);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"({"foo":"bar"})", helper.output());
  }

  {
    ValueSinkHelper helper;
    helper.sink().addValue(Protobuf::Struct());
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("{}", helper.output());
  }

  // A sink that was never written to is not consumed and produces no output.
  {
    ValueSinkHelper helper;
    EXPECT_FALSE(helper.consumed());
    EXPECT_EQ("", helper.output());
  }
}

TEST(SubstitutionFormatterTest, HeaderFormatterFormatToAndFormatValueTo) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{":method", "GET"}, {":path", "/"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header);

  // The main header is found.
  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>());

    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("GET", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("GET")", helper.output());
  }

  // The main header is found and the alternative header is not used.
  {
    RequestHeaderFormatter formatter(":path", ":method", std::optional<size_t>());

    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("/", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("/")", helper.output());
  }

  // The main header is missing and the alternative header is used.
  {
    RequestHeaderFormatter formatter(":TEST", ":METHOD", std::optional<size_t>());

    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("GET", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("GET")", helper.output());
  }

  // Neither header is found. formatTo() reports the failure and leaves the sink untouched and
  // formatValueTo() leaves the value sink unconsumed.
  {
    RequestHeaderFormatter formatter("does_not_exist", "", std::optional<size_t>());

    std::string sink = "existing";
    EXPECT_FALSE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("existing", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_FALSE(helper.consumed());
    EXPECT_EQ("", helper.output());
  }

  // The value is truncated to the max length.
  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>(2));

    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("GE", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("GE")", helper.output());
  }

  // formatTo() appends to the sink rather than overwriting it.
  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>());

    std::string sink = "method: ";
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ("method: GETGET", sink);
  }

  // The header value is JSON sanitized before it is written to the value sink but is written
  // verbatim to the string sink.
  {
    Http::TestRequestHeaderMapImpl special_header{{"x-header", R"(va"lue\)"}};
    Context special_context;
    special_context.setRequestHeaders(special_header);

    RequestHeaderFormatter formatter("x-header", "", std::optional<size_t>());

    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, special_context, stream_info));
    EXPECT_EQ(R"(va"lue\)", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), special_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("va\"lue\\")", helper.output());
  }

  // A header that is present but empty is still an extracted value.
  {
    Http::TestRequestHeaderMapImpl empty_value_header{{"x-header", ""}};
    Context empty_value_context;
    empty_value_context.setRequestHeaders(empty_value_header);

    RequestHeaderFormatter formatter("x-header", "", std::optional<size_t>());

    std::string sink = "value: ";
    EXPECT_TRUE(formatter.formatTo(sink, empty_value_context, stream_info));
    EXPECT_EQ("value: ", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), empty_value_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ(R"("")", helper.output());
  }

  // There are no request headers in the context at all.
  {
    RequestHeaderFormatter formatter(":Method", "", std::optional<size_t>());
    Context empty_context;

    std::string sink;
    EXPECT_FALSE(formatter.formatTo(sink, empty_context, stream_info));
    EXPECT_EQ("", sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), empty_context, stream_info);
    EXPECT_FALSE(helper.consumed());
    EXPECT_EQ("", helper.output());
  }
}

TEST(SubstitutionFormatterTest, HeaderFormattersReadTheirOwnHeaderMap) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"x-header", "request"}};
  Http::TestResponseHeaderMapImpl response_header{{"x-header", "response"}};
  Http::TestResponseTrailerMapImpl response_trailer{{"x-header", "trailer"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  const auto expect_value = [&](const FormatterProvider& formatter, const std::string& expected) {
    std::string sink;
    EXPECT_TRUE(formatter.formatTo(sink, formatter_context, stream_info));
    EXPECT_EQ(expected, sink);

    ValueSinkHelper helper;
    formatter.formatValueTo(helper.sink(), formatter_context, stream_info);
    EXPECT_TRUE(helper.consumed());
    EXPECT_EQ("\"" + expected + "\"", helper.output());
  };

  expect_value(RequestHeaderFormatter("x-header", "", std::optional<size_t>()), "request");
  expect_value(ResponseHeaderFormatter("x-header", "", std::optional<size_t>()), "response");
  expect_value(ResponseTrailerFormatter("x-header", "", std::optional<size_t>()), "trailer");
}

TEST(SubstitutionFormatterTest, LocalReplyBodyFormatter) {
  StreamInfo::MockStreamInfo stream_info;

  {
    Context formatter_context;
    formatter_context.setLocalReplyBody("local reply body");

    LocalReplyBodyFormatter formatter;
    EXPECT_EQ("local reply body", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("local reply body")));
  }

  {
    // An unset local reply body is reported as an empty string rather than as a missing value.
    Context formatter_context;

    LocalReplyBodyFormatter formatter;
    EXPECT_EQ("", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("")));
  }
}

TEST(SubstitutionFormatterTest, AccessLogTypeFormatter) {
  StreamInfo::MockStreamInfo stream_info;

  {
    Context formatter_context;
    formatter_context.setAccessLogType(AccessLogType::DownstreamEnd);

    AccessLogTypeFormatter formatter;
    EXPECT_EQ("DownstreamEnd", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("DownstreamEnd")));
  }

  {
    // The default (unspecified) log type still yields its enum name.
    Context formatter_context;

    AccessLogTypeFormatter formatter;
    EXPECT_EQ("NotSet", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("NotSet")));
  }
}

TEST(SubstitutionFormatterTest, TraceIDFormatter) {
  StreamInfo::MockStreamInfo stream_info;

  Tracing::MockSpan active_span;
  EXPECT_CALL(active_span, getTraceId()).WillRepeatedly(Return("ae0046f9075194306d7de2931bd38ce3"));

  {
    Context formatter_context;
    formatter_context.setActiveSpan(active_span);

    TraceIDFormatter formatter{};
    EXPECT_EQ("ae0046f9075194306d7de2931bd38ce3",
              formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("ae0046f9075194306d7de2931bd38ce3")));
  }

  {
    Context formatter_context;
    TraceIDFormatter formatter{};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    // Span present but getTraceId() returns empty (e.g. a tracer that doesn't expose the ID).
    Tracing::MockSpan empty_span;
    EXPECT_CALL(empty_span, getTraceId()).WillRepeatedly(Return(""));

    Context formatter_context;
    formatter_context.setActiveSpan(empty_span);

    TraceIDFormatter formatter{};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
}

TEST(SubstitutionFormatterTest, SpanIDFormatter) {
  StreamInfo::MockStreamInfo stream_info;

  {
    // Span present with valid span ID.
    Tracing::MockSpan active_span;
    EXPECT_CALL(active_span, getSpanId()).WillRepeatedly(Return("4041424344454647"));

    Context formatter_context;
    formatter_context.setActiveSpan(active_span);

    SpanIDFormatter formatter{};
    EXPECT_EQ("4041424344454647", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("4041424344454647")));
  }

  {
    // No active span.
    Context formatter_context;
    SpanIDFormatter formatter{};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    // Span present but getSpanId() returns empty (e.g., Zipkin, Datadog, SkyWalking).
    Tracing::MockSpan active_span;
    EXPECT_CALL(active_span, getSpanId()).WillRepeatedly(Return(""));

    Context formatter_context;
    formatter_context.setActiveSpan(active_span);

    SpanIDFormatter formatter{};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
}

/**
 * Populate a metadata object with the following test data:
 * "com.test":
 * {"test_key":"test_value","test_obj":{"inner_key":"inner_value"},"test_list":["item0",4.2]}
 */
void populateMetadataTestData(envoy::config::core::v3::Metadata& metadata) {
  Protobuf::Struct struct_obj;
  auto& fields_map = *struct_obj.mutable_fields();
  fields_map["test_key"] = ValueUtil::stringValue("test_value");
  Protobuf::Struct struct_inner;
  (*struct_inner.mutable_fields())["inner_key"] = ValueUtil::stringValue("inner_value");
  Protobuf::Value obj_value;
  *obj_value.mutable_struct_value() = struct_inner;
  fields_map["test_obj"] = obj_value;
  Protobuf::ListValue list_inner;
  *list_inner.add_values() = ValueUtil::stringValue("item0");
  *list_inner.add_values() = ValueUtil::numberValue(4.2);
  Protobuf::Value list_value;
  *list_value.mutable_list_value() = list_inner;
  fields_map["test_list"] = list_value;
  (*metadata.mutable_filter_metadata())["com.test"] = struct_obj;
}

TEST(SubstitutionFormatterTest, DynamicMetadataFieldExtractor) {
  Context formatter_context;
  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  EXPECT_CALL(stream_info, dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
  EXPECT_CALL(Const(stream_info), dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));

  {
    DynamicMetadataFormatter formatter("com.test", {}, std::optional<size_t>());
    std::string val = formatForTest(formatter, stream_info).value();
    EXPECT_THAT(val, HasSubstr(R"("test_key":"test_value")"));
    EXPECT_THAT(val, HasSubstr(R"("test_obj":{"inner_key":"inner_value"})"));
    EXPECT_THAT(val, HasSubstr(R"("test_list":["item0",4.2])"));

    Protobuf::Value expected_val;
    expected_val.mutable_struct_value()->CopyFrom(metadata.filter_metadata().at("com.test"));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(expected_val));
  }
  {
    DynamicMetadataFormatter formatter("com.test", {"test_key"}, std::optional<size_t>());
    EXPECT_EQ("test_value", formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_value")));
  }
  {
    DynamicMetadataFormatter formatter("com.test", {"test_obj"}, std::optional<size_t>());
    EXPECT_EQ("{\"inner_key\":\"inner_value\"}", formatForTest(formatter, stream_info));

    Protobuf::Value expected_val;
    (*expected_val.mutable_struct_value()->mutable_fields())["inner_key"] =
        ValueUtil::stringValue("inner_value");
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(expected_val));
  }
  {
    DynamicMetadataFormatter formatter("com.test", {"test_obj", "inner_key"},
                                       std::optional<size_t>());
    EXPECT_EQ("inner_value", formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("inner_value")));
  }

  // not found cases
  {
    DynamicMetadataFormatter formatter("com.notfound", {}, std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  {
    DynamicMetadataFormatter formatter("com.test", {"notfound"}, std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  {
    DynamicMetadataFormatter formatter("com.test", {"test_obj", "notfound"},
                                       std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }

  // size limit
  {
    DynamicMetadataFormatter formatter("com.test", {"test_key"}, std::optional<size_t>(5));
    EXPECT_EQ("test_", formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_")));
  }

  // size limit on struct
  {
    DynamicMetadataFormatter formatter("com.test", {"test_obj"}, std::optional<size_t>(5));
    // N.B. Does not truncate.
    Protobuf::Value expected_val;
    (*expected_val.mutable_struct_value()->mutable_fields())["inner_key"] =
        ValueUtil::stringValue("inner_value");
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(expected_val));
  }

  // size limit on list
  {
    DynamicMetadataFormatter formatter("com.test", {"test_list"}, std::optional<size_t>(5));
    // N.B. The value keeps its type and is not truncated...
    Protobuf::Value expected_val;
    expected_val.mutable_list_value()->add_values()->set_string_value("item0");
    expected_val.mutable_list_value()->add_values()->set_number_value(4.2);
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(expected_val));
    // ...but its rendered form is.
    EXPECT_EQ(R"(["ite)", formatForTest(formatter, stream_info));
  }

  // size limit on the whole namespace
  {
    DynamicMetadataFormatter formatter("com.test", {}, std::optional<size_t>(5));
    EXPECT_EQ(R"({"tes)", formatForTest(formatter, stream_info));

    Protobuf::Value expected_val;
    expected_val.mutable_struct_value()->CopyFrom(metadata.filter_metadata().at("com.test"));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(expected_val));
  }

  // A non-string scalar is rendered as JSON and, once truncated, becomes a string.
  {
    Protobuf::Struct& struct_obj = (*metadata.mutable_filter_metadata())["com.test"];
    (*struct_obj.mutable_fields())["test_num"] = ValueUtil::numberValue(1234);
    (*struct_obj.mutable_fields())["test_bool"] = ValueUtil::boolValue(true);

    {
      // No limit: the value keeps its type.
      DynamicMetadataFormatter formatter("com.test", {"test_num"}, std::optional<size_t>());
      EXPECT_EQ("1234", formatForTest(formatter, stream_info));
      EXPECT_THAT(formatValueForTest(formatter, stream_info),
                  ProtoEq(ValueUtil::numberValue(1234)));
    }
    {
      // A limit that doesn't bite leaves the value typed.
      DynamicMetadataFormatter formatter("com.test", {"test_num"}, std::optional<size_t>(10));
      EXPECT_EQ("1234", formatForTest(formatter, stream_info));
      EXPECT_THAT(formatValueForTest(formatter, stream_info),
                  ProtoEq(ValueUtil::numberValue(1234)));
    }
    {
      // A limit that bites turns the value into a truncated string.
      DynamicMetadataFormatter formatter("com.test", {"test_num"}, std::optional<size_t>(2));
      EXPECT_EQ("12", formatForTest(formatter, stream_info));
      EXPECT_THAT(formatValueForTest(formatter, stream_info),
                  ProtoEq(ValueUtil::stringValue("12")));
    }
    {
      DynamicMetadataFormatter formatter("com.test", {"test_bool"}, std::optional<size_t>());
      EXPECT_EQ("true", formatForTest(formatter, stream_info));
      EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::boolValue(true)));
    }
    {
      DynamicMetadataFormatter formatter("com.test", {"test_bool"}, std::optional<size_t>(2));
      EXPECT_EQ("tr", formatForTest(formatter, stream_info));
      EXPECT_THAT(formatValueForTest(formatter, stream_info),
                  ProtoEq(ValueUtil::stringValue("tr")));
    }

    struct_obj.mutable_fields()->erase("test_num");
    struct_obj.mutable_fields()->erase("test_bool");
  }

  {
    Protobuf::Value val;
    val.set_number_value(std::numeric_limits<double>::quiet_NaN());
    Protobuf::Struct struct_obj;
    (*struct_obj.mutable_fields())["nan_val"] = val;
    (*metadata.mutable_filter_metadata())["com.test"] = struct_obj;

    DynamicMetadataFormatter formatter("com.test", {"nan_val"}, std::optional<size_t>());
    std::optional<std::string> value = formatForTest(formatter, stream_info);
    EXPECT_EQ("null", value.value());
  }

  {
    Protobuf::Value val;
    val.set_number_value(std::numeric_limits<double>::infinity());
    Protobuf::Struct struct_obj;
    (*struct_obj.mutable_fields())["inf_val"] = val;
    (*metadata.mutable_filter_metadata())["com.test"] = struct_obj;

    DynamicMetadataFormatter formatter("com.test", {"inf_val"}, std::optional<size_t>());
    std::optional<std::string> value = formatForTest(formatter, stream_info);
    EXPECT_EQ("inf", value.value());
  }
}

// A metadata source that isn't available at all (no cluster info, no upstream host) is reported
// as a missing value by both the string and the value paths.
TEST(SubstitutionFormatterTest, MetadataFormatterWithoutMetadataSource) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;

  {
    EXPECT_CALL(Const(stream_info), upstreamClusterInfo())
        .WillRepeatedly(Return(OptRef<const Upstream::ClusterInfo>{}));

    ClusterMetadataFormatter formatter("com.test", {"test_key"}, std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::nullValue()));

    // The whole namespace form takes the same path.
    ClusterMetadataFormatter namespace_formatter("com.test", {}, std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(namespace_formatter, stream_info));
    EXPECT_THAT(formatValueForTest(namespace_formatter, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }

  {
    EXPECT_CALL(Const(stream_info), upstreamInfo()).WillRepeatedly(Return(std::nullopt));

    UpstreamHostMetadataFormatter formatter("com.test", {"test_key"}, std::optional<size_t>());
    EXPECT_EQ(std::nullopt, formatForTest(formatter, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
}

TEST(SubstitutionFormatterTest, FilterStateFormatter) {
  Context formatter_context;
  StreamInfo::MockStreamInfo stream_info;

  stream_info.filter_state_->setData("key",
                                     std::make_unique<Router::StringAccessorImpl>("test_value"));
  stream_info.filter_state_->setData("key-struct",
                                     std::make_unique<TestSerializedStructFilterState>());
  stream_info.filter_state_->setData("key-no-serialization",
                                     std::make_unique<StreamInfo::FilterState::Object>());

  stream_info.filter_state_->setData(
      "key-serialization-error",
      std::make_unique<TestSerializedStructFilterState>(std::chrono::seconds(-281474976710656)));
  stream_info.filter_state_->setData(
      "test_key", std::make_unique<TestSerializedStringFilterState>("test_value"));
  EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));

  {
    auto formatter =
        FilterStateFormatter::createForTest("key", std::optional<size_t>(), false).value();

    EXPECT_EQ("\"test_value\"", formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_value")));
  }
  {
    auto formatter =
        FilterStateFormatter::createForTest("key-struct", std::optional<size_t>(), false).value();

    EXPECT_EQ("{\"inner_key\":\"inner_value\"}", formatForTest(*formatter, stream_info));

    Protobuf::Value expected;
    (*expected.mutable_struct_value()->mutable_fields())["inner_key"] =
        ValueUtil::stringValue("inner_value");

    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(expected));
  }

  // not found case
  {
    auto formatter =
        FilterStateFormatter::createForTest("key-not-found", std::optional<size_t>(), false)
            .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }

  // no serialization case
  {
    auto formatter =
        FilterStateFormatter::createForTest("key-no-serialization", std::optional<size_t>(), false)
            .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }

  // serialization error case
  {
    auto formatter = FilterStateFormatter::createForTest("key-serialization-error",
                                                         std::optional<size_t>(), false)
                         .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }

  // size limit
  {
    auto formatter =
        FilterStateFormatter::createForTest("key", std::optional<size_t>(5), false).value();

    EXPECT_EQ("\"test", formatForTest(*formatter, stream_info));

    // N.B. Does not truncate.
    EXPECT_THAT(formatValueForTest(*formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_value")));
  }

  // serializeAsString case
  {
    auto formatter =
        FilterStateFormatter::createForTest("test_key", std::optional<size_t>(), true).value();

    EXPECT_EQ("test_value By PLAIN", formatForTest(*formatter, stream_info));
  }

  // size limit for serializeAsString
  {
    auto formatter =
        FilterStateFormatter::createForTest("test_key", std::optional<size_t>(10), true).value();

    EXPECT_EQ("test_value", formatForTest(*formatter, stream_info));
  }

  // no serialization case for serializeAsString
  {
    auto formatter =
        FilterStateFormatter::createForTest("key-no-serialization", std::optional<size_t>(), true)
            .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // FIELD test cases
  {
    auto formatter = FilterStateFormatter::createForTest("test_key", std::optional<size_t>(), false,
                                                         false, "test_field")
                         .value();

    EXPECT_EQ("test_value", formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_value")));
  }
  {
    auto formatter = FilterStateFormatter::createForTest("test_key", std::optional<size_t>(), false,
                                                         false, "test_num")
                         .value();

    EXPECT_EQ("137", formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("137")));
  }
  {
    auto formatter = FilterStateFormatter::createForTest("test_wrong_key", std::optional<size_t>(),
                                                         false, false, "test_field")
                         .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  {
    auto formatter = FilterStateFormatter::createForTest("test_key", std::optional<size_t>(), false,
                                                         false, "test_wrong_field")
                         .value();

    EXPECT_EQ(std::nullopt, formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  {
    auto formatter = FilterStateFormatter::createForTest("test_key", std::optional<size_t>(5),
                                                         false, false, "test_field")
                         .value();

    EXPECT_EQ("test_", formatForTest(*formatter, stream_info));
    EXPECT_THAT(formatValueForTest(*formatter, stream_info),
                ProtoEq(ValueUtil::stringValue("test_")));
  }
}

TEST(SubstitutionFormatterTest, DownstreamPeerCertVStartFormatter) {
  Context formatter_context;
  // No downstreamSslConnection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    auto cert_start_formart = makeTimeFormatter<DownstreamPeerCertVStartFormatter>(
                                  "DOWNSTREAM_PEER_CERT_V_START(%Y/%m/%d)")
                                  .value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_start_formart, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_start_formart, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // No validFromPeerCertificate
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_formart = makeTimeFormatter<DownstreamPeerCertVStartFormatter>(
                                  "DOWNSTREAM_PEER_CERT_V_START(%Y/%m/%d)")
                                  .value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(std::nullopt));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(*cert_start_formart, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_start_formart, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Default format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_format = makeTimeFormatter<DownstreamPeerCertVStartFormatter>("").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(AccessLogDateTimeFormatter::fromTime(time),
              formatForTest(*cert_start_format, stream_info));
  }
  // Custom format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_format =
        makeTimeFormatter<DownstreamPeerCertVStartFormatter>("%b %e %H:%M:%S %Y %Z").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("Mar 28 23:35:58 2018 UTC", formatForTest(*cert_start_format, stream_info));
  }
}

TEST(SubstitutionFormatterTest, DownstreamPeerCertVEndFormatter) {
  Context formatter_context;
  // No downstreamSslConnection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.downstream_connection_info_provider_->setSslConnection(nullptr);
    auto cert_end_format = makeTimeFormatter<DownstreamPeerCertVEndFormatter>("%Y/%m/%d").value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_end_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_end_format, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // No expirationPeerCertificate
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format = makeTimeFormatter<DownstreamPeerCertVEndFormatter>("%Y/%m/%d").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(std::nullopt));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(*cert_end_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_end_format, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // Default format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format = makeTimeFormatter<DownstreamPeerCertVEndFormatter>("").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ(AccessLogDateTimeFormatter::fromTime(time),
              formatForTest(*cert_end_format, stream_info));
  }
  // Custom format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format =
        makeTimeFormatter<DownstreamPeerCertVEndFormatter>("%b %e %H:%M:%S %Y %Z").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    EXPECT_EQ("Mar 28 23:35:58 2018 UTC", formatForTest(*cert_end_format, stream_info));
  }
}

TEST(SubstitutionFormatterTest, UpstreamPeerCertVStartFormatter) {
  Context formatter_context;
  // No upstream connection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));
    auto cert_start_format = makeTimeFormatter<UpstreamPeerCertVStartFormatter>("%Y/%m/%d").value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_start_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_start_format, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // No upstreamSslConnection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    auto cert_start_format =
        makeTimeFormatter<DownstreamPeerCertVStartFormatter>("UPSTREAM_PEER_CERT_V_START(%Y/%m/%d)")
            .value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_start_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_start_format, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // No validFromPeerCertificate
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_format =
        makeTimeFormatter<DownstreamPeerCertVStartFormatter>("UPSTREAM_PEER_CERT_V_START(%Y/%m/%d)")
            .value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(std::nullopt));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(*cert_start_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_start_format, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  // Default format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_format = makeTimeFormatter<UpstreamPeerCertVStartFormatter>("").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(AccessLogDateTimeFormatter::fromTime(time),
              formatForTest(*cert_start_format, stream_info));
  }
  // Custom format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_start_format =
        makeTimeFormatter<UpstreamPeerCertVStartFormatter>("%b %e %H:%M:%S %Y %Z").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("Mar 28 23:35:58 2018 UTC", formatForTest(*cert_start_format, stream_info));
  }
}

TEST(SubstitutionFormatterTest, UpstreamPeerCertVEndFormatter) {
  Context formatter_context;
  // No upstream connection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    EXPECT_CALL(stream_info, upstreamInfo()).WillRepeatedly(Return(nullptr));
    auto cert_end_format = makeTimeFormatter<UpstreamPeerCertVEndFormatter>("%Y/%m/%d").value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_end_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_end_format, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // No upstreamSslConnection
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    stream_info.upstreamInfo()->setUpstreamSslConnection(nullptr);
    auto cert_end_format = makeTimeFormatter<UpstreamPeerCertVEndFormatter>("%Y/%m/%d").value();
    EXPECT_EQ(std::nullopt, formatForTest(*cert_end_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_end_format, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // No expirationPeerCertificate
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format = makeTimeFormatter<UpstreamPeerCertVEndFormatter>("%Y/%m/%d").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(std::nullopt));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(std::nullopt, formatForTest(*cert_end_format, stream_info));
    EXPECT_THAT(formatValueForTest(*cert_end_format, stream_info), ProtoEq(ValueUtil::nullValue()));
  }
  // Default format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format = makeTimeFormatter<UpstreamPeerCertVEndFormatter>("").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ(AccessLogDateTimeFormatter::fromTime(time),
              formatForTest(*cert_end_format, stream_info));
  }
  // Custom format string
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    auto cert_end_format =
        makeTimeFormatter<UpstreamPeerCertVEndFormatter>("%b %e %H:%M:%S %Y %Z").value();
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.upstreamInfo()->setUpstreamSslConnection(connection_info);
    EXPECT_EQ("Mar 28 23:35:58 2018 UTC", formatForTest(*cert_end_format, stream_info));
  }
}

TEST(SubstitutionFormatterTest, StartTimeFormatter) {
  Context formatter_context;
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  Http::TestRequestHeaderMapImpl request_headers{{":method", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_headers;
  Http::TestResponseTrailerMapImpl response_trailers;
  std::string body;

  {
    auto start_time_format = makeTimeFormatter<StartTimeFormatter>("%Y/%m/%d").value();
    time_t test_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(time));
    EXPECT_EQ("2018/03/28", formatForTest(*start_time_format, stream_info));
    EXPECT_THAT(formatValueForTest(*start_time_format, stream_info),
                ProtoEq(ValueUtil::stringValue("2018/03/28")));
  }

  {
    auto start_time_format = makeTimeFormatter<StartTimeFormatter>("").value();
    SystemTime time;
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(time));
    EXPECT_EQ(AccessLogDateTimeFormatter::fromTime(time),
              formatForTest(*start_time_format, stream_info));
    EXPECT_THAT(formatValueForTest(*start_time_format, stream_info),
                ProtoEq(ValueUtil::stringValue(AccessLogDateTimeFormatter::fromTime(time))));
  }
}

TEST(SubstitutionFormatterTest, GrpcStatusFormatterCamelStringTest) {
  GrpcStatusFormatter formatter("grpc-status", "", std::optional<size_t>(),
                                GrpcStatusFormatter::Format::CamelString);
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"content-type", "application/grpc+proto"},
                                                {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header;
  Http::TestResponseTrailerMapImpl response_trailer;

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  std::vector<std::string> grpc_statuses{
      "OK",       "Canceled",       "Unknown",          "InvalidArgument",   "DeadlineExceeded",
      "NotFound", "AlreadyExists",  "PermissionDenied", "ResourceExhausted", "FailedPrecondition",
      "Aborted",  "OutOfRange",     "Unimplemented",    "Internal",          "Unavailable",
      "DataLoss", "Unauthenticated"};
  for (size_t i = 0; i < grpc_statuses.size(); ++i) {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", std::to_string(i)}};
    EXPECT_EQ(grpc_statuses[i], formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue(grpc_statuses[i])));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"not-a-grpc-status", "13"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("-1")));
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("42738")));
    response_trailer.clear();
  }
  {
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("-1")));
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("42738")));
    response_header.clear();
  }
  // Test "not gRPC request" with response_trailer
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "0"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_trailer.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
  // Test "not gRPC request" with response_header
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "2"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_header.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
}

TEST(SubstitutionFormatterTest, GrpcStatusFormatterSnakeStringTest) {
  GrpcStatusFormatter formatter("grpc-status", "", std::optional<size_t>(),
                                GrpcStatusFormatter::Format::SnakeString);
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"content-type", "application/grpc"},
                                                {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header;
  Http::TestResponseTrailerMapImpl response_trailer;

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  std::vector<std::string> grpc_statuses{"OK",
                                         "CANCELLED",
                                         "UNKNOWN",
                                         "INVALID_ARGUMENT",
                                         "DEADLINE_EXCEEDED",
                                         "NOT_FOUND",
                                         "ALREADY_EXISTS",
                                         "PERMISSION_DENIED",
                                         "RESOURCE_EXHAUSTED",
                                         "FAILED_PRECONDITION",
                                         "ABORTED",
                                         "OUT_OF_RANGE",
                                         "UNIMPLEMENTED",
                                         "INTERNAL",
                                         "UNAVAILABLE",
                                         "DATA_LOSS",
                                         "UNAUTHENTICATED"};
  for (size_t i = 0; i < grpc_statuses.size(); ++i) {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", std::to_string(i)}};
    EXPECT_EQ(grpc_statuses[i], formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue(grpc_statuses[i])));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"not-a-grpc-status", "13"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("-1")));
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("42738")));
    response_trailer.clear();
  }
  {
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("-1")));
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::stringValue("42738")));
    response_header.clear();
  }
  // Test "not gRPC request" with response_trailer
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "0"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_trailer.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
  // Test "not gRPC request" with response_header
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "2"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_header.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
}

TEST(SubstitutionFormatterTest, GrpcStatusFormatterNumberTest) {
  GrpcStatusFormatter formatter("grpc-status", "", std::optional<size_t>(),
                                GrpcStatusFormatter::Format::Number);
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"content-type", "application/grpc"},
                                                {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header;
  Http::TestResponseTrailerMapImpl response_trailer;

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  const int grpcStatuses = static_cast<int>(Grpc::Status::WellKnownGrpcStatus::MaximumKnown) + 1;

  for (size_t i = 0; i < grpcStatuses; ++i) {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", std::to_string(i)}};
    EXPECT_EQ(std::to_string(i), formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(i)));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"not-a-grpc-status", "13"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
  }
  {
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(-1)));
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(42738)));
    response_trailer.clear();
  }
  {
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "-1"}};
    EXPECT_EQ("-1", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(-1)));
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "42738"}};
    EXPECT_EQ("42738", formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::numberValue(42738)));
    response_header.clear();
  }
  // Test "not gRPC request" with response_trailer
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_trailer = Http::TestResponseTrailerMapImpl{{"grpc-status", "0"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_trailer.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
  // Test "not gRPC request" with response_header
  {
    request_header = {{":method", "GET"}, {":path", "/health"}};
    response_header = Http::TestResponseHeaderMapImpl{{"grpc-status", "2"}};
    EXPECT_EQ(std::nullopt, formatForTest(formatter, formatter_context, stream_info));
    EXPECT_THAT(formatValueForTest(formatter, formatter_context, stream_info),
                ProtoEq(ValueUtil::nullValue()));
    response_header.clear();
    request_header = {{":method", "GET"}, {":path", "/"}, {"content-type", "application/grpc"}};
  }
}

TEST(SubstitutionFormatterTest, JsonFormatterPlainStringTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  const std::string expected_json_map = R"EOF(
    {"plain_string": "plain_string_value"}
  )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    plain_string: plain_string_value
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterPlainNumberTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  const std::string expected_json_map = R"EOF(
    {"plain_number": 400}
  )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    plain_number: 400
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterTypesTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    string_type: plain_string_value
    struct_type:
      plain_string: plain_string_value
      protocol: '%PROTOCOL%'
    list_type:
      - plain_string_value
      - '%PROTOCOL%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  const Protobuf::Struct expected = TestUtility::jsonToStruct(R"EOF({
    "string_type": "plain_string_value",
    "struct_type": {
      "plain_string": "plain_string_value",
      "protocol": "HTTP/1.1"
    },
    "list_type": [
      "plain_string_value",
      "HTTP/1.1"
    ]
  })EOF");
  const Protobuf::Struct out_struct = TestUtility::jsonToStruct(formatter->format({}, stream_info));
  EXPECT_TRUE(TestUtility::protoEqual(out_struct, expected));
}

// Test that nested values are formatted properly, including inter-type nesting.
TEST(SubstitutionFormatterTest, JsonFormatterNestedObjectsTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  Protobuf::Struct key_mapping;
  // For both struct and list, we test 3 nesting levels of all types (string, struct and list).
  TestUtility::loadFromYaml(R"EOF(
    struct:
      struct_string: plain_string_value
      struct_protocol: '%PROTOCOL%'
      struct_struct:
        struct_struct_string: plain_string_value
        struct_struct_protocol: '%PROTOCOL%'
        struct_struct_struct:
          struct_struct_struct_string: plain_string_value
          struct_struct_struct_protocol: '%PROTOCOL%'
        struct_struct_list:
          - struct_struct_list_string
          - '%PROTOCOL%'
      struct_list:
        - struct_list_string
        - '%PROTOCOL%'
        # struct_list_struct
        - struct_list_struct_string: plain_string_value
          struct_list_struct_protocol: '%PROTOCOL%'
        # struct_list_list
        - - struct_list_list_string
          - '%PROTOCOL%'
    list:
      - list_string
      - '%PROTOCOL%'
      # list_struct
      - list_struct_string: plain_string_value
        list_struct_protocol: '%PROTOCOL%'
        list_struct_struct:
          list_struct_struct_string: plain_string_value
          list_struct_struct_protocol: '%PROTOCOL%'
        list_struct_list:
          - list_struct_list_string
          - '%PROTOCOL%'
      # list_list
      - - list_list_string
        - '%PROTOCOL%'
        # list_list_struct
        - list_list_struct_string: plain_string_value
          list_list_struct_protocol: '%PROTOCOL%'
        # list_list_list
        - - list_list_list_string
          - '%PROTOCOL%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();
  const Protobuf::Struct expected = TestUtility::jsonToStruct(R"EOF({
    "struct": {
      "struct_string": "plain_string_value",
      "struct_protocol": "HTTP/1.1",
      "struct_struct": {
        "struct_struct_string": "plain_string_value",
        "struct_struct_protocol": "HTTP/1.1",
        "struct_struct_struct": {
          "struct_struct_struct_string": "plain_string_value",
          "struct_struct_struct_protocol": "HTTP/1.1",
        },
        "struct_struct_list": [
          "struct_struct_list_string",
          "HTTP/1.1",
        ],
      },
      "struct_list": [
        "struct_list_string",
        "HTTP/1.1",
        {
          "struct_list_struct_string": "plain_string_value",
          "struct_list_struct_protocol": "HTTP/1.1",
        },
        [
          "struct_list_list_string",
          "HTTP/1.1",
        ],
      ],
    },
    "list": [
      "list_string",
      "HTTP/1.1",
      {
        "list_struct_string": "plain_string_value",
        "list_struct_protocol": "HTTP/1.1",
        "list_struct_struct": {
          "list_struct_struct_string": "plain_string_value",
          "list_struct_struct_protocol": "HTTP/1.1",
        },
        "list_struct_list": [
          "list_struct_list_string",
          "HTTP/1.1",
        ]
      },
      [
        "list_list_string",
        "HTTP/1.1",
        {
          "list_list_struct_string": "plain_string_value",
          "list_list_struct_protocol": "HTTP/1.1",
        },
        [
          "list_list_list_string",
          "HTTP/1.1",
        ],
      ],
    ],
  })EOF");
  const Protobuf::Struct out_struct = TestUtility::jsonToStruct(formatter->format({}, stream_info));
  EXPECT_TRUE(TestUtility::protoEqual(out_struct, expected));
}

TEST(SubstitutionFormatterTest, JsonFormatterSingleOperatorTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    protocol: '%PROTOCOL%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_THAT(TestUtility::jsonToStruct(formatter->format({}, stream_info)).fields(),
              UnorderedElementsAre(IsStructString("protocol", "HTTP/1.1")));
}

TEST(SubstitutionFormatterTest, EmptyJsonFormatterTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    protocol: ''
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_THAT(TestUtility::jsonToStruct(formatter->format({}, stream_info)).fields(),
              UnorderedElementsAre(IsStructString("protocol", "")));
}

TEST(SubstitutionFormatterTest, JsonFormatterNonExistentHeaderTest) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"some_request_header", "SOME_REQUEST_HEADER"}};
  Http::TestResponseHeaderMapImpl response_header{{"some_response_header", "SOME_RESPONSE_HEADER"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header).setResponseHeaders(response_header);

  const std::string expected_json_map = R"EOF({
    "protocol": "HTTP/1.1",
    "some_request_header": "SOME_REQUEST_HEADER",
    "nonexistent_response_header": null,
    "some_response_header": "SOME_RESPONSE_HEADER"
  })EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    protocol: '%PROTOCOL%'
    some_request_header: '%REQ(some_request_header)%'
    nonexistent_response_header: '%RESP(nonexistent_response_header)%'
    some_response_header: '%RESP(some_response_header)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format(formatter_context, stream_info),
                                           expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterAlternateHeaderTest) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header{
      {"request_present_header", "REQUEST_PRESENT_HEADER"}};
  Http::TestResponseHeaderMapImpl response_header{
      {"response_present_header", "RESPONSE_PRESENT_HEADER"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header).setResponseHeaders(response_header);

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    request_present_header_or_request_absent_header:
    '%REQ(request_present_header?request_absent_header)%'
    request_absent_header_or_request_present_header:
    '%REQ(request_absent_header?request_present_header)%'
    response_absent_header_or_response_absent_header:
    '%RESP(response_absent_header?response_present_header)%'
    response_present_header_or_response_absent_header:
    '%RESP(response_present_header?response_absent_header)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  EXPECT_THAT(
      TestUtility::jsonToStruct(formatter->format(formatter_context, stream_info)).fields(),
      UnorderedElementsAre(IsStructString("request_present_header_or_request_absent_header",
                                          "REQUEST_PRESENT_HEADER"),
                           IsStructString("request_absent_header_or_request_present_header",
                                          "REQUEST_PRESENT_HEADER"),
                           IsStructString("response_absent_header_or_response_absent_header",
                                          "RESPONSE_PRESENT_HEADER"),
                           IsStructString("response_present_header_or_response_absent_header",
                                          "RESPONSE_PRESENT_HEADER")));
}

TEST(SubstitutionFormatterTest, JsonFormatterDynamicMetadataTest) {
  StreamInfo::MockStreamInfo stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  EXPECT_CALL(stream_info, dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
  EXPECT_CALL(Const(stream_info), dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));

  const std::string expected_json_map = R"EOF({
    "test_key": "test_val",
    "test_key2": "test_test_val",
    "test_obj": {
      "inner_key": "inner_value"
    },
    "test_obj.inner_key": "inner_value"
  })EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%DYNAMIC_METADATA(com.test:test_key):8%'
    test_key2: '%DYNAMIC_METADATA(com.test:test_key):5%%DYNAMIC_METADATA(com.test:test_key):8%'
    test_obj: '%DYNAMIC_METADATA(com.test:test_obj)%'
    test_obj.inner_key: '%DYNAMIC_METADATA(com.test:test_obj:inner_key)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterClusterMetadataTest) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;

  Context formatter_context;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  auto cluster = std::make_shared<NiceMock<Upstream::MockClusterInfo>>();
  EXPECT_CALL(*cluster, metadata()).WillRepeatedly(ReturnRef(metadata));
  stream_info.upstream_cluster_info_ = cluster;

  const std::string expected_json_map = R"EOF({
    "test_key": "test_value",
    "test_obj": {
      "inner_key": "inner_value"
    },
    "test_obj.inner_key": "inner_value",
    "test_obj.non_existing_key": null
  })EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%CLUSTER_METADATA(com.test:test_key)%'
    test_obj: '%CLUSTER_METADATA(com.test:test_obj)%'
    test_obj.inner_key: '%CLUSTER_METADATA(com.test:test_obj:inner_key)%'
    test_obj.non_existing_key: '%CLUSTER_METADATA(com.test:test_obj:non_existing_key)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format(formatter_context, stream_info),
                                           expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterClusterMetadataNoClusterInfoTest) {
  StreamInfo::MockStreamInfo stream_info;

  Context formatter_context;

  const std::string expected_json_map = R"EOF(
      {"test_key": null}
    )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%CLUSTER_METADATA(com.test:test_key)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  // No cluster info
  {
    EXPECT_CALL(Const(stream_info), upstreamClusterInfo())
        .WillOnce(Return(OptRef<const Upstream::ClusterInfo>{}));
    EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format(formatter_context, stream_info),
                                             expected_json_map));
  }
}

TEST(SubstitutionFormatterTest, JsonFormatterUpstreamHostMetadataTest) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;

  Context formatter_context;

  const auto metadata = std::make_shared<envoy::config::core::v3::Metadata>();
  populateMetadataTestData(*metadata);
  // Get pointers to MockUpstreamInfo  and MockHostDescription.
  std::shared_ptr<StreamInfo::MockUpstreamInfo> mock_upstream_info =
      std::dynamic_pointer_cast<StreamInfo::MockUpstreamInfo>(stream_info.upstreamInfo());
  std::shared_ptr<const Upstream::MockHostDescription> mock_host_description =
      std::dynamic_pointer_cast<const Upstream::MockHostDescription>(
          mock_upstream_info->upstreamHost());
  EXPECT_CALL(*mock_host_description, metadata()).WillRepeatedly(Return(metadata));

  const std::string expected_json_map = R"EOF(
    {"test_key": "test_value",
    "test_obj": {
      "inner_key": "inner_value"
    },
    "test_obj.inner_key": "inner_value",
    "test_obj.non_existing_key": null
  })EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%UPSTREAM_METADATA(com.test:test_key)%'
    test_obj: '%UPSTREAM_METADATA(com.test:test_obj)%'
    test_obj.inner_key: '%UPSTREAM_METADATA(com.test:test_obj:inner_key)%'
    test_obj.non_existing_key: '%UPSTREAM_METADATA(com.test:test_obj:non_existing_key)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format(formatter_context, stream_info),
                                           expected_json_map));
}

TEST(SubstitutionFormatterTest, JsonFormatterUpstreamHostMetadataNullPtrs) {
  testing::NiceMock<StreamInfo::MockStreamInfo> stream_info;

  const std::string expected_json_map = R"EOF(
    {"test_key": null}
  )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%UPSTREAM_METADATA(com.test:test_key)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  // Empty optional (std::nullopt)
  {
    EXPECT_CALL(Const(stream_info), upstreamInfo()).WillOnce(Return(std::nullopt));
    EXPECT_TRUE(
        TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
    testing::Mock::VerifyAndClearExpectations(&stream_info);
  }
  // Empty host description info (nullptr)
  {
    std::shared_ptr<StreamInfo::MockUpstreamInfo> mock_upstream_info =
        std::dynamic_pointer_cast<StreamInfo::MockUpstreamInfo>(stream_info.upstreamInfo());
    EXPECT_CALL(*mock_upstream_info, upstreamHost()).WillOnce(Return(nullptr));
    EXPECT_TRUE(
        TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
  }
}

TEST(SubstitutionFormatterTest, JsonFormatterFilterStateTest) {
  StreamInfo::MockStreamInfo stream_info;

  stream_info.filter_state_->setData("test_key",
                                     std::make_unique<Router::StringAccessorImpl>("test_value"));
  stream_info.filter_state_->setData("test_obj",
                                     std::make_unique<TestSerializedStructFilterState>());
  EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));

  const std::string expected_json_map = R"EOF(
    {
      "test_key": "test_value",
      "test_obj": {
        "inner_key": "inner_value"
      }
    }
  )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key: '%FILTER_STATE(test_key)%'
    test_obj: '%FILTER_STATE(test_obj)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
}

// Test new specifier (PLAIN/TYPED) of FilterState. Ensure that after adding additional specifier,
// the FilterState can call the serializeAsProto or serializeAsString methods correctly.
TEST(SubstitutionFormatterTest, FilterStateSpeciferTest) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;

  stream_info.filter_state_->setData(
      "test_key", std::make_unique<TestSerializedStringFilterState>("test_value"));
  stream_info.upstream_info_->setUpstreamFilterState(
      stream_info.filter_state_); // Reuse the same filter state for test only.
  EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));

  const std::string expected_json_map = R"EOF(
    {
      "test_key_plain": "test_value By PLAIN",
      "test_key_typed": "test_value By TYPED",
      "test_key_field": "test_value",
      "upstream_test_key_plain": "test_value By PLAIN",
      "upstream_test_key_typed": "test_value By TYPED",
      "upstream_test_key_field": "test_value"
    }
  )EOF";

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key_plain: '%FILTER_STATE(test_key:PLAIN)%'
    test_key_typed: '%FILTER_STATE(test_key:TYPED)%'
    test_key_field: '%FILTER_STATE(test_key:FIELD:test_field)%'
    upstream_test_key_plain: '%UPSTREAM_FILTER_STATE(test_key:PLAIN)%'
    upstream_test_key_typed: '%UPSTREAM_FILTER_STATE(test_key:TYPED)%'
    upstream_test_key_field: '%UPSTREAM_FILTER_STATE(test_key:FIELD:test_field)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_TRUE(TestUtility::jsonStringEqual(formatter->format({}, stream_info), expected_json_map));
}

// Error specifier will cause an exception to be thrown.
TEST(SubstitutionFormatterTest, FilterStateErrorSpeciferTest) {
  StreamInfo::MockStreamInfo stream_info;

  stream_info.filter_state_->setData(
      "test_key", std::make_unique<TestSerializedStringFilterState>("test_value"));

  // 'ABCDE' is error specifier.
  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key_plain: '%FILTER_STATE(test_key:ABCDE)%'
    test_key_typed: '%FILTER_STATE(test_key:TYPED)%'
  )EOF",
                            key_mapping);
  EXPECT_THAT(JsonFormatterImpl::create(key_mapping, false),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "Invalid filter state serialize type, only support PLAIN/TYPED/FIELD."));
}

// Error specifier for PLAIN will cause an error if field is specified.
TEST(SubstitutionFormatterTest, FilterStateErrorSpeciferFieldTest) {
  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key_plain: '%FILTER_STATE(test_key:PLAIN:test_field)%'
  )EOF",
                            key_mapping);
  EXPECT_THAT(JsonFormatterImpl::create(key_mapping, false),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "Invalid filter state serialize type, FIELD "
                        "should be used with the field name."));
}

// Error specifier for FIELD will cause an exception to be thrown if no field is specified.
TEST(SubstitutionFormatterTest, FilterStateErrorSpeciferFieldNoNameTest) {
  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    test_key_plain: '%FILTER_STATE(test_key:FIELD)%'
  )EOF",
                            key_mapping);
  EXPECT_THAT(JsonFormatterImpl::create(key_mapping, false),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "Invalid filter state serialize type, FIELD "
                        "should be used with the field name."));
}

TEST(SubstitutionFormatterTest, JsonFormatterStartTimeTest) {
  StreamInfo::MockStreamInfo stream_info;

  time_t expected_time_in_epoch = 1522280158;
  SystemTime time = std::chrono::system_clock::from_time_t(expected_time_in_epoch);
  EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(time));

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    simple_date: '%START_TIME(%Y/%m/%d)%'
    test_time: '%START_TIME(%s)%'
    test_time_local: '%START_TIME_LOCAL(%s)%'
    bad_format: '%START_TIME(bad_format)%'
    default: '%START_TIME%'
    default_local: '%START_TIME_LOCAL%'
    all_zeroes: '%START_TIME(%f.%1f.%2f.%3f)%'
  )EOF",
                            key_mapping);
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

  EXPECT_THAT(TestUtility::jsonToStruct(formatter->format({}, stream_info)).fields(),
              UnorderedElementsAre(
                  IsStructString("simple_date", "2018/03/28"),
                  IsStructString("test_time", fmt::format("{}", expected_time_in_epoch)),
                  IsStructString("test_time_local", fmt::format("{}", expected_time_in_epoch)),
                  IsStructString("bad_format", "bad_format"),
                  IsStructString("default", "2018-03-28T23:35:58.000Z"),
                  IsStructString("default_local",
                                 absl::FormatTime("%Y-%m-%dT%H:%M:%E3S%z", absl::FromChrono(time),
                                                  absl::LocalTimeZone())),
                  IsStructString("all_zeroes", "000000000.0.00.000")));
}

TEST(SubstitutionFormatterTest, JsonFormatterMultiTokenTest) {
  {
    StreamInfo::MockStreamInfo stream_info;
    Http::TestRequestHeaderMapImpl request_header{{"some_request_header", "SOME_REQUEST_HEADER"}};
    Http::TestResponseHeaderMapImpl response_header{
        {"some_response_header", "SOME_RESPONSE_HEADER"}};

    Context formatter_context;
    formatter_context.setRequestHeaders(request_header).setResponseHeaders(response_header);

    Protobuf::Struct key_mapping;
    TestUtility::loadFromYaml(R"EOF(
      multi_token_field: '%PROTOCOL% plainstring %REQ(some_request_header)%
      %RESP(some_response_header)%'
    )EOF",
                              key_mapping);
    auto formatter = JsonFormatterImpl::create(key_mapping, false).value();

    std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
    EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

    EXPECT_THAT(
        TestUtility::jsonToStruct(formatter->format(formatter_context, stream_info)).fields(),
        UnorderedElementsAre(IsStructString(
            "multi_token_field", "HTTP/1.1 plainstring SOME_REQUEST_HEADER SOME_RESPONSE_HEADER")));
  }
}

TEST(SubstitutionFormatterTest, JsonFormatterTest) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;
  Http::TestRequestHeaderMapImpl request_header{{"key_1", "value_1"},
                                                {"key_2", R"(value_with_quotes_"_)"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header);

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));
  MockTimeSystem time_system;
  EXPECT_CALL(time_system, monotonicTime)
      .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(5000000))));
  stream_info.downstream_timing_.onLastDownstreamRxByteReceived(time_system);

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    raw_bool_value: true
    raw_nummber_value: 6
    nested_list:
      - 14
      - "3.14"
      - false
      - "ok"
      - '%REQ(key_1)%'
      - '%REQ(error)%'
    request_duration: '%REQUEST_DURATION%'
    nested_level:
      plain_string: plain_string_value
      protocol: '%PROTOCOL%'
    request_key: '%REQ(key_1)%_@!!!_"_%REQ(key_2)%'
    key: {}
  )EOF",
                            key_mapping);

  const std::string expected = R"EOF({
    "raw_bool_value": true,
    "raw_nummber_value": 6,
    "nested_list": [
      14,
      "3.14",
      false,
      "ok",
      "value_1",
      null
    ],
    "request_duration": 5,
    "nested_level": {
      "plain_string": "plain_string_value",
      "protocol": "HTTP/1.1"
    },
    "request_key": "value_1_@!!!_\"_value_with_quotes_\"_",
    "key": {}
  })EOF";

  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();
  const std::string out_json = formatter->format(formatter_context, stream_info);
  EXPECT_TRUE(TestUtility::jsonStringEqual(out_json, expected));
}

TEST(SubstitutionFormatterTest, JsonFormatterWithOrderedPropertiesTest) {
  NiceMock<StreamInfo::MockStreamInfo> stream_info;

  envoy::config::core::v3::Metadata metadata;
  populateMetadataTestData(metadata);
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));
  MockTimeSystem time_system;
  EXPECT_CALL(time_system, monotonicTime)
      .WillOnce(Return(MonotonicTime(std::chrono::nanoseconds(5000000))));
  stream_info.downstream_timing_.onLastDownstreamRxByteReceived(time_system);

  Protobuf::Struct key_mapping;
  TestUtility::loadFromYaml(R"EOF(
    request_duration: '%REQUEST_DURATION%'
    bfield: valb
    afield: vala
    nested_level:
      plain_string: plain_string_value
      cfield: valc
      protocol: '%PROTOCOL%'
  )EOF",
                            key_mapping);

  const std::string expected = "{"
                               "\"afield\":\"vala\","
                               "\"bfield\":\"valb\","
                               "\"nested_level\":"
                               "{"
                               "\"cfield\":\"valc\","
                               "\"plain_string\":\"plain_string_value\","
                               "\"protocol\":\"HTTP/1.1\""
                               "},"
                               "\"request_duration\":5"
                               "}\n";

  // The formatter will always order the properties alphabetically.
  auto formatter = JsonFormatterImpl::create(key_mapping, false).value();
  const std::string out_json = formatter->format({}, stream_info);
  // Check string equality to verify the order.
  EXPECT_EQ(out_json, expected);
}

TEST(SubstitutionFormatterTest, CompositeFormatterSuccess) {
  Http::TestRequestHeaderMapImpl request_header{{"first", "GET"}, {":path", "/"}};
  Http::TestResponseHeaderMapImpl response_header{{"second", "PUT"}, {"test", "test"}};
  Http::TestResponseTrailerMapImpl response_trailer{{"third", "POST"}, {"test-2", "test-2"}};

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    const std::string format = "{{%PROTOCOL%}}   %RESP(not_exist)%++%RESP(test)% "
                               "%REQ(FIRST?SECOND)%/%REQUEST_HEADER(FIRST?SECOND)% "
                               "%RESP(FIRST?SECOND)%/%RESPONSE_HEADER(FIRST?SECOND)% "
                               "\t@%TRAILER(THIRD)%@\t%TRAILER(TEST?TEST-2)%[] "
                               "%RESPONSE_TRAILER(THIRD)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
    EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

    EXPECT_EQ("{{HTTP/1.1}}   -++test GET/GET PUT/PUT \t@POST@\ttest-2[] POST",
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    const std::string format = "{}*JUST PLAIN string]";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ(format, formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    const std::string format = "%REQ(first):3%|%REQ(first):1%|%RESP(first?second):2%|%REQ(first):"
                               "10%|%TRAILER(second?third):3%";

    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("GET|G|PU|GET|POS", formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    envoy::config::core::v3::Metadata metadata;
    populateMetadataTestData(metadata);
    EXPECT_CALL(stream_info, dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    EXPECT_CALL(Const(stream_info), dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    const std::string format = "%DYNAMIC_METADATA(com.test:test_key)%|%DYNAMIC_METADATA(com.test:"
                               "test_obj)%|%DYNAMIC_METADATA(com.test:test_obj:inner_key)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("test_value|{\"inner_key\":\"inner_value\"}|inner_value",
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));
    stream_info.filter_state_->setData("testing",
                                       std::make_unique<Router::StringAccessorImpl>("test_value"),
                                       StreamInfo::FilterState::LifeSpan::FilterChain);
    stream_info.filter_state_->setData("serialized",
                                       std::make_unique<TestSerializedUnknownFilterState>(),
                                       StreamInfo::FilterState::LifeSpan::FilterChain);
    const std::string format = "%FILTER_STATE(testing)%|%FILTER_STATE(serialized)%|"
                               "%FILTER_STATE(testing):8%|%FILTER_STATE(nonexisting)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("\"test_value\"|-|\"test_va|-", formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // Various START_TIME formats
    const std::string format = "%START_TIME(%Y/%m/%d)%|%START_TIME(%s)%|%START_TIME(bad_format)%|"
                               "%START_TIME%|%START_TIME(%f.%1f.%2f.%3f)%";

    time_t expected_time_in_epoch = 1522280158;
    SystemTime time = std::chrono::system_clock::from_time_t(expected_time_in_epoch);
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ(fmt::format("2018/03/28|{}|bad_format|2018-03-28T23:35:58.000Z|000000000.0.00.000",
                          expected_time_in_epoch),
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // Various DOWNSTREAM_PEER_CERT_V_START formats (similar to START_TIME)
    const std::string format =
        "%DOWNSTREAM_PEER_CERT_V_START(%Y/%m/"
        "%d)%|%DOWNSTREAM_PEER_CERT_V_START(%s)%|%DOWNSTREAM_PEER_CERT_V_START(bad_format)%|"
        "%DOWNSTREAM_PEER_CERT_V_START%|%DOWNSTREAM_PEER_CERT_V_START(%f.%1f.%2f.%3f)%";

    time_t expected_time_in_epoch = 1522280158;
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    SystemTime time = std::chrono::system_clock::from_time_t(expected_time_in_epoch);
    EXPECT_CALL(*connection_info, validFromPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ(fmt::format("2018/03/28|{}|bad_format|2018-03-28T23:35:58.000Z|000000000.0.00.000",
                          expected_time_in_epoch),
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // Various DOWNSTREAM_PEER_CERT_V_END formats (similar to START_TIME)
    const std::string format =
        "%DOWNSTREAM_PEER_CERT_V_END(%Y/%m/"
        "%d)%|%DOWNSTREAM_PEER_CERT_V_END(%s)%|%DOWNSTREAM_PEER_CERT_V_END(bad_format)%|"
        "%DOWNSTREAM_PEER_CERT_V_END%|%DOWNSTREAM_PEER_CERT_V_END(%f.%1f.%2f.%3f)%";

    time_t expected_time_in_epoch = 1522280158;
    auto connection_info = std::make_shared<Ssl::MockConnectionInfo>();
    SystemTime time = std::chrono::system_clock::from_time_t(expected_time_in_epoch);
    EXPECT_CALL(*connection_info, expirationPeerCertificate()).WillRepeatedly(Return(time));
    stream_info.downstream_connection_info_provider_->setSslConnection(connection_info);
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ(fmt::format("2018/03/28|{}|bad_format|2018-03-28T23:35:58.000Z|000000000.0.00.000",
                          expected_time_in_epoch),
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // This tests the beginning of time.
    const std::string format = "%START_TIME(%Y/%m/%d)%|%START_TIME(%s)%|%START_TIME(bad_format)%|"
                               "%START_TIME%|%START_TIME(%f.%1f.%2f.%3f)%";

    const time_t test_epoch = 0;
    const SystemTime time = std::chrono::system_clock::from_time_t(test_epoch);
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("1970/01/01|0|bad_format|1970-01-01T00:00:00.000Z|000000000.0.00.000",
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // This tests multiple START_TIMEs.
    const std::string format =
        "%START_TIME(%s.%3f)%|%START_TIME(%s.%4f)%|%START_TIME(%s.%5f)%|%START_TIME(%s.%6f)%";
    const SystemTime start_time(std::chrono::microseconds(1522796769123456));
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(start_time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);
    EXPECT_EQ("1522796769.123|1522796769.1234|1522796769.12345|1522796769.123456",
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    const std::string format =
        "%START_TIME(segment1:%s.%3f|segment2:%s.%4f|seg3:%s.%6f|%s-%3f-asdf-%9f|.%7f:segm5:%Y)%";
    const SystemTime start_time(std::chrono::microseconds(1522796769123456));
    EXPECT_CALL(stream_info, startTime()).WillRepeatedly(Return(start_time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);
    EXPECT_EQ("segment1:1522796769.123|segment2:1522796769.1234|seg3:1522796769.123456|1522796769-"
              "123-asdf-123456000|.1234560:segm5:2018",
              formatter->format(formatter_context, stream_info));
  }

  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    // This tests START_TIME specifier that has shorter segments when formatted, i.e.
    // absl::FormatTime("%%%%"") equals "%%", %1f will have 1 as its size.
    const std::string format = "%START_TIME(%%%%|%%%%%f|%s%%%%%3f|%1f%%%%%s)%";
    const SystemTime start_time(std::chrono::microseconds(1522796769123456));
    EXPECT_CALL(stream_info, startTime()).WillOnce(Return(start_time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);
    EXPECT_EQ("%%|%%123456000|1522796769%%123|1%%1522796769",
              formatter->format(formatter_context, stream_info));
  }

  // The %E formatting option in Absl::FormatTime() behaves differently for non Linux platforms.
  //
  // See:
  // https://github.com/abseil/abseil-cpp/issues/869
  // https://github.com/google/cctz/issues/180
#if !defined(WIN32) && !defined(__APPLE__)
  {
    NiceMock<StreamInfo::MockStreamInfo> stream_info;
    const std::string format = "%START_TIME(%E4n)%";
    const SystemTime start_time(std::chrono::microseconds(1522796769123456));
    EXPECT_CALL(stream_info, startTime()).WillOnce(Return(start_time));
    FormatterPtr formatter = *FormatterImpl::create(format, false);
    EXPECT_EQ("%E4n", formatter->format(formatter_context, stream_info));
  }
#endif
}

TEST(SubstitutionFormatterTest, CompositeFormatterEmpty) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_header;
  Http::TestResponseHeaderMapImpl response_header;
  Http::TestResponseTrailerMapImpl response_trailer;

  Context formatter_context;
  formatter_context.setRequestHeaders(request_header)
      .setResponseHeaders(response_header)
      .setResponseTrailers(response_trailer);

  {
    const std::string format = "%PROTOCOL%|%RESP(not_exist)%|"
                               "%REQ(FIRST?SECOND)%|%RESP(FIRST?SECOND)%|"
                               "%TRAILER(THIRD)%|%TRAILER(TEST?TEST-2)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(std::nullopt));

    EXPECT_EQ("-|-|-|-|-|-", formatter->format(formatter_context, stream_info));
  }

  {
    const std::string format = "%PROTOCOL%|%RESP(not_exist)%|"
                               "%REQ(FIRST?SECOND)%%RESP(FIRST?SECOND)%|"
                               "%TRAILER(THIRD)%|%TRAILER(TEST?TEST-2)%";
    FormatterPtr formatter = *FormatterImpl::create(format, true);

    EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(std::nullopt));

    EXPECT_EQ("||||", formatter->format({}, stream_info));
  }

  {
    envoy::config::core::v3::Metadata metadata;
    EXPECT_CALL(stream_info, dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    EXPECT_CALL(Const(stream_info), dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    const std::string format = "%DYNAMIC_METADATA(com.test:test_key)%|%DYNAMIC_METADATA(com.test:"
                               "test_obj)%|%DYNAMIC_METADATA(com.test:test_obj:inner_key)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("-|-|-", formatter->format(formatter_context, stream_info));
  }

  {
    envoy::config::core::v3::Metadata metadata;
    EXPECT_CALL(stream_info, dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    EXPECT_CALL(Const(stream_info), dynamicMetadata()).WillRepeatedly(ReturnRef(metadata));
    const std::string format = "%DYNAMIC_METADATA(com.test:test_key)%|%DYNAMIC_METADATA(com.test:"
                               "test_obj)%|%DYNAMIC_METADATA(com.test:test_obj:inner_key)%";
    FormatterPtr formatter = *FormatterImpl::create(format, true);

    EXPECT_EQ("||", formatter->format(formatter_context, stream_info));
  }

  {
    EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));
    const std::string format = "%FILTER_STATE(testing)%|%FILTER_STATE(serialized)%|"
                               "%FILTER_STATE(testing):8%|%FILTER_STATE(nonexisting)%";
    FormatterPtr formatter = *FormatterImpl::create(format, false);

    EXPECT_EQ("-|-|-|-", formatter->format(formatter_context, stream_info));
  }

  {
    EXPECT_CALL(Const(stream_info), filterState()).Times(testing::AtLeast(1));
    const std::string format = "%FILTER_STATE(testing)%|%FILTER_STATE(serialized)%|"
                               "%FILTER_STATE(testing):8%|%FILTER_STATE(nonexisting)%";
    FormatterPtr formatter = *FormatterImpl::create(format, true);

    EXPECT_EQ("|||", formatter->format(formatter_context, stream_info));
  }
}

TEST(SubstitutionFormatterTest, ParserFailures) {
  SubstitutionFormatParser parser;

  std::vector<std::string> test_cases = {
      "{{%PROTOCOL%}}   ++ %REQ(FIRST?SECOND)% %RESP(FIRST?SECOND)",
      "%PROTOCOL(should_not_have_params)%",
      "%PROTOCOL(should_not_have_params_or_length):12%",
      "%PROTOCOL:12%",
      "%REQ(FIRST?SECOND)T%",
      "RESP(FIRST)%",
      "%REQ(valid)% %NOT_VALID%",
      "%REQ(FIRST?SECOND%",
      "%HOSTNAME%PROTOCOL%",
      "%protocol%",
      "%REQ(TEST):%",
      "%REQ(TEST):3q4%",
      "%REQ(TEST):-3%",
      "%REQ(\n)%",
      "%REQ(?\n)%",
      "%REQ(\0)%",
      "%REQ(?\0)%",
      "%REQ(\r)%",
      "%REQ(?\r)%",
      "%RESP(TEST):%",
      "%RESP(X?Y):%",
      "%RESP(X?Y):343o24%",
      "%REQ(TEST):10",
      "REQ(:TEST):10%",
      "%REQ(TEST:10%",
      "%REQ(",
      "%REQ(X?Y?Z)%",
      "%TRAILER(TEST):%",
      "%TRAILER(TEST):23u1%",
      "%TRAILER(X?Y?Z)%",
      "%TRAILER(:TEST):10",
      "%DYNAMIC_METADATA(TEST",
      "%FILTER_STATE(TEST",
      "%FILTER_STATE()%",
      "%START_TIME(%85n)%",
      "%START_TIME(%#__88n)%",
      "%START_TIME(%En%)%",
      "%START_TIME(%4En%)%",
      "%START_TIME(%On%)%",
      "%START_TIME(%4On%)%"};

  for (const std::string& test_case : test_cases) {
    EXPECT_THAT(parser.parse(test_case), HasStatusCode(absl::StatusCode::kInvalidArgument));
  }
}

TEST(SubstitutionFormatterTest, ParserSuccesses) {
  SubstitutionFormatParser parser;

  std::vector<std::string> test_cases = {"%START_TIME(%E4n%)%", "%START_TIME(%O4n%)%",
                                         "%DOWNSTREAM_PEER_FINGERPRINT_256%"};

  for (const std::string& test_case : test_cases) {
    EXPECT_OK(parser.parse(test_case).status());
  }
}

TEST(SubstitutionFormatterTest, EmptyFormatParse) {
  StreamInfo::MockStreamInfo stream_info;

  auto providers = *SubstitutionFormatParser::parse("");

  EXPECT_EQ(providers.size(), 1);
  EXPECT_EQ("", formatForTest(*providers[0], {}, stream_info));
}

TEST(SubstitutionFormatterTest, EscapingFormatParse) {
  StreamInfo::MockStreamInfo stream_info;

  auto providers = *SubstitutionFormatParser::parse("%%");

  ASSERT_EQ(providers.size(), 1);
  EXPECT_EQ("%", formatForTest(*providers[0], {}, stream_info));
}

TEST(SubstitutionFormatterTest, FormatterExtension) {
  StreamInfo::MockStreamInfo stream_info;

  std::vector<CommandParserPtr> commands;
  commands.push_back(std::make_unique<TestCommandParser>());

  auto providers = *SubstitutionFormatParser::parse("foo %COMMAND_EXTENSION(x)%", commands);

  EXPECT_EQ(providers.size(), 2);
  EXPECT_EQ("TestFormatter", formatForTest(*providers[1], {}, stream_info));
}

TEST(SubstitutionFormatterTest, PercentEscapingEdgeCase) {
  StreamInfo::MockStreamInfo stream_info;
  NiceMock<Api::MockOsSysCalls> os_sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> os_calls(&os_sys_calls);
  EXPECT_CALL(os_sys_calls, gethostname(_, _))
      .WillOnce(Invoke([](char* name, size_t) -> Api::SysCallIntResult {
        StringUtil::strlcpy(name, "myhostname", 11);
        return {0, 0};
      }));
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  auto providers = *SubstitutionFormatParser::parse("%HOSTNAME%%PROTOCOL%");

  ASSERT_EQ(providers.size(), 2);
  EXPECT_EQ("myhostname", formatForTest(*providers[0], {}, stream_info));
  EXPECT_EQ("HTTP/1.1", formatForTest(*providers[1], {}, stream_info));
}

TEST(SubstitutionFormatterTest, EnvironmentFormatterTest) {
  {
    EXPECT_THAT(SubstitutionFormatParser::parse("%ENVIRONMENT()%"),
                HasStatus(absl::StatusCode::kInvalidArgument, "ENVIRONMENT requires parameters"));
  }

  {
    StreamInfo::MockStreamInfo stream_info;

    auto providers = *SubstitutionFormatParser::parse("%ENVIRONMENT(ENVOY_TEST_ENV)%");

    ASSERT_EQ(providers.size(), 1);

    // An unset environment variable is latched as the default unspecified value at construction
    // time, so it is reported as a value rather than as a missing one.
    EXPECT_EQ("-", formatForTest(*providers[0], {}, stream_info));
    EXPECT_THAT(formatValueForTest(*providers[0], {}, stream_info),
                ProtoEq(ValueUtil::stringValue("-")));
  }

  {
    StreamInfo::MockStreamInfo stream_info;

    TestEnvironment::setEnvVar("ENVOY_TEST_ENV", "test", 1);
    Envoy::Cleanup cleanup([]() { TestEnvironment::unsetEnvVar("ENVOY_TEST_ENV"); });

    auto providers = *SubstitutionFormatParser::parse("%ENVIRONMENT(ENVOY_TEST_ENV)%");

    ASSERT_EQ(providers.size(), 1);

    EXPECT_EQ("test", formatForTest(*providers[0], {}, stream_info));
    EXPECT_THAT(formatValueForTest(*providers[0], {}, stream_info),
                ProtoEq(ValueUtil::stringValue("test")));
  }

  {
    StreamInfo::MockStreamInfo stream_info;

    TestEnvironment::setEnvVar("ENVOY_TEST_ENV", "test", 1);
    Envoy::Cleanup cleanup([]() { TestEnvironment::unsetEnvVar("ENVOY_TEST_ENV"); });

    auto providers = *SubstitutionFormatParser::parse("%ENVIRONMENT(ENVOY_TEST_ENV):2%");

    ASSERT_EQ(providers.size(), 1);

    EXPECT_EQ("te", formatForTest(*providers[0], {}, stream_info));
  }
}

TEST(SubstitutionFormatterTest, PathTest) {
  {
    EXPECT_THAT(SubstitutionFormatParser::parse("%PATH(A)%"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "Invalid PATH option: 'A', only 'WQ'/'NQ' are allowed"));
  }

  {
    EXPECT_THAT(
        SubstitutionFormatParser::parse("%PATH(NQ:B)%"),
        HasStatus(absl::StatusCode::kInvalidArgument,
                  "Invalid PATH option: 'B', only 'ORIG'/'PATH'/'ORIG_OR_PATH' are allowed"));
  }

  {
    Http::TestRequestHeaderMapImpl request_headers_1{{":path", "/path/to/something"}};
    Http::TestRequestHeaderMapImpl request_headers_2{{":path", "/path/to/something?query=123"}};
    Http::TestRequestHeaderMapImpl request_headers_3{{":path", "/path/to/something"},
                                                     {"x-envoy-original-path", "/original/path"}};
    Http::TestRequestHeaderMapImpl request_headers_4{
        {":path", "/path/to/something?query=123"},
        {"x-envoy-original-path", "/original/path?query=123"}};

    StreamInfo::MockStreamInfo stream_info;

    for (absl::string_view query : {"", "WQ", "NQ"}) {
      for (absl::string_view orig : {"", "ORIG", "PATH", "ORIG_OR_PATH"}) {
        auto providers =
            *SubstitutionFormatParser::parse(absl::StrCat("%PATH(", query, ":", orig, ")%"));
        ASSERT_EQ(providers.size(), 1);

        std::string expected_1 = orig != "ORIG" ? "/path/to/something" : "-";
        std::string expected_2 =
            fmt::format("{}", orig != "ORIG" ? fmt::format("/path/to/something{}",
                                                           query != "NQ" ? "?query=123" : "")
                                             : "-");
        std::string expected_3 = orig != "PATH" ? "/original/path" : "/path/to/something";
        std::string expected_4 =
            fmt::format("{}{}", orig != "PATH" ? "/original/path" : "/path/to/something",
                        query != "NQ" ? "?query=123" : "");

        EXPECT_EQ(expected_1,
                  formatForTest(*providers[0], {&request_headers_1}, stream_info).value_or("-"));
        EXPECT_EQ(expected_2,
                  formatForTest(*providers[0], {&request_headers_2}, stream_info).value_or("-"));
        EXPECT_EQ(expected_3,
                  formatForTest(*providers[0], {&request_headers_3}, stream_info).value_or("-"));
        EXPECT_EQ(expected_4,
                  formatForTest(*providers[0], {&request_headers_4}, stream_info).value_or("-"));

        // The same expectations hold for the value (JSON) path.
        const auto to_value = [](absl::string_view expected) {
          return expected == "-" ? ValueUtil::nullValue()
                                 : ValueUtil::stringValue(std::string(expected));
        };
        EXPECT_THAT(formatValueForTest(*providers[0], {&request_headers_1}, stream_info),
                    ProtoEq(to_value(expected_1)));
        EXPECT_THAT(formatValueForTest(*providers[0], {&request_headers_2}, stream_info),
                    ProtoEq(to_value(expected_2)));
        EXPECT_THAT(formatValueForTest(*providers[0], {&request_headers_3}, stream_info),
                    ProtoEq(to_value(expected_3)));
        EXPECT_THAT(formatValueForTest(*providers[0], {&request_headers_4}, stream_info),
                    ProtoEq(to_value(expected_4)));

        // No request headers at all.
        EXPECT_EQ(std::nullopt, formatForTest(*providers[0], {}, stream_info));
        EXPECT_THAT(formatValueForTest(*providers[0], {}, stream_info),
                    ProtoEq(ValueUtil::nullValue()));
      }
    }
  }
}

TEST(SubstitutionFormatParser, SyntaxVerifierFail) {
  std::vector<
      std::tuple<CommandSyntaxChecker::CommandSyntaxFlags, std::string, std::optional<size_t>>>
      test_cases = {
          // COMMAND_ONLY. Any additional params are not allowed
          {CommandSyntaxChecker::COMMAND_ONLY, "", 3},
          {CommandSyntaxChecker::COMMAND_ONLY, "PARAMS", 3},
          {CommandSyntaxChecker::COMMAND_ONLY, "PARAMS", std::nullopt},
          // PARAMS_REQUIRED. Length not allowed.
          {CommandSyntaxChecker::PARAMS_REQUIRED, "", 3},
          {CommandSyntaxChecker::PARAMS_REQUIRED, "PARAM", 3},
          {CommandSyntaxChecker::PARAMS_REQUIRED, "", std::nullopt},
          // PARAMS_REQUIRED and LENGTH_ALLOWED
          {CommandSyntaxChecker::PARAMS_REQUIRED | CommandSyntaxChecker::LENGTH_ALLOWED, "", 3},
          {CommandSyntaxChecker::PARAMS_REQUIRED | CommandSyntaxChecker::LENGTH_ALLOWED, "",
           std::nullopt},
      };

  for (const auto& test_case : test_cases) {
    EXPECT_THAT(CommandSyntaxChecker::verifySyntax(std::get<0>(test_case), "TEST_TOKEN",
                                                   std::get<1>(test_case), std::get<2>(test_case)),
                Not(IsOk()));
  }
}

TEST(SubstitutionFormatParser, SyntaxVerifierPass) {
  std::vector<
      std::tuple<CommandSyntaxChecker::CommandSyntaxFlags, std::string, std::optional<size_t>>>
      test_cases = {
          // COMMAND_ONLY. Any additional params are not allowed
          {CommandSyntaxChecker::COMMAND_ONLY, "", std::nullopt},
          // PARAMS_REQUIRED
          {CommandSyntaxChecker::PARAMS_REQUIRED, "PARAMS", std::nullopt},
          // PARAMS_REQUIRED and LENGTH_ALLOWED
          {CommandSyntaxChecker::PARAMS_REQUIRED | CommandSyntaxChecker::LENGTH_ALLOWED, "PARAMS",
           3},
          {CommandSyntaxChecker::PARAMS_REQUIRED, "PARAMS", std::nullopt},
          // ALLOWS_PARAMS
          {CommandSyntaxChecker::PARAMS_OPTIONAL, "PARAMS", std::nullopt},
          {CommandSyntaxChecker::PARAMS_OPTIONAL, "", std::nullopt},
          // ALLOWS_PARAMS and LENGTH_ALLOWED
          {CommandSyntaxChecker::PARAMS_OPTIONAL | CommandSyntaxChecker::LENGTH_ALLOWED, "PARAMS",
           3},
          {CommandSyntaxChecker::PARAMS_OPTIONAL | CommandSyntaxChecker::LENGTH_ALLOWED, "", 3},
          {CommandSyntaxChecker::PARAMS_OPTIONAL | CommandSyntaxChecker::LENGTH_ALLOWED, "PARAMS",
           std::nullopt},
          {CommandSyntaxChecker::PARAMS_OPTIONAL | CommandSyntaxChecker::LENGTH_ALLOWED, "",
           std::nullopt}};

  for (const auto& test_case : test_cases) {
    EXPECT_OK(CommandSyntaxChecker::verifySyntax(std::get<0>(test_case), "TEST_TOKEN",
                                                 std::get<1>(test_case), std::get<2>(test_case)));
  }
}

TEST(SubstitutionFormatterTest, UniqueIdFormatterTest) {
  StreamInfo::MockStreamInfo stream_info;

  // Simulate initial parsing of configuration
  auto providers1 = *SubstitutionFormatParser::parse("%UNIQUE_ID%");
  ASSERT_EQ(providers1.size(), 1);

  // Generate first unique ID with the initial configuration
  auto id1 = providers1[0]->format({}, stream_info);
  ASSERT_TRUE(id1.has_value());

  // Generate second unique ID with the same initial configuration
  auto id2 = providers1[0]->format({}, stream_info);
  ASSERT_TRUE(id2.has_value());

  // Check the two generated IDs are unique
  EXPECT_NE(id1, id2);

  // %UNIQUE_ID% returns a fresh value on every call, so format() and formatTo() cannot be
  // compared against each other; check formatTo() separately instead.
  std::string sink = "prefix:";
  EXPECT_TRUE(providers1[0]->formatTo(sink, {}, stream_info));
  const absl::string_view appended = absl::string_view(sink).substr(strlen("prefix:"));
  EXPECT_EQ(appended.size(), id1->size());
  EXPECT_NE(appended, *id1);

  // Simulate configuration reload
  auto providers2 = *SubstitutionFormatParser::parse("%UNIQUE_ID%");
  ASSERT_EQ(providers2.size(), 1);

  // Generate another unique ID after the simulated reload
  auto id3 = providers2[0]->format({}, stream_info);
  ASSERT_TRUE(id3.has_value());

  // Check the new ID is also unique compared to the previous ones
  EXPECT_NE(id1, id3);
  EXPECT_NE(id2, id3);
}

// COALESCE formatter tests.
TEST(SubstitutionFormatterTest, CoalesceFormatterBasic) {
  StreamInfo::MockStreamInfo stream_info;
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  // Test basic coalescing when the first value is available.
  {
    auto providers = *SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["PROTOCOL"]})%)");
    ASSERT_EQ(providers.size(), 1);
    EXPECT_EQ("HTTP/1.1", formatForTest(*providers[0], {}, stream_info).value_or("-"));
  }

  // Test with request headers using the REQ command.
  {
    Http::TestRequestHeaderMapImpl request_headers{{":authority", "example.com"}};
    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": [{"command": "REQ", "param": ":authority"}]})%)");
    ASSERT_EQ(providers.size(), 1);
    EXPECT_EQ("example.com",
              formatForTest(*providers[0], {&request_headers}, stream_info).value_or("-"));
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterFallback) {
  StreamInfo::MockStreamInfo stream_info;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(std::nullopt));

  // Create mock address provider with empty SNI.
  auto address = Network::Address::InstanceConstSharedPtr{
      new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
  auto downstream_address_provider =
      std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
  downstream_address_provider->setRequestedServerName("");
  EXPECT_CALL(stream_info, downstreamAddressProvider())
      .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

  // Test fallback when first operator returns null.
  {
    Http::TestRequestHeaderMapImpl request_headers{{":authority", "example.com"}};

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}]})%)");
    ASSERT_EQ(providers.size(), 1);
    // REQUESTED_SERVER_NAME is empty, so should fallback to :authority.
    EXPECT_EQ("example.com",
              formatForTest(*providers[0], {&request_headers}, stream_info).value_or("-"));
  }

  // Test when all operators return null.
  {
    Http::TestRequestHeaderMapImpl request_headers{};

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}]})%)");
    ASSERT_EQ(providers.size(), 1);
    // Both operators return null, should return nullopt.
    EXPECT_FALSE(formatForTest(*providers[0], {&request_headers}, stream_info).has_value());
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterMaxLength) {
  StreamInfo::MockStreamInfo stream_info;
  Http::TestRequestHeaderMapImpl request_headers{{":authority", "very-long-hostname.example.com"}};

  // Test max_length at command level.
  {
    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": [{"command": "REQ", "param": ":authority"}]}):10%)");
    ASSERT_EQ(providers.size(), 1);
    EXPECT_EQ("very-long-",
              formatForTest(*providers[0], {&request_headers}, stream_info).value_or("-"));
  }

  // Test max_length in operator entry.
  {
    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": [{"command": "REQ", "param": ":authority", "max_length": 5}]})%)");
    ASSERT_EQ(providers.size(), 1);
    EXPECT_EQ("very-", formatForTest(*providers[0], {&request_headers}, stream_info).value_or("-"));
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterMixedOperators) {
  StreamInfo::MockStreamInfo stream_info;
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  // Create mock address provider with SNI set.
  auto address = Network::Address::InstanceConstSharedPtr{
      new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
  auto downstream_address_provider =
      std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
  downstream_address_provider->setRequestedServerName("sni.example.com");
  EXPECT_CALL(stream_info, downstreamAddressProvider())
      .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

  // Test with mixed operator types with string and object.
  {
    Http::TestRequestHeaderMapImpl request_headers{{":authority", "host.example.com"}};

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}, "PROTOCOL"]})%)");
    ASSERT_EQ(providers.size(), 1);
    // REQUESTED_SERVER_NAME should be returned as it's the first available value.
    EXPECT_EQ("sni.example.com",
              formatForTest(*providers[0], {&request_headers}, stream_info).value_or("-"));
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterGridTest) {
  // Multiple combinations of operators and headers.
  struct TestCase {
    std::string sni;
    std::string authority;
    std::string original_host;
    std::string expected;
  };

  // Test SNI -> :authority -> x-envoy-original-host cascade.
  std::vector<TestCase> test_cases = {
      // SNI set, others set - return SNI.
      {"sni.example.com", "authority.example.com", "original.example.com", "sni.example.com"},
      // SNI empty, authority set - return authority.
      {"", "authority.example.com", "original.example.com", "authority.example.com"},
      // SNI empty, authority empty, original set - return original.
      {"", "", "original.example.com", "original.example.com"},
      // All empty - return nullopt.
      {"", "", "", ""},
  };

  for (const auto& tc : test_cases) {
    SCOPED_TRACE(fmt::format("sni='{}', authority='{}', original_host='{}'", tc.sni, tc.authority,
                             tc.original_host));

    StreamInfo::MockStreamInfo stream_info;

    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
    auto downstream_address_provider =
        std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
    downstream_address_provider->setRequestedServerName(tc.sni);
    EXPECT_CALL(stream_info, downstreamAddressProvider())
        .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

    Http::TestRequestHeaderMapImpl request_headers;
    if (!tc.authority.empty()) {
      request_headers.addCopy(":authority", tc.authority);
    }
    if (!tc.original_host.empty()) {
      request_headers.addCopy("x-envoy-original-host", tc.original_host);
    }

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}, {"command": "REQ", "param": "x-envoy-original-host"}]})%)");
    ASSERT_EQ(providers.size(), 1);

    auto result = formatForTest(*providers[0], {&request_headers}, stream_info);
    if (tc.expected.empty()) {
      EXPECT_FALSE(result.has_value());
    } else {
      EXPECT_EQ(tc.expected, result.value_or("-"));
    }
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterErrorCases) {
  // Empty JSON config.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse("%COALESCE()%"),
                HasStatus(absl::StatusCode::kInvalidArgument, "COALESCE requires parameters"));
  }

  // The command parser rejects the empty parameter before the formatter is created, so the
  // empty configuration is checked by creating the formatter directly.
  {
    EXPECT_THAT(CoalesceFormatter::create("", std::nullopt),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "COALESCE requires a JSON configuration parameter"));
  }

  // Invalid JSON.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse("%COALESCE(not json)%"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          StartsWith("COALESCE: failed to parse JSON configuration")));
  }

  // Missing operators field.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(R"(%COALESCE({"foo": "bar"})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "COALESCE: JSON configuration must contain 'operators' array"));
  }

  // The operators field is present but is not an array.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(R"(%COALESCE({"operators": "PROTOCOL"})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          StartsWith("COALESCE: 'operators' must be an array")));
  }

  // Empty operators array.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(R"(%COALESCE({"operators": []})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          "COALESCE: 'operators' array must not be empty"));
  }

  // Invalid operator which is not a string or object.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(R"(%COALESCE({"operators": [123]})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          StartsWith("COALESCE: failed to parse operator at index 0")));
  }

  // Missing command field in operator object.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(R"(%COALESCE({"operators": [{"param": "foo"}]})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          StartsWith("COALESCE: failed to parse operator at index 0")));
  }

  // Unknown command.
  {
    EXPECT_THAT(
        SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["UNKNOWN_COMMAND"]})%)"),
        HasStatus(
            absl::StatusCode::kInvalidArgument,
            ContainsRegex("COALESCE: failed to parse operator at index 0.*unknown command.*")));
  }

  // The param field is present but is not a string.
  {
    EXPECT_THAT(
        SubstitutionFormatParser::parse(
            R"(%COALESCE({"operators": [{"command": "REQ", "param": 123}]})%)"),
        HasStatus(
            absl::StatusCode::kInvalidArgument,
            ContainsRegex(
                "COALESCE: failed to parse operator at index 0.*'param' field must be a string")));
  }

  // The max_length field is present but is not an integer.
  {
    EXPECT_THAT(SubstitutionFormatParser::parse(
                    R"(%COALESCE({"operators": [{"command": "PROTOCOL", "max_length": "10"}]})%)"),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          ContainsRegex("COALESCE: failed to parse operator at index 0.*"
                                        "'max_length' field must be an integer")));
  }

  // Invalid not positive max_length.
  {
    EXPECT_THAT(
        SubstitutionFormatParser::parse(
            R"(%COALESCE({"operators": [{"command": "PROTOCOL", "max_length": 0}]})%)"),
        HasStatus(absl::StatusCode::kInvalidArgument,
                  ContainsRegex(
                      "COALESCE: failed to parse operator at index 0.*max_length.*positive.*")));
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterFormatValue) {
  StreamInfo::MockStreamInfo stream_info;
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  // Test formatValue returns proper protobuf value.
  {
    auto providers = *SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["PROTOCOL"]})%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = formatValueForTest(*providers[0], {}, stream_info);
    EXPECT_EQ(Protobuf::Value::kStringValue, value.kind_case());
    EXPECT_EQ("HTTP/1.1", value.string_value());
  }

  // Test formatValue when all operators return null.
  {
    StreamInfo::MockStreamInfo null_stream_info;
    EXPECT_CALL(null_stream_info, protocol()).WillRepeatedly(Return(std::nullopt));
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
    auto downstream_address_provider =
        std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
    downstream_address_provider->setRequestedServerName("");
    EXPECT_CALL(null_stream_info, downstreamAddressProvider())
        .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

    Http::TestRequestHeaderMapImpl request_headers{};

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}]})%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = formatValueForTest(*providers[0], {&request_headers}, null_stream_info);
    EXPECT_EQ(Protobuf::Value::kNullValue, value.kind_case());
  }

  // A string value longer than the COALESCE max length is truncated.
  {
    auto providers =
        *SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["PROTOCOL"]}):4%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = providers[0]->formatValue({}, stream_info);
    EXPECT_EQ(Protobuf::Value::kStringValue, value.kind_case());
    EXPECT_EQ("HTTP", value.string_value());
  }

  // A string value shorter than the COALESCE max length is left as is.
  {
    auto providers =
        *SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["PROTOCOL"]}):100%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = providers[0]->formatValue({}, stream_info);
    EXPECT_EQ(Protobuf::Value::kStringValue, value.kind_case());
    EXPECT_EQ("HTTP/1.1", value.string_value());
  }

  // A non-string value is returned as is and is not subject to the max length.
  {
    EXPECT_CALL(stream_info, responseCode()).WillRepeatedly(Return(std::optional<uint32_t>(503)));

    auto providers =
        *SubstitutionFormatParser::parse(R"(%COALESCE({"operators": ["RESPONSE_CODE"]}):1%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = providers[0]->formatValue({}, stream_info);
    EXPECT_EQ(Protobuf::Value::kNumberValue, value.kind_case());
    EXPECT_EQ(503, value.number_value());
  }

  // An empty string value is skipped and the next operator is used.
  {
    auto address = Network::Address::InstanceConstSharedPtr{
        new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
    auto downstream_address_provider =
        std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
    downstream_address_provider->setRequestedServerName("");
    EXPECT_CALL(stream_info, downstreamAddressProvider())
        .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

    auto providers = *SubstitutionFormatParser::parse(
        R"(%COALESCE({"operators": ["REQUESTED_SERVER_NAME", "PROTOCOL"]})%)");
    ASSERT_EQ(providers.size(), 1);
    auto value = providers[0]->formatValue({}, stream_info);
    EXPECT_EQ(Protobuf::Value::kStringValue, value.kind_case());
    EXPECT_EQ("HTTP/1.1", value.string_value());
  }
}

TEST(SubstitutionFormatterTest, CoalesceFormatterWithOtherCommands) {
  // Test COALESCE in combination with other formatters in the same format string.
  StreamInfo::MockStreamInfo stream_info;
  std::optional<Http::Protocol> protocol = Http::Protocol::Http11;
  EXPECT_CALL(stream_info, protocol()).WillRepeatedly(Return(protocol));

  auto address = Network::Address::InstanceConstSharedPtr{
      new Network::Address::Ipv4Instance("127.0.0.1", 8080)};
  auto downstream_address_provider =
      std::make_shared<Network::ConnectionInfoSetterImpl>(address, address);
  downstream_address_provider->setRequestedServerName("sni.example.com");
  EXPECT_CALL(stream_info, downstreamAddressProvider())
      .WillRepeatedly(ReturnPointee(downstream_address_provider.get()));

  Http::TestRequestHeaderMapImpl request_headers{{":authority", "host.example.com"}};

  auto formatter_or_error = FormatterImpl::create(
      R"(protocol=%PROTOCOL% host=%COALESCE({"operators": ["REQUESTED_SERVER_NAME", {"command": "REQ", "param": ":authority"}]})%)");
  ASSERT_OK(formatter_or_error);
  auto& formatter = *formatter_or_error.value();

  std::string result = formatter.format({&request_headers}, stream_info);
  EXPECT_EQ("protocol=HTTP/1.1 host=sni.example.com", result);
}
} // namespace
} // namespace Formatter
} // namespace Envoy
