# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

import unittest
from unittest import mock

from opentelemetry import trace as trace_api
from opentelemetry.sdk import trace
from opentelemetry.sdk.trace import export
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)


class TestInMemorySpanExporter(unittest.TestCase):
    def setUp(self):
        self.tracer_provider = trace.TracerProvider()
        self.tracer = self.tracer_provider.get_tracer(__name__)
        self.memory_exporter = InMemorySpanExporter()
        span_processor = export.SimpleSpanProcessor(self.memory_exporter)
        self.tracer_provider.add_span_processor(span_processor)
        self.exec_scenario()

    def exec_scenario(self):
        with self.tracer.start_as_current_span("foo"):
            with self.tracer.start_as_current_span("bar"):
                with self.tracer.start_as_current_span("xxx"):
                    pass

    def test_get_finished_spans(self):
        span_list = self.memory_exporter.get_finished_spans()
        spans_names_list = [span.name for span in span_list]
        self.assertListEqual(["xxx", "bar", "foo"], spans_names_list)

    def test_clear(self):
        self.memory_exporter.clear()
        span_list = self.memory_exporter.get_finished_spans()
        self.assertEqual(len(span_list), 0)

    def test_shutdown(self):
        span_list = self.memory_exporter.get_finished_spans()
        self.assertEqual(len(span_list), 3)

        self.memory_exporter.shutdown()

        # after shutdown no new spans are accepted
        self.exec_scenario()

        span_list = self.memory_exporter.get_finished_spans()
        self.assertEqual(len(span_list), 3)

    def test_return_code(self):
        span = trace._Span("name", mock.Mock(spec=trace_api.SpanContext))
        span_list = (span,)
        memory_exporter = InMemorySpanExporter()

        ret = memory_exporter.export(span_list)
        self.assertEqual(ret, export.SpanExportResult.SUCCESS)

        memory_exporter.shutdown()

        # after shutdown export should fail
        ret = memory_exporter.export(span_list)
        self.assertEqual(ret, export.SpanExportResult.FAILURE)

    def test_max_spans_limit(self):
        """Test that max_spans limits memory usage by dropping oldest spans."""
        exporter = InMemorySpanExporter(max_spans=2)
        span1 = trace._Span("span1", mock.Mock(spec=trace_api.SpanContext))
        span2 = trace._Span("span2", mock.Mock(spec=trace_api.SpanContext))
        span3 = trace._Span("span3", mock.Mock(spec=trace_api.SpanContext))
        exporter.export([span1, span2, span3])
        span_list = exporter.get_finished_spans()
        self.assertEqual(len(span_list), 2)
        self.assertSequenceEqual((span2, span3), span_list)

    def test_max_spans_none_is_unlimited(self):
        """Test that max_spans=None (default) imposes no limit."""
        exporter = InMemorySpanExporter(max_spans=None)
        span = trace._Span("name", mock.Mock(spec=trace_api.SpanContext))
        exporter.export([span] * 100)
        span_list = exporter.get_finished_spans()
        self.assertEqual(len(span_list), 100)
