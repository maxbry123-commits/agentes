# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0
"""
WSGI config for instrumentation_example project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.0/howto/deployment/wsgi/
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "instrumentation_example.settings")

application = get_wsgi_application()
