# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

# AUTO-GENERATED from "opentelemetry/proto/metrics/v1/metrics.proto"
# DO NOT EDIT MANUALLY

from __future__ import annotations

import builtins
import dataclasses
import enum
import functools
import typing

_dataclass = functools.partial(dataclasses.dataclass, slots=True)

import opentelemetry.proto_json._json_codec
import opentelemetry.proto_json.common.v1.common
import opentelemetry.proto_json.resource.v1.resource


@typing.final
class AggregationTemporality(enum.IntEnum):
    """
    Generated from protobuf enum AggregationTemporality
    """

    AGGREGATION_TEMPORALITY_UNSPECIFIED = 0
    AGGREGATION_TEMPORALITY_DELTA = 1
    AGGREGATION_TEMPORALITY_CUMULATIVE = 2

@typing.final
class DataPointFlags(enum.IntEnum):
    """
    Generated from protobuf enum DataPointFlags
    """

    DATA_POINT_FLAGS_DO_NOT_USE = 0
    DATA_POINT_FLAGS_NO_RECORDED_VALUE_MASK = 1

@typing.final
@_dataclass
class MetricsData(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message MetricsData
    """

    resource_metrics: builtins.list[ResourceMetrics] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.resource_metrics:
            _result["resourceMetrics"] = opentelemetry.proto_json._json_codec.encode_repeated(self.resource_metrics, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> MetricsData:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            MetricsData instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("resourceMetrics")) is not None:
            _args["resource_metrics"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: ResourceMetrics.from_dict(_v), "resource_metrics")

        return cls(**_args)


@typing.final
@_dataclass
class ResourceMetrics(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ResourceMetrics
    """

    resource: opentelemetry.proto_json.resource.v1.resource.Resource | None = None
    scope_metrics: builtins.list[ScopeMetrics] = dataclasses.field(default_factory=builtins.list)
    schema_url: builtins.str | None = ""

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.resource:
            _result["resource"] = self.resource.to_dict()
        if self.scope_metrics:
            _result["scopeMetrics"] = opentelemetry.proto_json._json_codec.encode_repeated(self.scope_metrics, lambda _v: _v.to_dict())
        if self.schema_url:
            _result["schemaUrl"] = self.schema_url
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ResourceMetrics:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ResourceMetrics instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("resource")) is not None:
            _args["resource"] = opentelemetry.proto_json.resource.v1.resource.Resource.from_dict(_value)
        if (_value := data.get("scopeMetrics")) is not None:
            _args["scope_metrics"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: ScopeMetrics.from_dict(_v), "scope_metrics")
        if (_value := data.get("schemaUrl")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "schema_url")
            _args["schema_url"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class ScopeMetrics(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ScopeMetrics
    """

    scope: opentelemetry.proto_json.common.v1.common.InstrumentationScope | None = None
    metrics: builtins.list[Metric] = dataclasses.field(default_factory=builtins.list)
    schema_url: builtins.str | None = ""

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.scope:
            _result["scope"] = self.scope.to_dict()
        if self.metrics:
            _result["metrics"] = opentelemetry.proto_json._json_codec.encode_repeated(self.metrics, lambda _v: _v.to_dict())
        if self.schema_url:
            _result["schemaUrl"] = self.schema_url
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ScopeMetrics:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ScopeMetrics instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("scope")) is not None:
            _args["scope"] = opentelemetry.proto_json.common.v1.common.InstrumentationScope.from_dict(_value)
        if (_value := data.get("metrics")) is not None:
            _args["metrics"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: Metric.from_dict(_v), "metrics")
        if (_value := data.get("schemaUrl")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "schema_url")
            _args["schema_url"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class Metric(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Metric
    """

    name: builtins.str | None = ""
    description: builtins.str | None = ""
    unit: builtins.str | None = ""
    gauge: Gauge | None = None
    sum: Sum | None = None
    histogram: Histogram | None = None
    exponential_histogram: ExponentialHistogram | None = None
    summary: Summary | None = None
    metadata: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.name:
            _result["name"] = self.name
        if self.description:
            _result["description"] = self.description
        if self.unit:
            _result["unit"] = self.unit
        if self.metadata:
            _result["metadata"] = opentelemetry.proto_json._json_codec.encode_repeated(self.metadata, lambda _v: _v.to_dict())
        if self.summary is not None:
            _result["summary"] = self.summary.to_dict()
        elif self.exponential_histogram is not None:
            _result["exponentialHistogram"] = self.exponential_histogram.to_dict()
        elif self.histogram is not None:
            _result["histogram"] = self.histogram.to_dict()
        elif self.sum is not None:
            _result["sum"] = self.sum.to_dict()
        elif self.gauge is not None:
            _result["gauge"] = self.gauge.to_dict()
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Metric:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Metric instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("name")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "name")
            _args["name"] = _value
        if (_value := data.get("description")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "description")
            _args["description"] = _value
        if (_value := data.get("unit")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "unit")
            _args["unit"] = _value
        if (_value := data.get("metadata")) is not None:
            _args["metadata"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "metadata")
        if (_value := data.get("summary")) is not None:
            _args["summary"] = Summary.from_dict(_value)
        elif (_value := data.get("exponentialHistogram")) is not None:
            _args["exponential_histogram"] = ExponentialHistogram.from_dict(_value)
        elif (_value := data.get("histogram")) is not None:
            _args["histogram"] = Histogram.from_dict(_value)
        elif (_value := data.get("sum")) is not None:
            _args["sum"] = Sum.from_dict(_value)
        elif (_value := data.get("gauge")) is not None:
            _args["gauge"] = Gauge.from_dict(_value)

        return cls(**_args)


@typing.final
@_dataclass
class Gauge(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Gauge
    """

    data_points: builtins.list[NumberDataPoint] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.data_points:
            _result["dataPoints"] = opentelemetry.proto_json._json_codec.encode_repeated(self.data_points, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Gauge:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Gauge instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("dataPoints")) is not None:
            _args["data_points"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: NumberDataPoint.from_dict(_v), "data_points")

        return cls(**_args)


@typing.final
@_dataclass
class Sum(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Sum
    """

    data_points: builtins.list[NumberDataPoint] = dataclasses.field(default_factory=builtins.list)
    aggregation_temporality: AggregationTemporality | builtins.int | None = 0
    is_monotonic: builtins.bool | None = False

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.data_points:
            _result["dataPoints"] = opentelemetry.proto_json._json_codec.encode_repeated(self.data_points, lambda _v: _v.to_dict())
        if self.aggregation_temporality:
            _result["aggregationTemporality"] = builtins.int(self.aggregation_temporality)
        if self.is_monotonic:
            _result["isMonotonic"] = self.is_monotonic
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Sum:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Sum instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("dataPoints")) is not None:
            _args["data_points"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: NumberDataPoint.from_dict(_v), "data_points")
        if (_value := data.get("aggregationTemporality")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "aggregation_temporality")
            _args["aggregation_temporality"] = AggregationTemporality(_value)
        if (_value := data.get("isMonotonic")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.bool, "is_monotonic")
            _args["is_monotonic"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class Histogram(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Histogram
    """

    data_points: builtins.list[HistogramDataPoint] = dataclasses.field(default_factory=builtins.list)
    aggregation_temporality: AggregationTemporality | builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.data_points:
            _result["dataPoints"] = opentelemetry.proto_json._json_codec.encode_repeated(self.data_points, lambda _v: _v.to_dict())
        if self.aggregation_temporality:
            _result["aggregationTemporality"] = builtins.int(self.aggregation_temporality)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Histogram:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Histogram instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("dataPoints")) is not None:
            _args["data_points"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: HistogramDataPoint.from_dict(_v), "data_points")
        if (_value := data.get("aggregationTemporality")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "aggregation_temporality")
            _args["aggregation_temporality"] = AggregationTemporality(_value)

        return cls(**_args)


@typing.final
@_dataclass
class ExponentialHistogram(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExponentialHistogram
    """

    data_points: builtins.list[ExponentialHistogramDataPoint] = dataclasses.field(default_factory=builtins.list)
    aggregation_temporality: AggregationTemporality | builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.data_points:
            _result["dataPoints"] = opentelemetry.proto_json._json_codec.encode_repeated(self.data_points, lambda _v: _v.to_dict())
        if self.aggregation_temporality:
            _result["aggregationTemporality"] = builtins.int(self.aggregation_temporality)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExponentialHistogram:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExponentialHistogram instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("dataPoints")) is not None:
            _args["data_points"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: ExponentialHistogramDataPoint.from_dict(_v), "data_points")
        if (_value := data.get("aggregationTemporality")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "aggregation_temporality")
            _args["aggregation_temporality"] = AggregationTemporality(_value)

        return cls(**_args)


@typing.final
@_dataclass
class Summary(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Summary
    """

    data_points: builtins.list[SummaryDataPoint] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.data_points:
            _result["dataPoints"] = opentelemetry.proto_json._json_codec.encode_repeated(self.data_points, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Summary:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Summary instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("dataPoints")) is not None:
            _args["data_points"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: SummaryDataPoint.from_dict(_v), "data_points")

        return cls(**_args)


@typing.final
@_dataclass
class NumberDataPoint(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message NumberDataPoint
    """

    attributes: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)
    start_time_unix_nano: builtins.int | None = 0
    time_unix_nano: builtins.int | None = 0
    as_double: builtins.float | None = None
    as_int: builtins.int | None = None
    exemplars: builtins.list[Exemplar] = dataclasses.field(default_factory=builtins.list)
    flags: builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.attributes:
            _result["attributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.attributes, lambda _v: _v.to_dict())
        if self.start_time_unix_nano:
            _result["startTimeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.start_time_unix_nano)
        if self.time_unix_nano:
            _result["timeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.time_unix_nano)
        if self.exemplars:
            _result["exemplars"] = opentelemetry.proto_json._json_codec.encode_repeated(self.exemplars, lambda _v: _v.to_dict())
        if self.flags:
            _result["flags"] = self.flags
        if self.as_int is not None:
            _result["asInt"] = opentelemetry.proto_json._json_codec.encode_int64(self.as_int)
        elif self.as_double is not None:
            _result["asDouble"] = opentelemetry.proto_json._json_codec.encode_float(self.as_double)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> NumberDataPoint:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            NumberDataPoint instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("attributes")) is not None:
            _args["attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "attributes")
        if (_value := data.get("startTimeUnixNano")) is not None:
            _args["start_time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "start_time_unix_nano")
        if (_value := data.get("timeUnixNano")) is not None:
            _args["time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "time_unix_nano")
        if (_value := data.get("exemplars")) is not None:
            _args["exemplars"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: Exemplar.from_dict(_v), "exemplars")
        if (_value := data.get("flags")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "flags")
            _args["flags"] = _value
        if (_value := data.get("asInt")) is not None:
            _args["as_int"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "as_int")
        elif (_value := data.get("asDouble")) is not None:
            _args["as_double"] = opentelemetry.proto_json._json_codec.decode_float(_value, "as_double")

        return cls(**_args)


@typing.final
@_dataclass
class HistogramDataPoint(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message HistogramDataPoint
    """

    attributes: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)
    start_time_unix_nano: builtins.int | None = 0
    time_unix_nano: builtins.int | None = 0
    count: builtins.int | None = 0
    sum: builtins.float | None = None
    bucket_counts: builtins.list[builtins.int] = dataclasses.field(default_factory=builtins.list)
    explicit_bounds: builtins.list[builtins.float] = dataclasses.field(default_factory=builtins.list)
    exemplars: builtins.list[Exemplar] = dataclasses.field(default_factory=builtins.list)
    flags: builtins.int | None = 0
    min: builtins.float | None = None
    max: builtins.float | None = None

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.attributes:
            _result["attributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.attributes, lambda _v: _v.to_dict())
        if self.start_time_unix_nano:
            _result["startTimeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.start_time_unix_nano)
        if self.time_unix_nano:
            _result["timeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.time_unix_nano)
        if self.count:
            _result["count"] = opentelemetry.proto_json._json_codec.encode_int64(self.count)
        if self.sum is not None:
            _result["sum"] = opentelemetry.proto_json._json_codec.encode_float(self.sum)
        if self.bucket_counts:
            _result["bucketCounts"] = opentelemetry.proto_json._json_codec.encode_repeated(self.bucket_counts, lambda _v: opentelemetry.proto_json._json_codec.encode_int64(_v))
        if self.explicit_bounds:
            _result["explicitBounds"] = opentelemetry.proto_json._json_codec.encode_repeated(self.explicit_bounds, lambda _v: opentelemetry.proto_json._json_codec.encode_float(_v))
        if self.exemplars:
            _result["exemplars"] = opentelemetry.proto_json._json_codec.encode_repeated(self.exemplars, lambda _v: _v.to_dict())
        if self.flags:
            _result["flags"] = self.flags
        if self.min is not None:
            _result["min"] = opentelemetry.proto_json._json_codec.encode_float(self.min)
        if self.max is not None:
            _result["max"] = opentelemetry.proto_json._json_codec.encode_float(self.max)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> HistogramDataPoint:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            HistogramDataPoint instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("attributes")) is not None:
            _args["attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "attributes")
        if (_value := data.get("startTimeUnixNano")) is not None:
            _args["start_time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "start_time_unix_nano")
        if (_value := data.get("timeUnixNano")) is not None:
            _args["time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "time_unix_nano")
        if (_value := data.get("count")) is not None:
            _args["count"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "count")
        if (_value := data.get("sum")) is not None:
            _args["sum"] = opentelemetry.proto_json._json_codec.decode_float(_value, "sum")
        if (_value := data.get("bucketCounts")) is not None:
            _args["bucket_counts"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json._json_codec.decode_int64(_v, "bucket_counts"), "bucket_counts")
        if (_value := data.get("explicitBounds")) is not None:
            _args["explicit_bounds"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json._json_codec.decode_float(_v, "explicit_bounds"), "explicit_bounds")
        if (_value := data.get("exemplars")) is not None:
            _args["exemplars"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: Exemplar.from_dict(_v), "exemplars")
        if (_value := data.get("flags")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "flags")
            _args["flags"] = _value
        if (_value := data.get("min")) is not None:
            _args["min"] = opentelemetry.proto_json._json_codec.decode_float(_value, "min")
        if (_value := data.get("max")) is not None:
            _args["max"] = opentelemetry.proto_json._json_codec.decode_float(_value, "max")

        return cls(**_args)


@typing.final
@_dataclass
class ExponentialHistogramDataPoint(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExponentialHistogramDataPoint
    """

    @typing.final
    @_dataclass
    class Buckets(opentelemetry.proto_json._json_codec.JsonMessage):
        """
        Generated from protobuf message Buckets
        """

        offset: builtins.int | None = 0
        bucket_counts: builtins.list[builtins.int] = dataclasses.field(default_factory=builtins.list)

        def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
            """
            Convert this message to a dictionary with lowerCamelCase keys.

            Returns:
                Dictionary representation following OTLP JSON encoding
            """
            _result = {}
            if self.offset:
                _result["offset"] = self.offset
            if self.bucket_counts:
                _result["bucketCounts"] = opentelemetry.proto_json._json_codec.encode_repeated(self.bucket_counts, lambda _v: opentelemetry.proto_json._json_codec.encode_int64(_v))
            return _result

        @builtins.classmethod
        def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExponentialHistogramDataPoint.Buckets:
            """
            Create from a dictionary with lowerCamelCase keys.

            Args:
                data: Dictionary representation following OTLP JSON encoding

            Returns:
                Buckets instance
            """
            opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
            _args = {}

            if (_value := data.get("offset")) is not None:
                opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "offset")
                _args["offset"] = _value
            if (_value := data.get("bucketCounts")) is not None:
                _args["bucket_counts"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json._json_codec.decode_int64(_v, "bucket_counts"), "bucket_counts")

            return cls(**_args)

    attributes: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)
    start_time_unix_nano: builtins.int | None = 0
    time_unix_nano: builtins.int | None = 0
    count: builtins.int | None = 0
    sum: builtins.float | None = None
    scale: builtins.int | None = 0
    zero_count: builtins.int | None = 0
    positive: ExponentialHistogramDataPoint.Buckets | None = None
    negative: ExponentialHistogramDataPoint.Buckets | None = None
    flags: builtins.int | None = 0
    exemplars: builtins.list[Exemplar] = dataclasses.field(default_factory=builtins.list)
    min: builtins.float | None = None
    max: builtins.float | None = None
    zero_threshold: builtins.float | None = 0.0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.attributes:
            _result["attributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.attributes, lambda _v: _v.to_dict())
        if self.start_time_unix_nano:
            _result["startTimeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.start_time_unix_nano)
        if self.time_unix_nano:
            _result["timeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.time_unix_nano)
        if self.count:
            _result["count"] = opentelemetry.proto_json._json_codec.encode_int64(self.count)
        if self.sum is not None:
            _result["sum"] = opentelemetry.proto_json._json_codec.encode_float(self.sum)
        if self.scale:
            _result["scale"] = self.scale
        if self.zero_count:
            _result["zeroCount"] = opentelemetry.proto_json._json_codec.encode_int64(self.zero_count)
        if self.positive:
            _result["positive"] = self.positive.to_dict()
        if self.negative:
            _result["negative"] = self.negative.to_dict()
        if self.flags:
            _result["flags"] = self.flags
        if self.exemplars:
            _result["exemplars"] = opentelemetry.proto_json._json_codec.encode_repeated(self.exemplars, lambda _v: _v.to_dict())
        if self.min is not None:
            _result["min"] = opentelemetry.proto_json._json_codec.encode_float(self.min)
        if self.max is not None:
            _result["max"] = opentelemetry.proto_json._json_codec.encode_float(self.max)
        if self.zero_threshold:
            _result["zeroThreshold"] = opentelemetry.proto_json._json_codec.encode_float(self.zero_threshold)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExponentialHistogramDataPoint:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExponentialHistogramDataPoint instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("attributes")) is not None:
            _args["attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "attributes")
        if (_value := data.get("startTimeUnixNano")) is not None:
            _args["start_time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "start_time_unix_nano")
        if (_value := data.get("timeUnixNano")) is not None:
            _args["time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "time_unix_nano")
        if (_value := data.get("count")) is not None:
            _args["count"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "count")
        if (_value := data.get("sum")) is not None:
            _args["sum"] = opentelemetry.proto_json._json_codec.decode_float(_value, "sum")
        if (_value := data.get("scale")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "scale")
            _args["scale"] = _value
        if (_value := data.get("zeroCount")) is not None:
            _args["zero_count"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "zero_count")
        if (_value := data.get("positive")) is not None:
            _args["positive"] = ExponentialHistogramDataPoint.Buckets.from_dict(_value)
        if (_value := data.get("negative")) is not None:
            _args["negative"] = ExponentialHistogramDataPoint.Buckets.from_dict(_value)
        if (_value := data.get("flags")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "flags")
            _args["flags"] = _value
        if (_value := data.get("exemplars")) is not None:
            _args["exemplars"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: Exemplar.from_dict(_v), "exemplars")
        if (_value := data.get("min")) is not None:
            _args["min"] = opentelemetry.proto_json._json_codec.decode_float(_value, "min")
        if (_value := data.get("max")) is not None:
            _args["max"] = opentelemetry.proto_json._json_codec.decode_float(_value, "max")
        if (_value := data.get("zeroThreshold")) is not None:
            _args["zero_threshold"] = opentelemetry.proto_json._json_codec.decode_float(_value, "zero_threshold")

        return cls(**_args)


@typing.final
@_dataclass
class SummaryDataPoint(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message SummaryDataPoint
    """

    @typing.final
    @_dataclass
    class ValueAtQuantile(opentelemetry.proto_json._json_codec.JsonMessage):
        """
        Generated from protobuf message ValueAtQuantile
        """

        quantile: builtins.float | None = 0.0
        value: builtins.float | None = 0.0

        def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
            """
            Convert this message to a dictionary with lowerCamelCase keys.

            Returns:
                Dictionary representation following OTLP JSON encoding
            """
            _result = {}
            if self.quantile:
                _result["quantile"] = opentelemetry.proto_json._json_codec.encode_float(self.quantile)
            if self.value:
                _result["value"] = opentelemetry.proto_json._json_codec.encode_float(self.value)
            return _result

        @builtins.classmethod
        def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> SummaryDataPoint.ValueAtQuantile:
            """
            Create from a dictionary with lowerCamelCase keys.

            Args:
                data: Dictionary representation following OTLP JSON encoding

            Returns:
                ValueAtQuantile instance
            """
            opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
            _args = {}

            if (_value := data.get("quantile")) is not None:
                _args["quantile"] = opentelemetry.proto_json._json_codec.decode_float(_value, "quantile")
            if (_value := data.get("value")) is not None:
                _args["value"] = opentelemetry.proto_json._json_codec.decode_float(_value, "value")

            return cls(**_args)

    attributes: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)
    start_time_unix_nano: builtins.int | None = 0
    time_unix_nano: builtins.int | None = 0
    count: builtins.int | None = 0
    sum: builtins.float | None = 0.0
    quantile_values: builtins.list[SummaryDataPoint.ValueAtQuantile] = dataclasses.field(default_factory=builtins.list)
    flags: builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.attributes:
            _result["attributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.attributes, lambda _v: _v.to_dict())
        if self.start_time_unix_nano:
            _result["startTimeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.start_time_unix_nano)
        if self.time_unix_nano:
            _result["timeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.time_unix_nano)
        if self.count:
            _result["count"] = opentelemetry.proto_json._json_codec.encode_int64(self.count)
        if self.sum:
            _result["sum"] = opentelemetry.proto_json._json_codec.encode_float(self.sum)
        if self.quantile_values:
            _result["quantileValues"] = opentelemetry.proto_json._json_codec.encode_repeated(self.quantile_values, lambda _v: _v.to_dict())
        if self.flags:
            _result["flags"] = self.flags
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> SummaryDataPoint:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            SummaryDataPoint instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("attributes")) is not None:
            _args["attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "attributes")
        if (_value := data.get("startTimeUnixNano")) is not None:
            _args["start_time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "start_time_unix_nano")
        if (_value := data.get("timeUnixNano")) is not None:
            _args["time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "time_unix_nano")
        if (_value := data.get("count")) is not None:
            _args["count"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "count")
        if (_value := data.get("sum")) is not None:
            _args["sum"] = opentelemetry.proto_json._json_codec.decode_float(_value, "sum")
        if (_value := data.get("quantileValues")) is not None:
            _args["quantile_values"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: SummaryDataPoint.ValueAtQuantile.from_dict(_v), "quantile_values")
        if (_value := data.get("flags")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "flags")
            _args["flags"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class Exemplar(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message Exemplar
    """

    filtered_attributes: builtins.list[opentelemetry.proto_json.common.v1.common.KeyValue] = dataclasses.field(default_factory=builtins.list)
    time_unix_nano: builtins.int | None = 0
    as_double: builtins.float | None = None
    as_int: builtins.int | None = None
    span_id: builtins.bytes | None = b""
    trace_id: builtins.bytes | None = b""

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.filtered_attributes:
            _result["filteredAttributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.filtered_attributes, lambda _v: _v.to_dict())
        if self.time_unix_nano:
            _result["timeUnixNano"] = opentelemetry.proto_json._json_codec.encode_int64(self.time_unix_nano)
        if self.span_id:
            _result["spanId"] = opentelemetry.proto_json._json_codec.encode_hex(self.span_id)
        if self.trace_id:
            _result["traceId"] = opentelemetry.proto_json._json_codec.encode_hex(self.trace_id)
        if self.as_int is not None:
            _result["asInt"] = opentelemetry.proto_json._json_codec.encode_int64(self.as_int)
        elif self.as_double is not None:
            _result["asDouble"] = opentelemetry.proto_json._json_codec.encode_float(self.as_double)
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> Exemplar:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            Exemplar instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("filteredAttributes")) is not None:
            _args["filtered_attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.common.v1.common.KeyValue.from_dict(_v), "filtered_attributes")
        if (_value := data.get("timeUnixNano")) is not None:
            _args["time_unix_nano"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "time_unix_nano")
        if (_value := data.get("spanId")) is not None:
            _args["span_id"] = opentelemetry.proto_json._json_codec.decode_hex(_value, "span_id")
        if (_value := data.get("traceId")) is not None:
            _args["trace_id"] = opentelemetry.proto_json._json_codec.decode_hex(_value, "trace_id")
        if (_value := data.get("asInt")) is not None:
            _args["as_int"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "as_int")
        elif (_value := data.get("asDouble")) is not None:
            _args["as_double"] = opentelemetry.proto_json._json_codec.decode_float(_value, "as_double")

        return cls(**_args)
