# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

# AUTO-GENERATED from "opentelemetry/proto/collector/trace/v1/trace_service.proto"
# DO NOT EDIT MANUALLY

from __future__ import annotations

import builtins
import dataclasses
import functools
import typing

_dataclass = functools.partial(dataclasses.dataclass, slots=True)

import opentelemetry.proto_json._json_codec
import opentelemetry.proto_json.trace.v1.trace


@typing.final
@_dataclass
class ExportTraceServiceRequest(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportTraceServiceRequest
    """

    resource_spans: builtins.list[opentelemetry.proto_json.trace.v1.trace.ResourceSpans] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.resource_spans:
            _result["resourceSpans"] = opentelemetry.proto_json._json_codec.encode_repeated(self.resource_spans, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportTraceServiceRequest:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportTraceServiceRequest instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("resourceSpans")) is not None:
            _args["resource_spans"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.trace.v1.trace.ResourceSpans.from_dict(_v), "resource_spans")

        return cls(**_args)


@typing.final
@_dataclass
class ExportTraceServiceResponse(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportTraceServiceResponse
    """

    partial_success: ExportTracePartialSuccess | None = None

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.partial_success:
            _result["partialSuccess"] = self.partial_success.to_dict()
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportTraceServiceResponse:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportTraceServiceResponse instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("partialSuccess")) is not None:
            _args["partial_success"] = ExportTracePartialSuccess.from_dict(_value)

        return cls(**_args)


@typing.final
@_dataclass
class ExportTracePartialSuccess(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportTracePartialSuccess
    """

    rejected_spans: builtins.int | None = 0
    error_message: builtins.str | None = ""

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.rejected_spans:
            _result["rejectedSpans"] = opentelemetry.proto_json._json_codec.encode_int64(self.rejected_spans)
        if self.error_message:
            _result["errorMessage"] = self.error_message
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportTracePartialSuccess:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportTracePartialSuccess instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("rejectedSpans")) is not None:
            _args["rejected_spans"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "rejected_spans")
        if (_value := data.get("errorMessage")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "error_message")
            _args["error_message"] = _value

        return cls(**_args)
