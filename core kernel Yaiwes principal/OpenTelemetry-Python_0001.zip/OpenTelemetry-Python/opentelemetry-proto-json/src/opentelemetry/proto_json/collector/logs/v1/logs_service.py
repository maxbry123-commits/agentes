# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

# AUTO-GENERATED from "opentelemetry/proto/collector/logs/v1/logs_service.proto"
# DO NOT EDIT MANUALLY

from __future__ import annotations

import builtins
import dataclasses
import functools
import typing

_dataclass = functools.partial(dataclasses.dataclass, slots=True)

import opentelemetry.proto_json._json_codec
import opentelemetry.proto_json.logs.v1.logs


@typing.final
@_dataclass
class ExportLogsServiceRequest(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportLogsServiceRequest
    """

    resource_logs: builtins.list[opentelemetry.proto_json.logs.v1.logs.ResourceLogs] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.resource_logs:
            _result["resourceLogs"] = opentelemetry.proto_json._json_codec.encode_repeated(self.resource_logs, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportLogsServiceRequest:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportLogsServiceRequest instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("resourceLogs")) is not None:
            _args["resource_logs"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: opentelemetry.proto_json.logs.v1.logs.ResourceLogs.from_dict(_v), "resource_logs")

        return cls(**_args)


@typing.final
@_dataclass
class ExportLogsServiceResponse(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportLogsServiceResponse
    """

    partial_success: ExportLogsPartialSuccess | None = None

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.partial_success:
            _result["partialSuccess"] = self.partial_success.to_dict()
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportLogsServiceResponse:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportLogsServiceResponse instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("partialSuccess")) is not None:
            _args["partial_success"] = ExportLogsPartialSuccess.from_dict(_value)

        return cls(**_args)


@typing.final
@_dataclass
class ExportLogsPartialSuccess(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ExportLogsPartialSuccess
    """

    rejected_log_records: builtins.int | None = 0
    error_message: builtins.str | None = ""

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.rejected_log_records:
            _result["rejectedLogRecords"] = opentelemetry.proto_json._json_codec.encode_int64(self.rejected_log_records)
        if self.error_message:
            _result["errorMessage"] = self.error_message
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ExportLogsPartialSuccess:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ExportLogsPartialSuccess instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("rejectedLogRecords")) is not None:
            _args["rejected_log_records"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "rejected_log_records")
        if (_value := data.get("errorMessage")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "error_message")
            _args["error_message"] = _value

        return cls(**_args)
