# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

# AUTO-GENERATED from "opentelemetry/proto/common/v1/common.proto"
# DO NOT EDIT MANUALLY

from __future__ import annotations

import builtins
import dataclasses
import functools
import typing

_dataclass = functools.partial(dataclasses.dataclass, slots=True)

import opentelemetry.proto_json._json_codec


@typing.final
@_dataclass
class AnyValue(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message AnyValue
    """

    string_value: builtins.str | None = None
    bool_value: builtins.bool | None = None
    int_value: builtins.int | None = None
    double_value: builtins.float | None = None
    array_value: ArrayValue | None = None
    kvlist_value: KeyValueList | None = None
    bytes_value: builtins.bytes | None = None
    string_value_strindex: builtins.int | None = None

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.string_value_strindex is not None:
            _result["stringValueStrindex"] = self.string_value_strindex
        elif self.bytes_value is not None:
            _result["bytesValue"] = opentelemetry.proto_json._json_codec.encode_base64(self.bytes_value)
        elif self.kvlist_value is not None:
            _result["kvlistValue"] = self.kvlist_value.to_dict()
        elif self.array_value is not None:
            _result["arrayValue"] = self.array_value.to_dict()
        elif self.double_value is not None:
            _result["doubleValue"] = opentelemetry.proto_json._json_codec.encode_float(self.double_value)
        elif self.int_value is not None:
            _result["intValue"] = opentelemetry.proto_json._json_codec.encode_int64(self.int_value)
        elif self.bool_value is not None:
            _result["boolValue"] = self.bool_value
        elif self.string_value is not None:
            _result["stringValue"] = self.string_value
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> AnyValue:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            AnyValue instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("stringValueStrindex")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "string_value_strindex")
            _args["string_value_strindex"] = _value
        elif (_value := data.get("bytesValue")) is not None:
            _args["bytes_value"] = opentelemetry.proto_json._json_codec.decode_base64(_value, "bytes_value")
        elif (_value := data.get("kvlistValue")) is not None:
            _args["kvlist_value"] = KeyValueList.from_dict(_value)
        elif (_value := data.get("arrayValue")) is not None:
            _args["array_value"] = ArrayValue.from_dict(_value)
        elif (_value := data.get("doubleValue")) is not None:
            _args["double_value"] = opentelemetry.proto_json._json_codec.decode_float(_value, "double_value")
        elif (_value := data.get("intValue")) is not None:
            _args["int_value"] = opentelemetry.proto_json._json_codec.decode_int64(_value, "int_value")
        elif (_value := data.get("boolValue")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.bool, "bool_value")
            _args["bool_value"] = _value
        elif (_value := data.get("stringValue")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "string_value")
            _args["string_value"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class ArrayValue(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message ArrayValue
    """

    values: builtins.list[AnyValue] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.values:
            _result["values"] = opentelemetry.proto_json._json_codec.encode_repeated(self.values, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> ArrayValue:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            ArrayValue instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("values")) is not None:
            _args["values"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: AnyValue.from_dict(_v), "values")

        return cls(**_args)


@typing.final
@_dataclass
class KeyValueList(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message KeyValueList
    """

    values: builtins.list[KeyValue] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.values:
            _result["values"] = opentelemetry.proto_json._json_codec.encode_repeated(self.values, lambda _v: _v.to_dict())
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> KeyValueList:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            KeyValueList instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("values")) is not None:
            _args["values"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: KeyValue.from_dict(_v), "values")

        return cls(**_args)


@typing.final
@_dataclass
class KeyValue(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message KeyValue
    """

    key: builtins.str | None = ""
    value: AnyValue | None = None
    key_strindex: builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.key:
            _result["key"] = self.key
        if self.value:
            _result["value"] = self.value.to_dict()
        if self.key_strindex:
            _result["keyStrindex"] = self.key_strindex
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> KeyValue:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            KeyValue instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("key")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "key")
            _args["key"] = _value
        if (_value := data.get("value")) is not None:
            _args["value"] = AnyValue.from_dict(_value)
        if (_value := data.get("keyStrindex")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "key_strindex")
            _args["key_strindex"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class InstrumentationScope(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message InstrumentationScope
    """

    name: builtins.str | None = ""
    version: builtins.str | None = ""
    attributes: builtins.list[KeyValue] = dataclasses.field(default_factory=builtins.list)
    dropped_attributes_count: builtins.int | None = 0

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.name:
            _result["name"] = self.name
        if self.version:
            _result["version"] = self.version
        if self.attributes:
            _result["attributes"] = opentelemetry.proto_json._json_codec.encode_repeated(self.attributes, lambda _v: _v.to_dict())
        if self.dropped_attributes_count:
            _result["droppedAttributesCount"] = self.dropped_attributes_count
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> InstrumentationScope:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            InstrumentationScope instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("name")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "name")
            _args["name"] = _value
        if (_value := data.get("version")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "version")
            _args["version"] = _value
        if (_value := data.get("attributes")) is not None:
            _args["attributes"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: KeyValue.from_dict(_v), "attributes")
        if (_value := data.get("droppedAttributesCount")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.int, "dropped_attributes_count")
            _args["dropped_attributes_count"] = _value

        return cls(**_args)


@typing.final
@_dataclass
class EntityRef(opentelemetry.proto_json._json_codec.JsonMessage):
    """
    Generated from protobuf message EntityRef
    """

    schema_url: builtins.str | None = ""
    type: builtins.str | None = ""
    id_keys: builtins.list[builtins.str] = dataclasses.field(default_factory=builtins.list)
    description_keys: builtins.list[builtins.str] = dataclasses.field(default_factory=builtins.list)

    def to_dict(self) -> builtins.dict[builtins.str, typing.Any]:
        """
        Convert this message to a dictionary with lowerCamelCase keys.

        Returns:
            Dictionary representation following OTLP JSON encoding
        """
        _result = {}
        if self.schema_url:
            _result["schemaUrl"] = self.schema_url
        if self.type:
            _result["type"] = self.type
        if self.id_keys:
            _result["idKeys"] = self.id_keys
        if self.description_keys:
            _result["descriptionKeys"] = self.description_keys
        return _result

    @builtins.classmethod
    def from_dict(cls, data: builtins.dict[builtins.str, typing.Any]) -> EntityRef:
        """
        Create from a dictionary with lowerCamelCase keys.

        Args:
            data: Dictionary representation following OTLP JSON encoding

        Returns:
            EntityRef instance
        """
        opentelemetry.proto_json._json_codec.validate_type(data, builtins.dict, "data")
        _args = {}

        if (_value := data.get("schemaUrl")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "schema_url")
            _args["schema_url"] = _value
        if (_value := data.get("type")) is not None:
            opentelemetry.proto_json._json_codec.validate_type(_value, builtins.str, "type")
            _args["type"] = _value
        if (_value := data.get("idKeys")) is not None:
            _args["id_keys"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: _v, "id_keys")
        if (_value := data.get("descriptionKeys")) is not None:
            _args["description_keys"] = opentelemetry.proto_json._json_codec.decode_repeated(_value, lambda _v: _v, "description_keys")

        return cls(**_args)
