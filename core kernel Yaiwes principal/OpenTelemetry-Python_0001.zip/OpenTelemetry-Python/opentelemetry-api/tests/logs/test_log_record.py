# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

import unittest
from unittest.mock import patch

from opentelemetry._logs import LogRecord

OBSERVED_TIMESTAMP = "OBSERVED_TIMESTAMP"


class TestLogRecord(unittest.TestCase):
    @patch("opentelemetry._logs._internal.time_ns")
    def test_log_record_observed_timestamp_default(self, time_ns_mock):  # type: ignore
        time_ns_mock.return_value = OBSERVED_TIMESTAMP
        self.assertEqual(LogRecord().observed_timestamp, OBSERVED_TIMESTAMP)

    def test_log_record_exception(self):
        exc = ValueError("boom")
        log_record = LogRecord(exception=exc)
        self.assertIs(log_record.exception, exc)
