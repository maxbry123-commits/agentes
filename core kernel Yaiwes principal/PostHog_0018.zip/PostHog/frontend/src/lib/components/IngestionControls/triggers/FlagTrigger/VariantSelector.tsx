import { useActions, useValues } from 'kea'

import { IconInfo } from '@posthog/icons'
import { LemonLabel, LemonSegmentedButton, LemonSegmentedButtonOption, Tooltip } from '@posthog/lemon-ui'

import { RestrictionScope, useRestrictedArea } from 'lib/components/RestrictedArea'
import { TeamMembershipLevel } from 'lib/constants'

import { MultivariateFlagOptions } from '~/types'

import { flagTriggerLogic } from './flagTriggerLogic'

export const ANY_VARIANT = 'any'

export function variantOptions(
    multivariate: MultivariateFlagOptions | undefined,
    disabledReason?: string | null
): LemonSegmentedButtonOption<string>[] {
    if (!multivariate) {
        return []
    }
    return [
        {
            label: ANY_VARIANT,
            value: ANY_VARIANT,
            disabledReason: disabledReason ?? undefined,
        },
        ...multivariate.variants.map((variant) => {
            return {
                label: variant.key,
                value: variant.key,
                disabledReason: disabledReason ?? undefined,
            }
        }),
    ]
}

export const FlagTriggerVariantSelector = ({ tooltip }: { tooltip: JSX.Element }): JSX.Element | null => {
    const { flag, featureFlagLoading, linkedFlag, flagHasVariants } = useValues(flagTriggerLogic)
    const { onChange } = useActions(flagTriggerLogic)
    const restrictedReason = useRestrictedArea({
        scope: RestrictionScope.Project,
        minimumAccessLevel: TeamMembershipLevel.Admin,
    })

    if (!flagHasVariants) {
        return null
    }

    return (
        <>
            <LemonLabel className="text-base">
                Link to a specific flag variant{' '}
                <Tooltip delayMs={200} title={tooltip}>
                    <IconInfo className="text-muted-alt cursor-help" />
                </Tooltip>
            </LemonLabel>
            <LemonSegmentedButton
                className="min-w-1/3"
                value={flag?.variant ?? ANY_VARIANT}
                options={variantOptions(
                    linkedFlag?.filters.multivariate,
                    restrictedReason ?? (featureFlagLoading ? 'Loading...' : undefined)
                )}
                onChange={(variant) => {
                    if (!linkedFlag) {
                        return
                    }

                    onChange({
                        id: linkedFlag?.id,
                        key: linkedFlag?.key,
                        variant: variant === ANY_VARIANT ? null : variant,
                    })
                }}
            />
        </>
    )
}
