import { MakeLogicType, actions, kea, path, reducers, selectors } from 'kea'

import { now } from 'lib/dayjs'
import { permanentlyMount } from 'lib/utils/kea-logic-builders'
import { isOperatorFlag } from 'lib/utils/operators'

import { AnyPropertyFilter } from '~/types'

import {
    isKeyOnlyForGroup,
    META_GROUP_TYPES,
    SelectingKeyOnly,
    TaxonomicDefinitionTypes,
    TaxonomicFilterGroupType,
    TaxonomicFilterValue,
} from './types'

export const MAX_RECENT_FILTERS = 20
export const RECENT_FILTER_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000
const EXCLUDED_RECENT_FILTER_GROUP_TYPES = new Set<TaxonomicFilterGroupType>([
    ...META_GROUP_TYPES,
    TaxonomicFilterGroupType.DataWarehouse,
    TaxonomicFilterGroupType.DataWarehouseSourceTables,
    TaxonomicFilterGroupType.DataWarehouseMaterializedViews,
    TaxonomicFilterGroupType.DataWarehouseProperties,
    TaxonomicFilterGroupType.DataWarehousePersonProperties,
])

export interface RecentTaxonomicFilter {
    groupType: TaxonomicFilterGroupType
    groupName: string
    value: TaxonomicFilterValue
    item: Record<string, any>
    timestamp: number
    teamId?: number
    propertyFilter?: AnyPropertyFilter
}

export interface RecentItemContext {
    sourceGroupType: TaxonomicFilterGroupType
    sourceGroupName: string
    /**
     * Canonical value the entry was recorded under (e.g. `action.id`,
     * `event.name`). Lets consumers resolve the underlying definition
     * when the recorded source group is a META group (Suggested filters)
     * or otherwise unavailable.
     */
    sourceValue: TaxonomicFilterValue
    teamId?: number
    propertyFilter?: AnyPropertyFilter
}

export function hasRecentContext(item: unknown): item is Record<string, any> & { _recentContext: RecentItemContext } {
    return typeof item === 'object' && item != null && '_recentContext' in item && (item as any)._recentContext != null
}

export function stripRecentContext<T extends Record<string, any>>(item: T): Omit<T, '_recentContext'> {
    const { _recentContext: _, ...clean } = item
    return clean
}

export function isCompleteRecentPropertyFilter(propertyFilter: AnyPropertyFilter | undefined): boolean {
    if (!propertyFilter) {
        return false
    }
    const hasValue =
        'value' in propertyFilter &&
        propertyFilter.value != null &&
        !(Array.isArray(propertyFilter.value) && propertyFilter.value.length === 0)
    const op = 'operator' in propertyFilter ? propertyFilter.operator : undefined
    return hasValue || (!!op && isOperatorFlag(op))
}

type RecentDisplayItem = Record<string, any> & { _recentContext: RecentItemContext }

function recentStorageKey(item: RecentDisplayItem): string {
    return `${item._recentContext.sourceGroupType}::${item._recentContext.sourceValue ?? ''}`
}

function toBareKeyRecent(item: RecentDisplayItem): TaxonomicDefinitionTypes {
    const { propertyFilter: _propertyFilter, ...restContext } = item._recentContext
    return { ...item, _recentContext: restContext } as unknown as TaxonomicDefinitionTypes
}

export function expandRecentsForDisplay(
    scopedRecentItems: TaxonomicDefinitionTypes[],
    selectingKeyOnly?: SelectingKeyOnly
): TaxonomicDefinitionTypes[] {
    const keysWithExplicitBareRecent = new Set<string>()
    for (const item of scopedRecentItems) {
        if (hasRecentContext(item) && !isCompleteRecentPropertyFilter(item._recentContext.propertyFilter)) {
            keysWithExplicitBareRecent.add(recentStorageKey(item))
        }
    }

    const emittedBareKey = new Set<string>()
    const result: TaxonomicDefinitionTypes[] = []
    for (const item of scopedRecentItems) {
        if (!hasRecentContext(item)) {
            result.push(item)
            continue
        }
        const key = recentStorageKey(item)

        if (isKeyOnlyForGroup(selectingKeyOnly, item._recentContext.sourceGroupType)) {
            if (!emittedBareKey.has(key)) {
                emittedBareKey.add(key)
                result.push(toBareKeyRecent(item))
            }
            continue
        }

        if (!isCompleteRecentPropertyFilter(item._recentContext.propertyFilter)) {
            emittedBareKey.add(key)
            result.push(item)
            continue
        }

        if (!keysWithExplicitBareRecent.has(key) && !emittedBareKey.has(key)) {
            emittedBareKey.add(key)
            result.push(toBareKeyRecent(item))
        }
        result.push(item)
    }
    return result
}

function isDuplicateRecentFilter(
    existing: RecentTaxonomicFilter,
    incoming: { groupType: TaxonomicFilterGroupType; value: TaxonomicFilterValue; propertyFilter?: AnyPropertyFilter }
): boolean {
    if (existing.groupType !== incoming.groupType || existing.value !== incoming.value) {
        return false
    }
    const existingComplete = isCompleteRecentPropertyFilter(existing.propertyFilter)
    const incomingComplete = isCompleteRecentPropertyFilter(incoming.propertyFilter)
    if (existingComplete !== incomingComplete) {
        return false
    }
    if (!existingComplete && !incomingComplete) {
        return true
    }
    if (existing.propertyFilter && incoming.propertyFilter) {
        const eOp = 'operator' in existing.propertyFilter ? existing.propertyFilter.operator : undefined
        const eVal = 'value' in existing.propertyFilter ? existing.propertyFilter.value : undefined
        const iOp = 'operator' in incoming.propertyFilter ? incoming.propertyFilter.operator : undefined
        const iVal = 'value' in incoming.propertyFilter ? incoming.propertyFilter.value : undefined
        return eOp === iOp && JSON.stringify(eVal) === JSON.stringify(iVal)
    }
    return true
}

const teamId = window.POSTHOG_APP_CONTEXT?.current_team?.id

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface recentTaxonomicFiltersLogicValues {
    recentFilterItems: TaxonomicDefinitionTypes[]
    recentFilters: RecentTaxonomicFilter[]
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface recentTaxonomicFiltersLogicActions {
    clearRecentFilters: () => {
        value: true
    }
    recordRecentFilter: (payload: {
        groupName: string
        groupType: TaxonomicFilterGroupType
        item: any
        propertyFilter?: AnyPropertyFilter
        selectingKeyOnly?: boolean
        teamId?: number
        value: TaxonomicFilterValue
    }) => {
        groupName: string
        groupType: TaxonomicFilterGroupType
        item: any
        propertyFilter?: AnyPropertyFilter | undefined
        selectingKeyOnly?: boolean | undefined
        teamId?: number | undefined
        value: TaxonomicFilterValue
    }
}

// Generated by kea-typegen. Update if you're an agent, ignore if you're human.
export interface recentTaxonomicFiltersLogicMeta {
    __keaTypeGenInternalSelectorTypes: {
        recentFilterItems: (recentFilters: RecentTaxonomicFilter[]) => TaxonomicDefinitionTypes[]
    }
}

export type recentTaxonomicFiltersLogicType = MakeLogicType<
    recentTaxonomicFiltersLogicValues,
    recentTaxonomicFiltersLogicActions,
    Record<string, any>,
    recentTaxonomicFiltersLogicMeta
>

export const recentTaxonomicFiltersLogic = kea<recentTaxonomicFiltersLogicType>([
    path(['lib', 'components', 'TaxonomicFilter', 'recentTaxonomicFiltersLogic']),
    actions({
        recordRecentFilter: (payload: {
            groupType: TaxonomicFilterGroupType
            groupName: string
            value: TaxonomicFilterValue
            item: any
            teamId?: number
            propertyFilter?: AnyPropertyFilter
            selectingKeyOnly?: boolean
        }) => payload,
        clearRecentFilters: true,
    }),
    reducers({
        recentFilters: [
            [] as RecentTaxonomicFilter[],
            { persist: true, prefix: `${teamId}__` },
            {
                clearRecentFilters: () => [],
                recordRecentFilter: (
                    state,
                    { groupType, groupName, value, item, teamId, propertyFilter, selectingKeyOnly }
                ) => {
                    if (EXCLUDED_RECENT_FILTER_GROUP_TYPES.has(groupType) || value == null) {
                        return state
                    }

                    const incomingComplete = isCompleteRecentPropertyFilter(propertyFilter)
                    // A non-selectingKeyOnly partial write is treated as a stale precursor to a complete filter
                    // and should not stomp the better record. A selectingKeyOnly write is the final value, so
                    // it is allowed to coexist with — and bump the recency of — any complete record.
                    if (
                        !incomingComplete &&
                        !selectingKeyOnly &&
                        state.some(
                            (f) =>
                                f.groupType === groupType &&
                                f.value === value &&
                                isCompleteRecentPropertyFilter(f.propertyFilter)
                        )
                    ) {
                        return state
                    }

                    const currentTime = now().valueOf()
                    const cutoff = currentTime - RECENT_FILTER_MAX_AGE_MS

                    const entry: RecentTaxonomicFilter = {
                        groupType,
                        groupName,
                        value,
                        item,
                        timestamp: currentTime,
                        ...(teamId ? { teamId } : {}),
                        ...(propertyFilter ? { propertyFilter } : {}),
                    }

                    const withoutDuplicate = state.filter((f) => {
                        if (f.groupType !== groupType || f.value !== value) {
                            return true
                        }
                        if (incomingComplete && !isCompleteRecentPropertyFilter(f.propertyFilter)) {
                            return false
                        }
                        return !isDuplicateRecentFilter(f, { groupType, value, propertyFilter })
                    })

                    const withoutExpired = withoutDuplicate.filter((f) => f.timestamp > cutoff)

                    return [entry, ...withoutExpired].slice(0, MAX_RECENT_FILTERS)
                },
            },
        ],
    }),
    selectors({
        recentFilterItems: [
            (s) => [s.recentFilters],
            (recentFilters: RecentTaxonomicFilter[]): TaxonomicDefinitionTypes[] =>
                recentFilters.map(
                    (f) =>
                        ({
                            ...f.item,
                            _recentContext: {
                                sourceGroupType: f.groupType,
                                sourceGroupName: f.groupName,
                                sourceValue: f.value,
                                teamId: f.teamId,
                                propertyFilter: f.propertyFilter,
                            } as RecentItemContext,
                        }) as unknown as TaxonomicDefinitionTypes
                ),
        ],
    }),
    permanentlyMount(),
])
