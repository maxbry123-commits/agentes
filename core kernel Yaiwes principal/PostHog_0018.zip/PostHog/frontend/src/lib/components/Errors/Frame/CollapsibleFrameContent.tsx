import { Collapsible } from 'lib/ui/Collapsible/Collapsible'

import { ErrorTrackingStackFrame, ErrorTrackingStackFrameContext, ErrorTrackingStackFrameRecord } from '../types'
import { CodeVariablesInlineBanner } from './CodeVariablesInlineBanner'
import { FrameContext } from './FrameContext'
import { getFrameLanguage } from './frameLanguage'
import { FrameVariables } from './FrameVariables'

export interface CollapsibleFrameContentProps {
    frame: ErrorTrackingStackFrame
    record?: ErrorTrackingStackFrameRecord

    onFrameContextClick?: (context: ErrorTrackingStackFrameContext, event: React.MouseEvent<HTMLDivElement>) => void
}

export function CollapsibleFrameContent({
    frame,
    record,
    onFrameContextClick,
}: CollapsibleFrameContentProps): JSX.Element | null {
    const { code_variables } = frame
    const hasCodeVariables = code_variables && Object.keys(code_variables).length > 0
    if (!record || !record.context) {
        return null
    }
    return (
        <Collapsible.Panel className="border-t-[color:var(--frame-border,var(--color-border-primary))]">
            <div onClick={(e) => onFrameContextClick?.(record.context!, e)}>
                <FrameContext context={record.context} language={getFrameLanguage(frame)} />
                {hasCodeVariables ? <FrameVariables variables={code_variables!} /> : <CodeVariablesInlineBanner />}
            </div>
        </Collapsible.Panel>
    )
}
