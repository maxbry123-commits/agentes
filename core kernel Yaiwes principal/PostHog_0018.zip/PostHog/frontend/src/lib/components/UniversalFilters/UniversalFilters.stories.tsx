import { Meta, StoryObj } from '@storybook/react'
import { useActions, useMountedLogic, useValues } from 'kea'
import { useState } from 'react'

import { actionsModel } from '~/models/actionsModel'
import { cohortsModel } from '~/models/cohortsModel'

import { taxonomicFilterMocksDecorator } from '../TaxonomicFilter/__mocks__/taxonomicFilterMocksDecorator'
import { TaxonomicFilterGroupType } from '../TaxonomicFilter/types'
import { DEFAULT_UNIVERSAL_GROUP_FILTER } from './constants'
import UniversalFilters, { UniversalFiltersProps } from './UniversalFilters'
import { universalFiltersLogic } from './universalFiltersLogic'
import { isUniversalGroupFilterLike } from './utils'

const meta: Meta<UniversalFiltersProps> = {
    title: 'Filters/Universal Filters',
    component: UniversalFilters,
    decorators: [taxonomicFilterMocksDecorator],
}
export default meta

type Story = StoryObj<UniversalFiltersProps>

// When implementing UniversalFilters, customize this to render your own UI
const NestedFilterGroup = ({ rootKey }: { rootKey: string }): JSX.Element => {
    const { rootKey: currentKey, filterGroup } = useValues(universalFiltersLogic)
    const { replaceGroupValue, removeGroupValue } = useActions(universalFiltersLogic)

    return (
        <div className="border">
            <div>Is root: {String(rootKey === currentKey)}</div>
            <div>{JSON.stringify(filterGroup)}</div>
            {filterGroup.values.map((filterOrGroup, index) => {
                return isUniversalGroupFilterLike(filterOrGroup) ? (
                    <UniversalFilters.Group key={index} index={index} group={filterOrGroup}>
                        <NestedFilterGroup rootKey={rootKey} />
                    </UniversalFilters.Group>
                ) : (
                    <UniversalFilters.Value
                        key={index}
                        index={index}
                        filter={filterOrGroup}
                        onRemove={() => removeGroupValue(index)}
                        onChange={(value) => replaceGroupValue(index, value)}
                    />
                )
            })}
            <UniversalFilters.AddFilterButton />
        </div>
    )
}

export const Default: Story = {
    render: ({ group }) => {
        const [filterGroup, setFilterGroup] = useState(group)
        useMountedLogic(cohortsModel)
        useMountedLogic(actionsModel)

        const rootKey = 'session-recordings'

        return (
            <UniversalFilters
                rootKey={rootKey}
                group={filterGroup}
                taxonomicGroupTypes={[
                    TaxonomicFilterGroupType.Events,
                    TaxonomicFilterGroupType.Actions,
                    TaxonomicFilterGroupType.Cohorts,
                    TaxonomicFilterGroupType.PersonProperties,
                    TaxonomicFilterGroupType.SessionProperties,
                ]}
                onChange={(filterGroup) => {
                    setFilterGroup(filterGroup)
                }}
            >
                <NestedFilterGroup rootKey={rootKey} />
            </UniversalFilters>
        )
    },
    args: {
        group: DEFAULT_UNIVERSAL_GROUP_FILTER,
    },
}
