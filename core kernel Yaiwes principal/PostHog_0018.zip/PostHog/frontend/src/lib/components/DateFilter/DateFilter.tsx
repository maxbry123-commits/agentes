import { Placement } from '@floating-ui/react'
import clsx from 'clsx'
import { useActions, useValues } from 'kea'
import { forwardRef, useEffect, useRef, useState } from 'react'

import { IconCalendar, IconInfo } from '@posthog/icons'
import { LemonButton, LemonButtonProps, LemonDivider, LemonSwitch, Popover } from '@posthog/lemon-ui'

import {
    CUSTOM_OPTION_DESCRIPTION,
    CUSTOM_OPTION_KEY,
    DateFilterLogicProps,
    DateFilterView,
    NO_OVERRIDE_RANGE_PLACEHOLDER,
} from 'lib/components/DateFilter/types'
import { ScrollableShadows } from 'lib/components/ScrollableShadows/ScrollableShadows'
import { dayjs } from 'lib/dayjs'
import { LemonCalendarSelect, LemonCalendarSelectProps } from 'lib/lemon-ui/LemonCalendar/LemonCalendarSelect'
import { LemonCalendarRange } from 'lib/lemon-ui/LemonCalendarRange/LemonCalendarRange'
import { Tooltip } from 'lib/lemon-ui/Tooltip'
import { dateFilterToText, dateMapping } from 'lib/utils/dateFilters'
import { formatResolvedDateRange } from 'lib/utils/datetime'
import { uuid } from 'lib/utils/dom'
import { teamLogic } from 'scenes/teamLogic'

import { ResolvedDateRangeResponse } from '~/queries/schema/schema-general'
import { DateMappingOption, PropertyOperator } from '~/types'

import { PropertyFilterDatePicker } from '../PropertyFilters/components/PropertyFilterDatePicker'
import type { DateFilterExclusions } from './DateFilterExclusionsControl'
import { dateFilterLogic } from './dateFilterLogic'
import { FixedRangeWithTimePicker } from './FixedRangeWithTimePicker'
import { JumpToTimestampPicker } from './JumpToTimestampPicker'
import { LemonDateFilterExclusions } from './LemonDateFilterExclusions'
import { RelativeDateRangeSelector } from './RelativeDateRangeSelector'
import { RollingDateRangeFilter } from './RollingDateRangeFilter'
import { DateOption } from './rollingDateRangeFilterLogic'

export interface DateFilterProps {
    showCustom?: boolean
    showRollingRangePicker?: boolean
    showCustomRangeOptions?: boolean
    makeLabel?: (key: React.ReactNode, startOfRange?: React.ReactNode, endOfRange?: React.ReactNode) => React.ReactNode
    className?: string
    onChange?: (fromDate: string | null, toDate: string | null, explicitDate?: boolean) => void
    disabled?: boolean
    disabledReason?: string | null
    dateOptions?: DateMappingOption[]
    isDateFormatted?: boolean
    size?: LemonButtonProps['size']
    type?: LemonButtonProps['type']
    dropdownPlacement?: Placement
    /* True when we're not dealing with ranges, but a single date / relative date */
    isFixedDateMode?: boolean
    placeholder?: string
    fullWidth?: boolean
    resolvedDateRange?: ResolvedDateRangeResponse
    showJumpToTimestamp?: boolean
    showCustomRelativeRange?: boolean
    allowFutureRelativeDateOptions?: boolean
    footerComponent?: (onClose: () => void) => React.ReactNode
    /**
     * When true, surfaces every option — presets, rolling picker, "Custom date…" (single exact),
     * "Custom fixed date range…", and "Custom relative range…" — in one flat list. Callers opt
     * in to let the user freely pick either a single value or a range. `isFixedDateMode` and
     * `showCustomRelativeRange` are ignored when this is set.
     */
    allowSingleAndRange?: boolean
    /** Called when the dropdown opens (true) or closes (false). Used for interaction analytics. */
    onOpenChange?: (open: boolean) => void
}

interface RawDateFilterProps extends DateFilterProps {
    dateFrom?: string | null | dayjs.Dayjs
    dateTo?: string | null | dayjs.Dayjs
    max?: number | null
    allowedRollingDateOptions?: DateOption[]
    allowTimePrecision?: boolean
    allowFixedRangeWithTime?: boolean
    /**
     * Granularity is picked based on the dateFrom value
     * but can be overridden to force a specific granularity.
     * For example, set to 'day' to never show the time picker.
     */
    forceGranularity?: LemonCalendarSelectProps['granularity']
    /** Use 24-hour format instead of 12-hour with AM/PM */
    use24HourFormat?: boolean
    explicitDate?: boolean
    showExplicitDateToggle?: boolean
    exclusions?: DateFilterExclusions
    onExclusionsChange?: (exclusions: DateFilterExclusions) => void
    showIncompletePeriodExclusion?: boolean
    showDaysOfWeekExclusions?: boolean
    optionsSize?: 'small' | 'medium'
}

export const DateFilter = forwardRef<HTMLButtonElement, RawDateFilterProps>(function DateFilter(
    {
        showCustom,
        showRollingRangePicker = true,
        showCustomRangeOptions = true,
        className,
        disabledReason,
        makeLabel,
        onChange,
        dateFrom,
        dateTo,
        dateOptions = dateMapping,
        isDateFormatted = true,
        size,
        type,
        dropdownPlacement = 'bottom-start',
        max,
        isFixedDateMode = false,
        allowedRollingDateOptions,
        allowTimePrecision = false,
        allowFixedRangeWithTime = false,
        placeholder,
        fullWidth = false,
        forceGranularity,
        use24HourFormat = false,
        explicitDate,
        showExplicitDateToggle = false,
        exclusions,
        onExclusionsChange,
        showIncompletePeriodExclusion = false,
        showDaysOfWeekExclusions = false,
        optionsSize,
        resolvedDateRange,
        showJumpToTimestamp = false,
        showCustomRelativeRange = false,
        allowFutureRelativeDateOptions = false,
        allowSingleAndRange = false,
        onOpenChange,
        footerComponent,
    },
    ref
) {
    const effectiveShowCustomRelativeRange = allowSingleAndRange ? true : showCustomRelativeRange
    const key = useRef(uuid()).current
    const logicProps: DateFilterLogicProps = {
        key,
        dateFrom,
        dateTo,
        onChange,
        dateOptions,
        isDateFormatted,
        isFixedDateMode,
        placeholder,
        allowTimePrecision,
        explicitDate,
        showCustomRelativeRange: effectiveShowCustomRelativeRange,
        allowSingleAndRange,
    }
    const {
        open,
        openFixedRange,
        openDateToNow,
        openFixedDate,
        openJumpToTimestamp,
        openCustomRelativeRange,
        close,
        setRangeDateFrom,
        setExplicitDate,
        setRangeDateTo,
        setDate,
        applyRange,
        setFixedRangeGranularity,
    } = useActions(dateFilterLogic(logicProps))
    const {
        isVisible,
        view,
        rangeDateFrom,
        rangeDateTo,
        label,
        isFixedRange,
        isDateToNow,
        isFixedDate,
        isRollingDateRange,
        isCustomRelativeRange,
        dateFromHasTimePrecision,
        fixedRangeGranularity,
    } = useValues(dateFilterLogic(logicProps))

    // Hold the callback in a ref so the visibility effect below depends only on `isVisible` —
    // callers pass an inline function, which would otherwise re-run the effect every render.
    const onOpenChangeRef = useRef(onOpenChange)
    useEffect(() => {
        onOpenChangeRef.current = onOpenChange
    })
    const wasVisibleRef = useRef(isVisible)
    useEffect(() => {
        if (isVisible !== wasVisibleRef.current) {
            wasVisibleRef.current = isVisible
            onOpenChangeRef.current?.(isVisible)
        }
    }, [isVisible])

    const { weekStartDay } = useValues(teamLogic)
    const optionsRef = useRef<HTMLDivElement | null>(null)
    const rollingDateRangeRef = useRef<HTMLDivElement | null>(null)
    const futureRollingDateRangeRef = useRef<HTMLDivElement | null>(null)
    const [granularity, setGranularity] = useState<LemonCalendarSelectProps['granularity']>(
        forceGranularity ?? (dateFromHasTimePrecision ? 'minute' : 'day')
    )

    const isFutureRelativeDate = typeof dateFrom === 'string' && /^\+?\d+[hdwmqyMs]$/.test(dateFrom)
    const showFixedRangeTimeToggle = allowTimePrecision || allowFixedRangeWithTime
    const showExclusions =
        (showIncompletePeriodExclusion || showDaysOfWeekExclusions) && !!exclusions && !!onExclusionsChange
    const showFooter =
        showCustomRangeOptions ||
        showExplicitDateToggle ||
        showExclusions ||
        showJumpToTimestamp ||
        Boolean(footerComponent)

    const popoverOverlay =
        view === DateFilterView.FixedRange ? (
            showFixedRangeTimeToggle && fixedRangeGranularity === 'minute' ? (
                <FixedRangeWithTimePicker
                    rangeDateFrom={rangeDateFrom}
                    rangeDateTo={rangeDateTo}
                    setDate={setDate}
                    onClose={open}
                    use24HourFormat={use24HourFormat}
                    showTimeToggle={showFixedRangeTimeToggle}
                    onToggleTime={(includeTime) => setFixedRangeGranularity(includeTime ? 'minute' : 'day')}
                />
            ) : (
                <LemonCalendarRange
                    value={[rangeDateFrom ?? dayjs(), rangeDateTo ?? dayjs()]}
                    onChange={([from, to]) => {
                        setRangeDateFrom(from)
                        setRangeDateTo(to)
                        setExplicitDate(false)
                        applyRange()
                    }}
                    onClose={open}
                    months={2}
                    showTimeToggle={showFixedRangeTimeToggle}
                    onToggleTime={(includeTime) => setFixedRangeGranularity(includeTime ? 'minute' : 'day')}
                />
            )
        ) : view === DateFilterView.FixedRangeWithTime ? (
            <FixedRangeWithTimePicker
                rangeDateFrom={rangeDateFrom}
                rangeDateTo={rangeDateTo}
                setDate={setDate}
                onClose={open}
                use24HourFormat={use24HourFormat}
            />
        ) : view === DateFilterView.DateToNow ? (
            <LemonCalendarSelect
                value={rangeDateFrom ?? dayjs()}
                onChange={(date) => {
                    setRangeDateFrom(date)
                    setRangeDateTo(null)
                    setExplicitDate(granularity === 'minute')
                    applyRange()
                }}
                onClose={open}
                granularity={forceGranularity ?? granularity}
                showTimeToggle={forceGranularity ? false : allowTimePrecision}
                onToggleTime={
                    forceGranularity ? undefined : () => setGranularity(granularity === 'minute' ? 'day' : 'minute')
                }
                use24HourFormat={use24HourFormat}
            />
        ) : view === DateFilterView.FixedDate ? (
            <PropertyFilterDatePicker
                autoFocus
                // IsDateExact (rather than Exact) so PropertyFilterDatePicker's auto-open gate
                // — `operator && isOperatorDate(operator) && autoFocus` — opens the calendar
                // immediately instead of waiting for a click on the input.
                operator={PropertyOperator.IsDateExact}
                value={rangeDateFrom ? rangeDateFrom.toString() : dayjs().toString()}
                setValue={(date) => {
                    setDate(String(date), null)
                }}
            />
        ) : view === DateFilterView.JumpToTimestamp ? (
            <JumpToTimestampPicker onApply={(dateFrom, dateTo) => setDate(dateFrom, dateTo)} onClose={open} />
        ) : view === DateFilterView.CustomRelativeRange ? (
            <RelativeDateRangeSelector
                onApply={(from, to) => setDate(from, to)}
                onClose={open}
                initialFrom={typeof dateFrom === 'string' ? dateFrom : null}
                initialTo={typeof dateTo === 'string' ? dateTo : null}
            />
        ) : (
            <div className="flex max-h-full min-h-0 flex-col" ref={optionsRef} onClick={(e) => e.stopPropagation()}>
                <ScrollableShadows
                    direction="vertical"
                    hideScrollbars
                    // max-h-80 shows ~9 preset rows with a sliver of the tenth as a scroll hint
                    className={clsx('min-h-0 flex-1', showFooter && 'border-b', optionsSize === 'small' && 'max-h-80')}
                    innerClassName="deprecated-space-y-px p-1"
                >
                    {dateOptions.map(({ key, values, inactive }) => {
                        if (key === CUSTOM_OPTION_KEY && !showCustom) {
                            return null
                        }

                        if (inactive && label !== key) {
                            return null
                        }

                        const isActive =
                            (dateFrom ?? null) === (values[0] ?? null) && (dateTo ?? null) === (values[1] ?? null)
                        const dateValue = dateFilterToText(
                            values[0],
                            values[1],
                            CUSTOM_OPTION_DESCRIPTION,
                            dateOptions,
                            isDateFormatted,
                            undefined,
                            undefined,
                            weekStartDay
                        )
                        const startOfRangeDateValue = dateFilterToText(
                            values[0],
                            undefined,
                            '',
                            [],
                            false,
                            'MMMM D, YYYY',
                            true
                        )
                        const endOfRangeDateValue = values[1]
                            ? dateFilterToText(values[1], undefined, '', [], false, 'MMMM D, YYYY', true)
                            : undefined

                        return (
                            <Tooltip
                                key={key}
                                title={
                                    makeLabel
                                        ? makeLabel(dateValue, startOfRangeDateValue, endOfRangeDateValue)
                                        : undefined
                                }
                            >
                                <LemonButton
                                    key={key}
                                    data-attr={`date-filter-${key.toLowerCase().replace(/\s+/g, '-')}`}
                                    onClick={() => setDate(values[0] || null, values[1] || null, false, explicitDate)}
                                    active={isActive}
                                    size={optionsSize}
                                    fullWidth
                                >
                                    {key === CUSTOM_OPTION_KEY ? NO_OVERRIDE_RANGE_PLACEHOLDER : key}
                                </LemonButton>
                            </Tooltip>
                        )
                    })}
                    {showRollingRangePicker && (
                        <RollingDateRangeFilter
                            pageKey={key}
                            size={optionsSize}
                            dateFrom={dateFrom}
                            dateRangeFilterLabel={isFixedDateMode ? 'Last' : undefined}
                            selected={isRollingDateRange && !isFutureRelativeDate}
                            onChange={(fromDate) => {
                                setDate(fromDate, '', true, explicitDate)
                            }}
                            makeLabel={makeLabel}
                            popover={{
                                ref: rollingDateRangeRef,
                            }}
                            max={max}
                            allowedDateOptions={
                                isFixedDateMode && !allowedRollingDateOptions
                                    ? ['hours', 'days', 'weeks', 'months', 'years']
                                    : allowedRollingDateOptions
                            }
                            fullWidth
                        />
                    )}
                    {allowFutureRelativeDateOptions && (
                        <RollingDateRangeFilter
                            pageKey={`${key}-future`}
                            size={optionsSize}
                            dateFrom={dateFrom}
                            dateRangeFilterLabel="In the next"
                            direction="future"
                            selected={isRollingDateRange && isFutureRelativeDate}
                            onChange={(fromDate) => {
                                setDate(fromDate, '', true, explicitDate)
                            }}
                            makeLabel={makeLabel}
                            popover={{
                                ref: futureRollingDateRangeRef,
                            }}
                            max={max}
                            allowedDateOptions={
                                isFixedDateMode && !allowedRollingDateOptions
                                    ? ['hours', 'days', 'weeks', 'months', 'years']
                                    : allowedRollingDateOptions
                            }
                            fullWidth
                        />
                    )}
                </ScrollableShadows>
                {showFooter && (
                    <div className="shrink-0 deprecated-space-y-px p-1">
                        {showCustomRangeOptions && (isFixedDateMode || allowSingleAndRange) && (
                            <LemonButton onClick={openFixedDate} active={isFixedDate} size={optionsSize} fullWidth>
                                Custom date...
                            </LemonButton>
                        )}
                        {showCustomRangeOptions && (!isFixedDateMode || allowSingleAndRange) && (
                            <>
                                {!allowSingleAndRange && (
                                    <LemonButton
                                        onClick={openDateToNow}
                                        active={isDateToNow}
                                        size={optionsSize}
                                        fullWidth
                                    >
                                        From custom date until now…
                                    </LemonButton>
                                )}
                                <LemonButton
                                    onClick={openFixedRange}
                                    active={isFixedRange}
                                    size={optionsSize}
                                    fullWidth
                                >
                                    Custom fixed date range…
                                </LemonButton>
                                {effectiveShowCustomRelativeRange && (
                                    <LemonButton
                                        onClick={openCustomRelativeRange}
                                        active={isCustomRelativeRange}
                                        size={optionsSize}
                                        fullWidth
                                    >
                                        Custom relative range…
                                    </LemonButton>
                                )}
                            </>
                        )}
                        {footerComponent?.(close)}
                        {showCustomRangeOptions && (showExplicitDateToggle || showExclusions) && <LemonDivider />}
                        {showExplicitDateToggle && (
                            <div
                                className={clsx(
                                    // Deliberately medium at every optionsSize: LemonButton--small keeps the default
                                    // 14px font, while LemonSwitch--small would drop the label to 12px
                                    'LemonSwitch LemonSwitch--full-width LemonSwitch--medium',
                                    optionsSize === 'small' ? 'pb-1 pt-1' : 'pb-2 pt-2'
                                )}
                            >
                                <label className="flex items-center gap-1">
                                    <span>Exact time range</span>
                                    <Tooltip
                                        title={
                                            <>
                                                <div className="font-semibold mb-1">When enabled:</div>
                                                <div className="mb-2">
                                                    Uses the current time for period boundaries instead of full days.
                                                </div>
                                                <div className="font-semibold mb-1">When disabled:</div>
                                                <div>Dates are rounded to full day periods (start and end of day).</div>
                                            </>
                                        }
                                    >
                                        <IconInfo className="text-muted-alt w-4 h-4" />
                                    </Tooltip>
                                </label>
                                <LemonSwitch
                                    checked={explicitDate ?? false}
                                    onChange={(checked) => {
                                        setExplicitDate(checked)
                                    }}
                                />
                            </div>
                        )}
                        {showExclusions && (
                            <LemonDateFilterExclusions
                                exclusions={exclusions}
                                onChange={onExclusionsChange}
                                showDays={showDaysOfWeekExclusions}
                                showIncomplete={showIncompletePeriodExclusion}
                                size={optionsSize}
                            />
                        )}
                        {showJumpToTimestamp && (
                            <>
                                <LemonDivider />
                                <LemonButton
                                    onClick={openJumpToTimestamp}
                                    size={optionsSize}
                                    fullWidth
                                    data-attr="jump-to-timestamp-option"
                                >
                                    Jump to timestamp…
                                </LemonButton>
                            </>
                        )}
                    </div>
                )}
            </div>
        )

    return (
        <Popover
            visible={isVisible}
            overlay={popoverOverlay}
            placement={dropdownPlacement}
            actionable
            additionalRefs={[rollingDateRangeRef, futureRollingDateRangeRef]}
            onClickOutside={close}
            closeParentPopoverOnClickInside={false}
            overflowHidden={view === DateFilterView.QuickList}
        >
            <LemonButton
                ref={ref}
                id="daterange_selector"
                size={size ?? 'small'}
                type={type ?? 'secondary'}
                disabledReason={disabledReason}
                data-attr="date-filter"
                icon={<IconCalendar />}
                onClick={isVisible ? close : open}
                fullWidth={fullWidth}
                tooltip={formatResolvedDateRange(resolvedDateRange)}
            >
                <span className={clsx('text-nowrap', className)}>{label}</span>
            </LemonButton>
        </Popover>
    )
})
