import {
    breakdownFilterToTaxonomicFilterType,
    convertPropertiesToPropertyGroup,
    convertPropertyGroupToProperties,
    createDefaultPropertyFilter,
    formatPropertyLabel,
    isAnyPropertyfilter,
    isGroupCardFilterKey,
    isValidPropertyFilter,
    normalizePropertyFilterValue,
    propertyFilterTypeToTaxonomicFilterType,
    resolvePropertyDefinitionId,
    taxonomicFilterTypeToPropertyFilterType,
} from 'lib/components/PropertyFilters/utils'

import type { propertyDefinitionsModelType } from '~/models/propertyDefinitionsModel'
import { BreakdownFilter } from '~/queries/schema/schema-general'

import {
    ActionType,
    AnyPropertyFilter,
    BehavioralEventType,
    BehavioralPropertyFilter,
    CohortPropertyFilter,
    ElementPropertyFilter,
    EmptyPropertyFilter,
    FilterLogicalOperator,
    PropertyDefinition,
    PropertyDefinitionType,
    PropertyFilterType,
    PropertyGroupFilter,
    PropertyOperator,
    SessionPropertyFilter,
    TimeUnitType,
} from '../../../types'
import { TaxonomicFilterGroup, TaxonomicFilterGroupType } from '../TaxonomicFilter/types'

describe('isGroupCardFilterKey()', () => {
    it.each([
        { key: '$group_key', type: PropertyFilterType.Group, expected: true },
        { key: 'id', type: PropertyFilterType.Group, expected: true },
        // 'id' is also the Cohort key — must not match there.
        { key: 'id', type: PropertyFilterType.Cohort, expected: false },
        // Group *property* filters use other keys.
        { key: 'industry', type: PropertyFilterType.Group, expected: false },
        // '$group_key' only makes sense for a Group-type filter.
        { key: '$group_key', type: PropertyFilterType.Event, expected: false },
        { key: '$group_key', type: undefined, expected: false },
        { key: undefined, type: PropertyFilterType.Group, expected: false },
    ])('returns $expected for key=$key type=$type', ({ key, type, expected }) => {
        expect(isGroupCardFilterKey(key, type)).toBe(expected)
    })
})

describe('isValidPropertyFilter()', () => {
    it('returns values correctly', () => {
        const emptyProperty: AnyPropertyFilter = {} as EmptyPropertyFilter
        const realProperty: CohortPropertyFilter = {
            key: 'id',
            value: 33,
            type: PropertyFilterType.Cohort,
            operator: PropertyOperator.NotIn,
        }
        expect(isValidPropertyFilter(emptyProperty)).toEqual(false)
        expect(isValidPropertyFilter(realProperty)).toEqual(true)
        expect(isValidPropertyFilter(undefined as any)).toEqual(false)
        expect(isValidPropertyFilter(null as any)).toEqual(false)
        expect(isValidPropertyFilter({ bla: 'true' } as any)).toEqual(false)
        expect(isValidPropertyFilter({ key: undefined } as any)).toEqual(false)
        expect(isValidPropertyFilter({ key: 'cohort', value: 123 } as any)).toEqual(true)
    })
})

describe('formatPropertyLabel() for behavioral filters', () => {
    const base: BehavioralPropertyFilter = {
        type: PropertyFilterType.Behavioral,
        value: BehavioralEventType.PerformEvent,
        key: 'signed_up',
        event_type: 'events',
        time_value: 30,
        time_interval: TimeUnitType.Day,
    }

    // pluralize() glues the count to its unit with a non-breaking space
    // Every row spells out actionsById: a shorter row makes jest-each hand the callback a `done`
    const noActions: Partial<Record<string | number, ActionType>> = {}

    test.each<[string, Partial<BehavioralPropertyFilter>, string, Partial<Record<string | number, ActionType>>]>([
        ['performed', {}, 'Performed signed_up in the last 30\u00a0days', noActions],
        ['did not perform', { negation: true }, 'Did not perform signed_up in the last 30\u00a0days', noActions],
        [
            'count',
            {
                value: BehavioralEventType.PerformMultipleEvents,
                operator: PropertyOperator.GreaterThanOrEqual,
                operator_value: 3,
            },
            'Performed signed_up at least 3\u00a0times in the last 30\u00a0days',
            noActions,
        ],
        [
            'single unit',
            { time_value: 1, time_interval: TimeUnitType.Week },
            'Performed signed_up in the last 1\u00a0week',
            noActions,
        ],
        [
            'explicit date',
            { explicit_datetime: '-14d', time_value: undefined },
            'Performed signed_up since -14d',
            noActions,
        ],
        [
            'core event uses its readable label',
            { key: '$pageview' },
            'Performed Pageview in the last 30\u00a0days',
            noActions,
        ],
        [
            'action resolves to its name',
            { key: '42', event_type: 'actions' },
            'Performed Completed checkout in the last 30\u00a0days',
            { 42: { id: 42, name: 'Completed checkout' } as ActionType },
        ],
        [
            'unresolved action falls back to its id',
            { key: '42', event_type: 'actions' },
            'Performed action 42 in the last 30\u00a0days',
            noActions,
        ],
        [
            'API-created negated filter includes its nested event filters',
            {
                negation: true,
                event_filters: [
                    { type: PropertyFilterType.Event, key: 'source', operator: PropertyOperator.Exact, value: ['web'] },
                ],
            },
            'Did not perform signed_up where Source = web in the last 30\u00a0days',
            noActions,
        ],
        [
            'multiple nested event filters join with and',
            {
                event_filters: [
                    { type: PropertyFilterType.Event, key: 'source', operator: PropertyOperator.Exact, value: ['web'] },
                    { type: PropertyFilterType.Person, key: 'email', operator: PropertyOperator.IsSet, value: null },
                ],
            },
            'Performed signed_up where Source = web and Email address ✓ is set in the last 30\u00a0days',
            noActions,
        ],
    ])('%s', (_name, overrides, expected, actionsById) => {
        expect(formatPropertyLabel({ ...base, ...overrides }, {}, undefined, actionsById)).toEqual(expected)
    })
})

describe('formatPropertyLabel() for account date filters', () => {
    it.each([
        ['-14d', 'created_at > 14 days ago'],
        [['-14d'], 'created_at > 14 days ago'],
        ['14d', 'created_at > 14 days from now'],
        ['+1w', 'created_at > 1 week from now'],
    ])('formats %s as %s', (value, expected) => {
        expect(
            formatPropertyLabel(
                {
                    key: 'created_at',
                    value,
                    type: PropertyFilterType.Account,
                    operator: PropertyOperator.IsDateAfter,
                } as unknown as AnyPropertyFilter,
                {}
            ).trim()
        ).toBe(expected)
    })
})

describe('propertyFilterTypeToTaxonomicFilterType()', () => {
    const baseFilter: AnyPropertyFilter = {
        type: PropertyFilterType.Event,
        key: 'some_key',
        value: 'some_value',
        operator: PropertyOperator.Exact,
    }

    it('returns values correctly', () => {
        expect(propertyFilterTypeToTaxonomicFilterType({} as EmptyPropertyFilter)).toEqual(undefined)
        expect(
            propertyFilterTypeToTaxonomicFilterType({
                type: PropertyFilterType.Cohort,
                operator: PropertyOperator.In,
                key: 'id',
                value: 33,
            })
        ).toEqual(TaxonomicFilterGroupType.Cohorts)
        expect(
            propertyFilterTypeToTaxonomicFilterType({
                ...baseFilter,
                type: PropertyFilterType.Group,
                group_type_index: 2,
            })
        ).toEqual('groups_2')
        expect(
            propertyFilterTypeToTaxonomicFilterType({
                ...baseFilter,
                type: PropertyFilterType.Event,
                key: '$feature/abc',
            })
        ).toEqual(TaxonomicFilterGroupType.EventFeatureFlags)
        expect(propertyFilterTypeToTaxonomicFilterType({ ...baseFilter, type: PropertyFilterType.Person })).toEqual(
            TaxonomicFilterGroupType.PersonProperties
        )
        expect(propertyFilterTypeToTaxonomicFilterType({ ...baseFilter, type: PropertyFilterType.Event })).toEqual(
            TaxonomicFilterGroupType.EventProperties
        )
        expect(
            propertyFilterTypeToTaxonomicFilterType({
                ...baseFilter,
                type: PropertyFilterType.Element,
            } as ElementPropertyFilter)
        ).toEqual(TaxonomicFilterGroupType.Elements)
        expect(
            propertyFilterTypeToTaxonomicFilterType({
                ...baseFilter,
                type: PropertyFilterType.Session,
            } as SessionPropertyFilter)
        ).toEqual(TaxonomicFilterGroupType.SessionProperties)
        expect(propertyFilterTypeToTaxonomicFilterType({ ...baseFilter, type: PropertyFilterType.HogQL })).toEqual(
            TaxonomicFilterGroupType.HogQLExpression
        )
    })
})

describe('breakdownFilterToTaxonomicFilterType()', () => {
    const baseFilter: BreakdownFilter = {
        breakdown_type: 'event',
        breakdown: '$browser',
    }

    it('returns values correctly', () => {
        expect(breakdownFilterToTaxonomicFilterType({} as BreakdownFilter)).toEqual(undefined)
        expect(breakdownFilterToTaxonomicFilterType({ breakdown_type: 'cohort', breakdown: 33 })).toEqual(
            TaxonomicFilterGroupType.Cohorts
        )
        expect(
            breakdownFilterToTaxonomicFilterType({
                ...baseFilter,
                breakdown_type: 'group',
                breakdown_group_type_index: 2,
            })
        ).toEqual('groups_2')
        expect(
            breakdownFilterToTaxonomicFilterType({
                ...baseFilter,
                breakdown_type: 'event',
                breakdown: '$feature/abc',
            })
        ).toEqual(TaxonomicFilterGroupType.EventFeatureFlags)
        expect(breakdownFilterToTaxonomicFilterType({ ...baseFilter, breakdown_type: 'person' })).toEqual(
            TaxonomicFilterGroupType.PersonProperties
        )
        expect(breakdownFilterToTaxonomicFilterType({ ...baseFilter, breakdown_type: 'event' })).toEqual(
            TaxonomicFilterGroupType.EventProperties
        )
        expect(breakdownFilterToTaxonomicFilterType({ ...baseFilter, breakdown_type: 'session' })).toEqual(
            TaxonomicFilterGroupType.SessionProperties
        )
        expect(breakdownFilterToTaxonomicFilterType({ ...baseFilter, breakdown_type: 'hogql' })).toEqual(
            TaxonomicFilterGroupType.HogQLExpression
        )
    })
})

describe('convertPropertyGroupToProperties()', () => {
    it('converts a single layer property group into an array of properties', () => {
        const propertyGroup = {
            type: FilterLogicalOperator.And,
            values: [
                {
                    type: FilterLogicalOperator.And,
                    values: [
                        { key: '$browser', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
                        { key: '$current_url', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
                    ] as AnyPropertyFilter[],
                },
                {
                    type: FilterLogicalOperator.And,
                    values: [
                        { key: '$lib', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
                    ] as AnyPropertyFilter[],
                },
            ],
        }
        expect(convertPropertyGroupToProperties(propertyGroup)).toEqual([
            { key: '$browser', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
            { key: '$current_url', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
            { key: '$lib', type: PropertyFilterType.Event, operator: PropertyOperator.IsSet },
        ])
    })

    it('converts a deeply nested property group into an array of properties', () => {
        const propertyGroup: PropertyGroupFilter = {
            type: FilterLogicalOperator.And,
            values: [
                {
                    type: FilterLogicalOperator.And,
                    values: [{ type: FilterLogicalOperator.And, values: [{ key: '$lib' } as any] }],
                },
                { type: FilterLogicalOperator.And, values: [{ key: '$browser' } as any] },
            ],
        }
        expect(convertPropertyGroupToProperties(propertyGroup)).toEqual([{ key: '$lib' }, { key: '$browser' }])
    })
})

describe('convertPropertiesToPropertyGroup', () => {
    it('converts properties to one AND operator property group', () => {
        const properties: any[] = [{ key: '$lib' }, { key: '$browser' }, { key: '$current_url' }]
        expect(convertPropertiesToPropertyGroup(properties)).toEqual({
            type: FilterLogicalOperator.And,
            values: [
                {
                    type: FilterLogicalOperator.And,
                    values: [{ key: '$lib' }, { key: '$browser' }, { key: '$current_url' }],
                },
            ],
        })
    })

    it('converts undefined properties to one AND operator property group', () => {
        expect(convertPropertiesToPropertyGroup(undefined)).toEqual({
            type: FilterLogicalOperator.And,
            values: [],
        })
    })
})

describe('normalizePropertyFilterValue()', () => {
    it('wraps string values in arrays for multi-select operators', () => {
        expect(normalizePropertyFilterValue('test', PropertyOperator.Exact)).toEqual(['test'])
        expect(normalizePropertyFilterValue('test', PropertyOperator.IsNot)).toEqual(['test'])
    })

    it('wraps number values in arrays for multi-select operators', () => {
        expect(normalizePropertyFilterValue(123, PropertyOperator.Exact)).toEqual([123])
    })

    it('does not wrap values that are already arrays', () => {
        expect(normalizePropertyFilterValue(['test'], PropertyOperator.Exact)).toEqual(['test'])
        expect(normalizePropertyFilterValue(['a', 'b'], PropertyOperator.Exact)).toEqual(['a', 'b'])
    })

    it('wraps values for multi-select contains operators', () => {
        expect(normalizePropertyFilterValue('test', PropertyOperator.IContainsMulti)).toEqual(['test'])
        expect(normalizePropertyFilterValue('test', PropertyOperator.NotIContainsMulti)).toEqual(['test'])
    })

    it('does not wrap values for non-multi-select operators', () => {
        expect(normalizePropertyFilterValue('test', PropertyOperator.Regex)).toEqual('test')
        expect(normalizePropertyFilterValue('test', PropertyOperator.IsSet)).toEqual('test')
        expect(normalizePropertyFilterValue('test', PropertyOperator.GreaterThan)).toEqual('test')
        expect(normalizePropertyFilterValue('test', PropertyOperator.IContains)).toEqual('test')
        expect(normalizePropertyFilterValue('test', PropertyOperator.NotIContains)).toEqual('test')
    })

    it('handles null and undefined values', () => {
        expect(normalizePropertyFilterValue(null, PropertyOperator.Exact)).toEqual(null)
        expect(normalizePropertyFilterValue(undefined, PropertyOperator.Exact)).toEqual(undefined)
    })

    it('handles null and undefined operators', () => {
        expect(normalizePropertyFilterValue('test', null)).toEqual('test')
        expect(normalizePropertyFilterValue('test', undefined)).toEqual('test')
    })
})

describe('isAnyPropertyfilter()', () => {
    // A taxonomic-backed attribute filter that isn't recognized here resolves to no
    // activeTaxonomicGroup, so its value picker loses `valuesEndpoint` and falls back to a
    // bogus `api/<type>/values` URL that returns nothing. Guards that regression for each
    // attribute family (metric_attribute broke exactly this way).
    it.each([PropertyFilterType.MetricAttribute, PropertyFilterType.LogAttribute, PropertyFilterType.SpanAttribute])(
        'recognizes %s as a property filter',
        (type) => {
            const filter = { type, key: 'env', operator: PropertyOperator.Exact, value: ['prod'] } as AnyPropertyFilter
            expect(isAnyPropertyfilter(filter)).toBe(true)
        }
    )
})

describe('type mapping round-trip', () => {
    it.each([
        [PropertyFilterType.Event, TaxonomicFilterGroupType.EventProperties],
        [PropertyFilterType.Person, TaxonomicFilterGroupType.PersonProperties],
        [PropertyFilterType.Cohort, TaxonomicFilterGroupType.Cohorts],
        [PropertyFilterType.Element, TaxonomicFilterGroupType.Elements],
        [PropertyFilterType.Session, TaxonomicFilterGroupType.SessionProperties],
        [PropertyFilterType.HogQL, TaxonomicFilterGroupType.HogQLExpression],
    ])('PropertyFilterType.%s round-trips through both mapping functions', (propertyType, expectedTaxonomicType) => {
        const filter = {
            type: propertyType,
            key: 'test_key',
            value: 'test_value',
            operator: PropertyOperator.Exact,
        } as AnyPropertyFilter
        const taxonomicType = propertyFilterTypeToTaxonomicFilterType(filter)
        expect(taxonomicType).toEqual(expectedTaxonomicType)

        const backToPropertyType = taxonomicFilterTypeToPropertyFilterType(taxonomicType)
        expect(backToPropertyType).toEqual(propertyType)
    })

    it('MCPProperties maps one-way to the Event property filter type', () => {
        // The rebuild menu commits with the tab's own group type, so without this
        // mapping an MCP-tab selection would produce a filter with no type.
        expect(taxonomicFilterTypeToPropertyFilterType(TaxonomicFilterGroupType.MCPProperties)).toEqual(
            PropertyFilterType.Event
        )
    })

    it('Group type round-trips with group_type_index preserved', () => {
        const filter = {
            type: PropertyFilterType.Group,
            key: 'test_key',
            value: 'test_value',
            operator: PropertyOperator.Exact,
            group_type_index: 2,
        } as AnyPropertyFilter
        const taxonomicType = propertyFilterTypeToTaxonomicFilterType(filter)
        expect(taxonomicType).toEqual('groups_2')

        const backToPropertyType = taxonomicFilterTypeToPropertyFilterType(taxonomicType)
        expect(backToPropertyType).toEqual(PropertyFilterType.Group)
    })
})

describe('createDefaultPropertyFilter()', () => {
    const noopDescribeProperty = (): null => null
    const makeGroup = (type: TaxonomicFilterGroupType, groupTypeIndex?: number): TaxonomicFilterGroup =>
        ({
            type,
            groupTypeIndex,
        }) as TaxonomicFilterGroup

    it('creates a cohort filter with parseInt value', () => {
        const result = createDefaultPropertyFilter(
            null,
            '42',
            PropertyFilterType.Cohort,
            makeGroup(TaxonomicFilterGroupType.Cohorts),
            noopDescribeProperty
        )
        expect(result).toEqual({
            key: 'id',
            value: 42,
            type: PropertyFilterType.Cohort,
            operator: PropertyOperator.In,
        })
    })

    it('creates a HogQL filter with null value', () => {
        const result = createDefaultPropertyFilter(
            null,
            "event = 'click'",
            PropertyFilterType.HogQL,
            makeGroup(TaxonomicFilterGroupType.HogQLExpression),
            noopDescribeProperty
        )
        expect(result).toEqual({
            type: PropertyFilterType.HogQL,
            key: "event = 'click'",
            value: null,
        })
    })

    it('creates a flag filter with default true value and FlagEvaluatesTo operator', () => {
        const result = createDefaultPropertyFilter(
            null,
            'my-flag',
            PropertyFilterType.Flag,
            makeGroup(TaxonomicFilterGroupType.FeatureFlags),
            noopDescribeProperty
        )
        expect(result).toEqual({
            type: PropertyFilterType.Flag,
            key: 'my-flag',
            value: true,
            operator: PropertyOperator.FlagEvaluatesTo,
        })
    })

    it('creates a group name filter with $group_key as key and the selection as value', () => {
        const result = createDefaultPropertyFilter(
            null,
            'my-company',
            PropertyFilterType.Group,
            makeGroup('name_groups_0' as TaxonomicFilterGroupType, 0),
            noopDescribeProperty
        )
        expect(result).toEqual(
            expect.objectContaining({
                key: '$group_key',
                value: 'my-company',
                type: PropertyFilterType.Group,
                group_type_index: 0,
            })
        )
    })

    it.each([
        ['$browser', PropertyOperator.Exact],
        ['$current_url', PropertyOperator.IContains],
        ['$pathname', PropertyOperator.IContains],
    ])('defaults the %s event property filter to the %s operator', (propertyKey, expectedOperator) => {
        const result = createDefaultPropertyFilter(
            null,
            propertyKey,
            PropertyFilterType.Event,
            makeGroup(TaxonomicFilterGroupType.EventProperties),
            noopDescribeProperty
        )
        expect(result).toEqual(
            expect.objectContaining({
                key: propertyKey,
                value: null,
                type: PropertyFilterType.Event,
                operator: expectedOperator,
            })
        )
    })

    it('preserves existing operator from previous filter when valid', () => {
        const existingFilter: AnyPropertyFilter = {
            key: '$browser',
            value: 'Chrome',
            type: PropertyFilterType.Event,
            operator: PropertyOperator.IsNot,
        }
        const result = createDefaultPropertyFilter(
            existingFilter,
            '$os',
            PropertyFilterType.Event,
            makeGroup(TaxonomicFilterGroupType.EventProperties),
            noopDescribeProperty
        )
        expect(result).toEqual(expect.objectContaining({ operator: PropertyOperator.IsNot }))
    })

    it('pre-fills value from selectedItem.matchedValue when matchedOn is "value"', () => {
        const result = createDefaultPropertyFilter(
            null,
            'user.email',
            'log_attribute' as PropertyFilterType,
            makeGroup('log_attributes' as TaxonomicFilterGroupType),
            noopDescribeProperty,
            { matchedOn: 'value', matchedValue: 'frank@posthog.com' }
        )
        expect(result).toEqual(
            expect.objectContaining({
                key: 'user.email',
                value: ['frank@posthog.com'],
                operator: PropertyOperator.Exact,
            })
        )
    })

    it('does not pre-fill value when matchedOn is "key"', () => {
        const result = createDefaultPropertyFilter(
            null,
            'user.email',
            'log_attribute' as PropertyFilterType,
            makeGroup('log_attributes' as TaxonomicFilterGroupType),
            noopDescribeProperty,
            { matchedOn: 'key', matchedValue: 'frank@posthog.com' }
        )
        expect(result).toEqual(expect.objectContaining({ key: 'user.email', value: null }))
    })

    it('does not pre-fill value when selectedItem is omitted', () => {
        const result = createDefaultPropertyFilter(
            null,
            'user.email',
            'log_attribute' as PropertyFilterType,
            makeGroup('log_attributes' as TaxonomicFilterGroupType),
            noopDescribeProperty
        )
        expect(result).toEqual(expect.objectContaining({ key: 'user.email', value: null }))
    })
})

describe('resolvePropertyDefinitionId()', () => {
    const modelWith = (
        byKey: Record<string, PropertyDefinition>
    ): propertyDefinitionsModelType['values']['getPropertyDefinition'] =>
        ((name, type) =>
            byKey[`${type}/${name}`] ?? null) as propertyDefinitionsModelType['values']['getPropertyDefinition']

    it('returns the id already on the definition without consulting the model', () => {
        const getPropertyDefinition = jest.fn()
        expect(
            resolvePropertyDefinitionId(
                { id: 'abc', name: '$browser' },
                TaxonomicFilterGroupType.EventProperties,
                getPropertyDefinition as unknown as propertyDefinitionsModelType['values']['getPropertyDefinition']
            )
        ).toBe('abc')
        expect(getPropertyDefinition).not.toHaveBeenCalled()
    })

    // Recovers a name-only pinned/default property's id from the model, keyed by the
    // group type mapped through to a PropertyDefinitionType — the /properties/undefined regression.
    it.each([
        [TaxonomicFilterGroupType.EventProperties, PropertyDefinitionType.Event, '$current_url', 'event-url-id'],
        [TaxonomicFilterGroupType.PersonProperties, PropertyDefinitionType.Person, 'email', 'person-email-id'],
    ])('recovers a name-only %s id from the model', (groupType, defType, name, id) => {
        const get = modelWith({ [`${defType}/${name}`]: { id, name } as PropertyDefinition })
        expect(resolvePropertyDefinitionId({ name } as PropertyDefinition, groupType, get)).toBe(id)
    })

    it('returns undefined when the model has no matching definition', () => {
        expect(
            resolvePropertyDefinitionId(
                { name: 'never-loaded' } as PropertyDefinition,
                TaxonomicFilterGroupType.EventProperties,
                () => null
            )
        ).toBeUndefined()
    })
})
