import { useActions, useValues } from 'kea'
import { forwardRef } from 'react'

import { IconTarget } from '@posthog/icons'
import { LemonButton } from '@posthog/lemon-ui'

import { keyBinds } from 'lib/components/Shortcuts/shortcuts'
import { useShortcut } from 'lib/components/Shortcuts/useShortcut'
import { useFeatureFlag } from 'lib/hooks/useFeatureFlag'
import { LemonBadge } from 'lib/lemon-ui/LemonBadge'
import { organizationLogic } from 'scenes/organizationLogic'

import { globalSetupLogic } from './globalSetupLogic'
import { productSetupLogic } from './productSetupLogic'
import { ProductSetupPopover } from './ProductSetupPopover'

/**
 * ProductSetupButton - A button that appears in the scene title section
 * and allows users to access quick start guides for any product.
 * The selected product is managed by globalSetupLogic, with auto-selection
 * handled by SceneContent when a productKey is provided.
 */
export function ProductSetupButton(): JSX.Element | null {
    const { selectedProduct, isGlobalModalOpen, sceneHasNoSetup } = useValues(globalSetupLogic)
    const { openGlobalSetup, closeGlobalSetup, setSelectedProduct } = useActions(globalSetupLogic)
    const { isCurrentOrganizationNew } = useValues(organizationLogic)
    const showPulseIndicator = useFeatureFlag('QUICK_START_PULSE_INDICATOR', 'test')

    // Get the setup state for the selected product
    const logic = productSetupLogic({ productKey: selectedProduct })
    const { remainingCount, shouldShowSetup, isDismissed } = useValues(logic)
    const { undismissSetup } = useActions(logic)

    // Show button if there are remaining tasks OR if the modal is currently open (to show completion)
    const shouldShowButton = isCurrentOrganizationNew && !sceneHasNoSetup && (remainingCount > 0 || isGlobalModalOpen)

    const handleToggle = (): void => {
        if (isGlobalModalOpen) {
            closeGlobalSetup()
        } else {
            if (isDismissed) {
                undismissSetup()
            }
            openGlobalSetup()
        }
    }

    useShortcut({
        name: 'QuickStartGlobal',
        keybind: [keyBinds.quickStart],
        intent: 'Open quick start guide',
        interaction: 'function',
        callback: handleToggle,
        disabled: !shouldShowButton,
    })

    if (!shouldShowButton) {
        return null
    }

    return (
        <ProductSetupPopover
            visible={isGlobalModalOpen}
            onClickOutside={closeGlobalSetup}
            selectedProduct={selectedProduct}
            onSelectProduct={setSelectedProduct}
        >
            {isDismissed && !isGlobalModalOpen ? (
                <MinimizedButton remainingCount={remainingCount} isActive={isGlobalModalOpen} onClick={handleToggle} />
            ) : (
                <ExpandedButton
                    remainingCount={remainingCount}
                    showBadge={shouldShowSetup}
                    isActive={isGlobalModalOpen}
                    onClick={handleToggle}
                    showPulse={showPulseIndicator}
                />
            )}
        </ProductSetupPopover>
    )
}

interface MinimizedButtonProps {
    remainingCount: number
    isActive: boolean
    onClick: () => void
}

const MinimizedButton = forwardRef<HTMLButtonElement, MinimizedButtonProps>(function MinimizedButton(
    { remainingCount, isActive, onClick },
    ref
) {
    return (
        <LemonButton
            ref={ref}
            icon={
                <span className="relative">
                    <IconTarget />
                    {remainingCount > 0 && (
                        <LemonBadge.Number count={remainingCount} status="warning" size="medium" position="top-right" />
                    )}
                </span>
            }
            size="small"
            type="secondary"
            onClick={onClick}
            active={isActive}
            tooltip="Quick start (click to expand)"
            data-attr="global-product-setup-button-minimized"
        />
    )
})

interface ExpandedButtonProps {
    remainingCount: number
    showBadge: boolean
    isActive: boolean
    onClick: () => void
    showPulse: boolean
}

const ExpandedButton = forwardRef<HTMLButtonElement, ExpandedButtonProps>(function ExpandedButton(
    { remainingCount, showBadge, isActive, onClick, showPulse },
    ref
) {
    // Hide the pulse when the popover is open to avoid distracting the user, but keep the
    // numeric badge visible in the control variant so its behavior matches the pre-experiment baseline.
    const showIndicator = showBadge && remainingCount > 0 && (!showPulse || !isActive)

    return (
        <LemonButton
            ref={ref}
            icon={<IconTarget />}
            size="small"
            type="secondary"
            onClick={onClick}
            active={isActive}
            data-attr="global-product-setup-button"
            sideIcon={
                showIndicator ? (
                    showPulse ? (
                        <span className="relative flex h-3 w-3">
                            <span className="absolute inline-flex h-full w-full rounded-full bg-danger animate-ping opacity-75" />
                            <span className="relative inline-flex h-3 w-3 rounded-full bg-danger" />
                        </span>
                    ) : (
                        <LemonBadge.Number count={remainingCount} status="warning" size="small" />
                    )
                ) : undefined
            }
        >
            Quick start
        </LemonButton>
    )
})
