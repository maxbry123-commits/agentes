import {
    ChainedCommands as EditorCommands,
    FocusPosition as EditorFocusPosition,
    Range as EditorRange,
    JSONContent as TTJSONContent,
} from '@tiptap/core'
import { Node as PMNode } from '@tiptap/pm/model'

export interface RichContentNode extends PMNode {}
export interface JSONContent extends TTJSONContent {}

export type {
    ChainedCommands as EditorCommands,
    FocusPosition as EditorFocusPosition,
    Range as EditorRange,
    Editor as TTEditor,
} from '@tiptap/core'

export enum RichContentNodeType {
    Mention = 'ph-mention',
}

declare module '@tiptap/core' {
    interface NodeConfig {
        /** Plain-text serialization of a custom node, used when extracting text content. */
        serializedText: (attrs: Record<string, any>) => string
    }
}

export interface RichContentEditorType {
    isEmpty: () => boolean
    getJSON: () => JSONContent
    getEndPosition: () => number
    getSelectedNode: () => RichContentNode | null
    getCurrentPosition: () => number
    getAdjacentNodes: (pos: number) => { previous: RichContentNode | null; next: RichContentNode | null }
    setEditable: (editable: boolean) => void
    setContent: (content: JSONContent | string) => void
    setSelection: (position: number) => void
    setTextSelection: (position: number | EditorRange) => void
    focus: (position?: EditorFocusPosition) => void
    chain: () => EditorCommands
    destroy: () => void
    getMarks: (type: string) => { id: string; pos: number }[]
    getAttributes: (typeOrName: string) => Record<string, any>
    setMark: (id: string) => void
    getMentions: () => number[]
    isActive: (name: string, attributes?: {}) => boolean
    isSelectionFullyWithinSingleMark: (markName: string) => boolean
    deleteRange: (range: EditorRange) => EditorCommands
    insertContent: (content: JSONContent) => void
    insertContentAt: (position: number, content: JSONContent) => void
    insertContentAfterNode: (position: number, content: JSONContent) => void
    pasteContent: (position: number, text: string) => void
    findNode: (position: number) => RichContentNode | null
    findNodePositionByAttrs: (attrs: Record<string, any>) => any
    nextNode: (position: number) => { node: RichContentNode; position: number } | null
    hasChildOfType: (node: RichContentNode, type: string) => boolean
    scrollToSelection: () => void
    scrollToPosition: (position: number) => void
    clear: () => void
}
