import { Menu } from '@base-ui/react/menu'
import { useActions, useValues } from 'kea'

import {
    IconDatabase,
    IconGear,
    IconLeave,
    IconPeople,
    IconPlusSmall,
    IconReceipt,
    IconServer,
    IconShieldLock,
    IconToggle,
} from '@posthog/icons'

import { FEATURE_FLAGS } from 'lib/constants'
import { Link } from 'lib/lemon-ui/Link/Link'
import { ProfilePicture } from 'lib/lemon-ui/ProfilePicture/ProfilePicture'
import { UploadedLogo } from 'lib/lemon-ui/UploadedLogo/UploadedLogo'
import { featureFlagLogic } from 'lib/logic/featureFlagLogic'
import { preflightLogic } from 'lib/logic/preflightLogic'
import { ButtonPrimitive } from 'lib/ui/Button/ButtonPrimitives'
import { DropdownMenuSeparator } from 'lib/ui/DropdownMenu/DropdownMenu'
import { Label } from 'lib/ui/Label/Label'
import { MenuOpenIndicator } from 'lib/ui/Menus/Menus'
import { cn } from 'lib/utils/css-classes'
import { eventUsageLogic } from 'lib/utils/eventUsageLogic'
import { billingLogic } from 'scenes/billing/billingLogic'
import { organizationLogic } from 'scenes/organizationLogic'
import { inviteLogic } from 'scenes/settings/organization/inviteLogic'
import { isAuthenticatedTeam, teamLogic } from 'scenes/teamLogic'
import { urls } from 'scenes/urls'
import { userLogic } from 'scenes/userLogic'

import { globalModalsLogic } from '~/layout/globalModalsLogic'
import { AvailableFeature } from '~/types'

import { ScrollableShadows } from '../ScrollableShadows/ScrollableShadows'
import { RenderKeybind } from '../Shortcuts/ShortcutMenu'
import { keyBinds } from '../Shortcuts/shortcuts'
import { upgradeModalLogic } from '../UpgradeModal/upgradeModalLogic'
import { newAccountMenuLogic } from './newAccountMenuLogic'
import { OrgModal } from './OrgModal'
import { OrgSwitcher } from './OrgSwitcher'
import { pendingInvitesLogic } from './pendingInvitesLogic'
import { PendingInviteDot } from './ProjectMenu'
import { ProjectModal } from './ProjectModal'
import { ProjectSwitcher } from './ProjectSwitcher'

interface AccountMenuProps {
    isLayoutNavCollapsed: boolean
}

export function NewAccountMenu({ isLayoutNavCollapsed }: AccountMenuProps): JSX.Element {
    const { user } = useValues(userLogic)
    const { isCloudOrDev } = useValues(preflightLogic)
    const { featureFlags } = useValues(featureFlagLogic)
    const { showInviteModal } = useActions(inviteLogic)
    const { reportInviteMembersButtonClicked } = useActions(eventUsageLogic)
    const { logout } = useActions(userLogic)
    const { currentTeam } = useValues(teamLogic)
    const { isAccountMenuOpen } = useValues(newAccountMenuLogic)
    const { setAccountMenuOpen } = useActions(newAccountMenuLogic)
    const { pendingInvites } = useValues(pendingInvitesLogic)
    const hasPendingInvites = pendingInvites.length > 0
    const { preflight } = useValues(preflightLogic)
    const { currentOrganization } = useValues(organizationLogic)
    const { billingEntryUrl } = useValues(billingLogic)
    const { guardAvailableFeature } = useValues(upgradeModalLogic)
    const { showCreateProjectModal } = useActions(globalModalsLogic)
    const { showCreateOrganizationModal } = useActions(globalModalsLogic)

    const projectNameStartsWithEmoji = currentTeam?.name?.match(/^\p{Extended_Pictographic}/u) !== null
    const projectNameWithoutFirstEmoji = projectNameStartsWithEmoji
        ? currentTeam?.name?.replace(/^\p{Extended_Pictographic}/u, '').trimStart()
        : currentTeam?.name

    return (
        <>
            <Menu.Root open={isAccountMenuOpen} onOpenChange={setAccountMenuOpen}>
                <Menu.Trigger
                    render={(props) => (
                        <ButtonPrimitive
                            {...props}
                            iconOnly={isLayoutNavCollapsed}
                            className={cn('relative flex-1 py-1 min-w-0 group', {
                                'pl-[3px] gap-[6px]': !isLayoutNavCollapsed,
                            })}
                            data-attr="new-account-menu-button"
                            tooltip={
                                <div className="flex flex-col gap-1">
                                    <div>
                                        Account menu
                                        <RenderKeybind keybind={[keyBinds.newAccountMenu]} className="ml-1" />
                                    </div>
                                    <div>
                                        Organization:{' '}
                                        {currentOrganization ? currentOrganization.name : 'Select organization'}
                                    </div>
                                    <div>Project: {currentTeam ? currentTeam.name : 'Select project'}</div>
                                    {hasPendingInvites && <div>You have a pending invitation</div>}
                                </div>
                            }
                        >
                            {currentOrganization ? (
                                <UploadedLogo
                                    name={currentOrganization.name}
                                    entityId={currentOrganization.id}
                                    mediaId={currentOrganization.logo_media_id}
                                    size="small"
                                />
                            ) : (
                                <UploadedLogo name="?" entityId="" mediaId="" size="xsmall" />
                            )}
                            {!isLayoutNavCollapsed && (
                                <span className="truncate text-secondary group-hover:text-primary">
                                    {isAuthenticatedTeam(currentTeam)
                                        ? (projectNameWithoutFirstEmoji ?? 'Project')
                                        : 'Account menu'}
                                </span>
                            )}
                            {hasPendingInvites && (
                                <PendingInviteDot
                                    className={isLayoutNavCollapsed ? 'absolute top-0.5 right-0.5' : 'mr-0.5'}
                                />
                            )}
                        </ButtonPrimitive>
                    )}
                />

                <Menu.Portal>
                    <Menu.Backdrop className="fixed inset-0 z-[var(--z-modal)]" />

                    <Menu.Positioner className="z-[var(--z-popover)]" sideOffset={4}>
                        <Menu.Popup className="primitive-menu-content max-h-[calc(var(--available-height)-4px)] min-w-[250px] w-full">
                            <ScrollableShadows
                                direction="vertical"
                                styledScrollbars
                                className="flex flex-col gap-px overflow-x-hidden"
                                innerClassName="primitive-menu-content-inner p-1 "
                            >
                                <Label intent="menu" className="pl-2 relative">
                                    Project
                                    {preflight?.can_create_org && (
                                        <ButtonPrimitive
                                            iconOnly
                                            tooltip="Create a new project"
                                            size="xs"
                                            className="absolute -right-[2px] -top-[2px]"
                                            data-attr="new-account-menu-create-project-icon-button"
                                            onClick={() => {
                                                guardAvailableFeature(
                                                    AvailableFeature.ORGANIZATIONS_PROJECTS,
                                                    () => {
                                                        setAccountMenuOpen(false)
                                                        showCreateProjectModal()
                                                    },
                                                    { currentUsage: currentOrganization?.teams?.length }
                                                )
                                            }}
                                        >
                                            <IconPlusSmall className="text-tertiary size-4" />
                                        </ButtonPrimitive>
                                    )}
                                </Label>
                                <DropdownMenuSeparator />

                                {isAuthenticatedTeam(currentTeam) && (
                                    <Menu.SubmenuRoot>
                                        <Menu.SubmenuTrigger
                                            openOnHover={false}
                                            render={
                                                <ButtonPrimitive
                                                    menuItem
                                                    data-attr="new-account-menu-all-projects-button"
                                                >
                                                    <div className="Lettermark bg-[var(--color-bg-fill-button-tertiary-active)] size-4 dark:text-tertiary text-[8px]">
                                                        {String.fromCodePoint(
                                                            currentTeam.name.codePointAt(0)!
                                                        ).toLocaleUpperCase()}
                                                    </div>
                                                    <span className="truncate font-semibold">
                                                        {currentTeam ? projectNameWithoutFirstEmoji : 'Select project'}
                                                    </span>
                                                    {hasPendingInvites && <PendingInviteDot className="mr-0.5" />}
                                                    <MenuOpenIndicator intent="sub" className="ml-auto" />
                                                </ButtonPrimitive>
                                            }
                                        />
                                        <Menu.Portal>
                                            <Menu.Positioner
                                                className="z-[var(--z-popover)]"
                                                collisionPadding={{ top: 50, bottom: 50 }}
                                            >
                                                <Menu.Popup className="primitive-menu-content w-min max-w-[var(--available-width)]">
                                                    {/* We need to add a div here to prevent the keydown event from bubbling up to the menu. */}
                                                    <div onKeyDown={(e) => e.stopPropagation()}>
                                                        <ProjectSwitcher dialog={false} />
                                                    </div>
                                                </Menu.Popup>
                                            </Menu.Positioner>
                                        </Menu.Portal>
                                    </Menu.SubmenuRoot>
                                )}

                                <Menu.Item
                                    onClick={() => {
                                        showInviteModal()
                                        reportInviteMembersButtonClicked()
                                    }}
                                    render={
                                        <ButtonPrimitive
                                            menuItem
                                            tooltip="Invite members"
                                            tooltipPlacement="right"
                                            data-attr="new-account-menu-invite-team-members-button"
                                        >
                                            <IconPlusSmall />
                                            Invite members
                                        </ButtonPrimitive>
                                    }
                                />

                                {currentTeam && (
                                    <Menu.Item
                                        render={
                                            <Link
                                                buttonProps={{
                                                    menuItem: true,
                                                }}
                                                tooltip="Project settings"
                                                tooltipPlacement="right"
                                                data-attr="new-account-menu-project-settings-button"
                                                to={urls.project(currentTeam.id, urls.settings('project'))}
                                            >
                                                <IconGear />
                                                Project settings
                                            </Link>
                                        }
                                    />
                                )}

                                <Label intent="menu" className="px-2 mt-2 relative">
                                    Organization
                                    {preflight?.can_create_org && (
                                        <ButtonPrimitive
                                            iconOnly
                                            tooltip="Create a new organization"
                                            size="xs"
                                            className="absolute right-0 -top-1 p-0"
                                            data-attr="new-account-menu-create-organization-icon-button"
                                            onClick={() => {
                                                guardAvailableFeature(
                                                    AvailableFeature.ORGANIZATIONS_PROJECTS,
                                                    () => {
                                                        setAccountMenuOpen(false)
                                                        showCreateOrganizationModal()
                                                    },
                                                    { guardOnCloud: false }
                                                )
                                            }}
                                        >
                                            <IconPlusSmall className="text-tertiary size-4" />
                                        </ButtonPrimitive>
                                    )}
                                </Label>
                                <DropdownMenuSeparator />
                                <Menu.SubmenuRoot>
                                    <Menu.SubmenuTrigger
                                        openOnHover={false}
                                        render={
                                            <ButtonPrimitive
                                                menuItem
                                                data-attr="new-account-menu-all-organizations-button"
                                            >
                                                {currentOrganization ? (
                                                    <UploadedLogo
                                                        name={currentOrganization.name}
                                                        entityId={currentOrganization.id}
                                                        mediaId={currentOrganization.logo_media_id}
                                                        size="xsmall"
                                                    />
                                                ) : (
                                                    <UploadedLogo name="?" entityId="" mediaId="" size="xsmall" />
                                                )}
                                                <span className="truncate font-semibold">
                                                    {currentOrganization
                                                        ? currentOrganization.name
                                                        : 'Select organization'}
                                                </span>
                                                <MenuOpenIndicator intent="sub" className="ml-auto" />
                                            </ButtonPrimitive>
                                        }
                                    />
                                    <Menu.Portal>
                                        <Menu.Positioner
                                            className="z-[var(--z-popover)]"
                                            collisionPadding={{ top: 50, bottom: 50 }}
                                        >
                                            <Menu.Popup className="primitive-menu-content w-min max-w-[var(--available-width)]">
                                                {/* We need to add a div here to prevent the keydown event from bubbling up to the menu. */}
                                                <div onKeyDown={(e) => e.stopPropagation()}>
                                                    <OrgSwitcher dialog={false} />
                                                </div>
                                            </Menu.Popup>
                                        </Menu.Positioner>
                                    </Menu.Portal>
                                </Menu.SubmenuRoot>

                                {isCloudOrDev && billingEntryUrl ? (
                                    <Menu.Item
                                        render={(props) => (
                                            <Link
                                                {...props}
                                                to={billingEntryUrl}
                                                buttonProps={{
                                                    className: 'flex items-center gap-2',
                                                    menuItem: true,
                                                    truncate: true,
                                                }}
                                            >
                                                <IconReceipt />
                                                {featureFlags[FEATURE_FLAGS.USAGE_SPEND_DASHBOARDS]
                                                    ? 'Billing & usage'
                                                    : 'Billing'}
                                            </Link>
                                        )}
                                    />
                                ) : null}

                                <Menu.Item
                                    render={(props) => (
                                        <Link
                                            {...props}
                                            to={urls.settings('organization')}
                                            buttonProps={{
                                                menuItem: true,
                                            }}
                                            tooltip="Organization settings"
                                            tooltipPlacement="right"
                                            data-attr="new-account-menu-organization-settings-button"
                                        >
                                            <IconGear />
                                            Organization settings
                                        </Link>
                                    )}
                                />

                                {user?.is_staff && (
                                    <>
                                        <Label intent="menu" className="px-2 mt-2">
                                            Staff
                                        </Label>
                                        <DropdownMenuSeparator />
                                        <Menu.Item
                                            render={(props) => (
                                                <Link
                                                    {...props}
                                                    to="/admin/"
                                                    buttonProps={{
                                                        menuItem: true,
                                                    }}
                                                    data-attr="new-account-menu-django-admin"
                                                    disableClientSideRouting
                                                >
                                                    <IconShieldLock />
                                                    Django admin
                                                </Link>
                                            )}
                                        />
                                        <Menu.Item
                                            render={(props) => (
                                                <Link
                                                    {...props}
                                                    to={urls.instanceStatus()}
                                                    buttonProps={{
                                                        menuItem: true,
                                                    }}
                                                    data-attr="new-account-menu-instance-panel"
                                                >
                                                    <IconServer />
                                                    Instance panel
                                                </Link>
                                            )}
                                        />
                                        <Menu.Item
                                            render={(props) => (
                                                <Link
                                                    {...props}
                                                    to={urls.featureFlagsStaffTools()}
                                                    buttonProps={{
                                                        menuItem: true,
                                                    }}
                                                    data-attr="new-account-menu-flags-staff-tools"
                                                >
                                                    <IconToggle />
                                                    Flags staff tools
                                                </Link>
                                            )}
                                        />
                                        <Menu.Item
                                            render={(props) => (
                                                <Link
                                                    {...props}
                                                    to={urls.cohortsStaffTools()}
                                                    buttonProps={{
                                                        menuItem: true,
                                                    }}
                                                    data-attr="new-account-menu-cohorts-staff-tools"
                                                >
                                                    <IconPeople />
                                                    Cohorts staff tools
                                                </Link>
                                            )}
                                        />
                                        <Menu.Item
                                            render={(props) => (
                                                <Link
                                                    {...props}
                                                    to={urls.experimentsStaffTools()}
                                                    buttonProps={{
                                                        menuItem: true,
                                                    }}
                                                    // Stable autocapture contract: name stays query-performance even though the label and route are now experiments staff tools
                                                    data-attr="new-account-menu-query-performance"
                                                >
                                                    <IconDatabase />
                                                    Experiments staff tools
                                                </Link>
                                            )}
                                        />
                                    </>
                                )}

                                <Label intent="menu" className="px-2 mt-2">
                                    Account
                                </Label>
                                <DropdownMenuSeparator />
                                <Menu.Item
                                    render={(props) => (
                                        <Link
                                            {...props}
                                            to={urls.settings(user?.organization?.id ? 'user' : 'user-danger-zone')}
                                            buttonProps={{
                                                className: 'flex items-center gap-2 h-fit',
                                                menuItem: true,
                                                truncate: true,
                                            }}
                                            tooltip="User settings"
                                            tooltipPlacement="right"
                                            data-attr="new-account-menu-account-owner-button"
                                        >
                                            <ProfilePicture user={user} size="xs" />
                                            <span className="flex flex-col truncate">
                                                <span className="font-semibold truncate">{user?.first_name}</span>
                                                <span className="text-tertiary text-xs truncate">{user?.email}</span>
                                            </span>
                                        </Link>
                                    )}
                                />

                                <Menu.Item
                                    onClick={() => logout()}
                                    render={
                                        <ButtonPrimitive menuItem data-attr="new-account-menu-logout-button">
                                            <IconLeave />
                                            Log out
                                        </ButtonPrimitive>
                                    }
                                />
                            </ScrollableShadows>
                        </Menu.Popup>
                    </Menu.Positioner>
                </Menu.Portal>
            </Menu.Root>

            <ProjectModal />
            <OrgModal />
        </>
    )
}
