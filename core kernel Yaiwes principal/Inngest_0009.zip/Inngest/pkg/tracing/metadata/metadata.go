package metadata

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"maps"

	"github.com/99designs/gqlgen/graphql"
	"github.com/inngest/inngest/pkg/enums"
)

var (
	ErrMetadataSpanTooLarge    = errors.New("metadata span exceeds maximum size")
	ErrRunMetadataSizeExceeded = errors.New("run cumulative metadata size exceeded")
	ErrScoreNameInvalid        = errors.New("score name contains invalid characters")
	ErrScoreNameTooLong        = errors.New("score name exceeds maximum length")
	ErrScoreValueInvalid       = errors.New("score value must be a finite number or boolean")
)

type Opcode = enums.MetadataOpcode

type Scope = enums.MetadataScope

type Structured interface {
	Kind() Kind
	Serialize() (Values, error)

	Op() enums.MetadataOpcode
}

type Values map[string]json.RawMessage

var _ graphql.ContextMarshaler = Values(nil)
var _ graphql.ContextUnmarshaler = (*Values)(nil)

func (m Values) MarshalGQLContext(ctx context.Context, w io.Writer) error {
	return json.NewEncoder(w).Encode(m)
}

func (m *Values) UnmarshalGQLContext(ctx context.Context, v any) error {
	vm, ok := v.(map[string]any)
	if !ok {
		return fmt.Errorf("cannot unmarshal %T as RawMetadata", v)
	}

	clear(*m)
	for k, v := range vm {
		var err error
		(*m)[k], err = json.Marshal(v)
		if err != nil {
			return err
		}
	}

	return nil
}

func (m *Values) FromStruct(v any) error {
	// TODO: reflect stuff so we don't need to remarshal?
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}

	return json.Unmarshal(data, m)
}

func (m Values) Combine(o Values, op enums.MetadataOpcode) error {
	switch op {
	case enums.MetadataOpcodeMerge:
		maps.Copy(m, o)
		return nil
	case enums.MetadataOpcodeDelete:
		for k := range o {
			delete(m, k)
		}
		return nil
	case enums.MetadataOpcodeAdd:
		for k := range o {
			var a float64
			if err := json.Unmarshal(m[k], &a); err != nil {
				m[k] = o[k]
				continue
			}

			var b float64
			if err := json.Unmarshal(o[k], &b); err != nil {
				continue
			}

			m[k], _ = json.Marshal(a + b)
		}
		return nil
	case enums.MetadataOpcodeSet:
		clear(m)
		maps.Copy(m, o)
		return nil
	default:
		return fmt.Errorf("unrecognized op %q", op)
	}
}

// Size returns the sum of key lengths and raw JSON value byte lengths.
// Map overhead is excluded; this is intended as an approximate cost metric.
func (m Values) Size() int {
	total := 0
	for k, val := range m {
		total += len(k) + len(val)
	}
	return total
}

type RawUpdate struct {
	Kind   Kind   `json:"kind"`
	Op     Opcode `json:"op"`
	Values Values `json:"values"`
}

type ScopedUpdate struct {
	Scope Scope `json:"scope"`
	Update
}

type Update struct {
	RawUpdate
}

func (m Update) Kind() Kind {
	return m.RawUpdate.Kind
}

func (m Update) Op() Opcode {
	return m.RawUpdate.Op
}

func (m Update) Serialize() (Values, error) {
	return m.RawUpdate.Values, nil
}

func (m Update) validate() error {
	if err := m.RawUpdate.Kind.Validate(); err != nil {
		return fmt.Errorf("invalid kind: %w", err)
	}

	return nil
}

// ValidateAllowed checks generic shape, reserved kind allowlists, and reserved
// value formats.
func (m Update) ValidateAllowed() error {
	if err := m.validate(); err != nil {
		return err
	}

	if err := m.Kind().ValidateAllowed(); err != nil {
		return err
	}

	switch m.Kind() {
	case KindInngestScore:
		if err := validateNamedScoreValue(m.Values); err != nil {
			return err
		}
	}

	return nil
}

// ValidateUpdatesAllowed applies reserved-kind rules to each update.
func ValidateUpdatesAllowed(updates []Update) error {
	for _, update := range updates {
		if err := update.ValidateAllowed(); err != nil {
			return err
		}
	}

	return nil
}
