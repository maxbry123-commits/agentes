/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.optimize.service.util.configuration.security;

import java.util.Objects;

public class CCSMAuthConfiguration {

  // the url to Identity
  private String issuerUrl;
  // the url to Identity (back channel for container to container communication)
  private String issuerBackendUrl;
  // the redirect root url back to Optimize. If not provided, Optimize uses the container url
  private String redirectRootUrl;
  // Identity client id to use by Optimize
  private String clientId;
  // Identity client secret to use by Optimize
  private String clientSecret;
  // Identity audience
  private String audience;
  private String baseUrl;
  // When true, enables detailed DEBUG/WARN logging for OIDC redirect flows to diagnose
  // reverse-proxy misconfigurations (forwarded-header mismatches, session-cookie issues).
  // Defaults to false — only enable temporarily during troubleshooting.
  private boolean diagnosticsEnabled = false;
  // When true, rejects Microsoft Entra access tokens whose `ver` claim is not "2.0".
  // Defaults to true. Set to false as a last-resort escape hatch if a deployment is stuck
  // on v1.0 tokens and cannot immediately update the Azure app registration.
  private boolean entraTokenVersionCheckEnabled = true;

  public CCSMAuthConfiguration() {}

  public String getIssuerUrl() {
    return issuerUrl;
  }

  public void setIssuerUrl(final String issuerUrl) {
    this.issuerUrl = issuerUrl;
  }

  public String getIssuerBackendUrl() {
    return issuerBackendUrl;
  }

  public void setIssuerBackendUrl(final String issuerBackendUrl) {
    this.issuerBackendUrl = issuerBackendUrl;
  }

  public String getRedirectRootUrl() {
    return redirectRootUrl;
  }

  public void setRedirectRootUrl(final String redirectRootUrl) {
    this.redirectRootUrl = redirectRootUrl;
  }

  public String getClientId() {
    return clientId;
  }

  public void setClientId(final String clientId) {
    this.clientId = clientId;
  }

  public String getClientSecret() {
    return clientSecret;
  }

  public void setClientSecret(final String clientSecret) {
    this.clientSecret = clientSecret;
  }

  public String getAudience() {
    return audience;
  }

  public void setAudience(final String audience) {
    this.audience = audience;
  }

  public String getBaseUrl() {
    return baseUrl;
  }

  public void setBaseUrl(final String baseUrl) {
    this.baseUrl = baseUrl;
  }

  public boolean isDiagnosticsEnabled() {
    return diagnosticsEnabled;
  }

  public void setDiagnosticsEnabled(final boolean diagnosticsEnabled) {
    this.diagnosticsEnabled = diagnosticsEnabled;
  }

  public boolean isEntraTokenVersionCheckEnabled() {
    return entraTokenVersionCheckEnabled;
  }

  public void setEntraTokenVersionCheckEnabled(final boolean entraTokenVersionCheckEnabled) {
    this.entraTokenVersionCheckEnabled = entraTokenVersionCheckEnabled;
  }

  protected boolean canEqual(final Object other) {
    return other instanceof CCSMAuthConfiguration;
  }

  @Override
  public boolean equals(final Object o) {
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    final CCSMAuthConfiguration that = (CCSMAuthConfiguration) o;
    return Objects.equals(issuerUrl, that.issuerUrl)
        && Objects.equals(issuerBackendUrl, that.issuerBackendUrl)
        && Objects.equals(redirectRootUrl, that.redirectRootUrl)
        && Objects.equals(clientId, that.clientId)
        && Objects.equals(clientSecret, that.clientSecret)
        && Objects.equals(audience, that.audience)
        && Objects.equals(baseUrl, that.baseUrl)
        && diagnosticsEnabled == that.diagnosticsEnabled
        && entraTokenVersionCheckEnabled == that.entraTokenVersionCheckEnabled;
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        issuerUrl,
        issuerBackendUrl,
        redirectRootUrl,
        clientId,
        clientSecret,
        audience,
        baseUrl,
        diagnosticsEnabled,
        entraTokenVersionCheckEnabled);
  }

  @Override
  public String toString() {
    return "CCSMAuthConfiguration(issuerUrl="
        + getIssuerUrl()
        + ", issuerBackendUrl="
        + getIssuerBackendUrl()
        + ", redirectRootUrl="
        + getRedirectRootUrl()
        + ", clientId="
        + getClientId()
        + ", clientSecret="
        + getClientSecret()
        + ", audience="
        + getAudience()
        + ", baseUrl="
        + getBaseUrl()
        + ", diagnosticsEnabled="
        + isDiagnosticsEnabled()
        + ", entraTokenVersionCheckEnabled="
        + isEntraTokenVersionCheckEnabled()
        + ")";
  }
}
