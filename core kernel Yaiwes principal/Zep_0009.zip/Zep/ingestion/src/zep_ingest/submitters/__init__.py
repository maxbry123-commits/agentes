"""Submitters and the method="auto" dispatch."""

import logging
from collections.abc import Iterable
from itertools import chain
from typing import Any, Literal

from zep_cloud.client import Zep

from zep_ingest._validation import require_int_range, require_nonnegative_number
from zep_ingest.exceptions import ConfigurationError
from zep_ingest.result import IngestResult
from zep_ingest.submitters.batch import BatchSubmitter, is_batch_unavailable, require_batch_id
from zep_ingest.submitters.sequential import SequentialSubmitter, call_with_retries
from zep_ingest.types import (
    DEFAULT_ITEMS_PER_BATCH,
    MAX_ITEMS_PER_ADD,
    MAX_ITEMS_PER_BATCH,
    Destination,
    Episode,
)

logger = logging.getLogger("zep_ingest")

Method = Literal["auto", "batch", "sequential"]

__all__ = ["BatchSubmitter", "Method", "SequentialSubmitter", "submit_episodes"]


def submit_episodes(
    client: Zep,
    episodes: Iterable[Episode],
    destination: Destination,
    *,
    method: Method = "auto",
    page_size: int = MAX_ITEMS_PER_ADD,
    max_items_per_batch: int = DEFAULT_ITEMS_PER_BATCH,
    batch_metadata: dict[str, Any] | None = None,
    max_add_retries: int = 3,
    max_retries: int = 5,
    min_interval: float = 0.0,
) -> IngestResult:
    """Submit an episode stream via the requested method.

    method="auto" uses the Batch API when this deployment serves it and falls
    back to sequential graph.add ingestion when it does not; no episodes are
    lost on fallback. Any other failure is raised, not worked around.
    """
    if method not in ("auto", "batch", "sequential"):
        raise ConfigurationError(
            f"method must be one of ['auto', 'batch', 'sequential'], got {method!r}"
        )
    require_int_range("page_size", page_size, minimum=1, maximum=MAX_ITEMS_PER_ADD)
    require_int_range(
        "max_items_per_batch",
        max_items_per_batch,
        minimum=page_size,
        maximum=MAX_ITEMS_PER_BATCH,
    )
    require_int_range("max_add_retries", max_add_retries, minimum=1)
    require_int_range("max_retries", max_retries, minimum=1)
    require_nonnegative_number("min_interval", min_interval)

    if method == "sequential":
        return SequentialSubmitter(
            client, max_retries=max_retries, min_interval=min_interval
        ).submit(episodes, destination)

    batch_kwargs: dict[str, Any] = {
        "page_size": page_size,
        "max_items_per_batch": max_items_per_batch,
        "batch_metadata": batch_metadata,
        "max_add_retries": max_add_retries,
    }
    if method == "batch":
        return BatchSubmitter(client, **batch_kwargs).submit(episodes, destination)

    # method == "auto": probe batch availability with the real batch.create,
    # then hand the (untouched) stream to the chosen submitter. The probe is
    # retried on transient errors (429/5xx) like every other batch call, so a
    # momentary blip can't crash the run or wrongly trip the sequential
    # fallback — only a deployment that does not serve the endpoint does that.
    # Every other error, transient or not, is re-raised rather than silently
    # downgraded to sequential, which would hit the same wall one item at a time.
    iterator = iter(episodes)
    try:
        first = next(iterator)
    except StopIteration:
        return IngestResult(method="sequential", client=client)
    stream = chain([first], iterator)

    def create_probe_batch() -> Any:
        if batch_metadata is not None:
            return client.batch.create(metadata=batch_metadata)
        return client.batch.create()

    summary, error = call_with_retries(create_probe_batch, max_retries=max_add_retries)
    if error is not None:
        if is_batch_unavailable(error):
            notice = (
                "Zep Batch API not available on this deployment — "
                "falling back to sequential graph.add ingestion."
            )
            logger.info(notice)
            result = SequentialSubmitter(
                client, max_retries=max_retries, min_interval=min_interval
            ).submit(stream, destination)
            result.warnings.insert(0, notice)
            return result
        raise error
    batch_id = require_batch_id(getattr(summary, "batch_id", None))
    return BatchSubmitter(client, initial_batch_id=batch_id, **batch_kwargs).submit(
        stream, destination
    )
