// Vitest extension signal config wires the extension signal test shard.
import { createSingleChannelExtensionVitestConfig } from "./vitest.extension-config.ts";

export function createExtensionSignalVitestConfig(
  env: Record<string, string | undefined> = process.env,
) {
  return createSingleChannelExtensionVitestConfig("signal", env);
}

export default createExtensionSignalVitestConfig();
