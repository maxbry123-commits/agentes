// Test routing roots for miscellaneous messaging extension suites.
import { bundledPluginRoot } from "../../scripts/lib/bundled-plugin-paths.mjs";

const messagingExtensionIds = [
  "googlechat",
  "nextcloud-talk",
  "nostr",
  "synology-chat",
  "tlon",
  "twitch",
];

export const messagingExtensionTestRoots = messagingExtensionIds.map((id) => bundledPluginRoot(id));

export function isMessagingExtensionRoot(root) {
  return messagingExtensionTestRoots.includes(root);
}
