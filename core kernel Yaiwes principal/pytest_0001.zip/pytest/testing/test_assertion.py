# mypy: allow-untyped-defs
from __future__ import annotations

from collections.abc import Iterator
from collections.abc import Mapping
from collections.abc import MutableSequence
import dataclasses
import sys
import textwrap
from typing import Any
from typing import Literal
from typing import NamedTuple

import attr

from _pytest import outcomes
import _pytest.assertion as plugin
from _pytest.assertion import truncate
from _pytest.assertion import util
from _pytest.assertion._compare_any import _compare_eq_cls
from _pytest.assertion._compare_mapping import _compare_eq_mapping
from _pytest.assertion._typing import _AssertionTextDiffStyle
from _pytest.assertion._typing import NO_TRUNCATION_BUDGET
from _pytest.assertion._typing import TruncationBudget
from _pytest.assertion.compare_text import _compare_eq_text
from _pytest.assertion.compare_text import _notin_text
from _pytest.config import Config as _Config
from _pytest.monkeypatch import MonkeyPatch
from _pytest.pytester import Pytester
import pytest


def mock_config(
    verbose: int = 0,
    assertion_override: int | None = None,
    assertion_text_diff_style: _AssertionTextDiffStyle = "ndiff",
    truncation_limit_lines: str = "0",
    truncation_limit_chars: str = "0",
    has_terminalreporter: bool = True,
):
    class TerminalWriter:
        def _highlight(self, source, lexer="python"):
            return source

    class PluginManager:
        def has_plugin(self, name: str) -> bool:
            return has_terminalreporter

    class Config:
        pluginmanager = PluginManager()

        def get_terminal_writer(self):
            # When the terminalreporter plugin is absent the dispatcher must
            # fall back to the plaintext highlighter without reaching for a
            # terminal writer (#14377); make that misuse fail loudly.
            assert has_terminalreporter, (
                "get_terminal_writer() must not be called without terminalreporter"
            )
            return TerminalWriter()

        def get_verbosity(self, verbosity_type: str | None = None) -> int:
            if verbosity_type is None:
                return verbose
            if verbosity_type == _Config.VERBOSITY_ASSERTIONS:
                if assertion_override is not None:
                    return assertion_override
                return verbose

            raise KeyError(f"Not mocked out: {verbosity_type}")

        def getini(self, name: str) -> str:
            if name == "assertion_text_diff_style":
                return assertion_text_diff_style
            # Truncation defaults to disabled (``"0"``) so ``callop``-style
            # tests can compare against the full explanation; the dispatcher
            # tests pass explicit limits to exercise the budget wiring.
            if name == "truncation_limit_lines":
                return truncation_limit_lines
            if name == "truncation_limit_chars":
                return truncation_limit_chars
            raise KeyError(f"Not mocked out: {name}")

    return Config()


class TestMockConfig:
    SOME_VERBOSITY_LEVEL = 3
    SOME_OTHER_VERBOSITY_LEVEL = 10

    def test_verbose_exposes_value(self):
        config = mock_config(verbose=TestMockConfig.SOME_VERBOSITY_LEVEL)

        assert config.get_verbosity() == TestMockConfig.SOME_VERBOSITY_LEVEL

    def test_get_assertion_override_not_set_verbose_value(self):
        config = mock_config(verbose=TestMockConfig.SOME_VERBOSITY_LEVEL)

        assert (
            config.get_verbosity(_Config.VERBOSITY_ASSERTIONS)
            == TestMockConfig.SOME_VERBOSITY_LEVEL
        )

    def test_get_assertion_override_set_custom_value(self):
        config = mock_config(
            verbose=TestMockConfig.SOME_VERBOSITY_LEVEL,
            assertion_override=TestMockConfig.SOME_OTHER_VERBOSITY_LEVEL,
        )

        assert (
            config.get_verbosity(_Config.VERBOSITY_ASSERTIONS)
            == TestMockConfig.SOME_OTHER_VERBOSITY_LEVEL
        )

    def test_get_unsupported_type_error(self):
        config = mock_config(verbose=TestMockConfig.SOME_VERBOSITY_LEVEL)

        with pytest.raises(KeyError):
            config.get_verbosity("--- NOT A VERBOSITY LEVEL ---")

    def test_getini_unsupported_error(self):
        config = mock_config()

        with pytest.raises(KeyError, match="Not mocked out: --- NOT AN INI ---"):
            config.getini("--- NOT AN INI ---")


class TestImportHookInstallation:
    @pytest.mark.parametrize("initial_conftest", [True, False])
    @pytest.mark.parametrize("mode", ["plain", "rewrite"])
    def test_conftest_assertion_rewrite(
        self, pytester: Pytester, initial_conftest, mode
    ) -> None:
        """Test that conftest files are using assertion rewrite on import (#1619)."""
        pytester.mkdir("foo")
        pytester.mkdir("foo/tests")
        conftest_path = "conftest.py" if initial_conftest else "foo/conftest.py"
        contents = {
            conftest_path: """
                import pytest
                @pytest.fixture
                def check_first():
                    def check(values, value):
                        assert values.pop(0) == value
                    return check
            """,
            "foo/tests/test_foo.py": """
                def test(check_first):
                    check_first([10, 30], 30)
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.runpytest_subprocess(f"--assert={mode}")
        if mode == "plain":
            expected = "E       AssertionError"
        elif mode == "rewrite":
            expected = "*assert 10 == 30*"
        else:
            assert 0
        result.stdout.fnmatch_lines([expected])

    def test_rewrite_assertions_pytester_plugin(self, pytester: Pytester) -> None:
        """
        Assertions in the pytester plugin must also benefit from assertion
        rewriting (#1920).
        """
        pytester.makepyfile(
            """
            pytest_plugins = ['pytester']
            def test_dummy_failure(pytester):  # how meta!
                pytester.makepyfile('def test(): assert 0')
                r = pytester.inline_run()
                r.assertoutcome(passed=1)
        """
        )
        result = pytester.runpytest_subprocess()
        result.stdout.fnmatch_lines(
            [
                ">       r.assertoutcome(passed=1)",
                "E       AssertionError: ([[][]], [[][]], [[]<TestReport *>[]])*",
                "E       assert {'failed': 1,... 'skipped': 0} == {'failed': 0,... 'skipped': 0}",
                "E         Omitting 1 identical items, use -vv to show",
                "E         Differing items:",
                "E         Use -v to get more diff",
            ]
        )
        # XXX: unstable output.
        result.stdout.fnmatch_lines_random(
            [
                "E         {'failed': 1} != {'failed': 0}",
                "E         {'passed': 0} != {'passed': 1}",
            ]
        )

    @pytest.mark.parametrize("mode", ["plain", "rewrite"])
    def test_pytest_plugins_rewrite(self, pytester: Pytester, mode) -> None:
        contents = {
            "conftest.py": """
                pytest_plugins = ['ham']
            """,
            "ham.py": """
                import pytest
                @pytest.fixture
                def check_first():
                    def check(values, value):
                        assert values.pop(0) == value
                    return check
            """,
            "test_foo.py": """
                def test_foo(check_first):
                    check_first([10, 30], 30)
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.runpytest_subprocess(f"--assert={mode}")
        if mode == "plain":
            expected = "E       AssertionError"
        elif mode == "rewrite":
            expected = "*assert 10 == 30*"
        else:
            assert 0
        result.stdout.fnmatch_lines([expected])

    @pytest.mark.parametrize("mode", ["str", "list"])
    def test_pytest_plugins_rewrite_module_names(
        self, pytester: Pytester, mode
    ) -> None:
        """Test that pluginmanager correct marks pytest_plugins variables
        for assertion rewriting if they are defined as plain strings or
        list of strings (#1888).
        """
        plugins = '"ham"' if mode == "str" else '["ham"]'
        contents = {
            "conftest.py": f"""
                pytest_plugins = {plugins}
            """,
            "ham.py": """
                import pytest
            """,
            "test_foo.py": """
                def test_foo(pytestconfig):
                    assert 'ham' in pytestconfig.pluginmanager.rewrite_hook._must_rewrite
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.runpytest_subprocess("--assert=rewrite")
        assert result.ret == 0

    def test_pytest_plugins_rewrite_module_names_correctly(
        self, pytester: Pytester
    ) -> None:
        """Test that we match files correctly when they are marked for rewriting (#2939)."""
        contents = {
            "conftest.py": """\
                pytest_plugins = "ham"
            """,
            "ham.py": "",
            "hamster.py": "",
            "test_foo.py": """\
                def test_foo(pytestconfig):
                    assert pytestconfig.pluginmanager.rewrite_hook.find_spec('ham') is not None
                    assert pytestconfig.pluginmanager.rewrite_hook.find_spec('hamster') is None
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.runpytest_subprocess("--assert=rewrite")
        assert result.ret == 0

    @pytest.mark.parametrize("mode", ["plain", "rewrite"])
    @pytest.mark.parametrize("disable_plugin_autoload", ["env_var", "cli", ""])
    @pytest.mark.parametrize("explicit_specify", ["env_var", "cli", ""])
    def test_installed_plugin_rewrite(
        self,
        pytester: Pytester,
        mode: str,
        monkeypatch: pytest.MonkeyPatch,
        disable_plugin_autoload: str,
        explicit_specify: str,
    ) -> None:
        args = ["mainwrapper.py", "-s", f"--assert={mode}"]
        if disable_plugin_autoload == "env_var":
            monkeypatch.setenv("PYTEST_DISABLE_PLUGIN_AUTOLOAD", "1")
        elif disable_plugin_autoload == "cli":
            monkeypatch.delenv("PYTEST_DISABLE_PLUGIN_AUTOLOAD", raising=False)
            args.append("--disable-plugin-autoload")
        else:
            assert disable_plugin_autoload == ""
            monkeypatch.delenv("PYTEST_DISABLE_PLUGIN_AUTOLOAD", raising=False)

        name = "spamplugin"

        if explicit_specify == "env_var":
            monkeypatch.setenv("PYTEST_PLUGINS", name)
        elif explicit_specify == "cli":
            args.append("-p")
            args.append(name)
        else:
            assert explicit_specify == ""

        # Make sure the hook is installed early enough so that plugins
        # installed via distribution package are rewritten.
        pytester.mkdir("hampkg")
        contents = {
            "hampkg/__init__.py": """\
                import pytest

                @pytest.fixture
                def check_first2():
                    def check(values, value):
                        assert values.pop(0) == value
                    return check
            """,
            "spamplugin.py": """\
            import pytest
            from hampkg import check_first2

            @pytest.fixture
            def check_first():
                def check(values, value):
                    assert values.pop(0) == value
                return check
            """,
            "mainwrapper.py": """\
            import importlib.metadata
            import pytest

            class DummyEntryPoint(object):
                name = 'spamplugin'
                module_name = 'spam.py'
                group = 'pytest11'

                def load(self):
                    import spamplugin
                    return spamplugin

            class DummyDistInfo(object):
                version = '1.0'
                files = ('spamplugin.py', 'hampkg/__init__.py')
                entry_points = (DummyEntryPoint(),)
                metadata = {'name': 'foo'}

            def distributions():
                return (DummyDistInfo(),)

            importlib.metadata.distributions = distributions
            pytest.main()
            """,
            "test_foo.py": """\
            def test(check_first):
                check_first([10, 30], 30)

            def test2(check_first2):
                check_first2([10, 30], 30)
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.run(sys.executable, *args)
        if mode == "plain":
            expected = "E       AssertionError"
        elif mode == "rewrite":
            expected = "*assert 10 == 30*"
        else:
            assert 0

        if not disable_plugin_autoload or explicit_specify:
            result.assert_outcomes(failed=2)
            result.stdout.fnmatch_lines([expected, expected])
        else:
            result.assert_outcomes(errors=2)
            result.stdout.fnmatch_lines(
                [
                    "E       fixture 'check_first' not found",
                    "E       fixture 'check_first2' not found",
                ]
            )

    def test_rewrite_ast(self, pytester: Pytester) -> None:
        pytester.mkdir("pkg")
        contents = {
            "pkg/__init__.py": """
                import pytest
                pytest.register_assert_rewrite('pkg.helper')
            """,
            "pkg/helper.py": """
                def tool():
                    a, b = 2, 3
                    assert a == b
            """,
            "pkg/plugin.py": """
                import pytest, pkg.helper
                @pytest.fixture
                def tool():
                    return pkg.helper.tool
            """,
            "pkg/other.py": """
                values = [3, 2]
                def tool():
                    assert values.pop() == 3
            """,
            "conftest.py": """
                pytest_plugins = ['pkg.plugin']
            """,
            "test_pkg.py": """
                import pkg.other
                def test_tool(tool):
                    tool()
                def test_other():
                    pkg.other.tool()
            """,
        }
        pytester.makepyfile(**contents)
        result = pytester.runpytest_subprocess("--assert=rewrite")
        result.stdout.fnmatch_lines(
            [
                ">*assert a == b*",
                "E*assert 2 == 3*",
                ">*assert values.pop() == 3*",
                "E*AssertionError",
            ]
        )

    def test_register_assert_rewrite_checks_types(self) -> None:
        with pytest.raises(TypeError):
            pytest.register_assert_rewrite(["pytest_tests_internal_non_existing"])  # type: ignore
        pytest.register_assert_rewrite(
            "pytest_tests_internal_non_existing", "pytest_tests_internal_non_existing2"
        )


class TestBinReprIntegration:
    def test_pytest_assertrepr_compare_called(self, pytester: Pytester) -> None:
        pytester.makeconftest(
            """
            import pytest
            values = []
            def pytest_assertrepr_compare(op, left, right):
                values.append((op, left, right))

            @pytest.fixture
            def list(request):
                return values
        """
        )
        pytester.makepyfile(
            """
            def test_hello():
                assert 0 == 1
            def test_check(list):
                assert list == [("==", 0, 1)]
        """
        )
        result = pytester.runpytest("-v")
        result.stdout.fnmatch_lines(["*test_hello*FAIL*", "*test_check*PASS*"])


def callop(
    op: str,
    left: Any,
    right: Any,
    verbose: int = 0,
    assertion_text_diff_style: _AssertionTextDiffStyle = "ndiff",
) -> list[str] | None:
    config = mock_config(
        verbose=verbose,
        assertion_text_diff_style=assertion_text_diff_style,
    )
    return plugin.pytest_assertrepr_compare(config, op, left, right)


def callequal(
    left: Any,
    right: Any,
    verbose: int = 0,
    assertion_text_diff_style: _AssertionTextDiffStyle = "ndiff",
) -> list[str] | None:
    return callop(
        "==",
        left,
        right,
        verbose,
        assertion_text_diff_style=assertion_text_diff_style,
    )


class TestAssert_reprcompare:
    def test_different_types(self) -> None:
        assert callequal([0, 1], "foo") is None

    def test_summary(self) -> None:
        lines = callequal([0, 1], [0, 2])
        assert lines is not None
        summary = lines[0]
        assert len(summary) < 65

    def test_text_diff(self) -> None:
        assert callequal("spam", "eggs") == [
            "'spam' == 'eggs'",
            "",
            "- eggs",
            "+ spam",
        ]

    def test_text_diff_ndiff_style(self) -> None:
        assert list(
            _compare_eq_text(
                "spam",
                "eggs",
                util.dummy_highlighter,
                0,
                "ndiff",
            )
        ) == [
            "- eggs",
            "+ spam",
        ]

    def test_text_diff_budget_caps_ndiff_input(self) -> None:
        """A truncation budget caps the inputs to ndiff, so the result is
        bounded instead of growing with the input."""
        left = "\n".join(f"left {i}" for i in range(1000))
        right = "\n".join(f"right {i}" for i in range(1000))
        ndiff_style: Literal["ndiff"] = "ndiff"
        capped = list(
            _compare_eq_text(
                left,
                right,
                util.dummy_highlighter,
                1,
                ndiff_style,
                TruncationBudget(max_lines=11, max_chars=710),
            )
        )
        full = list(
            _compare_eq_text(
                left,
                right,
                util.dummy_highlighter,
                1,
                ndiff_style,
                NO_TRUNCATION_BUDGET,
            )
        )
        assert len(capped) < 80
        assert len(full) > 1500
        # a few huge lines: the char budget bounds each emitted line.
        capped_chars = list(
            _compare_eq_text(
                "x" * 100_000,
                "y" * 100_000,
                util.dummy_highlighter,
                1,
                ndiff_style,
                TruncationBudget(max_lines=11, max_chars=710),
            )
        )
        assert all(len(line) < 1000 for line in capped_chars)

    def test_notin_text_budget_caps_ndiff_input(self) -> None:
        """``not in`` runs the same ndiff machinery as ``==`` and is capped
        the same way."""
        # The needle sits in the middle so an uncapped diff has to walk
        # past ~N identical chars to reach it.
        needle = "NEEDLE"
        text = "a" * 100_000 + needle + "a" * 100_000
        capped = list(
            _notin_text(needle, text, 1, TruncationBudget(max_lines=11, max_chars=710))
        )
        full = list(_notin_text(needle, text, 1, NO_TRUNCATION_BUDGET))
        assert len(capped) < 80
        assert all(len(line) < 1000 for line in capped)
        assert sum(len(line) for line in full) > 100_000

    def test_text_skipping(self) -> None:
        lines = callequal("a" * 50 + "spam", "a" * 50 + "eggs")
        assert lines is not None
        assert "Skipping" in lines[2]
        for line in lines:
            assert "a" * 50 not in line

    def test_text_skipping_trailing(self) -> None:
        # Same length, differ at index 1, then ~50 identical trailing chars.
        # Exercises the trailing-skip branch in ``_diff_text``.
        lines = callequal("a" + "x" + "z" * 50, "a" + "y" + "z" * 50)
        assert lines is not None
        assert any("identical trailing" in line for line in lines)
        for line in lines:
            assert "z" * 50 not in line

    def test_text_skipping_trailing_when_prefix_differs(self) -> None:
        # The trailing-skip branch must still work when the first characters differ.
        lines = callequal("x" + "z" * 50, "y" + "z" * 50)
        assert lines is not None
        assert any("identical trailing" in line for line in lines)
        for line in lines:
            assert "z" * 50 not in line

    def test_text_skipping_verbose(self) -> None:
        lines = callequal("a" * 50 + "spam", "a" * 50 + "eggs", verbose=1)
        assert lines is not None
        assert "- " + "a" * 50 + "eggs" in lines
        assert "+ " + "a" * 50 + "spam" in lines

    def test_multiline_text_diff(self) -> None:
        left = "foo\nspam\nbar"
        right = "foo\neggs\nbar"
        diff = callequal(left, right)
        assert diff is not None
        assert "- eggs" in diff
        assert "+ spam" in diff

    def test_multiline_text_diff_block(self) -> None:
        assert callequal(
            "foo\nspam\nbar",
            "foo\neggs\nbar",
            assertion_text_diff_style="block",
        ) == [
            r"'foo\nspam\nbar' == 'foo\neggs\nbar'",
            "",
            "Left:",
            "  foo",
            "  spam",
            "  bar",
            "",
            "Right:",
            "  foo",
            "  eggs",
            "  bar",
        ]

    def test_multiline_text_diff_block_preserves_blank_lines(self) -> None:
        assert callequal(
            "\nfoo\n",
            "\nbar",
            assertion_text_diff_style="block",
        ) == [
            r"'\nfoo\n' == '\nbar'",
            "",
            "Left:",
            "  ",
            "  foo",
            "  ",
            "",
            "Right:",
            "  ",
            "  bar",
        ]

    def test_single_line_text_diff_block(self) -> None:
        assert callequal(
            "spam",
            "eggs",
            assertion_text_diff_style="block",
        ) == [
            "'spam' == 'eggs'",
            "",
            "Left:",
            "  spam",
            "",
            "Right:",
            "  eggs",
        ]

    def test_bytes_diff_normal(self) -> None:
        """Check special handling for bytes diff (#5260)"""
        diff = callequal(b"spam", b"eggs")

        assert diff == [
            "b'spam' == b'eggs'",
            "",
            "At index 0 diff: b's' != b'e'",
            "Use -v to get more diff",
        ]

    def test_bytes_diff_verbose(self) -> None:
        """Check special handling for bytes diff (#5260)"""
        diff = callequal(b"spam", b"eggs", verbose=1)
        assert diff == [
            "b'spam' == b'eggs'",
            "",
            "At index 0 diff: b's' != b'e'",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "- b'eggs'",
            "+ b'spam'",
        ]

    def test_list(self) -> None:
        expl = callequal([0, 1], [0, 2])
        assert expl is not None
        assert len(expl) > 1

    @pytest.mark.parametrize(
        ["left", "right", "expected"],
        [
            pytest.param(
                [0, 1],
                [0, 2],
                """
                Full diff: (-: missing in left side, +: extra in left side)
                  [
                      0,
                -     2,
                ?     ^
                +     1,
                ?     ^
                  ]
                """,
                id="lists",
            ),
            pytest.param(
                {0: 1},
                {0: 2},
                """
                Full diff: (-: missing in left side, +: extra in left side)
                  {
                -     0: 2,
                ?        ^
                +     0: 1,
                ?        ^
                  }
            """,
                id="dicts",
            ),
            pytest.param(
                {0, 1},
                {0, 2},
                """
                Full diff: (-: missing in left side, +: extra in left side)
                  {
                      0,
                -     2,
                ?     ^
                +     1,
                ?     ^
                  }
            """,
                id="sets",
            ),
        ],
    )
    def test_iterable_full_diff(self, left, right, expected) -> None:
        """Test the full diff assertion failure explanation.

        When verbose is False, then just a -v notice to get the diff is rendered,
        when verbose is True, then ndiff of the pprint is returned.
        """
        expl = callequal(left, right, verbose=0)
        assert expl is not None
        assert expl[-1] == "Use -v to get more diff"
        verbose_expl = callequal(left, right, verbose=1)
        assert verbose_expl is not None
        assert "\n".join(verbose_expl).endswith(textwrap.dedent(expected).strip())

    def test_iterable_quiet(self) -> None:
        expl = callequal([1, 2], [10, 2], verbose=-1)
        assert expl == [
            "[1, 2] == [10, 2]",
            "",
            "At index 0 diff: 1 != 10",
            "Use -v to get more diff",
        ]

    def test_iterable_full_diff_ci(
        self, monkeypatch: MonkeyPatch, pytester: Pytester
    ) -> None:
        pytester.makepyfile(
            r"""
            def test_full_diff():
                left = [0, 1]
                right = [0, 2]
                assert left == right
        """
        )
        monkeypatch.setenv("CI", "true")
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(
            ["E         Full diff: (-: missing in left side, +: extra in left side)"]
        )

        # Setting CI to empty string is same as having it undefined
        monkeypatch.setenv("CI", "")
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(["E         Use -v to get more diff"])

        monkeypatch.delenv("CI", raising=False)
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(["E         Use -v to get more diff"])

    def test_list_different_lengths(self) -> None:
        expl = callequal([0, 1], [0, 1, 2])
        assert expl is not None
        assert len(expl) > 1
        expl = callequal([0, 1, 2], [0, 1])
        assert expl is not None
        assert len(expl) > 1

    def test_list_wrap_for_multiple_lines(self) -> None:
        long_d = "d" * 80
        l1 = ["a", "b", "c"]
        l2 = ["a", "b", "c", long_d]
        diff = callequal(l1, l2, verbose=True)
        assert diff == [
            "['a', 'b', 'c'] == ['a', 'b', 'c...dddddddddddd']",
            "",
            "Right contains one more item: '" + long_d + "'",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  [",
            "      'a',",
            "      'b',",
            "      'c',",
            "-     '" + long_d + "',",
            "  ]",
        ]

        diff = callequal(l2, l1, verbose=True)
        assert diff == [
            "['a', 'b', 'c...dddddddddddd'] == ['a', 'b', 'c']",
            "",
            "Left contains one more item: '" + long_d + "'",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  [",
            "      'a',",
            "      'b',",
            "      'c',",
            "+     '" + long_d + "',",
            "  ]",
        ]

    def test_list_wrap_for_width_rewrap_same_length(self) -> None:
        long_a = "a" * 30
        long_b = "b" * 30
        long_c = "c" * 30
        l1 = [long_a, long_b, long_c]
        l2 = [long_b, long_c, long_a]
        diff = callequal(l1, l2, verbose=True)
        assert diff == [
            "['aaaaaaaaaaa...cccccccccccc'] == ['bbbbbbbbbbb...aaaaaaaaaaaa']",
            "",
            "At index 0 diff: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa' != 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  [",
            "+     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',",
            "      'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',",
            "      'cccccccccccccccccccccccccccccc',",
            "-     'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',",
            "  ]",
        ]

    def test_list_dont_wrap_strings(self) -> None:
        long_a = "a" * 10
        l1 = ["a"] + [long_a for _ in range(7)]
        l2 = ["should not get wrapped"]
        diff = callequal(l1, l2, verbose=True)
        assert diff == [
            "['a', 'aaaaaa...aaaaaaa', ...] == ['should not get wrapped']",
            "",
            "At index 0 diff: 'a' != 'should not get wrapped'",
            "Left contains 7 more items, first extra item: 'aaaaaaaaaa'",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  [",
            "-     'should not get wrapped',",
            "+     'a',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "+     'aaaaaaaaaa',",
            "  ]",
        ]

    def test_dict_wrap(self) -> None:
        d1 = {"common": 1, "env": {"env1": 1, "env2": 2}}
        d2 = {"common": 1, "env": {"env1": 1}}

        diff = callequal(d1, d2, verbose=True)
        assert diff == [
            "{'common': 1,...1, 'env2': 2}} == {'common': 1,...: {'env1': 1}}",
            "",
            "Omitting 1 identical items, use -vv to show",
            "Differing items:",
            "{'env': {'env1': 1, 'env2': 2}} != {'env': {'env1': 1}}",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  {",
            "      'common': 1,",
            "      'env': {",
            "          'env1': 1,",
            "+         'env2': 2,",
            "      },",
            "  }",
        ]

        long_a = "a" * 80
        sub = {"long_a": long_a, "sub1": {"long_a": "substring that gets wrapped " * 3}}
        d1 = {"env": {"sub": sub}}
        d2 = {"env": {"sub": sub}, "new": 1}
        diff = callequal(d1, d2, verbose=True)
        assert diff == [
            "{'env': {'sub... wrapped '}}}} == {'env': {'sub...}}}, 'new': 1}",
            "",
            "Omitting 1 identical items, use -vv to show",
            "Right contains 1 more item:",
            "{'new': 1}",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  {",
            "      'env': {",
            "          'sub': {",
            f"              'long_a': '{long_a}',",
            "              'sub1': {",
            "                  'long_a': 'substring that gets wrapped substring that gets wrapped '",
            "                  'substring that gets wrapped ',",
            "              },",
            "          },",
            "      },",
            "-     'new': 1,",
            "  }",
        ]

    def test_dict(self) -> None:
        expl = callequal({"a": 0}, {"a": 1})
        assert expl is not None
        assert len(expl) > 1

    def test_dict_omitting(self) -> None:
        lines = callequal({"a": 0, "b": 1}, {"a": 1, "b": 1})
        assert lines is not None
        assert lines[2].startswith("Omitting 1 identical item")
        assert "Common items" not in lines
        for line in lines[1:]:
            assert "b" not in line

    def test_dict_omitting_with_verbosity_1(self) -> None:
        """Ensure differing items are visible for verbosity=1 (#1512)."""
        lines = callequal({"a": 0, "b": 1}, {"a": 1, "b": 1}, verbose=1)
        assert lines is not None
        assert lines[1] == ""
        assert lines[2].startswith("Omitting 1 identical item")
        assert lines[3].startswith("Differing items")
        assert lines[4] == "{'a': 0} != {'a': 1}"
        assert "Common items" not in lines

    def test_dict_omitting_with_verbosity_2(self) -> None:
        lines = callequal({"a": 0, "b": 1}, {"a": 1, "b": 1}, verbose=2)
        assert lines is not None
        assert lines[2].startswith("Common items:")
        assert "Omitting" not in lines[2]
        assert lines[3] == "{'b': 1}"

    def test_dict_different_items(self) -> None:
        lines = callequal({"a": 0}, {"b": 1, "c": 2}, verbose=2)
        assert lines == [
            "{'a': 0} == {'b': 1, 'c': 2}",
            "",
            "Left contains 1 more item:",
            "{'a': 0}",
            "Right contains 2 more items:",
            "{'b': 1, 'c': 2}",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  {",
            "-     'b': 1,",
            "?      ^   ^",
            "+     'a': 0,",
            "?      ^   ^",
            "-     'c': 2,",
            "  }",
        ]
        lines = callequal({"b": 1, "c": 2}, {"a": 0}, verbose=2)
        assert lines == [
            "{'b': 1, 'c': 2} == {'a': 0}",
            "",
            "Left contains 2 more items:",
            "{'b': 1, 'c': 2}",
            "Right contains 1 more item:",
            "{'a': 0}",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  {",
            "-     'a': 0,",
            "?      ^   ^",
            "+     'b': 1,",
            "?      ^   ^",
            "+     'c': 2,",
            "  }",
        ]

    def test_dict_extra_items_bounded_under_budget(self) -> None:
        """With more extra keys than the budget, only the smallest
        ``max_lines`` keys are emitted, one per line."""
        out = list(
            _compare_eq_mapping(
                {i: i for i in range(1000)},
                {},
                util.dummy_highlighter,
                0,
                TruncationBudget(max_lines=5, max_chars=350),
            )
        )
        assert out[0] == "Left contains 1000 more items:"
        body = out[1:]
        assert body == [f"{{{i}: {i}}}" for i in range(5)]  # smallest 5, sorted

    def test_dict_extra_items_small_keeps_pformat_block(self) -> None:
        """Under the budget, the compact pprint block is unchanged."""
        out = list(
            _compare_eq_mapping(
                {"b": 2, "a": 1},
                {},
                util.dummy_highlighter,
                0,
                TruncationBudget(max_lines=5, max_chars=350),
            )
        )
        assert out == ["Left contains 2 more items:", "{'a': 1, 'b': 2}"]

    def test_mapping_different_items(self) -> None:
        class SimpleMapping(Mapping[str, int]):
            def __init__(self, values: dict[str, int]) -> None:
                self._values = values

            def __getitem__(self, key: str) -> int:
                return self._values[key]

            def __iter__(self) -> Iterator[str]:
                return iter(self._values)

            def __len__(self) -> int:  # pragma: no cover
                return len(self._values)

            def __repr__(self) -> str:
                return f"SimpleMapping({self._values!r})"

        lines = callequal(
            SimpleMapping({"a": 0, "b": 1}),
            SimpleMapping({"a": 1, "b": 1, "c": 2}),
        )

        assert lines is not None
        assert lines[2:] == [
            "Omitting 1 identical items, use -vv to show",
            "Differing items:",
            "{'a': 0} != {'a': 1}",
            "Right contains 1 more item:",
            "{'c': 2}",
            "Use -v to get more diff",
        ]

    def test_sequence_different_items(self) -> None:
        lines = callequal((1, 2), (3, 4, 5), verbose=2)
        assert lines == [
            "(1, 2) == (3, 4, 5)",
            "",
            "At index 0 diff: 1 != 3",
            "Right contains one more item: 5",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  (",
            "-     3,",
            "?     ^",
            "+     1,",
            "?     ^",
            "-     4,",
            "?     ^",
            "+     2,",
            "?     ^",
            "-     5,",
            "  )",
        ]
        lines = callequal((1, 2, 3), (4,), verbose=2)
        assert lines == [
            "(1, 2, 3) == (4,)",
            "",
            "At index 0 diff: 1 != 4",
            "Left contains 2 more items, first extra item: 2",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  (",
            "-     4,",
            "?     ^",
            "+     1,",
            "?     ^",
            "+     2,",
            "+     3,",
            "  )",
        ]
        lines = callequal((1, 2, 3), (1, 20, 3), verbose=2)
        assert lines == [
            "(1, 2, 3) == (1, 20, 3)",
            "",
            "At index 1 diff: 2 != 20",
            "",
            "Full diff: (-: missing in left side, +: extra in left side)",
            "  (",
            "      1,",
            "-     20,",
            "?      -",
            "+     2,",
            "      3,",
            "  )",
        ]

    def test_set(self) -> None:
        expl = callequal({0, 1}, {0, 2})
        assert expl is not None
        assert len(expl) > 1

    def test_frozenzet(self) -> None:
        expl = callequal(frozenset([0, 1]), {0, 2})
        assert expl is not None
        assert len(expl) > 1

    def test_Sequence(self) -> None:
        # Test comparing with a Sequence subclass.
        class TestSequence(MutableSequence[int]):
            def __init__(self, iterable):
                self.elements = list(iterable)

            def __getitem__(self, item):
                return self.elements[item]

            def __len__(self):
                return len(self.elements)

            def __setitem__(self, item, value):
                pass

            def __delitem__(self, item):
                pass

            def insert(self, index, value):
                pass

        expl = callequal(TestSequence([0, 1]), [0, 2])
        assert expl is not None
        assert len(expl) > 1

    def test_list_tuples(self) -> None:
        expl = callequal([], [(1, 2)])
        assert expl is not None
        assert len(expl) > 1
        expl = callequal([(1, 2)], [])
        assert expl is not None
        assert len(expl) > 1

    def test_list_bad_repr(self) -> None:
        class A:
            def __repr__(self):
                raise ValueError(42)

        expl = callequal([], [A()])
        assert expl is not None
        assert "ValueError" in "".join(expl)
        expl = callequal({}, {"1": A()}, verbose=2)
        assert expl is not None
        assert expl[0].startswith("{} == <[ValueError")
        assert "raised in repr" in expl[0]
        # Streaming explanation: any per-line output produced before the
        # bad repr is preserved, then the failure notice is appended.
        assert expl[-2:] == [
            "(pytest_assertion plugin: representation of details failed:"
            f" {__file__}:{A.__repr__.__code__.co_firstlineno + 1}: ValueError: 42.",
            " Probably an object has a faulty __repr__.)",
        ]

    def test_one_repr_empty(self) -> None:
        """The faulty empty string repr did trigger an unbound local error in _diff_text."""

        class A(str):
            def __repr__(self):
                return ""

        expl = callequal(A(), "")
        assert not expl

    def test_repr_no_exc(self) -> None:
        expl = callequal("foo", "bar")
        assert expl is not None
        assert "raised in repr()" not in " ".join(expl)

    def test_unicode(self) -> None:
        assert callequal("£€", "£") == [
            "'£€' == '£'",
            "",
            "- £",
            "+ £€",
        ]

    def test_nonascii_text(self) -> None:
        """
        :issue: 877
        non ascii python2 str caused a UnicodeDecodeError
        """

        class A(str):
            def __repr__(self):
                return "\xff"

        expl = callequal(A(), "1")
        assert expl == ["ÿ == '1'", "", "- 1"]

    def test_format_nonascii_explanation(self) -> None:
        assert util.format_explanation("λ")

    def test_mojibake(self) -> None:
        # issue 429
        left = b"e"
        right = b"\xc3\xa9"
        expl = callequal(left, right)
        assert expl is not None
        for line in expl:
            assert isinstance(line, str)
        msg = "\n".join(expl)
        assert msg

    def test_nfc_nfd_same_string(self) -> None:
        # issue 3426
        left = "hyv\xe4"
        right = "hyva\u0308"
        expl = callequal(left, right)
        assert expl == [
            r"'hyv\xe4' == 'hyva\u0308'",
            "",
            f"- {right!s}",
            f"+ {left!s}",
        ]

        expl = callequal(left, right, verbose=2)
        assert expl == [
            r"'hyv\xe4' == 'hyva\u0308'",
            "",
            f"- {right!s}",
            f"+ {left!s}",
        ]


class TestAssert_reprcompare_dataclass:
    def test_dataclasses(self, pytester: Pytester) -> None:
        p = pytester.copy_example("dataclasses/test_compare_dataclasses.py")
        result = pytester.runpytest(p)
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.fnmatch_lines(
            [
                "E         Omitting 1 identical items, use -vv to show",
                "E         Differing attributes:",
                "E         ['field_b']",
                "E         ",
                "E         Drill down into differing attribute field_b:",
                "E           field_b: 'b' != 'c'",
                "E           - c",
                "E           + b",
            ],
            consecutive=True,
        )

    def test_recursive_dataclasses(self, pytester: Pytester) -> None:
        p = pytester.copy_example("dataclasses/test_compare_recursive_dataclasses.py")
        result = pytester.runpytest(p)
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.fnmatch_lines(
            [
                "E         Omitting 1 identical items, use -vv to show",
                "E         Differing attributes:",
                "E         ['g', 'h', 'j']",
                "E         ",
                "E         Drill down into differing attribute g:",
                "E           g: S(a=10, b='ten') != S(a=20, b='xxx')...",
                "E         ",
                "E         ...Full output truncated, use '-vv' to show",
            ],
            consecutive=True,
        )

    def test_recursive_dataclasses_verbose(self, pytester: Pytester) -> None:
        p = pytester.copy_example("dataclasses/test_compare_recursive_dataclasses.py")
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.fnmatch_lines(
            [
                "E         Matching attributes:",
                "E         ['i']",
                "E         Differing attributes:",
                "E         ['g', 'h', 'j']",
                "E         ",
                "E         Drill down into differing attribute g:",
                "E           g: S(a=10, b='ten') != S(a=20, b='xxx')",
                "E           ",
                "E           Differing attributes:",
                "E           ['a', 'b']",
                "E           ",
                "E           Drill down into differing attribute a:",
                "E             a: 10 != 20",
                "E           ",
                "E           Drill down into differing attribute b:",
                "E             b: 'ten' != 'xxx'",
                "E             - xxx",
                "E             + ten",
                "E         ",
                "E         Drill down into differing attribute h:",
            ],
            consecutive=True,
        )

    def test_dataclasses_verbose(self, pytester: Pytester) -> None:
        p = pytester.copy_example("dataclasses/test_compare_dataclasses_verbose.py")
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.fnmatch_lines(
            [
                "*Matching attributes:*",
                "*['field_a']*",
                "*Differing attributes:*",
                "*field_b: 'b' != 'c'*",
            ]
        )

    def test_dataclasses_with_attribute_comparison_off(
        self, pytester: Pytester
    ) -> None:
        p = pytester.copy_example(
            "dataclasses/test_compare_dataclasses_field_comparison_off.py"
        )
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=0, passed=1)

    def test_comparing_two_different_data_classes(self, pytester: Pytester) -> None:
        p = pytester.copy_example(
            "dataclasses/test_compare_two_different_dataclasses.py"
        )
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=0, passed=1)

    def test_data_classes_with_custom_eq(self, pytester: Pytester) -> None:
        p = pytester.copy_example(
            "dataclasses/test_compare_dataclasses_with_custom_eq.py"
        )
        # issue 9362
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.no_re_match_line(".*Differing attributes.*")

    def test_data_classes_with_initvar(self, pytester: Pytester) -> None:
        p = pytester.copy_example("dataclasses/test_compare_initvar.py")
        # issue 9820
        result = pytester.runpytest(p, "-vv")
        result.assert_outcomes(failed=1, passed=0)
        result.stdout.no_re_match_line(".*AttributeError.*")


class TestAssert_reprcompare_attrsclass:
    def test_attrs(self) -> None:
        @attr.s
        class SimpleDataObject:
            field_a = attr.ib()
            field_b = attr.ib()

        left = SimpleDataObject(1, "b")
        right = SimpleDataObject(1, "c")

        lines = callequal(left, right)
        assert lines is not None
        assert lines[2].startswith("Omitting 1 identical item")
        assert "Matching attributes" not in lines
        for line in lines[2:]:
            assert "field_a" not in line

    def test_attrs_recursive(self) -> None:
        @attr.s
        class OtherDataObject:
            field_c = attr.ib()
            field_d = attr.ib()

        @attr.s
        class SimpleDataObject:
            field_a = attr.ib()
            field_b = attr.ib()

        left = SimpleDataObject(OtherDataObject(1, "a"), "b")
        right = SimpleDataObject(OtherDataObject(1, "b"), "b")

        lines = callequal(left, right)
        assert lines is not None
        assert "Matching attributes" not in lines
        for line in lines[1:]:
            assert "field_b:" not in line
            assert "field_c:" not in line

    def test_attrs_recursive_verbose(self) -> None:
        @attr.s
        class OtherDataObject:
            field_c = attr.ib()
            field_d = attr.ib()

        @attr.s
        class SimpleDataObject:
            field_a = attr.ib()
            field_b = attr.ib()

        left = SimpleDataObject(OtherDataObject(1, "a"), "b")
        right = SimpleDataObject(OtherDataObject(1, "b"), "b")

        lines = callequal(left, right)
        assert lines is not None
        # indentation in output because of nested object structure
        assert "    field_d: 'a' != 'b'" in lines

    def test_attrs_verbose(self) -> None:
        @attr.s
        class SimpleDataObject:
            field_a = attr.ib()
            field_b = attr.ib()

        left = SimpleDataObject(1, "b")
        right = SimpleDataObject(1, "c")

        lines = callequal(left, right, verbose=2)
        assert lines is not None
        assert lines[2].startswith("Matching attributes:")
        assert "Omitting" not in lines[2]
        assert lines[3] == "['field_a']"

    def test_attrs_with_attribute_comparison_off(self) -> None:
        @attr.s
        class SimpleDataObject:
            field_a = attr.ib()
            field_b = attr.ib(eq=False)

        left = SimpleDataObject(1, "b")
        right = SimpleDataObject(1, "b")

        lines = callequal(left, right, verbose=2)
        assert lines is not None
        assert lines[2].startswith("Matching attributes:")
        assert "Omitting" not in lines[1]
        assert lines[3] == "['field_a']"
        for line in lines[3:]:
            assert "field_b" not in line

    def test_comparing_two_different_attrs_classes(self) -> None:
        @attr.s
        class SimpleDataObjectOne:
            field_a = attr.ib()
            field_b = attr.ib()

        @attr.s
        class SimpleDataObjectTwo:
            field_a = attr.ib()
            field_b = attr.ib()

        left = SimpleDataObjectOne(1, "b")
        right = SimpleDataObjectTwo(1, "c")

        lines = callequal(left, right)
        assert lines is None

    def test_attrs_with_auto_detect_and_custom_eq(self) -> None:
        @attr.s(
            auto_detect=True
        )  # attr.s doesn't ignore a custom eq if auto_detect=True
        class SimpleDataObject:
            field_a = attr.ib()

            def __eq__(self, other):  # pragma: no cover
                return super().__eq__(other)

        left = SimpleDataObject(1)
        right = SimpleDataObject(2)
        # issue 9362
        lines = callequal(left, right, verbose=2)
        assert lines is None

    def test_attrs_with_custom_eq(self) -> None:
        @attr.define(slots=False)
        class SimpleDataObject:
            field_a = attr.ib()

            def __eq__(self, other):  # pragma: no cover
                return super().__eq__(other)

        left = SimpleDataObject(1)
        right = SimpleDataObject(2)
        # issue 9362
        lines = callequal(left, right, verbose=2)
        assert lines is None


class TestAssert_reprcompare_namedtuple:
    def test_namedtuple(self) -> None:
        class NT(NamedTuple):
            a: Any
            b: Any

        left = NT(1, "b")
        right = NT(1, "c")

        lines = callequal(left, right)
        assert lines == [
            "NT(a=1, b='b') == NT(a=1, b='c')",
            "",
            "Omitting 1 identical items, use -vv to show",
            "Differing attributes:",
            "['b']",
            "",
            "Drill down into differing attribute b:",
            "  b: 'b' != 'c'",
            "  - c",
            "  + b",
            "Use -v to get more diff",
        ]

    def test_comparing_two_different_namedtuple(self) -> None:
        class NT1(NamedTuple):
            a: Any
            b: Any

        class NT2(NamedTuple):
            a: Any
            b: Any

        left = NT1(1, "b")
        right = NT2(2, "b")

        lines = callequal(left, right)
        # Because the types are different, uses the generic sequence matcher.
        assert lines == [
            "NT1(a=1, b='b') == NT2(a=2, b='b')",
            "",
            "At index 0 diff: 1 != 2",
            "Use -v to get more diff",
        ]


class TestFormatExplanation:
    def test_special_chars_full(self, pytester: Pytester) -> None:
        # Issue 453, for the bug this would raise IndexError
        pytester.makepyfile(
            """
            def test_foo():
                assert '\\n}' == ''
        """
        )
        result = pytester.runpytest()
        assert result.ret == 1
        result.stdout.fnmatch_lines(["*AssertionError*"])

    def test_fmt_simple(self) -> None:
        expl = "assert foo"
        assert util.format_explanation(expl) == "assert foo"

    def test_fmt_where(self) -> None:
        expl = "\n".join(["assert 1", "{1 = foo", "} == 2"])
        res = "\n".join(["assert 1 == 2", " +  where 1 = foo"])
        assert util.format_explanation(expl) == res

    def test_fmt_and(self) -> None:
        expl = "\n".join(["assert 1", "{1 = foo", "} == 2", "{2 = bar", "}"])
        res = "\n".join(["assert 1 == 2", " +  where 1 = foo", " +  and   2 = bar"])
        assert util.format_explanation(expl) == res

    def test_fmt_where_nested(self) -> None:
        expl = "\n".join(["assert 1", "{1 = foo", "{foo = bar", "}", "} == 2"])
        res = "\n".join(["assert 1 == 2", " +  where 1 = foo", " +    where foo = bar"])
        assert util.format_explanation(expl) == res

    def test_fmt_newline(self) -> None:
        expl = "\n".join(['assert "foo" == "bar"', "~- foo", "~+ bar"])
        res = "\n".join(['assert "foo" == "bar"', "  - foo", "  + bar"])
        assert util.format_explanation(expl) == res

    def test_fmt_newline_escaped(self) -> None:
        expl = "\n".join(["assert foo == bar", "baz"])
        res = "assert foo == bar\\nbaz"
        assert util.format_explanation(expl) == res

    def test_fmt_newline_before_where(self) -> None:
        expl = "\n".join(
            [
                "the assertion message here",
                ">assert 1",
                "{1 = foo",
                "} == 2",
                "{2 = bar",
                "}",
            ]
        )
        res = "\n".join(
            [
                "the assertion message here",
                "assert 1 == 2",
                " +  where 1 = foo",
                " +  and   2 = bar",
            ]
        )
        assert util.format_explanation(expl) == res

    def test_fmt_multi_newline_before_where(self) -> None:
        expl = "\n".join(
            [
                "the assertion",
                "~message here",
                ">assert 1",
                "{1 = foo",
                "} == 2",
                "{2 = bar",
                "}",
            ]
        )
        res = "\n".join(
            [
                "the assertion",
                "  message here",
                "assert 1 == 2",
                " +  where 1 = foo",
                " +  and   2 = bar",
            ]
        )
        assert util.format_explanation(expl) == res


class TestTruncateExplanation:
    # The number of lines in the truncation explanation message. Used
    # to calculate that results have the expected length.
    LINES_IN_TRUNCATION_MSG = 2

    def test_doesnt_truncate_when_input_is_empty_list(self) -> None:
        expl: list[str] = []
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=100)
        )
        assert result == expl

    def test_doesnt_truncate_at_when_input_is_5_lines_and_LT_max_chars(self) -> None:
        expl = ["a" * 100 for x in range(5)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=8 * 80)
        )
        assert result == expl

    def test_truncates_at_8_lines_when_given_list_of_empty_strings(self) -> None:
        expl = ["" for x in range(50)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=100)
        )
        assert len(result) != len(expl)
        assert result != expl
        assert len(result) == 8 + self.LINES_IN_TRUNCATION_MSG
        assert "Full output truncated" in result[-1]
        last_line_before_trunc_msg = result[-self.LINES_IN_TRUNCATION_MSG - 1]
        assert last_line_before_trunc_msg.endswith("...")

    def test_truncates_at_8_lines_when_first_8_lines_are_LT_max_chars(self) -> None:
        total_lines = 100
        expl = ["a" for x in range(total_lines)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=8 * 80)
        )
        assert result != expl
        assert len(result) == 8 + self.LINES_IN_TRUNCATION_MSG
        assert "Full output truncated" in result[-1]
        last_line_before_trunc_msg = result[-self.LINES_IN_TRUNCATION_MSG - 1]
        assert last_line_before_trunc_msg.endswith("...")

    def test_truncates_at_8_lines_when_there_is_one_line_to_remove(self) -> None:
        """The number of line in the result is 9, the same number as if we truncated."""
        expl = ["a" for x in range(9)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=8 * 80)
        )
        assert result == expl
        assert "truncated" not in result[-1]

    def test_truncates_full_line_because_of_max_chars(self) -> None:
        """A line is fully truncated because of the max_chars value."""
        expl = ["a" * 10, "b" * 71]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=10, max_chars=10)
        )
        assert result == [
            "a" * 10,
            "...",
            "",
            "...Full output truncated, use '-vv' to show",
        ]

    def test_truncates_edgecase_when_truncation_message_makes_the_result_longer_for_chars(
        self,
    ) -> None:
        line = "a" * 10
        expl = [line, line]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=10, max_chars=10)
        )
        assert result == [line, line]

    def test_truncates_edgecase_when_truncation_message_makes_the_result_longer_for_lines(
        self,
    ) -> None:
        line = "a" * 10
        expl = [line, line]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=1, max_chars=100)
        )
        assert result == [line, line]

    def test_truncates_at_8_lines_when_first_8_lines_are_EQ_max_chars(self) -> None:
        expl = [chr(97 + x) * 80 for x in range(16)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=8 * 80)
        )
        assert result != expl
        assert len(result) == 16 - 8 + self.LINES_IN_TRUNCATION_MSG
        assert "Full output truncated" in result[-1]
        last_line_before_trunc_msg = result[-self.LINES_IN_TRUNCATION_MSG - 1]
        assert last_line_before_trunc_msg.endswith("...")

    def test_truncates_at_4_lines_when_first_4_lines_are_GT_max_chars(self) -> None:
        expl = ["a" * 250 for x in range(10)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=999)
        )
        assert result != expl
        assert len(result) == 4 + self.LINES_IN_TRUNCATION_MSG
        assert "Full output truncated" in result[-1]
        last_line_before_trunc_msg = result[-self.LINES_IN_TRUNCATION_MSG - 1]
        assert last_line_before_trunc_msg.endswith("...")

    def test_truncates_at_1_line_when_first_line_is_GT_max_chars(self) -> None:
        expl = ["a" * 250 for x in range(1000)]
        result = truncate._truncate_explanation(
            expl, TruncationBudget(max_lines=8, max_chars=100)
        )
        assert result != expl
        assert len(result) == 1 + self.LINES_IN_TRUNCATION_MSG
        assert "Full output truncated" in result[-1]
        last_line_before_trunc_msg = result[-self.LINES_IN_TRUNCATION_MSG - 1]
        assert last_line_before_trunc_msg.endswith("...")

    def test_full_output_truncated(self, monkeypatch, pytester: Pytester) -> None:
        """Test against full runpytest() output."""
        line_count = 7
        line_len = 100
        pytester.makepyfile(
            rf"""
            def test_many_lines():
                a = list([str(i)[0] * {line_len} for i in range({line_count})])
                b = a[::2]
                a = '\n'.join(map(str, a))
                b = '\n'.join(map(str, b))
                assert a == b
        """
        )
        monkeypatch.delenv("CI", raising=False)

        result = pytester.runpytest()
        # without -vv, truncate the message showing a few diff lines only
        result.stdout.fnmatch_lines(
            [
                "*+ 1*",
                "*+ 3*",
                "*Full output truncated*use*-vv*",
            ]
        )

        result = pytester.runpytest("-vv")
        result.stdout.fnmatch_lines(["* 6*"])

        # Setting CI to empty string is same as having it undefined
        monkeypatch.setenv("CI", "")
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(
            [
                "*+ 1*",
                "*+ 3*",
                "*Full output truncated*use*-vv*",
            ]
        )

        monkeypatch.setenv("CI", "1")
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(["* 6*"])

    @pytest.mark.parametrize(
        ["truncation_lines", "truncation_chars", "expected_lines_hidden"],
        (
            (3, None, 3),
            (4, None, 0),
            (0, None, 0),
            (None, 8, 6),
            (None, 33, 0),
            (None, 0, 0),
            (0, 0, 0),
            (0, 1000, 0),
            (1000, 0, 0),
        ),
    )
    def test_truncation_with_ini(
        self,
        monkeypatch,
        pytester: Pytester,
        truncation_lines: int | None,
        truncation_chars: int | None,
        expected_lines_hidden: int,
    ) -> None:
        pytester.makepyfile(
            """\
            string_a = "123456789\\n23456789\\n3"
            string_b = "123456789\\n23456789\\n4"

            def test():
                assert string_a == string_b
            """
        )

        # This test produces 6 lines of diff output or 79 characters
        # So the effect should be when threshold is < 4 lines (considering 2 additional lines for explanation)
        # Or < 33 characters (considering the ~46-char footer slack, see truncate.TRUNCATION_FOOTER_CHARS)

        monkeypatch.delenv("CI", raising=False)

        ini = "[pytest]\n"
        if truncation_lines is not None:
            ini += f"truncation_limit_lines = {truncation_lines}\n"
        if truncation_chars is not None:
            ini += f"truncation_limit_chars = {truncation_chars}\n"
        pytester.makeini(ini)

        result = pytester.runpytest()

        if expected_lines_hidden != 0:
            result.stdout.fnmatch_lines(["*Full output truncated*"])
        else:
            result.stdout.no_fnmatch_line("*truncated*")
            result.stdout.fnmatch_lines(
                [
                    "*- 4*",
                    "*+ 3*",
                ]
            )

    @pytest.mark.parametrize(
        "config",
        [
            # Native [tool.pytest] uses TOML types, so an int is accepted (#14675).
            pytest.param(
                """
                [tool.pytest]
                truncation_limit_lines = 3
                truncation_limit_chars = 0
                """,
                id="native-toml-int",
            ),
            # A string in native [tool.pytest] must keep working (backward compat).
            pytest.param(
                """
                [tool.pytest]
                truncation_limit_lines = "3"
                truncation_limit_chars = "0"
                """,
                id="native-toml-string",
            ),
            # [tool.pytest.ini_options] keeps the string-based INI behaviour.
            pytest.param(
                """
                [tool.pytest.ini_options]
                truncation_limit_lines = "3"
                truncation_limit_chars = "0"
                """,
                id="ini-options-string",
            ),
            # ... and also accepts a bare int, coerced like the INI format does.
            pytest.param(
                """
                [tool.pytest.ini_options]
                truncation_limit_lines = 3
                truncation_limit_chars = 0
                """,
                id="ini-options-int",
            ),
        ],
    )
    def test_truncation_limits_accept_int_and_string(
        self, monkeypatch, pytester: Pytester, config: str
    ) -> None:
        """Truncation limits accept both int and string values in TOML (#14675)."""
        pytester.makepyfile(
            """\
            string_a = "123456789\\n23456789\\n3"
            string_b = "123456789\\n23456789\\n4"

            def test():
                assert string_a == string_b
            """
        )
        monkeypatch.delenv("CI", raising=False)
        pytester.makepyprojecttoml(config)

        result = pytester.runpytest()

        result.stdout.no_fnmatch_line("*TypeError*")
        result.stdout.fnmatch_lines(["*Full output truncated, use '-vv' to show*"])


class TestMaterializeWithTruncation:
    """Tests for ``truncate.materialize_with_truncation``."""

    @staticmethod
    def _config_with_limits(verbose: int = 0):
        class C:
            def getini(self, name: str) -> object:
                return None  # use defaults (8 lines / 640 chars)

            def get_verbosity(self, _verbosity_type: str | None = None) -> int:
                return verbose

        return C()

    def test_sized_input_returns_same_shape_as_iterator_input(self) -> None:
        """A list input truncates the same way as an iterator over it."""
        content = [f"line {i}" for i in range(50)]
        sized = truncate.materialize_with_truncation(
            content, self._config_with_limits()
        )
        unsized = truncate.materialize_with_truncation(
            iter(content), self._config_with_limits()
        )
        assert sized[0] == unsized[0] == "line 0"
        assert any("truncated" in line for line in sized)
        assert any("truncated" in line for line in unsized)

    def test_truncation_disabled_returns_full_input(self) -> None:
        """Verbose >= 2 disables truncation; the iterator is fully drained."""
        lines = (f"line {i}" for i in range(50))
        result = truncate.materialize_with_truncation(
            lines, self._config_with_limits(verbose=2)
        )
        assert result == [f"line {i}" for i in range(50)]
        assert not any("truncated" in line for line in result)

    def test_idempotent_on_already_truncated_list(self) -> None:
        """Re-truncating an already-truncated explanation changes nothing.

        The dispatcher re-applies truncation to the built-in impl's
        already-truncated output.
        """
        once = truncate.materialize_with_truncation(
            (f"line {i}" for i in range(200)), self._config_with_limits()
        )
        twice = truncate.materialize_with_truncation(once, self._config_with_limits())
        assert twice == once

    def test_does_not_over_consume_the_stream(self) -> None:
        """Laziness guard: the input iterator is never drained past the
        truncation threshold."""
        pulled = 0

        def tripwire() -> Iterator[str]:
            nonlocal pulled
            for i in range(10_000):  # pragma: no branch
                pulled += 1
                yield f"line {i}"
            raise AssertionError(  # pragma: no cover
                "materialize_with_truncation drained the whole stream — "
                "the explanation iterator is no longer consumed lazily"
            )

        result = truncate.materialize_with_truncation(
            tripwire(), self._config_with_limits()
        )
        assert any("truncated" in line for line in result)
        assert pulled < 20

    def test_pull_count_is_independent_of_input_size(self) -> None:
        """The number of lines pulled to truncate does not grow with the input."""

        def count_pulls(n: int) -> int:
            pulled = 0

            def gen() -> Iterator[str]:
                nonlocal pulled
                for i in range(n):  # pragma: no branch
                    pulled += 1
                    yield f"line {i}"

            truncate.materialize_with_truncation(gen(), self._config_with_limits())
            return pulled

        assert count_pulls(100) == count_pulls(100_000)

    def _explain_capped(self, left: object, right: object) -> list[str]:
        # Drive the comparison as the dispatcher does: budget-capped
        # ``assertrepr_compare``, then materialise with truncation.
        config = self._config_with_limits()
        should, base = truncate._get_truncation_parameters(config)
        cap = (
            TruncationBudget(
                max_lines=base.max_lines + 3 if base.max_lines > 0 else 0,
                max_chars=base.max_chars + 70 if base.max_chars > 0 else 0,
            )
            if should
            else NO_TRUNCATION_BUDGET
        )
        src = util.assertrepr_compare(
            op="==",
            left=left,
            right=right,
            verbose=1,
            highlighter=util.dummy_highlighter,
            assertion_text_diff_style="ndiff",
            truncation_budget=cap,
        )
        return truncate.materialize_with_truncation(src, config)

    @pytest.mark.parametrize("shape", ["list", "tuple", "dict", "set"])
    def test_formatting_work_is_bounded_for_a_10_line_display(self, shape: str) -> None:
        """A huge comparison whose display is truncated to ~10 lines must
        not format the whole input to get there.

        Element ``repr`` calls are counted as a deterministic proxy for
        the formatting work (wall-clock would flake in CI).
        """

        class Tracked:
            reprs = 0

            def __init__(self, v: int) -> None:
                self.v = v

            def __repr__(self) -> str:
                Tracked.reprs += 1
                return f"T({self.v})"

            def __eq__(self, o: object) -> bool:
                return isinstance(o, Tracked) and self.v == o.v

            def __hash__(self) -> int:
                return hash(self.v)

        def make(n: int) -> tuple[object, object]:
            # Two near-identical containers differing in one spot, so the
            # explanation is a real (truncated) diff.
            if shape in ("list", "tuple"):
                seq_left = [Tracked(i) for i in range(n)]
                seq_right = [Tracked(i) for i in range(n)]
                seq_right[0] = Tracked(-1)
                if shape == "tuple":
                    return tuple(seq_left), tuple(seq_right)
                return seq_left, seq_right
            if shape == "dict":
                map_left = {i: Tracked(i) for i in range(n)}
                map_right = {i: Tracked(i) for i in range(n)}
                map_right[0] = Tracked(-1)
                return map_left, map_right
            # set
            set_left = {Tracked(i) for i in range(n)}
            set_right = {Tracked(i) for i in range(n)}
            set_right.discard(Tracked(0))
            set_right.add(Tracked(-1))
            return set_left, set_right

        def work(n: int) -> tuple[int, int]:
            left, right = make(n)
            Tracked.reprs = 0  # count only the formatting, not the construction
            out = self._explain_capped(left, right)
            assert any("truncated" in line for line in out)
            return len(out), Tracked.reprs

        lines_small, reprs_small = work(1_000)
        lines_big, reprs_big = work(100_000)
        assert lines_small == lines_big
        assert reprs_small == reprs_big
        assert reprs_big < 200  # nowhere near the 100_000-element input


class TestAssertReprCompareDispatcher:
    """Tests for the budget wiring in ``plugin.pytest_assertrepr_compare``.

    Unlike ``callequal``/``callop``, these tests pass explicit truncation
    limits, covering the branch that derives a :class:`TruncationBudget`
    for the comparison helpers.
    """

    def test_both_limits_truncate_without_formatting_everything(self) -> None:
        """A huge list comparison is truncated to a few lines without the
        element ``repr`` work scaling with the input."""

        class Tracked:
            reprs = 0

            def __init__(self, v: int) -> None:
                self.v = v

            def __repr__(self) -> str:
                Tracked.reprs += 1
                return f"T({self.v})"

            def __eq__(self, o: object) -> bool:
                return isinstance(o, Tracked) and self.v == o.v

        config = mock_config(
            verbose=1,  # -v: emit the full diff that truncation then clips
            truncation_limit_lines="4",
            truncation_limit_chars="160",
        )
        left = [Tracked(i) for i in range(50_000)]
        right = [Tracked(i) for i in range(50_000)]
        right[0] = Tracked(-1)
        Tracked.reprs = 0  # count only the formatting, not the construction
        result = plugin.pytest_assertrepr_compare(config, "==", left, right)
        assert result is not None
        assert len(result) < 20
        assert any("truncated" in line for line in result)
        assert Tracked.reprs < 200  # nowhere near the 50k-element input

    def test_chars_only_budget_still_truncates(self) -> None:
        """With the line limit disabled, the char cap alone still bounds
        the explanation."""
        config = mock_config(
            verbose=1,  # -v: emit the full diff that truncation then clips
            truncation_limit_lines="0",
            truncation_limit_chars="160",
        )
        left = list(range(1000))
        right = list(range(1, 1001))
        result = plugin.pytest_assertrepr_compare(config, "==", left, right)
        assert result is not None
        assert any("truncated" in line for line in result)
        assert sum(len(line) for line in result) < 1000

    def test_lines_only_budget_still_truncates(self) -> None:
        """With the char limit disabled, the line cap alone still bounds
        the explanation."""
        config = mock_config(
            verbose=1,  # -v: emit the full diff that truncation then clips
            truncation_limit_lines="4",
            truncation_limit_chars="0",
        )
        left = list(range(1000))
        right = list(range(1, 1001))
        result = plugin.pytest_assertrepr_compare(config, "==", left, right)
        assert result is not None
        assert len(result) < 20
        assert any("truncated" in line for line in result)

    def test_no_terminalreporter_uses_plaintext_highlighter(self) -> None:
        """Without the terminalreporter plugin the dispatcher uses the
        plaintext highlighter and never touches a terminal writer (#14377)."""
        config = mock_config(has_terminalreporter=False)
        result = plugin.pytest_assertrepr_compare(config, "==", {1, 2}, {1, 3})
        assert result is not None
        assert any("Extra items" in line for line in result)
        assert not any("\x1b[" in line for line in result)


def test_python25_compile_issue257(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_rewritten():
            assert 1 == 2
        # some comment
    """
    )
    result = pytester.runpytest()
    assert result.ret == 1
    result.stdout.fnmatch_lines(
        """
            *E*assert 1 == 2*
            *1 failed*
    """
    )


def test_rewritten(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_rewritten():
            assert "@py_builtins" in globals()
    """
    )
    assert pytester.runpytest().ret == 0


def test_reprcompare_notin() -> None:
    assert callop("not in", "foo", "aaafoobbb") == [
        "'foo' not in 'aaafoobbb'",
        "",
        "'foo' is contained here:",
        "  aaafoobbb",
        "?    +++",
    ]


def test_reprcompare_notin_nontext() -> None:
    # ``not in`` with non-text operands has no specialised explanation.
    assert callop("not in", 1, [1, 2]) is None


def test_reprcompare_notin_long_text() -> None:
    # Long enough surrounding context to make the underlying ``_diff_text`` call
    # emit a "Skipping ... identical leading characters" line, which
    # ``_notin_text`` filters out.
    lines = callop("not in", "x", "a" * 50 + "x")
    assert lines is not None
    assert not any("Skipping" in line for line in lines)


def test_compare_eq_cls_no_comparable_fields() -> None:
    # A dataclass with no compared fields always compares equal, so the
    # comparison hook is never reached via a failed assertion. Call the
    # helper directly to exercise the "nothing to report" path.
    @dataclasses.dataclass
    class NoCompare:
        x: int = dataclasses.field(default=0, compare=False)

    assert (
        list(
            _compare_eq_cls(
                NoCompare(1),
                NoCompare(2),
                util.dummy_highlighter,
                0,
                "ndiff",
            )
        )
        == []
    )


def test_reprcompare_whitespaces() -> None:
    assert callequal("\r\n", "\n") == [
        r"'\r\n' == '\n'",
        "",
        r"Strings contain only whitespace, escaping them using repr()",
        r"- '\n'",
        r"+ '\r\n'",
        r"?  ++",
    ]


class TestSetAssertions:
    @pytest.mark.parametrize("op", [">=", ">", "<=", "<", "=="])
    def test_set_extra_item(self, op, pytester: Pytester) -> None:
        pytester.makepyfile(
            f"""
            def test_hello():
                x = set("hello x")
                y = set("hello y")
                assert x {op} y
        """
        )

        result = pytester.runpytest()
        result.stdout.fnmatch_lines(
            [
                "*def test_hello():*",
                f"*assert x {op} y*",
            ]
        )
        if op in [">=", ">", "=="]:
            result.stdout.fnmatch_lines(
                [
                    "*E*Extra items in the right set:*",
                    "*E*'y'",
                ]
            )
        if op in ["<=", "<", "=="]:
            result.stdout.fnmatch_lines(
                [
                    "*E*Extra items in the left set:*",
                    "*E*'x'",
                ]
            )

    @pytest.mark.parametrize("op", [">", "<", "!="])
    def test_set_proper_superset_equal(self, pytester: Pytester, op) -> None:
        pytester.makepyfile(
            f"""
            def test_hello():
                x = set([1, 2, 3])
                y = x.copy()
                assert x {op} y
        """
        )

        result = pytester.runpytest()
        result.stdout.fnmatch_lines(
            [
                "*def test_hello():*",
                f"*assert x {op} y*",
                "*E*Both sets are equal*",
            ]
        )

    def test_pytest_assertrepr_compare_integration(self, pytester: Pytester) -> None:
        pytester.makepyfile(
            """
            def test_hello():
                x = set(range(100))
                y = x.copy()
                y.remove(50)
                assert x == y
        """
        )
        result = pytester.runpytest()
        result.stdout.fnmatch_lines(
            [
                "*def test_hello():*",
                "*assert x == y*",
                "*E*Extra items*left*",
                "*E*50*",
                "*= 1 failed in*",
            ]
        )

    @pytest.mark.parametrize("op", [">=", "<="])
    def test_dict_items_view_subset(self, op, pytester: Pytester) -> None:
        """dict.items() supports set-like comparisons; assert diff should show the missing items."""
        if op == ">=":
            pytester.makepyfile(
                """
                def test_hello():
                    x = {"a": 1, "b": 2}
                    y = {"a": 1, "b": 2, "c": 3}
                    assert x.items() >= y.items()
            """
            )
        else:
            pytester.makepyfile(
                """
                def test_hello():
                    x = {"a": 1, "b": 2, "c": 3}
                    y = {"a": 1, "b": 2}
                    assert x.items() <= y.items()
            """
            )
        result = pytester.runpytest()
        side = "right" if op == ">=" else "left"
        result.stdout.fnmatch_lines(
            [
                "*def test_hello():*",
                f"*assert x.items() {op} y.items()*",
                f"*E*Extra items in the {side} set:*",
                "*E*('c', 3)*",
            ]
        )


def test_assertrepr_loaded_per_dir(pytester: Pytester) -> None:
    pytester.makepyfile(test_base=["def test_base(): assert 1 == 2"])
    a = pytester.mkdir("a")
    a.joinpath("test_a.py").write_text("def test_a(): assert 1 == 2", encoding="utf-8")
    a.joinpath("conftest.py").write_text(
        'def pytest_assertrepr_compare(): return ["summary a"]', encoding="utf-8"
    )
    b = pytester.mkdir("b")
    b.joinpath("test_b.py").write_text("def test_b(): assert 1 == 2", encoding="utf-8")
    b.joinpath("conftest.py").write_text(
        'def pytest_assertrepr_compare(): return ["summary b"]', encoding="utf-8"
    )

    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        [
            "*def test_a():*",
            "*E*assert summary a*",
            "*def test_b():*",
            "*E*assert summary b*",
            "*def test_base():*",
            "*E*assert 1 == 2*",
        ]
    )


def test_assertion_options(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_hello():
            x = 3
            assert x == 4
    """
    )
    result = pytester.runpytest()
    assert "3 == 4" in result.stdout.str()
    result = pytester.runpytest_subprocess("--assert=plain")
    result.stdout.no_fnmatch_line("*3 == 4*")


def test_triple_quoted_string_issue113(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_hello():
            assert "" == '''
    '''"""
    )
    result = pytester.runpytest("--fulltrace")
    result.stdout.fnmatch_lines(["*1 failed*"])
    result.stdout.no_fnmatch_line("*SyntaxError*")


def test_traceback_failure(pytester: Pytester) -> None:
    p1 = pytester.makepyfile(
        """
        def g():
            return 2
        def f(x):
            assert x == g()
        def test_onefails():
            f(3)
    """
    )
    result = pytester.runpytest(p1, "--tb=long")
    result.stdout.fnmatch_lines(
        [
            "*test_traceback_failure.py F*",
            "====* FAILURES *====",
            "____*____",
            "",
            "    def test_onefails():",
            ">       f(3)",
            "",
            "*test_*.py:6: ",
            "_ _ _ *",
            # "",
            "    def f(x):",
            ">       assert x == g()",
            "E       assert 3 == 2",
            "E        +  where 2 = g()",
            "",
            "*test_traceback_failure.py:4: AssertionError",
        ]
    )

    result = pytester.runpytest(p1)  # "auto"
    result.stdout.fnmatch_lines(
        [
            "*test_traceback_failure.py F*",
            "====* FAILURES *====",
            "____*____",
            "",
            "    def test_onefails():",
            ">       f(3)",
            "",
            "*test_*.py:6: ",
            "",
            "    def f(x):",
            ">       assert x == g()",
            "E       assert 3 == 2",
            "E        +  where 2 = g()",
            "",
            "*test_traceback_failure.py:4: AssertionError",
        ]
    )


def test_exception_handling_no_traceback(pytester: Pytester) -> None:
    """Handle chain exceptions in tasks submitted by the multiprocess module (#1984)."""
    p1 = pytester.makepyfile(
        """
        from multiprocessing import Pool

        def process_task(n):
            assert n == 10

        def multitask_job():
            tasks = [1]
            with Pool(processes=1) as pool:
                pool.map(process_task, tasks)

        def test_multitask_job():
            multitask_job()
    """
    )
    pytester.syspathinsert()
    result = pytester.runpytest(p1, "--tb=long")
    result.stdout.fnmatch_lines(
        [
            "====* FAILURES *====",
            "*multiprocessing.pool.RemoteTraceback:*",
            "Traceback (most recent call last):",
            "*assert n == 10",
            "The above exception was the direct cause of the following exception:",
            "> * multitask_job()",
        ]
    )


@pytest.mark.skipif("'__pypy__' in sys.builtin_module_names")
@pytest.mark.parametrize(
    "cmdline_args, warning_output",
    [
        (
            ["-OO", "-m", "pytest", "-h"],
            ["warning :*PytestConfigWarning:*assert statements are not executed*"],
        ),
        (
            ["-OO", "-m", "pytest"],
            [
                "=*= warnings summary =*=",
                "*PytestConfigWarning:*assert statements are not executed*",
            ],
        ),
        (
            ["-OO", "-m", "pytest", "--assert=plain"],
            [
                "=*= warnings summary =*=",
                "*PytestConfigWarning: ASSERTIONS ARE NOT EXECUTED and FAILING TESTS WILL PASS.  "
                "Are you using python -O?",
            ],
        ),
    ],
)
def test_warn_missing(pytester: Pytester, cmdline_args, warning_output) -> None:
    pytester.makepyfile("")

    result = pytester.run(sys.executable, *cmdline_args)
    result.stdout.fnmatch_lines(warning_output)


def test_recursion_source_decode(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_something():
            pass
    """
    )
    pytester.makeini(
        """
        [pytest]
        python_files = *.py
    """
    )
    result = pytester.runpytest("--collect-only")
    result.stdout.fnmatch_lines(
        [
            "  <Module*>",
        ]
    )


def test_AssertionError_message(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_hello():
            x,y = 1,2
            assert 0, (x,y)
    """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        """
        *def test_hello*
        *assert 0, (x,y)*
        *AssertionError: (1, 2)*
    """
    )


def test_diff_newline_at_end(pytester: Pytester) -> None:
    pytester.makepyfile(
        r"""
        def test_diff():
            assert 'asdf' == 'asdf\n'
    """
    )

    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        r"""
        *assert 'asdf' == 'asdf\n'
        *  - asdf
        *  ?     -
        *  + asdf
    """
    )


@pytest.mark.filterwarnings("default")
def test_assert_tuple_warning(pytester: Pytester) -> None:
    msg = "assertion is always true"
    pytester.makepyfile(
        """
        def test_tuple():
            assert(False, 'you shall not pass')
    """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines([f"*test_assert_tuple_warning.py:2:*{msg}*"])

    # tuples with size != 2 should not trigger the warning
    pytester.makepyfile(
        """
        def test_tuple():
            assert ()
    """
    )
    result = pytester.runpytest()
    assert msg not in result.stdout.str()


def test_assert_indirect_tuple_no_warning(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_tuple():
            tpl = ('foo', 'bar')
            assert tpl
    """
    )
    result = pytester.runpytest()
    output = "\n".join(result.stdout.lines)
    assert "WR1" not in output


def test_assert_with_unicode(pytester: Pytester) -> None:
    pytester.makepyfile(
        """\
        def test_unicode():
            assert '유니코드' == 'Unicode'
        """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(["*AssertionError*"])


def test_raise_unprintable_assertion_error(pytester: Pytester) -> None:
    pytester.makepyfile(
        r"""
        def test_raise_assertion_error():
            raise AssertionError('\xff')
    """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        [r">       raise AssertionError('\xff')", "E       AssertionError: *"]
    )


def test_raise_assertion_error_raising_repr(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        class RaisingRepr(object):
            def __repr__(self):
                raise Exception()
        def test_raising_repr():
            raise AssertionError(RaisingRepr())
    """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(["E       AssertionError: <exception str() failed>"])


def test_issue_1944(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def f():
            return

        assert f() == 10
    """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(["*1 error*"])
    assert (
        "AttributeError: 'Module' object has no attribute '_obj'"
        not in result.stdout.str()
    )


def test_exit_from_assertrepr_compare(monkeypatch) -> None:
    from _pytest.assertion import _compare_any

    def raise_exit(obj):
        outcomes.exit("Quitting debugger")

    monkeypatch.setattr(_compare_any, "istext", raise_exit)

    with pytest.raises(outcomes.Exit, match="Quitting debugger"):
        callequal(1, 1)


def test_plugin_hook_returning_none_is_skipped(pytester: Pytester) -> None:
    """A ``pytest_assertrepr_compare`` impl returning ``None`` is skipped
    so the next impl (or the built-in) can produce the explanation."""
    pytester.makeconftest(
        """
        def pytest_assertrepr_compare(op, left, right):
            # Always defer to the next plugin / the built-in.
            return None
        """
    )
    pytester.makepyfile(
        """
        def test_diff():
            assert {1, 2} == {1, 3}
        """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        ["*Extra items in the left set:*", "*Extra items in the right set:*"]
    )


def test_plugin_hook_returning_empty_iterator_is_skipped(pytester: Pytester) -> None:
    """A plugin returning a truthy but ultimately empty iterable is
    skipped after materialisation."""
    pytester.makeconftest(
        """
        def pytest_assertrepr_compare(op, left, right):
            return iter([])
        """
    )
    pytester.makepyfile(
        """
        def test_diff():
            assert {1, 2} == {1, 3}
        """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(
        ["*Extra items in the left set:*", "*Extra items in the right set:*"]
    )


def test_callbinrepr_falls_through_when_all_hooks_return_none(
    pytester: Pytester,
) -> None:
    """When no ``pytest_assertrepr_compare`` impl produces an explanation,
    the plain assert rewrite is shown."""
    pytester.makepyfile(
        """
        def test_trivial():
            assert 1 == 2
        """
    )
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(["*assert 1 == 2*"])
    result.assert_outcomes(failed=1)


def test_callbinrepr_plain_assert_mode(pytester: Pytester) -> None:
    """In ``--assert=plain`` mode the comparison explanation is still produced."""
    pytester.makepyfile(
        """
        def test_diff():
            assert {1, 2} == {1, 3}
        """
    )
    result = pytester.runpytest("--assert=plain")
    result.stdout.fnmatch_lines(
        ["*Extra items in the left set:*", "*Extra items in the right set:*"]
    )


def test_exception_before_first_yield_emits_summary_and_notice(monkeypatch) -> None:
    """A comparator raising before any explanation line is yielded still
    produces the summary, followed by the failure notice."""
    from _pytest.assertion import _compare_any

    def raise_value_error(obj):
        raise ValueError("synthetic repr failure")

    # ``istext`` is called before the first yield, so this triggers the
    # failure path on the very first ``next()``.
    monkeypatch.setattr(_compare_any, "istext", raise_value_error)

    expl = callequal(1, 1)
    assert expl is not None
    assert expl[0] == "1 == 1"
    # Wording deliberately not asserted, only the underlying error's signature.
    assert any("ValueError" in line or "synthetic" in line for line in expl)


def test_assertion_location_with_coverage(pytester: Pytester) -> None:
    """This used to report the wrong location when run with coverage (#5754)."""
    p = pytester.makepyfile(
        """
        def test():
            assert False, 1
            assert False, 2
        """
    )
    result = pytester.runpytest(str(p))
    result.stdout.fnmatch_lines(
        [
            ">       assert False, 1",
            "E       AssertionError: 1",
            "E       assert False",
            "*= 1 failed in*",
        ]
    )


def test_reprcompare_verbose_long() -> None:
    a = {f"v{i}": i for i in range(11)}
    b = a.copy()
    b["v2"] += 10
    lines = callop("==", a, b, verbose=2)
    assert lines is not None
    assert lines[0] == (
        "{'v0': 0, 'v1': 1, 'v2': 2, 'v3': 3, 'v4': 4, 'v5': 5, "
        "'v6': 6, 'v7': 7, 'v8': 8, 'v9': 9, 'v10': 10}"
        " == "
        "{'v0': 0, 'v1': 1, 'v2': 12, 'v3': 3, 'v4': 4, 'v5': 5, "
        "'v6': 6, 'v7': 7, 'v8': 8, 'v9': 9, 'v10': 10}"
    )


@pytest.mark.parametrize("enable_colors", [True, False])
@pytest.mark.parametrize(
    ("test_code", "expected_lines"),
    (
        (
            """
            def test():
                assert [0, 1] == [0, 2]
            """,
            [
                "{bold}{red}E         At index 1 diff: {reset}{number}1{hl-reset}{endline} != {reset}{number}2*",
                "{bold}{red}E         {reset}{light-red}-     2,{hl-reset}{endline}{reset}",
                "{bold}{red}E         {reset}{light-green}+     1,{hl-reset}{endline}{reset}",
            ],
        ),
        (
            """
            def test():
                assert {f"number-is-{i}": i for i in range(1, 6)} == {
                    f"number-is-{i}": i for i in range(5)
                }
            """,
            [
                "{bold}{red}E         Common items:{reset}",
                "{bold}{red}E         {reset}{{{str}'{hl-reset}{str}number-is-1{hl-reset}{str}'{hl-reset}: {number}1*",
                "{bold}{red}E         Left contains 1 more item:{reset}",
                "{bold}{red}E         {reset}{{{str}'{hl-reset}{str}number-is-5{hl-reset}{str}'{hl-reset}: {number}5*",
                "{bold}{red}E         Right contains 1 more item:{reset}",
                "{bold}{red}E         {reset}{{{str}'{hl-reset}{str}number-is-0{hl-reset}{str}'{hl-reset}: {number}0*",
                "{bold}{red}E         {reset}{light-gray} {hl-reset} {{{endline}{reset}",
                "{bold}{red}E         {reset}{light-gray} {hl-reset}     'number-is-1': 1,{endline}{reset}",
                "{bold}{red}E         {reset}{light-green}+     'number-is-5': 5,{hl-reset}{endline}{reset}",
            ],
        ),
        (
            """
            def test():
                assert "abcd" == "abce"
            """,
            [
                "{bold}{red}E         {reset}{light-red}- abce{hl-reset}{endline}{reset}",
                "{bold}{red}E         {light-green}+ abcd{hl-reset}{endline}{reset}",
            ],
        ),
    ),
)
def test_comparisons_handle_colors(
    pytester: Pytester, color_mapping, enable_colors, test_code, expected_lines
) -> None:
    p = pytester.makepyfile(test_code)
    result = pytester.runpytest(
        f"--color={'yes' if enable_colors else 'no'}", "-vv", str(p)
    )
    formatter = (
        color_mapping.format_for_fnmatch
        if enable_colors
        else color_mapping.strip_colors
    )

    result.stdout.fnmatch_lines(formatter(expected_lines), consecutive=False)


def test_fine_grained_assertion_verbosity(pytester: Pytester):
    long_text = "Lorem ipsum dolor sit amet " * 10
    p = pytester.makepyfile(
        f"""
        def test_ok():
            pass


        def test_words_fail():
            fruits1 = ["banana", "apple", "grapes", "melon", "kiwi"]
            fruits2 = ["banana", "apple", "orange", "melon", "kiwi"]
            assert fruits1 == fruits2


        def test_numbers_fail():
            number_to_text1 = {{str(x): x for x in range(5)}}
            number_to_text2 = {{str(x * 10): x * 10 for x in range(5)}}
            assert number_to_text1 == number_to_text2


        def test_long_text_fail():
            long_text = "{long_text}"
            assert "hello world" in long_text
        """
    )
    pytester.makeini(
        """
        [pytest]
        verbosity_assertions = 2
        """
    )
    result = pytester.runpytest(p)

    result.stdout.fnmatch_lines(
        [
            f"{p.name} .FFF                            [100%]",
            "E         At index 2 diff: 'grapes' != 'orange'",
            "E         Full diff: (-: missing in left side, +: extra in left side)",
            "E           [",
            "E               'banana',",
            "E               'apple',",
            "E         -     'orange',",
            "E         ?      ^  ^^",
            "E         +     'grapes',",
            "E         ?      ^  ^ +",
            "E               'melon',",
            "E               'kiwi',",
            "E           ]",
            "E         Full diff: (-: missing in left side, +: extra in left side)",
            "E           {",
            "E               '0': 0,",
            "E         -     '10': 10,",
            "E         ?       -    -",
            "E         +     '1': 1,",
            "E         -     '20': 20,",
            "E         ?       -    -",
            "E         +     '2': 2,",
            "E         -     '30': 30,",
            "E         ?       -    -",
            "E         +     '3': 3,",
            "E         -     '40': 40,",
            "E         ?       -    -",
            "E         +     '4': 4,",
            "E           }",
            f"E       AssertionError: assert 'hello world' in '{long_text}'",
        ]
    )


def test_assertion_text_diff_style_block_for_multiline_strings(
    pytester: Pytester,
) -> None:
    pytester.makepyfile(
        r"""
        actual = "alpha\n  beta\n"
        expected = "alpha\n    beta"

        def test_text_diff():
            assert actual == expected
        """
    )
    pytester.makeini(
        """
        [pytest]
        assertion_text_diff_style = block
        """
    )

    result = pytester.runpytest("-vv")

    result.stdout.fnmatch_lines(
        [
            "E         Left:",
            "E           alpha",
            "E             beta",
            "E           ",
            "E         Right:",
            "E           alpha",
            "E               beta",
        ]
    )
    result.stdout.no_fnmatch_line("*?     -*")


def test_assertion_text_diff_style_block_for_single_line_strings(
    pytester: Pytester,
) -> None:
    pytester.makepyfile(
        """
        def test_text_diff():
            assert "spam" == "eggs"
        """
    )
    pytester.makeini(
        """
        [pytest]
        assertion_text_diff_style = block
        """
    )

    result = pytester.runpytest("-vv")

    result.stdout.fnmatch_lines(
        [
            "E         Left:",
            "E           spam",
            "E         Right:",
            "E           eggs",
        ]
    )
    result.stdout.no_fnmatch_line("*- eggs*")


def test_assertion_text_diff_style_invalid(pytester: Pytester) -> None:
    pytester.makepyfile(
        """
        def test_ok():
            pass
        """
    )
    pytester.makeini(
        """
        [pytest]
        assertion_text_diff_style = side-by-side
        """
    )

    result = pytester.runpytest()

    assert result.ret == pytest.ExitCode.USAGE_ERROR
    result.stderr.fnmatch_lines(
        [
            "*ERROR: *: config option 'assertion_text_diff_style' expects one of "
            "'ndiff' | 'block', got 'side-by-side'"
        ]
    )


def test_full_output_vvv(pytester: Pytester) -> None:
    pytester.makepyfile(
        r"""
        def crash_helper(m):
            assert 1 == 2
        def test_vvv():
            crash_helper(500 * "a")
    """
    )
    result = pytester.runpytest("")
    # without -vvv, the passed args are truncated
    expected_non_vvv_arg_line = "m = 'aaaaaaaaaaaaaaa*..aaaaaaaaaaaa*"
    result.stdout.fnmatch_lines(
        [
            expected_non_vvv_arg_line,
            "test_full_output_vvv.py:2: AssertionError",
        ],
    )
    # double check that the untruncated part is not in the output
    expected_vvv_arg_line = "m = '{}'".format(500 * "a")
    result.stdout.no_fnmatch_line(expected_vvv_arg_line)

    # but with "-vvv" the args are not truncated
    result = pytester.runpytest("-vvv")
    result.stdout.fnmatch_lines(
        [
            expected_vvv_arg_line,
            "test_full_output_vvv.py:2: AssertionError",
        ]
    )
    result.stdout.no_fnmatch_line(expected_non_vvv_arg_line)


def test_dict_extra_items_preserve_insertion_order(pytester: Pytester) -> None:
    """Assertion output of dict diff shows keys in insertion order (#13503)."""
    pytester.makepyfile(
        test_order="""
        def test_order():
            a = {
                "b": 2,
                "a": 1,
                "d": 4,
                "e": 5,
                "c": 3,
            }
            assert a == {}
        """
    )

    result = pytester.runpytest("-vv")
    result.stdout.fnmatch_lines(
        [
            "*Left contains 5 more items:*",
            "*Full diff: (-: missing in left side, +: extra in left side)",
            "* + *'b': 2,",
            "* + *'a': 1,",
            "* + *'d': 4,",
            "* + *'e': 5,",
            "* + *'c': 3,",
            "test_order.py:*: AssertionError",
        ]
    )
