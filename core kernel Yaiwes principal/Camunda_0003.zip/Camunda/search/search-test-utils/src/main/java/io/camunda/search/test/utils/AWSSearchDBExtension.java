/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.test.utils;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.camunda.search.connect.configuration.ConnectConfiguration;
import io.camunda.search.connect.os.OpensearchConnector;
import java.time.Duration;
import java.util.UUID;
import org.agrona.CloseHelper;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.opensearch._types.ExpandWildcard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * {@code AWSSearchDBExtension} is an extension that manages an AWS-based OpenSearch instance,
 * creates and configures respective client, and provides a client for interaction for usage in
 * tests.
 *
 * <p>To use this extension, preconditions from {@link SearchDBExtension} must be met.
 *
 * <p>This extension fetches the AWS URL from the {@link
 * SearchDBExtension#TEST_INTEGRATION_OPENSEARCH_AWS_URL} argument.
 *
 * <p>This extension uses the {@link
 * software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider} for implicit authentication.
 *
 * <p>This extension always returns `null` for all ElasticSearch related methods, meaning test
 * maintainer has to make sure it won't fail on a CI.
 */
public class AWSSearchDBExtension extends SearchDBExtension {

  private static final Logger LOGGER = LoggerFactory.getLogger(AWSSearchDBExtension.class);

  private static OpenSearchClient osClient;

  private final String osUrl;
  private final Duration dataAvailabilityTimeout;
  private ObjectMapper objectMapper;

  public AWSSearchDBExtension(
      final String openSearchAwsInstanceUrl, final Duration dataAvailabilityTimeout) {
    osUrl = openSearchAwsInstanceUrl;
    this.dataAvailabilityTimeout = dataAvailabilityTimeout;
  }

  @Override
  public void beforeAll(final ExtensionContext context) throws Exception {
    final var osConfig = new ConnectConfiguration();
    osConfig.setType("opensearch");
    osConfig.setUrl(osUrl);
    osConfig.setIndexPrefix("test-" + UUID.randomUUID());
    osConfig.setAwsEnabled(true);
    final var connector = new OpensearchConnector(osConfig);
    objectMapper = connector.objectMapper();
    osClient = connector.createClient();
  }

  /** {@inheritDoc} */
  @Override
  public ObjectMapper objectMapper() {
    return objectMapper;
  }

  /** {@inheritDoc} */
  @Override
  public ElasticsearchClient esClient() {
    return null;
  }

  /** {@inheritDoc} */
  @Override
  public OpenSearchClient osClient() {
    return osClient;
  }

  /** {@inheritDoc} */
  @Override
  public String esUrl() {
    return null;
  }

  /** {@inheritDoc} */
  @Override
  public String osUrl() {
    return osUrl;
  }

  @Override
  public boolean isAws() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public Duration dataAvailabilityTimeout() {
    return dataAvailabilityTimeout;
  }

  @Override
  public void afterAll(final ExtensionContext context) throws Exception {
    final String[] prefixes = {
      IDX_FORM_PREFIX,
      CUSTOM_PREFIX,
      IDX_PROCESS_PREFIX,
      ZEEBE_IDX_PREFIX,
      ARCHIVER_IDX_PREFIX,
      BATCH_IDX_PREFIX,
      INCIDENT_IDX_PREFIX,
      IDX_DECISIONREQUIREMENTS_PREFIX,
      IDX_BATCH_OPERATION_PREFIX,
      HISTORY_DELETION_ID_PREFIX,
    };

    CloseHelper.quietCloseAll(
        () -> {
          for (final String prefix : prefixes) {
            deleteIndicesQuietly(prefix + "*");
            deleteIndexTemplatesQuietly(prefix + "*");
          }
          deleteIndicesQuietly("*" + ENGINE_CLIENT_TEST_MARKERS + "*");
          deleteIndexTemplatesQuietly("*" + ENGINE_CLIENT_TEST_MARKERS + "*");
        },
        () -> osClient._transport().close());
  }

  private void deleteIndicesQuietly(final String pattern) {
    try {
      osClient
          .indices()
          .delete(
              req ->
                  req.index(pattern)
                      .ignoreUnavailable(true)
                      .allowNoIndices(true)
                      .expandWildcards(ExpandWildcard.Open));
    } catch (final Exception e) {
      LOGGER.warn("Failed to delete indices matching {}", pattern, e);
    }
  }

  private void deleteIndexTemplatesQuietly(final String pattern) {
    try {
      osClient.indices().deleteIndexTemplate(req -> req.name(pattern));
    } catch (final Exception e) {
      LOGGER.warn("Failed to delete index templates matching {}", pattern, e);
    }
  }
}
