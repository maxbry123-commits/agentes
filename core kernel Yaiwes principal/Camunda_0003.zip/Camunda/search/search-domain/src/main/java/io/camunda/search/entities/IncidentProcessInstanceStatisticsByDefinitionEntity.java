/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.camunda.util.ObjectBuilder;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

@JsonIgnoreProperties(ignoreUnknown = true)
public record IncidentProcessInstanceStatisticsByDefinitionEntity(
    // cache-enriched; null on cache miss.
    @Nullable String processDefinitionId,
    Long processDefinitionKey,
    // cache-enriched; null on cache miss.
    @Nullable String processDefinitionName,
    // cache-enriched; null on cache miss.
    @Nullable Integer processDefinitionVersion,
    // cache-enriched; null on cache miss.
    @Nullable String tenantId,
    Long activeInstancesWithErrorCount) {

  public IncidentProcessInstanceStatisticsByDefinitionEntity {
    Objects.requireNonNull(processDefinitionKey, "processDefinitionKey");
    Objects.requireNonNull(activeInstancesWithErrorCount, "activeInstancesWithErrorCount");
  }

  public static final class Builder
      implements ObjectBuilder<IncidentProcessInstanceStatisticsByDefinitionEntity> {
    private @Nullable String processDefinitionId;
    private @Nullable Long processDefinitionKey;
    private @Nullable String processDefinitionName;
    private @Nullable Integer processDefinitionVersion;
    private @Nullable String tenantId;
    private @Nullable Long activeInstancesWithErrorCount;

    public Builder processDefinitionId(final String value) {
      processDefinitionId = value;
      return this;
    }

    public Builder processDefinitionKey(final Long value) {
      processDefinitionKey = value;
      return this;
    }

    public Builder processDefinitionName(final String value) {
      processDefinitionName = value;
      return this;
    }

    public Builder processDefinitionVersion(final Integer value) {
      processDefinitionVersion = value;
      return this;
    }

    public Builder tenantId(final String value) {
      tenantId = value;
      return this;
    }

    public Builder activeInstancesWithErrorCount(final Long value) {
      activeInstancesWithErrorCount = value;
      return this;
    }

    @SuppressWarnings("NullAway")
    @Override
    public IncidentProcessInstanceStatisticsByDefinitionEntity build() {
      return new IncidentProcessInstanceStatisticsByDefinitionEntity(
          processDefinitionId,
          processDefinitionKey,
          processDefinitionName,
          processDefinitionVersion,
          tenantId,
          activeInstancesWithErrorCount);
    }
  }
}
