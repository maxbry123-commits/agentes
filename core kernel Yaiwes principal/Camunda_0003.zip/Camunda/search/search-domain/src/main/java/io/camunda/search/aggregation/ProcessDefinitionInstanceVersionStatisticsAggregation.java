/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.aggregation;

import io.camunda.search.filter.ProcessDefinitionInstanceVersionStatisticsFilter;
import io.camunda.search.page.SearchQueryPage;
import io.camunda.search.query.AggregationPaginated;
import io.camunda.search.sort.ProcessDefinitionInstanceVersionStatisticsSort;

public record ProcessDefinitionInstanceVersionStatisticsAggregation(
    ProcessDefinitionInstanceVersionStatisticsFilter filter,
    ProcessDefinitionInstanceVersionStatisticsSort sort,
    SearchQueryPage page)
    implements AggregationBase, AggregationPaginated {

  public static final int AGGREGATION_TERMS_SIZE = 10000;
  public static final String AGGREGATION_NAME_BY_VERSION_TENANT = "by_version_tenant";
  public static final String AGGREGATION_NAME_PAGE = "page";
  public static final String AGGREGATION_FIELD_PROCESS_DEFINITION_ID = "processDefinitionId";
  public static final String AGGREGATION_FIELD_KEY = "_key";
  public static final String AGGREGATION_NAME_PROCESS_DEFINITION_VERSION =
      "processDefinitionVersion";
  public static final String AGGREGATION_NAME_TOTAL_WITH_INCIDENT =
      "activeInstancesWithIncidentCount";
  public static final String AGGREGATION_NAME_TOTAL_WITHOUT_INCIDENT =
      "activeInstancesWithoutIncidentCount";
  public static final String AGGREGATION_NAME_VERSION_CARDINALITY = "versionCardinality";
  public static final String AGG_MAX_PROCESS_DEFINITION_KEY = "maxProcessDefinitionKey";
  public static final String AGG_MAX_PROCESS_VERSION = "maxProcessVersion";
  public static final String AGGREGATION_FIELD_PROCESS_DEFINITION_KEY = "processDefinitionKey";
  public static final String AGGREGATION_FIELD_PROCESS_DEFINITION_NAME = "processDefinitionName";
  public static final String PROCESS_DEFINITION_AND_TENANT_KEY =
      "doc['processName'].value + '::' + doc['processVersion'].value + '::' + doc['tenantId'].value";
}
