/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.entities;

public sealed interface WaitStateDetails
    permits WaitStateJobDetails,
        WaitStateMessageDetails,
        WaitStateUserTaskDetails,
        WaitStateTimerDetails,
        WaitStateSignalDetails,
        WaitStateConditionDetails {

  WaitStateType waitStateType();

  enum WaitStateType {
    JOB,
    MESSAGE,
    USER_TASK,
    TIMER,
    SIGNAL,
    CONDITION
  }
}
