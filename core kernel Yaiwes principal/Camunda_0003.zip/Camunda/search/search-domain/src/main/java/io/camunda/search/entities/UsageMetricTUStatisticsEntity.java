/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.entities;

import io.camunda.util.ObjectBuilder;
import java.util.HashMap;
import java.util.Map;
import org.jspecify.annotations.Nullable;

public record UsageMetricTUStatisticsEntity(
    long totalTu, Map<String, UsageMetricTUStatisticsEntityTenant> tenants) {

  public UsageMetricTUStatisticsEntity(
      final long totalTu,
      final @Nullable Map<String, UsageMetricTUStatisticsEntityTenant> tenants) {
    this.totalTu = totalTu;
    // Mutable collections are required: MyBatis hydrates collection-mapped fields (e.g. from a
    // <collection> result map or a LEFT JOIN) by calling .add() on the existing instance.
    // Immutable defaults (e.g. Map.of()) would cause UnsupportedOperationException at runtime.
    this.tenants = tenants != null ? tenants : new HashMap<>();
  }

  public record UsageMetricTUStatisticsEntityTenant(long tu) {

    public static class Builder implements ObjectBuilder<UsageMetricTUStatisticsEntityTenant> {

      private long tu = 0;

      public UsageMetricTUStatisticsEntityTenant.Builder tu(final long tu) {
        this.tu = tu;
        return this;
      }

      @Override
      public UsageMetricTUStatisticsEntityTenant build() {
        return new UsageMetricTUStatisticsEntityTenant(tu);
      }
    }
  }
}
