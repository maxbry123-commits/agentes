/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.camunda.security.core.authz.TenantOwnedEntity;
import java.util.Objects;

@JsonIgnoreProperties(ignoreUnknown = true)
public record FormEntity(Long formKey, String tenantId, String formId, String schema, Long version)
    implements TenantOwnedEntity {

  public FormEntity {
    Objects.requireNonNull(formKey, "formKey");
    Objects.requireNonNull(tenantId, "tenantId");
    Objects.requireNonNull(formId, "formId");
    Objects.requireNonNull(schema, "schema");
    Objects.requireNonNull(version, "version");
  }
}
