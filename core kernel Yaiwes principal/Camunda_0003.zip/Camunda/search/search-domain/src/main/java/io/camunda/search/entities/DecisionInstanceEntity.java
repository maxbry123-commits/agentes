/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.entities;

import io.camunda.security.core.authz.TenantOwnedEntity;
import io.camunda.util.ObjectBuilder;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

public record DecisionInstanceEntity(
    String decisionInstanceId, // this is the unique identifier of the decision instance
    Long decisionInstanceKey,
    DecisionInstanceState state,
    OffsetDateTime evaluationDate,
    @Nullable String evaluationFailure,
    @Nullable String evaluationFailureMessage,
    @Nullable Long processDefinitionKey,
    @Nullable Long processInstanceKey,
    @Nullable Long rootProcessInstanceKey,
    @Nullable String businessId,
    @Nullable Long flowNodeInstanceKey,
    String tenantId,
    String decisionDefinitionId,
    Long decisionDefinitionKey,
    String decisionDefinitionName,
    // null in legacy/partially-migrated rows.
    @Nullable Integer decisionDefinitionVersion,
    DecisionDefinitionType decisionDefinitionType,
    @Nullable Long rootDecisionDefinitionKey,
    String result,
    List<DecisionInstanceInputEntity> evaluatedInputs,
    List<DecisionInstanceOutputEntity> evaluatedOutputs)
    implements TenantOwnedEntity {

  public DecisionInstanceEntity {
    Objects.requireNonNull(decisionInstanceId, "decisionInstanceId");
    Objects.requireNonNull(decisionInstanceKey, "decisionInstanceKey");
    Objects.requireNonNull(state, "state");
    Objects.requireNonNull(evaluationDate, "evaluationDate");
    Objects.requireNonNull(tenantId, "tenantId");
    Objects.requireNonNull(decisionDefinitionId, "decisionDefinitionId");
    Objects.requireNonNull(decisionDefinitionKey, "decisionDefinitionKey");
    Objects.requireNonNull(decisionDefinitionName, "decisionDefinitionName");
    Objects.requireNonNull(decisionDefinitionType, "decisionDefinitionType");
    Objects.requireNonNull(result, "result");
    // Mutable collections are required: MyBatis hydrates collection-mapped fields (e.g. from a
    // <collection> result map or a LEFT JOIN) by calling .add() on the existing instance.
    // Immutable defaults (e.g. List.of()) would cause UnsupportedOperationException at runtime.
    evaluatedInputs = evaluatedInputs != null ? evaluatedInputs : new ArrayList<>();
    evaluatedOutputs = evaluatedOutputs != null ? evaluatedOutputs : new ArrayList<>();
  }

  public Builder toBuilder() {
    return new Builder()
        .decisionInstanceId(decisionInstanceId)
        .decisionInstanceKey(decisionInstanceKey)
        .state(state)
        .evaluationDate(evaluationDate)
        .evaluationFailure(evaluationFailure)
        .evaluationFailureMessage(evaluationFailureMessage)
        .processDefinitionKey(processDefinitionKey)
        .processInstanceKey(processInstanceKey)
        .rootProcessInstanceKey(rootProcessInstanceKey)
        .businessId(businessId)
        .flowNodeInstanceKey(flowNodeInstanceKey)
        .decisionDefinitionKey(decisionDefinitionKey)
        .decisionDefinitionId(decisionDefinitionId)
        .decisionDefinitionName(decisionDefinitionName)
        .decisionDefinitionVersion(decisionDefinitionVersion)
        .decisionDefinitionType(decisionDefinitionType)
        .rootDecisionDefinitionKey(rootDecisionDefinitionKey)
        .tenantId(tenantId)
        .result(result)
        .evaluatedInputs(evaluatedInputs)
        .evaluatedOutputs(evaluatedOutputs);
  }

  public static class Builder implements ObjectBuilder<DecisionInstanceEntity> {

    private @Nullable String decisionInstanceId;
    private @Nullable Long decisionInstanceKey;
    private @Nullable DecisionInstanceState state;
    private @Nullable OffsetDateTime evaluationDate;
    private @Nullable String evaluationFailure;
    private @Nullable String evaluationFailureMessage;
    private @Nullable Long processDefinitionKey;
    private @Nullable Long processInstanceKey;
    private @Nullable Long rootProcessInstanceKey;
    private @Nullable String businessId;
    private @Nullable Long flowNodeInstanceKey;
    private @Nullable String tenantId;
    private @Nullable String decisionDefinitionId;
    private @Nullable Long decisionDefinitionKey;
    private @Nullable String decisionDefinitionName;
    private @Nullable Integer decisionDefinitionVersion;
    private @Nullable DecisionDefinitionType decisionDefinitionType;
    private @Nullable Long rootDecisionDefinitionKey;
    private @Nullable String result;
    private @Nullable List<DecisionInstanceInputEntity> evaluatedInputs;
    private @Nullable List<DecisionInstanceOutputEntity> evaluatedOutputs;

    public Builder decisionInstanceId(final String decisionInstanceId) {
      this.decisionInstanceId = decisionInstanceId;
      return this;
    }

    public Builder decisionInstanceKey(final Long decisionInstanceKey) {
      this.decisionInstanceKey = decisionInstanceKey;
      return this;
    }

    public Builder state(final DecisionInstanceState state) {
      this.state = state;
      return this;
    }

    public Builder evaluationDate(final OffsetDateTime evaluationDate) {
      this.evaluationDate = evaluationDate;
      return this;
    }

    public Builder evaluationFailure(final @Nullable String evaluationFailure) {
      this.evaluationFailure = evaluationFailure;
      return this;
    }

    public Builder evaluationFailureMessage(final @Nullable String evaluationFailureMessage) {
      this.evaluationFailureMessage = evaluationFailureMessage;
      return this;
    }

    public Builder processDefinitionKey(final @Nullable Long processDefinitionKey) {
      this.processDefinitionKey = processDefinitionKey;
      return this;
    }

    public Builder processInstanceKey(final @Nullable Long processInstanceKey) {
      this.processInstanceKey = processInstanceKey;
      return this;
    }

    public Builder rootProcessInstanceKey(final @Nullable Long rootProcessInstanceKey) {
      this.rootProcessInstanceKey = rootProcessInstanceKey;
      return this;
    }

    public Builder businessId(final @Nullable String businessId) {
      this.businessId = businessId;
      return this;
    }

    public Builder flowNodeInstanceKey(final @Nullable Long flowNodeInstanceKey) {
      this.flowNodeInstanceKey = flowNodeInstanceKey;
      return this;
    }

    public Builder tenantId(final String tenantId) {
      this.tenantId = tenantId;
      return this;
    }

    public Builder decisionDefinitionId(final String decisionDefinitionId) {
      this.decisionDefinitionId = decisionDefinitionId;
      return this;
    }

    public Builder decisionDefinitionKey(final Long decisionDefinitionKey) {
      this.decisionDefinitionKey = decisionDefinitionKey;
      return this;
    }

    public Builder decisionDefinitionName(final String decisionDefinitionName) {
      this.decisionDefinitionName = decisionDefinitionName;
      return this;
    }

    public Builder decisionDefinitionVersion(final @Nullable Integer decisionDefinitionVersion) {
      this.decisionDefinitionVersion = decisionDefinitionVersion;
      return this;
    }

    public Builder decisionDefinitionType(final DecisionDefinitionType decisionDefinitionType) {
      this.decisionDefinitionType = decisionDefinitionType;
      return this;
    }

    public Builder rootDecisionDefinitionKey(final @Nullable Long rootDecisionDefinitionKey) {
      this.rootDecisionDefinitionKey = rootDecisionDefinitionKey;
      return this;
    }

    public Builder result(final String result) {
      this.result = result;
      return this;
    }

    public Builder evaluatedInputs(final List<DecisionInstanceInputEntity> evaluatedInputs) {
      this.evaluatedInputs = evaluatedInputs;
      return this;
    }

    public Builder evaluatedOutputs(final List<DecisionInstanceOutputEntity> evaluatedOutputs) {
      this.evaluatedOutputs = evaluatedOutputs;
      return this;
    }

    @SuppressWarnings("NullAway")
    @Override
    public DecisionInstanceEntity build() {
      return new DecisionInstanceEntity(
          decisionInstanceId,
          decisionInstanceKey,
          state,
          evaluationDate,
          evaluationFailure,
          evaluationFailureMessage,
          processDefinitionKey,
          processInstanceKey,
          rootProcessInstanceKey,
          businessId,
          flowNodeInstanceKey,
          tenantId,
          decisionDefinitionId,
          decisionDefinitionKey,
          decisionDefinitionName,
          decisionDefinitionVersion,
          decisionDefinitionType,
          rootDecisionDefinitionKey,
          result,
          evaluatedInputs,
          evaluatedOutputs);
    }
  }

  public record DecisionInstanceInputEntity(
      @Nullable String inputId, @Nullable String inputName, @Nullable String inputValue) {}

  public record DecisionInstanceOutputEntity(
      @Nullable String outputId,
      @Nullable String outputName,
      @Nullable String outputValue,
      @Nullable String ruleId,
      int ruleIndex) {}

  public enum DecisionDefinitionType {
    DECISION_TABLE,
    LITERAL_EXPRESSION,
    UNSPECIFIED,
    UNKNOWN;

    public static DecisionDefinitionType fromValue(final String value) {
      for (final DecisionDefinitionType b : DecisionDefinitionType.values()) {
        if (b.name().equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  public enum DecisionInstanceState {
    EVALUATED,
    FAILED,
    UNKNOWN,
    UNSPECIFIED;

    public static DecisionInstanceState fromValue(final String value) {
      for (final DecisionInstanceState b : DecisionInstanceState.values()) {
        if (b.name().equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }
}
