/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.search.clients.transformers.filter;

import static io.camunda.search.clients.query.SearchQueryBuilders.and;
import static io.camunda.search.clients.query.SearchQueryBuilders.hasParentQuery;
import static io.camunda.search.clients.query.SearchQueryBuilders.stringTerms;
import static io.camunda.search.clients.query.SearchQueryBuilders.term;
import static io.camunda.webapps.schema.descriptors.index.TenantIndex.TENANT_ID;

import io.camunda.search.clients.query.SearchQuery;
import io.camunda.search.filter.TenantMemberFilter;
import io.camunda.security.core.auth.RequiredAuthorization;
import io.camunda.webapps.schema.descriptors.IndexDescriptor;
import io.camunda.webapps.schema.descriptors.index.TenantIndex;
import io.camunda.webapps.schema.entities.usermanagement.EntityJoinRelation.IdentityJoinRelationshipType;

public class TenantMemberFilterTransformer extends IndexFilterTransformer<TenantMemberFilter> {

  public TenantMemberFilterTransformer(final IndexDescriptor indexDescriptor) {
    super(indexDescriptor);
  }

  @Override
  public SearchQuery toSearchQuery(final TenantMemberFilter filter) {
    return and(
        filter.tenantId() == null
            ? term(TenantIndex.JOIN, IdentityJoinRelationshipType.TENANT.getType())
            : hasParentQuery(
                IdentityJoinRelationshipType.TENANT.getType(), term(TENANT_ID, filter.tenantId())),
        filter.entityType() == null
            ? null
            : term(TenantIndex.MEMBER_TYPE, filter.entityType().name()));
  }

  @Override
  protected SearchQuery toAuthorizationCheckSearchQuery(
      final RequiredAuthorization<?> authorization) {
    return hasParentQuery(
        IdentityJoinRelationshipType.TENANT.getType(),
        stringTerms(TENANT_ID, authorization.resourceIds()));
  }
}
