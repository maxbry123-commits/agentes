module github.com/casbin/casbin/v3

require (
	github.com/bmatcuk/doublestar/v4 v4.6.1
	github.com/casbin/govaluate v1.3.0
	github.com/google/uuid v1.6.0
)

go 1.13
