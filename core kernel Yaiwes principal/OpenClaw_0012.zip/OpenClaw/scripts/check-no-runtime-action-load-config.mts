#!/usr/bin/env node
// Prevents runtime action paths from loading global config directly.
import { collectRuntimeActionLoadConfigViolations } from "./lib/config-boundary-guard.mts";

function main() {
  const violations = collectRuntimeActionLoadConfigViolations();
  if (violations.length === 0) {
    return 0;
  }
  console.error(
    [
      "Runtime channel send/action/client/pairing helpers must not call loadConfig().",
      "Load and resolve config at the command/gateway/monitor boundary, then pass cfg through.",
      "",
      ...violations,
    ].join("\n"),
  );
  return 1;
}

process.exitCode = main();
