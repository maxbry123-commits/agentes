#!/usr/bin/env bash
set -euo pipefail
source scripts/lib/openclaw-e2e-instance.sh
openclaw_e2e_eval_test_state_from_b64 "${OPENCLAW_TEST_STATE_FUNCTION_B64:?missing OPENCLAW_TEST_STATE_FUNCTION_B64}"

# Keep logs focused; the npm global install step can emit noisy deprecation warnings.
export npm_config_loglevel=error
export npm_config_fund=false
export npm_config_audit=false
export OPENCLAW_DISABLE_BUNDLED_PLUGINS=1

package_tgz="${OPENCLAW_CURRENT_PACKAGE_TGZ:?missing OPENCLAW_CURRENT_PACKAGE_TGZ}"
git_root="/tmp/openclaw-git"
mkdir -p "$git_root"
# The git-style install fixture is unpacked from the tarball so this lane does
# not depend on checkout source files being present in the Docker image.
tar -xzf "$package_tgz" -C "$git_root" --strip-components=1
node scripts/e2e/lib/package-git-fixture.mjs prepare "$git_root"
(
  cd "$git_root"
  # Git-style fixtures still need optional native prebuilds; omit only development dependencies.
  if ! openclaw_e2e_maybe_timeout "${OPENCLAW_E2E_NPM_INSTALL_TIMEOUT:-600s}" npm install --omit=dev --no-fund --no-audit >/tmp/openclaw-git-install.log 2>&1; then
    openclaw_e2e_print_log /tmp/openclaw-git-install.log >&2
    exit 1
  fi
  git init -q
  git config user.email "docker-e2e@openclaw.local"
  git config user.name "OpenClaw Docker E2E"
  git add -A --
  git commit -qm "test fixture"
)
npm_log="/tmp/openclaw-doctor-switch-npm-install.log"
if ! openclaw_e2e_maybe_timeout "${OPENCLAW_E2E_NPM_INSTALL_TIMEOUT:-600s}" npm install -g --prefix /tmp/npm-prefix --omit=optional "$package_tgz" >"$npm_log" 2>&1; then
  openclaw_e2e_print_log "$npm_log"
  exit 1
fi

npm_bin="/tmp/npm-prefix/bin/openclaw"
npm_root="/tmp/npm-prefix/lib/node_modules/openclaw"
export OPENCLAW_E2E_REDACTOR_MODULE="$npm_root/dist/plugin-sdk/logging-core.js"
if [ -f "$npm_root/dist/index.mjs" ]; then
  npm_entry="$npm_root/dist/index.mjs"
else
  npm_entry="$npm_root/dist/index.js"
fi

if [ -f "$git_root/dist/index.mjs" ]; then
  git_entry="$git_root/dist/index.mjs"
else
  git_entry="$git_root/dist/index.js"
fi
git_cli="$git_root/openclaw.mjs"

package_version="$(node -p "require(\"$npm_root/package.json\").version")"
update_doctor_env="OPENCLAW_UPDATE_IN_PROGRESS=1"
update_doctor_env+=" OPENCLAW_UPDATE_PARENT_SUPPORTS_DOCTOR_CONFIG_WRITE=1"
update_doctor_env+=" OPENCLAW_UPDATE_PARENT_SUPPORTS_GATEWAY_RESTART=1"
update_doctor_env+=" OPENCLAW_UPDATE_PARENT_ALLOWS_GATEWAY_SERVICE_REPAIR=1"
update_doctor_env+=" OPENCLAW_UPDATE_PARENT_ALLOWS_GATEWAY_ACTIVATION=0"

use_default_service_identity() {
  local account_home
  account_home="$(node -p 'require("node:os").userInfo().homedir')"

  # Service mutation is intentionally restricted to the OS account home. Keep
  # these disposable-container flows isolated without pretending a temp HOME owns it.
  rm -rf \
    "$account_home/.openclaw" \
    "$account_home/.config/systemd/user/openclaw-gateway.service" \
    "$account_home/.config/fish" \
    "$account_home/.config/powershell" \
    "$account_home/.local/bin/openclaw-wrapper" \
    "$account_home/openclaw-wrapper-argv.log"
  export HOME="$account_home"
  export USERPROFILE="$account_home"
  unset OPENCLAW_HOME OPENCLAW_STATE_DIR OPENCLAW_CONFIG_PATH
}

is_legacy_package_acceptance_compat() {
  [ "$(node scripts/e2e/lib/package-compat.mjs "$1")" = "1" ]
}

assert_entrypoint() {
  local unit_path="$1"
  local expected="$2"
  if ! node scripts/e2e/lib/doctor-install-switch/assert-exec-start.mjs \
    entrypoint "$unit_path" "$expected"; then
    if [ -n "${doctor_log:-}" ] && [ -f "$doctor_log" ]; then
      openclaw_e2e_print_log "$doctor_log"
    fi
    exit 1
  fi
}

assert_exec_arg() {
  local unit_path="$1"
  local index="$2"
  local expected="$3"
  if ! node scripts/e2e/lib/doctor-install-switch/assert-exec-start.mjs \
    argument "$unit_path" "$expected" "$index"; then
    cat "$unit_path"
    exit 1
  fi
}

assert_env_value() {
  local unit_path="$1"
  local key="$2"
  local expected="$3"
  if ! grep -Fxq "Environment=${key}=${expected}" "$unit_path"; then
    echo "Expected Environment=${key}=${expected} in $unit_path"
    cat "$unit_path"
    exit 1
  fi
}

assert_no_env_key() {
  local unit_path="$1"
  local key="$2"
  if grep -q "^Environment=${key}=" "$unit_path"; then
    echo "Expected no Environment=${key}= line in $unit_path"
    cat "$unit_path"
    exit 1
  fi
}

service_definition_fingerprint() {
  sha256sum "$1"
  local env_file="$HOME/.openclaw/gateway.systemd.env"
  if [ -f "$env_file" ]; then
    sha256sum "$env_file"
  else
    echo "No generated systemd environment file"
  fi
}

run_doctor_preserving_service() {
  local unit_path="$1"
  local doctor_log="$2"
  local command_timeout="$3"
  local doctor_cmd="$4"
  local before
  before="$(service_definition_fingerprint "$unit_path")"
  if ! openclaw_e2e_maybe_timeout "$command_timeout" bash -c "$doctor_cmd" >"$doctor_log" 2>&1; then
    openclaw_e2e_print_log "$doctor_log"
    exit 1
  fi
  if [ "$(service_definition_fingerprint "$unit_path")" != "$before" ]; then
    echo "Doctor changed the installed service definition during maintenance"
    openclaw_e2e_print_log "$doctor_log"
    exit 1
  fi
}

# Doctor preserves the service definition; explicit gateway install owns switching.
run_flow() {
  local name="$1"
  local install_cmd="$2"
  local install_expected="$3"
  local doctor_cmd="$4"
  local switch_expected="$5"
  local switch_cmd="$6"
  local install_log="/tmp/openclaw-doctor-switch-${name}-install.log"
  local doctor_log="/tmp/openclaw-doctor-switch-${name}-doctor.log"
  local switch_log="/tmp/openclaw-doctor-switch-${name}-switch.log"
  local command_timeout="${OPENCLAW_DOCKER_DOCTOR_SWITCH_COMMAND_TIMEOUT:-900s}"

  echo "== Flow: $name =="
  openclaw_test_state_create "switch-${name}" empty
  use_default_service_identity
  export USER="testuser"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" bash -c "$install_cmd" >"$install_log" 2>&1; then
    openclaw_e2e_print_log "$install_log"
    exit 1
  fi
  rm -f "$HOME/.zshrc" "$HOME/.bashrc" "$HOME/.bash_profile"
  rm -rf "$HOME/.config/fish" "$HOME/.config/powershell"

  unit_path="$HOME/.config/systemd/user/openclaw-gateway.service"
  if [ ! -f "$unit_path" ]; then
    echo "Missing unit file: $unit_path"
    exit 1
  fi
  assert_entrypoint "$unit_path" "$install_expected"

  run_doctor_preserving_service "$unit_path" "$doctor_log" "$command_timeout" "$doctor_cmd"
  assert_entrypoint "$unit_path" "$install_expected"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" bash -c "$switch_cmd" >"$switch_log" 2>&1; then
    openclaw_e2e_print_log "$switch_log"
    exit 1
  fi
  assert_entrypoint "$unit_path" "$switch_expected"
}

run_flow \
  "npm-to-git" \
  "$npm_bin daemon install --force" \
  "$npm_entry" \
  "$update_doctor_env node $git_cli doctor --repair --force --yes --non-interactive" \
  "$git_entry" \
  "node $git_cli gateway install --force"

run_flow \
  "git-to-npm" \
  "node $git_cli daemon install --force" \
  "$git_entry" \
  "$update_doctor_env $npm_bin doctor --repair --force --yes --non-interactive" \
  "$npm_entry" \
  "$npm_bin gateway install --force"

plugin_binding_approval_count() {
  local database_path="$1"
  if [ ! -f "$database_path" ]; then
    echo "0"
    return
  fi
  node --no-warnings - "$database_path" <<'NODE'
const { DatabaseSync } = require("node:sqlite");
const database = new DatabaseSync(process.argv[2]);
const table = database
  .prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?")
  .get("plugin_binding_approvals");
const row = table
  ? database.prepare("SELECT COUNT(*) AS count FROM plugin_binding_approvals").get()
  : { count: 0 };
database.close();
process.stdout.write(String(row.count));
NODE
}

run_cross_state_approval_flow() {
  local name="cross-state-approvals"
  local automated_log="/tmp/openclaw-doctor-switch-${name}-automated.log"
  local direct_log="/tmp/openclaw-doctor-switch-${name}-direct.log"
  local command_timeout="${OPENCLAW_DOCKER_DOCTOR_SWITCH_COMMAND_TIMEOUT:-900s}"

  echo "== Flow: $name =="
  openclaw_test_state_create "switch-${name}" empty
  export USER="testuser"

  local default_state_dir="$HOME/.openclaw"
  local custom_state_dir="$HOME/custom-state"
  local exec_source="$default_state_dir/exec-approvals.json"
  local plugin_source="$default_state_dir/plugin-binding-approvals.json"
  local state_database="$custom_state_dir/state/openclaw.sqlite"
  mkdir -p "$default_state_dir" "$custom_state_dir"
  printf '%s\n' '{"version":1,"socket":{"token":"legacy-token"},"defaults":{"security":"deny","ask":"always"}}' >"$exec_source"
  printf '%s\n' '{"version":1,"approvals":[{"pluginRoot":"/plugins/codex-a","pluginId":"codex","channel":"telegram","accountId":"default","approvedAt":2345}]}' >"$plugin_source"
  local exec_source_hash
  local plugin_source_hash
  exec_source_hash="$(sha256sum "$exec_source" | awk '{print $1}')"
  plugin_source_hash="$(sha256sum "$plugin_source" | awk '{print $1}')"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" env \
    OPENCLAW_STATE_DIR="$custom_state_dir" \
    OPENCLAW_CONFIG_PATH="$custom_state_dir/openclaw.json" \
    OPENCLAW_UPDATE_IN_PROGRESS=1 \
    "$npm_bin" doctor --repair --yes --non-interactive >"$automated_log" 2>&1; then
    openclaw_e2e_print_log "$automated_log"
    exit 1
  fi

  test "$(sha256sum "$exec_source" | awk '{print $1}')" = "$exec_source_hash"
  test "$(sha256sum "$plugin_source" | awk '{print $1}')" = "$plugin_source_hash"
  test ! -e "$exec_source.migrated"
  test ! -e "$plugin_source.migrated"
  test ! -e "$custom_state_dir/exec-approvals.json"
  test "$(plugin_binding_approval_count "$state_database")" = "0"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" env \
    -u OPENCLAW_UPDATE_IN_PROGRESS \
    OPENCLAW_STATE_DIR="$custom_state_dir" \
    OPENCLAW_CONFIG_PATH="$custom_state_dir/openclaw.json" \
    "$npm_bin" doctor --repair --yes --non-interactive >"$direct_log" 2>&1; then
    openclaw_e2e_print_log "$direct_log"
    exit 1
  fi

  test "$(sha256sum "$exec_source" | awk '{print $1}')" = "$exec_source_hash"
  test "$(sha256sum "$plugin_source" | awk '{print $1}')" = "$plugin_source_hash"
  test ! -e "$exec_source.migrated"
  test ! -e "$plugin_source.migrated"
  test ! -e "$custom_state_dir/exec-approvals.json"
  test "$(plugin_binding_approval_count "$state_database")" = "0"
}

run_cross_state_approval_flow

run_proxy_env_flow() {
  local name="proxy-env-cleanup"
  local install_log="/tmp/openclaw-doctor-switch-${name}-install.log"
  local doctor_log="/tmp/openclaw-doctor-switch-${name}-doctor.log"
  local reinstall_log="/tmp/openclaw-doctor-switch-${name}-reinstall.log"
  local command_timeout="${OPENCLAW_DOCKER_DOCTOR_SWITCH_COMMAND_TIMEOUT:-900s}"

  echo "== Flow: $name =="
  openclaw_test_state_create "switch-${name}" empty
  use_default_service_identity
  export USER="testuser"

  unit_path="$HOME/.config/systemd/user/openclaw-gateway.service"
  if ! openclaw_e2e_maybe_timeout "$command_timeout" env \
    HTTP_PROXY="http://proxy.local:7890" \
    HTTPS_PROXY="https://proxy.local:7890" \
    NO_PROXY="localhost,127.0.0.1" \
    "$npm_bin" gateway install --force >"$install_log" 2>&1; then
    openclaw_e2e_print_log "$install_log"
    exit 1
  fi
  assert_no_env_key "$unit_path" "HTTP_PROXY"
  assert_no_env_key "$unit_path" "HTTPS_PROXY"
  assert_no_env_key "$unit_path" "NO_PROXY"

  {
    printf "%s\n" "Environment=HTTP_PROXY=http://stale-proxy.local:7890"
    printf "%s\n" "Environment=HTTPS_PROXY=https://stale-proxy.local:7890"
  } >>"$unit_path"
  run_doctor_preserving_service "$unit_path" "$doctor_log" "$command_timeout" \
    "$update_doctor_env node $git_cli doctor --repair --force --yes --non-interactive"
  assert_env_value "$unit_path" "HTTP_PROXY" "http://stale-proxy.local:7890"
  assert_env_value "$unit_path" "HTTPS_PROXY" "https://stale-proxy.local:7890"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" node "$git_cli" gateway install --force >"$reinstall_log" 2>&1; then
    openclaw_e2e_print_log "$reinstall_log"
    exit 1
  fi
  assert_no_env_key "$unit_path" "HTTP_PROXY"
  assert_no_env_key "$unit_path" "HTTPS_PROXY"
}

run_proxy_env_flow

run_wrapper_flow() {
  local name="wrapper-persistence"
  local install_log="/tmp/openclaw-doctor-switch-${name}-install.log"
  local reinstall_log="/tmp/openclaw-doctor-switch-${name}-reinstall.log"
  local env_repair_log="/tmp/openclaw-doctor-switch-${name}-env-repair.log"
  local doctor_log="/tmp/openclaw-doctor-switch-${name}-doctor.log"
  local clear_log="/tmp/openclaw-doctor-switch-${name}-clear.log"
  local command_timeout="${OPENCLAW_DOCKER_DOCTOR_SWITCH_COMMAND_TIMEOUT:-900s}"

  echo "== Flow: $name =="
  openclaw_test_state_create "switch-${name}" empty
  use_default_service_identity
  export USER="testuser"
  mkdir -p "$HOME/.local/bin"
  local wrapper="$HOME/.local/bin/openclaw-wrapper"
  node scripts/e2e/lib/doctor-install-switch/write-wrapper.mjs \
    "$wrapper" \
    "$npm_bin" \
    "$HOME/openclaw-wrapper-argv.log"

  local unit_path="$HOME/.config/systemd/user/openclaw-gateway.service"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" "$npm_bin" gateway install --wrapper "$wrapper" --force >"$install_log" 2>&1; then
    openclaw_e2e_print_log "$install_log"
    exit 1
  fi
  assert_exec_arg "$unit_path" 1 "$wrapper"
  assert_exec_arg "$unit_path" 2 "gateway"
  assert_env_value "$unit_path" "OPENCLAW_WRAPPER" "$wrapper"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" "$npm_bin" gateway install --force >"$reinstall_log" 2>&1; then
    openclaw_e2e_print_log "$reinstall_log"
    exit 1
  fi
  assert_exec_arg "$unit_path" 1 "$wrapper"
  assert_exec_arg "$unit_path" 2 "gateway"
  assert_env_value "$unit_path" "OPENCLAW_WRAPPER" "$wrapper"

  sed -i "/^Environment=OPENCLAW_WRAPPER=/d" "$unit_path"
  if ! openclaw_e2e_maybe_timeout "$command_timeout" "$npm_bin" gateway install --wrapper "$wrapper" >"$env_repair_log" 2>&1; then
    openclaw_e2e_print_log "$env_repair_log"
    exit 1
  fi
  assert_exec_arg "$unit_path" 1 "$wrapper"
  assert_env_value "$unit_path" "OPENCLAW_WRAPPER" "$wrapper"

  sed -i "s#^Environment=OPENCLAW_WRAPPER=.*#Environment=OPENCLAW_WRAPPER=/tmp/stale-openclaw-wrapper#" "$unit_path"
  if ! openclaw_e2e_maybe_timeout "$command_timeout" "$npm_bin" gateway install --wrapper "$wrapper" >"$env_repair_log" 2>&1; then
    openclaw_e2e_print_log "$env_repair_log"
    exit 1
  fi
  assert_exec_arg "$unit_path" 1 "$wrapper"
  assert_env_value "$unit_path" "OPENCLAW_WRAPPER" "$wrapper"

  run_doctor_preserving_service "$unit_path" "$doctor_log" "$command_timeout" \
    "node $git_cli doctor --repair --force --yes"
  assert_exec_arg "$unit_path" 1 "$wrapper"
  assert_exec_arg "$unit_path" 2 "gateway"
  assert_env_value "$unit_path" "OPENCLAW_WRAPPER" "$wrapper"

  if ! openclaw_e2e_maybe_timeout "$command_timeout" env OPENCLAW_WRAPPER= "$npm_bin" gateway install --force >"$clear_log" 2>&1; then
    openclaw_e2e_print_log "$clear_log"
    exit 1
  fi
  assert_no_env_key "$unit_path" "OPENCLAW_WRAPPER"
  assert_entrypoint "$unit_path" "$npm_entry"
}

if "$npm_bin" gateway install --help 2>&1 | grep -q -- "--wrapper"; then
  run_wrapper_flow
elif is_legacy_package_acceptance_compat "$package_version"; then
  # Legacy compatibility: 2026.4.25 and older did not ship gateway install --wrapper.
  echo "Skipping wrapper persistence; package gateway install does not support --wrapper."
else
  echo "Package $package_version must support gateway install --wrapper." >&2
  exit 1
fi
