// Defines source/config paths that pnpm dev watches for rebuilds and restarts.
import path from "node:path";
import {
  BUNDLED_PLUGIN_PATH_PREFIX,
  BUNDLED_PLUGIN_ROOT_DIR,
} from "./lib/bundled-plugin-paths.mjs";
import { listGeneratedExtensionAssetSources } from "./lib/static-extension-assets.mts";

const RUN_NODE_PACKAGE_SOURCE_ROOTS = [
  // Root runtime code imports these package sources through tsconfig aliases,
  // while pnpm dev/watch still runs the root dist entrypoint. Treat them like
  // src/ so edits restart the same process that consumes them.
  "packages/ai/src",
  "packages/gateway-client/src",
  "packages/gateway-protocol/src",
  "packages/markdown-core/src",
  "packages/llm-core/src",
  "packages/media-core/src",
  "packages/media-generation-core/src",
  "packages/media-understanding-common/src",
  "packages/normalization-core/src",
  "packages/retry/src",
  "packages/acp-core/src",
  "packages/terminal-core/src",
  "packages/net-policy/src",
];

/** Source roots whose changes require the root dev build pipeline. */
export const runNodeSourceRoots = [
  "src",
  ...RUN_NODE_PACKAGE_SOURCE_ROOTS,
  BUNDLED_PLUGIN_ROOT_DIR,
];
/** Root config files whose changes invalidate the dev build. */
export const runNodeConfigFiles = ["tsconfig.json", "package.json", "tsdown.config.ts"];
/** Combined watch list used by the run-node wrapper. */
export const runNodeWatchedPaths = [...runNodeSourceRoots, ...runNodeConfigFiles];
/** Plugin metadata files that require a runtime restart even without source edits. */
export const extensionRestartMetadataFiles = new Set(["openclaw.plugin.json", "package.json"]);

const ignoredRunNodeRepoPathPatterns = [
  /^extensions\/[^/]+\/src\/host\/.+\/\.bundle\.hash$/u,
  /^extensions\/[^/]+\/src\/host\/.+\/[^/]+\.bundle\.js$/u,
];
const extensionSourceFilePattern = /\.(?:[cm]?[jt]sx?)$/;

/** Normalizes watch paths to repository-style POSIX separators. */
export const normalizeRunNodePath = (filePath: unknown): string =>
  (typeof filePath === "string" ? filePath : "").replaceAll("\\", "/");

const isIgnoredSourcePath = (relativePath: string): boolean => {
  const normalizedPath = normalizeRunNodePath(relativePath);
  return (
    normalizedPath.endsWith(".test.ts") ||
    normalizedPath.endsWith(".test.tsx") ||
    normalizedPath.endsWith("test-helpers.ts")
  );
};

const isBuildRelevantSourcePath = (relativePath: string): boolean => {
  const normalizedPath = normalizeRunNodePath(relativePath);
  return extensionSourceFilePattern.test(normalizedPath) && !isIgnoredSourcePath(normalizedPath);
};

const isRestartRelevantExtensionPath = (relativePath: string): boolean => {
  const normalizedPath = normalizeRunNodePath(relativePath);
  if (extensionRestartMetadataFiles.has(path.posix.basename(normalizedPath))) {
    return true;
  }
  return isBuildRelevantSourcePath(normalizedPath);
};

const isRelevantRunNodePath = (
  repoPath: unknown,
  isRelevantBundledPluginPath: (relativePath: string) => boolean,
  generatedPluginAssetPaths: ReadonlySet<string>,
): boolean => {
  const normalizedPath = normalizeRunNodePath(repoPath).replace(/^\.\/+/, "");
  if (
    generatedPluginAssetPaths.has(normalizedPath) ||
    ignoredRunNodeRepoPathPatterns.some((pattern) => pattern.test(normalizedPath))
  ) {
    return false;
  }
  if (runNodeConfigFiles.includes(normalizedPath)) {
    return true;
  }
  if (normalizedPath.startsWith("src/")) {
    return !isIgnoredSourcePath(normalizedPath.slice("src/".length));
  }
  for (const sourceRoot of RUN_NODE_PACKAGE_SOURCE_ROOTS) {
    if (normalizedPath.startsWith(`${sourceRoot}/`)) {
      return !isIgnoredSourcePath(normalizedPath.slice(sourceRoot.length + 1));
    }
  }
  if (normalizedPath.startsWith(BUNDLED_PLUGIN_PATH_PREFIX)) {
    return isRelevantBundledPluginPath(normalizedPath.slice(BUNDLED_PLUGIN_PATH_PREFIX.length));
  }
  return false;
};

/** Creates a path classifier whose generated-output metadata can be refreshed. */
export function createRunNodePathClassifier(params: { rootDir?: string } = {}) {
  const rootDir = params.rootDir ?? process.cwd();
  let generatedPluginAssetPaths = new Set<string>();

  return {
    refreshGeneratedPluginAssetPaths() {
      generatedPluginAssetPaths = new Set(listGeneratedExtensionAssetSources({ rootDir }));
    },
    isBuildRelevantRunNodePath(repoPath: unknown) {
      return isRelevantRunNodePath(repoPath, isBuildRelevantSourcePath, generatedPluginAssetPaths);
    },
    isRestartRelevantRunNodePath(repoPath: unknown) {
      return isRelevantRunNodePath(
        repoPath,
        isRestartRelevantExtensionPath,
        generatedPluginAssetPaths,
      );
    },
  };
}

type RunNodePathClassifier = ReturnType<typeof createRunNodePathClassifier>;

let defaultRunNodePathClassifier: RunNodePathClassifier | undefined;
const getDefaultRunNodePathClassifier = (): RunNodePathClassifier => {
  if (!defaultRunNodePathClassifier) {
    defaultRunNodePathClassifier = createRunNodePathClassifier();
    defaultRunNodePathClassifier.refreshGeneratedPluginAssetPaths();
  }
  return defaultRunNodePathClassifier;
};

/** Returns true when a repo path should trigger a dev rebuild. */
export const isBuildRelevantRunNodePath = (repoPath: unknown): boolean =>
  getDefaultRunNodePathClassifier().isBuildRelevantRunNodePath(repoPath);

/** Returns true when a repo path should restart the running dev process. */
export const isRestartRelevantRunNodePath = (repoPath: unknown): boolean =>
  getDefaultRunNodePathClassifier().isRestartRelevantRunNodePath(repoPath);
