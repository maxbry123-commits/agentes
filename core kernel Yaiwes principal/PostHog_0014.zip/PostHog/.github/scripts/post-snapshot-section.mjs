#!/usr/bin/env node
import { postSection } from '../../frontend/bin/ci-report/update-ci-report.mjs'

const [workflowType, mode, changesJson, repo, commitSha, snapshotSha] = process.argv.slice(2)

if (process.argv.length !== 8) {
    console.error(
        'Usage: post-snapshot-section.mjs <workflow_type> <mode> <changes_json> <repo> <commit_sha> <snapshot_sha>'
    )
    process.exit(0)
}

const CONFIGS = {
    storybook: {
        id: 'storybook-snapshots',
        label: 'Storybook',
        type: 'UI snapshots',
        headerPrefix: 'Visual regression',
        whatThisMeans: `- Snapshots have been automatically updated to match current rendering
- Next CI run will switch to CHECK mode to verify stability
- If snapshots change again, CHECK mode will fail (indicates flapping)`,
        nextSteps: `- Review the changes to ensure they're intentional
- Approve if changes match your expectations
- If unexpected, investigate component rendering`,
    },
    backend: {
        id: 'backend-snapshots',
        label: 'Backend',
        type: 'query snapshots',
        headerPrefix: 'Query snapshots',
        whatThisMeans: `- Query snapshots have been automatically updated to match current output
- These changes reflect modifications to database queries or schema`,
        nextSteps: `- Review the query changes to ensure they're intentional
- If unexpected, investigate what caused the query to change`,
    },
    // MCP unit-test snapshots need their own section: ci-mcp and ci-backend can both
    // update snapshots on one PR, and a shared id would let the later writer clobber
    // the earlier one's review link.
    mcp: {
        id: 'mcp-snapshots',
        label: 'MCP',
        type: 'unit test snapshots',
        headerPrefix: 'Snapshots',
        whatThisMeans: `- Snapshots have been automatically updated to match current output`,
        nextSteps: `- Review the changes to ensure they're intentional
- If unexpected, investigate what caused the output to change`,
    },
    playwright: {
        id: 'playwright-snapshots',
        label: 'Playwright E2E',
        type: 'E2E screenshots',
        headerPrefix: 'Visual regression',
        whatThisMeans: `- Snapshots have been automatically updated to match current rendering
- Next CI run will switch to CHECK mode to verify stability
- If snapshots change again, CHECK mode will fail (indicates flapping)`,
        nextSteps: `- Review the changes to ensure they're intentional
- Approve if changes match your expectations
- If unexpected, investigate component rendering`,
    },
}

const config = CONFIGS[workflowType]
if (!config) {
    console.error(`Unknown workflow type: ${workflowType} — skipping snapshot section.`)
    process.exit(0)
}

if (mode === 'skip') {
    const currentShort = snapshotSha.slice(0, 7)
    const testedShort = commitSha.slice(0, 7)
    await postSection(
        {
            id: config.id,
            status: 'info',
            summary: `skipped stale run for ${testedShort}`,
            body: `Skipped the snapshot commit because the branch advanced to \`${currentShort}\` while the workflow was testing \`${testedShort}\`.

The new commit will trigger its own snapshot update workflow. If a fresh run does not start, merge master or push an empty commit.`,
        },
        { legacyPrefixes: ['⏭️ Skipped snapshot commit because branch advanced'] }
    )
    process.exit(0)
}

if (mode !== 'update') {
    console.error(`Unknown mode: ${mode} — skipping snapshot section.`)
    process.exit(0)
}

const changes = JSON.parse(changesJson)
const { total, added, modified, deleted } = changes

if (total === 0) {
    console.info('No snapshot changes — nothing to post.')
    process.exit(0)
}

const body = `### ${config.headerPrefix}: ${config.label} ${config.type} updated

**Changes:** ${total} snapshots (${modified} modified, ${added} added, ${deleted} deleted)

**What this means:**
${config.whatThisMeans}

**Next steps:**
${config.nextSteps}

[Review snapshot changes →](https://github.com/${repo}/commit/${snapshotSha || commitSha})`

const summary = `${total} updated (${modified} modified, ${added} added, ${deleted} deleted)`

await postSection({
    id: config.id,
    status: 'warn',
    summary,
    body,
})
