from __future__ import annotations

import re
import sys
import json
import textwrap
import subprocess
import importlib.util
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from defusedxml import ElementTree

SCRIPT_PATH = Path(__file__).with_name("report_test_timings.py")
REPO_ROOT = SCRIPT_PATH.parents[2]
SPEC = importlib.util.spec_from_file_location("report_test_timings", SCRIPT_PATH)
assert SPEC is not None and SPEC.loader is not None
report_test_timings = importlib.util.module_from_spec(SPEC)
# Register before exec so @dataclass can resolve the module via sys.modules.
sys.modules["report_test_timings"] = report_test_timings
SPEC.loader.exec_module(report_test_timings)


def test_jest_timing_markdown_matches_checked_in_example() -> None:
    fixture = SCRIPT_PATH.parent / "fixtures/jest-timings-example.json"
    expected = fixture.with_suffix(".md").read_text()

    result = subprocess.run(
        [REPO_ROOT / "bin/render-jest-timings-example"],
        check=True,
        capture_output=True,
        text=True,
    )

    assert result.stderr == ""
    assert result.stdout == expected


def test_full_jest_fixture_renders_single_browser_report(tmp_path: Path) -> None:
    fixture = SCRIPT_PATH.parent / "fixtures/jest-timings-real-run"
    output = tmp_path / "jest-test-speed-report.html"

    subprocess.run(
        [REPO_ROOT / "bin/report-jest-timings", "--artifacts", fixture, "--html", output],
        check=True,
        capture_output=True,
        text=True,
    )

    html = output.read_text()
    match = re.search(r"const tests=(.*), summary=", html)
    assert match is not None
    tests = json.loads(match.group(1))

    assert "<title>Jest test-speed report</title>" in html
    assert len(tests) == 11_446
    assert tests == sorted(tests, key=lambda test: test[0], reverse=True)
    assert output.stat().st_size < 3 * 1024 * 1024


def _testcase(
    *,
    outcome: str = "passed",
    attempts: int = 1,
    duration: float = 1.0,
    start: datetime | None = None,
    name: str = "t",
    file: str = "m.py",
) -> report_test_timings.TestCase:  # type: ignore[name-defined]
    test_start = start if start is not None else datetime(2026, 5, 4, 10, 0, 0, tzinfo=UTC)
    return report_test_timings.TestCase(
        nodeid=f"m::{name}",
        classname="m",
        name=name,
        file=file,
        file_source="junit",
        selector=f"m.py::{name}",
        duration_seconds=duration,
        start=test_start,
        end=test_start + timedelta(seconds=duration),
        outcome=outcome,
        attempts=attempts,
    )


@pytest.mark.parametrize(
    "file,classname,name,expected",
    [
        # Class-based: the file's module prefix is stripped from classname, leaving the class.
        (
            "posthog/hogql/test/test_resolver.py",
            "posthog.hogql.test.test_resolver.TestResolver",
            "test_x",
            "posthog/hogql/test/test_resolver.py::TestResolver::test_x",
        ),
        # Module-level test: classname equals the module, so no class segment.
        ("pkg/test_a.py", "pkg.test_a", "test_y", "pkg/test_a.py::test_y"),
        # No classname at all also collapses to file::name.
        ("pkg/test_a.py", "", "test_y", "pkg/test_a.py::test_y"),
        # No file (external shard) or an unexpected classname shape yields '' — caller uses the nodeid.
        ("", "pkg.test_a.TestA", "test_y", ""),
        ("pkg/test_a.py", "totally.unrelated.Thing", "test_y", ""),
    ],
)
def test_to_pytest_selector(file: str, classname: str, name: str, expected: str) -> None:
    assert report_test_timings.to_pytest_selector(file, classname, name) == expected


def test_find_repo_root_walks_to_repository_markers(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    script = repo_root / ".github/scripts/report_test_timings.py"
    script.parent.mkdir(parents=True)
    script.touch()
    (repo_root / "owners.yaml").touch()

    assert report_test_timings.find_repo_root(script) == repo_root


def test_test_identity_infers_existing_pytest_file_when_junit_omits_it(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    test_file = tmp_path / "products/approvals/backend/tests/test_approvals_api.py"
    test_file.parent.mkdir(parents=True)
    test_file.touch()
    monkeypatch.setattr(report_test_timings, "REPO_ROOT", tmp_path)

    file, nodeid, selector, file_source = report_test_timings.test_identity(
        "pytest",
        "",
        "products.approvals.backend.tests.test_approvals_api.TestApprovalsFeatureGating",
        "test_accessible",
    )

    assert file == "products/approvals/backend/tests/test_approvals_api.py"
    assert nodeid == "products/approvals/backend/tests/test_approvals_api/TestApprovalsFeatureGating::test_accessible"
    assert (
        selector
        == "products/approvals/backend/tests/test_approvals_api.py::TestApprovalsFeatureGating::test_accessible"
    )
    assert file_source == "inferred"


@pytest.mark.parametrize(
    "classname,file_exists,expected",
    [
        (
            "products.logs.skills.authoring-log-alerts.tests.test_baseline_stats.TestBaselineStats",
            True,
            "products/logs/skills/authoring-log-alerts/tests/test_baseline_stats.py",
        ),
        (
            "products.approvals.backend.tests.test_new_api.TestNewAPI",
            False,
            "products/approvals/backend/tests/test_new_api.py",
        ),
    ],
)
def test_infer_pytest_file_supports_safe_test_paths(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    classname: str,
    file_exists: bool,
    expected: str,
) -> None:
    monkeypatch.setattr(report_test_timings, "REPO_ROOT", tmp_path)
    if file_exists:
        test_file = tmp_path / expected
        test_file.parent.mkdir(parents=True)
        test_file.touch()

    assert report_test_timings.infer_pytest_file(classname) == expected


def test_infer_pytest_file_rejects_path_traversal(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    (tmp_path / "secret.py").touch()
    monkeypatch.setattr(report_test_timings, "REPO_ROOT", repo_root)

    assert report_test_timings.infer_pytest_file("products/../../secret") == ""


# ---------- artifact name parsing ----------


@pytest.mark.parametrize(
    "dir_name,expected",
    [
        ("junit-results-backend-core-29", ("backend", "core", 29)),
        ("junit-results-frontend-FOSS-4", ("frontend", "FOSS", 4)),
        ("junit-results-llm-gateway", ("llm-gateway", "llm-gateway", None)),
        ("junit-results-hogli", ("hogli", "hogli", None)),
    ],
)
def test_derive_suite_segment_and_group(dir_name: str, expected: tuple[str, str, int | None]) -> None:
    assert report_test_timings.derive_suite_segment_and_group(dir_name) == expected


@pytest.mark.parametrize(
    "dir_name,expected",
    [
        # A suffix folded into the segment would mis-key the shard and break recovery pairing.
        ("junit-results-backend-core-29-attempt2", ("junit-results-backend-core-29", 2)),
        ("junit-results-backend-core-29-attempt10", ("junit-results-backend-core-29", 10)),
        ("junit-results-backend-core-29", ("junit-results-backend-core-29", 1)),
        # No digits is not an attempt suffix: a segment could legitimately end in a word.
        ("junit-results-backend-core-attempt", ("junit-results-backend-core-attempt", 1)),
    ],
)
def test_split_attempt_suffix(dir_name: str, expected: tuple[str, int]) -> None:
    assert report_test_timings.split_attempt_suffix(dir_name) == expected


def test_collect_artifact_infos_does_not_expand_large_sparse_group(tmp_path: Path) -> None:
    artifact_dir = tmp_path / "junit-results-frontend-FOSS-8574803097"
    artifact_dir.mkdir()

    info = report_test_timings.collect_artifact_infos(tmp_path)[0]

    assert info.group == 8_574_803_097
    assert info.total is None


# ---------- shard parsing end-to-end ----------


def _write_shard_xml(
    artifact_dir: Path,
    *,
    filename: str,
    timestamp: str,
    time: str,
    body: str,
    properties: dict[str, str] | None = None,
) -> None:
    artifact_dir.mkdir(parents=True, exist_ok=True)
    properties_block = ""
    if properties:
        # Single line keeps `textwrap.dedent` below honest — an unindented inner line would zero the common prefix.
        property_elements = "".join(f'<property name="{n}" value="{v}"/>' for n, v in properties.items())
        properties_block = f"<properties>{property_elements}</properties>"
    (artifact_dir / filename).write_text(
        textwrap.dedent(
            f"""\
            <?xml version="1.0"?>
            <testsuites>
              <testsuite name="pytest" timestamp="{timestamp}" time="{time}">
                {properties_block}
                {body}
              </testsuite>
            </testsuites>
            """
        )
    )


def test_collect_shards_builds_test_windows_and_overhead(tmp_path: Path) -> None:
    for group in range(1, 7):
        (tmp_path / f"junit-results-backend-core-{group}").mkdir()
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-7",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00.000000",
        time="10.0",
        body="""\
            <testcase classname="pkg.test_a.TestA" name="test_fast" time="0.1"/>
            <testcase classname="pkg.test_a.TestA" name="test_slow" time="2.0"/>
            <testcase classname="pkg.test_a.TestA" name="test_rerun" time="0.2">
              <flakyFailure message="x" time="0.3"/>
            </testcase>
            <testcase classname="pkg.test_a.TestA" name="test_fail" time="0.1"><failure message="x"/></testcase>
        """,
    )

    shards = report_test_timings.collect_shards(tmp_path)

    assert len(shards) == 1
    shard = shards[0]
    assert shard.info.suite == "backend"
    assert shard.info.segment == "core"
    assert shard.info.group == 7
    assert shard.info.total == 7
    assert shard.start == datetime(2026, 5, 4, 10, 0, 0, tzinfo=UTC)
    assert (shard.end - shard.start).total_seconds() == pytest.approx(10.0)
    assert shard.testcase_seconds == pytest.approx(2.7)
    assert shard.overhead_seconds == pytest.approx(7.3)
    assert shard.junit_filename == "junit-core.xml"
    assert [t.name for t in shard.tests] == ["test_fast", "test_slow", "test_rerun", "test_fail"]
    assert shard.tests[0].nodeid == "pkg/test_a/TestA::test_fast"
    assert shard.tests[0].start == shard.start
    assert shard.tests[0].end == datetime(2026, 5, 4, 10, 0, 0, 100000, tzinfo=UTC)
    assert shard.tests[1].start == shard.tests[0].end
    assert shard.tests[2].start == datetime(2026, 5, 4, 10, 0, 2, 100000, tzinfo=UTC)
    assert shard.tests[2].duration_seconds == pytest.approx(0.5)
    assert shard.tests[2].outcome == "rerun_passed"
    assert shard.tests[2].attempts == 2
    assert shard.tests[3].outcome == "failed"


def test_collect_jest_shard_reads_legacy_and_isolated_product_suites(tmp_path: Path) -> None:
    artifact_dir = tmp_path / "junit-results-frontend-EE-1"
    artifact_dir.mkdir()
    (artifact_dir / "junit-EE-1.xml").write_text(
        textwrap.dedent(
            """\
            <?xml version="1.0"?>
            <testsuites name="jest tests" tests="2" failures="1" time="4.0">
              <testsuite name="src/scenes/legacy.test.ts" timestamp="2026-05-04T10:00:00" time="2.0">
                <testcase classname="legacy scene renders" name="legacy scene renders" time="0.2"
                  file="src/scenes/legacy.test.ts"><failure message="x"/></testcase>
              </testsuite>
              <testsuite name="../products/surveys/frontend/surveyLogic.test.ts"
                timestamp="2026-05-04T10:00:01" time="3.0">
                <testcase classname="surveyLogic saves" name="surveyLogic saves" time="0.3"
                  file="../products/surveys/frontend/surveyLogic.test.ts"/>
              </testsuite>
            </testsuites>
            """
        )
    )

    shard = report_test_timings.collect_shards(tmp_path, "jest")[0]

    assert (shard.info.suite, shard.info.segment, shard.info.group) == ("frontend", "EE", 1)
    assert [test.file for test in shard.tests] == [
        "frontend/src/scenes/legacy.test.ts",
        "products/surveys/frontend/surveyLogic.test.ts",
    ]
    assert [test.selector for test in shard.tests] == [
        "frontend/src/scenes/legacy.test.ts::legacy scene renders",
        "products/surveys/frontend/surveyLogic.test.ts::surveyLogic saves",
    ]
    assert [test.nodeid for test in shard.tests] == [test.selector for test in shard.tests]
    assert [test.outcome for test in shard.tests] == ["failed", "passed"]
    assert shard.start == datetime(2026, 5, 4, 10, 0, tzinfo=UTC)
    assert shard.end == datetime(2026, 5, 4, 10, 0, 4, tzinfo=UTC)


def test_collect_jest_shard_marks_tolerated_failures_as_quarantined(tmp_path: Path) -> None:
    artifact_dir = tmp_path / "junit-results-frontend-FOSS-1"
    _write_shard_xml(
        artifact_dir,
        filename="junit-FOSS-1.xml",
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body=(
            '<testcase classname="suite flaky" name="suite flaky" time="0.1" '
            'file="src/flaky.test.ts"/>'
            '<testcase classname="suite healthy" name="suite healthy" time="0.1" '
            'file="src/flaky.test.ts"/>'
        ),
    )
    (artifact_dir / "posthog-jest-quarantine-123.jsonl").write_text(
        f"{json.dumps({'test_id': 'frontend/src/flaky.test.ts::suite flaky'})}\n"
    )

    shard = report_test_timings.collect_shards(tmp_path, "jest")[0]

    assert [test.outcome for test in shard.tests] == ["xfailed", "passed"]
    assert report_test_timings.should_emit(shard.tests[0], float("inf")) is True


@pytest.mark.parametrize(
    "runner,filename,run_attempt,recovered,expected_attempt",
    [
        # download-artifact extracts a single matching artifact flat into the download root, so
        # identity must come from the filename and current workflow attempt.
        ("jest", "junit-EE-1.xml", 2, ("frontend", "EE", 1), 2),
        ("jest", "junit-nodejs-postgres-parity.xml", 2, ("nodejs", "postgres-parity", None), 2),
        # A filename without a `-<chunk>` suffix and non-jest runners keep the directory-derived
        # fallback identity.
        ("jest", "junit-report.xml", 2, None, 1),
        ("pytest", "junit-EE-1.xml", 2, None, 1),
    ],
)
def test_flat_download_shard_identity(
    runner: str,
    filename: str,
    run_attempt: int,
    recovered: tuple[str, str, int | None] | None,
    expected_attempt: int,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _write_shard_xml(
        tmp_path,
        filename=filename,
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body='<testcase classname="suite flaky" name="suite flaky" time="0.1" file="src/flaky.test.ts"><failure message="x"/></testcase>',
    )
    monkeypatch.setenv("GITHUB_RUN_ATTEMPT", str(run_attempt))

    shard = report_test_timings.collect_shards(tmp_path, runner)[0]

    expected = recovered or report_test_timings.derive_suite_segment_and_group(tmp_path.name)
    assert (shard.info.suite, shard.info.segment, shard.info.group) == expected
    assert shard.info.attempt == expected_attempt
    if recovered:
        assert report_test_timings.job_trace_key(shard.info) == ":".join(map(str, recovered))


def test_load_jest_quarantine_signals_rejects_oversized_artifacts(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(report_test_timings, "MAX_QUARANTINE_SIGNAL_BYTES", 10)
    (tmp_path / "posthog-jest-quarantine-123.jsonl").write_text('{"test_id":"too-large"}\n')

    assert report_test_timings.load_jest_quarantine_signals(tmp_path) == frozenset()


@pytest.mark.parametrize(
    "junit_file,expected",
    [
        ("src/test/example.test.ts", "frontend/src/test/example.test.ts"),
        ("../products/web_analytics/frontend/example.test.ts", "products/web_analytics/frontend/example.test.ts"),
        ("../../outside.test.ts", ""),
    ],
)
def test_normalize_jest_file(junit_file: str, expected: str) -> None:
    assert report_test_timings.normalize_jest_file(junit_file) == expected


# ---------- rerun classification (posthog.reruns testcase property) ----------


@pytest.mark.parametrize(
    "testcase_xml,expected",
    [
        # pytest 8's junitxml drops rerun attempts entirely; the posthog-junit-timings
        # plugin records them as a testcase property — the only rerun signal we get.
        (
            '<testcase name="t"><properties><property name="posthog.reruns" value="2"/></properties></testcase>',
            ("rerun_passed", 3),
        ),
        # A rerun count must not mask a test that exhausted its retries and failed.
        (
            '<testcase name="t"><properties><property name="posthog.reruns" value="2"/></properties>'
            '<failure message="x"/></testcase>',
            ("failed", 3),
        ),
        # Malformed value must never crash the exporter.
        (
            '<testcase name="t"><properties><property name="posthog.reruns" value="garbage"/></properties></testcase>',
            ("passed", 1),
        ),
        # Playwright's JUnit reporter uses flakyFailure/flakyError for attempts
        # that failed before the final successful retry.
        ('<testcase name="t"><flakyFailure message="x"/></testcase>', ("rerun_passed", 2)),
        ('<testcase name="t"><flakyError message="x"/></testcase>', ("rerun_passed", 2)),
    ],
)
def test_classify_testcase_reads_retry_attempts(testcase_xml: str, expected: tuple[str, int]) -> None:
    assert report_test_timings.classify_testcase(ElementTree.fromstring(testcase_xml)) == expected


# ---------- setup_seconds (posthog-junit-timings plugin) ----------


def test_parse_shard_shifts_tests_past_setup_seconds(tmp_path: Path) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="10.0",
        properties={"posthog.setup_seconds": "3.5", "posthog.collection_seconds": "0.4"},
        body="""\
            <testcase classname="pkg.t.T" name="test_a" time="1.0"/>
            <testcase classname="pkg.t.T" name="test_b" time="2.0"/>
        """,
    )

    shard = report_test_timings.collect_shards(tmp_path)[0]

    assert shard.setup_seconds == pytest.approx(3.5)
    # First test no longer starts at shard.start — it starts after the setup gap.
    assert shard.tests[0].start == datetime(2026, 5, 4, 10, 0, 3, 500000, tzinfo=UTC)
    assert shard.tests[0].end == datetime(2026, 5, 4, 10, 0, 4, 500000, tzinfo=UTC)
    assert shard.tests[1].start == shard.tests[0].end
    # Shard wall-clock bounds are unaffected by the property.
    assert (shard.end - shard.start).total_seconds() == pytest.approx(10.0)


def test_parse_shard_defaults_setup_to_zero_when_property_missing(tmp_path: Path) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="5.0",
        body='<testcase classname="pkg.t.T" name="test_a" time="1.0"/>',
    )

    shard = report_test_timings.collect_shards(tmp_path)[0]

    assert shard.setup_seconds == 0.0
    assert shard.tests[0].start == shard.start


@pytest.mark.parametrize(
    "raw_value,expected",
    [
        ("not-a-float", 0.0),  # malformed → fall back to zero, don't crash
        ("-1.5", 0.0),  # negative → clamp to zero
        ("999.0", 5.0),  # exceeds wall time → clamp to wall_seconds to avoid pushing tests past shard.end
    ],
)
def test_parse_shard_handles_malformed_or_out_of_range_setup_seconds(
    tmp_path: Path, raw_value: str, expected: float
) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="5.0",
        properties={"posthog.setup_seconds": raw_value},
        body='<testcase classname="pkg.t.T" name="test_a" time="1.0"/>',
    )

    shard = report_test_timings.collect_shards(tmp_path)[0]

    assert shard.setup_seconds == pytest.approx(expected)


def test_parse_testsuite_properties_returns_empty_when_block_missing(tmp_path: Path) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body='<testcase classname="pkg.t.T" name="t" time="0.5"/>',
    )
    import defusedxml.ElementTree as ET

    suite = ET.parse(tmp_path / "junit-results-backend-core-1" / "junit-core.xml").getroot().find("testsuite")
    assert report_test_timings.parse_testsuite_properties(suite) == {}


# ---------- threshold filter ----------


@pytest.mark.parametrize(
    "outcome,attempts,duration,threshold,expected",
    [
        ("passed", 1, 0.1, 0.5, False),  # sub-threshold pass: dropped
        ("passed", 1, 1.0, 0.5, True),  # above threshold: kept
        ("failed", 1, 0.0, 0.5, True),  # failure: kept regardless of duration
        ("error", 1, 0.0, 0.5, True),  # error: kept regardless of duration
        ("rerun_passed", 3, 0.1, 0.5, True),  # rerun: kept regardless of duration
    ],
)
def test_should_emit(outcome: str, attempts: int, duration: float, threshold: float, expected: bool) -> None:
    test = _testcase(outcome=outcome, attempts=attempts, duration=duration)
    assert report_test_timings.should_emit(test, threshold) is expected


def test_filter_shards_preserves_parse_time_test_windows(tmp_path: Path) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="10.0",
        body="""\
            <testcase classname="pkg.t.T" name="test_fast_before" time="0.1"/>
            <testcase classname="pkg.t.T" name="test_slow" time="2.0"/>
            <testcase classname="pkg.t.T" name="test_rerun" time="0.2"><rerunFailure message="x"/></testcase>
            <testcase classname="pkg.t.T" name="test_fail" time="0.1"><failure message="x"/></testcase>
        """,
    )

    filtered = report_test_timings.filter_shards(
        report_test_timings.collect_shards(tmp_path),
        min_duration_seconds=0.5,
    )

    assert [test.name for test in filtered[0].tests] == ["test_slow", "test_rerun", "test_fail"]
    assert filtered[0].tests[0].start == datetime(2026, 5, 4, 10, 0, 0, 100000, tzinfo=UTC)
    assert filtered[0].tests[0].end == datetime(2026, 5, 4, 10, 0, 2, 100000, tzinfo=UTC)
    assert filtered[0].tests[1].start == datetime(2026, 5, 4, 10, 0, 2, 100000, tzinfo=UTC)
    assert filtered[0].tests[2].start == datetime(2026, 5, 4, 10, 0, 2, 300000, tzinfo=UTC)


def test_signals_only_threshold_keeps_failures_and_same_job_recovery() -> None:
    tests = [
        _testcase(name="slow_pass", duration=30.0),
        _testcase(name="failure", outcome="failed", duration=0.1),
        _testcase(name="recovery", duration=0.1),
    ]

    assert [
        test.name for test in tests if report_test_timings.should_emit(test, float("inf"), frozenset({"m::recovery"}))
    ] == ["failure", "recovery"]


# ---------- re-run attempts ----------


def test_rerun_attempt_emits_only_reexecuted_shards_and_same_leg_recovery_passes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body="""\
            <testcase classname="pkg.t.T" name="test_flaky" time="0.1"><failure message="x"/></testcase>
            <testcase classname="pkg.t.T" name="test_untouched" time="0.1"/>
        """,
    )
    # Not re-executed on attempt 2: must not be re-reported under the new attempt.
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-2",
        filename="junit-core.xml",
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body='<testcase classname="pkg.t.T" name="test_other" time="0.1"><failure message="x"/></testcase>',
    )
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-1-attempt2",
        filename="junit-core.xml",
        timestamp="2026-05-04T11:00:00",
        time="1.0",
        body="""\
            <testcase classname="pkg.t.T" name="test_flaky" time="0.1"/>
            <testcase classname="pkg.t.T" name="test_untouched" time="0.1"/>
        """,
    )
    # A pass in a different leg runs a different config and must not read as recovery.
    _write_shard_xml(
        tmp_path / "junit-results-backend-core-3-attempt2",
        filename="junit-core.xml",
        timestamp="2026-05-04T11:00:00",
        time="1.0",
        body='<testcase classname="pkg.t.T" name="test_flaky" time="0.1"/>',
    )

    current, prior_failed = report_test_timings.partition_run_attempt(report_test_timings.collect_shards(tmp_path), 2)
    filtered = report_test_timings.filter_shards(current, 0.5, prior_failed)

    assert [(s.info.group, s.info.attempt) for s in filtered] == [(1, 2), (3, 2)]
    assert prior_failed == {
        "backend:core:1": frozenset({"pkg/t/T::test_flaky"}),
        "backend:core:2": frozenset({"pkg/t/T::test_other"}),
    }
    # Only the same-leg recovery pass survives the threshold filter; the fast pass that never
    # failed and the cross-leg pass are dropped.
    assert [test.name for test in filtered[0].tests] == ["test_flaky"]
    assert filtered[1].tests == []

    monkeypatch.setenv("GITHUB_RUN_ATTEMPT", "2")
    timings = tmp_path / "timings.json"
    assert report_test_timings.main(["--runner", "jest", "--timings", str(timings), str(tmp_path)]) == 0
    assert [shard["group"] for shard in json.loads(timings.read_text())["shards"]] == [1, 3]


class _FakeSpan:
    def __init__(self, name: str, start_time: int) -> None:
        self.name = name
        self.start_time = start_time
        self.end_time: int | None = None
        self.attributes: dict[str, str | int | float] = {}

    def set_attribute(self, key: str, value: str | int | float) -> None:
        self.attributes[key] = value

    def set_status(self, status: object) -> None:
        pass

    def end(self, end_time: int) -> None:
        self.end_time = end_time


class _FakeTracer:
    def __init__(self) -> None:
        self.spans: list[_FakeSpan] = []

    def start_span(self, name: str, start_time: int) -> _FakeSpan:
        span = _FakeSpan(name, start_time)
        self.spans.append(span)
        return span


@contextmanager
def _noop_use_span(span: _FakeSpan, end_on_exit: bool = False) -> Iterator[None]:
    yield


def _no_owner(file: str) -> str:
    return ""


def test_emit_shard_span_uses_stored_test_windows(monkeypatch: pytest.MonkeyPatch) -> None:
    start = datetime(2026, 5, 4, 10, 0, 0, tzinfo=UTC)
    shard = report_test_timings.Shard(
        info=report_test_timings.ArtifactInfo(
            path=Path("junit-results-backend-core-1"),
            suite="backend",
            segment="core",
            group=1,
            total=1,
        ),
        junit_filename="junit-core.xml",
        start=start,
        end=start + timedelta(seconds=10),
        testcase_seconds=2.1,
        overhead_seconds=7.9,
        tests=[
            _testcase(name="slow", duration=2.0, start=start + timedelta(seconds=0.1)),
            _testcase(
                name="fail",
                outcome="failed",
                duration=0.1,
                start=start + timedelta(seconds=2.3),
            ),
        ],
    )
    tracer = _FakeTracer()
    monkeypatch.setattr(report_test_timings.trace, "use_span", _noop_use_span)

    has_error = report_test_timings._emit_shard_span(tracer, shard, "Backend CI / core (1)", _no_owner)

    assert has_error is True
    assert [span.name for span in tracer.spans] == ["Backend CI / core (1)", "m::slow", "m::fail"]
    assert tracer.spans[0].attributes["shard.setup_seconds"] == 0.0
    assert tracer.spans[1].start_time == report_test_timings._to_ns(start + timedelta(seconds=0.1))
    assert tracer.spans[1].end_time == report_test_timings._to_ns(start + timedelta(seconds=2.1))
    assert tracer.spans[2].start_time == report_test_timings._to_ns(start + timedelta(seconds=2.3))
    assert tracer.spans[2].end_time == report_test_timings._to_ns(start + timedelta(seconds=2.4))
    assert tracer.spans[0].attributes["shard.testcase_seconds"] == pytest.approx(2.1)
    assert tracer.spans[0].attributes["shard.overhead_seconds"] == pytest.approx(7.9)
    assert tracer.spans[1].attributes["test.runner"] == "pytest"
    assert tracer.spans[1].attributes["test.job_key"] == "backend:core:1"


def test_emit_shard_span_emits_setup_span_when_setup_seconds_positive(monkeypatch: pytest.MonkeyPatch) -> None:
    """When the posthog-junit-timings plugin reported setup_seconds, a sibling `setup`
    span covers the pre-first-test gap. Without this, the cursor-based reconstruction
    would visually attribute that gap to the first test."""
    start = datetime(2026, 5, 4, 10, 0, 0, tzinfo=UTC)
    shard = report_test_timings.Shard(
        info=report_test_timings.ArtifactInfo(
            path=Path("junit-results-backend-core-1"),
            suite="backend",
            segment="core",
            group=1,
            total=1,
        ),
        junit_filename="junit-core.xml",
        start=start,
        end=start + timedelta(seconds=10),
        testcase_seconds=2.0,
        overhead_seconds=8.0,
        tests=[_testcase(name="slow", duration=2.0, start=start + timedelta(seconds=3.5))],
        setup_seconds=3.5,
    )
    tracer = _FakeTracer()
    monkeypatch.setattr(report_test_timings.trace, "use_span", _noop_use_span)

    report_test_timings._emit_shard_span(tracer, shard, "Backend CI / core (1)", _no_owner)

    assert [span.name for span in tracer.spans] == ["Backend CI / core (1)", "setup", "m::slow"]
    setup_span = tracer.spans[1]
    assert setup_span.start_time == report_test_timings._to_ns(start)
    assert setup_span.end_time == report_test_timings._to_ns(start + timedelta(seconds=3.5))
    assert setup_span.attributes["shard.setup_seconds"] == pytest.approx(3.5)
    assert tracer.spans[0].attributes["shard.setup_seconds"] == pytest.approx(3.5)


# `test.owner_team` is the contract the team CI health rollup reads: an unstamped span
# aggregates as `unowned`, so an unowned file must stay unstamped rather than carry an empty one.
def test_emit_shard_span_stamps_owner_team_only_for_owned_files(monkeypatch: pytest.MonkeyPatch) -> None:
    start = datetime(2026, 5, 4, 10, 0, 0, tzinfo=UTC)
    shard = report_test_timings.Shard(
        info=report_test_timings.ArtifactInfo(
            path=Path("junit-results-backend-core-1"),
            suite="backend",
            segment="core",
            group=1,
            total=1,
        ),
        junit_filename="junit-core.xml",
        start=start,
        end=start + timedelta(seconds=10),
        testcase_seconds=2.0,
        overhead_seconds=8.0,
        tests=[
            _testcase(name="owned", file="products/x/test_a.py"),
            _testcase(name="unowned", file="stray/test_b.py", start=start + timedelta(seconds=1)),
        ],
    )
    tracer = _FakeTracer()
    monkeypatch.setattr(report_test_timings.trace, "use_span", _noop_use_span)

    owners = {"products/x/test_a.py": "team-devex"}
    report_test_timings._emit_shard_span(tracer, shard, "Backend CI / core (1)", lambda f: owners.get(f, ""))

    assert tracer.spans[1].attributes["test.file"] == "products/x/test_a.py"
    assert tracer.spans[1].attributes["test.file_source"] == "junit"
    assert tracer.spans[1].attributes["test.owner_team"] == "team-devex"
    assert tracer.spans[2].attributes["test.file"] == "stray/test_b.py"
    assert tracer.spans[2].attributes["test.file_source"] == "junit"
    assert "test.owner_team" not in tracer.spans[2].attributes


def test_product_shard_derives_product_suite_and_keeps_repo_relative_paths(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Products run pytest with `--rootdir ../..`, so real product JUnit `file`/`classname`
    # are already repo-relative; the span must carry them through, not double-prefix them.
    _write_shard_xml(
        tmp_path / "product-junit-results-1",
        filename="junit-product-warehouse_sources.xml",
        timestamp="2026-05-04T10:00:00",
        time="1.0",
        body=(
            '<testcase classname="products.warehouse_sources.backend.migrations.test.test_migration_0075.TestBackfillApiVersion" '
            'file="products/warehouse_sources/backend/migrations/test/test_migration_0075.py" name="test_backfill" time="1.0"/>'
        ),
    )
    shard = report_test_timings.collect_shards(tmp_path)[0]
    assert shard.info.suite == "product"
    assert shard.info.segment == "warehouse_sources"
    assert report_test_timings.job_trace_name("Backend CI", shard.info) == "Backend CI / warehouse_sources (1)"

    tracer = _FakeTracer()
    owner_paths: list[str] = []
    monkeypatch.setattr(report_test_timings.trace, "use_span", _noop_use_span)

    def owner_of(file: str) -> str:
        owner_paths.append(file)
        return "team-data-warehouse"

    report_test_timings._emit_shard_span(tracer, shard, "Backend CI / warehouse_sources (1)", owner_of)

    test_span = tracer.spans[1]
    expected_file = "products/warehouse_sources/backend/migrations/test/test_migration_0075.py"
    assert (
        test_span.name
        == "products/warehouse_sources/backend/migrations/test/test_migration_0075/TestBackfillApiVersion::test_backfill"
    )
    assert test_span.attributes["test.selector"] == f"{expected_file}::TestBackfillApiVersion::test_backfill"
    assert test_span.attributes["test.owner_team"] == "team-data-warehouse"
    assert owner_paths == [expected_file]


# ---------- workflow context ----------


def test_workflow_resource_attributes_includes_query_and_drilldown_fields(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    event_path = tmp_path / "event.json"
    event_path.write_text(json.dumps({"number": 57216}))
    monkeypatch.setenv("GITHUB_EVENT_PATH", str(event_path))
    monkeypatch.setenv("GITHUB_EVENT_NAME", "pull_request")
    monkeypatch.setenv("GITHUB_HEAD_REF", "worktree-per-test-telemetry-junit")
    monkeypatch.setenv("GITHUB_BASE_REF", "master")
    monkeypatch.setenv("GITHUB_SERVER_URL", "https://github.com")
    monkeypatch.setenv("GITHUB_REPOSITORY", "PostHog/posthog")
    monkeypatch.setenv("GITHUB_RUN_ID", "25218527467")

    attrs = report_test_timings.workflow_resource_attributes()

    assert attrs["ci.event_name"] == "pull_request"
    assert attrs["ci.head_ref"] == "worktree-per-test-telemetry-junit"
    assert attrs["ci.base_ref"] == "master"
    assert attrs["ci.branch"] == "worktree-per-test-telemetry-junit"
    assert attrs["ci.pr_number"] == 57216
    assert attrs["ci.repository"] == "PostHog/posthog"
    assert attrs["ci.run_url"] == "https://github.com/PostHog/posthog/actions/runs/25218527467"


def test_workflow_resource_attributes_branch_on_push(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GITHUB_HEAD_REF", raising=False)
    monkeypatch.setenv("GITHUB_EVENT_NAME", "push")
    monkeypatch.setenv("GITHUB_REF_NAME", "master")

    attrs = report_test_timings.workflow_resource_attributes()

    assert attrs["ci.ref_name"] == "master"
    assert attrs["ci.branch"] == "master"


# ---------- trace id ----------


def test_deterministic_trace_id_is_stable_across_processes() -> None:
    a = report_test_timings.deterministic_trace_id("25218527467", "1", "backend:core:1")
    b = report_test_timings.deterministic_trace_id("25218527467", "1", "backend:core:1")
    assert a == b
    # Different attempt -> different trace id (so reruns of the same workflow run id are isolated).
    assert report_test_timings.deterministic_trace_id("25218527467", "2", "backend:core:1") != a
    # Different job -> different trace id (so each job in a run is its own trace).
    assert report_test_timings.deterministic_trace_id("25218527467", "1", "backend:core:2") != a
    # Result fits in 128 bits.
    assert 0 <= a < 2**128


# ---------- per-job trace naming ----------


def _artifact(suite: str, segment: str, group: int | None) -> report_test_timings.ArtifactInfo:  # type: ignore[name-defined]
    return report_test_timings.ArtifactInfo(
        path=Path(f"junit-results-{suite}"), suite=suite, segment=segment, group=group, total=None
    )


@pytest.mark.parametrize(
    "suite,segment,group,expected",
    [
        ("backend", "core", 29, "Backend CI / core (29)"),
        ("backend", "temporal", 1, "Backend CI / temporal (1)"),
        ("llm-gateway", "llm-gateway", None, "Backend CI / llm-gateway"),
    ],
)
def test_job_trace_name(suite: str, segment: str, group: int | None, expected: str) -> None:
    assert report_test_timings.job_trace_name("Backend CI", _artifact(suite, segment, group)) == expected


def test_job_trace_key_distinguishes_jobs() -> None:
    key = report_test_timings.job_trace_key
    assert key(_artifact("backend", "core", 1)) != key(_artifact("backend", "core", 2))
    assert key(_artifact("backend", "core", 1)) != key(_artifact("backend", "temporal", 1))
    assert key(_artifact("backend", "core", 1)) == key(_artifact("backend", "core", 1))


@pytest.mark.parametrize(
    "env,expected",
    [
        ({"POSTHOG_DEVEX_PROJECT_API_TOKEN": "phc_a", "POSTHOG_CI_TRACES_EXTRA_TOKEN": "phc_b"}, ["phc_a", "phc_b"]),
        ({"POSTHOG_DEVEX_PROJECT_API_TOKEN": "phc_a", "POSTHOG_CI_TRACES_EXTRA_TOKEN": "phc_a"}, ["phc_a"]),
        ({"POSTHOG_DEVEX_PROJECT_API_TOKEN": "phc_a"}, ["phc_a"]),
        ({"POSTHOG_CI_TRACES_EXTRA_TOKEN": "phc_b"}, ["phc_b"]),
        ({"POSTHOG_DEVEX_PROJECT_API_TOKEN": "", "POSTHOG_CI_TRACES_EXTRA_TOKEN": ""}, []),
        ({}, []),
    ],
)
def test_emission_tokens(env: dict[str, str], expected: list[str]) -> None:
    assert report_test_timings.emission_tokens(env) == expected


# ---------- jest timings: per-file launch + teardown ----------


def _write_nodejs_serial_xml(artifact_dir: Path) -> None:
    """One serial-nodejs-shaped jest XML: per-file staggered timestamps + per-file times.

    Real jest-junit emits per-file durations (perfStats.runtime) with staggered start
    timestamps in both serial and parallel layouts; the in-band shape this fixture used
    to model (uniform timestamps + cumulative times) does not occur in practice. The
    launch+teardown signal is `suite_time - sum(test durations)` regardless of layout.
    """
    artifact_dir.mkdir(parents=True, exist_ok=True)
    (artifact_dir / "junit-nodejs-2.xml").write_text(
        textwrap.dedent(
            """\
            <?xml version="1.0"?>
            <testsuites name="jest tests" tests="4" failures="0" time="12">
              <testsuite name="a" timestamp="2026-05-04T10:00:00" time="5.0">
                <testcase classname="a one" name="a one" time="1.0" file="src/worker/a.test.ts"/>
                <testcase classname="a two" name="a two" time="1.0" file="src/worker/a.test.ts"/>
              </testsuite>
              <testsuite name="b" timestamp="2026-05-04T10:00:05" time="3.0">
                <testcase classname="b one" name="b one" time="2.0" file="src/worker/b.test.ts"/>
              </testsuite>
              <testsuite name="c" timestamp="2026-05-04T10:00:08" time="4.0">
                <testcase classname="c one" name="c one" time="3.0" file="src/worker/c.test.ts"/>
              </testsuite>
            </testsuites>
            """
        )
    )


def test_collect_jest_shard_wall_bounds_and_file_launch(tmp_path: Path) -> None:
    (tmp_path / "junit-results-nodejs-2").mkdir()
    _write_nodejs_serial_xml(tmp_path / "junit-results-nodejs-2")

    shard = report_test_timings.collect_shards(tmp_path, "jest")[0]

    assert (shard.info.suite, shard.info.segment, shard.info.group) == ("nodejs", "nodejs", 2)
    assert shard.start == datetime(2026, 5, 4, 10, 0, tzinfo=UTC)
    # Wall = union of per-suite spans: [10:00:00, 10:00:12). Testcase bodies sum to 7s;
    # the 5s of launch+teardown overhead spread across the files is what the timings
    # layer reports.
    assert (shard.end - shard.start).total_seconds() == pytest.approx(12.0)
    assert shard.testcase_seconds == pytest.approx(7.0)
    # Per-suite: a=5-2=3s, b=3-2=1s, c=4-3=1s.
    assert shard.file_launch_seconds == [3.0, 1.0, 1.0]
    # Each test starts at its suite's real timestamp, laid contiguously within the suite.
    assert shard.tests[2].start == datetime(2026, 5, 4, 10, 0, 5, tzinfo=UTC)


def test_build_timings_report_quantifies_per_file_launch(tmp_path: Path) -> None:
    (tmp_path / "junit-results-nodejs-2").mkdir()
    _write_nodejs_serial_xml(tmp_path / "junit-results-nodejs-2")

    payload = report_test_timings.build_timings_report(
        report_test_timings.collect_shards(tmp_path, "jest"), tmp_path, "jest"
    )

    shard = payload["shards"][0]
    assert shard["wall_seconds"] == pytest.approx(12.0)
    assert shard["launch_seconds"] == pytest.approx(5.0)
    assert shard["per_file_launch_overhead_seconds"]["nodejs/src/worker/a.test.ts"] == pytest.approx(3.0)
    assert shard["per_file_launch_overhead_seconds"]["nodejs/src/worker/b.test.ts"] == pytest.approx(1.0)
    assert shard["per_file_launch_overhead_seconds"]["nodejs/src/worker/c.test.ts"] == pytest.approx(1.0)
    assert payload["suites"] == ["nodejs"]
    assert [t["name"] for t in shard["slowest_tests"][:2]] == ["c one", "b one"]


def test_build_timings_report_covers_parallel_frontend_layout(tmp_path: Path) -> None:
    artifact_dir = tmp_path / "junit-results-frontend-EE-1"
    artifact_dir.mkdir(parents=True)
    (artifact_dir / "junit-EE-1.xml").write_text(
        textwrap.dedent(
            """\
            <?xml version="1.0"?>
            <testsuites name="jest tests" tests="2" failures="0" time="9">
              <testsuite name="x" timestamp="2026-05-04T10:00:02" time="4.0">
                <testcase classname="x" name="renders" time="2.5" file="src/scenes/x.test.ts"/>
              </testsuite>
              <testsuite name="y" timestamp="2026-05-04T10:00:05" time="5.0">
                <testcase classname="y" name="computes" time="3.0" file="src/lib/y.test.ts"/>
              </testsuite>
            </testsuites>
            """
        )
    )

    payload = report_test_timings.build_timings_report(
        report_test_timings.collect_shards(tmp_path, "jest"), tmp_path, "jest"
    )

    shard = payload["shards"][0]
    # Overlapping parallel suites: wall is the union extrema (10:00:02 -> 10:00:10).
    assert shard["wall_seconds"] == pytest.approx(8.0)
    # x = 4-2.5 = 1.5s launch, y = 5-3 = 2s launch.
    assert shard["launch_seconds"] == pytest.approx(3.5)
    assert shard["per_file_launch_overhead_seconds"]["frontend/src/scenes/x.test.ts"] == pytest.approx(1.5)
    assert shard["per_file_launch_overhead_seconds"]["frontend/src/lib/y.test.ts"] == pytest.approx(2.0)
