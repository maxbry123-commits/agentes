"""Tests for hogli framework."""
