---
summary: "Project origin, contributors, and license."
read_when:
  - You want the project backstory or contributor credits
title: "Credits"
---

OpenClaw = CLAW + TARDIS: every space lobster needs a time and space machine.

## Credits

- **Peter Steinberger** ([@steipete](https://x.com/steipete)) - Creator, lobster whisperer
- **Mario Zechner** ([@badlogicc](https://x.com/badlogicgames)) - Pi creator, security pen tester
- **Clawd** - The space lobster who demanded a better name

## Core contributors

- **Maxim Vovshin** (@Hyaxia, [36747317+Hyaxia@users.noreply.github.com](mailto:36747317+Hyaxia@users.noreply.github.com)) - Blogwatcher skill
- **Nacho Iacovino** (@nachoiacovino, [nacho.iacovino@gmail.com](mailto:nacho.iacovino@gmail.com)) - Location parsing (Telegram and WhatsApp)
- **Vincent Koc** ([@vincentkoc](https://github.com/vincentkoc), [@vincent_koc](https://x.com/vincent_koc)) - Agents, telemetry, hooks, security

## License

MIT, copyright OpenClaw Foundation. Third-party notices for incorporated or adapted code are in `THIRD_PARTY_NOTICES.md`.

> "We are all just playing with our own prompts." (An AI, probably high on tokens)

## Related

- [Token use and costs](/reference/token-use)
- [Release policy](/reference/RELEASING)
