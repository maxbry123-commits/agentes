from maxbry_loop.models import Goal, State, Task
from maxbry_loop.integrity import validate

def test_dependency_integrity():
    a = Task(id="A", title="A", description="A")
    b = Task(id="B", title="B", description="B", depends_on=["A"])
    s = State("1", Goal("x"), {"A": a, "B": b})
    assert validate(s)

def test_self_dependency_rejected():
    a = Task(id="A", title="A", description="A", depends_on=["A"])
    s = State("1", Goal("x"), {"A": a})
    try:
        validate(s)
        assert False
    except Exception:
        assert True
