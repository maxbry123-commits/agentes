import os, requests, json

class Model:
    def __init__(self, cfg):
        self.cfg = cfg
        self.provider = cfg.get("provider", "mock")

    def execute(self, task, goal):
        if self.provider == "mock":
            return {
                "status": "done",
                "result": f"MOCK completed: {task.title}",
                "evidence": ["mock-execution"],
            }

        if self.provider != "openai_compatible":
            raise ValueError(f"Unsupported provider: {self.provider}")

        url = os.environ["LLM_BASE_URL"].rstrip("/") + "/chat/completions"
        headers = {"Authorization": f"Bearer {os.environ['LLM_API_KEY']}"}
        prompt = f"""Goal:
{goal.text}

Task:
{task.title}

Description:
{task.description}

Acceptance criteria:
{chr(10).join('- '+x for x in task.acceptance)}

Return JSON with exactly:
{{"status":"done|blocked|needs_revision","result":"...","evidence":["..."]}}
"""
        r = requests.post(
            url,
            headers=headers,
            json={
                "model": os.environ["LLM_MODEL"],
                "temperature": self.cfg.get("temperature", 0.1),
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=180,
        )
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        return json.loads(content)
