import json
from pathlib import Path
from dataclasses import asdict
from .models import State, Task, Goal, Event

class Store:
    def __init__(self, state_path, ledger_path, checkpoint_dir):
        self.state_path = Path(state_path)
        self.ledger_path = Path(ledger_path)
        self.checkpoint_dir = Path(checkpoint_dir)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def save(self, state):
        state.updated_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(state.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.state_path)

    def load(self):
        if not self.state_path.exists():
            return None
        raw = json.loads(self.state_path.read_text(encoding="utf-8"))
        goal = Goal(**raw["goal"])
        tasks = {k: Task(**v) for k, v in raw["tasks"].items()}
        return State(
            schema_version=raw["schema_version"],
            goal=goal,
            tasks=tasks,
            iteration=raw["iteration"],
            workflow_version=raw["workflow_version"],
            completion_score=raw["completion_score"],
            blockers=raw["blockers"],
            started_at=raw["started_at"],
            updated_at=raw["updated_at"],
        )

    def event(self, event):
        with self.ledger_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(event), ensure_ascii=False) + "\n")

    def checkpoint(self, state):
        p = self.checkpoint_dir / f"iteration-{state.iteration:04d}.json"
        p.write_text(json.dumps(state.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
