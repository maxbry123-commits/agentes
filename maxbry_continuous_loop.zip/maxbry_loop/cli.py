import argparse, pathlib, yaml
from .models import Goal, State, Task, uid
from .persistence import Store
from .model import Model
from .engine import Engine

def load_config(path):
    return yaml.safe_load(pathlib.Path(path).read_text(encoding="utf-8"))

def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--goal")
    r.add_argument("--document")
    r.add_argument("--config", default="config/loop.yaml")
    args = p.parse_args()

    if not args.goal and not args.document:
        raise SystemExit("Use --goal or --document")

    cfg = load_config(args.config)
    text = args.goal or pathlib.Path(args.document).read_text(encoding="utf-8")
    store = Store(cfg["paths"]["state"], cfg["paths"]["ledger"], cfg["paths"]["checkpoints"])
    existing = store.load()

    if existing:
        state = existing
        print(f"Resuming iteration={state.iteration}, workflow_version={state.workflow_version}")
    else:
        goal = Goal(text=text, source="document" if args.document else "chat")
        root = Task(
            id=uid("ROOT"),
            title="Analyze goal and establish initial implementation",
            description="Convert the goal into verifiable work and produce the first implementation increment.",
            priority=100,
            acceptance=["Concrete result exists", "Evidence is recorded", "No dependency integrity errors"],
            provenance={"source": goal.source, "kind": "bootstrap"},
        )
        state = State(schema_version="1.0", goal=goal, tasks={root.id: root})

    engine = Engine(state, store, Model(cfg["model"]), cfg)
    final = engine.run()

    print("=== MAXBRY LOOP ===")
    print(f"iteration: {final.iteration}")
    print(f"workflow_version: {final.workflow_version}")
    print(f"completion_score: {final.completion_score}")
    print(f"blockers: {final.blockers}")
    print(f"tasks: {len(final.tasks)}")

if __name__ == "__main__":
    main()
