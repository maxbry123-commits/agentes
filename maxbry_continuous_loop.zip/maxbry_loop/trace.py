import hashlib, json
from dataclasses import asdict

class TraceEngine:
    def fingerprint(self, state):
        data = []
        for tid in sorted(state.tasks):
            t = state.tasks[tid]
            data.append({
                "id": tid,
                "status": t.status,
                "deps": sorted(t.depends_on),
                "acceptance": t.acceptance,
                "evidence": t.evidence,
                "result": t.result,
            })
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()

    def diff(self, before, after):
        b = before.get("tasks", {})
        a = after.get("tasks", {})
        changes = []
        for tid in sorted(set(b) | set(a)):
            if tid not in b:
                changes.append({"type": "added_task", "task": tid})
            elif tid not in a:
                changes.append({"type": "removed_task", "task": tid})
            elif b[tid] != a[tid]:
                changes.append({"type": "changed_task", "task": tid})
        return changes
