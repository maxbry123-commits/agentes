from .models import Task

class IntegrityError(Exception):
    pass

def validate(state):
    errors = []
    ids = set(state.tasks)
    for tid, t in state.tasks.items():
        if tid != t.id:
            errors.append(f"id mismatch: {tid} != {t.id}")
        for dep in t.depends_on:
            if dep not in ids:
                errors.append(f"{tid}: missing dependency {dep}")
        if tid in t.depends_on:
            errors.append(f"{tid}: self dependency")
    # cycle check
    visiting, visited = set(), set()
    def dfs(n):
        if n in visiting:
            errors.append(f"dependency cycle at {n}")
            return
        if n in visited:
            return
        visiting.add(n)
        for d in state.tasks[n].depends_on:
            if d in state.tasks:
                dfs(d)
        visiting.remove(n)
        visited.add(n)
    for n in state.tasks:
        dfs(n)
    if errors:
        raise IntegrityError("; ".join(errors))
    return True

def ready_tasks(state):
    out = []
    for t in state.tasks.values():
        if t.status != "pending":
            continue
        if all(state.tasks[d].status == "done" for d in t.depends_on):
            out.append(t)
    return sorted(out, key=lambda x: (-x.priority, x.created_at))
